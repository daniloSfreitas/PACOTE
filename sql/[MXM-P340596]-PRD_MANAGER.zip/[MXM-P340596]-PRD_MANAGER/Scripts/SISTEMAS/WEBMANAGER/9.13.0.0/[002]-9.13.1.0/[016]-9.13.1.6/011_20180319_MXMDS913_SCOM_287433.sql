PROMPT ======================================================================
PROMPT == DEMANDA......: 287433
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: LUANA MARIA DE SOUZA
PROMPT == DATA.........: 02/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRETABELARELVISAL_TRV
      SET TRV_NMCONDICAOTABREL = 'TITCPGR_PGRR.PGRR_CDGRUPO = GRPAG_GPA.GPA_CDGRUPO(+) AND REQCOMPRA_RCO.RCO_NUMERO(+) = TITCP_TCPR.TCPR_NOPEDCOMPRA AND TITCPGR_PGRR.PGRR_NOTITULO(+) = TITCP_TCPR.TCPR_NOTITULO AND ((FORNEC_FOR.FOR_CODIGO = TITCPGR_PGRR.PGRR_CDFOR) OR  (TITCPGR_PGRR.PGRR_CDFOR IS NULL))'
 WHERE  TRV_NRVISAO = (SELECT VDR_IDVISAO
                                          FROM GREVISAOTAB_VDR
                                        WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA
                                                                                  FROM GRETABDICDADOS_TDR
                                                                                WHERE TDR_NMTABELA = 'TITCP_TCPR'))
     AND  TRV_NRTABELA = (SELECT TDR_IDTABELA
                                            FROM GRETABDICDADOS_TDR
                                          WHERE TDR_NMTABELA = 'GRPAG_GPA')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287433
PROMPT ======================================================================