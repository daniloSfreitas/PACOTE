PROMPT ======================================================================
PROMPT == DEMANDA......: 277888
PROMPT == SISTEMA......: Comissao
PROMPT == RESPONSAVEL..: MARCEL BRUNO BARREIROS COSTA
PROMPT == DATA.........: 23/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE ALTPARAMSCOMIS_PCO
 (pPCO_EMPRESA  IN CHAR ,
  pPCO_FILIAL   IN CHAR ,
  pPCO_ESTOQUE  IN CHAR ,
  pPCO_GRUPO    IN CHAR ,
  pPCO_ITEM     IN CHAR ,
  pPCO_VENDEDOR IN CHAR ,
  pPCO_COMISSAO IN NUMBER )
AS BEGIN
   UPDATE PARAMSCOMIS_PCO
   SET PCO_ESTOQUE  = pPCO_ESTOQUE ,
       PCO_GRUPO    = pPCO_GRUPO   ,
       PCO_ITEM     = pPCO_ITEM    ,
       PCO_VENDEDOR = pPCO_VENDEDOR,
       PCO_COMISSAO = pPCO_COMISSAO
   WHERE
       PCO_EMPRESA  = pPCO_EMPRESA AND
       PCO_FILIAL   = pPCO_FILIAL  AND
       PCO_ESTOQUE  = pPCO_ESTOQUE AND
       (PCO_GRUPO   = pPCO_GRUPO   OR (pPCO_GRUPO IS NULL AND PCO_GRUPO IS NULL)) AND
       (PCO_ITEM    = pPCO_ITEM    OR (pPCO_ITEM IS NULL AND PCO_ITEM  IS NULL));
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 277888
PROMPT ======================================================================