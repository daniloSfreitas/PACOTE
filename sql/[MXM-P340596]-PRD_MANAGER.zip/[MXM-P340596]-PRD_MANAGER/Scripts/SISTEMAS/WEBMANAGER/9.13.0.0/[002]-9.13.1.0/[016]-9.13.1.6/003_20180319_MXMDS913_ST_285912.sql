PROMPT ======================================================================
PROMPT == DEMANDA......: 285912
PROMPT == SISTEMA......: Tesouraria
PROMPT == RESPONSAVEL..: NIKOLAS DE AGUIAR PONTES
PROMPT == DATA.........: 22/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_STATUSTITULOFLUXO (
   TPMOV        IN   CHAR,
   CDCLIFOR     IN   CHAR,
   NOTITULO     IN   CHAR,
   TPINTEGRACAO IN NUMBER DEFAULT -1
)
   RETURN VARCHAR2
IS
   STATUS  CHAR;
BEGIN
   IF TPMOV = 'P'
   THEN
      IF TPINTEGRACAO IN(41, 19)
      THEN
        SELECT DECODE(NVL(CP.ACP_STATUS, 'P'), 'P', NULL, 'B', 'P')
          INTO STATUS
          FROM ANTECCP_ACP CP
         WHERE CP.ACP_CDFOR = CDCLIFOR AND CP.ACP_DOCANTEC = NOTITULO;
      ELSE
        SELECT CP.TCP_STATUS
          INTO STATUS
          FROM TITCP_TCP CP
         WHERE CP.TCP_CDFOR = CDCLIFOR AND CP.TCP_NOTITULO = NOTITULO;
      END IF;
   ELSE
      SELECT CR.TCR_STATUS
        INTO STATUS
        FROM TITCR_TCR CR
       WHERE CR.TCR_CDCLIENTE = CDCLIFOR AND CR.TCR_NOTITULO = NOTITULO;
   END IF;
   RETURN STATUS;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 285912
PROMPT ======================================================================