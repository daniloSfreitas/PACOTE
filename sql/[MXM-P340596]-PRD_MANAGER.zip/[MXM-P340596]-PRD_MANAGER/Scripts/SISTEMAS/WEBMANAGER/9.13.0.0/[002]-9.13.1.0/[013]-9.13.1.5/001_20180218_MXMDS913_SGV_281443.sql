PROMPT ======================================================================
PROMPT == DEMANDA......: 281443
PROMPT == SISTEMA......: Sistema de gest�o de viagens
PROMPT == RESPONSAVEL..: DIOGO DE FREITAS RODRIGUES
PROMPT == DATA.........: 26/01/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

alter table SGVVIAGEM_VIA modify VIA_CDSTATUS VARCHAR2(2)
/

UPDATE PROCESSOAPROV_PAPR P
SET    P.PAPR_DESCRICAO = 'Informa��o de Pre�o de Viagem'
WHERE  P.PAPR_CDPROCESSO = 24
/

insert into PROCESSOAPROV_PAPR (PAPR_CDPROCESSO, PAPR_DESCRICAO)
values (27, 'Solicita��o de Viagem')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 281443
PROMPT ======================================================================