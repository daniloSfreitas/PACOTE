
/*
====================================================================================
     Data: 06/06/2018  14:34
	 Solicitante:  MAXUEL
	 Motivo: Erro no cliente DPC para entrega do EFDREINF 
===================================================================================  
         
De: Maxuel Santana 
Enviada em: quarta-feira, 6 de junho de 2018 14:13
Para: Paola Farias <paola.farias@mxm.com.br>; admdados <admdados@mxm.com.br>
Cc: Vanderson Guidi <vanderson.guidi@mxm.com.br>
Assunto: pat 293946 DPC Erro no envio R2099 produ��o

Paola,  boa tarde.

Para seu conhecimento.

A corre��o � o script em anexo. Ao pat     Script<< MANTIS_58742.sql.zip>>

Filipe/Leonel,  se poss�vel deixem esse script formatado para envio aos cliente.

ALTER TABLE RNFINFENVIOSREINF_IEF MODIFY IEF_CDPROTOCOLO VARCHAR2(50)
/


Obs.  O Script subira na demanda 293652

*/


ALTER TABLE RNFINFENVIOSREINF_IEF MODIFY IEF_CDPROTOCOLO VARCHAR2(50)
/
