PROMPT ======================================================================
PROMPT == DEMANDA......: 287848
PROMPT == SISTEMA......: Tesouraria
PROMPT == RESPONSAVEL..: LUANA MARIA DE SOUZA
PROMPT == DATA.........: 19/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

   INSERT INTO GREFILTROCAMPOTAB_FCT
  (FCT_IDFILTROCAMPO,
   FCT_NRVISAO,
   FCT_DSFILTRO,
   FCT_TPFILTRO,
   FCT_TPCAMPOFILTRO,
   FCT_NMARQUIVOAJUDA,
   FCT_NMLISTATABELA,
   FCT_NMLISTACONDICAOAJUDA,
   FCT_NMCONDCAMPOCHB,
   FCT_TABELARELVISAO,
   FCT_NMCAMPO,
   FCT_DSFILTROCABECALHO)
VALUES
  ((SELECT MAX(FCT_IDFILTROCAMPO) + 1 FROM GREFILTROCAMPOTAB_FCT),
   (SELECT VDR_IDVISAO
      FROM GREVISAOTAB_VDR
     WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA
                             FROM GRETABDICDADOS_TDR
                            WHERE TDR_NMTABELA = 'MOVIST_MST')),
   'Grupo de Pagamento',
   0,
   0,
   'GRPAG_GPA',
   null,
   null,
   null,
   (SELECT TRV_IDTABELARELVISAO
      FROM GRETABELARELVISAL_TRV
     WHERE TRV_NRVISAO =
           (SELECT VDR_IDVISAO
              FROM GREVISAOTAB_VDR
             WHERE VDR_NRTABELA =
                   (SELECT TDR_IDTABELA
                      FROM GRETABDICDADOS_TDR
                     WHERE TDR_NMTABELA = 'MOVIST_MST'))
       AND TRV_NRTABELA =
           (SELECT TDR_IDTABELA
              FROM GRETABDICDADOS_TDR
             WHERE TDR_NMTABELA = 'GRPAG_GPA')),
   'GRPAG_GPA.GPA_CDGRUPO',
   'Grupo de Pagamento')
   
/

      INSERT INTO GREFILTROCAMPOTAB_FCT
  (FCT_IDFILTROCAMPO,
   FCT_NRVISAO,
   FCT_DSFILTRO,
   FCT_TPFILTRO,
   FCT_TPCAMPOFILTRO,
   FCT_NMARQUIVOAJUDA,
   FCT_NMLISTATABELA,
   FCT_NMLISTACONDICAOAJUDA,
   FCT_NMCONDCAMPOCHB,
   FCT_TABELARELVISAO,
   FCT_NMCAMPO,
   FCT_DSFILTROCABECALHO)
VALUES
  ((SELECT MAX(FCT_IDFILTROCAMPO) + 1 FROM GREFILTROCAMPOTAB_FCT),
   (SELECT VDR_IDVISAO
      FROM GREVISAOTAB_VDR
     WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA
                             FROM GRETABDICDADOS_TDR
                            WHERE TDR_NMTABELA = 'MOVIST_MST')),
   'Grupo de Recebimento',
   0,
   0,
   'GRREC_GRE',
   null,
   null,
   null,
   (SELECT TRV_IDTABELARELVISAO
      FROM GRETABELARELVISAL_TRV
     WHERE TRV_NRVISAO =
           (SELECT VDR_IDVISAO
              FROM GREVISAOTAB_VDR
             WHERE VDR_NRTABELA =
                   (SELECT TDR_IDTABELA
                      FROM GRETABDICDADOS_TDR
                     WHERE TDR_NMTABELA = 'MOVIST_MST'))
       AND TRV_NRTABELA =
           (SELECT TDR_IDTABELA
              FROM GRETABDICDADOS_TDR
             WHERE TDR_NMTABELA = 'GRREC_GRE')),
   'GRREC_GRE.GRE_CDGRUPO',
   'Grupo de Recebimento')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287848
PROMPT ======================================================================