PROMPT ======================================================================
PROMPT == DEMANDA......: 285611
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: JULIAN CHAVES ALVES
PROMPT == DATA.........: 06/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE TABLE EFDAJUSTEIPI_AJI
(
  AJI_IDAJUSTEIPI      NUMBER(12) NOT NULL,
  AJI_NRITDOCFIS       NUMBER(12) NOT NULL,
  AJI_TPAJUSTE         NUMBER(1) NOT NULL,
  AJI_CDAJUSTE         VARCHAR2(3) NOT NULL,
  AJI_VLALIQIPI        NUMBER(5,2) NOT NULL,
  AJI_VLAJUSTE         NUMBER(15,2) NOT NULL,
  AJI_TPORIGEM         NUMBER(1) NOT NULL,
  AJI_NRDOCUMENTO      VARCHAR2(60),
  AJI_TXDESCRICAORESUM VARCHAR2(200),
  AJI_DTINCLUSAO       DATE NOT NULL,
  AJI_DTALTERACAO      DATE,
  AJI_USINCLUSAO       VARCHAR2(30) NOT NULL,
  AJI_USALTERACAO      VARCHAR2(30)
)
/

COMMENT ON TABLE EFDAJUSTEIPI_AJI IS 'Manter as informa��es dos ajustes de IPI.'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_IDAJUSTEIPI IS 'Identificador de ajuste de IPI'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_NRITDOCFIS IS 'Identificador dos itens de documento fiscal'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_TPAJUSTE IS 'Tipo de ajuste [0,1]'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_CDAJUSTE IS 'C�digo do ajuste'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_VLALIQIPI IS 'Al�quota usada no c�lculo do ajuste de IPI'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_VLAJUSTE IS 'Valor do ajuste.'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_TPORIGEM IS 'Indicador da origem do documento [0,1,2,3 e 9]'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_NRDOCUMENTO IS 'N�mero do documento / processo / declara��o.'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_TXDESCRICAORESUM is 'Descri��o resumida.'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_DTINCLUSAO IS 'Indica��o do dia, m�s e ano em que a informa��o foi criada na base de dados'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_DTALTERACAO IS 'Indica��o do dia, m�s e ano em que a informa��o foi alterada na base de dados'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_USINCLUSAO IS 'O respons�vel por realizar a cria��o das informa��es na base de dados'
/

COMMENT ON COLUMN EFDAJUSTEIPI_AJI.AJI_USALTERACAO IS 'O respons�vel por realizar a altera��o das informa��es na base de dados'
/

ALTER TABLE EFDAJUSTEIPI_AJI ADD CONSTRAINT PK_EFDAJUSTEIPI_AJI PRIMARY KEY (AJI_IDAJUSTEIPI)
/

ALTER TABLE EFDAJUSTEIPI_AJI ADD CONSTRAINT FK1_EFDAJUSTEIPI_AJI FOREIGN KEY (AJI_NRITDOCFIS) REFERENCES SPEDITDOCFIS_IDF (IDF_SQITDOCFIS)
/

ALTER TABLE EFDAJUSTEIPI_AJI ADD CONSTRAINT FK2_EFDAJUSTEIPI_AJI FOREIGN KEY (AJI_CDAJUSTE) REFERENCES SPEDCODAJIPI_SAI (SAI_CODIGO)
/

CREATE SEQUENCE SEQ1_EFDAJUSTEIPI_AJI
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

CREATE OR REPLACE PROCEDURE PRC_INSEFDAJUSTEIPI_AJI(
 PAJI_IDAJUSTEIPI IN OUT NUMBER
,PAJI_NRITDOCFIS IN NUMBER
,PAJI_TPAJUSTE IN NUMBER
,PAJI_CDAJUSTE IN CHAR
,PAJI_VLALIQIPI IN NUMBER
,PAJI_VLAJUSTE IN NUMBER
,PAJI_TPORIGEM IN NUMBER
,PAJI_NRDOCUMENTO IN CHAR DEFAULT NULL
,PAJI_TXDESCRICAORESUM IN CHAR DEFAULT NULL
)
AS
BEGIN
  IF PAJI_IDAJUSTEIPI IS NULL THEN
   SELECT SEQ1_EFDAJUSTEIPI_AJI.NEXTVAL INTO PAJI_IDAJUSTEIPI FROM DUAL;
  END IF;
  INSERT INTO EFDAJUSTEIPI_AJI(
    AJI_IDAJUSTEIPI
   ,AJI_NRITDOCFIS
   ,AJI_TPAJUSTE
   ,AJI_CDAJUSTE
   ,AJI_VLALIQIPI
   ,AJI_VLAJUSTE
   ,AJI_TPORIGEM
   ,AJI_NRDOCUMENTO
   ,AJI_TXDESCRICAORESUM
   ,AJI_DTINCLUSAO
   ,AJI_USINCLUSAO
) VALUES (
    PAJI_IDAJUSTEIPI
   ,PAJI_NRITDOCFIS
   ,PAJI_TPAJUSTE
   ,PAJI_CDAJUSTE
   ,PAJI_VLALIQIPI
   ,PAJI_VLAJUSTE
   ,PAJI_TPORIGEM
   ,PAJI_NRDOCUMENTO
   ,PAJI_TXDESCRICAORESUM
   ,SYSDATE
   ,GET_USER_MXM
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTEFDAJUSTEIPI_AJI(
 PAJI_IDAJUSTEIPI IN NUMBER
,PAJI_NRITDOCFIS IN NUMBER
,PAJI_TPAJUSTE IN NUMBER
,PAJI_CDAJUSTE IN CHAR
,PAJI_VLALIQIPI IN NUMBER
,PAJI_VLAJUSTE IN NUMBER
,PAJI_TPORIGEM IN NUMBER
,PAJI_NRDOCUMENTO IN CHAR DEFAULT NULL
,PAJI_TXDESCRICAORESUM IN CHAR DEFAULT NULL
)
AS
BEGIN
  UPDATE EFDAJUSTEIPI_AJI
     SET AJI_IDAJUSTEIPI = PAJI_IDAJUSTEIPI
        ,AJI_NRITDOCFIS = PAJI_NRITDOCFIS
        ,AJI_TPAJUSTE = PAJI_TPAJUSTE
        ,AJI_CDAJUSTE = PAJI_CDAJUSTE
        ,AJI_VLALIQIPI = PAJI_VLALIQIPI
        ,AJI_VLAJUSTE = PAJI_VLAJUSTE
        ,AJI_TPORIGEM = PAJI_TPORIGEM
        ,AJI_NRDOCUMENTO = PAJI_NRDOCUMENTO
        ,AJI_TXDESCRICAORESUM = PAJI_TXDESCRICAORESUM
        ,AJI_DTALTERACAO = SYSDATE
        ,AJI_USALTERACAO = GET_USER_MXM
   WHERE AJI_IDAJUSTEIPI = PAJI_IDAJUSTEIPI;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCEFDAJUSTEIPI_AJI(
 PAJI_IDAJUSTEIPI IN NUMBER
)
AS
BEGIN
  DELETE FROM EFDAJUSTEIPI_AJI
   WHERE AJI_IDAJUSTEIPI = PAJI_IDAJUSTEIPI;
END;
/

DELETE FROM TIPOENUMERADO_TENU WHERE TENU_CDTPENUMERADO = 'TPENU_TIPOAJUSTEIPI'
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENU_TIPOAJUSTEIPI','0','Ajuste a d�bito')
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENU_TIPOAJUSTEIPI','1','Ajuste a cr�dito')
/

DELETE FROM TIPOENUMERADO_TENU WHERE TENU_CDTPENUMERADO = 'TPENU_INDORIGEMAJUSTEIPI'
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENU_INDORIGEMAJUSTEIPI','0','Processo Judicial')
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENU_INDORIGEMAJUSTEIPI','1','Processo Administrativo')
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENU_INDORIGEMAJUSTEIPI','2','PER/DCOMP')
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENU_INDORIGEMAJUSTEIPI','3','Documento Fiscal')
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENU_INDORIGEMAJUSTEIPI','9','Outros')
/

DELETE FROM ERROMSG_ERM E WHERE E.ERM_CDERRO IN ('AJI0001','AJI0002','AJI0003','AJI0004','AJI0005','AJI0006','AJI0007','AJI0008','AJI0009','AJI0010','AJI0011','AJI0012')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0001','O tipo de ajuste � obrigat�rio.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0002','O tipo de ajuste � inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0003','O c�digo do ajuste � obrigat�rio.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0004','O c�digo do ajuste � inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0005','O c�digo do ajuste n�o � compat�vel com o tipo de ajuste informado.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0006','A al�quota do ajuste � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0007','O valor do ajuste deve ser maior que zero.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0008','O valor informado n�o est� batendo com o calculado pelo sistema.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0009','A origem do ajuste � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0010','A origem do ajuste � inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0011','N�o deve ser informado o n�mero do documento quando a origem do ajuste for "3 - Documento Fiscal".')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('AJI0012','A origem do ajuste "3 - Documento Fiscal", deve ser usada somente para os modelos de documento fiscal "01" e "55".')
/

Insert into LAYOUTMOD_LYM   (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) Values   ('EFD - DOC. FISCAL', 'TSDF_CDMUNORIGEM', 90, 'C�digo do Munic�pio de Origem (mod 57 e 67)', 'C',  7, 0, 0)
/

Insert into LAYOUTMOD_LYM   (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) Values   ('EFD - DOC. FISCAL', 'TSDF_CDMUNDEST', 91, 'C�digo do Munic�pio de Destino (mod 57 e 67)', 'C', 7, 0, 0)
/

Insert into LAYOUTCOD_LYC   (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_INDEX) Values   ('01', 'EFD - DOC. FISCAL', 'TSDF_CDMUNORIGEM', 'C', 1192, 7, 0, 0)
/

Insert into LAYOUTCOD_LYC   (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_INDEX) Values   ('01', 'EFD - DOC. FISCAL', 'TSDF_CDMUNDEST', 'C', 1199,    7, 0, 0)
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO IN ( 'SDF0178', 'SDF0179',  'SDF0180', 'SDF0181')
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES ( 'SDF0178','C�digo do munic�pio de origem inexistente')
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES ('SDF0179','C�digo do munic�pio de origem obrigatorio')
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES ('SDF0180','C�digo do munic�pio de destino inexistente')
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES ('SDF0181','C�digo do munic�pio de destino obrigatorio')
/

ALTER TABLE TI_ARQSPEDDOCFIS_TSDF ADD TSDF_CDMUNORIGEM VARCHAR2(7) DEFAULT NULL
/

COMMENT ON COLUMN TI_ARQSPEDDOCFIS_TSDF.TSDF_CDMUNORIGEM IS 'C�digo do munic�pio de origem do servi�o'
/

ALTER TABLE TI_ARQSPEDDOCFIS_TSDF ADD TSDF_CDMUNDEST VARCHAR2(7) DEFAULT NULL
/

COMMENT ON COLUMN TI_ARQSPEDDOCFIS_TSDF.TSDF_CDMUNDEST IS 'C�digo do munic�pio de destino'
/

CREATE OR REPLACE PROCEDURE INSTI_ARQSPEDDOCFIS_TSDF
(PTSDF_SQPROCESSO IN NUMBER,
 PTSDF_SQREGISTRO IN NUMBER,
 PTSDF_STOPERACAO IN NUMBER,
 PTSDF_CDEMPRESA IN CHAR,
 PTSDF_CDFILIAL IN CHAR,
 PTSDF_CDTPOPER IN CHAR,
 PTSDF_MODELO IN CHAR,
 PTSDF_SERIE IN CHAR,
 PTSDF_SUBSERIE IN CHAR,
 PTSDF_EMITENTE IN CHAR,
 PTSDF_TPCLIFOR IN CHAR,
 PTSDF_CDCLIFOR IN CHAR,
 PTSDF_DOCUMENTO IN CHAR,
 PTSDF_CDSITDOC IN CHAR,
 PTSDF_DTEMISSAO IN CHAR,
 PTSDF_DTENTRADA IN CHAR,
 PTSDF_DTESCRIT IN CHAR,
 PTSDF_VLTOTAL IN CHAR,
 PTSDF_VLSERNTRIB IN CHAR,
 PTSDF_TPCTE IN CHAR,
 PTSDF_CHAVECTE IN CHAR,
 PTSDF_CHAVECTE_REF IN CHAR,
 PTSDF_CDINFCOMP IN CHAR,
 PTSDF_CONTACTB IN CHAR,
 PTSDF_VBIMPOSTOINF IN CHAR,
 PTSDF_VLBCISSQN IN CHAR,
 PTSDF_VLISSQN IN CHAR,
 PTSDF_VLIRRF IN CHAR,
 PTSDF_INDEMITENTE IN CHAR,
 PTSDF_INDTITULO IN CHAR,
 PTSDF_NUMTITULO IN CHAR,
 PTSDF_QTDPARCELAS IN CHAR,
 PTSDF_DESCTITULO IN CHAR,
 PTSDF_VLTOTALTITULO IN CHAR,
 PTSDF_CLIFORTRANSP IN CHAR,
 PTSDF_CDCLIFORTRANSP IN CHAR,
 PTSDF_VEICULOID IN CHAR,
 PTSDF_QTDVOLUME IN CHAR,
 PTSDF_PESOBRT IN CHAR,
 PTSDF_PESOLIQ IN CHAR,
 PTSDF_IDUF IN CHAR,
 PTSDF_ABATNTRIB IN CHAR,
 PTSDF_VLPREV IN CHAR,
 PTSDF_VLBCPREV IN CHAR,
 PTSDF_VLBCIRRF IN CHAR,
 PTSDF_VLSERVNT IN CHAR,
 PTSDF_CHAVENFE IN CHAR,
 PTSDF_CDINDPAG  IN CHAR,
 PTSDF_VLCOFINSST IN CHAR,
 PTSDF_CDESTOQUE IN CHAR DEFAULT NULL,
 PTSDF_VLPISST IN CHAR DEFAULT NULL,
 PTSDF_CLASSECONS IN CHAR DEFAULT NULL,
 PTSDF_VLBCICMS IN CHAR DEFAULT NULL,
 PTSDF_VLICMS IN CHAR DEFAULT NULL,
 PTSDF_VLBCICMSST IN CHAR DEFAULT NULL,
 PTSDF_VLICMSST IN CHAR DEFAULT NULL,
 PTSDF_VLPIS IN CHAR DEFAULT NULL,
 PTSDF_VLCOFINS IN CHAR DEFAULT NULL,
 PTSDF_VLIPI IN CHAR DEFAULT NULL,
 PTSDF_VLESPEC IN CHAR DEFAULT NULL,
 PTSDF_VLTERCEIROS IN CHAR DEFAULT NULL,
 PTSDF_VLSEGUROS IN CHAR DEFAULT NULL,
 PTSDF_DESPESASAC IN CHAR DEFAULT NULL,
 PTSDF_INDTPFRETE IN CHAR DEFAULT NULL,
 PTSDF_VLFRETE IN CHAR DEFAULT NULL,
 PTSDF_CONTABINF IN CHAR DEFAULT NULL,
 PTSDF_VLBIICMS IN CHAR DEFAULT NULL,
 PTSDF_VLBOICMS IN CHAR DEFAULT NULL,
 PTSDF_VLBIIPI IN CHAR DEFAULT NULL,
 PTSDF_VLBOIPI IN CHAR DEFAULT NULL,
 PTSDF_ISAJUSTE IN CHAR DEFAULT NULL,
 PTSDF_CODUTILIZACAO IN CHAR DEFAULT NULL,
 PTSDF_VBIMPORTADO IN CHAR DEFAULT NULL,
 PTSDF_VBIMPORTADOXML IN CHAR DEFAULT NULL,
 PTSDF_SEGMOEDA IN CHAR DEFAULT NULL,
 PTSDF_TAXASEGMOEDA IN CHAR DEFAULT NULL,
 PTSDF_UFOPER IN CHAR DEFAULT NULL,
 PTSDF_OPER IN CHAR DEFAULT NULL,
 PTSDF_TPLIGACAO IN CHAR DEFAULT NULL,
 PTSDF_GRUPOTENSAO IN CHAR DEFAULT NULL,
 PTSDF_TPASSINANTE IN CHAR DEFAULT NULL,
 PTSDF_CDENDCLIFOR IN CHAR DEFAULT NULL,
 PTSDF_SYSTEM IN CHAR DEFAULT NULL,
 PTSDF_ALIQIRRF IN CHAR DEFAULT NULL,
 PTSDF_ALIQCSLL IN CHAR DEFAULT NULL,
 PTSDF_BCCSLL IN CHAR DEFAULT NULL,
 PTSDF_VLCSLL IN CHAR DEFAULT NULL,
 PTSDF_ALIQINSS IN CHAR DEFAULT NULL,
 PTSDF_VOLESPEC IN CHAR DEFAULT NULL,
 PTSDF_VIATTRANSP IN CHAR DEFAULT NULL,
 PTSDF_CDTIPOTITULO IN CHAR DEFAULT NULL,
 PTSDF_VLTOTDESC IN CHAR DEFAULT NULL,
 PTSDF_NMARQUIVO IN CHAR DEFAULT NULL,
 PTSDF_VLTOTALII IN CHAR DEFAULT NULL,
 PTSDF_CDALMOXARIFADO IN CHAR DEFAULT NULL,
 PTSDF_CDMUNORIGEM IN CHAR DEFAULT NULL,
 PTSDF_CDMUNDEST IN CHAR DEFAULT NULL
)
AS
BEGIN
  INSERT INTO TI_ARQSPEDDOCFIS_TSDF(
      TSDF_SQPROCESSO,
      TSDF_SQREGISTRO,
      TSDF_STOPERACAO,
      TSDF_CDEMPRESA,
      TSDF_CDFILIAL,
      TSDF_CDTPOPER,
      TSDF_MODELO,
      TSDF_SERIE,
      TSDF_SUBSERIE,
      TSDF_EMITENTE,
      TSDF_TPCLIFOR,
      TSDF_CDCLIFOR,
      TSDF_DOCUMENTO,
      TSDF_CDSITDOC,
      TSDF_DTEMISSAO,
      TSDF_DTENTRADA,
      TSDF_DTESCRIT,
      TSDF_VLTOTAL,
      TSDF_VLSERNTRIB,
      TSDF_TPCTE,
      TSDF_CHAVECTE,
      TSDF_CHAVECTE_REF,
      TSDF_CDINFCOMP,
      TSDF_CONTACTB,
      TSDF_VBIMPOSTOINF,
      TSDF_VLBCISSQN,
      TSDF_VLISSQN,
      TSDF_VLIRRF,
      TSDF_INDEMITENTE,
      TSDF_INDTITULO,
      TSDF_NUMTITULO,
      TSDF_QTDPARCELAS,
      TSDF_DESCTITULO,
      TSDF_VLTOTALTITULO,
      TSDF_CLIFORTRANSP,
      TSDF_CDCLIFORTRANSP,
      TSDF_VEICULOID,
      TSDF_QTDVOLUME,
      TSDF_PESOBRT,
      TSDF_PESOLIQ,
      TSDF_IDUF,
      TSDF_ABATNTRIB,
      TSDF_VLPREV,
      TSDF_VLBCPREV,
      TSDF_VLBCIRRF,
      TSDF_VLSERVNT,
      TSDF_CHAVENFE,
      TSDF_CDINDPAG,
      --TSDF_VLCOFINSST,
      TSDF_CDESTOQUE,
      TSDF_VLPISST,
      TSDF_VLCOFINSST,
      TSDF_CLASSECONS,
      TSDF_VLBCICMS,
      TSDF_VLICMS,
      TSDF_VLBCICMSST,
      TSDF_VLICMSST,
      TSDF_VLPIS,
      TSDF_VLCOFINS,
      TSDF_VLIPI,
      TSDF_VLESPEC,
      TSDF_VLTERCEIROS,
      TSDF_VLSEGUROS,
      TSDF_DESPESASAC,
      TSDF_INDTPFRETE,
      TSDF_VLFRETE,
      TSDF_CONTABINF,
      TSDF_VLBIICMS,
      TSDF_VLBOICMS,
      TSDF_VLBIIPI,
      TSDF_VLBOIPI,
      TSDF_ISAJUSTE,
      TSDF_CODUTILIZACAO,
      TSDF_VBIMPORTADO,
      TSDF_VBIMPORTADOXML,
      TSDF_SEGMOEDA,
      TSDF_TAXASEGMOEDA,
      TSDF_UFOPER,
      TSDF_OPER,
      TSDF_TPLIGACAO,
      TSDF_GRUPOTENSAO,
      TSDF_TPASSINANTE,
      TSDF_CDENDCLIFOR,
      TSDF_SYSTEM,
      TSDF_ALIQIRRF,
      TSDF_ALIQCSLL,
      TSDF_BCCSLL,
      TSDF_VLCSLL,
      TSDF_ALIQINSS,
      TSDF_VOLESPEC,
      TSDF_VIATTRANSP,
      TSDF_CDTIPOTITULO,
      TSDF_VLTOTDESC,
      TSDF_NMARQUIVO,
      TSDF_VLTOTALII,
      TSDF_CDALMOXARIFADO,
      TSDF_CDMUNORIGEM,
      TSDF_CDMUNDEST
) VALUES (
      PTSDF_SQPROCESSO,
      PTSDF_SQREGISTRO,
      PTSDF_STOPERACAO,
      PTSDF_CDEMPRESA,
      PTSDF_CDFILIAL,
      PTSDF_CDTPOPER,
      PTSDF_MODELO,
      PTSDF_SERIE,
      PTSDF_SUBSERIE,
      PTSDF_EMITENTE,
      PTSDF_TPCLIFOR,
      PTSDF_CDCLIFOR,
      PTSDF_DOCUMENTO,
      PTSDF_CDSITDOC,
      PTSDF_DTEMISSAO,
      PTSDF_DTENTRADA,
      PTSDF_DTESCRIT,
      PTSDF_VLTOTAL,
      PTSDF_VLSERNTRIB,
      PTSDF_TPCTE,
      PTSDF_CHAVECTE,
      PTSDF_CHAVECTE_REF,
      PTSDF_CDINFCOMP,
      PTSDF_CONTACTB,
      PTSDF_VBIMPOSTOINF,
      PTSDF_VLBCISSQN,
      PTSDF_VLISSQN,
      PTSDF_VLIRRF,
      PTSDF_INDEMITENTE,
      PTSDF_INDTITULO,
      PTSDF_NUMTITULO,
      PTSDF_QTDPARCELAS,
      PTSDF_DESCTITULO,
      PTSDF_VLTOTALTITULO,
      PTSDF_CLIFORTRANSP,
      PTSDF_CDCLIFORTRANSP,
      PTSDF_VEICULOID,
      PTSDF_QTDVOLUME,
      PTSDF_PESOBRT,
      PTSDF_PESOLIQ,
      PTSDF_IDUF,
      PTSDF_ABATNTRIB,
      PTSDF_VLPREV,
      PTSDF_VLBCPREV,
      PTSDF_VLBCIRRF,
      PTSDF_VLSERVNT,
      PTSDF_CHAVENFE,
      PTSDF_CDINDPAG,
      --PTSDF_VLCOFINSST,
      PTSDF_CDESTOQUE,
      PTSDF_VLPISST,
      PTSDF_VLCOFINSST,
      PTSDF_CLASSECONS,
      PTSDF_VLBCICMS,
      PTSDF_VLICMS,
      PTSDF_VLBCICMSST,
      PTSDF_VLICMSST,
      PTSDF_VLPIS,
      PTSDF_VLCOFINS,
      PTSDF_VLIPI,
      PTSDF_VLESPEC,
      PTSDF_VLTERCEIROS,
      PTSDF_VLSEGUROS,
      PTSDF_DESPESASAC,
      PTSDF_INDTPFRETE,
      PTSDF_VLFRETE,
      PTSDF_CONTABINF,
      PTSDF_VLBIICMS,
      PTSDF_VLBOICMS,
      PTSDF_VLBIIPI,
      PTSDF_VLBOIPI,
      PTSDF_ISAJUSTE,
      PTSDF_CODUTILIZACAO,
      PTSDF_VBIMPORTADO,
      PTSDF_VBIMPORTADOXML,
      PTSDF_SEGMOEDA,
      PTSDF_TAXASEGMOEDA,
      PTSDF_UFOPER,
      PTSDF_OPER,
      PTSDF_TPLIGACAO,
      PTSDF_GRUPOTENSAO,
      PTSDF_TPASSINANTE,
      PTSDF_CDENDCLIFOR,
      PTSDF_SYSTEM,
      PTSDF_ALIQIRRF,
      PTSDF_ALIQCSLL,
      PTSDF_BCCSLL,
      PTSDF_VLCSLL,
      PTSDF_ALIQINSS,
      PTSDF_VOLESPEC,
      PTSDF_VIATTRANSP,
      PTSDF_CDTIPOTITULO,
      PTSDF_VLTOTDESC,
      PTSDF_NMARQUIVO,
      PTSDF_VLTOTALII,
      PTSDF_CDALMOXARIFADO,
      PTSDF_CDMUNORIGEM,
      PTSDF_CDMUNDEST
);
END;
/

ALTER TABLE EFD_ICMSIPIBLK220_K03 ADD K03_QTDESTINO VARCHAR2(15) DEFAULT '0'
/

COMMENT ON COLUMN EFD_ICMSIPIBLK220_K03.K03_QTDESTINO IS 'Quantidade movimentada do item de destino'
/

CREATE OR REPLACE PROCEDURE PRC_INSEFD_ICMSIPIBLK220_K03(
 PK03_IDREGK220 IN OUT NUMBER
,PK01_IDREGK100 IN NUMBER
,PSMECODIGO IN CHAR
,PK03_CDREG IN CHAR DEFAULT NULL
,PK03_DTMOV IN CHAR DEFAULT NULL
,PK03_CDITEMORI IN CHAR DEFAULT NULL
,PK03_CDITEMDEST IN CHAR DEFAULT NULL
,PK03_QTMOVIMENTADA IN CHAR DEFAULT NULL
,PK03_QTDESTINO IN CHAR DEFAULT '0'
)
AS
BEGIN
  IF PK03_IDREGK220 IS NULL THEN
   SELECT SEQ1_EFD_ICMSIPIBLK220_K03.NEXTVAL INTO PK03_IDREGK220 FROM DUAL;
  END IF;
  INSERT INTO EFD_ICMSIPIBLK220_K03(
    K03_IDREGK220
   ,K01_IDREGK100
   ,SMECODIGO
   ,K03_CDREG
   ,K03_DTMOV
   ,K03_CDITEMORI
   ,K03_CDITEMDEST
   ,K03_QTMOVIMENTADA
   ,K03_USINCLUSAO
   ,K03_DTINCLUSAO
   ,K03_QTDESTINO
) VALUES (
    PK03_IDREGK220
   ,PK01_IDREGK100
   ,PSMECODIGO
   ,PK03_CDREG
   ,PK03_DTMOV
   ,PK03_CDITEMORI
   ,PK03_CDITEMDEST
   ,PK03_QTMOVIMENTADA
   ,GET_USER_MXM
   ,SYSDATE
   ,PK03_QTDESTINO
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTEFD_ICMSIPIBLK220_K03(
 PK03_IDREGK220 IN NUMBER
,PK01_IDREGK100 IN NUMBER
,PSMECODIGO IN CHAR
,PK03_CDREG IN CHAR DEFAULT NULL
,PK03_DTMOV IN CHAR DEFAULT NULL
,PK03_CDITEMORI IN CHAR DEFAULT NULL
,PK03_CDITEMDEST IN CHAR DEFAULT NULL
,PK03_QTMOVIMENTADA IN CHAR DEFAULT NULL
,PK03_QTDESTINO IN CHAR DEFAULT '0'
)
AS
BEGIN
  UPDATE EFD_ICMSIPIBLK220_K03
     SET K03_IDREGK220 = PK03_IDREGK220
        ,K01_IDREGK100 = PK01_IDREGK100
        ,SMECODIGO = PSMECODIGO
        ,K03_CDREG = PK03_CDREG
        ,K03_DTMOV = PK03_DTMOV
        ,K03_CDITEMORI = PK03_CDITEMORI
        ,K03_CDITEMDEST = PK03_CDITEMDEST
        ,K03_QTMOVIMENTADA = PK03_QTMOVIMENTADA
        ,K03_USALTERACAO = GET_USER_MXM
        ,K03_DTALTERACAO = SYSDATE
        ,K03_QTDESTINO = PK03_QTDESTINO
   WHERE K03_IDREGK220 = PK03_IDREGK220;
END;
/

ALTER TABLE EFDBLOCKMOVINTMERC_BMI ADD BMI_QTDESTINO NUMBER(15,3) DEFAULT 0
/

COMMENT ON COLUMN  EFDBLOCKMOVINTMERC_BMI.BMI_QTDESTINO IS 'Quantidade movimentada do item de destino'
/

CREATE OR REPLACE PROCEDURE PRC_INSEFDBLOCKMOVINTMERC_BMI(
 PBMI_IDMOVINTMERC IN OUT NUMBER
,PBMI_NRBPA IN NUMBER
,PBMI_DTMOVIMENTACAOINTERNA IN DATE
,PBMI_CDPRDORIGEM IN CHAR
,PBMI_CDPRDDESTINO IN CHAR
,PBMI_QTMOVIMENTADA IN NUMBER
,PBMI_QTDESTINO IN NUMBER DEFAULT 0
)
AS
BEGIN
  IF PBMI_IDMOVINTMERC IS NULL THEN
   SELECT SEQ1_EFDBLOCKMOVINTMERC_BMI.NEXTVAL INTO PBMI_IDMOVINTMERC FROM DUAL;
  END IF;
  INSERT INTO EFDBLOCKMOVINTMERC_BMI(
    BMI_IDMOVINTMERC
   ,BMI_NRBPA
   ,BMI_DTMOVIMENTACAOINTERNA
   ,BMI_CDPRDORIGEM
   ,BMI_CDPRDDESTINO
   ,BMI_QTMOVIMENTADA
   ,BMI_DTINCLUSAO
   ,BMI_USINCLUSAO
   ,BMI_QTDESTINO
) VALUES (
    PBMI_IDMOVINTMERC
   ,PBMI_NRBPA
   ,PBMI_DTMOVIMENTACAOINTERNA
   ,PBMI_CDPRDORIGEM
   ,PBMI_CDPRDDESTINO
   ,PBMI_QTMOVIMENTADA
   ,SYSDATE
   ,GET_USER_MXM
   ,PBMI_QTDESTINO
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTEFDBLOCKMOVINTMERC_BMI(
 PBMI_IDMOVINTMERC IN NUMBER
,PBMI_NRBPA IN NUMBER
,PBMI_DTMOVIMENTACAOINTERNA IN DATE
,PBMI_CDPRDORIGEM IN CHAR
,PBMI_CDPRDDESTINO IN CHAR
,PBMI_QTMOVIMENTADA IN NUMBER
,PBMI_QTDESTINO IN NUMBER DEFAULT 0
)
AS
BEGIN
  UPDATE EFDBLOCKMOVINTMERC_BMI
     SET BMI_IDMOVINTMERC = PBMI_IDMOVINTMERC
        ,BMI_NRBPA = PBMI_NRBPA
        ,BMI_DTMOVIMENTACAOINTERNA = PBMI_DTMOVIMENTACAOINTERNA
        ,BMI_CDPRDORIGEM = PBMI_CDPRDORIGEM
        ,BMI_CDPRDDESTINO = PBMI_CDPRDDESTINO
        ,BMI_QTMOVIMENTADA = PBMI_QTMOVIMENTADA
        ,BMI_DTALTERACAO = SYSDATE
        ,BMI_USALTERACAO = GET_USER_MXM
        ,BMI_QTDESTINO = PBMI_QTDESTINO
   WHERE BMI_IDMOVINTMERC = PBMI_IDMOVINTMERC;
END;
/

ALTER TABLE SPEDDOCFIS_SDF ADD SDF_CDMUNORIGEM VARCHAR2(7) DEFAULT NULL
/

CREATE INDEX IN3_SPEDDOCFIS_SDF ON SPEDDOCFIS_SDF (SDF_CDMUNORIGEM)
/

ALTER TABLE SPEDDOCFIS_SDF ADD SDF_CDMUNDEST VARCHAR2(7) DEFAULT NULL
/

CREATE INDEX IN4_SPEDDOCFIS_SDF ON SPEDDOCFIS_SDF (SDF_CDMUNDEST)
/

ALTER TABLE SPEDDOCFIS_SDF ADD CONSTRAINT FK6_SPEDDOCFIS_SDF  FOREIGN KEY (SDF_CDMUNORIGEM)   REFERENCES  SPEDTABMUNICIBGE_TMI (TMI_CODIGO)
/

ALTER TABLE SPEDDOCFIS_SDF ADD CONSTRAINT FK7_SPEDDOCFIS_SDF  FOREIGN KEY (SDF_CDMUNDEST)   REFERENCES  SPEDTABMUNICIBGE_TMI (TMI_CODIGO)
/

CREATE OR REPLACE PROCEDURE INSSPEDDOCFIS_SDF(PSDF_SQDOCFIS                   IN OUT NUMBER
                                            , PSDF_CDEMPRESA                  IN     CHAR
                                            , PSDF_CDFILIAL                   IN     CHAR
                                            , PSDF_TPOP                       IN     CHAR
                                            , PSDF_MODELO                     IN     CHAR
                                            , PSDF_SERIE                      IN     CHAR
                                            , PSDF_SUBSERIE                   IN     CHAR
                                            , PSDF_EMITENTE                   IN     CHAR
                                            , PSDF_CLIFOR                     IN     CHAR
                                            , PSDF_CDCLIFOR                   IN     CHAR
                                            , PSDF_DOCUMENTO                  IN     CHAR
                                            , PSDF_DATAEMISS                  IN     DATE
                                            , PSDF_DATAENTR                   IN     DATE
                                            , PSDF_DATAESCR                   IN     DATE
                                            , PSDF_SITDOC                     IN     CHAR
                                            , PSDF_VLTOTAL                    IN     NUMBER
                                            , PSDF_CHAVENFE                   IN     CHAR
                                            , PSDF_INDPAG                     IN     CHAR
                                            , PSDF_CLASSECONS                 IN     CHAR
                                            , PSDF_VLBCICMS                   IN     NUMBER
                                            , PSDF_VLICMS                     IN     NUMBER
                                            , PSDF_VLBCICMSST                 IN     NUMBER
                                            , PSDF_VLICMSST                   IN     NUMBER
                                            , PSDF_VLPIS                      IN     NUMBER
                                            , PSDF_VLCOFINS                   IN     NUMBER
                                            , PSDF_VLPISST                    IN     NUMBER
                                            , PSDF_VLCOFINSST                 IN     NUMBER
                                            , PSDF_VLIPI                      IN     NUMBER
                                            , PSDF_VLTOTDESC                  IN     NUMBER
                                            , PSDF_VLESPEC                    IN     NUMBER
                                            , PSDF_VLSERNTRIB                 IN     NUMBER
                                            , PSDF_VLTERCEIROS                IN     NUMBER
                                            , PSDF_VLSEGUROS                  IN     NUMBER
                                            , PSDF_DESPESASAC                 IN     NUMBER
                                            , PSDF_ABATNTRIB                  IN     NUMBER
                                            , PSDF_INDTPFRETE                 IN     CHAR
                                            , PSDF_VLFRETE                    IN     NUMBER
                                            , PSDF_CONTABINF                  IN     NUMBER
                                            , PSDF_IMPOSTOINF                 IN     NUMBER
                                            , PSDF_VLBIICMS                   IN     NUMBER
                                            , PSDF_VLBOICMS                   IN     NUMBER
                                            , PSDF_VLBIIPI                    IN     NUMBER
                                            , PSDF_VLBOIPI                    IN     NUMBER
                                            , PSDF_ISAJUSTE                   IN     NUMBER
                                            , PSDF_CODUTILIZACAO              IN     NUMBER
                                            , PSDF_TPCTE                      IN     CHAR
                                            , PSDF_CHAVECTE                   IN     CHAR
                                            , PSDF_CHAVECTE_REF               IN     CHAR
                                            , PSDF_CDINFCOMP                  IN     CHAR
                                            , PSDF_CONTACTB                   IN     CHAR
                                            , PSDF_VBIMPORTADO                IN     NUMBER
                                            , PSDF_VLSERVNT                   IN     NUMBER
                                            , PSDF_VLBCISSQN                  IN     NUMBER
                                            , PSDF_VLISSQN                    IN     NUMBER
                                            , PSDF_VLBCIRRF                   IN     NUMBER
                                            , PSDF_VLIRRF                     IN     NUMBER
                                            , PSDF_VLBCPREV                   IN     NUMBER
                                            , PSDF_VLPREV                     IN     NUMBER
                                            , PSDF_INDEMITENTE                IN     CHAR
                                            , PSDF_INDTITULO                  IN     CHAR
                                            , PSDF_DESCTITULO                 IN     CHAR
                                            , PSDF_NUMTITULO                  IN     CHAR
                                            , PSDF_QTDPARCELAS                IN     NUMBER
                                            , PSDF_VLTOTALTITULO              IN     NUMBER
                                            , PSDF_CLIFORTRANSP               IN     CHAR
                                            , PSDF_CDCLIFORTRANSP             IN     CHAR
                                            , PSDF_VEICULOID                  IN     CHAR
                                            , PSDF_QTDVOLUME                  IN     NUMBER
                                            , PSDF_PESOBRT                    IN     NUMBER
                                            , PSDF_PESOLIQ                    IN     NUMBER
                                            , PSDF_IDUF                       IN     CHAR
                                            , PSDF_VBIMPORTADOXML             IN     NUMBER
                                            , PSDF_SEGMOEDA                   IN     CHAR
                                            , PSDF_TAXASEGMOEDA               IN     NUMBER
                                            , PSDF_UFOPER                     IN     CHAR
                                            , PSDF_OPER                       IN     CHAR
                                            , PSDF_TPLIGACAO                  IN     CHAR
                                            , PSDF_GRUPOTENSAO                IN     CHAR
                                            , PSDF_TPASSINANTE                IN     CHAR
                                            , PSDF_CDENDCLIFOR                IN     CHAR
                                            , PSDF_SYSTEM                     IN     CHAR
                                            , PSDF_ALIQIRRF                   IN     NUMBER DEFAULT NULL
                                            , PSDF_ALIQCSLL                   IN     NUMBER DEFAULT NULL
                                            , PSDF_BCCSLL                     IN     NUMBER DEFAULT NULL
                                            , PSDF_VLCSLL                     IN     NUMBER DEFAULT NULL
                                            , PSDF_ALIQINSS                   IN     NUMBER DEFAULT NULL
                                            , PSDF_VOLESPEC                   IN     CHAR DEFAULT NULL
                                            , PSDF_VIATTRANSP                 IN     CHAR DEFAULT NULL
                                            , PSDF_CDTIPOTITULO               IN     CHAR DEFAULT NULL
                                            , PSDF_TPESTOQUE                  IN     CHAR DEFAULT NULL
                                            , PSDF_VLTOTALCANC                IN     NUMBER DEFAULT NULL
                                            , PSDF_VLTOTALII                  IN     NUMBER DEFAULT NULL
                                            , PSDF_VBNAOALTERACONTABILIDADE   IN     NUMBER DEFAULT NULL
                                            , PSDF_TPINDCOMPLEMENTAR          IN     CHAR DEFAULT NULL
                                            , PSDF_VLTOTALCOMPLEMENTAR        IN     NUMBER DEFAULT NULL
                                            , PSDF_CDMUNORIGEM IN CHAR DEFAULT NULL
                                            , PSDF_CDMUNDEST IN CHAR DEFAULT NULL
                                            ) AS
BEGIN
   IF PSDF_SQDOCFIS IS NULL
   THEN
      SELECT SEQ_SDF_SQDOCFIS.NEXTVAL INTO PSDF_SQDOCFIS FROM DUAL;
   END IF;
   INSERT INTO SPEDDOCFIS_SDF(SDF_SQDOCFIS
                            , SDF_CDEMPRESA
                            , SDF_CDFILIAL
                            , SDF_TPOP
                            , SDF_MODELO
                            , SDF_SERIE
                            , SDF_SUBSERIE
                            , SDF_EMITENTE
                            , SDF_CLIFOR
                            , SDF_CDCLIFOR
                            , SDF_DOCUMENTO
                            , SDF_DATAEMISS
                            , SDF_DATAENTR
                            , SDF_DATAESCR
                            , SDF_SITDOC
                            , SDF_VLTOTAL
                            , SDF_CHAVENFE
                            , SDF_INDPAG
                            , SDF_CLASSECONS
                            , SDF_VLBCICMS
                            , SDF_VLICMS
                            , SDF_VLBCICMSST
                            , SDF_VLICMSST
                            , SDF_VLPIS
                            , SDF_VLCOFINS
                            , SDF_VLPISST
                            , SDF_VLCOFINSST
                            , SDF_VLIPI
                            , SDF_VLTOTDESC
                            , SDF_VLESPEC
                            , SDF_VLSERNTRIB
                            , SDF_VLTERCEIROS
                            , SDF_VLSEGUROS
                            , SDF_DESPESASAC
                            , SDF_ABATNTRIB
                            , SDF_INDTPFRETE
                            , SDF_VLFRETE
                            , SDF_CONTABINF
                            , SDF_IMPOSTOINF
                            , SDF_VLBIICMS
                            , SDF_VLBOICMS
                            , SDF_VLBIIPI
                            , SDF_VLBOIPI
                            , SDF_ISAJUSTE
                            , SDF_CODUTILIZACAO
                            , SDF_TPCTE
                            , SDF_CHAVECTE
                            , SDF_CHAVECTE_REF
                            , SDF_CDINFCOMP
                            , SDF_CONTACTB
                            , SDF_VBIMPORTADO
                            , SDF_VLSERVNT
                            , SDF_VLBCISSQN
                            , SDF_VLISSQN
                            , SDF_VLBCIRRF
                            , SDF_VLIRRF
                            , SDF_VLBCPREV
                            , SDF_VLPREV
                            , SDF_INDEMITENTE
                            , SDF_INDTITULO
                            , SDF_DESCTITULO
                            , SDF_NUMTITULO
                            , SDF_QTDPARCELAS
                            , SDF_VLTOTALTITULO
                            , SDF_CLIFORTRANSP
                            , SDF_CDCLIFORTRANSP
                            , SDF_VEICULOID
                            , SDF_QTDVOLUME
                            , SDF_PESOBRT
                            , SDF_PESOLIQ
                            , SDF_IDUF
                            , SDF_VBIMPORTADOXML
                            , SDF_SEGMOEDA
                            , SDF_TAXASEGMOEDA
                            , SDF_UFOPER
                            , SDF_OPER
                            , SDF_TPLIGACAO
                            , SDF_GRUPOTENSAO
                            , SDF_TPASSINANTE
                            , SDF_CDENDCLIFOR
                            , SDF_SYSTEM
                            , SDF_ALIQIRRF
                            , SDF_ALIQCSLL
                            , SDF_BCCSLL
                            , SDF_VLCSLL
                            , SDF_ALIQINSS
                            , SDF_VOLESPEC
                            , SDF_VIATTRANSP
                            , SDF_CDTIPOTITULO
                            , SDF_TPESTOQUE
                            , SDF_VLTOTALCANC
                            , SDF_VLTOTALII
                            , SDF_VBNAOALTERACONTABILIDADE
                            , SDF_USINCLUSAO
                            , SDF_DTINCLUSAO
                            , SDF_USALTERACAO
                            , SDF_DTALTERACAO
                            , SDF_TPINDCOMPLEMENTAR
                            , SDF_VLTOTALCOMPLEMENTAR
                            , SDF_CDMUNORIGEM
                            , SDF_CDMUNDEST )
   VALUES (PSDF_SQDOCFIS
         , PSDF_CDEMPRESA
         , PSDF_CDFILIAL
         , PSDF_TPOP
         , PSDF_MODELO
         , PSDF_SERIE
         , PSDF_SUBSERIE
         , PSDF_EMITENTE
         , PSDF_CLIFOR
         , PSDF_CDCLIFOR
         , PSDF_DOCUMENTO
         , PSDF_DATAEMISS
         , PSDF_DATAENTR
         , PSDF_DATAESCR
         , PSDF_SITDOC
         , PSDF_VLTOTAL
         , PSDF_CHAVENFE
         , PSDF_INDPAG
         , PSDF_CLASSECONS
         , PSDF_VLBCICMS
         , PSDF_VLICMS
         , PSDF_VLBCICMSST
         , PSDF_VLICMSST
         , PSDF_VLPIS
         , PSDF_VLCOFINS
         , PSDF_VLPISST
         , PSDF_VLCOFINSST
         , PSDF_VLIPI
         , PSDF_VLTOTDESC
         , PSDF_VLESPEC
         , PSDF_VLSERNTRIB
         , PSDF_VLTERCEIROS
         , PSDF_VLSEGUROS
         , PSDF_DESPESASAC
         , PSDF_ABATNTRIB
         , PSDF_INDTPFRETE
         , PSDF_VLFRETE
         , PSDF_CONTABINF
         , PSDF_IMPOSTOINF
         , PSDF_VLBIICMS
         , PSDF_VLBOICMS
         , PSDF_VLBIIPI
         , PSDF_VLBOIPI
         , PSDF_ISAJUSTE
         , PSDF_CODUTILIZACAO
         , PSDF_TPCTE
         , PSDF_CHAVECTE
         , PSDF_CHAVECTE_REF
         , PSDF_CDINFCOMP
         , PSDF_CONTACTB
         , PSDF_VBIMPORTADO
         , PSDF_VLSERVNT
         , PSDF_VLBCISSQN
         , PSDF_VLISSQN
         , PSDF_VLBCIRRF
         , PSDF_VLIRRF
         , PSDF_VLBCPREV
         , PSDF_VLPREV
         , PSDF_INDEMITENTE
         , PSDF_INDTITULO
         , PSDF_DESCTITULO
         , PSDF_NUMTITULO
         , PSDF_QTDPARCELAS
         , PSDF_VLTOTALTITULO
         , PSDF_CLIFORTRANSP
         , PSDF_CDCLIFORTRANSP
         , PSDF_VEICULOID
         , PSDF_QTDVOLUME
         , PSDF_PESOBRT
         , PSDF_PESOLIQ
         , PSDF_IDUF
         , PSDF_VBIMPORTADOXML
         , PSDF_SEGMOEDA
         , PSDF_TAXASEGMOEDA
         , PSDF_UFOPER
         , PSDF_OPER
         , PSDF_TPLIGACAO
         , PSDF_GRUPOTENSAO
         , PSDF_TPASSINANTE
         , PSDF_CDENDCLIFOR
         , PSDF_SYSTEM
         , PSDF_ALIQIRRF
         , PSDF_ALIQCSLL
         , PSDF_BCCSLL
         , PSDF_VLCSLL
         , PSDF_ALIQINSS
         , PSDF_VOLESPEC
         , PSDF_VIATTRANSP
         , PSDF_CDTIPOTITULO
         , PSDF_TPESTOQUE
         , PSDF_VLTOTALCANC
         , PSDF_VLTOTALII
         , PSDF_VBNAOALTERACONTABILIDADE
         , GET_USER_MXM
         , SYSDATE
         , NULL
         , NULL
         , PSDF_TPINDCOMPLEMENTAR
         , PSDF_VLTOTALCOMPLEMENTAR
         , PSDF_CDMUNORIGEM
         , PSDF_CDMUNDEST);
END;
/

CREATE OR REPLACE PROCEDURE ALTSPEDDOCFIS_SDF (PSDF_SQDOCFIS                   IN OUT NUMBER
                                            , PSDF_CDEMPRESA                  IN     CHAR
                                            , PSDF_CDFILIAL                   IN     CHAR
                                            , PSDF_TPOP                       IN     CHAR
                                            , PSDF_MODELO                     IN     CHAR
                                            , PSDF_SERIE                      IN     CHAR
                                            , PSDF_SUBSERIE                   IN     CHAR
                                            , PSDF_EMITENTE                   IN     CHAR
                                            , PSDF_CLIFOR                     IN     CHAR
                                            , PSDF_CDCLIFOR                   IN     CHAR
                                            , PSDF_DOCUMENTO                  IN     CHAR
                                            , PSDF_DATAEMISS                  IN     DATE
                                            , PSDF_DATAENTR                   IN     DATE
                                            , PSDF_DATAESCR                   IN     DATE
                                            , PSDF_SITDOC                     IN     CHAR
                                            , PSDF_VLTOTAL                    IN     NUMBER
                                            , PSDF_CHAVENFE                   IN     CHAR
                                            , PSDF_INDPAG                     IN     CHAR
                                            , PSDF_CLASSECONS                 IN     CHAR
                                            , PSDF_VLBCICMS                   IN     NUMBER
                                            , PSDF_VLICMS                     IN     NUMBER
                                            , PSDF_VLBCICMSST                 IN     NUMBER
                                            , PSDF_VLICMSST                   IN     NUMBER
                                            , PSDF_VLPIS                      IN     NUMBER
                                            , PSDF_VLCOFINS                   IN     NUMBER
                                            , PSDF_VLPISST                    IN     NUMBER
                                            , PSDF_VLCOFINSST                 IN     NUMBER
                                            , PSDF_VLIPI                      IN     NUMBER
                                            , PSDF_VLTOTDESC                  IN     NUMBER
                                            , PSDF_VLESPEC                    IN     NUMBER
                                            , PSDF_VLSERNTRIB                 IN     NUMBER
                                            , PSDF_VLTERCEIROS                IN     NUMBER
                                            , PSDF_VLSEGUROS                  IN     NUMBER
                                            , PSDF_DESPESASAC                 IN     NUMBER
                                            , PSDF_ABATNTRIB                  IN     NUMBER
                                            , PSDF_INDTPFRETE                 IN     CHAR
                                            , PSDF_VLFRETE                    IN     NUMBER
                                            , PSDF_CONTABINF                  IN     NUMBER
                                            , PSDF_IMPOSTOINF                 IN     NUMBER
                                            , PSDF_VLBIICMS                   IN     NUMBER
                                            , PSDF_VLBOICMS                   IN     NUMBER
                                            , PSDF_VLBIIPI                    IN     NUMBER
                                            , PSDF_VLBOIPI                    IN     NUMBER
                                            , PSDF_ISAJUSTE                   IN     NUMBER
                                            , PSDF_CODUTILIZACAO              IN     NUMBER
                                            , PSDF_TPCTE                      IN     CHAR
                                            , PSDF_CHAVECTE                   IN     CHAR
                                            , PSDF_CHAVECTE_REF               IN     CHAR
                                            , PSDF_CDINFCOMP                  IN     CHAR
                                            , PSDF_CONTACTB                   IN     CHAR
                                            , PSDF_VBIMPORTADO                IN     NUMBER
                                            , PSDF_VLSERVNT                   IN     NUMBER
                                            , PSDF_VLBCISSQN                  IN     NUMBER
                                            , PSDF_VLISSQN                    IN     NUMBER
                                            , PSDF_VLBCIRRF                   IN     NUMBER
                                            , PSDF_VLIRRF                     IN     NUMBER
                                            , PSDF_VLBCPREV                   IN     NUMBER
                                            , PSDF_VLPREV                     IN     NUMBER
                                            , PSDF_INDEMITENTE                IN     CHAR
                                            , PSDF_INDTITULO                  IN     CHAR
                                            , PSDF_DESCTITULO                 IN     CHAR
                                            , PSDF_NUMTITULO                  IN     CHAR
                                            , PSDF_QTDPARCELAS                IN     NUMBER
                                            , PSDF_VLTOTALTITULO              IN     NUMBER
                                            , PSDF_CLIFORTRANSP               IN     CHAR
                                            , PSDF_CDCLIFORTRANSP             IN     CHAR
                                            , PSDF_VEICULOID                  IN     CHAR
                                            , PSDF_QTDVOLUME                  IN     NUMBER
                                            , PSDF_PESOBRT                    IN     NUMBER
                                            , PSDF_PESOLIQ                    IN     NUMBER
                                            , PSDF_IDUF                       IN     CHAR
                                            , PSDF_VBIMPORTADOXML             IN     NUMBER
                                            , PSDF_SEGMOEDA                   IN     CHAR
                                            , PSDF_TAXASEGMOEDA               IN     NUMBER
                                            , PSDF_UFOPER                     IN     CHAR
                                            , PSDF_OPER                       IN     CHAR
                                            , PSDF_TPLIGACAO                  IN     CHAR
                                            , PSDF_GRUPOTENSAO                IN     CHAR
                                            , PSDF_TPASSINANTE                IN     CHAR
                                            , PSDF_CDENDCLIFOR                IN     CHAR
                                            , PSDF_SYSTEM                     IN     CHAR
                                            , PSDF_ALIQIRRF                   IN     NUMBER DEFAULT NULL
                                            , PSDF_ALIQCSLL                   IN     NUMBER DEFAULT NULL
                                            , PSDF_BCCSLL                     IN     NUMBER DEFAULT NULL
                                            , PSDF_VLCSLL                     IN     NUMBER DEFAULT NULL
                                            , PSDF_ALIQINSS                   IN     NUMBER DEFAULT NULL
                                            , PSDF_VOLESPEC                   IN     CHAR DEFAULT NULL
                                            , PSDF_VIATTRANSP                 IN     CHAR DEFAULT NULL
                                            , PSDF_CDTIPOTITULO               IN     CHAR DEFAULT NULL
                                            , PSDF_TPESTOQUE                  IN     CHAR DEFAULT NULL
                                            , PSDF_VLTOTALCANC                IN     NUMBER DEFAULT NULL
                                            , PSDF_VLTOTALII                  IN     NUMBER DEFAULT NULL
                                            , PSDF_VBNAOALTERACONTABILIDADE   IN     NUMBER DEFAULT NULL
                                            , PSDF_TPINDCOMPLEMENTAR          IN     CHAR DEFAULT NULL
                                            , PSDF_VLTOTALCOMPLEMENTAR        IN     NUMBER DEFAULT NULL
                                            , PSDF_CDMUNORIGEM IN CHAR DEFAULT NULL
                                            , PSDF_CDMUNDEST IN CHAR DEFAULT NULL) AS
BEGIN
   UPDATE SPEDDOCFIS_SDF
      SET SDF_CDEMPRESA                  = PSDF_CDEMPRESA
        , SDF_CDFILIAL                   = PSDF_CDFILIAL
        , SDF_TPOP                       = PSDF_TPOP
        , SDF_MODELO                     = PSDF_MODELO
        , SDF_SERIE                      = PSDF_SERIE
        , SDF_SUBSERIE                   = PSDF_SUBSERIE
        , SDF_EMITENTE                   = PSDF_EMITENTE
        , SDF_CLIFOR                     = PSDF_CLIFOR
        , SDF_CDCLIFOR                   = PSDF_CDCLIFOR
        , SDF_DOCUMENTO                  = PSDF_DOCUMENTO
        , SDF_DATAEMISS                  = PSDF_DATAEMISS
        , SDF_DATAENTR                   = PSDF_DATAENTR
        , SDF_DATAESCR                   = PSDF_DATAESCR
        , SDF_SITDOC                     = PSDF_SITDOC
        , SDF_VLTOTAL                    = PSDF_VLTOTAL
        , SDF_CHAVENFE                   = PSDF_CHAVENFE
        , SDF_INDPAG                     = PSDF_INDPAG
        , SDF_CLASSECONS                 = PSDF_CLASSECONS
        , SDF_VLBCICMS                   = PSDF_VLBCICMS
        , SDF_VLICMS                     = PSDF_VLICMS
        , SDF_VLBCICMSST                 = PSDF_VLBCICMSST
        , SDF_VLICMSST                   = PSDF_VLICMSST
        , SDF_VLPIS                      = PSDF_VLPIS
        , SDF_VLCOFINS                   = PSDF_VLCOFINS
        , SDF_VLPISST                    = PSDF_VLPISST
        , SDF_VLCOFINSST                 = PSDF_VLCOFINSST
        , SDF_VLIPI                      = PSDF_VLIPI
        , SDF_VLTOTDESC                  = PSDF_VLTOTDESC
        , SDF_VLESPEC                    = PSDF_VLESPEC
        , SDF_VLSERNTRIB                 = PSDF_VLSERNTRIB
        , SDF_VLTERCEIROS                = PSDF_VLTERCEIROS
        , SDF_VLSEGUROS                  = PSDF_VLSEGUROS
        , SDF_DESPESASAC                 = PSDF_DESPESASAC
        , SDF_ABATNTRIB                  = PSDF_ABATNTRIB
        , SDF_INDTPFRETE                 = PSDF_INDTPFRETE
        , SDF_VLFRETE                    = PSDF_VLFRETE
        , SDF_CONTABINF                  = PSDF_CONTABINF
        , SDF_IMPOSTOINF                 = PSDF_IMPOSTOINF
        , SDF_VLBIICMS                   = PSDF_VLBIICMS
        , SDF_VLBOICMS                   = PSDF_VLBOICMS
        , SDF_VLBIIPI                    = PSDF_VLBIIPI
        , SDF_VLBOIPI                    = PSDF_VLBOIPI
        , SDF_ISAJUSTE                   = PSDF_ISAJUSTE
        , SDF_CODUTILIZACAO              = PSDF_CODUTILIZACAO
        , SDF_TPCTE                      = PSDF_TPCTE
        , SDF_CHAVECTE                   = PSDF_CHAVECTE
        , SDF_CHAVECTE_REF               = PSDF_CHAVECTE_REF
        , SDF_CDINFCOMP                  = PSDF_CDINFCOMP
        , SDF_CONTACTB                   = PSDF_CONTACTB
        , SDF_VBIMPORTADO                = PSDF_VBIMPORTADO
        , SDF_VLSERVNT                   = PSDF_VLSERVNT
        , SDF_VLBCISSQN                  = PSDF_VLBCISSQN
        , SDF_VLISSQN                    = PSDF_VLISSQN
        , SDF_VLBCIRRF                   = PSDF_VLBCIRRF
        , SDF_VLIRRF                     = PSDF_VLIRRF
        , SDF_VLBCPREV                   = PSDF_VLBCPREV
        , SDF_VLPREV                     = PSDF_VLPREV
        , SDF_INDEMITENTE                = PSDF_INDEMITENTE
        , SDF_INDTITULO                  = PSDF_INDTITULO
        , SDF_DESCTITULO                 = PSDF_DESCTITULO
        , SDF_NUMTITULO                  = PSDF_NUMTITULO
        , SDF_QTDPARCELAS                = PSDF_QTDPARCELAS
        , SDF_VLTOTALTITULO              = PSDF_VLTOTALTITULO
        , SDF_CLIFORTRANSP               = PSDF_CLIFORTRANSP
        , SDF_CDCLIFORTRANSP             = PSDF_CDCLIFORTRANSP
        , SDF_VEICULOID                  = PSDF_VEICULOID
        , SDF_QTDVOLUME                  = PSDF_QTDVOLUME
        , SDF_PESOBRT                    = PSDF_PESOBRT
        , SDF_PESOLIQ                    = PSDF_PESOLIQ
        , SDF_IDUF                       = PSDF_IDUF
        , SDF_VBIMPORTADOXML             = PSDF_VBIMPORTADOXML
        , SDF_SEGMOEDA                   = PSDF_SEGMOEDA
        , SDF_TAXASEGMOEDA               = PSDF_TAXASEGMOEDA
        , SDF_UFOPER                     = PSDF_UFOPER
        , SDF_OPER                       = PSDF_OPER
        , SDF_TPLIGACAO                  = PSDF_TPLIGACAO
        , SDF_GRUPOTENSAO                = PSDF_GRUPOTENSAO
        , SDF_TPASSINANTE                = PSDF_TPASSINANTE
        , SDF_CDENDCLIFOR                = PSDF_CDENDCLIFOR
        , SDF_SYSTEM                     = PSDF_SYSTEM
        , SDF_ALIQIRRF                   = PSDF_ALIQIRRF
        , SDF_ALIQCSLL                   = PSDF_ALIQCSLL
        , SDF_BCCSLL                     = PSDF_BCCSLL
        , SDF_VLCSLL                     = PSDF_VLCSLL
        , SDF_ALIQINSS                   = PSDF_ALIQINSS
        , SDF_VOLESPEC                   = PSDF_VOLESPEC
        , SDF_VIATTRANSP                 = PSDF_VIATTRANSP
        , SDF_CDTIPOTITULO               = PSDF_CDTIPOTITULO
        , SDF_TPESTOQUE                  = PSDF_TPESTOQUE
        , SDF_VLTOTALCANC                = PSDF_VLTOTALCANC
        , SDF_VLTOTALII                  = PSDF_VLTOTALII
        , SDF_VBNAOALTERACONTABILIDADE   = PSDF_VBNAOALTERACONTABILIDADE
        , SDF_USALTERACAO                = GET_USER_MXM
        , SDF_DTALTERACAO                = SYSDATE
        , SDF_TPINDCOMPLEMENTAR          = PSDF_TPINDCOMPLEMENTAR
        , SDF_VLTOTALCOMPLEMENTAR        = PSDF_VLTOTALCOMPLEMENTAR
        , SDF_CDMUNORIGEM =  PSDF_CDMUNORIGEM
        , SDF_CDMUNDEST = PSDF_CDMUNDEST
    WHERE SDF_SQDOCFIS = PSDF_SQDOCFIS;
END;
/

ALTER TABLE SPEDEFDSERVTRANSPV10_RD100 ADD RD100_CDMUNORIG VARCHAR2(7) DEFAULT NULL
/

ALTER TABLE SPEDEFDSERVTRANSPV10_RD100 ADD RD100_CDMUNDEST VARCHAR2(7) DEFAULT NULL
/

CREATE OR REPLACE PROCEDURE INSSPEDEFDSERVTRANSPV10_RD100
(PIDREGD100 IN OUT NUMBER,
 PSMECODIGO IN CHAR,
 PREG IN CHAR,
 PIND_OPER IN CHAR,
 PIND_EMIT IN CHAR,
 PCOD_PART IN CHAR,
 PCOD_MOD IN CHAR,
 PCOD_SIT IN CHAR,
 PSER IN CHAR,
 PSUB IN CHAR,
 PNUM_DOC IN CHAR,
 PDT_DOC IN CHAR,
 PDT_A_P IN CHAR,
 PVL_DOC IN CHAR,
 PVL_DESC IN CHAR,
 PIND_FRT IN CHAR,
 PVL_SERV IN CHAR,
 PVL_BC_ICMS IN CHAR,
 PVL_ICMS IN CHAR,
 PVL_NT IN CHAR,
 PCOD_INF IN CHAR,
 PVL_PIS IN CHAR,
 PVL_COFINS IN CHAR,
 PCOD_CTA IN CHAR,
 PTP_CTE  IN CHAR,
 PCHAVE_CTE IN CHAR,
 PCHAVE_CTE_REF IN CHAR,
 PRD100_CDCLIFOR IN CHAR,
 PRD100_CLIFOR IN CHAR,
 PRD100_CDENDCLIFOR IN CHAR,
 PRD100_CDMUNORIG IN CHAR DEFAULT NULL,
 PRD100_CDMUNDEST IN CHAR DEFAULT NULL
)
AS
BEGIN
IF PIDREGD100 IS NULL THEN
 SELECT SEQ_IDREGD100.NEXTVAL INTO PIDREGD100 FROM DUAL;
END IF;
  INSERT INTO SPEDEFDSERVTRANSPV10_RD100(
      IDREGD100,
      SMECODIGO,
      REG,
      IND_OPER,
      IND_EMIT,
      COD_PART,
      COD_MOD,
      COD_SIT,
      SER,
      SUB,
      NUM_DOC,
      DT_DOC,
      DT_A_P,
      VL_DOC,
      VL_DESC,
      IND_FRT,
      VL_SERV,
      VL_BC_ICMS,
      VL_ICMS,
      VL_NT,
      COD_INF,
      VL_PIS,
      VL_COFINS,
      COD_CTA,
      TP_CTE,
      CHAVE_CTE,
      CHAVE_CTE_REF,
      RD100_CDCLIFOR,
      RD100_CLIFOR,
      RD100_CDENDCLIFOR,
      RD100_CDMUNORIG,
      RD100_CDMUNDEST
) VALUES (
      PIDREGD100,
      PSMECODIGO,
      PREG,
      PIND_OPER,
      PIND_EMIT,
      PCOD_PART,
      PCOD_MOD,
      PCOD_SIT,
      PSER,
      PSUB,
      PNUM_DOC,
      PDT_DOC,
      PDT_A_P,
      PVL_DOC,
      PVL_DESC,
      PIND_FRT,
      PVL_SERV,
      PVL_BC_ICMS,
      PVL_ICMS,
      PVL_NT,
      PCOD_INF,
      PVL_PIS,
      PVL_COFINS,
      PCOD_CTA,
      PTP_CTE,
      PCHAVE_CTE,
      PCHAVE_CTE_REF,
      PRD100_CDCLIFOR,
      PRD100_CLIFOR,
      PRD100_CDENDCLIFOR,
      PRD100_CDMUNORIG,
      PRD100_CDMUNDEST
);
END;
/

CREATE OR REPLACE PROCEDURE ALTSPEDEFDSERVTRANSPV10_RD100
(PIDREGD100 IN OUT NUMBER,
 PSMECODIGO IN CHAR,
 PREG IN CHAR,
 PIND_OPER IN CHAR,
 PIND_EMIT IN CHAR,
 PCOD_PART IN CHAR,
 PCOD_MOD IN CHAR,
 PCOD_SIT IN CHAR,
 PSER IN CHAR,
 PSUB IN CHAR,
 PNUM_DOC IN CHAR,
 PDT_DOC IN CHAR,
 PDT_A_P IN CHAR,
 PVL_DOC IN CHAR,
 PVL_DESC IN CHAR,
 PIND_FRT IN CHAR,
 PVL_SERV IN CHAR,
 PVL_BC_ICMS IN CHAR,
 PVL_ICMS IN CHAR,
 PVL_NT IN CHAR,
 PCOD_INF IN CHAR,
 PVL_PIS IN CHAR,
 PVL_COFINS IN CHAR,
 PCOD_CTA IN CHAR,
 PTP_CTE  IN CHAR,
 PCHAVE_CTE IN CHAR,
 PCHAVE_CTE_REF IN CHAR,
 PRD100_CDMUNORIG IN CHAR,
 PRD100_CDMUNDEST IN CHAR
)
AS
BEGIN
  UPDATE SPEDEFDSERVTRANSPV10_RD100
   SET SMECODIGO = PSMECODIGO,
       REG = PREG,
       IND_OPER = PIND_OPER,
       IND_EMIT = PIND_EMIT,
       COD_PART = PCOD_PART,
       COD_MOD = PCOD_MOD,
       COD_SIT = PCOD_SIT,
       SER = PSER,
       SUB = PSUB,
       NUM_DOC = PNUM_DOC,
       DT_DOC = PDT_DOC,
       DT_A_P = PDT_A_P,
       VL_DOC = PVL_DOC,
       VL_DESC = PVL_DESC,
       IND_FRT = PIND_FRT,
       VL_SERV = PVL_SERV,
       VL_BC_ICMS = PVL_BC_ICMS,
       VL_ICMS = PVL_ICMS,
       VL_NT = PVL_NT,
       COD_INF = PCOD_INF,
       VL_PIS = PVL_PIS,
       VL_COFINS = PVL_COFINS,
       COD_CTA = PCOD_CTA,
       TP_CTE  = PTP_CTE,
       CHAVE_CTE = PCHAVE_CTE,
       CHAVE_CTE_REF = PCHAVE_CTE_REF,
       RD100_CDMUNORIG  =  PRD100_CDMUNORIG ,
       RD100_CDMUNDEST =  PRD100_CDMUNDEST
   WHERE IDREGD100 = PIDREGD100;
END;
/

CREATE TABLE EFDAJUSTEIPIDOC_DAI
(
  DAI_IDAJUSTEIPIDOC NUMBER(6) NOT NULL,
  DAI_NRAJUAPIPI      NUMBER(6) NOT NULL,
  DAI_NRDOCFIS       NUMBER(9),
  DAI_TPCLIFOR       VARCHAR2(1),
  DAI_CDCLIFOR       VARCHAR2(15),
  DAI_CDMODDOC       VARCHAR2(2) NOT NULL,
  DAI_NRSERIE        VARCHAR2(3),
  DAI_NRSUBSERIE     NUMBER(3),
  DAI_NRDOCUMENTO    VARCHAR2(9) NOT NULL,
  DAI_CDITEM         VARCHAR2(15),
  DAI_DTDATA         DATE NOT NULL,
  DAI_NRCHAVENFE     VARCHAR2(44),
  DAI_VLAJUSTE       NUMBER(15,2) NOT NULL,
  DAI_DTINCLUSAO     DATE NOT NULL,
  DAI_DTALTERACAO    DATE,
  DAI_USINCLUSAO     VARCHAR2(30) NOT NULL,
  DAI_USALTERACAO    VARCHAR2(30)
)
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_IDAJUSTEIPIDOC IS 'Identificador  do Documento Refericial ao Ajuste'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_NRAJUAPIPI IS 'Identificador da Apura��o de IPI'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_NRDOCFIS IS 'Identificador do Documento Fiscal'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_TPCLIFOR IS 'Identificador de Cliente/Fornecedor'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_CDCLIFOR IS 'N�mero do Codigo do Cliente/Fornecedor'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_CDMODDOC IS 'N�mero do Modelo'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_NRSERIE IS 'N�mero de S�rie'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_NRSUBSERIE IS 'N�mero de SubS�rie'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_NRDOCUMENTO IS 'N�mero do Documento'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_CDITEM IS 'N�mero do C�digo do Item'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_DTDATA IS 'Data'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_NRCHAVENFE IS 'Chave NFE'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_VLAJUSTE IS 'Valor do Ajuste'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_DTINCLUSAO IS 'Indica��o do dia, m�s e ano em que a informa��o foi criada na base de dados'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_DTALTERACAO IS 'Indica��o do dia, m�s e ano em que a informa��o foi alterada na base de dados'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_USINCLUSAO IS 'O respons�vel por realizar a cria��o das informa��es na base de dados'
/

COMMENT ON COLUMN EFDAJUSTEIPIDOC_DAI.DAI_USALTERACAO IS 'O respons�vel por realizar a altera��o das informa��es na base de dados'
/

ALTER TABLE EFDAJUSTEIPIDOC_DAI ADD CONSTRAINT PK_EFDAJUSTEIPIDOC_DAI PRIMARY KEY  (DAI_IDAJUSTEIPIDOC)
/

ALTER TABLE EFDAJUSTEIPIDOC_DAI ADD CONSTRAINT FK1_EFDAJUSTEIPIDOC_DAI FOREIGN KEY (DAI_NRAJUAPIPI) REFERENCES SPEDAJUAPIPI_SAAI (SAAI_SQAJUAPIPI)
/

ALTER TABLE EFDAJUSTEIPIDOC_DAI ADD CONSTRAINT FK2_EFDAJUSTEIPIDOC_DAI FOREIGN KEY (DAI_CDITEM) REFERENCES PRODUTO_PRD (PRD_ITEM)
/

ALTER TABLE EFDAJUSTEIPIDOC_DAI ADD CONSTRAINT FK3_EFDAJUSTEIPIDOC_DAI FOREIGN KEY (DAI_NRDOCFIS) REFERENCES SPEDDOCFIS_SDF (SDF_SQDOCFIS)
/

CREATE SEQUENCE SEQ1_EFDAJUSTEIPIDOC_DAI
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

CREATE OR REPLACE PROCEDURE PRC_INSEFDAJUSTEIPIDOC_DAI(
 PDAI_IDAJUSTEIPIDOC IN OUT NUMBER
,PDAI_NRAJUAPIPI IN NUMBER
,PDAI_NRDOCFIS IN NUMBER DEFAULT NULL
,PDAI_TPCLIFOR IN CHAR DEFAULT NULL
,PDAI_CDCLIFOR IN CHAR DEFAULT NULL
,PDAI_CDMODDOC IN CHAR
,PDAI_NRSERIE IN CHAR DEFAULT NULL
,PDAI_NRSUBSERIE IN NUMBER DEFAULT NULL
,PDAI_NRDOCUMENTO IN CHAR
,PDAI_CDITEM IN CHAR DEFAULT NULL
,PDAI_DTDATA IN DATE
,PDAI_NRCHAVENFE IN CHAR DEFAULT NULL
,PDAI_VLAJUSTE IN NUMBER
)
AS
BEGIN
  IF PDAI_IDAJUSTEIPIDOC IS NULL THEN
   SELECT SEQ1_EFDAJUSTEIPIDOC_DAI.NEXTVAL INTO PDAI_IDAJUSTEIPIDOC FROM DUAL;
  END IF;
  INSERT INTO EFDAJUSTEIPIDOC_DAI(
    DAI_IDAJUSTEIPIDOC
   ,DAI_NRAJUAPIPI
   ,DAI_NRDOCFIS
   ,DAI_TPCLIFOR
   ,DAI_CDCLIFOR
   ,DAI_CDMODDOC
   ,DAI_NRSERIE
   ,DAI_NRSUBSERIE
   ,DAI_NRDOCUMENTO
   ,DAI_CDITEM
   ,DAI_DTDATA
   ,DAI_NRCHAVENFE
   ,DAI_VLAJUSTE
   ,DAI_DTINCLUSAO
   ,DAI_USINCLUSAO
) VALUES (
    PDAI_IDAJUSTEIPIDOC
   ,PDAI_NRAJUAPIPI
   ,PDAI_NRDOCFIS
   ,PDAI_TPCLIFOR
   ,PDAI_CDCLIFOR
   ,PDAI_CDMODDOC
   ,PDAI_NRSERIE
   ,PDAI_NRSUBSERIE
   ,PDAI_NRDOCUMENTO
   ,PDAI_CDITEM
   ,PDAI_DTDATA
   ,PDAI_NRCHAVENFE
   ,PDAI_VLAJUSTE
   ,SYSDATE
   ,GET_USER_MXM
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTEFDAJUSTEIPIDOC_DAI(
 PDAI_IDAJUSTEIPIDOC IN NUMBER
,PDAI_NRAJUAPIPI IN NUMBER
,PDAI_NRDOCFIS IN NUMBER DEFAULT NULL
,PDAI_TPCLIFOR IN CHAR DEFAULT NULL
,PDAI_CDCLIFOR IN CHAR DEFAULT NULL
,PDAI_CDMODDOC IN CHAR
,PDAI_NRSERIE IN CHAR DEFAULT NULL
,PDAI_NRSUBSERIE IN NUMBER DEFAULT NULL
,PDAI_NRDOCUMENTO IN CHAR
,PDAI_CDITEM IN CHAR DEFAULT NULL
,PDAI_DTDATA IN DATE
,PDAI_NRCHAVENFE IN CHAR DEFAULT NULL
,PDAI_VLAJUSTE IN NUMBER
)
AS
BEGIN
  UPDATE EFDAJUSTEIPIDOC_DAI
     SET DAI_IDAJUSTEIPIDOC = PDAI_IDAJUSTEIPIDOC
        ,DAI_NRAJUAPIPI = PDAI_NRAJUAPIPI
        ,DAI_NRDOCFIS = PDAI_NRDOCFIS
        ,DAI_TPCLIFOR = PDAI_TPCLIFOR
        ,DAI_CDCLIFOR = PDAI_CDCLIFOR
        ,DAI_CDMODDOC = PDAI_CDMODDOC
        ,DAI_NRSERIE = PDAI_NRSERIE
        ,DAI_NRSUBSERIE = PDAI_NRSUBSERIE
        ,DAI_NRDOCUMENTO = PDAI_NRDOCUMENTO
        ,DAI_CDITEM = PDAI_CDITEM
        ,DAI_DTDATA = PDAI_DTDATA
        ,DAI_NRCHAVENFE = PDAI_NRCHAVENFE
        ,DAI_VLAJUSTE = PDAI_VLAJUSTE
        ,DAI_DTALTERACAO = SYSDATE
        ,DAI_USALTERACAO = GET_USER_MXM
   WHERE DAI_IDAJUSTEIPIDOC = PDAI_IDAJUSTEIPIDOC;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCEFDAJUSTEIPIDOC_DAI(
 PDAI_IDAJUSTEIPIDOC IN NUMBER
)
AS
BEGIN
  DELETE FROM EFDAJUSTEIPIDOC_DAI
   WHERE DAI_IDAJUSTEIPIDOC = PDAI_IDAJUSTEIPIDOC;
END;
/

CREATE TABLE EFDREGISTROE531_E31
(
  E31_IDREGE531 NUMBER(20) NOT NULL,
  IDREGE530     NUMBER(20) NOT NULL,
  SMECODIGO     VARCHAR2(15) NOT NULL,
  E31_CDREG     VARCHAR2(4) NOT NULL,
  E31_CDPART    VARCHAR2(60),
  E31_CDMOD     VARCHAR2(2),
  E31_NRSER     VARCHAR2(4),
  E31_NRSUBSER  VARCHAR2(3),
  E31_NRDOC     VARCHAR2(9),
  E31_DTDOC     VARCHAR2(8),
  E31_CDITEM    VARCHAR2(60),
  E31_VLAJUITEM VARCHAR2(20),
  E31_NRCHVNFE  VARCHAR2(44),
  E31_TPCLIFOR  VARCHAR2(1),
  E31_CDCLIFOR  VARCHAR2(60)
)
/

COMMENT ON TABLE EFDREGISTROE531_E31
  IS 'EFD - Tabela de processamento Registro E531 - Informa��es adicionais dos ajustes da apura��o do IPI - Identifica��o dos documentos fiscais (01 e 55).'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_IDREGE531
  IS 'Identificador do registro E531'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.IDREGE530
  IS 'Identificador do registro E530'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.SMECODIGO
  IS 'C�digo do modelo de escritura��o'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_CDREG
  IS 'Texto fixo contendo E531'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_CDPART
  IS 'C�digo do participante (campo 02 do Registro 0150): - do emitente do documento ou do remetente das mercadorias, no caso de entradas; - do adquirente, no caso de sa�das'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_CDMOD
  IS 'C�digo do modelo do documento fiscal'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_NRSER
  IS 'S�rie do documento fiscal'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_NRSUBSER
  IS 'Subs�rie do documento fiscal'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_NRDOC
  IS 'N�mero do documento fiscal'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_DTDOC
  IS 'Data da emiss�o do documento fiscal'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_CDITEM
  IS 'C�digo do item (campo 02 do Registro 0200)'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_VLAJUITEM
  IS 'Valor do ajuste para a opera��o/item'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_NRCHVNFE
  IS 'Chave da Nota Fiscal Eletr�nica (modelo 55)'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_TPCLIFOR
  IS 'C�digo do participante (campo 02 do Registro 0150): - do emitente do documento ou do remetente das mercadorias, no caso de entradas; - do adquirente, no caso de sa�das'
/

COMMENT ON COLUMN EFDREGISTROE531_E31.E31_CDCLIFOR
  IS 'C�digo do participante (campo 02 do Registro 0150): - do emitente do documento ou do remetente das mercadorias, no caso de entradas; - do adquirente, no caso de sa�das'
/

ALTER TABLE EFDREGISTROE531_E31
  ADD CONSTRAINT PK_EFDREGISTROE531_E31 PRIMARY KEY (E31_IDREGE531)
/

ALTER TABLE EFDREGISTROE531_E31 ADD (
  CONSTRAINT FK_EFDREGISTROE531_E31
 FOREIGN KEY (IDREGE530)
 REFERENCES SPEDEFDAJAPURAIPIV10_RE530 (IDREGE530))
/

CREATE SEQUENCE SEQ1_EFDREGISTROE531_E31
  START WITH 1
  INCREMENT BY 1
  MAXVALUE 999999999999
/

CREATE OR REPLACE PROCEDURE PRC_INSEFDREGISTROE531_E31 (
   PE31_IDREGE531 IN OUT   NUMBER,
   PIDREGE530     IN       NUMBER,
   PSMECODIGO     IN       CHAR,
   PE31_CDREG     IN       CHAR,
   PE31_CDPART    IN       CHAR,
   PE31_CDMOD     IN       CHAR,
   PE31_NRSER     IN       CHAR,
   PE31_NRSUBSER  IN       CHAR,
   PE31_NRDOC     IN       CHAR,
   PE31_DTDOC     IN       CHAR,
   PE31_CDITEM    IN       CHAR,
   PE31_VLAJUITEM IN       CHAR,
   PE31_NRCHVNFE  IN       CHAR,
   PE31_TPCLIFOR  IN       CHAR,
   PE31_CDCLIFOR  IN       CHAR
)
AS
BEGIN
   IF PE31_IDREGE531 IS NULL
   THEN
      SELECT SEQ1_EFDREGISTROE531_E31.NEXTVAL
        INTO PE31_IDREGE531
        FROM DUAL;
   END IF;
   INSERT INTO EFDREGISTROE531_E31
               (E31_IDREGE531, IDREGE530, SMECODIGO, E31_CDREG, E31_CDPART, E31_CDMOD, E31_NRSER, E31_NRSUBSER, E31_NRDOC,
                E31_DTDOC, E31_CDITEM, E31_VLAJUITEM, E31_NRCHVNFE, E31_TPCLIFOR, E31_CDCLIFOR
               )
        VALUES (PE31_IDREGE531, PIDREGE530, PSMECODIGO, PE31_CDREG, PE31_CDPART, PE31_CDMOD, PE31_NRSER, PE31_NRSUBSER, PE31_NRDOC,
                PE31_DTDOC, PE31_CDITEM, PE31_VLAJUITEM, PE31_NRCHVNFE, PE31_TPCLIFOR, PE31_CDCLIFOR
               );
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTEFDREGISTROE531_E31 (
   PE31_IDREGE531 IN OUT   NUMBER,
   PIDREGE530      IN       NUMBER,
   PSMECODIGO     IN       CHAR,
   PE31_CDREG     IN       CHAR,
   PE31_CDPART    IN       CHAR,
   PE31_CDMOD     IN       CHAR,
   PE31_NRSER     IN       CHAR,
   PE31_NRSUBSER  IN       CHAR,
   PE31_NRDOC     IN       CHAR,
   PE31_DTDOC     IN       CHAR,
   PE31_CDITEM    IN       CHAR,
   PE31_VLAJUITEM IN       CHAR,
   PE31_NRCHVNFE  IN       CHAR,
   PE31_TPCLIFOR  IN       CHAR,
   PE31_CDCLIFOR  IN       CHAR
)
AS
BEGIN
   UPDATE EFDREGISTROE531_E31
      SET IDREGE530 = PIDREGE530,
          SMECODIGO = PSMECODIGO,
          E31_CDREG = PE31_CDREG,
          E31_CDPART = PE31_CDPART,
          E31_CDMOD = PE31_CDMOD,
          E31_NRSER = PE31_NRSER,
          E31_NRSUBSER = PE31_NRSUBSER,
          E31_NRDOC = PE31_NRDOC,
          E31_DTDOC = PE31_DTDOC,
          E31_CDITEM = PE31_CDITEM,
          E31_VLAJUITEM = PE31_VLAJUITEM,
          E31_NRCHVNFE = PE31_NRCHVNFE,
          E31_TPCLIFOR = PE31_TPCLIFOR,
          E31_CDCLIFOR = PE31_CDCLIFOR
    WHERE E31_IDREGE531 = PE31_IDREGE531;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCEFDREGISTROE531_E31 (PE31_IDREGE531 IN NUMBER)
AS
BEGIN
   DELETE FROM EFDREGISTROE531_E31
         WHERE E31_IDREGE531 = PE31_IDREGE531;
END;
/

CREATE OR REPLACE FORCE VIEW VW_SPEDEFDICMSR0150
(
   SMECODIGO,
   COD_PART,
   CDCLIFOR,
   CLIFOR,
   CDENDCLIFOR
)
AS
   (  SELECT SMECODIGO,
             COD_PART,
             CDCLIFOR,
             CLIFOR,
             CDENDCLIFOR
        FROM (                                                   /* BLOCO C */
                                                               --REGISTRO C100
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    C100.COD_PART AS COD_PART,
                    C100.RC100_CDCLIFOR AS CDCLIFOR,
                    C100.RC100_CLIFOR AS CLIFOR,
                    C100.RC100_CDENDCLIFOR AS CDENDCLIFOR
               FROM SPEDEFDNOTASFISCV10_RC100 C100, SPEDMODELOESCRT_SME SME
              WHERE C100.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             --REGISTRO C113
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    C113.COD_PART AS COD_PART,
                    C113.RC113_CDCLIFOR AS CDCLIFOR,
                    C113.RC113_CLIFOR AS CLIFOR,
                    C113.RC113_CDENDCLIFOR AS CDENDCLIFOR
               FROM SPEDEFDDOCFISCREFV10_RC113 C113, SPEDMODELOESCRT_SME SME
              WHERE C113.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             --REGISTRO C176
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    C176.COD_PART_ULT_E AS COD_PART,
                    C176.RC176_CDCLIFOR AS CDCLIFOR,
                    C176.RC176_CLIFOR AS CLIFOR,
                    NULL AS CDENDCLIFOR
               FROM SPEDEFDRESICMSOPSTV10_RC176 C176, SPEDMODELOESCRT_SME SME
              WHERE C176.SMECODIGO = SME.SME_CODIGO
                    AND C176.COD_PART_ULT_E IS NOT NULL
             --REGISTRO C160 - Ainda n�o implementado no processamento 08/08/13.
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    C160.COD_PART AS COD_PART,
                    NULL AS CDCLIFOR,
                    NULL AS CLIFOR,
                    NULL AS CDENDCLIFOR
               FROM SPEDEFDVOLTRANSPV10_RC160 C160, SPEDMODELOESCRT_SME SME
              WHERE C160.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             --REGISTRO C500
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    C500.COD_PART AS COD_PART,
                    C500.RC500_CDCLIFOR AS CDCLIFOR,
                    C500.RC500_CLIFOR AS CLIFOR,
                    C500.RC500_CDENDCLIFOR AS CDENDCLIFOR
               FROM SPEDEFDNFCONSUMOV10_RC500 C500, SPEDMODELOESCRT_SME SME
              WHERE C500.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             --REGISTRO C510
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    C510.COD_PART AS COD_PART,
                    C510.RC510_CDCLIFOR AS CDCLIFOR,
                    C510.RC510_CLIFOR AS CLIFOR,
                    NULL AS CDENDCLIFOR
               FROM SPEDEFDITNFCONSUMOV10_RC510 C510, SPEDMODELOESCRT_SME SME
              WHERE C510.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             /* BLOCO D*/
             --REGISTRO D100
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    D100.COD_PART AS COD_PART,
                    D100.RD100_CDCLIFOR AS CDCLIFOR,
                    D100.RD100_CLIFOR AS CLIFOR,
                    D100.RD100_CDENDCLIFOR AS CDENDCLIFOR
               FROM SPEDEFDSERVTRANSPV10_RD100 D100, SPEDMODELOESCRT_SME SME
              WHERE D100.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             -- Registro D130 COD_PART_CONSG
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    D130.COD_PART_CONSG AS COD_PART,
                    D130.RD130_CDCLIFOR_CONSG AS CDCLIFOR,
                    D130.RD130_CLIFOR_CONSG AS CLIFOR,
                    NULL AS CDENDCLIFOR
               FROM EFDCOCORODV10_RD130 D130, SPEDMODELOESCRT_SME SME
              WHERE D130.SMECODIGO = SME.SME_CODIGO
                    AND D130.COD_PART_CONSG IS NOT NULL
             -- Registro D130 COD_PART_RED
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    D130.COD_PART_RED AS COD_PART,
                    D130.RD130_CDCLIFOR_REDESP AS CDCLIFOR,
                    D130.RD130_CLIFOR_REDESP AS CLIFOR,
                    NULL AS CDENDCLIFOR
               FROM EFDCOCORODV10_RD130 D130, SPEDMODELOESCRT_SME SME
              WHERE D130.SMECODIGO = SME.SME_CODIGO
                    AND D130.COD_PART_RED IS NOT NULL
             -- Registro D140
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    D140.COD_PART_CONSG AS COD_PART,
                    D140.RD140_CDCLIFOR_CONSG AS CDCLIFOR,
                    D140.RD140_CLIFOR_CONSG AS CLIFOR,
                    NULL AS CDENDCLIFOR
               FROM EFDCOCOAQDV10_RD140 D140, SPEDMODELOESCRT_SME SME
              WHERE D140.SMECODIGO = SME.SME_CODIGO
                    AND D140.COD_PART_CONSG IS NOT NULL
             --REGISTRO D500
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    D500.COD_PART AS COD_PART,
                    D500.RD500_CDCLIFOR AS CDCLIFOR,
                    D500.RD500_CLIFOR AS CLIFOR,
                    D500.RD500_CDENDCLIFOR AS CDENDCLIFOR
               FROM SPEDEFDNFSRVCOMV10_RD500 D500, SPEDMODELOESCRT_SME SME
              WHERE D500.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             --REGISTRO D510
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    D510.COD_PART AS COD_PART,
                    D510.RD510_CDCLIFOR AS CDCLIFOR,
                    D510.RD510_CLIFOR AS CLIFOR,
                    NULL AS CDENDCLIFOR
               FROM SPEDEFDITNFSRVCOMV10_RD510 D510, SPEDMODELOESCRT_SME SME
              WHERE D510.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             /* BLOCO E */
             --REGISTRO E113
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    E113.COD_PART AS COD_PART,
                    E113.RE113_CDCLIFOR AS CDCLIFOR,
                    E113.RE113_CLIFOR AS CLIFOR,
                    E113.RE113_CDENDCLIFOR AS CDENDCLIFOR
               FROM SPEDEFDINFDAJAICMSV10_RE113 E113, SPEDMODELOESCRT_SME SME
              WHERE E113.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             --REGISTRO E240
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    E240.COD_PART AS COD_PART,
                    E240.RE240_CDCLIFOR AS CDCLIFOR,
                    E240.RE240_CLIFOR AS CLIFOR,
                    E240.RE240_CDENDCLIFOR AS CDENDCLIFOR
               FROM SPEDEFDINAJAPICMSTV10_RE240 E240, SPEDMODELOESCRT_SME SME
              WHERE E240.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             /* BLOCO G */
             --REGISTRO G130
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    G130.COD_PART AS COD_PART,
                    G130.RG130_CDCLIFOR AS CDCLIFOR,
                    G130.RG130_CLIFOR AS CLIFOR,
                    G130.RG130_CDENDCLIFOR AS CDENDCLIFOR
               FROM SPEDEFDDOCFISCALV10_RG130 G130, SPEDMODELOESCRT_SME SME
              WHERE G130.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             -- BLOCO H - H010
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    H010.COD_PART AS COD_PART,
                    H010.RH010_CDCLIFOR AS CDCLIFOR,
                    H010.RH010_CLIFOR AS CLIFOR,
                    NULL AS CDENDCLIFOR
               FROM SPEDEFDINVENTARIOV10_RH010 H010, SPEDMODELOESCRT_SME SME
              WHERE H010.SMECODIGO = SME.SME_CODIGO AND COD_PART IS NOT NULL
             /* BLOCO 1 */
             --REGISTRO 1600
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    R1600.COD_PART AS COD_PART,
                    R1600.R1600_CDCLIFOR AS CDCLIFOR,
                    R1600.R1600_CLIFOR CLIFOR,
                    NULL AS CDENDCLIFOR
               FROM SPEDEFDTOTALCARTAO_R1600 R1600, SPEDMODELOESCRT_SME SME
              WHERE R1600.SMECODIGO = SME.SME_CODIGO
             --REGISTRO 1110
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    R1110.COD_PART AS COD_PART,
                    R1110.R1110_CDCLIFOR AS CDCLIFOR,
                    R1110.R1110_CLIFOR AS CLIFOR,
                    R1110.R1110_CDENDCLIFOR AS CDENDCLIFOR
               FROM SPEDEFDDOCEXPORTV10_R1110 R1110, SPEDMODELOESCRT_SME SME
              WHERE R1110.SMECODIGO = SME.SME_CODIGO
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    K200.K02_CDPARTICIPANTE AS COD_PART,
                    K200.K02_CDCLIFOR AS CDCLIFOR,
                    K200.K02_TPCLIFOR AS CLIFOR,
                    NULL AS CDENDCLIFOR
               FROM EFD_ICMSIPIBLK200_K02 K200, SPEDMODELOESCRT_SME SME
              WHERE K200.SMECODIGO = SME.SME_CODIGO
             UNION
             SELECT SME.SME_CODIGO AS SMECODIGO,
                    K280.K16_CDPARTICIPANTE AS COD_PART,
                    K280.K16_CDCLIFOR AS CDCLIFOR,
                    K280.K16_TPCLIFOR AS CLIFOR,
                    NULL AS CDENDCLIFOR
               FROM EFD_ICMSIPIBLK280_K16 K280, SPEDMODELOESCRT_SME SME
              WHERE K280.SMECODIGO = SME.SME_CODIGO
              UNION
              SELECT SME.SME_CODIGO AS SMECODIGO,
                    E31.E31_CDPART AS COD_PART,
                    E31.E31_CDCLIFOR AS CDCLIFOR,
                    E31.E31_TPCLIFOR AS CLIFOR,
                    NULL AS CDENDCLIFOR
                FROM EFDREGISTROE531_E31 E31, SPEDMODELOESCRT_SME SME
                 WHERE E31.SMECODIGO = SME.SME_CODIGO
              )
    GROUP BY SMECODIGO,
             COD_PART,
             CDCLIFOR,
             CLIFOR,
             CDENDCLIFOR)
/

UPDATE SPEDVERSOESLAYOUT_SVL SET SVL_DTFIM = TO_DATE('31/12/2017', 'DD/MM/RRRR') WHERE SVL_CDLAYOUT = 'EFD10'
/

DELETE FROM RELTIPOREGISTROCOLUNA_RTC WHERE RTC_CDLAYOUT = 'EFD11'
/

DELETE FROM TIPOREGISTROARQUIVO_TRA WHERE TRA_CDLAYOUT = 'EFD11'
/

DELETE FROM NIVELLAYOUT_NLT WHERE NLT_CDLAYOUT = 'EFD11'
/

DELETE FROM LAYOUTARQUIVO_LAR WHERE LAR_CDLAYOUT = 'EFD11'
/

INSERT INTO LAYOUTARQUIVO_LAR(LAR_CDLAYOUT, LAR_DESCLAYOUT, LAR_NMABREVIACAO, LAR_NMPROCSYNC) VALUES('EFD11','LEIAUTE ESCRITURACAO FISCAL DIGITAL.Ato ICMS/COTEPE N� 52 DE 21/11/2013','LEFD',NULL)
/

INSERT INTO SPEDVERSOESLAYOUT_SVL  (SVL_IDVERSAOLAYOUT,   SVL_CDLEIAUTE,   SVL_LEIAUTE,   SVL_TPLEIAUTE,   SVL_CDSISTEMA,   SVL_DTINICIO,   SVL_DTCADASTRO,   SVL_USUARIO,   SVL_CDLAYOUT,   SVL_CDVERSAO,   SVL_DTFIM) VALUES  ((SELECT MAX(SVL_IDVERSAOLAYOUT) + 1 FROM SPEDVERSOESLAYOUT_SVL),   'ICMS/IPI 012',   'EFD-ICMS/IPI',   '1',   'EFD',   TO_DATE('01/01/2018', 'DD/MM/RRRR'),   SYSDATE,   GET_USER_MXM,   'EFD11',   '012',   NULL)
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1','REGISTRO 0000',NULL,NULL,1,NULL)
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','101','REGISTRO 0001',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10101','REGISTRO 0005',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10102','REGISTRO 0015',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10103','REGISTRO 0100',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10104','REGISTRO 0150',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1010401','REGISTRO 0175',NULL,NULL,7,'10104')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10105','REGISTRO 0190',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10106','REGISTRO 0200',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1010601','REGISTRO 0205',NULL,NULL,7,'10106')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1010602','REGISTRO 0206',NULL,NULL,7,'10106')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1010603','REGISTRO 0210',NULL,NULL,7,'10106')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1010604','REGISTRO 0220',NULL,NULL,5,'10106')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10108','REGISTRO 0300',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1010801','REGISTRO 0305',NULL,NULL,7,'10108')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10109','REGISTRO 0400',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10110','REGISTRO 0450',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10111','REGISTRO 0460',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10112','REGISTRO 0500',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10113','REGISTRO 0600',NULL,NULL,5,'101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','102','REGISTRO 0990',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103','REGISTRO C001',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10301','REGISTRO C100',NULL,NULL,5,'103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030101','REGISTRO C101',NULL,NULL,7,'10301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030102','REGISTRO C105',NULL,NULL,7,'10301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030103','REGISTRO C110',NULL,NULL,7,'10301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010301','REGISTRO C111',NULL,NULL,9,'1030103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010302','REGISTRO C112',NULL,NULL,9,'1030103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010303','REGISTRO C113',NULL,NULL,9,'1030103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010304','REGISTRO C114',NULL,NULL,9,'1030103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010305','REGISTRO C115',NULL,NULL,9,'1030103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010306','REGISTRO C116',NULL,NULL,9,'1030103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030104','REGISTRO C120',NULL,NULL,7,'10301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030105','REGISTRO C130',NULL,NULL,7,'10301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030106','REGISTRO C140',NULL,NULL,7,'10301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010601','REGISTRO C141',NULL,NULL,9,'1030106')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030107','REGISTRO C160',NULL,NULL,7,'10301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030108','REGISTRO C165',NULL,NULL,7,'10301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030109','REGISTRO C170',NULL,NULL,7,'10301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010901','REGISTRO C171',NULL,NULL,9,'1030109')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010902','REGISTRO C172',NULL,NULL,9,'1030109')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010903','REGISTRO C173',NULL,NULL,9,'1030109')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010904','REGISTRO C174',NULL,NULL,9,'1030109')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010905','REGISTRO C175',NULL,NULL,9,'1030109')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010906','REGISTRO C176',NULL,NULL,9,'1030109')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010907','REGISTRO C177',NULL,NULL,9,'1030109')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010908','REGISTRO C178',NULL,NULL,9,'1030109')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103010909','REGISTRO C179',NULL,NULL,9,'1030109')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030110','REGISTRO C190',NULL,NULL,7,'10301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030111','REGISTRO C195',NULL,NULL,7,'10301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103011101','REGISTRO C197',NULL,NULL,9,'1030111')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10302','REGISTRO C300',NULL,NULL,5,'103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030201','REGISTRO C310',NULL,NULL,7,'10302')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030202','REGISTRO C320',NULL,NULL,7,'10302')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103020201','REGISTRO C321',NULL,NULL,9,'1030202')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10303','REGISTRO C350',NULL,NULL,5,'103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030301','REGISTRO C370',NULL,NULL,7,'10303')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030302','REGISTRO C390',NULL,NULL,7,'10303')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10304','REGISTRO C400',NULL,NULL,5,'103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030401','REGISTRO C405',NULL,NULL,7,'10304')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103040101','REGISTRO C410',NULL,NULL,9,'1030401')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103040102','REGISTRO C420',NULL,NULL,9,'1030401')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10304010201','REGISTRO C425',NULL,NULL,11,'103040102')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103040103','REGISTRO C460',NULL,NULL,9,'1030401')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10304010301','REGISTRO C470',NULL,NULL,11,'103040103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103040104','REGISTRO C490',NULL,NULL,9,'1030401')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10305','REGISTRO C495',NULL,NULL,5,'103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10306','REGISTRO C500',NULL,NULL,5,'103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030601','REGISTRO C510',NULL,NULL,7,'10306')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030602','REGISTRO C590',NULL,NULL,7,'10306')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10307','REGISTRO C600',NULL,NULL,5,'103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030701','REGISTRO C601',NULL,NULL,7,'10307')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030702','REGISTRO C610',NULL,NULL,7,'10307')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030703','REGISTRO C620',NULL,NULL,7,'10307')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030704','REGISTRO C690',NULL,NULL,7,'10307')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10308','REGISTRO C700',NULL,NULL,5,'103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030801','REGISTRO C790',NULL,NULL,7,'10308')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','103080101','REGISTRO C791',NULL,NULL,9,'1030801')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10309','REGISTRO C800',NULL,NULL,5,'103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1030901','REGISTRO C850',NULL,NULL,7,'10309')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10310','REGISTRO C860',NULL,NULL,5,'103')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1031001','REGISTRO C890',NULL,NULL,7,'10310')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','104','REGISTRO C999',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','105','REGISTRO D001',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10501','REGISTRO D100',NULL,NULL,5,'105')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050101','REGISTRO D101',NULL,NULL,7,'10501')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050102','REGISTRO D110',NULL,NULL,7,'10501')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','105010202','REGISTRO D120',NULL,NULL,9,'1050102')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050103','REGISTRO D130',NULL,NULL,7,'10501')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050104','REGISTRO D140',NULL,NULL,7,'10501')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050105','REGISTRO D150',NULL,NULL,7,'10501')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050106','REGISTRO D160',NULL,NULL,7,'10501')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','105010601','REGISTRO D161',NULL,NULL,9,'1050106')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','105010602','REGISTRO D162',NULL,NULL,9,'1050106')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050107','REGISTRO D170',NULL,NULL,7,'10501')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050108','REGISTRO D180',NULL,NULL,7,'10501')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050109','REGISTRO D190',NULL,NULL,7,'10501')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050110','REGISTRO D195',NULL,NULL,7,'10501')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','105011001','REGISTRO D197',NULL,NULL,9,'1050110')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10502','REGISTRO D300',NULL,NULL,5,'105')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050201','REGISTRO D301',NULL,NULL,7,'10502')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050202','REGISTRO D310',NULL,NULL,7,'10502')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10503','REGISTRO D350',NULL,NULL,5,'105')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050301','REGISTRO D355',NULL,NULL,7,'10503')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','105030101','REGISTRO D360',NULL,NULL,9,'1050301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','105030102','REGISTRO D365',NULL,NULL,9,'1050301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','105030103','REGISTRO D390',NULL,NULL,9,'1050301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10504','REGISTRO D400',NULL,NULL,5,'105')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050401','REGISTRO D410',NULL,NULL,7,'10504')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','105040101','REGISTRO D411',NULL,NULL,9,'1050401')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050402','REGISTRO D420',NULL,NULL,7,'10504')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10505','REGISTRO D500',NULL,NULL,5,'105')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050501','REGISTRO D510',NULL,NULL,7,'10505')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050502','REGISTRO D520',NULL,NULL,7,'10505')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050503','REGISTRO D530',NULL,NULL,7,'10505')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050504','REGISTRO D590',NULL,NULL,7,'10505')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10506','REGISTRO D600',NULL,NULL,5,'105')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050601','REGISTRO D610',NULL,NULL,7,'10506')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050602','REGISTRO D620',NULL,NULL,7,'10506')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050603','REGISTRO D690',NULL,NULL,7,'10506')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10507','REGISTRO D695',NULL,NULL,5,'105')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1050701','REGISTRO D696',NULL,NULL,7,'10507')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','105070101','REGISTRO D697',NULL,NULL,9,'1050701')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','106','REGISTRO D990',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','107','REGISTRO E001',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10701','REGISTRO E100',NULL,NULL,5,'107')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1070101','REGISTRO E110',NULL,NULL,7,'10701')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','107010101','REGISTRO E111',NULL,NULL,9,'1070101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10701010101','REGISTRO E112',NULL,NULL,11,'107010101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10701010102','REGISTRO E113',NULL,NULL,11,'107010101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','107010102','REGISTRO E115',NULL,NULL,9,'1070101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','107010103','REGISTRO E116',NULL,NULL,9,'1070101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10702','REGISTRO E200',NULL,NULL,5,'107')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1070201','REGISTRO E210',NULL,NULL,7,'10702')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','107020101','REGISTRO E220',NULL,NULL,9,'1070201')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10702010101','REGISTRO E230',NULL,NULL,11,'107020101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10702010102','REGISTRO E240',NULL,NULL,11,'107020101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','107020102','REGISTRO E250',NULL,NULL,9,'1070201')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10703','REGISTRO E300',NULL,NULL,5,'107')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1070301','REGISTRO E310',NULL,NULL,7,'10703')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','107030101','REGISTRO E311',NULL,NULL,9,'1070301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10703010101','REGISTRO E312',NULL,NULL,11,'107030101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10703010102','REGISTRO E313',NULL,NULL,11,'107030101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','107030102','REGISTRO E316',NULL,NULL,9,'1070301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10704','REGISTRO E500',NULL,NULL,5,'107')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1070401','REGISTRO E510',NULL,NULL,7,'10704')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1070402','REGISTRO E520',NULL,NULL,7,'10704')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','107040201','REGISTRO E530',NULL,NULL,9,'1070402')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10704020101','REGISTRO E531',NULL,NULL,11,'107040201')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','108','REGISTRO E990',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','109','REGISTRO G001',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10901','REGISTRO G110',NULL,NULL,5,'109')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1090101','REGISTRO G125',NULL,NULL,7,'10901')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','109010101','REGISTRO G126',NULL,NULL,9,'1090101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','109010102','REGISTRO G130',NULL,NULL,9,'1090101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','10901010201','REGISTRO G140',NULL,NULL,11,'109010102')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','110','REGISTRO G990',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','111','REGISTRO H001',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11101','REGISTRO H005',NULL,NULL,5,'111')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1110101','REGISTRO H010',NULL,NULL,7,'11101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','111010101','REGISTRO H020',NULL,NULL,9,'1110101')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','112','REGISTRO H990',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','113','REGISTRO K001',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11301','REGISTRO K100',NULL,NULL,5,'113')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1130101','REGISTRO K200',NULL,NULL,7,'11301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1130102','REGISTRO K210',NULL,NULL,7,'11301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','113010201','REGISTRO K215',NULL,NULL,9,'1130102')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1130103','REGISTRO K220',NULL,NULL,7,'11301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1130104','REGISTRO K230',NULL,NULL,7,'11301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','113010401','REGISTRO K235',NULL,NULL,9,'1130104')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1130105','REGISTRO K250',NULL,NULL,7,'11301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','113010501','REGISTRO K255',NULL,NULL,9,'1130105')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1130106','REGISTRO K260',NULL,NULL,7,'11301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','113010601','REGISTRO K265',NULL,NULL,9,'1130106')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1130107','REGISTRO K270',NULL,NULL,7,'11301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','113010701','REGISTRO K275',NULL,NULL,9,'1130107')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1130108','REGISTRO K280',NULL,NULL,7,'11301')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','114','REGISTRO K990',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','115','REGISTRO 1001',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11501','REGISTRO 1010',NULL,NULL,5,'115')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11502','REGISTRO 1100',NULL,NULL,5,'115')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1150201','REGISTRO 1105',NULL,NULL,7,'11502')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','115020101','REGISTRO 1110',NULL,NULL,9,'1150201')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11503','REGISTRO 1200',NULL,NULL,5,'115')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1150301','REGISTRO 1210',NULL,NULL,7,'11503')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11504','REGISTRO 1300',NULL,NULL,5,'115')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1150401','REGISTRO 1310',NULL,NULL,7,'11504')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','115040101','REGISTRO 1320',NULL,NULL,9,'1150401')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11505','REGISTRO 1350',NULL,NULL,5,'115')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1150501','REGISTRO 1360',NULL,NULL,7,'11505')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1150502','REGISTRO 1370',NULL,NULL,7,'11505')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11506','REGISTRO 1390',NULL,NULL,5,'115')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1150601','REGISTRO 1391',NULL,NULL,7,'11506')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11507','REGISTRO 1400',NULL,NULL,5,'115')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11508','REGISTRO 1500',NULL,NULL,5,'115')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1150801','REGISTRO 1510',NULL,NULL,7,'11508')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11509','REGISTRO 1600',NULL,NULL,5,'115')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11510','REGISTRO 1700',NULL,NULL,5,'115')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','1151001','REGISTRO 1710',NULL,NULL,7,'11510')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','116','REGISTRO 1990',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','117','REGISTRO 9001',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','11701','REGISTRO 9900',NULL,NULL,5,'117')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','118','REGISTRO 9990',NULL,NULL,3,'1')
/

INSERT INTO NIVELLAYOUT_NLT(NLT_CDLAYOUT,NLT_SQNIVEL,NLT_DESCNIVEL,NLT_SQNIVELSUM,NLT_SQNIVELSUM2,NLT_NUMNIVEL,NLT_SQNIVELPAI) VALUES('EFD11','2','REGISTRO 9999',NULL,NULL,1,NULL)
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1','REG0000','REGISTRO 0000','1','SPEDEFDABERTURAV10_R0000',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','101','REG0001','REGISTRO 0001','2','SPEDEFDABERTBLOCO_R0001',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10101','REG0005','REGISTRO 0005','3','SPEDEFDCOMPLENTV10_R0005',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10102','REG0015','REGISTRO 0015','4','SPEDEFDCONTSUBSTV10_R0015',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10103','REG0100','REGISTRO 0100','5','SPEDEFDCONTABILISTV10_R0100',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10104','REG0150','REGISTRO 0150','6','SPEDEFDPARTV10_R0150',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1010401','REG0175','REGISTRO 0175','7','SPEDEFDALTPARTV10_R0175',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10105','REG0190','REGISTRO 0190','8','SPEDEFDIDUNMEDV10_R0190',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10106','REG0200','REGISTRO 0200','9','SPEDEFDIDITEMV10_R0200',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1010601','REG0205','REGISTRO 0205','10','SPEDEFDALTITEM_R0205',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1010602','REG0206','REGISTRO 0206','11','SPEDEFDPRODANPV10_R0206',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1010603','REG0210','REGISTRO 0210','12','EFD_ICMSIPIBLK0210_K09',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1010604','REG0220','REGISTRO 0220','13','SPEDEFDFATCONVV10_R0220',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10108','REG0300','REGISTRO 0300','14','SPEDEFDBEMCOMPV10_R0300',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1010801','REG0305','REGISTRO 0305','15','SPEDEFDINFUTILBEMV10_R0305',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10109','REG0400','REGISTRO 0400','16','SPEDEFDNATOPSERVV10_R0400',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10110','REG0450','REGISTRO 0450','17','SPEDEFDINFDOCFISV10_R0450',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10111','REG0460','REGISTRO 0460','18','SPEDEFDOBSDOCFISV10_R0460',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10112','REG0500','REGISTRO 0500','19','SPEDEFDPLCONTASV10_R0500',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10113','REG0600','REGISTRO 0600','20','SPEDEFDCENTROCUSTV10_R0600',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','102','REG0990','REGISTRO 0990','21','SPEDEFDENCERRBLOCO_R0990',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103','REGC001','REGISTRO C001','22','SPEDEFDABERTURAV10_RC001',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10301','REGC100','REGISTRO C100','23','SPEDEFDNOTASFISCV10_RC100',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030101','REGC101','REGISTRO C101','24','EFD_ICMSIPIBLC101_C01',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030102','REGC105','REGISTRO C105','25','SPEDEFDOPICMSSTUFV12_RC105',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030103','REGC110','REGISTRO C110','26','SPEDEFDINFCOMPNFV10_RC110',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010301','REGC111','REGISTRO C111','27','SPEDEFDPROCREFV10_RC111',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010302','REGC112','REGISTRO C112','28','SPEDEFDDOCARRECREFV10_RC112',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010303','REGC113','REGISTRO C113','29','SPEDEFDDOCFISCREFV10_RC113',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010304','REGC114','REGISTRO C114','30','SPEDEFDCUPOMFISREFV10_RC114',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010305','REGC115','REGISTRO C115','31','SPEDEFDLOCCOLENTV10_RC115',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010306','REGC116','REGISTRO C116','32','SPEDEFDCUPOMELEREF_RC116',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030104','REGC120','REGISTRO C120','33','SPEDEFDOPERIMPORTV10_RC120',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030105','REGC130','REGISTRO C130','34','SPEDEFDOUTROSIMPV10_RC130',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030106','REGC140','REGISTRO C140','35','SPEDEFDFATURAV10_RC140',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010601','REGC141','REGISTRO C141','36','SPEDEFDVENCFATURAV10_RC141',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030107','REGC160','REGISTRO C160','37','SPEDEFDVOLTRANSPV10_RC160',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030108','REGC165','REGISTRO C165','38','SPEDEFDOPCOMBV10_RC165',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030109','REGC170','REGISTRO C170','39','SPEDEFDITDOCV10_RC170',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010901','REGC171','REGISTRO C171','40','SPEDEFDARMCOMBV10_RC171',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010902','REGC172','REGISTRO C172','41','SPEDEFDOPISSQNV10_RC172',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010903','REGC173','REGISTRO C173','42','SPEDEFDOPMEDICV10_RC173',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010904','REGC174','REGISTRO C174','43','SPEDEFDOPARMFOGV10_RC174',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010905','REGC175','REGISTRO C175','44','SPEDEFDOPVEICNOVV10_RC175',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010906','REGC176','REGISTRO C176','45','SPEDEFDRESICMSOPSTV10_RC176',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010907','REGC177','REGISTRO C177','46','SPEDEFDOPPRODSLIPIV10_RC177',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010908','REGC178','REGISTRO C178','47','SPEDEFDPRDIPIUNQTV10_RC178',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103010909','REGC179','REGISTRO C179','48','SPEDEFDINFCOMPSTV10_RC179',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030110','REGC190','REGISTRO C190','49','SPEDEFDREGANALV10_RC190',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030111','REGC195','REGISTRO C195','50','SPEDEFDOBSLANCFISCV10_RC195',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103011101','REGC197','REGISTRO C197','51','SPEDEFDOBSLANCFISCV10_RC197',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10302','REGC300','REGISTRO C300','52','SPEDEFDRESNFVENCONV10_RC300',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030201','REGC310','REGISTRO C310','53','SPEDEFDDOCCANCNFCONV10_R310',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030202','REGC320','REGISTRO C320','54','SPEDEFDRGANRSNFCONV10_RC320',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103020201','REGC321','REGISTRO C321','55','SPEDEFDITRESDIADOCV10_RC321',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10303','REGC350','REGISTRO C350','56','SPEDEFDNFVENDCONSV10_RC350',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030301','REGC370','REGISTRO C370','57','SPEDEFDITDOCV10_RC370',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030302','REGC390','REGISTRO C390','58','SPEDEFDREGANANFCONV10_RC390',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10304','REGC400','REGISTRO C400','59','SPEDEFDEQUIPECFV10_RC400',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030401','REGC405','REGISTRO C405','60','SPEDEFDREDUCAOZV10_RC405',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103040101','REGC410','REGISTRO C410','61','SPEDEFDTOTIPOSTOV10_RC410',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103040102','REGC420','REGISTRO C420','62','SPEDEFDREGTOTREDZV10_RC420',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10304010201','REGC425','REGISTRO C425','63','SPEDEFDITMOVDIAV10_RC425',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103040103','REGC460','REGISTRO C460','64','SPEDEFDOCFISCEFCV10_RC460',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10304010301','REGC470','REGISTRO C470','65','SPEDEFDITDOCFISEFCV10_RC470',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103040104','REGC490','REGISTRO C490','66','SPEDEFDREGANMOVDIAV10_RC490',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10305','REGC495','REGISTRO C495','67','SPEDEFDRESMESITECFV10_RC495',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10306','REGC500','REGISTRO C500','68','SPEDEFDNFCONSUMOV10_RC500',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030601','REGC510','REGISTRO C510','69','SPEDEFDITNFCONSUMOV10_RC510',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030602','REGC590','REGISTRO C590','70','SPEDEFDREANANFCONSV10_RC590',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10307','REGC600','REGISTRO C600','71','SPEDEFDCONDIANFCONV10_RC600',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030701','REGC601','REGISTRO C601','72','SPEDEFDDOCCANCCONSV10_RC601',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030702','REGC610','REGISTRO C610','73','SPEDEFDITCONNFCONSV10_RC610',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030703','REGC620','REGISTRO C620','74','SPEDEFDCOMPDOCADV10_RC620',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030704','REGC690','REGISTRO C690','75','SPEDEFDRECANALDOCSV10_RC690',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10308','REGC700','REGISTRO C700','76','SPEDEFDCONDOCNFCEEV10_RC700',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030801','REGC790','REGISTRO C790','77','SPEDEFDANALDOCSV10_RC790',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','103080101','REGC791','REGISTRO C791','78','SPEDEFDANALDOCSV10_RC791',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10309','REGC800','REGISTRO C800','79','SPEDEFDCUPOMFISELETRO_RC800',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1030901','REGC850','REGISTRO C850','80','SPEDEFDREGANACFE_RC850',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10310','REGC860','REGISTRO C860','81','SPEDEFDIDEQPSATCFE_RC860',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1031001','REGC890','REGISTRO C890','82','SPEDEFDRESUDIACFE_RC890',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','104','REGC990','REGISTRO C990','83','SPEDEFDENCERRAMENTV10_RC990',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','105','REGD001','REGISTRO D001','84','SPEDEFDABERTURAV10_RD001',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10501','REGD100','REGISTRO D100','85','SPEDEFDSERVTRANSPV10_RD100',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050101','REGD101','REGISTRO D101','86','EFD_ICMSIPIBLD101_D01',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050102','REGD110','REGISTRO D110','87','SPEDEFDITDCNFSRVTRV10_RD110',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','105010202','REGD120','REGISTRO D120','88','SPEDEFDCOMPNFSRVTRV10_RD120',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050103','REGD130','REGISTRO D130','89','EFDCOCORODV10_RD130',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050104','REGD140','REGISTRO D140','90','EFDCOCOAQDV10_RD140',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050105','REGD150','REGISTRO D150','91','EFDCOCOAEDV10_RD150',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050106','REGD160','REGISTRO D160','92','SPEDEFDCRGTRNSPV10_RD160',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','105010601','REGD161','REGISTRO D161','93','SPEDEFDLOCCOLENTRV10_RD161',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','105010602','REGD162','REGISTRO D162','94','EFDIDENTDFV10_RD162',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050107','REGD170','REGISTRO D170','95','SPEDEFDCONMULTCARGV10_RD170',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050108','REGD180','REGISTRO D180','96','SPEDEFDMODAISV10_RD180',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050109','REGD190','REGISTRO D190','97','SPEDEFDREGANALDOCV10_RD190',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050110','REGD195','REGISTRO D195','98','SPEDEFDOBSLANCFISCV10_RD195',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','105011001','REGD197','REGISTRO D197','99','SPEDEFDOBSLANCFISCV10_RD197',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10502','REGD300','REGISTRO D300','100','SPEDEFDRGANALPASSV10_RD300',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050201','REGD301','REGISTRO D301','101','SPEDEFDRGDOCCANCV10_RD301',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050202','REGD310','REGISTRO D310','102','SPEDEFDCOMPBILHETV10_RD310',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10503','REGD350','REGISTRO D350','103','SPEDEFDEQUIPECFV10_RD350',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050301','REGD355','REGISTRO D355','104','SPEDEFDREDUCAOZV10_RD355',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','105030101','REGD360','REGISTRO D360','105','SPEDEFDTOTPISCOFINV10_RD360',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','105030102','REGD365','REGISTRO D365','106','SPEDEFDTOTPARRDZV10_RD365',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','105030103','REGD390','REGISTRO D390','107','SPEDEFDTOTPARRDZV10_RD390',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10504','REGD400','REGISTRO D400','108','SPEDEFDRESMOVDIAV10_RD400',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050401','REGD410','REGISTRO D410','109','SPEDEFDDOCFISINFOV10_RD410',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','105040101','REGD411','REGISTRO D411','110','SPEDEFDDOCFISINFOV10_RD411',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050402','REGD420','REGISTRO D420','111','SPEDEFDCOMPDOCINFV10_RD420',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10505','REGD500','REGISTRO D500','112','SPEDEFDNFSRVCOMV10_RD500',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050501','REGD510','REGISTRO D510','113','SPEDEFDITNFSRVCOMV10_RD510',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050502','REGD520','REGISTRO D520','114','SPEDEFDCOMPDOCADV10_RD520',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050503','REGD530','REGISTRO D530','115','SPEDEFDTERMFATV10_RD530',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050504','REGD590','REGISTRO D590','116','SPEDEFDREGANALDOCV10_RD590',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10506','REGD600','REGISTRO D600','117','SPEDEFDCONSRVNFV10_RD600',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050601','REGD610','REGISTRO D610','118','SPEDEFDITDOCCONSV10_RD610',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050602','REGD620','REGISTRO D620','119','SPEDEFDCOMPDOCADV10_RD620',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050603','REGD690','REGISTRO D690','120','SPEDEFDREGANALDOCV10_RD690',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10507','REGD695','REGISTRO D695','121','SPEDEFDCONSPRESSRVV10_D695',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1050701','REGD696','REGISTRO D696','122','SPEDEFDREGANALDOCV10_RD696',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','105070101','REGD697','REGISTRO D697','123','SPEDEFDINFICMSUFV10_RD697',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','106','REGD990','REGISTRO D990','124','SPEDEFDENCERRAMENTV10_RD990',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','107','REGE001','REGISTRO E001','125','SPEDEFDABERTURAV10_RE001',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10701','REGE100','REGISTRO E100','126','SPEDEFDPERAPICMSV10_RE100',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1070101','REGE110','REGISTRO E110','127','SPEDEFDAPURAICSMV10_RE110',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','107010101','REGE111','REGISTRO E111','128','SPEDEFDAJUSTAPICMSV10_RE111',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10701010101','REGE112','REGISTRO E112','129','SPEDEFDINFADAJICMSV10_RE112',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10701010102','REGE113','REGISTRO E113','130','SPEDEFDINFDAJAICMSV10_RE113',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','107010102','REGE115','REGISTRO E115','131','SPEDEFDINFADAPV10_RE115',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','107010103','REGE116','REGISTRO E116','132','SPEDEFDOBRICMSROPV10_RE116',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10702','REGE200','REGISTRO E200','133','SPEDEFDPERAPICMSSTV10_RE200',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1070201','REGE210','REGISTRO E210','134','SPEDEFDAPICMSSTV10_RE210',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','107020101','REGE220','REGISTRO E220','135','SPEDEFDAJAPICMSSTV10_RE220',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10702010101','REGE230','REGISTRO E230','136','SPEDEFDINADAPICMSTV10_RE230',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10702010102','REGE240','REGISTRO E240','137','SPEDEFDINAJAPICMSTV10_RE240',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','107020102','REGE250','REGISTRO E250','138','SPEDEFDOBICMSRECSTV10_RE250',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10703','REGE300','REGISTRO E300','139','EFD_ICMSIPIBLE300_E00',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1070301','REGE310','REGISTRO E310','140','EFD_ICMSIPIBLE310_E01',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','107030101','REGE311','REGISTRO E311','141','EFD_ICMSIPIBLE311_E02',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10703010101','REGE312','REGISTRO E312','142','EFD_ICMSIPIBLE312_E03',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10703010102','REGE313','REGISTRO E313','143','EFD_ICMSIPIBLE313_E04',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','107030102','REGE316','REGISTRO E316','144','EFD_ICMSIPIBLE316_E05',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10704','REGE500','REGISTRO E500','145','SPEDEFDPERAPIPIV10_RE500',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1070401','REGE510','REGISTRO E510','146','SPEDEFDCONSVLRIPIV10_RE510',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1070402','REGE520','REGISTRO E520','147','SPEDEFDAPURACAOIPIV10_RE520',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','107040201','REGE530','REGISTRO E530','148','SPEDEFDAJAPURAIPIV10_RE530',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10704020101','REGE531','REGISTRO E531','149','EFDREGISTROE531_E31',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','108','REGE990','REGISTRO E990','150','SPEDEFDENCERRBLOCO_RE990',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','109','REGG001','REGISTRO G001','151','SPEDEFDABERTURAV10_RG001',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10901','REGG110','REGISTRO G110','152','SPEDEFDATIVOPERV10_RG110',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1090101','REGG125','REGISTRO G125','153','SPEDEFDMOVATIVOV10_RG125',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','109010101','REGG126','REGISTRO G126','154','SPEDEFDOUTROSCREDV10_RG126',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','109010102','REGG130','REGISTRO G130','155','SPEDEFDDOCFISCALV10_RG130',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','10901010201','REGG140','REGISTRO G140','156','SPEDEFDITDOCFISCALV10_RG140',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','110','REGG990','REGISTRO G990','157','SPEDEFDENCERRAMENTV10_RG990',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','111','REGH001','REGISTRO H001','158','SPEDEFDABERTURAV10_RH001',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11101','REGH005','REGISTRO H005','159','SPEDEFDTOTINVENTV10_RH005',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1110101','REGH010','REGISTRO H010','160','SPEDEFDINVENTARIOV10_RH010',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','111010101','REGH020','REGISTRO H020','161','SPEDEFDINFCOMPINVV10_RH020',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','112','REGH990','REGISTRO H990','162','SPEDEFDENCERRAV10_RH990',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','113','REGK001','REGISTRO K001','163','EFD_ICMSIPIBLK001_K00',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11301','REGK100','REGISTRO K100','164','EFD_ICMSIPIBLK100_K01',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1130101','REGK200','REGISTRO K200','165','EFD_ICMSIPIBLK200_K02',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1130102','REGK210','REGISTRO K210','166','EFD_ICMSIPIBLK210_K10',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','113010201','REGK215','REGISTRO K215','167','EFD_ICMSIPIBLK215_K11',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1130103','REGK220','REGISTRO K220','168','EFD_ICMSIPIBLK220_K03',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1130104','REGK230','REGISTRO K230','169','EFD_ICMSIPIBLK230_K04',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','113010401','REGK235','REGISTRO K235','170','EFD_ICMSIPIBLK235_K05',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1130105','REGK250','REGISTRO K250','171','EFD_ICMSIPIBLK250_K06',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','113010501','REGK255','REGISTRO K255','172','EFD_ICMSIPIBLK255_K07',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1130106','REGK260','REGISTRO K260','173','EFD_ICMSIPIBLK260_K12',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','113010601','REGK265','REGISTRO K265','174','EFD_ICMSIPIBLK265_K13',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1130107','REGK270','REGISTRO K270','175','EFD_ICMSIPIBLK270_K14',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','113010701','REGK275','REGISTRO K275','176','EFD_ICMSIPIBLK275_K15',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1130108','REGK280','REGISTRO K280','177','EFD_ICMSIPIBLK280_K16',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','114','REGK990','REGISTRO K990','178','EFD_ICMSIPIBLK990_K08',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','115','REG1001','REGISTRO 1001','179','SPEDEFDABERTURAV10_R1001',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11501','REG1010','REGISTRO 1010','180','SPEDEFDOBRIGATORIEDADV10_R1010',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11502','REG1100','REGISTRO 1100','181','SPEDEFDINFEXPORTV10_R1100',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1150201','REG1105','REGISTRO 1105','182','SPEDEFDDOCEXPORTV10_R1105',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','115020101','REG1110','REGISTRO 1110','183','SPEDEFDDOCEXPORTV10_R1110',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11503','REG1200','REGISTRO 1200','184','SPEDEFDCTRLCREDFISV10_R1200',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1150301','REG1210','REGISTRO 1210','185','SPEDEFDUTILCREDFISV10_R1210',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11504','REG1300','REGISTRO 1300','186','SPEDEFDMOVCOMBUSTV10_R1300',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1150401','REG1310','REGISTRO 1310','187','SPEDEFDMOVCOMBTQV20_R1310',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','115040101','REG1320','REGISTRO 1320','188','SPEDEFDVOLVENDASV10_R1320',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11505','REG1350','REGISTRO 1350','189','SPEDEFDBOMBAV10_R1350',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1150501','REG1360','REGISTRO 1360','190','SPEDEFDLACREBOMBAV10_R1360',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1150502','REG1370','REGISTRO 1370','191','SPEDEFDBICOBOMBAV10_R1370',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11506','REG1390','REGISTRO 1390','192','SPEDEFDCONTRPRODUSINAV10_R1390',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1150601','REG1391','REGISTRO 1391','193','SPEDEFDPRODDIAUSINAV10_R1391',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11507','REG1400','REGISTRO 1400','194','SPEDEFDINFVALAGREGV10_1400',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11508','REG1500','REGISTRO 1500','195','SPEDEFDNFENERGIAV10_R1500',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1150801','REG1510','REGISTRO 1510','196','SPEDEFDITNFENERGIAV10_R1510',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11509','REG1600','REGISTRO 1600','197','SPEDEFDTOTALCARTAO_R1600',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11510','REG1700','REGISTRO 1700','198','SPEDEFDDOCUTV10_R1700',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','1151001','REG1710','REGISTRO 1710','199','SPEDEFDDOCCANV10_R1710',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','116','REG1990','REGISTRO 1990','200','SPEDEFDENCERBLOCV10_R1990',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','117','REG9001','REGISTRO 9001','201','SPEDEFDABERTURAV10_R9001',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','11701','REGI9900','REGISTRO 9900','202','SPEDEFDREGARQV10_R9900',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','118','REG9990','REGISTRO 9990','203','SPEDEFDENCERBLOCV10_R9990',NULL,NULL,NULL,'N')
/

INSERT INTO TIPOREGISTROARQUIVO_TRA(TRA_CDLAYOUT, TRA_SQNIVEL, TRA_TIPOARQUIVO, TRA_DESCTIPOARQUIVO, TRA_ORDERTIPO, TRA_NMVIEW, TRA_SQNIVELSUM, TRA_TPARQUIVOSUM, TRA_ORDERBY, TRA_PROCESPEC) VALUES('EFD11','2','REG9999','REGISTRO 9999','204','SPEDEFDENCERARQV10_R9999',NULL,NULL,NULL,'N')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','240','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','243','4','3','0','0','DT_INI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','244','5','4','0','0','DT_FIN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','245','6','5','0','0','NOME',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','246','7','6','0','0','CNPJ',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','248','9','7','0','0','UF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','249','10','8','0','0','IE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','250','11','9','0','0','COD_MUN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','251','12','10','0','0','IM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','247','8','19','0','0','CPF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','252','13','22','0','0','SUFRAMA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','255','16','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','241','2','112','0','0','COD_VER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','242','3','113','0','0','COD_FIN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','253','14','114','0','0','IND_PERFIL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1','REG0000','254','15','115','0','0','IND_ATIV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','101','REG0001','256','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','101','REG0001','258','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','101','REG0001','257','2','116','0','0','IND_MOV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10101','REG0005','259','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10101','REG0005','269','11','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10101','REG0005','260','2','117','0','0','FANTASIA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10101','REG0005','261','3','118','0','0','CEP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10101','REG0005','262','4','119','0','0','END',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10101','REG0005','263','5','120','0','0','NUM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10101','REG0005','264','6','121','0','0','COMPL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10101','REG0005','265','7','122','0','0','BAIRRO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10101','REG0005','266','8','123','0','0','FONE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10101','REG0005','267','9','124','0','0','FAX',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10101','REG0005','268','10','125','0','0','EMAIL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10102','REG0015','270','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10102','REG0015','272','3','21','0','0','IE_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10102','REG0015','273','4','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10102','REG0015','271','2','126','0','0','UF_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','1062','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','1063','2','5','0','0','NOME',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','278','5','6','0','0','CNPJ',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','287','14','9','0','0','COD_MUN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','276','3','19','0','0','CPF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','288','15','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','279','6','118','0','0','CEP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','280','7','119','0','0','END',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','281','8','120','0','0','NUM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','282','9','121','0','0','COMPL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','283','10','122','0','0','BAIRRO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','284','11','123','0','0','FONE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','285','12','124','0','0','FAX',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','286','13','125','0','0','EMAIL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10103','REG0100','277','4','128','0','0','CRC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','289','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','291','3','5','0','0','NOME',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','293','5','6','0','0','CNPJ',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','295','7','8','0','0','IE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','296','8','9','0','0','COD_MUN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','290','2','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','292','4','18','0','0','COD_PAIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','294','6','19','0','0','CPF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','297','9','22','0','0','SUFRAMA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','302','14','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','298','10','119','0','0','END',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','299','11','120','0','0','NUM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','300','12','121','0','0','COMPL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10104','REG0150','301','13','122','0','0','BAIRRO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010401','REG0175','303','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010401','REG0175','304','2','43','0','0','DT_ALT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010401','REG0175','307','5','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010401','REG0175','305','3','110','0','0','NR_CAMPO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010401','REG0175','306','4','127','0','0','CONT_ANT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10105','REG0190','308','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10105','REG0190','311','4','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10105','REG0190','309','2','129','0','0','UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10105','REG0190','310','3','130','0','0','DESCR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','14','13','9','0','0','R0200_CEST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','13','14','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','2','2','131','0','1','COD_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','3','3','132','0','0','DESCR_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','4','4','133','0','0','COD_BARRA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','5','5','134','0','0','COD_ANT_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','6','6','135','0','0','UNID_INV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','7','7','136','0','0','TIPO_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','8','8','137','0','0','COD_NCM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','9','9','138','0','0','EX_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','10','10','139','0','0','COD_GEN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','11','11','140','0','0','COD_LST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10106','REG0200','12','12','141','0','0','ALIQ_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010601','REG0205','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010601','REG0205','3','3','3','0','0','DT_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010601','REG0205','4','4','4','0','0','DT_FIM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010601','REG0205','6','6','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010601','REG0205','7','7','131','0','1','COD_ITEM','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010601','REG0205','5','5','134','0','0','COD_ANT_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010601','REG0205','2','2','142','0','0','DESCR_ANT_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010602','REG0206','330','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010602','REG0206','332','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010602','REG0206','331','2','143','0','0','COD_COMB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010603','REG0210','1','1','1','0','0','K09_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010603','REG0210','2','2','17','0','0','K09_CDITEMCOMP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010603','REG0210','3','3','127','0','0','K09_QTCOMP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010603','REG0210','6','6','131','0','1','COD_ITEM','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010603','REG0210','4','4','197','0','0','K09_PEPERDA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010603','REG0210','5','5','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010604','REG0220','333','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010604','REG0220','336','4','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010604','REG0220','337','5','131','0','1','COD_ITEM','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010604','REG0220','334','2','144','0','0','UNID_CONV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010604','REG0220','335','3','145','0','0','FAT_CONV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10108','REG0300','3','3','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10108','REG0300','2','2','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10108','REG0300','6','6','132','0','0','DESCR_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10108','REG0300','1','1','1112','0','1','IDREG0300','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10108','REG0300','4','4','1121','0','0','COD_IND_BEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10108','REG0300','5','5','1136','0','0','IDENT_MERC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10108','REG0300','7','7','1137','0','0','COD_PRNC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10108','REG0300','8','8','1138','0','0','COD_CTA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10108','REG0300','9','9','1139','0','0','NR_PARC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010801','REG0305','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010801','REG0305','3','3','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010801','REG0305','1','1','1112','0','1','IDREG0305','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010801','REG0305','2','2','1112','0','0','IDREG0300','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010801','REG0305','5','5','1140','0','0','COD_CCUS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010801','REG0305','6','6','1141','0','0','FUNC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1010801','REG0305','7','7','1142','0','0','VIDA_UTIL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10109','REG0400','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10109','REG0400','2','2','44','0','1','COD_NAT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10109','REG0400','4','4','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10109','REG0400','3','3','146','0','0','DESCR_NAT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10110','REG0450','341','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10110','REG0450','344','4','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10110','REG0450','342','2','147','0','0','COD_INF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10110','REG0450','343','3','148','0','0','TXT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10111','REG0460','345','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10111','REG0460','348','4','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10111','REG0460','347','3','148','0','0','TXT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10111','REG0460','346','2','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10112','REG0500','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10112','REG0500','4','4','45','0','0','IND_CTA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10112','REG0500','8','8','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10112','REG0500','2','2','110','0','0','DT_ALT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10112','REG0500','3','3','1100','0','0','COD_NAT_CC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10112','REG0500','5','5','1101','0','0','NIVEL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10112','REG0500','6','6','1102','0','1','COD_CTA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10112','REG0500','7','7','1103','0','0','NOME_CTA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10113','REG0600','3','3','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10113','REG0600','2','2','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10113','REG0600','1','1','1112','0','1','IDREG0600','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10113','REG0600','6','6','1140','0','0','CCUS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10113','REG0600','5','5','1140','0','0','COD_CCUS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10113','REG0600','4','4','1143','0','0','DT_ALT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','102','REG0990','349','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','102','REG0990','350','2','26','0','0','QTD_LIN_0',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','102','REG0990','351','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103','REGC001','495','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103','REGC001','497','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103','REGC001','496','2','116','0','0','IND_MOV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','498','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','501','4','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','527','30','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','502','5','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','505','8','163','0','0','NUM_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','506','9','164','0','0','CHV_NFE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','507','10','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','504','7','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','499','2','196','0','0','IND_OPER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','500','3','197','0','0','IND_EMIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','503','6','198','0','0','COD_SIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','508','11','201','0','0','DT_E_S',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','509','12','202','0','0','VL_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','511','14','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','518','21','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','519','22','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','520','23','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','521','24','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','523','26','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','524','27','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','510','13','225','0','0','IND_PGTO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','512','15','226','0','0','VL_ABAT_NT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','513','16','227','0','0','VL_MERC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','515','18','228','0','0','VL_FRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','516','19','229','0','0','VL_SEG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','517','20','230','0','0','VL_OUT_DA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','522','25','231','0','0','VL_IPI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','525','28','232','0','0','VL_PIS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','526','29','233','0','0','VL_COFINS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','514','17','355','0','0','IND_FRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','1057','30','468','0','1','IDREGC100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10301','REGC100','1045','31','468','0','0','IDREGC100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030101','REGC101','1','1','1','0','0','C01_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030101','REGC101','5','5','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030101','REGC101','4','4','202','0','0','C01_VLICMSUFREM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030101','REGC101','3','3','202','0','0','C01_VLICMSUFDEST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030101','REGC101','2','2','202','0','0','C01_VLFCPUFDEST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030101','REGC101','6','6','468','0','1','IDREGC100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030103','REGC110','528','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030103','REGC110','531','4','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030103','REGC110','529','2','147','0','0','COD_INF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030103','REGC110','530','3','234','0','0','TXT_COMPL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030103','REGC110','1044','5','468','0','1','IDREGC110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010301','REGC111','532','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010301','REGC111','535','4','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010301','REGC111','534','3','235','0','0','IND_PROC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010301','REGC111','533','2','236','0','0','NUM_PROC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010301','REGC111','1045','5','469','0','1','IDREGC110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010302','REGC112','536','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010302','REGC112','538','3','7','0','0','UF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010302','REGC112','544','9','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010302','REGC112','541','6','207','0','0','VL_DA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010302','REGC112','537','2','237','0','0','COD_DA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010302','REGC112','539','4','238','0','0','NUM_DA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010302','REGC112','540','5','239','0','0','COD_AUT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010302','REGC112','542','7','240','0','0','DT_VCTO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010302','REGC112','543','8','241','0','0','DT_PGTO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010302','REGC112','1046','10','469','0','1','IDREGC110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','4','4','17','0','0','COD_PART','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','10','11','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','5','5','161','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','8','8','163','0','0','NUM_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','9','9','165','0','0','DT_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','6','6','166','0','0','SER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','2','2','196','0','0','IND_OPER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','3','3','197','0','0','IND_EMIT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','7','7','199','0','0','SUB','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','11','12','469','0','1','IDREGC110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010303','REGC113','12','10','1133','0','0','RC113_NMCHAVEDOCE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010304','REGC114','555','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010304','REGC114','561','7','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010304','REGC114','556','2','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010304','REGC114','559','5','163','0','0','NUM_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010304','REGC114','560','6','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010304','REGC114','557','3','242','0','0','ECF_FAB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010304','REGC114','558','4','243','0','0','ECF_CX',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010304','REGC114','1048','8','469','0','1','IDREGC110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','562','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','572','11','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','563','2','244','0','0','IND_CARGA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','564','3','245','0','0','CNPJ_COL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','565','4','246','0','0','IE_COL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','566','5','247','0','0','CPF_COL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','567','6','248','0','0','COD_MUN_COL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','568','7','249','0','0','CNPJ_ENTG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','569','8','250','0','0','IE_ENTG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','570','9','251','0','0','CPF_ENTG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','571','10','252','0','0','COD_MUN_ENTG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010305','REGC115','1049','12','469','0','1','IDREGC110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010306','REGC116','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010306','REGC116','7','7','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010306','REGC116','2','2','161','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010306','REGC116','9','9','469','0','1','IDREG116','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010306','REGC116','8','8','469','0','0','IDREG110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010306','REGC116','3','3','1145','0','0','NR_SAT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010306','REGC116','4','4','1146','0','0','CHV_CFE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010306','REGC116','5','5','1147','0','0','NUM_CFE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010306','REGC116','6','6','1148','0','0','DT_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030104','REGC120','573','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030104','REGC120','574','2','253','0','0','COD_DOC_IMP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030104','REGC120','575','3','254','0','0','NUM_DOC_IMP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030104','REGC120','576','4','255','0','0','PIS_IMP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030104','REGC120','577','5','256','0','0','COFINS_IMP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030104','REGC120','1050','6','468','0','1','IDREGC100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030104','REGC120','1051','7','1051','0','0','NUM_ACDRAW',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030105','REGC130','579','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030105','REGC130','578','6','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030105','REGC130','587','9','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030105','REGC130','580','2','205','0','0','VL_SERV_NT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030105','REGC130','581','3','257','0','0','VL_BC_ISSQN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030105','REGC130','582','4','258','0','0','VL_ISSQN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030105','REGC130','583','5','259','0','0','VL_BC_IRRF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030105','REGC130','584','6','260','0','0','VL_IRRF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030105','REGC130','585','7','261','0','0','VL_BC_PREV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030105','REGC130','586','8','262','0','0','VL_PREV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030105','REGC130','1051','10','468','0','1','IDREGC100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030106','REGC140','588','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030106','REGC140','595','8','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030106','REGC140','589','2','197','0','0','IND_EMIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030106','REGC140','590','3','263','0','0','IND_TIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030106','REGC140','591','4','264','0','0','DESC_TIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030106','REGC140','592','5','265','0','0','NUM_TIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030106','REGC140','593','6','266','0','0','QTD_PARC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030106','REGC140','594','7','267','0','0','VL_TIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030106','REGC140','1052','9','468','0','1','IDREGC140','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010601','REGC141','596','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010601','REGC141','600','5','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010601','REGC141','598','3','240','0','0','DT_VCTO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010601','REGC141','597','2','268','0','0','NUM_PARC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010601','REGC141','599','4','269','0','0','VL_PARC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010601','REGC141','1053','6','470','0','1','IDREGC140','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030107','REGC160','601','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030107','REGC160','602','2','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030107','REGC160','608','8','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030107','REGC160','603','3','270','0','0','VEIC_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030107','REGC160','604','4','271','0','0','QTD_VOL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030107','REGC160','605','5','272','0','0','PESO_BRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030107','REGC160','606','6','273','0','0','PESO_LIQ',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030107','REGC160','607','7','274','0','0','UF_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030107','REGC160','1054','9','468','0','1','IDREGC100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','609','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','610','2','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','620','12','19','0','0','CPF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','622','14','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','612','4','239','0','0','COD_AUT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','611','3','270','0','0','VEIC_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','616','8','271','0','0','QTD_VOL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','617','9','272','0','0','PESO_BRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','618','10','273','0','0','PESO_LIQ',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','621','13','274','0','0','UF_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','613','5','275','0','0','NR_PASSE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','614','6','276','0','0','HORA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','615','7','277','0','0','TEMPER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','619','11','278','0','0','NOM_MOT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030108','REGC165','1055','15','468','0','1','IDREGC100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','623','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','634','12','44','0','0','COD_NAT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','659','37','47','0','0','COD_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','660','38','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','631','9','116','0','0','IND_MOV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','628','6','129','0','0','UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','625','3','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','636','14','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','627','5','168','0','0','QTD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','630','8','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','635','13','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','637','15','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','638','16','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','640','18','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','652','30','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','658','36','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','624','2','214','0','0','NUM_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','629','7','216','0','0','VL_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','632','10','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','633','11','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','639','17','219','0','0','ALIQ_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','646','24','231','0','0','VL_IPI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','626','4','279','0','0','DESCR_COMPL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','641','19','280','0','0','IND_APUR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','643','21','281','0','0','COD_ENQ',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','644','22','282','0','0','VL_BC_IPI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','645','23','283','0','0','ALIQ_IPI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','647','25','284','0','0','CST_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','648','26','285','0','0','VL_BC_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','649','27','286','0','0','ALIQ_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','651','29','286','0','0','ALIQ_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','656','34','287','0','0','QUANT_BC_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','653','31','288','0','0','CST_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','654','32','289','0','0','VL_BC_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','655','33','290','0','0','ALIQ_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','657','35','290','0','0','ALIQ_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','642','20','356','0','0','CST_IPI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','650','28','357','0','0','QUANT_BC_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','1056','38','468','0','1','IDREGC170','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030109','REGC170','1044','9','468','0','0','IDREGC100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010901','REGC171','661','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010901','REGC171','664','4','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010901','REGC171','662','2','187','0','0','NUM_TANQUE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010901','REGC171','663','3','291','0','0','QTDE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010902','REGC172','665','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010902','REGC172','669','5','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010902','REGC172','666','2','257','0','0','VL_BC_ISSQN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010902','REGC172','668','4','258','0','0','VL_ISSQN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010902','REGC172','667','3','358','0','0','ALIQ_ISSQN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010903','REGC173','670','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010903','REGC173','678','9','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010903','REGC173','671','2','293','0','0','LOTE_MED',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010903','REGC173','672','3','294','0','0','QTD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010903','REGC173','673','4','295','0','0','DT_FAB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010903','REGC173','674','5','296','0','0','DT_VAL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010903','REGC173','675','6','297','0','0','IND_MED',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010903','REGC173','676','7','298','0','0','TP_PROD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010903','REGC173','677','8','299','0','0','VL_TAB_MAX',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010904','REGC174','679','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010904','REGC174','683','5','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010904','REGC174','682','4','279','0','0','DESCR_COMPL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010904','REGC174','680','2','359','0','0','IND_ARM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010904','REGC174','681','3','360','0','0','NUM_ARM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010905','REGC175','684','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010905','REGC175','686','3','6','0','0','CNPJ',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010905','REGC175','687','4','7','0','0','UF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010905','REGC175','689','6','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010905','REGC175','685','2','300','0','0','IND_VEIC_OPER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010905','REGC175','688','5','301','0','0','CHASSI_VEIC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','25','25','11','0','0','RC176_TPCODARRECADACAO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','19','19','11','0','0','RC176_TPCODMOTRES','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','18','18','11','0','0','RC176_TPCDRESPRET','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','22','22','28','0','0','RC176_NMSERNFERET','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','26','26','33','0','0','RC176_NMDOCARRECADACAO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','24','24','80','0','0','RC176_NMSEQITEMNFERET','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','11','11','82','0','0','RC176_NMSEQITEMULTENT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','27','27','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','2','2','302','0','0','COD_MOD_ULT_E','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','3','3','303','0','0','NUM_DOC_ULT_E','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','23','23','303','0','0','RC176_NMNFERET','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','4','4','304','0','0','SER_ULT_E','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','5','5','305','0','0','DT_ULT_E','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','6','6','306','0','0','COD_PART_ULT_E','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','7','7','307','0','0','QUANT_ULT_E','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','8','8','308','0','0','VL_UNIT_ULT_E','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','9','9','309','0','0','VL_UNIT_BC_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','21','21','1103','0','0','RC176_CDPARTNFERET','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','13','13','1116','0','0','RC176_ALIQICMSULTENT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','14','14','1116','0','0','RC176_VLUNITLIMITEBCICMSULTENT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','15','15','1116','0','0','RC176_VLUNITICMSULTENT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','12','12','1116','0','0','RC176_VLUNITBCICMSULTENT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','16','16','1116','0','0','RC176_ALIQSTULTENT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','17','17','1116','0','0','RC176_VLUNITRES','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','20','20','1133','0','0','RC176_NMCHAVENFERET','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010906','REGC176','10','10','1133','0','0','RC176_NMCHAVENFEULTENT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010907','REGC177','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010907','REGC177','4','4','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010907','REGC177','2','2','310','0','0','COD_SELO_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010907','REGC177','3','3','311','0','0','QT_SELO_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010908','REGC178','704','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010908','REGC178','708','5','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010908','REGC178','705','2','312','0','0','CL_ENQ',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010908','REGC178','706','3','313','0','0','VL_UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010908','REGC178','707','4','314','0','0','QUANT_PAD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010909','REGC179','709','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010909','REGC179','715','7','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010909','REGC179','710','2','315','0','0','BC_ST_ORIG_DEST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010909','REGC179','711','3','316','0','0','ICMS_ST_REP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010909','REGC179','713','5','317','0','0','BC_RET',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010909','REGC179','714','6','318','0','0','ICMS_RET',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103010909','REGC179','712','4','361','0','0','ICMS_ST_COMPL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','716','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','727','12','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','719','4','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','728','12','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','721','6','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','722','7','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','723','8','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','724','9','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','717','2','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','718','3','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','726','11','231','0','0','VL_IPI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','720','5','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030110','REGC190','725','10','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030111','REGC195','728','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030111','REGC195','731','4','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030111','REGC195','729','2','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030111','REGC195','730','3','234','0','0','TXT_COMPL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030111','REGC195','732','5','468','0','1','IDREGC195','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103011101','REGC197','1224','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103011101','REGC197','1222','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103011101','REGC197','1225','5','322','0','0','COD_AJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103011101','REGC197','1234','9','322','0','0','ALIQ_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103011101','REGC197','1235','10','322','0','0','VL_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103011101','REGC197','1227','6','322','0','0','DESCR_COMPL_AJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103011101','REGC197','1230','7','322','0','0','COD_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103011101','REGC197','1232','8','322','0','0','VL_BC_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103011101','REGC197','1236','11','322','0','0','VL_OUTROS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103011101','REGC197','1218','1','468','0','1','IDREGC197','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103011101','REGC197','1220','2','468','0','1','IDREGC195','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','741','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','751','11','75','0','0','VL_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','752','12','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','742','2','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','747','7','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','743','3','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','744','4','199','0','0','SUB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','748','8','202','0','0','VL_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','749','9','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','750','10','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','745','5','324','0','0','NUM_DOC_INI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10302','REGC300','746','6','325','0','0','NUM_DOC_FIN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030201','REGC310','753','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030201','REGC310','755','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030201','REGC310','754','2','326','0','0','NUM_DOC_CANC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030202','REGC320','756','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030202','REGC320','765','10','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030202','REGC320','759','4','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030202','REGC320','764','9','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030202','REGC320','761','6','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030202','REGC320','762','7','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030202','REGC320','757','2','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030202','REGC320','758','3','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030202','REGC320','760','5','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030202','REGC320','763','8','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103020201','REGC321','767','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103020201','REGC321','777','11','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103020201','REGC321','770','4','129','0','0','UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103020201','REGC321','768','2','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103020201','REGC321','769','3','168','0','0','QTD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103020201','REGC321','772','6','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103020201','REGC321','773','7','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103020201','REGC321','774','8','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103020201','REGC321','775','9','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103020201','REGC321','776','10','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103020201','REGC321','771','5','216','0','0','VL_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','778','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','789','12','47','0','0','COD_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','781','4','163','0','0','NUM_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','782','5','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','779','2','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','785','8','202','0','0','VL_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','786','9','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','787','10','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','788','11','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','784','7','227','0','0','VL_MERC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','780','3','327','0','0','SUB_SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','783','6','328','0','0','CNPJ_CPF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10303','REGC350','791','13','1150','0','1','IDREGC350','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030301','REGC370','791','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030301','REGC370','795','5','129','0','0','UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030301','REGC370','793','3','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030301','REGC370','794','4','168','0','0','QTD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030301','REGC370','797','7','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030301','REGC370','792','2','214','0','0','NUM_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030301','REGC370','796','6','216','0','0','VL_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030301','REGC370','21268','9','1150','0','1','IDREGC350','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030302','REGC390','799','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030302','REGC390','802','4','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030302','REGC390','807','9','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030302','REGC390','804','6','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030302','REGC390','805','7','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030302','REGC390','800','2','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030302','REGC390','801','3','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030302','REGC390','803','5','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030302','REGC390','806','8','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304','REGC400','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304','REGC400','6','6','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304','REGC400','2','2','161','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304','REGC400','4','4','242','0','0','ECF_FAB','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304','REGC400','5','5','243','0','0','ECF_CX','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304','REGC400','3','3','329','0','0','ECF_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304','REGC400','7','7','1104','0','1','IDREGC400','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030401','REGC405','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030401','REGC405','8','8','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030401','REGC405','2','2','165','0','0','DT_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030401','REGC405','3','3','330','0','0','CRO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030401','REGC405','4','4','331','0','0','CRZ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030401','REGC405','5','5','332','0','0','NUM_COO_FIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030401','REGC405','6','6','333','0','0','GT_FIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030401','REGC405','7','7','334','0','0','VL_BRT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030401','REGC405','9','9','1104','0','0','IDREGC400','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030401','REGC405','10','10','1105','0','1','IDREGC405','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040101','REGC410','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040101','REGC410','4','4','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040101','REGC410','2','2','212','0','0','VL_PIS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040101','REGC410','3','3','213','0','0','VL_COFINS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040101','REGC410','5','5','1105','0','0','IDREGC405','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040101','REGC410','6','6','1106','0','1','IDREGC410','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040102','REGC420','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040102','REGC420','6','6','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040102','REGC420','2','2','335','0','0','COD_TOT_PAR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040102','REGC420','3','3','336','0','0','VLR_ACUM_TOT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040102','REGC420','5','5','337','0','0','DESCR_NR_TOT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040102','REGC420','4','4','362','0','0','NR_TOT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040102','REGC420','7','7','1105','0','0','IDREGC405','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040102','REGC420','8','8','1107','0','1','IDREGC420','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010201','REGC425','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010201','REGC425','8','8','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010201','REGC425','4','4','129','0','0','UNID','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010201','REGC425','2','2','131','0','0','COD_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010201','REGC425','3','3','168','0','0','QTD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010201','REGC425','6','6','212','0','0','VL_PIS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010201','REGC425','7','7','213','0','0','VL_COFINS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010201','REGC425','5','5','216','0','0','VL_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010201','REGC425','9','9','1107','0','0','IDREGC420','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010201','REGC425','10','10','1111','0','1','IDREGC425','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','10','10','5','0','0','NOM_ADQ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','9','9','19','0','0','CPF_CNPJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','11','11','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','2','2','161','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','4','4','163','0','0','NUM_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','5','5','165','0','0','DT_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','3','3','198','0','0','COD_SIT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','6','6','202','0','0','VL_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','7','7','212','0','0','VL_PIS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','8','8','213','0','0','VL_COFINS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','12','12','1105','0','0','IDREGC405','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040103','REGC460','13','13','1108','0','1','IDREGC460','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','3','3','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','14','14','322','0','0','VL_COFINS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','5','5','322','0','0','COD_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','6','6','322','0','0','QTD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','11','11','322','0','0','CFOP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','8','8','322','0','0','UNID','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','9','9','322','0','0','VL_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','10','10','322','0','0','CST_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','13','13','322','0','0','VL_PIS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','7','7','322','0','0','QTD_CANC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','12','12','322','0','0','ALIQ_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','2','2','1108','0','0','IDREGC460','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10304010301','REGC470','1','1','1109','0','1','IDREGC470','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040104','REGC490','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040104','REGC490','9','9','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040104','REGC490','4','4','141','0','0','ALIQ_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040104','REGC490','8','8','149','0','0','COD_OBS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040104','REGC490','6','6','208','0','0','VL_BC_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040104','REGC490','7','7','209','0','0','VL_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040104','REGC490','2','2','217','0','0','CST_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040104','REGC490','3','3','218','0','0','CFOP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040104','REGC490','5','5','319','0','0','VL_OPR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040104','REGC490','10','10','1105','0','0','IDREGC405','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103040104','REGC490','11','11','1110','0','1','IDREGC490','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','873','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','888','16','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','878','6','129','0','0','UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','875','3','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','874','2','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','876','4','168','0','0','QTD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','880','8','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','883','11','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','884','12','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','887','15','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','879','7','216','0','0','VL_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','877','5','339','0','0','QTD_CANC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','885','13','340','0','0','VL_ISEN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','886','14','341','0','0','VL_NT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','882','10','342','0','0','VL_ACMO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10305','REGC495','881','9','343','0','0','VL_CANC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','889','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','892','4','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','914','26','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','1251','27','111','0','1','IDREGC500','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','911','23','147','0','0','COD_INF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','893','5','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','898','10','163','0','0','NUM_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','899','11','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','895','7','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','890','2','196','0','0','IND_OPER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','891','3','197','0','0','IND_EMIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','894','6','198','0','0','COD_SIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','896','8','199','0','0','SUB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','897','9','200','0','0','COD_CONS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','900','12','201','0','0','DT_E_S',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','901','13','202','0','0','VL_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','902','14','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','903','15','204','0','0','VL_FORN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','904','16','205','0','0','VL_SERV_NT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','905','17','206','0','0','VL_TERC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','906','18','207','0','0','VL_DA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','907','19','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','908','20','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','909','21','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','910','22','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','912','24','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','913','25','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','1272','28','771','0','0','TP_LIGACAO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10306','REGC500','1273','29','772','0','0','COD_GRUPO_TENSAO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','915','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','932','18','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','935','21','47','0','0','COD_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','936','22','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','920','6','129','0','0','UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','917','3','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','926','12','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','919','5','168','0','0','QTD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','922','8','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','925','11','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','927','13','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','928','14','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','930','16','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','933','19','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','934','20','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','916','2','214','0','0','NUM_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','918','4','215','0','0','COD_CLASS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','921','7','216','0','0','VL_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','923','9','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','924','10','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','929','15','219','0','0','ALIQ_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030601','REGC510','931','17','220','0','0','IND_REC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','941','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','952','12','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','944','4','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','951','11','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','946','6','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','947','7','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','948','8','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','949','9','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','942','2','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','943','3','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','945','5','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030602','REGC590','950','10','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','953','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','955','3','9','0','0','COD_MUN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','975','23','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','954','2','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','961','9','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','956','4','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','957','5','199','0','0','SUB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','958','6','200','0','0','COD_CONS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','962','10','202','0','0','VL_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','963','11','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','965','13','204','0','0','VL_FORN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','966','14','205','0','0','VL_SERV_NT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','967','15','206','0','0','VL_TERC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','968','16','207','0','0','VL_DA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','969','17','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','970','18','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','971','19','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','972','20','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','973','21','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','974','22','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','960','8','339','0','0','QTD_CANC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','964','12','339','0','0','CONS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10307','REGC600','959','7','346','0','0','QTD_CONS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030701','REGC601','976','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030701','REGC601','978','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030701','REGC601','977','2','326','0','0','NUM_DOC_CANC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','979','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','995','17','47','0','0','COD_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','996','18','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','983','5','129','0','0','UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','981','3','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','988','10','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','982','4','168','0','0','QTD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','985','7','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','989','11','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','990','12','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','991','13','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','992','14','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','993','15','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','994','16','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','980','2','215','0','0','COD_CLASS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','984','6','216','0','0','VL_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','986','8','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030702','REGC610','987','9','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1001','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1012','12','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1004','4','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1011','11','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1006','6','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1007','7','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1009','9','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1010','10','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1002','2','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1003','3','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1005','5','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030704','REGC690','1008','8','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10308','REGC700','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10308','REGC700','10','10','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10308','REGC700','2','2','161','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10308','REGC700','3','3','166','0','0','SER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10308','REGC700','4','4','347','0','0','NRO_ORD_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10308','REGC700','5','5','348','0','0','NRO_ORD_FIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10308','REGC700','6','6','349','0','0','DT_DOC_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10308','REGC700','7','7','350','0','0','DT_DOC_FIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10308','REGC700','8','8','351','0','0','NOM_MEST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10308','REGC700','9','9','353','0','0','CHV_COD_DIG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1024','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1035','12','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1027','4','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1034','11','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1029','6','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1030','7','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1031','8','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1032','9','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1025','2','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1026','3','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1028','5','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030801','REGC790','1033','10','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103080101','REGC791','1036','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103080101','REGC791','1037','2','7','0','0','UF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103080101','REGC791','1040','5','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103080101','REGC791','1038','3','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','103080101','REGC791','1039','4','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','18','18','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','2','2','161','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','3','3','198','0','0','COD_SIT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','12','12','203','0','0','VL_DESC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','15','15','209','0','0','VL_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','7','7','212','0','0','VL_PIS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','8','8','213','0','0','VL_COFINS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','6','6','216','0','0','VL_CFE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','13','13','227','0','0','VL_MERC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','14','14','230','0','0','VL_OUT_DA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','16','16','232','0','0','VL_PIS_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','17','17','233','0','0','VL_COFINS_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','9','9','328','0','0','CNPJ_CPF','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','19','19','468','0','1','IDREGC800','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','10','10','1145','0','0','NR_SAT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','11','11','1146','0','0','CHV_CFE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','4','4','1147','0','0','NUM_CFE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10309','REGC800','5','5','1148','0','0','DT_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030901','REGC850','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030901','REGC850','9','9','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030901','REGC850','4','4','141','0','0','ALIQ_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030901','REGC850','8','8','149','0','0','COD_OBS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030901','REGC850','6','6','208','0','0','VL_BC_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030901','REGC850','7','7','209','0','0','VL_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030901','REGC850','2','2','217','0','0','CST_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030901','REGC850','3','3','218','0','0','CFOP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030901','REGC850','5','5','319','0','0','VL_OPR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030901','REGC850','10','10','468','0','0','IDREGC800','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1030901','REGC850','11','11','468','0','1','IDREGC850','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10310','REGC860','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10310','REGC860','7','7','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10310','REGC860','2','2','161','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10310','REGC860','5','5','349','0','0','DOC_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10310','REGC860','6','6','350','0','0','DOC_FIM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10310','REGC860','8','8','468','0','1','IDREGC860','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10310','REGC860','3','3','1145','0','0','NR_SAT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10310','REGC860','4','4','1148','0','0','DT_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1031001','REGC890','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1031001','REGC890','9','9','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1031001','REGC890','4','4','141','0','0','ALIQ_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1031001','REGC890','8','8','149','0','0','COD_OBS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1031001','REGC890','6','6','208','0','0','VL_BC_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1031001','REGC890','7','7','209','0','0','VL_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1031001','REGC890','2','2','217','0','0','CST_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1031001','REGC890','3','3','218','0','0','CFOP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1031001','REGC890','5','5','319','0','0','VL_OPR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1031001','REGC890','10','10','468','0','0','IDREGC860','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1031001','REGC890','11','11','468','0','1','IDREGC890','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','104','REGC990','1041','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','104','REGC990','1043','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','104','REGC990','1042','2','354','0','0','QTD_LIN_C',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105','REGD001','418','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105','REGD001','420','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105','REGD001','419','2','116','0','0','IND_MOV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','421','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','1065','13','12','0','0','TP_CTE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','424','4','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','442','23','47','0','0','COD_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','443','26','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','439','22','147','0','0','COD_INF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','425','5','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','21271','24','163','0','0','RD100_CDMUNORIG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','21272','25','163','0','0','RD100_CDMUNDEST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','429','9','163','0','0','NUM_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','1067','14','164','0','0','CHAVE_CTE_REF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','1064','10','164','0','0','CHAVE_CTE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','430','11','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','427','7','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','422','2','196','0','0','IND_OPER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','423','3','197','0','0','IND_EMIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','426','6','198','0','0','COD_SIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','428','8','199','0','0','SUB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','432','15','202','0','0','VL_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','433','16','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','436','19','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','437','20','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','438','21','341','0','0','VL_NT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','434','17','355','0','0','IND_FRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','431','12','386','0','0','DT_A_P',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','435','18','387','0','0','VL_SERV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10501','REGD100','1216','27','468','0','1','IDREGD100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050101','REGD101','1','1','1','0','0','D01_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050101','REGD101','5','5','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050101','REGD101','3','3','202','0','0','D01_VLICMSUFDEST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050101','REGD101','4','4','202','0','0','D01_VLICMSUFREM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050101','REGD101','2','2','202','0','0','D01_VLFCPUFDEST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050101','REGD101','6','6','468','0','1','IDREGD100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050102','REGD110','444','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050102','REGD110','449','6','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050102','REGD110','446','3','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050102','REGD110','445','2','214','0','0','NUM_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050102','REGD110','447','4','387','0','0','VL_SERV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050102','REGD110','448','5','420','0','0','VL_OUT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050102','REGD110','450','7','468','0','1','IDREGD110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010202','REGD120','450','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010202','REGD120','455','6','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010202','REGD120','453','4','270','0','0','VEIC_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010202','REGD120','454','5','274','0','0','UF_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010202','REGD120','451','2','421','0','0','COD_MUN_ORIG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010202','REGD120','452','3','422','0','0','COD_MUN_DEST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','456','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','470','15','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','468','13','228','0','0','VL_FRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','462','7','270','0','0','VEIC_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','469','14','274','0','0','UF_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','467','12','420','0','0','VL_OUT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','460','5','421','0','0','COD_MUN_ORIG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','461','6','422','0','0','COD_MUN_DEST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','457','2','423','0','0','COD_PART_CONSG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','458','3','424','0','0','COD_PART_RED',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','459','4','425','0','0','IND_FRT_RED',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','463','8','426','0','0','VL_LIQ_FRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','464','9','427','0','0','VL_SEC_CAT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','465','10','428','0','0','VL_DESP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050103','REGD130','466','11','429','0','0','VL_PEDG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','471','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','485','15','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','476','6','270','0','0','VEIC_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','475','5','300','0','0','IND_VEIC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','482','12','420','0','0','VL_OUT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','473','3','421','0','0','COD_MUN_ORIG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','474','4','422','0','0','COD_MUN_DEST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','472','2','423','0','0','COD_PART_CONSG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','477','7','430','0','0','IND_NAV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','478','8','431','0','0','VIAGEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','479','9','432','0','0','VL_FRT_LIQ',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','480','10','433','0','0','VL_DESP_PORT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','481','11','434','0','0','VL_DESP_CAR_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','483','13','435','0','0','VL_FRT_BRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050104','REGD140','484','14','436','0','0','VL_FRT_MM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','486','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','497','12','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','489','4','270','0','0','VEIC_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','495','10','420','0','0','VL_OUT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','487','2','421','0','0','COD_MUN_ORIG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','488','3','422','0','0','COD_MUN_DEST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','490','5','431','0','0','VIAGEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','491','6','437','0','0','IND_TFA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','492','7','438','0','0','VL_PESO_TX',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','493','8','439','0','0','VL_TX_TERR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','494','9','440','0','0','VL_TX_RED',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050105','REGD150','496','11','441','0','0','VL_TX_ADV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050106','REGD160','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050106','REGD160','2','2','1','0','0','DESPACHO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050106','REGD160','9','9','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050106','REGD160','5','5','421','0','0','COD_MUN_ORI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050106','REGD160','8','8','442','0','0','COD_MUN_DEST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050106','REGD160','3','3','442','0','0','CNPJ_CPF_REM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050106','REGD160','4','4','444','0','0','IE_REM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050106','REGD160','6','6','445','0','0','CNPJ_CPF_DEST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050106','REGD160','7','7','447','0','0','IE_EST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050106','REGD160','10','10','468','0','1','IDREGD160','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010601','REGD161','519','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010601','REGD161','527','9','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010601','REGD161','520','2','244','0','0','IND_CARGA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010601','REGD161','521','3','245','0','0','CNPJ_COL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010601','REGD161','522','4','246','0','0','IE_COL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010601','REGD161','523','5','248','0','0','COD_MUN_COL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010601','REGD161','524','6','249','0','0','CNPJ_ENTG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010601','REGD161','525','7','250','0','0','IE_ENTG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010601','REGD161','526','8','252','0','0','COD_MUN_ENTG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010602','REGD162','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010602','REGD162','11','11','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010602','REGD162','2','2','161','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010602','REGD162','4','4','163','0','0','NUM_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010602','REGD162','5','5','165','0','0','DT_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010602','REGD162','3','3','166','0','0','SER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010602','REGD162','6','6','202','0','0','VL_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010602','REGD162','7','7','227','0','0','VL_MERC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010602','REGD162','8','8','271','0','0','QTD_VOL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010602','REGD162','9','9','272','0','0','PESO_BRT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105010602','REGD162','10','10','273','0','0','PESO_LIQ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','528','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','542','15','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','539','12','228','0','0','VL_FRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','540','13','270','0','0','VEIC_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','541','14','274','0','0','UF_ID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','538','11','420','0','0','VL_OUT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','531','4','421','0','0','COD_MUN_ORIG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','532','5','422','0','0','COD_MUN_DEST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','529','2','423','0','0','COD_PART_CONSG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','530','3','424','0','0','COD_PART_RED',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','535','8','426','0','0','VL_LIQ_FRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','533','6','448','0','0','OTM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','534','7','449','0','0','IND_NAT_FRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','536','9','450','0','0','VL_GRIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050107','REGD170','537','10','451','0','0','VL_PDG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','543','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','560','18','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','554','12','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','557','15','163','0','0','NUM_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','558','16','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','555','13','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','545','3','197','0','0','IND_EMIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','556','14','199','0','0','SUB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','559','17','202','0','0','VL_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','549','7','421','0','0','COD_MUN_ORIG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','553','11','422','0','0','COD_MUN_DEST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','544','2','452','0','0','NUM_SEQ',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','546','4','453','0','0','CNPJ_EMIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','547','5','454','0','0','UF_EMIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','548','6','455','0','0','IE_EMIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','550','8','456','0','0','CNPJ_CPF_TOM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','551','9','457','0','0','UF_TOM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050108','REGD180','552','10','458','0','0','IE_TOM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050109','REGD190','561','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050109','REGD190','570','10','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050109','REGD190','564','4','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050109','REGD190','569','9','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050109','REGD190','566','6','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050109','REGD190','567','7','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050109','REGD190','562','2','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050109','REGD190','563','3','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050109','REGD190','565','5','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050109','REGD190','568','8','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050110','REGD195','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050110','REGD195','4','4','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050110','REGD195','2','2','149','0','0','COD_OBS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050110','REGD195','3','3','234','0','0','TXT_COMPL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050110','REGD195','5','5','468','0','1','IDREGD195','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105011001','REGD197','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105011001','REGD197','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105011001','REGD197','5','5','322','0','0','COD_AJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105011001','REGD197','6','6','322','0','0','DESCR_COMPL_AJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105011001','REGD197','7','7','322','0','0','COD_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105011001','REGD197','9','9','322','0','0','ALIQ_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105011001','REGD197','11','11','322','0','0','VL_OUTROS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105011001','REGD197','10','10','322','0','0','VL_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105011001','REGD197','8','8','322','0','0','VL_BC_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105011001','REGD197','1','1','468','0','1','IDREGD197','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105011001','REGD197','2','2','468','0','1','NRREGD195','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','571','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','590','20','47','0','0','COD_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','591','21','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','21','21','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','579','9','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','589','19','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','572','2','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','580','10','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','573','3','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','574','4','199','0','0','SUB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','582','12','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','586','16','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','587','17','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','577','7','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','578','8','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','584','14','229','0','0','VL_SEG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','581','11','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','588','18','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','575','5','324','0','0','NUM_DOC_INI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','576','6','325','0','0','NUM_DOC_FIN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','583','13','387','0','0','VL_SERV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','585','15','459','0','0','VL_OUT_DESP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10502','REGD300','22','22','468','0','1','IDREGD300','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050201','REGD301','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050201','REGD301','3','3','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050201','REGD301','2','2','326','0','0','NUM_DOC_CANC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050201','REGD301','4','4','468','0','1','IDREGD300','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050201','REGD301','5','5','468','0','1','IDREGD300','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050202','REGD310','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050202','REGD310','6','6','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050202','REGD310','4','4','208','0','0','VL_BC_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050202','REGD310','5','5','209','0','0','VL_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050202','REGD310','3','3','387','0','0','VL_SERV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050202','REGD310','2','2','421','0','0','COD_MUN_ORIG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050202','REGD310','8','8','468','0','1','IDREGD300','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050202','REGD310','7','7','468','0','1','IDREGD300','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10503','REGD350','601','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10503','REGD350','606','6','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10503','REGD350','602','2','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10503','REGD350','604','4','242','0','0','ECF_FAB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10503','REGD350','605','5','243','0','0','ECF_CX',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10503','REGD350','603','3','329','0','0','ECF_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050301','REGD355','607','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050301','REGD355','614','8','108','0','1','SMECODIGO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050301','REGD355','608','2','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050301','REGD355','609','3','330','0','0','CRO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050301','REGD355','610','4','331','0','0','CRZ',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050301','REGD355','611','5','332','0','0','NUM_COO_FIN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050301','REGD355','612','6','333','0','0','GT_FIN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050301','REGD355','613','7','334','0','0','VL_BRT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030101','REGD360','615','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030101','REGD360','618','4','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030101','REGD360','616','2','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030101','REGD360','617','3','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030102','REGD365','619','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030102','REGD365','624','6','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030102','REGD365','620','2','335','0','0','COD_TOT_PAR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030102','REGD365','621','3','336','0','0','VLR_ACUM_TOT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030102','REGD365','623','5','337','0','0','DESCR_NR_TOT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030102','REGD365','622','4','362','0','0','NR_TOT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','632','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','643','12','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','635','4','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','642','11','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','640','9','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','641','10','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','633','2','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','634','3','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','637','6','257','0','0','VL_BC_ISSQN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','639','8','258','0','0','VL_ISSQN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','636','5','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105030103','REGD390','638','7','358','0','0','ALIQ_ISSQN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','644','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','645','2','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','659','16','47','0','0','COD_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','660','17','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','646','3','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','650','7','163','0','0','NUM_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','651','8','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','648','5','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','647','4','198','0','0','COD_SIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','649','6','199','0','0','SUB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','652','9','202','0','0','VL_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','653','10','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','655','12','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','656','13','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','657','14','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','658','15','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10504','REGD400','654','11','387','0','0','VL_SERV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','661','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','676','16','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','670','10','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','662','2','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','667','7','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','663','3','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','664','4','199','0','0','SUB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','672','12','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','674','14','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','675','15','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','668','8','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','669','9','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','671','11','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','665','5','324','0','0','NUM_DOC_INI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','666','6','325','0','0','NUM_DOC_FIN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050401','REGD410','673','13','387','0','0','VL_SERV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105040101','REGD411','677','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105040101','REGD411','679','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105040101','REGD411','678','2','326','0','0','NUM_DOC_CANC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050402','REGD420','680','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050402','REGD420','685','6','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050402','REGD420','683','4','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050402','REGD420','684','5','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050402','REGD420','682','3','387','0','0','VL_SERV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050402','REGD420','681','2','421','0','0','COD_MUN_ORIG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','686','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','689','4','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','708','23','47','0','0','COD_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','709','24','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','1250','25','111','0','1','IDREGD500','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','705','20','147','0','0','COD_INF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','690','5','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','694','9','163','0','0','NUM_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','695','10','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','692','7','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','687','2','196','0','0','IND_OPER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','688','3','197','0','0','IND_EMIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','691','6','198','0','0','COD_SIT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','693','8','199','0','0','SUB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','697','12','202','0','0','VL_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','698','13','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','700','15','205','0','0','VL_SERV_NT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','701','16','206','0','0','VL_TERC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','702','17','207','0','0','VL_DA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','703','18','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','704','19','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','706','21','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','707','22','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','696','11','386','0','0','DT_A_P',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','699','14','387','0','0','VL_SERV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10505','REGD500','1274','26','773','0','0','TP_ASSINANTE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','710','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','726','17','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','729','20','47','0','0','COD_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','730','21','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','715','6','129','0','0','UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','712','3','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','721','12','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','714','5','168','0','0','QTD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','717','8','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','720','11','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','722','13','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','723','14','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','724','15','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','727','18','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','728','19','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','711','2','214','0','0','NUM_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','713','4','215','0','0','COD_CLASS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','716','7','216','0','0','VL_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','718','9','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','719','10','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050501','REGD510','725','16','220','0','0','IND_REC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050503','REGD530','735','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050503','REGD530','742','8','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050503','REGD530','736','2','461','0','0','IND_SERV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050503','REGD530','737','3','462','0','0','DT_INI_SERV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050503','REGD530','738','4','463','0','0','DT_FIN_SERV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050503','REGD530','739','5','464','0','0','PER_FISCAL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050503','REGD530','740','6','465','0','0','COD_AREA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050503','REGD530','741','7','466','0','0','TERMINAL',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','743','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','754','12','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','746','4','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','753','11','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','748','6','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','749','7','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','750','8','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','751','9','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','744','2','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','745','3','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','747','5','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050504','REGD590','752','10','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','755','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','757','3','9','0','0','COD_MUN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','773','19','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','756','2','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','762','8','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','758','4','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','759','5','199','0','0','SUB',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','760','6','200','0','0','COD_CONS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','763','9','202','0','0','VL_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','764','10','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','766','12','205','0','0','VL_SERV_NT',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','767','13','206','0','0','VL_TERC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','768','14','207','0','0','VL_DA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','769','15','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','770','16','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','771','17','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','772','18','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','761','7','346','0','0','QTD_CONS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10506','REGD600','765','11','387','0','0','VL_SERV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','774','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','791','18','47','0','0','COD_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','792','19','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','778','5','129','0','0','UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','776','3','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','783','10','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','777','4','168','0','0','QTD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','780','7','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','784','11','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','785','12','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','786','13','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','787','14','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','789','16','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','790','17','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','775','2','215','0','0','COD_CLASS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','779','6','216','0','0','VL_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','781','8','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','782','9','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050601','REGD610','788','15','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','797','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','808','12','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','800','4','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','807','11','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','802','6','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','803','7','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','804','8','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','805','9','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','798','2','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','799','3','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','801','5','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050603','REGD690','806','10','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10507','REGD695','809','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10507','REGD695','818','10','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10507','REGD695','810','2','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10507','REGD695','811','3','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10507','REGD695','812','4','347','0','0','NRO_ORD_INI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10507','REGD695','813','5','348','0','0','NRO_ORD_FIN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10507','REGD695','814','6','349','0','0','DT_DOC_INI',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10507','REGD695','815','7','350','0','0','DT_DOC_FIN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10507','REGD695','816','8','351','0','0','NOM_MEST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10507','REGD695','817','9','353','0','0','CHV_COD_DIG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','819','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','830','12','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','822','4','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','829','11','149','0','0','COD_OBS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','824','6','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','825','7','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','826','8','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','827','9','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','820','2','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','821','3','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','823','5','319','0','0','VL_OPR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1050701','REGD696','828','10','320','0','0','VL_RED_BC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105070101','REGD697','831','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105070101','REGD697','832','2','7','0','0','UF',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105070101','REGD697','835','5','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105070101','REGD697','833','3','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','105070101','REGD697','834','4','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','106','REGD990','1067','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','106','REGD990','1069','3','24','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','106','REGD990','1068','2','221','0','0','QTD_LIN_D',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107','REGE001','270','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107','REGE001','272','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107','REGE001','271','2','116','0','0','IND_MOV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701','REGE100','1119','3','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701','REGE100','1098','2','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701','REGE100','1142','5','322','0','0','DT_FIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701','REGE100','1128','4','322','0','0','DT_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701','REGE100','1094','1','468','0','1','IDREGE100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1136','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1121','3','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1215','18','322','0','0','DEB_ESP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1193','10','322','0','0','VL_AJ_CREDITOS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1198','11','322','0','0','VL_TOT_AJ_CREDITOS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1150','5','322','0','0','VL_TOT_DEBITOS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1172','7','322','0','0','VL_TOT_AJ_DEBITOS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1162','6','322','0','0','VL_AJ_DEBITOS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1179','8','322','0','0','VL_ESTORNOS_CRED','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1213','17','322','0','0','VL_SLD_CREDOR_TRANSPORTAR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1202','12','322','0','0','VL_ESTORNOS_DEB','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1186','9','322','0','0','VL_TOT_CREDITOS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1205','13','322','0','0','VL_SLD_CREDOR_ANT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1207','14','322','0','0','VL_SLD_APURADO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1209','15','322','0','0','VL_TOT_DED','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1211','16','322','0','0','VL_ICMS_RECOLHER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1104','2','468','0','0','IDREGE100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070101','REGE110','1092','1','468','0','1','IDREGE110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010101','REGE111','1133','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010101','REGE111','1111','3','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010101','REGE111','1169','7','322','0','0','VL_AJ_APUR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010101','REGE111','1159','6','322','0','0','DESCR_COMPL_AJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010101','REGE111','1147','5','322','0','0','COD_AJ_APUR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010101','REGE111','1107','2','468','0','0','IDREGE110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010101','REGE111','1093','1','468','0','1','IDREGE111','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010101','REGE112','1223','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010101','REGE112','1221','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010101','REGE112','1229','7','322','0','0','IND_PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010101','REGE112','1226','5','322','0','0','NUM_DA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010101','REGE112','1228','6','322','0','0','NUM_PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010101','REGE112','1233','9','322','0','0','COD_OBS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010101','REGE112','1231','8','322','0','0','PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010101','REGE112','1219','2','468','0','0','IDREGE111','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010101','REGE112','1217','1','468','0','0','IDREGE112','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','10','10','322','0','0','DT_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','7','7','322','0','0','SER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','8','8','322','0','0','SUB','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','5','5','322','0','0','COD_PART','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','11','11','322','0','0','COD_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','9','9','322','0','0','NUM_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','6','6','322','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','12','12','322','0','0','VL_AJ_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','1','1','468','0','0','IDREGE113','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','2','2','468','0','0','IDREGE111','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10701010102','REGE113','13','13','1133','0','0','RE113_NMCHAVEDOCE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010102','REGE115','1130','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010102','REGE115','1116','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010102','REGE115','1156','6','322','0','0','VL_INF_ADIC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010102','REGE115','1166','7','322','0','0','DESCR_COMPL_AJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010102','REGE115','1144','5','322','0','0','COD_INF_ADIC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010102','REGE115','1096','2','468','0','0','IDREGE110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010102','REGE115','1083','1','468','0','0','IDREGE115','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1073','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1072','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1074','5','322','0','0','COD_OR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1075','6','322','0','0','VL_OR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1076','7','322','0','0','DT_VCTO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1081','12','322','0','0','TXT_COMPL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1080','11','322','0','0','PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1079','10','322','0','0','IND_PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1082','13','322','0','0','MES_REF','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1078','9','322','0','0','NUM_PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1077','8','322','0','0','COD_REC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1070','1','468','0','1','IDREGE116','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107010103','REGE116','1071','2','468','0','0','IDREGE110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702','REGE200','1123','3','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702','REGE200','1099','2','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702','REGE200','1141','5','322','0','0','DT_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702','REGE200','1127','4','322','0','0','UF','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702','REGE200','1154','6','322','0','0','DT_FIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702','REGE200','1091','1','468','0','1','IDREGE200','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1134','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1114','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1184','9','322','0','0','VL_OUT_CRED_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1177','8','322','0','0','VL_RESSARC_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1170','7','322','0','0','VL_DEVOL_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1160','6','322','0','0','VL_SLD_CRED_ANT_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1204','13','322','0','0','VL_AJ_DEBITOS_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1148','5','322','0','0','IND_MOV_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1210','16','322','0','0','VL_ICMS_RECOL_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1208','15','322','0','0','VL_DEDUCOES_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1206','14','322','0','0','VL_SLD_DEV_ANT_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1212','17','322','0','0','VL_SLD_CRED_ST_TRANSPORTAR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1214','18','322','0','0','DEB_ESP_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1201','12','322','0','0','VL_OUT_DEB_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1196','11','322','0','0','VL_RETENCAO_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1191','10','322','0','0','VL_AJ_CREDITOS_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1090','1','468','0','1','IDREGE210','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070201','REGE210','1106','2','468','0','0','IDREGE200','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020101','REGE220','1131','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020101','REGE220','1120','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020101','REGE220','1157','6','322','0','0','DESCR_COMPL_AJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020101','REGE220','1167','7','322','0','0','VL_AJ_APUR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020101','REGE220','1145','5','322','0','0','COD_AJ_APUR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020101','REGE220','1109','2','468','0','0','IDREGE210','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020101','REGE220','1084','1','468','0','1','IDREGE220','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010101','REGE230','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010101','REGE230','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010101','REGE230','7','7','322','0','0','IND_PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010101','REGE230','9','9','322','0','0','TXT_COMPL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010101','REGE230','5','5','322','0','0','NUM_DA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010101','REGE230','6','6','322','0','0','NUM_PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010101','REGE230','8','8','322','0','0','PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010101','REGE230','1','1','468','0','1','IDREGE230','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010101','REGE230','2','2','468','0','0','IDREGE220','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','12','12','322','0','0','VL_AJ_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','11','11','322','0','0','COD_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','5','5','322','0','0','COD_PART','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','6','6','322','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','7','7','322','0','0','SER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','8','8','322','0','0','SUB','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','9','9','322','0','0','NUM_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','10','10','322','0','0','DT_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','2','2','468','0','0','IDREGE220','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','1','1','468','0','1','IDREGE240','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10702010102','REGE240','13','13','1133','0','0','RE240_NMCHAVEDOCE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1126','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1112','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1175','8','322','0','0','COD_REC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1195','11','322','0','0','PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1165','7','322','0','0','DT_VCTO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1189','10','322','0','0','IND_PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1200','12','322','0','0','TXT_COMPL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1153','6','322','0','0','VL_OR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1140','5','322','0','0','COD_OR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1182','9','322','0','0','NUM_PROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1201','13','322','0','0','MES_REF','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1095','1','468','0','1','IDREGE250','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107020102','REGE250','1100','2','468','0','0','IDREGE210','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703','REGE300','3','3','1','0','0','E00_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703','REGE300','2','2','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703','REGE300','6','6','322','0','0','E00_DTFINAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703','REGE300','4','4','322','0','0','E00_CDUF','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703','REGE300','5','5','322','0','0','E00_DTINICIO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703','REGE300','1','1','468','0','1','E00_IDREGE300','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','4','4','1','0','0','E01_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','19','19','322','0','0','E01_VLTOTCREDFCP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','20','20','322','0','0','E01_VLOUTCREDFCP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','17','17','322','0','0','E01_VLTOTDEBFCP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','16','16','322','0','0','E01_VLSLDCREDANTFCP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','15','15','322','0','0','E01_DEBESPDIFAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','14','14','322','0','0','E01_VLSLDCREDTRANSPORTAR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','13','13','322','0','0','E01_VLRECOL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','12','12','322','0','0','E01_VLDEDUCOESDIFAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','11','11','322','0','0','E01_VLSLDDEVANTDIFAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','10','10','322','0','0','E01_VLOUTCREDDIFAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','9','9','322','0','0','E01_VLTOTCREDITOSDIFAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','8','8','322','0','0','E01_VLOUTDEBDIFAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','7','7','322','0','0','E01_VLTOTDEBITOSDIFAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','6','6','322','0','0','E01_VLSLDCREDANTDIFAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','5','5','322','0','0','E01_TPMOVDIFAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','18','18','322','0','0','E01_VLOUTDEBFCP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','25','25','322','0','0','E01_DEBESPFCP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','24','24','322','0','0','E01_VLSLDCREDTRANSPFCP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','22','22','322','0','0','E01_VLDEDUCOESFCP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','23','23','322','0','0','E01_VLRECOLFCP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','21','21','322','0','0','E01_VLSLDDEVANTFCP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','1','1','468','0','1','E01_IDREGE310','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070301','REGE310','2','2','468','0','0','E00_IDREGE300','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030101','REGE311','4','4','1','0','0','E02_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030101','REGE311','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030101','REGE311','7','7','322','0','0','E02_VLAJAPUR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030101','REGE311','6','6','322','0','0','E02_DESCRCOMPLAJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030101','REGE311','5','5','322','0','0','E02_CODAJAPUR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030101','REGE311','2','2','468','0','0','E01_IDREGE310','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030101','REGE311','1','1','468','0','1','E02_IDREGE311','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010101','REGE312','4','4','1','0','0','E03_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010101','REGE312','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010101','REGE312','8','8','322','0','0','E03_DESCPROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010101','REGE312','7','7','322','0','0','E03_TPINDPROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010101','REGE312','6','6','322','0','0','E03_NMPROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010101','REGE312','9','9','322','0','0','E03_DESCCOMPL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010101','REGE312','5','5','322','0','0','E03_NMDOCARREC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010101','REGE312','2','2','468','0','0','E02_IDREGE311','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010101','REGE312','1','1','468','0','1','E03_IDREGE312','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','4','4','1','0','0','E04_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','5','5','322','0','0','E04_CDPARTICIPANTE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','13','13','322','0','0','E04_VLAJITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','9','9','322','0','0','E04_NMDOCFIS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','11','11','322','0','0','E04_DTDOCFIS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','7','7','322','0','0','E04_NMSERIE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','8','8','322','0','0','E04_NMSUBSERIE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','10','10','322','0','0','E04_NMCHAVEDOCFIS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','6','6','322','0','0','E04_CDMODDOCFIS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','12','12','322','0','0','E04_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','1','1','468','0','1','E04_IDREGE313','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10703010102','REGE313','2','2','468','0','0','E02_IDREGE311','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','4','4','1','0','0','E05_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','7','7','322','0','0','E05_DTVENC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','12','12','322','0','0','E05_TXTCOMPL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','8','8','322','0','0','E05_CDRECEITA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','9','9','322','0','0','E05_NMPROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','10','10','322','0','0','E05_TPINDPROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','11','11','322','0','0','E05_DESCPROC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','13','13','322','0','0','E05_ANOMESREF','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','5','5','322','0','0','E05_CDOBRIGREC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','6','6','322','0','0','E05_VLOBRIGREC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','1','1','468','0','1','E05_IDREGE316','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107030102','REGE316','2','2','468','0','0','E01_IDREGE310','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704','REGE500','1122','3','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704','REGE500','1097','2','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704','REGE500','1155','6','322','0','0','DT_FIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704','REGE500','1129','4','322','0','0','IND_APUR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704','REGE500','1143','5','322','0','0','DT_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704','REGE500','1086','1','468','0','1','IDREGE500','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070401','REGE510','1137','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070401','REGE510','1113','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070401','REGE510','1180','8','322','0','0','VL_BC_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070401','REGE510','1173','7','322','0','0','VL_CONT_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070401','REGE510','1163','6','322','0','0','CST_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070401','REGE510','1151','5','322','0','0','CFOP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070401','REGE510','1187','9','322','0','0','VL_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070401','REGE510','1089','1','468','0','1','IDREGE510','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070401','REGE510','1103','2','468','0','0','IDREGE500','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070402','REGE520','1135','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070402','REGE520','1118','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070402','REGE520','1161','6','322','0','0','VL_DEB_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070402','REGE520','1171','7','322','0','0','VL_CRED_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070402','REGE520','1178','8','322','0','0','VL_OD_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070402','REGE520','1185','9','322','0','0','VL_OC_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070402','REGE520','1192','10','322','0','0','VL_SC_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070402','REGE520','1197','11','322','0','0','VL_SD_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070402','REGE520','1149','5','322','0','0','VL_SD_ANT_IPI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070402','REGE520','1105','2','468','0','0','IDREGE500','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1070402','REGE520','1082','1','468','0','1','IDREGE520','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107040201','REGE530','1132','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107040201','REGE530','1117','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107040201','REGE530','1158','6','322','0','0','VL_AJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107040201','REGE530','1183','9','322','0','0','NUM_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107040201','REGE530','1176','8','322','0','0','IND_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107040201','REGE530','1168','7','322','0','0','COD_AJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107040201','REGE530','1190','10','322','0','0','DESCR_AJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107040201','REGE530','1146','5','322','0','0','IND_AJ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107040201','REGE530','1108','2','468','0','0','IDREGE520','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','107040201','REGE530','1087','1','468','0','1','IDREGE530','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','4','4','1','0','0','E31_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','5','5','17','0','0','E31_CDPART','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','11','11','131','0','0','E31_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','6','6','161','0','0','E31_CDMOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','9','9','163','0','0','E31_NRDOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','10','10','165','0','0','E31_DTDOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','7','7','166','0','0','E31_NRSER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','8','8','199','0','0','E31_NRSUBSER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','12','12','380','0','0','E31_VLAJUITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','2','2','468','0','0','IDREGE530','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','1','1','468','0','1','E31_IDREGE531','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10704020101','REGE531','13','13','1133','0','0','E31_NRCHVNFE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','108','REGE990','415','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','108','REGE990','417','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','108','REGE990','416','2','414','0','0','QTD_LIN_E',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109','REGG001','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109','REGG001','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109','REGG001','2','2','116','0','0','IND_MOV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','3','3','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','4','4','3','0','0','DT_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','5','5','4','0','0','DT_FIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','2','2','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','1','1','1112','0','1','IDREGG110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','6','6','1113','0','0','SALDO_IN_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','7','7','1114','0','0','SOM_PARC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','8','8','1115','0','0','VL_TRIB_EXP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','9','9','1116','0','0','VL_TOTAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','10','10','1117','0','0','IND_PER_SAI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','11','11','1118','0','0','ICMS_APROP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901','REGG110','12','12','1119','0','0','SOM_ICMS_OC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','3','3','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','12','12','268','0','0','NUM_PARC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','2','2','1112','0','0','IDREGG110','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','1','1','1120','0','1','IDREGG125','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','5','5','1121','0','0','COD_IND_BEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','6','6','1122','0','0','DT_MOV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','7','7','1123','0','0','TIPO_MOV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','8','8','1124','0','0','VL_IMOB_ICMS_OP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','9','9','1125','0','0','VL_IMOB_ICMS_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','10','10','1126','0','0','VL_IMOB_ICMS_FRT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','11','11','1127','0','0','VL_IMOB_ICMS_DIF','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1090101','REGG125','13','13','1128','0','0','VL_PARC_PASS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','5','5','3','0','0','DT_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','6','6','4','0','0','DT_FIM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','3','3','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','7','7','268','0','0','NUM_PARC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','10','10','1116','0','0','VL_TOTAL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','11','11','1117','0','0','IND_PER_SAI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','2','2','1120','0','0','IDREGG125','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','8','8','1128','0','0','VL_PARC_PASS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','1','1','1129','0','1','IDREGG126','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','9','9','1130','0','0','VL_TRIB_OC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010101','REGG126','12','12','1131','0','0','VL_PARC_APROP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010102','REGG130','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010102','REGG130','6','6','17','0','0','COD_PART','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010102','REGG130','3','3','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010102','REGG130','7','7','161','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010102','REGG130','8','8','162','0','0','SERIE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010102','REGG130','9','9','163','0','0','NUM_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010102','REGG130','11','11','165','0','0','DT_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010102','REGG130','5','5','197','0','0','IND_EMIT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010102','REGG130','2','2','1120','0','0','IDREGG125','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010102','REGG130','1','1','1132','0','1','IDREGG130','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','109010102','REGG130','10','10','1133','0','0','CHV_NFE_CTE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901010201','REGG140','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901010201','REGG140','3','3','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901010201','REGG140','6','6','131','0','0','COD_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901010201','REGG140','5','5','214','0','0','NUM_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901010201','REGG140','2','2','1132','0','0','IDREGG130','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','10901010201','REGG140','1','1','1134','0','1','IDREGG140','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','110','REGG990','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','110','REGG990','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','110','REGG990','2','2','1135','0','0','QTD_LIN_G','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','111','REGH001','418','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','111','REGH001','420','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','111','REGH001','419','2','116','0','0','IND_MOV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11101','REGH005','3','3','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11101','REGH005','6','6','7','0','0','MOT_INV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11101','REGH005','2','2','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11101','REGH005','4','4','322','0','0','DT_INV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11101','REGH005','5','5','322','0','0','VL_INV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11101','REGH005','1','1','468','0','1','IDREGH005','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','8','8','322','0','0','VL_UNIT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','9','9','322','0','0','VL_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','10','10','322','0','0','IND_PROP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','11','11','322','0','0','COD_PART','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','12','12','322','0','0','TXT_COMPL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','13','13','322','0','0','COD_CTA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','6','6','322','0','0','UNID','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','14','14','322','0','0','RH010_VLITEMIR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','5','5','322','0','0','COD_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','7','7','322','0','0','QTD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','1','1','468','0','1','IDREGH010','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1110101','REGH010','2','2','468','0','0','IDREGH005','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','111010101','REGH020','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','111010101','REGH020','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','111010101','REGH020','7','7','322','0','0','VL_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','111010101','REGH020','5','5','322','0','0','CST_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','111010101','REGH020','6','6','322','0','0','BC_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','111010101','REGH020','2','2','468','0','0','IDREGH010','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','111010101','REGH020','1','1','468','0','1','IDREGH020','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','112','REGH990','437','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','112','REGH990','439','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','112','REGH990','438','2','419','0','0','QTD_LIN_H',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113','REGK001','1','1','1','0','0','K00_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113','REGK001','3','3','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113','REGK001','2','2','1136','0','0','K00_TPINDMOV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11301','REGK100','1','1','1','0','0','K01_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11301','REGK100','5','5','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11301','REGK100','4','4','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11301','REGK100','2','2','1122','0','0','K01_DTINI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11301','REGK100','3','3','1122','0','0','K01_DTFIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130101','REGK200','1','1','1','0','0','K02_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130101','REGK200','3','3','17','0','0','K02_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130101','REGK200','6','6','17','0','0','K02_CDPARTICIPANTE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130101','REGK200','8','8','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130101','REGK200','7','7','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130101','REGK200','4','4','268','0','0','K02_QTESTOQUE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130101','REGK200','2','2','1122','0','0','K02_DTEST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130101','REGK200','5','5','1136','0','0','K02_TPINDEST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130102','REGK210','1','1','1','0','0','K10_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130102','REGK210','4','4','17','0','0','K10_CDDOCOS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130102','REGK210','5','5','17','0','0','K10_CDITEMORI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130102','REGK210','8','8','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130102','REGK210','9','9','167','0','1','K10_IDREGK210','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130102','REGK210','6','6','268','0','0','K10_QTORI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130102','REGK210','7','7','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130102','REGK210','2','2','1122','0','0','K10_DTINIOS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130102','REGK210','3','3','1122','0','0','K10_DTFINOS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010201','REGK215','1','1','1','0','0','K11_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010201','REGK215','2','2','17','0','0','K11_CDITEMDESTINO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010201','REGK215','5','5','167','0','1','K10_IDREGK210','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010201','REGK215','6','6','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010201','REGK215','3','3','268','0','0','K11_QTDESTINO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010201','REGK215','4','4','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130103','REGK220','1','1','1','0','0','K03_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130103','REGK220','4','4','17','0','0','K03_CDITEMDEST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130103','REGK220','3','3','17','0','0','K03_CDITEMORI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130103','REGK220','8','8','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130103','REGK220','6','6','268','0','0','K03_QTDESTINO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130103','REGK220','5','5','268','0','0','K03_QTMOVIMENTADA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130103','REGK220','7','7','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130103','REGK220','2','2','1122','0','0','K03_DTMOV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130104','REGK230','1','1','1','0','0','K04_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130104','REGK230','5','5','17','0','0','K04_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130104','REGK230','4','4','127','0','0','K04_CDDOCOP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130104','REGK230','9','9','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130104','REGK230','8','8','167','0','1','K04_IDREGK230','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130104','REGK230','7','7','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130104','REGK230','6','6','268','0','0','K04_QTENC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130104','REGK230','3','3','1122','0','0','K04_DTFINOP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130104','REGK230','2','2','1122','0','0','K04_DTINIOP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010401','REGK235','1','1','1','0','0','K05_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010401','REGK235','5','5','17','0','0','K05_CDINSSUBST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010401','REGK235','3','3','17','0','0','K05_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010401','REGK235','8','8','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010401','REGK235','7','7','167','0','1','K04_IDREGK230','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010401','REGK235','4','4','268','0','0','K05_QTCONSUMO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010401','REGK235','6','6','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010401','REGK235','2','2','1122','0','0','K05_DTSAIDA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130105','REGK250','1','1','1','0','0','K06_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130105','REGK250','3','3','17','0','0','K06_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130105','REGK250','6','6','167','0','1','K06_IDREGK250','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130105','REGK250','7','7','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130105','REGK250','4','4','268','0','0','K06_QTPRODUZIDA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130105','REGK250','5','5','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130105','REGK250','2','2','1122','0','0','K06_DTPROD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010501','REGK255','1','1','1','0','0','K07_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010501','REGK255','3','3','17','0','0','K07_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010501','REGK255','5','5','17','0','0','K07_CDINSSUBST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010501','REGK255','7','7','167','0','1','K06_IDREGK250','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010501','REGK255','8','8','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010501','REGK255','9','9','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010501','REGK255','4','4','268','0','0','K07_QTCONSUMO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010501','REGK255','6','6','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010501','REGK255','2','2','1122','0','0','K07_DTCONS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130106','REGK260','1','1','1','0','0','K12_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130106','REGK260','3','3','17','0','0','K12_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130106','REGK260','2','2','17','0','0','K12_CDORDPRODSERV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130106','REGK260','9','9','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130106','REGK260','10','10','167','0','1','K12_IDREGK260','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130106','REGK260','5','5','268','0','0','K12_QTSAIDA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130106','REGK260','8','8','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130106','REGK260','7','7','268','0','0','K12_QTRETORNO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130106','REGK260','4','4','1122','0','0','K12_DTSAIDA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130106','REGK260','6','6','1122','0','0','K12_DTRETORNO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010601','REGK265','1','1','1','0','0','K13_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010601','REGK265','2','2','17','0','0','K13_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010601','REGK265','6','6','167','0','1','K12_IDREGK260','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010601','REGK265','4','4','268','0','0','K13_QTRETORNADA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010601','REGK265','5','5','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010601','REGK265','3','3','268','0','0','K13_QTCONSUMIDA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130107','REGK270','1','1','1','0','0','K14_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130107','REGK270','5','5','17','0','0','K14_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130107','REGK270','4','4','17','0','0','K14_CDORDPRODSERV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130107','REGK270','10','10','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130107','REGK270','11','11','167','0','1','K14_IDREGK270','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130107','REGK270','9','9','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130107','REGK270','8','8','268','0','0','K14_TPORIGEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130107','REGK270','7','7','268','0','0','K14_QTCORNEGATIVA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130107','REGK270','6','6','268','0','0','K14_QTCORPOSITIVA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130107','REGK270','3','3','1122','0','0','K14_DTFINAPURACAO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130107','REGK270','2','2','1122','0','0','K14_DTINIAPURACAO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010701','REGK275','1','1','1','0','0','K15_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010701','REGK275','5','5','17','0','0','K15_CDINSSUBST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010701','REGK275','2','2','17','0','0','K15_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010701','REGK275','9','9','167','0','1','K14_IDREGK270','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010701','REGK275','8','8','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010701','REGK275','4','4','268','0','0','K15_QTCORNEGATIVA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010701','REGK275','6','6','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','113010701','REGK275','3','3','268','0','0','K15_QTCORPOSITIVA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130108','REGK280','1','1','1','0','0','K16_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130108','REGK280','3','3','17','0','0','K16_CDITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130108','REGK280','7','7','17','0','0','K16_CDPARTICIPANTE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130108','REGK280','9','9','167','0','1','K01_IDREGK100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130108','REGK280','5','5','268','0','0','K16_QTCORNEGATIVA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130108','REGK280','6','6','268','0','0','K16_TPINDESTOQUE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130108','REGK280','8','8','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130108','REGK280','4','4','268','0','0','K16_QTCORPOSITIVA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1130108','REGK280','2','2','1122','0','0','K16_DTESTOQUEFIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','114','REGK990','1','1','1','0','0','K08_CDREG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','114','REGK990','3','3','268','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','114','REGK990','2','2','1147','0','0','K08_QTLINK','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115','REG1001','352','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115','REG1001','354','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115','REG1001','353','2','116','0','0','IND_MOV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11501','REG1010','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11501','REG1010','5','5','27','0','0','IND_COMB','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11501','REG1010','6','6','27','0','0','IND_USINA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11501','REG1010','7','7','27','0','0','IND_VA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11501','REG1010','4','4','27','0','0','IND_CCRF','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11501','REG1010','8','8','27','0','0','IND_EE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11501','REG1010','10','10','27','0','0','IND_FORM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11501','REG1010','3','3','27','0','0','IND_EXP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11501','REG1010','9','9','27','0','0','IND_CART','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11501','REG1010','11','11','27','0','0','IND_AER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11501','REG1010','2','2','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','13','13','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','14','14','108','0','1','IDREG1100','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','2','2','150','0','0','IND_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','3','3','151','0','0','NRO_DE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','4','4','152','0','0','DT_DE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','5','5','153','0','0','NAT_EXP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','6','6','154','0','0','NRO_RE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','7','7','155','0','0','DT_RE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','8','8','156','0','0','CH_EMB','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','9','9','157','0','0','DT_CHC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','10','10','158','0','0','DT_AVB','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','11','11','159','0','0','TP_CHC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11502','REG1100','12','12','160','0','0','PAIS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150201','REG1105','368','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150201','REG1105','376','9','108','0','1','IDREG1105','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150201','REG1105','375','8','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150201','REG1105','374','7','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150201','REG1105','369','2','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150201','REG1105','370','3','162','0','0','SERIE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150201','REG1105','371','4','163','0','0','NUM_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150201','REG1105','372','5','164','0','0','CHV_NFE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150201','REG1105','373','6','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115020101','REG1110','376','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115020101','REG1110','377','2','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115020101','REG1110','386','11','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115020101','REG1110','385','10','129','0','0','UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115020101','REG1110','378','3','161','0','0','COD_MOD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115020101','REG1110','380','5','163','0','0','NUM_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115020101','REG1110','382','7','164','0','0','CHV_NFE',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115020101','REG1110','381','6','165','0','0','DT_DOC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115020101','REG1110','379','4','166','0','0','SER',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115020101','REG1110','383','8','167','0','0','NR_MEMO',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115020101','REG1110','384','9','168','0','0','QTD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11503','REG1200','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11503','REG1200','8','8','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11503','REG1200','2','2','169','0','0','COD_AJ_APUR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11503','REG1200','3','3','170','0','0','SLD_CRED','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11503','REG1200','4','4','171','0','0','CRED_APR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11503','REG1200','5','5','172','0','0','CRED_RECEB','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11503','REG1200','6','6','173','0','0','CRED_UTIL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11503','REG1200','7','7','174','0','0','SLD_CRED_FIM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11503','REG1200','9','9','468','0','1','IDREG1200','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150301','REG1210','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150301','REG1210','5','6','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150301','REG1210','4','4','175','0','0','VL_CRED_UTIL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150301','REG1210','2','2','223','0','0','TIPO_UTIL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150301','REG1210','3','3','224','0','0','NR_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150301','REG1210','6','7','468','0','1','IDREG1200','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150301','REG1210','7','5','1133','0','0','R1210_NMCHAVEDOCE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','400','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','411','12','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','401','2','131','0','0','COD_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','402','3','176','0','0','DT_FECH','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','403','4','178','0','0','ESTQ_ABERT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','404','5','179','0','0','VOL_ENTR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','405','6','180','0','0','VOL_DISP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','406','7','181','0','0','VOL_SAIDAS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','407','8','183','0','0','ESTQ_ESCR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','408','9','184','0','0','VAL_AJ_PERDA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','409','10','185','0','0','VAL_AJ_GANHO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','410','11','193','0','0','FECH_FISICO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11504','REG1300','13','13','1091','0','1','IDREG1300','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','11','11','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','3','3','178','0','0','ESTQ_ABERT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','4','4','179','0','0','VOL_ENTR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','5','5','180','0','0','VOL_DISP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','6','6','181','0','0','VOL_SAIDAS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','7','7','183','0','0','ESTQ_ESCR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','8','8','184','0','0','VAL_AJ_PERDA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','9','9','185','0','0','VAL_AJ_GANHO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','2','2','187','0','0','NUM_TANQUE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','10','10','193','0','0','FECH_FISICO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','12','12','1091','0','1','IDREG1300','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150401','REG1310','13','13','1092','0','1','IDREG1310','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','12','12','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','3','3','177','0','0','NR_INTERV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','2','2','1077','0','0','NUM_BICO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','4','4','1078','0','0','MOT_INTERV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','5','5','1079','0','0','NOM_INTERV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','6','6','1080','0','0','CNPJ_INTERV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','7','7','1081','0','0','CPF_INTERV','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','8','8','1082','0','0','VAL_FECHA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','9','9','1083','0','0','VAL_ABERT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','10','10','1084','0','0','VOL_AFERI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','11','11','1085','0','0','VOL_VENDAS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','13','13','1092','0','1','IDREG1310','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','115040101','REG1320','14','14','1093','0','1','IDREG1320','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11505','REG1350','435','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11505','REG1350','440','6','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11505','REG1350','436','2','162','0','0','SERIE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11505','REG1350','437','3','1086','0','0','FABRICANTE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11505','REG1350','438','4','1087','0','0','MODELO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11505','REG1350','439','5','1088','0','0','TIPO_MEDICAO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11505','REG1350','7','7','1094','0','1','IDREG1350','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150501','REG1360','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150501','REG1360','4','4','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150501','REG1360','2','2','1089','0','0','NUM_LACRE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150501','REG1360','3','3','1090','0','0','DT_APLICACAO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150501','REG1360','5','5','1094','0','1','IDREG1350','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150501','REG1360','6','6','1095','0','1','IDREG1360','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150502','REG1370','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150502','REG1370','5','5','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150502','REG1370','3','3','131','0','0','COD_ITEM','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150502','REG1370','4','4','187','0','0','NUM_TANQUE','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150502','REG1370','2','2','1077','0','0','NUM_BICO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150502','REG1370','6','6','1094','0','1','IDREG1350','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150502','REG1370','7','7','1096','0','1','IDREG1370','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11506','REG1390','3','3','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11506','REG1390','2','2','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11506','REG1390','4','4','322','0','0','COD_PROD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11506','REG1390','1','1','468','0','1','IDREG1390','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','4','4','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','3','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','7','7','322','0','0','ESTQ_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','17','17','322','0','0','PROD_DIA_MEL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','16','16','322','0','0','ESTQ_INI_MEL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','15','15','322','0','0','ESTQ_FIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','14','14','322','0','0','SA�DAS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','6','6','322','0','0','QTD_MOID','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','13','13','322','0','0','SAI_ANI_HID','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','5','5','322','0','0','DT_REGISTRO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','19','19','322','0','0','PROD_ALC_MEL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','8','8','322','0','0','QTD_PRODUZ','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','20','20','322','0','0','OBS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','18','18','322','0','0','UTIL_MEL','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','9','9','322','0','0','ENT_ANID_HID','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','10','10','322','0','0','OUTR_ENTR','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','11','11','322','0','0','PERDA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','12','12','322','0','0','CONS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','1','1','468','0','1','IDREG1391','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150601','REG1391','2','2','468','0','1','IDREG1390','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11507','REG1400','426','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11507','REG1400','430','5','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11507','REG1400','427','2','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11507','REG1400','428','3','194','0','0','MUN',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11507','REG1400','429','4','195','0','0','VALOR',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','4','4','17','0','0','COD_PART','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','28','28','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','23','23','147','0','0','COD_INF','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','5','5','161','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','10','10','163','0','0','NUM_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','11','11','165','0','0','DT_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','7','7','166','0','0','SER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','2','2','196','0','0','IND_OPER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','3','3','197','0','0','IND_EMIT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','6','6','198','0','0','COD_SIT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','8','8','199','0','0','SUB','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','9','9','200','0','0','COD_CONS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','12','12','201','0','0','DT_E_S','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','13','13','202','0','0','VL_DOC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','14','14','203','0','0','VL_DESC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','15','15','204','0','0','VL_FORN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','16','16','205','0','0','VL_SERV_NT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','17','17','206','0','0','VL_TERC','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','18','18','207','0','0','VL_DA','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','19','19','208','0','0','VL_BC_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','20','20','209','0','0','VL_ICMS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','21','21','210','0','0','VL_BC_ICMS_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','22','22','211','0','0','VL_ICMS_ST','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','24','24','212','0','0','VL_PIS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','25','25','213','0','0','VL_COFINS','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','26','26','771','0','0','TP_LIGACAO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11508','REG1500','27','27','772','0','0','COD_GRUPO_TENSAO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','457','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','474','18','17','0','0','COD_PART',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','477','21','47','0','0','COD_CTA',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','478','22','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','462','6','129','0','0','UNID',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','459','3','131','0','0','COD_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','468','12','141','0','0','ALIQ_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','461','5','168','0','0','QTD',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','464','8','203','0','0','VL_DESC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','467','11','208','0','0','VL_BC_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','469','13','209','0','0','VL_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','470','14','210','0','0','VL_BC_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','472','16','211','0','0','VL_ICMS_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','475','19','212','0','0','VL_PIS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','476','20','213','0','0','VL_COFINS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','458','2','214','0','0','NUM_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','460','4','215','0','0','COD_CLASS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','463','7','216','0','0','VL_ITEM',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','465','9','217','0','0','CST_ICMS',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','466','10','218','0','0','CFOP',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','471','15','219','0','0','ALIQ_ST',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1150801','REG1510','473','17','220','0','0','IND_REC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11509','REG1600','21263','2','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11509','REG1600','21262','1','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11509','REG1600','21266','5','322','0','0','TOT_DEBITO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11509','REG1600','21264','3','322','0','0','COD_PART','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11509','REG1600','21265','4','322','0','0','TOT_CREDITO','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11510','REG1700','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11510','REG1700','9','9','108','0','0','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11510','REG1700','3','3','161','0','0','COD_MOD','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11510','REG1700','4','4','166','0','0','SER','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11510','REG1700','5','5','199','0','0','SUB','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11510','REG1700','6','6','324','0','0','NUM_DOC_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11510','REG1700','7','7','325','0','0','NUM_DOC_FIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11510','REG1700','10','10','468','0','1','IDREG1700','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11510','REG1700','8','8','769','0','0','NUM_AUT','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11510','REG1700','2','2','1052','0','0','COD_DISP','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1151001','REG1710','1','3','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1151001','REG1710','2','4','324','0','0','NUM_DOC_INI','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1151001','REG1710','3','5','325','0','0','NUM_DOC_FIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','1151001','REG1710','4','6','468','0','1','IDREG1710','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','116','REG1990','479','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','116','REG1990','481','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','116','REG1990','480','2','221','0','0','QTD_LIN_1',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','117','REG9001','482','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','117','REG9001','484','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','117','REG9001','483','2','116','0','0','IND_MOV',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11701','REGI9900','1059','2','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11701','REGI9900','1060','3','105','0','0','REG_BLC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11701','REGI9900','1061','4','106','0','0','QTD_REG_BLC',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','11701','REGI9900','1058','1','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','118','REG9990','489','1','1','0','0','REG',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','118','REG9990','490','2','107','0','0','QTD_LIN_9',NULL)
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','118','REG9990','491','3','108','0','1','SMECODIGO','1')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','2','REG9999','1','1','1','0','0','REG','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','2','REG9999','2','2','39','0','0','QTD_LIN','0')
/

INSERT INTO RELTIPOREGISTROCOLUNA_RTC(RTC_CDLAYOUT, RTC_SQNIVEL, RTC_TIPOARQUIVO, RTC_SQRTC, RTC_ORDERCAMPO, RTC_SQCAMPO, RTC_TPALINHAMENTO, RTC_VBCHAVE, RTC_COLUMN, RTC_VBNAOGERA) VALUES('EFD11','2','REG9999','3','3','108','0','1','SMECODIGO','1')
/

ALTER TABLE SPEDAPUIPI_SIPI ADD SIPI_VBDOCINF NUMBER(1)
/

COMMENT ON COLUMN SPEDAPUIPI_SIPI.SIPI_VBDOCINF IS 'Indica que ser�o aceitas as notas digitadas pelo usu�rio'
/

CREATE OR REPLACE PROCEDURE INSSPEDAPUIPI_SIPI
(PSIPI_SQAPUIPI  IN OUT NUMBER,
 PSIPI_CDEMPRESA IN CHAR,
 PSIPI_CDFILIAL  IN CHAR,
 PSIPI_DATAINI   IN DATE,
 PSIPI_DATAFIN   IN DATE,
 PSIPI_INDPER    IN NUMBER,
 PSIPI_CDSISTEMA IN CHAR DEFAULT NULL,
 PSIPI_VBDOCINF  IN NUMBER
)
AS
BEGIN
  IF PSIPI_SQAPUIPI IS NULL THEN
   SELECT SEQ_SIPI_SQAPUIPI.NEXTVAL
     INTO PSIPI_SQAPUIPI
     FROM DUAL;
  END IF;
  INSERT INTO SPEDAPUIPI_SIPI
     (SIPI_SQAPUIPI,
      SIPI_CDEMPRESA,
      SIPI_CDFILIAL,
      SIPI_DATAINI,
      SIPI_DATAFIN,
      SIPI_INDPER,
      SIPI_CDSISTEMA,
      SIPI_VBDOCINF)
  VALUES
     (PSIPI_SQAPUIPI,
      PSIPI_CDEMPRESA,
      PSIPI_CDFILIAL,
      PSIPI_DATAINI,
      PSIPI_DATAFIN,
      PSIPI_INDPER,
      PSIPI_CDSISTEMA,
      PSIPI_VBDOCINF);
END;
/

CREATE OR REPLACE PROCEDURE ALTSPEDAPUIPI_SIPI
(PSIPI_SQAPUIPI  IN OUT NUMBER,
 PSIPI_CDEMPRESA IN CHAR,
 PSIPI_CDFILIAL  IN CHAR,
 PSIPI_DATAINI   IN DATE,
 PSIPI_DATAFIN   IN DATE,
 PSIPI_INDPER    IN NUMBER,
 PSIPI_CDSISTEMA IN CHAR DEFAULT NULL,
 PSIPI_VBDOCINF  IN NUMBER
)
AS
BEGIN
  UPDATE SPEDAPUIPI_SIPI
     SET SIPI_CDEMPRESA = PSIPI_CDEMPRESA,
         SIPI_CDFILIAL = PSIPI_CDFILIAL,
         SIPI_DATAINI = PSIPI_DATAINI,
         SIPI_DATAFIN = PSIPI_DATAFIN,
         SIPI_INDPER = PSIPI_INDPER,
         SIPI_CDSISTEMA = PSIPI_CDSISTEMA,
         SIPI_VBDOCINF = PSIPI_VBDOCINF
   WHERE SIPI_SQAPUIPI = PSIPI_SQAPUIPI;
END;
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO IN ('SAAI0009','SAAI0010')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('SAAI0009','N�o deve ser informado o n�mero do documento quando a origem do ajuste for "3 - Documento Fiscal".')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('SAAI0010','Quando a origem do ajuste for "3 - Documento Fiscal", deve ser feita a identifica��o dos documentos fiscais relacionados aos ajustes.')
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO IN ('DAI0001','DAI0002','DAI0003','DAI0004','DAI0005','DAI0006','DAI0007','DAI0008','DAI0009','DAI0010','DAI0011','DAI0012','DAI0013','DAI0014','DAI0015','DAI0016')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0001','Sequencial de documento fiscal inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0002','O tipo do participante � inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0003','O fornecedor � inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0004','Fornecedor inativo.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0005','O cliente � inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0006','Cliente inativo.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0007','O c�digo do modelo do documento fiscal � obrigat�rio.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0008','O c�digo do modelo do documento fiscal � inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0009','Devem ser utilizados apenas os modelos de documento fiscal "01" e "55".')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0010','O n�mero do documento fiscal � obrigat�rio.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0011','O c�digo do produto � obrigat�rio.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0012','O c�digo do produto � inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0013','A data do documento fiscal � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0014','A data � maior que o per�odo de apura��o.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0015','O valor do ajuste � obrigat�rio.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO)VALUES('DAI0016','O somat�rio dos documentos fiscais relacionados � maior que o valor do ajuste.')
/

CREATE OR REPLACE PROCEDURE PRC_EFD_APUR_ICMSDIFAL_SALDO(PSAI_SQAPUICMS         IN NUMBER,
                                                         PVL_TOT_DEBITOS_DIFAL  OUT NUMBER,
                                                         PVL_TOT_DEB_FCP        OUT NUMBER,
                                                         PVL_TOT_CREDITOS_DIFAL OUT NUMBER,
                                                         PVL_TOT_CRED_FCP       OUT NUMBER,
                                                         PDEB_ESP_DIFAL         OUT NUMBER) AS
  --DECLARACAO DE VARIAVEIS
  VSAI_SQAPUICMS NUMBER;
  --DECLARACAO DE CURSORES
  CURSOR CUR_SPEDAPUICMS_SAI IS
    SELECT SUM(VL_TOT_DEBITOS_DIFAL) AS VL_TOT_DEBITOS_DIFAL,
           SUM(VL_TOT_DEB_FCP) AS VL_TOT_DEB_FCP,
           SUM(VL_TOT_CREDITOS_DIFAL) AS VL_TOT_CREDITOS_DIFAL,
           SUM(VL_TOT_CRED_FCP) AS VL_TOT_CRED_FCP,
           SUM(DEB_ESP_DIFAL) AS DEB_ESP_DIFAL
      FROM (SELECT SUM(CASE
                         WHEN S.SDF_CDENDCLIFOR IS NOT NULL THEN
                          CASE
                            WHEN S.SDF_CLIFOR = 'C' THEN
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                I.IDF_VLICMSUFREMETENTE
                               WHEN A.SAI_UF = CLE.CLE_UF THEN
                                I.IDF_VLICMSUFDESTINO
                               ELSE
                                0
                             END
                            ELSE
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                I.IDF_VLICMSUFREMETENTE
                               WHEN A.SAI_UF = FOE.FOE_UF THEN
                                I.IDF_VLICMSUFDESTINO
                               ELSE
                                0
                             END
                          END
                         ELSE
                          CASE
                            WHEN S.SDF_CLIFOR = 'C' THEN
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                I.IDF_VLICMSUFREMETENTE
                               WHEN A.SAI_UF = CLI.CLI_UF THEN
                                I.IDF_VLICMSUFDESTINO
                               ELSE
                                0
                             END
                            ELSE
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                I.IDF_VLICMSUFREMETENTE
                               WHEN A.SAI_UF = FORN.FOR_UF THEN
                                I.IDF_VLICMSUFDESTINO
                               ELSE
                                0
                             END
                          END
                       END) AS VL_TOT_DEBITOS_DIFAL,
                   SUM(CASE
                         WHEN S.SDF_CDENDCLIFOR IS NOT NULL THEN
                          CASE
                            WHEN S.SDF_CLIFOR = 'C' THEN
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                0
                               WHEN A.SAI_UF = CLE.CLE_UF THEN
                                I.IDF_VLICMSFECPUFDEST
                               ELSE
                                0
                             END
                            ELSE
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                0
                               WHEN A.SAI_UF = FOE.FOE_UF THEN
                                I.IDF_VLICMSFECPUFDEST
                               ELSE
                                0
                             END
                          END
                         ELSE
                          CASE
                            WHEN S.SDF_CLIFOR = 'C' THEN
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                0
                               WHEN A.SAI_UF = CLI.CLI_UF THEN
                                I.IDF_VLICMSFECPUFDEST
                               ELSE
                                0
                             END
                            ELSE
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                0
                               WHEN A.SAI_UF = FORN.FOR_UF THEN
                                I.IDF_VLICMSFECPUFDEST
                               ELSE
                                0
                             END
                          END
                       END) AS VL_TOT_DEB_FCP,
                   0 AS VL_TOT_CREDITOS_DIFAL,
                   0 AS VL_TOT_CRED_FCP,
                   0 AS DEB_ESP_DIFAL
              FROM SPEDDOCFIS_SDF       S,
                   SPEDITDOCFIS_IDF     I,
                   TPOPER_TPO           T,
                   SPEDAPUICMS_SAI      A,
                   SPEDPAREMPRESA_PEMP  P,
                   SPEDTABMUNICIBGE_TMI B,
                   SPEDTABUF_TUF        U,
                   CLIENTE_CLI          CLI,
                   FORNEC_FOR           FORN,
                   CLE_CLE              CLE,
                   FOE_FOE              FOE
             WHERE S.SDF_SQDOCFIS = I.IDF_SQDOCFIS
               AND S.SDF_TPOP = T.TPO_CODIGO
               AND T.TPO_TIPO = 'S'
               AND S.SDF_MODELO = '55'
               AND S.SDF_SITDOC NOT IN ('01', '07')
               AND S.SDF_DATAESCR >= A.SAI_DATAINI
               AND S.SDF_DATAESCR <= A.SAI_DATAFIM
               AND S.SDF_CDEMPRESA = A.SAI_CDEMPRESA
               AND S.SDF_CDFILIAL = A.SAI_CDFILIAL
               AND A.SAI_ICMSTPOPERACAO = 3
               AND P.PEMP_CDEMPRESA = S.SDF_CDEMPRESA
               AND P.PEMP_CDFILIAL = S.SDF_CDFILIAL
               AND P.PEMP_CDFILIAL IS NOT NULL
               AND S.SDF_CDCLIFOR = CLI.CLI_CODIGO(+)
               AND S.SDF_CDCLIFOR = FORN.FOR_CODIGO(+)
               AND S.SDF_CDENDCLIFOR = FOE.FOE_CDEND(+)
               AND S.SDF_CDCLIFOR = CLE.CLE_CODIGO(+)
               AND S.SDF_CDENDCLIFOR = CLE.CLE_CDEND(+)
               AND S.SDF_CDCLIFOR = FOE.FOE_CODIGO(+)
               AND S.SDF_CDENDCLIFOR = FOE.FOE_CDEND(+)
               AND P.PEMP_CODMUN = B.TMI_CODIGO
               AND B.TMI_CODIGOUF = U.TUF_CODIGO
               AND A.SAI_SQAPUICMS = VSAI_SQAPUICMS
            UNION ALL
            SELECT 0 AS VL_TOT_DEBITOS_DIFAL,
                   0 AS VL_TOT_DEB_FCP,
                   SUM(CASE
                         WHEN S.SDF_CDENDCLIFOR IS NOT NULL THEN
                          CASE
                            WHEN S.SDF_CLIFOR = 'C' THEN
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                I.IDF_VLICMSUFDESTINO
                               WHEN A.SAI_UF = CLE.CLE_UF THEN
                                I.IDF_VLICMSUFREMETENTE
                               ELSE
                                0
                             END
                            ELSE
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                I.IDF_VLICMSUFDESTINO
                               WHEN A.SAI_UF = FOE.FOE_UF THEN
                                I.IDF_VLICMSUFREMETENTE
                               ELSE
                                0
                             END
                          END
                         ELSE
                          CASE
                            WHEN S.SDF_CLIFOR = 'C' THEN
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                I.IDF_VLICMSUFDESTINO
                               WHEN A.SAI_UF = CLI.CLI_UF THEN
                                I.IDF_VLICMSUFREMETENTE
                               ELSE
                                0
                             END
                            ELSE
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                I.IDF_VLICMSUFDESTINO
                               WHEN A.SAI_UF = FORN.FOR_UF THEN
                                I.IDF_VLICMSUFREMETENTE
                               ELSE
                                0
                             END
                          END
                       END) AS VL_TOT_CREDITOS_DIFAL,
                   SUM(CASE
                         WHEN S.SDF_CDENDCLIFOR IS NOT NULL THEN
                          CASE
                            WHEN S.SDF_CLIFOR = 'C' THEN
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                0
                               WHEN A.SAI_UF = CLE.CLE_UF THEN
                                I.IDF_VLICMSFECPUFDEST
                               ELSE
                                0
                             END
                            ELSE
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                0
                               WHEN A.SAI_UF = FOE.FOE_UF THEN
                                I.IDF_VLICMSFECPUFDEST
                               ELSE
                                0
                             END
                          END
                         ELSE
                          CASE
                            WHEN S.SDF_CLIFOR = 'C' THEN
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                0
                               WHEN A.SAI_UF = CLI.CLI_UF THEN
                                I.IDF_VLICMSFECPUFDEST
                               ELSE
                                0
                             END
                            ELSE
                             CASE
                               WHEN A.SAI_UF = U.TUF_SIGLA THEN
                                0
                               WHEN A.SAI_UF = FORN.FOR_UF THEN
                                I.IDF_VLICMSFECPUFDEST
                               ELSE
                                0
                             END
                          END
                       END) AS VL_TOT_CRED_FCP,
                   0 AS DEB_ESP_DIFAL
              FROM SPEDDOCFIS_SDF       S,
                   SPEDITDOCFIS_IDF     I,
                   TPOPER_TPO           T,
                   SPEDAPUICMS_SAI      A,
                   SPEDPAREMPRESA_PEMP  P,
                   SPEDTABMUNICIBGE_TMI B,
                   SPEDTABUF_TUF        U,
                   CLIENTE_CLI          CLI,
                   FORNEC_FOR           FORN,
                   CLE_CLE              CLE,
                   FOE_FOE              FOE
             WHERE S.SDF_SQDOCFIS = I.IDF_SQDOCFIS
               AND S.SDF_TPOP = T.TPO_CODIGO
               AND T.TPO_TIPO = 'E'
               AND S.SDF_MODELO = '55'
               AND S.SDF_DATAESCR >= A.SAI_DATAINI
               AND S.SDF_DATAESCR <= A.SAI_DATAFIM
               AND S.SDF_CDEMPRESA = A.SAI_CDEMPRESA
               AND S.SDF_CDFILIAL = A.SAI_CDFILIAL
               AND A.SAI_ICMSTPOPERACAO = 3
               AND P.PEMP_CDEMPRESA = S.SDF_CDEMPRESA
               AND P.PEMP_CDFILIAL = S.SDF_CDFILIAL
               AND P.PEMP_CDFILIAL IS NOT NULL
               AND S.SDF_CDCLIFOR = CLI.CLI_CODIGO(+)
               AND S.SDF_CDCLIFOR = FORN.FOR_CODIGO(+)
               AND S.SDF_CDENDCLIFOR = FOE.FOE_CDEND(+)
               AND S.SDF_CDCLIFOR = CLE.CLE_CODIGO(+)
               AND S.SDF_CDENDCLIFOR = CLE.CLE_CDEND(+)
               AND S.SDF_CDCLIFOR = FOE.FOE_CODIGO(+)
               AND S.SDF_CDENDCLIFOR = FOE.FOE_CDEND(+)
               AND P.PEMP_CODMUN = B.TMI_CODIGO
               AND B.TMI_CODIGOUF = U.TUF_CODIGO
               AND A.SAI_SQAPUICMS = VSAI_SQAPUICMS
            UNION ALL
            SELECT SUM(CASE
                         WHEN U.TUF_CODIGO = SUBSTR(SDF_CDMUNORIGEM, 1, 2) THEN
                          I.IDF_VLICMSUFREMETENTE
                         WHEN U.TUF_CODIGO = SUBSTR(SDF_CDMUNDEST, 1, 2) THEN
                          I.IDF_VLICMSUFDESTINO
                         ELSE
                          0
                       END) AS VL_TOT_DEBITOS_DIFAL,
                   SUM(CASE
                         WHEN U.TUF_CODIGO = SUBSTR(SDF_CDMUNDEST, 1, 2) THEN
                          I.IDF_VLICMSFECPUFDEST
                         WHEN U.TUF_CODIGO = SUBSTR(SDF_CDMUNORIGEM, 1, 2) THEN
                          0
                         ELSE
                          0
                       END) AS VL_TOT_DEB_FCP,
                   0 AS VL_TOT_CREDITOS_DIFAL,
                   0 AS VL_TOT_CRED_FCP,
                   0 AS DEB_ESP_DIFAL
              FROM SPEDDOCFIS_SDF   S,
                   SPEDITDOCFIS_IDF I,
                   TPOPER_TPO       T,
                   SPEDAPUICMS_SAI  A,
                   SPEDTABUF_TUF    U
             WHERE S.SDF_SQDOCFIS = I.IDF_SQDOCFIS
               AND S.SDF_TPOP = T.TPO_CODIGO
               AND T.TPO_TIPO = 'S'
               AND S.SDF_MODELO IN ('57', '67')
               AND S.SDF_SITDOC NOT IN ('01', '07')
               AND S.SDF_DATAESCR >= A.SAI_DATAINI
               AND S.SDF_DATAESCR <= A.SAI_DATAFIM
               AND S.SDF_CDEMPRESA = A.SAI_CDEMPRESA
               AND S.SDF_CDFILIAL = A.SAI_CDFILIAL
               AND A.SAI_ICMSTPOPERACAO = 3
               AND A.SAI_UF = TUF_SIGLA
               AND A.SAI_SQAPUICMS = VSAI_SQAPUICMS
            UNION ALL
            SELECT 0 AS VL_TOT_DEBITOS_DIFAL,
                   0 AS VL_TOT_DEB_FCP,
                   SUM(CASE
                         WHEN U.TUF_CODIGO = SUBSTR(SDF_CDMUNDEST, 1, 2) THEN
                          I.IDF_VLICMSUFDESTINO
                         WHEN U.TUF_CODIGO = SUBSTR(SDF_CDMUNORIGEM, 1, 2) THEN
                          I.IDF_VLICMSUFREMETENTE
                         ELSE
                          0
                       END) AS VL_TOT_CREDITOS_DIFAL,
                   SUM(CASE
                         WHEN U.TUF_CODIGO = SUBSTR(SDF_CDMUNORIGEM, 1, 2) THEN
                          0
                         WHEN U.TUF_CODIGO = SUBSTR(SDF_CDMUNDEST, 1, 2) THEN
                          I.IDF_VLICMSFECPUFDEST
                         ELSE
                          0
                       END) AS VL_TOT_CRED_FCP,
                   0 AS DEB_ESP_DIFAL
              FROM SPEDDOCFIS_SDF   S,
                   SPEDITDOCFIS_IDF I,
                   TPOPER_TPO       T,
                   SPEDAPUICMS_SAI  A,
                   SPEDTABUF_TUF    U
             WHERE S.SDF_SQDOCFIS = I.IDF_SQDOCFIS
               AND S.SDF_TPOP = T.TPO_CODIGO
               AND T.TPO_TIPO = 'E'
               AND S.SDF_MODELO IN ('57', '67')
               AND S.SDF_DATAESCR >= A.SAI_DATAINI
               AND S.SDF_DATAESCR <= A.SAI_DATAFIM
               AND S.SDF_CDEMPRESA = A.SAI_CDEMPRESA
               AND S.SDF_CDFILIAL = A.SAI_CDFILIAL
               AND A.SAI_ICMSTPOPERACAO = 3
               AND A.SAI_UF = TUF_SIGLA
               AND A.SAI_SQAPUICMS = VSAI_SQAPUICMS);
BEGIN
  VSAI_SQAPUICMS := PSAI_SQAPUICMS;
  FOR REC_SPEDAPUICMS_SAI IN CUR_SPEDAPUICMS_SAI LOOP
    PVL_TOT_DEBITOS_DIFAL  := REC_SPEDAPUICMS_SAI.VL_TOT_DEBITOS_DIFAL;
    PVL_TOT_DEB_FCP        := REC_SPEDAPUICMS_SAI.VL_TOT_DEB_FCP;
    PVL_TOT_CREDITOS_DIFAL := REC_SPEDAPUICMS_SAI.VL_TOT_CREDITOS_DIFAL;
    PVL_TOT_CRED_FCP       := REC_SPEDAPUICMS_SAI.VL_TOT_CRED_FCP;
    PDEB_ESP_DIFAL         := REC_SPEDAPUICMS_SAI.DEB_ESP_DIFAL;
  END LOOP;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFD_APURACAO_ICMSDIFAL(PSAI_SQAPUICMS           IN NUMBER,
                                                       PIND_MOV_DIFAL           OUT NUMBER,
                                                       PVL_SLD_CRED_ANT_DIFAL   OUT NUMBER,
                                                       PVL_TOT_DEBITOS_DIFAL    OUT NUMBER,
                                                       PVL_OUT_DEB_DIFAL        OUT NUMBER,
                                                       PVL_TOT_DEB_FCP          OUT NUMBER,
                                                       PVL_TOT_CREDITOS_DIFAL   OUT NUMBER,
                                                       PVL_TOT_CRED_FCP         OUT NUMBER,
                                                       PVL_OUT_CRED_DIFAL       OUT NUMBER,
                                                       PVL_SLD_DEV_ANT_DIFAL    OUT NUMBER,
                                                       PVL_DEDUCOES_DIFAL       OUT NUMBER,
                                                       PVL_RECOL                OUT NUMBER,
                                                       PVL_SLD_CRED_TRANSPORTAR OUT NUMBER,
                                                       PDEB_ESP_DIFAL           OUT NUMBER
                                                       -- CAMPOS V�LIDOS A PARTIR DE 01/01/2017
                                                      ,
                                                       PVL_SLD_CRED_ANT_FCP    OUT NUMBER,
                                                       PVL_OUT_DEB_FCP         OUT NUMBER,
                                                       PVL_OUT_CRED_FCP        OUT NUMBER,
                                                       PVL_DEDUCOES_FCP        OUT NUMBER,
                                                       PDEB_ESP_FCP            OUT NUMBER,
                                                       PVL_SLD_DEV_ANT_FCP     OUT NUMBER,
                                                       PVL_RECOL_FCP           OUT NUMBER,
                                                       PVL_SLD_CRED_TRANSP_FCP OUT NUMBER,
                                                       PVL_E316                OUT NUMBER) AS
  --DECLARACAO DE VARIAVEIS
  V_VL_OUT_DEB_DIFAL        NUMBER(15, 2);
  V_VL_OUT_CRED_DIFAL       NUMBER(15, 2);
  V_VL_DEDUCOES_DIFAL       NUMBER(15, 2);
  V_DEB_ESP_DIFAL           NUMBER(15, 2);
  V_VL_SLD_CRED_ANT_DIFAL   NUMBER(15, 2);
  V_VL_TOT_DEBITOS_DIFAL    NUMBER(15, 2);
  V_VL_TOT_DEB_FCP          NUMBER(15, 2);
  V_VL_TOT_CREDITOS_DIFAL   NUMBER(15, 2);
  V_VL_TOT_CRED_FCP         NUMBER(15, 2);
  V_VL_SLD_DEV_ANT_DIFAL    NUMBER(15, 2);
  V_VL_RECOL                NUMBER(15, 2);
  V_VL_SLD_CRED_TRANSPORTAR NUMBER(15, 2);
  -- CAMPOS V�LIDOS A PARTIR DE 01/01/2017
  V_VL_SLD_CRED_ANT_FCP    NUMBER(15, 2);
  V_VL_OUT_DEB_FCP         NUMBER(15, 2);
  V_VL_OUT_CRED_FCP        NUMBER(15, 2);
  V_VL_DEDUCOES_FCP        NUMBER(15, 2);
  V_DEB_ESP_FCP            NUMBER(15, 2);
  V_VL_SLD_DEV_ANT_FCP     NUMBER(15, 2);
  V_VL_RECOL_FCP           NUMBER(15, 2);
  V_VL_SLD_CRED_TRANSP_FCP NUMBER(15, 2);
  --TOTALIZADORES
  V_TOT_VL_OUT_DEB_DIFAL        NUMBER(15, 2);
  V_TOT_VL_OUT_CRED_DIFAL       NUMBER(15, 2);
  V_TOT_VL_DEDUCOES_DIFAL       NUMBER(15, 2);
  V_TOT_DEB_ESP_DIFAL           NUMBER(15, 2);
  V_TOT_VL_SLD_CRED_ANT_DIFAL   NUMBER(15, 2);
  V_TOT_TOT_DEBITOS_DIFAL       NUMBER(15, 2);
  V_TOT_TOT_DEB_FCP             NUMBER(15, 2);
  V_TOT_TOT_CREDITOS_DIFAL      NUMBER(15, 2);
  V_TOT_TOT_CRED_FCP            NUMBER(15, 2);
  V_TOT_VL_SLD_DEV_ANT_DIFAL    NUMBER(15, 2);
  V_TOT_VL_RECOL                NUMBER(15, 2);
  V_TOT_VL_SLD_CRED_TRANSPORTAR NUMBER(15, 2);
  -- CAMPOS V�LIDOS A PARTIR DE 01/01/2017
  V_TOT_VL_SLD_CRED_ANT_FCP    NUMBER(15, 2);
  V_TOT_VL_OUT_DEB_FCP         NUMBER(15, 2);
  V_TOT_VL_OUT_CRED_FCP        NUMBER(15, 2);
  V_TOT_VL_DEDUCOES_FCP        NUMBER(15, 2);
  V_TOT_DEB_ESP_FCP            NUMBER(15, 2);
  V_TOT_VL_SLD_DEV_ANT_FCP     NUMBER(15, 2);
  V_TOT_VL_RECOL_FCP           NUMBER(15, 2);
  V_TOT_VL_SLD_CRED_TRANSP_FCP NUMBER(15, 2);
  V_TOT_VL_E316                NUMBER(15, 2);
  VDATA010117 CONSTANT SPEDAPUICMS_SAI.SAI_DATAINI%TYPE := TO_DATE('01/01/17',
                                                                   'DD/MM/RR');
  VDATAINICIOAPURACAO SPEDAPUICMS_SAI.SAI_DATAINI%TYPE;
  CURSOR CS_GET_DATA_INICIO_APURACAO IS
    SELECT TO_DATE(S.SAI_DATAINI, 'DD/MM/RR') AS DATA_INICIO
      FROM SPEDAPUICMS_SAI S
     WHERE S.SAI_SQAPUICMS = PSAI_SQAPUICMS;
BEGIN
  --ZERA VARIAVEIS
  V_VL_OUT_DEB_DIFAL            := 0;
  V_VL_OUT_CRED_DIFAL           := 0;
  V_VL_DEDUCOES_DIFAL           := 0;
  V_DEB_ESP_DIFAL               := 0;
  V_VL_SLD_CRED_ANT_DIFAL       := 0;
  V_VL_TOT_DEBITOS_DIFAL        := 0;
  V_VL_TOT_DEB_FCP              := 0;
  V_VL_TOT_CREDITOS_DIFAL       := 0;
  V_VL_TOT_CRED_FCP             := 0;
  V_VL_SLD_DEV_ANT_DIFAL        := 0;
  V_VL_RECOL                    := 0;
  V_VL_SLD_CRED_TRANSPORTAR     := 0;
  V_TOT_VL_OUT_DEB_DIFAL        := 0;
  V_TOT_VL_OUT_CRED_DIFAL       := 0;
  V_TOT_VL_DEDUCOES_DIFAL       := 0;
  V_TOT_DEB_ESP_DIFAL           := 0;
  V_TOT_VL_SLD_CRED_ANT_DIFAL   := 0;
  V_TOT_TOT_DEBITOS_DIFAL       := 0;
  V_TOT_TOT_DEB_FCP             := 0;
  V_TOT_TOT_CREDITOS_DIFAL      := 0;
  V_TOT_TOT_CRED_FCP            := 0;
  V_TOT_VL_SLD_DEV_ANT_DIFAL    := 0;
  V_TOT_VL_RECOL                := 0;
  V_TOT_VL_SLD_CRED_TRANSPORTAR := 0;
  -- CAMPOS V�LIDOS A PARTIR DE 01/01/2017
  V_VL_SLD_CRED_ANT_FCP        := 0;
  V_TOT_VL_SLD_CRED_ANT_FCP    := 0;
  V_VL_OUT_DEB_FCP             := 0;
  V_TOT_VL_OUT_DEB_FCP         := 0;
  V_VL_OUT_CRED_FCP            := 0;
  V_TOT_VL_OUT_CRED_FCP        := 0;
  V_VL_DEDUCOES_FCP            := 0;
  V_TOT_VL_DEDUCOES_FCP        := 0;
  V_DEB_ESP_FCP                := 0;
  V_TOT_DEB_ESP_FCP            := 0;
  V_VL_SLD_DEV_ANT_FCP         := 0;
  V_TOT_VL_SLD_DEV_ANT_FCP     := 0;
  V_VL_RECOL_FCP               := 0;
  V_TOT_VL_RECOL_FCP           := 0;
  V_VL_SLD_CRED_TRANSP_FCP     := 0;
  V_TOT_VL_SLD_CRED_TRANSP_FCP := 0;
  V_TOT_VL_E316                := 0;
  OPEN CS_GET_DATA_INICIO_APURACAO;
  FETCH CS_GET_DATA_INICIO_APURACAO
    INTO VDATAINICIOAPURACAO;
  CLOSE CS_GET_DATA_INICIO_APURACAO;
  --EXECUTA PARTE DE AJUSTES
  PRC_EFD_APUR_ICMSDIFAL_AJUSTE(PSAI_SQAPUICMS,
                                V_VL_OUT_CRED_DIFAL,
                                V_VL_OUT_DEB_DIFAL,
                                V_VL_DEDUCOES_DIFAL,
                                V_DEB_ESP_DIFAL);
  --TOTALIZA AJUSTES
  V_TOT_VL_OUT_CRED_DIFAL := V_TOT_VL_OUT_CRED_DIFAL +
                             NVL(V_VL_OUT_CRED_DIFAL, 0);
  V_TOT_VL_OUT_DEB_DIFAL  := V_TOT_VL_OUT_DEB_DIFAL +
                             NVL(V_VL_OUT_DEB_DIFAL, 0);
  V_TOT_VL_DEDUCOES_DIFAL := V_TOT_VL_DEDUCOES_DIFAL +
                             NVL(V_VL_DEDUCOES_DIFAL, 0);
  V_TOT_DEB_ESP_DIFAL     := V_TOT_DEB_ESP_DIFAL + NVL(V_DEB_ESP_DIFAL, 0);
  --EXECUTA PARTE DE SALDOS
  PRC_EFD_APUR_ICMSDIFAL_SALDO(PSAI_SQAPUICMS,
                               V_VL_TOT_DEBITOS_DIFAL,
                               V_VL_TOT_DEB_FCP,
                               V_VL_TOT_CREDITOS_DIFAL,
                               V_VL_TOT_CRED_FCP,
                               V_DEB_ESP_DIFAL);
  --TOTALIZA SALDOS
  V_TOT_TOT_DEBITOS_DIFAL  := V_TOT_TOT_DEBITOS_DIFAL +
                              NVL(V_VL_TOT_DEBITOS_DIFAL, 0);
  V_TOT_TOT_DEB_FCP        := V_TOT_TOT_DEB_FCP + NVL(V_VL_TOT_DEB_FCP, 0);
  V_TOT_TOT_CREDITOS_DIFAL := V_TOT_TOT_CREDITOS_DIFAL +
                              NVL(V_VL_TOT_CREDITOS_DIFAL, 0);
  V_TOT_TOT_CRED_FCP       := V_TOT_TOT_CRED_FCP +
                              NVL(V_VL_TOT_CRED_FCP, 0);
  V_TOT_DEB_ESP_DIFAL      := V_TOT_DEB_ESP_DIFAL + NVL(V_DEB_ESP_DIFAL, 0);
  --EXECUTA PARTE DE SALDO ANTERIOR
  PRC_EFD_APUR_ICMSDIFAL_SLDANT(PSAI_SQAPUICMS, V_VL_SLD_CRED_ANT_DIFAL);
  --TOTALIZA SALDO ANTERIOR
  V_TOT_VL_SLD_CRED_ANT_DIFAL := V_TOT_VL_SLD_CRED_ANT_DIFAL +
                                 NVL(V_VL_SLD_CRED_ANT_DIFAL, 0);
  --CALCULO DO SALDO DEVEDOR ANTES DAS DEDU��ES
  IF (VDATAINICIOAPURACAO >= VDATA010117) THEN
    BEGIN
      V_VL_SLD_DEV_ANT_DIFAL := (V_TOT_TOT_DEBITOS_DIFAL +
                                V_TOT_VL_OUT_DEB_DIFAL) -
                                (V_TOT_VL_SLD_CRED_ANT_DIFAL +
                                V_TOT_TOT_CREDITOS_DIFAL +
                                V_TOT_VL_OUT_CRED_DIFAL);
    END;
  ELSE
    BEGIN
      V_VL_SLD_DEV_ANT_DIFAL := (V_TOT_TOT_DEBITOS_DIFAL +
                                V_TOT_VL_OUT_DEB_DIFAL + V_TOT_TOT_DEB_FCP) -
                                (V_TOT_VL_SLD_CRED_ANT_DIFAL +
                                V_TOT_TOT_CREDITOS_DIFAL +
                                V_TOT_VL_OUT_CRED_DIFAL +
                                V_TOT_TOT_CRED_FCP);
    END;
  END IF;
  IF V_VL_SLD_DEV_ANT_DIFAL >= 0 THEN
    V_TOT_VL_SLD_DEV_ANT_DIFAL := V_VL_SLD_DEV_ANT_DIFAL;
  ELSE
    V_TOT_VL_SLD_DEV_ANT_DIFAL := 0;
  END IF;
  --CALCULO DO VALOR RECOLHIDO
  V_VL_RECOL := (V_TOT_VL_SLD_DEV_ANT_DIFAL - V_TOT_VL_DEDUCOES_DIFAL);
  IF V_VL_RECOL >= 0 THEN
    V_TOT_VL_RECOL := V_VL_RECOL;
  ELSE
    V_TOT_VL_RECOL := 0;
  END IF;
  --CALCULO DO SALDO DO CREDITO TRANSPORTAR
  IF (VDATAINICIOAPURACAO >= VDATA010117) THEN
    BEGIN
      V_VL_SLD_CRED_TRANSPORTAR := (V_TOT_VL_SLD_CRED_ANT_DIFAL +
                                   V_TOT_TOT_CREDITOS_DIFAL +
                                   V_TOT_VL_OUT_CRED_DIFAL) -
                                   (V_TOT_TOT_DEBITOS_DIFAL +
                                   V_TOT_VL_OUT_DEB_DIFAL);
    END;
  ELSE
    BEGIN
      V_VL_SLD_CRED_TRANSPORTAR := (V_TOT_VL_SLD_CRED_ANT_DIFAL +
                                   V_TOT_TOT_CREDITOS_DIFAL +
                                   V_TOT_VL_OUT_CRED_DIFAL +
                                   V_TOT_TOT_CRED_FCP) - (V_TOT_TOT_DEBITOS_DIFAL +
                                   V_TOT_VL_OUT_DEB_DIFAL +
                                   V_TOT_TOT_DEB_FCP);
    END;
  END IF;
  IF V_VL_SLD_CRED_TRANSPORTAR >= 0 THEN
    V_TOT_VL_SLD_CRED_TRANSPORTAR := V_VL_SLD_CRED_TRANSPORTAR;
  ELSE
    V_TOT_VL_SLD_CRED_TRANSPORTAR := 0;
  END IF;
  -- CAMPOS V�LIDOS A PARTIR DE 01/01/2017
  --EXECUTA PARTE DE SALDO ANTERIOR FCP
  PRC_EFD_APUR_ICMSFCP_SLDANT(PSAI_SQAPUICMS, V_VL_SLD_CRED_ANT_FCP);
  --TOTALIZA SALDO ANTERIOR FCP
  V_TOT_VL_SLD_CRED_ANT_FCP := V_TOT_VL_SLD_CRED_ANT_FCP +
                               NVL(V_VL_SLD_CRED_ANT_FCP, 0);
  --EXECUTA PARTE DE AJUSTES FCP
  PRC_EFD_APUR_ICMSFCP_AJUSTE(PSAI_SQAPUICMS,
                              V_VL_OUT_CRED_FCP,
                              V_VL_OUT_DEB_FCP,
                              V_VL_DEDUCOES_FCP,
                              V_DEB_ESP_FCP);
  --TOTALIZA AJUSTES FCP
  V_TOT_VL_OUT_CRED_FCP := V_TOT_VL_OUT_CRED_FCP +
                           NVL(V_VL_OUT_CRED_FCP, 0);
  V_TOT_VL_OUT_DEB_FCP  := V_TOT_VL_OUT_DEB_FCP + NVL(V_VL_OUT_DEB_FCP, 0);
  V_TOT_VL_DEDUCOES_FCP := V_TOT_VL_DEDUCOES_FCP +
                           NVL(V_VL_DEDUCOES_FCP, 0);
  V_TOT_DEB_ESP_FCP     := V_TOT_DEB_ESP_FCP + NVL(V_DEB_ESP_FCP, 0);
  --CALCULO DO SALDO DEVEDOR FCP ANTES DAS DEDU��ES
  V_VL_SLD_DEV_ANT_FCP := (V_TOT_TOT_DEB_FCP + V_TOT_VL_OUT_DEB_FCP) -
                          (V_TOT_VL_SLD_CRED_ANT_FCP + V_TOT_TOT_CRED_FCP +
                          V_TOT_VL_OUT_CRED_FCP);
  IF V_VL_SLD_DEV_ANT_FCP >= 0 THEN
    V_TOT_VL_SLD_DEV_ANT_FCP := V_VL_SLD_DEV_ANT_FCP;
  ELSE
    V_TOT_VL_SLD_DEV_ANT_FCP := 0;
  END IF;
  --CALCULO DO VALOR RECOLHIDO FCP
  V_VL_RECOL_FCP := (V_TOT_VL_SLD_DEV_ANT_FCP - V_TOT_VL_DEDUCOES_FCP);
  IF V_VL_RECOL_FCP >= 0 THEN
    V_TOT_VL_RECOL_FCP := V_VL_RECOL_FCP;
  ELSE
    V_TOT_VL_RECOL_FCP := 0;
  END IF;
  --CALCULO DO SALDO DO CREDITO TRANSPORTAR FCP
  V_VL_SLD_CRED_TRANSP_FCP := (V_TOT_VL_SLD_CRED_ANT_FCP +
                              V_TOT_TOT_CRED_FCP + V_TOT_VL_OUT_CRED_FCP) -
                              (V_TOT_TOT_DEB_FCP + V_TOT_VL_OUT_DEB_FCP);
  IF V_VL_SLD_CRED_TRANSP_FCP >= 0 THEN
    V_TOT_VL_SLD_CRED_TRANSP_FCP := V_VL_SLD_CRED_TRANSP_FCP;
  ELSE
    V_TOT_VL_SLD_CRED_TRANSP_FCP := 0;
  END IF;
  --PASSANDO VALOR DAS VARIAVEIS PARA PARAMETRO DE SAIDA
  IF ((V_VL_TOT_DEBITOS_DIFAL = 0) AND (V_TOT_TOT_DEB_FCP = 0) AND
     (V_TOT_TOT_CREDITOS_DIFAL = 0) AND (V_TOT_TOT_CRED_FCP = 0)) THEN
    PIND_MOV_DIFAL := 0;
  ELSE
    PIND_MOV_DIFAL := 1;
  END IF;
  IF (VDATAINICIOAPURACAO >= VDATA010117) THEN
    V_TOT_VL_E316 := (V_TOT_VL_RECOL + V_TOT_DEB_ESP_DIFAL +
                     V_TOT_VL_RECOL_FCP + V_TOT_DEB_ESP_FCP);
  ELSE
    V_TOT_VL_E316 := (V_TOT_VL_RECOL + V_TOT_DEB_ESP_DIFAL);
  END IF;
  PVL_SLD_CRED_ANT_DIFAL   := V_TOT_VL_SLD_CRED_ANT_DIFAL;
  PVL_TOT_DEBITOS_DIFAL    := V_TOT_TOT_DEBITOS_DIFAL;
  PVL_OUT_DEB_DIFAL        := V_TOT_VL_OUT_DEB_DIFAL;
  PVL_TOT_DEB_FCP          := V_TOT_TOT_DEB_FCP;
  PVL_TOT_CREDITOS_DIFAL   := V_TOT_TOT_CREDITOS_DIFAL;
  PVL_TOT_CRED_FCP         := V_TOT_TOT_CRED_FCP;
  PVL_OUT_CRED_DIFAL       := V_TOT_VL_OUT_CRED_DIFAL;
  PVL_SLD_DEV_ANT_DIFAL    := V_TOT_VL_SLD_DEV_ANT_DIFAL;
  PVL_DEDUCOES_DIFAL       := V_TOT_VL_DEDUCOES_DIFAL;
  PVL_RECOL                := V_TOT_VL_RECOL;
  PVL_SLD_CRED_TRANSPORTAR := V_TOT_VL_SLD_CRED_TRANSPORTAR;
  PDEB_ESP_DIFAL           := V_TOT_DEB_ESP_DIFAL;
  -- CAMPOS V�LIDOS A PARTIR DE 01/01/2017
  PVL_SLD_CRED_ANT_FCP    := V_TOT_VL_SLD_CRED_ANT_FCP;
  PVL_OUT_CRED_FCP        := V_TOT_VL_OUT_CRED_FCP;
  PVL_OUT_DEB_FCP         := V_TOT_VL_OUT_DEB_FCP;
  PVL_DEDUCOES_FCP        := V_TOT_VL_DEDUCOES_FCP;
  PDEB_ESP_FCP            := V_TOT_DEB_ESP_FCP;
  PVL_SLD_DEV_ANT_FCP     := V_TOT_VL_SLD_DEV_ANT_FCP;
  PVL_RECOL_FCP           := V_TOT_VL_RECOL_FCP;
  PVL_SLD_CRED_TRANSP_FCP := V_TOT_VL_SLD_CRED_TRANSP_FCP;
  PVL_E316                := V_TOT_VL_E316;
END;
/

CREATE OR REPLACE VIEW VW_SPEDEFDICMSR0200 AS
(  SELECT CODITEM,
             SMECODIGO,
             CDITEMPATRIMONIAL,
             CDANEXOITPATRIMONIAL
        FROM (                                                 --REGISTRO C170
              SELECT  C170.COD_ITEM AS CODITEM,
                      SME.SME_CODIGO AS SMECODIGO,
                      NULL AS CDITEMPATRIMONIAL,
                      NULL AS CDANEXOITPATRIMONIAL
                 FROM SPEDEFDITDOCV10_RC170 C170, SPEDMODELOESCRT_SME SME
                WHERE C170.SMECODIGO = SME.SME_CODIGO
                      AND C170.RC170_CDITEMPATRIMONIAL IS NULL
              --REGISTRO C170 - ITENS PATRIMONIAIS
              UNION
              SELECT C170.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     PAT.PAT_CDPATRIMO AS CDITEMPATRIMONIAL,
                     PAT.PAT_CDANEXO AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDITDOCV10_RC170 C170,
                     SPEDMODELOESCRT_SME SME,
                     PATRIMON_PAT PAT
               WHERE SME.SME_CODIGO = C170.SMECODIGO
                     AND SME.SME_CDEMPRESA = PAT.PAT_CDEMPRESA
                     AND (SME.SME_CDFILIAL = PAT.PAT_FILIAL
                          OR PAT.PAT_FILIAL IS NULL)
                     AND C170.RC170_CDITEMPATRIMONIAL IS NOT NULL
                     AND C170.RC170_CDITEMPATRIMONIAL = PAT.PAT_CDPATRIMO
                     AND C170.RC170_CDANEXO = PAT.PAT_CDANEXO
              -- BLOCO H - H010
              UNION
              SELECT H010.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDINVENTARIOV10_RH010 H010, SPEDMODELOESCRT_SME SME
               WHERE H010.SMECODIGO = SME.SME_CODIGO
              -- BLOCO C - C470
              UNION
              SELECT C470.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDITDOCFISEFCV10_RC470 C470, SPEDMODELOESCRT_SME SME
               WHERE C470.SMECODIGO = SME.SME_CODIGO
              --REGISTRO C425 (02,2D) PERFIL B
              UNION
              SELECT C425.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDITMOVDIAV10_RC425 C425, SPEDMODELOESCRT_SME SME
               WHERE C425.SMECODIGO = SME.SME_CODIGO
              /*REGISTRO C610 (06,29,28), REGISTRO D610 (21,22)*/
              UNION
              SELECT C610.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDITCONNFCONSV10_RC610 C610, SPEDMODELOESCRT_SME SME
               WHERE C610.SMECODIGO = SME.SME_CODIGO
              --REGISTRO E113
              UNION
              SELECT E113.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDINFDAJAICMSV10_RE113 E113, SPEDMODELOESCRT_SME SME
               WHERE E113.SMECODIGO = SME.SME_CODIGO
              --REGISTRO E531
              UNION
              SELECT E31.E31_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL           AS CDITEMPATRIMONIAL,
                     NULL           AS CDANEXOITPATRIMONIAL
                FROM EFDREGISTROE531_E31 E31, SPEDMODELOESCRT_SME SME
               WHERE E31.SMECODIGO = SME.SME_CODIGO
              --REGISTRO C370
              UNION
              SELECT C370.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDITDOCV10_RC370 C370, SPEDMODELOESCRT_SME SME
               WHERE C370.SMECODIGO = SME.SME_CODIGO
              --REGISTRO C510
              UNION
              SELECT C510.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDITNFCONSUMOV10_RC510 C510, SPEDMODELOESCRT_SME SME
               WHERE C510.SMECODIGO = SME.SME_CODIGO
              --REGISTRO D110
              UNION
              SELECT D110.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDITDCNFSRVTRV10_RD110 D110, SPEDMODELOESCRT_SME SME
               WHERE D110.SMECODIGO = SME.SME_CODIGO
              --REGISTRO D510
              UNION
              SELECT D510.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDITNFSRVCOMV10_RD510 D510, SPEDMODELOESCRT_SME SME
               WHERE D510.SMECODIGO = SME.SME_CODIGO
              --REGISTRO 1105
              UNION
              SELECT R1105.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDDOCEXPORTV10_R1105 R1105, SPEDMODELOESCRT_SME SME
               WHERE R1105.SMECODIGO = SME.SME_CODIGO
              --REGISTRO C197
              UNION
              SELECT C197.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDOBSLANCFISCV10_RC197 C197, SPEDMODELOESCRT_SME SME
               WHERE C197.SMECODIGO = SME.SME_CODIGO
              --REGISTRO G140
              UNION
              SELECT G140.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDITDOCFISCALV10_RG140 G140, SPEDMODELOESCRT_SME SME
               WHERE G140.SMECODIGO = SME.SME_CODIGO
              --REGISTRO C495 - Resumo Mensal dos Itens por ECF
              UNION
              SELECT C495.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDRESMESITECFV10_RC495 C495, SPEDMODELOESCRT_SME SME
               WHERE C495.SMECODIGO = SME.SME_CODIGO
              --REGISTRO 1400 Valores Agregados
              UNION
              SELECT R1400.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDINFVALAGREGV10_1400 R1400, SPEDMODELOESCRT_SME SME
               WHERE R1400.SMECODIGO = SME.SME_CODIGO
              --REGISTRO 1105
              UNION
              SELECT R1105.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDDOCEXPORTV10_R1105 R1105, SPEDMODELOESCRT_SME SME
               WHERE R1105.SMECODIGO = SME.SME_CODIGO
              --REGISTRO D197
              UNION
              SELECT D197.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDOBSLANCFISCV10_RD197 D197, SPEDMODELOESCRT_SME SME
               WHERE D197.SMECODIGO = SME.SME_CODIGO
              UNION
              SELECT E240.COD_ITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM SPEDEFDINAJAPICMSTV10_RE240 E240, SPEDMODELOESCRT_SME SME
               WHERE E240.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K200
              UNION
              SELECT K200.K02_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK200_K02 K200, SPEDMODELOESCRT_SME SME
               WHERE K200.SMECODIGO = SME.SME_CODIGO
            --REGISTRO K210
              UNION
              SELECT K210.K10_CDITEMORI AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK210_K10 K210, SPEDMODELOESCRT_SME SME
               WHERE K210.SMECODIGO = SME.SME_CODIGO
            --REGISTRO K215
              UNION
              SELECT K215.K11_CDITEMDESTINO AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK215_K11 K215, SPEDMODELOESCRT_SME SME
               WHERE K215.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K220 - K03_CDITEMORI
              UNION
              SELECT K220.K03_CDITEMORI AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK220_K03 K220, SPEDMODELOESCRT_SME SME
               WHERE K220.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K220 -
              UNION
              SELECT K220.K03_CDITEMDEST AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK220_K03 K220, SPEDMODELOESCRT_SME SME
               WHERE K220.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K230
              UNION
              SELECT K230.K04_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK230_K04 K230, SPEDMODELOESCRT_SME SME
               WHERE K230.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K235
              UNION
              SELECT K235.K05_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK235_K05 K235, SPEDMODELOESCRT_SME SME
               WHERE K235.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K235
              UNION
              SELECT K235.K05_CDINSSUBST AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK235_K05 K235, SPEDMODELOESCRT_SME SME
               WHERE K235.SMECODIGO = SME.SME_CODIGO
                     AND K235.K05_CDINSSUBST IS NOT NULL
              --REGISTRO K250
              UNION
              SELECT K250.K06_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK250_K06 K250, SPEDMODELOESCRT_SME SME
               WHERE K250.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K255
              UNION
              SELECT K255.K07_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK255_K07 K255, SPEDMODELOESCRT_SME SME
               WHERE K255.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K255
              UNION
              SELECT K255.K07_CDINSSUBST AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK255_K07 K255, SPEDMODELOESCRT_SME SME
               WHERE K255.SMECODIGO = SME.SME_CODIGO
                     AND K255.K07_CDINSSUBST IS NOT NULL
              --REGISTRO K260
              UNION
              SELECT K260.K12_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK260_K12 K260, SPEDMODELOESCRT_SME SME
               WHERE K260.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K265
              UNION
              SELECT K265.K13_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK265_K13 K265, SPEDMODELOESCRT_SME SME
               WHERE K265.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K270
              UNION
              SELECT K270.K14_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK270_K14 K270, SPEDMODELOESCRT_SME SME
               WHERE K270.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K275
              UNION
              SELECT K275.K15_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK275_K15 K275, SPEDMODELOESCRT_SME SME
               WHERE K275.SMECODIGO = SME.SME_CODIGO
              --REGISTRO K275
              UNION
              SELECT K275.K15_CDINSSUBST AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK275_K15 K275, SPEDMODELOESCRT_SME SME
               WHERE K275.SMECODIGO = SME.SME_CODIGO
                   AND  K275.K15_CDINSSUBST IS NOT NULL
              --REGISTRO K280
              UNION
              SELECT K280.K16_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLK280_K16 K280, SPEDMODELOESCRT_SME SME
               WHERE K280.SMECODIGO = SME.SME_CODIGO
              UNION
              --REGISTRO E313
              SELECT E313.E04_CDITEM AS CODITEM,
                     SME.SME_CODIGO AS SMECODIGO,
                     NULL AS CDITEMPATRIMONIAL,
                     NULL AS CDANEXOITPATRIMONIAL
                FROM EFD_ICMSIPIBLE313_E04 E313, SPEDMODELOESCRT_SME SME
               WHERE E313.SMECODIGO = SME.SME_CODIGO
                )
    GROUP BY CODITEM,
             SMECODIGO,
             CDITEMPATRIMONIAL,
             CDANEXOITPATRIMONIAL)

/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENUFRETEMANUTENCAODOCFISSTR_2018C100_EXTENSO', '0', 'Contrata��o do Frete por conta do Remetente(CIF)')
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENUFRETEMANUTENCAODOCFISSTR_2018C100_EXTENSO', '1', 'Contrata��o do Frete por conta do Destinat�rio(FOB)')
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENUFRETEMANUTENCAODOCFISSTR_2018C100_EXTENSO', '2', 'Contrata��o do Frete por conta de Terceiros')
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENUFRETEMANUTENCAODOCFISSTR_2018C100_EXTENSO', '3', 'Transporte Pr�prio por conta do Remetente')
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENUFRETEMANUTENCAODOCFISSTR_2018C100_EXTENSO', '4', 'Transporte Pr�prio por conta do Destinat�rio')
/

INSERT INTO TIPOENUMERADO_TENU(TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO) VALUES('TPENUFRETEMANUTENCAODOCFISSTR_2018C100_EXTENSO', '9', 'Sem Ocorr�ncia de Transporte')
/

CREATE INDEX IN1_EFDAJUSTEIPI_AJI ON EFDAJUSTEIPI_AJI (AJI_NRITDOCFIS)
/

CREATE INDEX IN2_EFDAJUSTEIPI_AJI ON EFDAJUSTEIPI_AJI (AJI_CDAJUSTE)
/

CREATE INDEX IN1_EFDAJUSTEIPIDOC_DAI ON EFDAJUSTEIPIDOC_DAI (DAI_NRAJUAPIPI)
/

CREATE INDEX IN2_EFDAJUSTEIPIDOC_DAI ON EFDAJUSTEIPIDOC_DAI (DAI_CDITEM)
/

CREATE INDEX IN3_EFDAJUSTEIPIDOC_DAI ON EFDAJUSTEIPIDOC_DAI (DAI_NRDOCFIS)
/

CREATE INDEX IN1_EFDREGISTROE531_E31 ON EFDREGISTROE531_E31 (IDREGE530)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 285611
PROMPT ======================================================================