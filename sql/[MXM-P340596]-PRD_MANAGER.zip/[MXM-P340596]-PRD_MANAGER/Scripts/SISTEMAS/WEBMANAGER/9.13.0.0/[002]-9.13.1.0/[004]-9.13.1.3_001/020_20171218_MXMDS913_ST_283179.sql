PROMPT ======================================================================
PROMPT == DEMANDA......: 283179
PROMPT == SISTEMA......: Tesouraria
PROMPT == RESPONSAVEL..: NIKOLAS DE AGUIAR PONTES
PROMPT == DATA.........: 18/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO grefiltrocampotab_fct
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'FLUXOCAIXAFIN_FCF')),
   'Somente Previsto',
   1,
   0,
   '',
   '',
   '',
   'DECODE(FLUXOCAIXAFIN_FCF.FCF_TIPO, ''P'', ''S'', ''N'')',
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'FLUXOCAIXAFIN_FCF'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'FLUXOCAIXAFIN_FCF')),
   'FLUXOCAIXAFIN_FCF.FCF_TIPO1',
   'Somente Previsto')
/

INSERT INTO grefiltrocampotab_fct
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'FLUXOCAIXAFIN_FCF')),
   'Somente Realizado',
   1,
   0,
   '',
   '',
   '',
   'DECODE(FLUXOCAIXAFIN_FCF.FCF_TIPO, ''R'', ''S'', ''N'')',
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'FLUXOCAIXAFIN_FCF'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'FLUXOCAIXAFIN_FCF')),
   'FLUXOCAIXAFIN_FCF.FCF_TIPO2',
   'Somente Realizado')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283179
PROMPT ======================================================================