PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.7_003 gerados em 08/05/2018 
PROMPT ============================================================= 

@@001_20180508_MXMDS913_EFDREINF_AJUSTE.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.7_003');

COMMIT;
