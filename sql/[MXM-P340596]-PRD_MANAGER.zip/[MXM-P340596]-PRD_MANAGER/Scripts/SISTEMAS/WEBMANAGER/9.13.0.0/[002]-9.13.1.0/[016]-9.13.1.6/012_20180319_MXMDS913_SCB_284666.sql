PROMPT ======================================================================
PROMPT == DEMANDA......: 284666
PROMPT == SISTEMA......: Contabilidade
PROMPT == RESPONSAVEL..: VICTOR SANTOS DE MELLO
PROMPT == DATA.........: 02/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRETABELARELVISAL_TRV
            (TRV_IDTABELARELVISAO, TRV_NRVISAO,
             TRV_NRTABELA, TRV_NMLISTATABREL,
             TRV_NMCONDICAOTABREL
            )
     VALUES ((SELECT MAX (TRV_IDTABELARELVISAO) + 1
                FROM GRETABELARELVISAL_TRV), (SELECT VDR_IDVISAO
                                                FROM GREVISAOTAB_VDR
                                               WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA
                                                                       FROM GRETABDICDADOS_TDR
                                                                      WHERE TDR_NMTABELA = 'MXS_USUARIO_MXU')),
             (SELECT TDR_IDTABELA
                FROM GRETABDICDADOS_TDR
               WHERE TDR_NMTABELA = 'VW_EMPCLASSESPE_VCE EMP'), 'USUEMPRESA_UEM, EMPEND_EEN',
             'MXS_USUARIO_MXU.MXU_USUARIO = USUEMPRESA_UEM.UEM_USUARIO(+) AND USUEMPRESA_UEM.UEM_EMPRESA = EMP.EMP_CODIGO(+) AND
             USUEMPRESA_UEM.UEM_EMPRESA = EMPEND_EEN.EEN_CODIGO(+) AND USUEMPRESA_UEM.UEM_FILIAL = EMPEND_EEN.EEN_CDEND(+)'
            )
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 284666
PROMPT ======================================================================