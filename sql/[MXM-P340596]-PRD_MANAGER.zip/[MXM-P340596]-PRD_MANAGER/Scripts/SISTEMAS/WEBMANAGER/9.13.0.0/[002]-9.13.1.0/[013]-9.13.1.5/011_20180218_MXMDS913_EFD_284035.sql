PROMPT ======================================================================
PROMPT == DEMANDA......: 284035
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: Camilla Batista de Lima
PROMPT == DATA.........: 16/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'GSDF003'
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES ('GSDF003', 'Lan�amendo de documento cancelado originado do m�dulo EFD n�o gera t�tulo cancelado.')
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'SDFS0142'
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES ('SDFS0142','Obra inexistente.')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 284035
PROMPT ======================================================================