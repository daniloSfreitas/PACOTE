PROMPT ======================================================================
PROMPT == DEMANDA......: 286063
PROMPT == SISTEMA......: MXM-RECRUITMENT
PROMPT == RESPONSAVEL..: PALOMA CASSIA CAMPELO DE OLIVEIRA
PROMPT == DATA.........: 06/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE RECPROCRECRUTAMENTO_PRC
ADD PRC_VBPROCESSOINTERNO NUMBER(1)
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
 'DECODE(RECCANDIDATO_CAN.PRC_VBPROCESSOINTERNO, 0, ''Externo'', ''Interno'')',
 'Tipo de processo',
  2,
 'Tipo de processo')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECPROCRECRUTAMENTO_PRC RECPROC'),
 'DECODE(RECPROC.PRC_VBPROCESSOINTERNO, 0, ''Externo'', ''Interno'')',
 'Tipo de processo',
  2,
 'Tipo de processo')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
 'DECODE(RECCANDIDATO_CAN.CAN_IDCADASTRADOPOR, ''Externo'', ''Externo'', ''Interno'')',
'Cadastro efetuado pela tela de trabalhe conosco',
  2,
'Candidato externo'
 )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Cadastro efetuado pela tela de trabalhe conosco',
             1,
             0,
             '',
             '',
             '',
             'DECODE(CAN_IDCADASTRADOPOR, ''Externo'', ''S'', ''N'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_CANDIDATOEXTERNO',
              'Cadastro efetuado pela tela de trabalhe conosco'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'Processos internos',
             1,
             0,
             '',
             '',
             '',
             'DECODE(PRC_VBPROCESSOINTERNO, ''1'', ''S'', ''N'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'RECCANDIDATO_CAN.CAN_PROCESSOINTERNO',
              'Processos internos'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'Processos externos',
             1,
             0,
             '',
             '',
             '',
             'DECODE(PRC_VBPROCESSOINTERNO, ''1'', ''N'', ''S'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'RECCANDIDATO_CAN.CAN_PROCESSOEXTERNO',
              'Processos externos'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Sexo feminino',
             1,
             0,
             '',
             '',
             '',
             'DECODE(RECCANDIDATO_CAN.CAN_CDSEXO, ''F'', ''S'', ''N'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela =  'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela =  'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_SEXOFEMININO',
              'Sexo feminino'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Sexo masculino',
             1,
             0,
             '',
             '',
             '',
             'DECODE(RECCANDIDATO_CAN.CAN_CDSEXO, ''M'', ''S'', ''N'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela =  'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela =  'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_SEXOMASCULINO',
              'Sexo masculino'
            )
/

delete from grefiltrocampotab_fct
where
FCT_NMCAMPO LIKE 'RECCANDIDATO_CAN.CAN_CDSEXO'
AND FCT_TPFILTRO = 0
AND FCT_NRVISAO = (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
 'NVL(Floor(Months_Between(SYSDATE,CAN_DTNASCIMENTO)/12),0)',
 'Idade',
  0,
 'Idade')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 286063
PROMPT ======================================================================