PROMPT ======================================================================
PROMPT == DEMANDA......: 279945
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: Sistema MANTIS - PAT 263852
PROMPT == DATA.........: 31/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO IN ('DRNT0012', 'SRNT0016', 'IDC0023', 'SDGC0111', 'RAB0042', 'IDF0032', 'SDF0177', 'IDFS0076', 'CPB0021', 'SBI0060', 'SCE0023','FS50016')
/

INSERT INTO ERROMSG_ERM VALUES ('DRNT0012', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('SRNT0016', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('IDC0023', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('SDGC0111', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('RAB0042', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('IDF0032', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('SDF0177', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('IDFS0076', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('CPB0021', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('SBI0060', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('SCE0023', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('FS50016', 'C�digo da Conta Analitica/Cont�bil Obrigat�ria.')
/

DROP FUNCTION GET_CONTACONTABILITEM
/

DROP FUNCTION GET_CONTACONTABILCLIFOR
/

DROP FUNCTION GET_CONTACONTABILIZACAO
/

DROP FUNCTION GET_CONTACONTABIL
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279945
PROMPT ======================================================================