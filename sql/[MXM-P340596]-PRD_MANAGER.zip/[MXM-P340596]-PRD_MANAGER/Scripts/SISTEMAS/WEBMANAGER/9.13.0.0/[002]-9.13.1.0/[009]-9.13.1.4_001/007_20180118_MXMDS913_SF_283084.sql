PROMPT ======================================================================
PROMPT == DEMANDA......: 283084
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: ALAN DA SILVA BATISTA
PROMPT == DATA.........: 17/01/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
VALUES (
   (SELECT MAX(cdr_idcampo)+1 FROM GRECAMPOS_CDR),
   (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'FATURAS_FAT'),
   'FATURAS_FAT.FAT_USUARIO',
   'Usu�rio da Fatura',
   0,
   'Usu�rio da Fatura')
/

insert into GRETABELARELVISAL_TRV (TRV_IDTABELARELVISAO, TRV_NRVISAO, TRV_NRTABELA, TRV_NMLISTATABREL, TRV_NMCONDICAOTABREL)
     values (
			 (SELECT MAX(TRV_IDTABELARELVISAO)+1 FROM GRETABELARELVISAL_TRV),
			 (SELECT VDR_IDVISAO
			    FROM GREVISAOTAB_VDR
			   WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA
									   FROM GRETABDICDADOS_TDR
									  WHERE TDR_NMTABELA = 'FATURAS_FAT')),
			 (SELECT TDR_IDTABELA
			    FROM GRETABDICDADOS_TDR
			   WHERE TDR_NMTABELA = 'CONDPAG_CPG'),
			 null,
			 'FATURAS_FAT.FAT_CONDPAGTO = CONDPAG_CPG.CPG_CODIGO'
			)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283084
PROMPT ======================================================================