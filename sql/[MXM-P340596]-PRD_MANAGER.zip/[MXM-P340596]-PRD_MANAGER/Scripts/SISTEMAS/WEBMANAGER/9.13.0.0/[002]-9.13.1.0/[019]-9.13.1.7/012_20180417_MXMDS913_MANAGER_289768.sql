PROMPT ======================================================================
PROMPT == DEMANDA......: 289768
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: JULIANO MENEZES
PROMPT == DATA.........: 10/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_SALDOPERIODOANTERIORIPI (PSIPI_SQAPUIPI IN NUMBER)
RETURN NUMBER
AS
VL_SD_ANT_IPI NUMBER;
VL_DEB_IPI NUMBER;
VL_CRED_IPI NUMBER;
VL_OD_IPI NUMBER;
VL_OC_IPI NUMBER;
VL_SC_IPI NUMBER;
VL_SD_IPI NUMBER;
BEGIN
VL_SD_ANT_IPI := 0;
VL_DEB_IPI := 0;
VL_CRED_IPI := 0;
VL_OD_IPI := 0;
VL_OC_IPI := 0;
VL_SC_IPI := 0;
VL_SD_IPI := 0;
  EFDPROC_APURACAO_IPI(PSIPI_SQAPUIPI, VL_SD_ANT_IPI, VL_DEB_IPI, VL_CRED_IPI , VL_OD_IPI , VL_OC_IPI , VL_SC_IPI , VL_SD_IPI);
  RETURN  VL_SC_IPI;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 289768
PROMPT ======================================================================