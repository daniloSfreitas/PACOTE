PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.7_007 gerados em 13/06/2018 
PROMPT ============================================================= 

@@000_20180613_MXMDS913_ADMDADOS_9.13.1.7_006.sql
@@001_20180613_MXMDS913_SF_292658.sql
@@002_20180613_MXMDS913_SF_293171.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.7_007');

COMMIT;
