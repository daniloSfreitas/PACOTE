/*
  Ajuste incluido conforme solicitado

De: Filipe Santos 
Enviada em: sexta-feira, 29 de dezembro de 2017 09:44
Para: Leonel Hora <leonel.hora@mxm.com.br>
Assunto: ENC: ERRO NO CADASTRO DE NOVOS FORNECEDORES - MXM WEB

Leonel, 


                Por gentileza, incluir ajuste abaixo, no pacote webmanager que foi fechado ontem.


DROP TRIGGER INSERE_FOR_SPEDPARPART_TRX;
DROP TRIGGER INS_SPEDPARPART_PPA_FOR_TRX;


 	Filipe Rocha dos Santos
MXM Sistemas
Desenvolvimento MXM-Manager
Tel.: (21) 3233-2300 
filipe.santos@mxm.com.br
----------------------------------------------
    
De: Filipe Santos 
Enviada em: sexta-feira, 22 de dezembro de 2017 11:29
Para: Alan Batista <alan.batista@mxm.com.br>
Cc: admdados <admdados@mxm.com.br>
Assunto: RES: ERRO NO CADASTRO DE NOVOS FORNECEDORES - MXM WEB

Alan, bom dia.

                O  ajuste mencionado subiu na vers�o 9.13.1.3_001 e o cliente foi atualizado com a vers�o  9.13.1.2. 

                Mesmo aplicando esse ajuste, o problema n�o seria corrigido. Existem 2 triggers espec�ficos na tabela de cadastro de fornecedores, por�m, com nomes distintos.
�	Ajuste: 
o	Elimina o trigger INTEGRA_SPED_FORNECEDOR_TRX
�	No cliente:
o	Trigger INSERE_FOR_SPEDPARPART_TRX (desabilitado);
o	Trigger INS_SPEDPARPART_PPA_FOR_TRX (habilitado);

�	Para corre��o desse problema, efetuamos a mesma corre��o  detalhada no PAT 269522. Subiremos a elimina��o desses triggers no pacote WebManager.


 	Filipe Rocha dos Santos
MXM Sistemas
Desenvolvimento MXM-Manager
Tel.: (21) 3233-2300 
filipe.santos@mxm.com.br
----------------------------------------------
 
De: Alan Batista 
Enviada em: sexta-feira, 22 de dezembro de 2017 10:36
Para: Vania Nunes <vania.nunes@mxm.com.br>; ASPBD <aspbd@mxm.com.br>
Cc: Erica Soares de Santana <erica.santana@mxm.com.br>; Leandro Melo Felgueiras <leandro.melo@mxm.com.br>
Assunto: RES: ERRO NO CADASTRO DE NOVOS FORNECEDORES - MXM WEB

Banco de dados ASP,

Favor priorizar a corre��o do PAT 283963. Ela encontra-se documentada na caixa de voc�s.

Atenciosamente,
 
 	Alan da Silva Batista
MXM Sistemas
Gerencia de Desenvolvimento de Software
Tel.: (21) 3233-2300 / (21) 98244-8833
alan.batista@ mxm.com.br
----------------------------------------------

De: Alan Batista 
Enviada em: sexta-feira, 22 de dezembro de 2017 10:31
Para: Vania Nunes <vania.nunes@mxm.com.br>
Cc: Erica Soares de Santana <erica.santana@mxm.com.br>; Leandro Melo Felgueiras <leandro.melo@mxm.com.br>
Assunto: RES: ERRO NO CADASTRO DE NOVOS FORNECEDORES - MXM WEB

V�nia,
Falando com a �rica, identificamos o problema. Trata-se de uma trigger que n�o deveria existir. Estou documentando o PAT e enviando para o ASP aplicar para resolver a quest�o.

Atenciosamente,

*/


DROP TRIGGER INSERE_FOR_SPEDPARPART_TRX
/

DROP TRIGGER INS_SPEDPARPART_PPA_FOR_TRX
/

