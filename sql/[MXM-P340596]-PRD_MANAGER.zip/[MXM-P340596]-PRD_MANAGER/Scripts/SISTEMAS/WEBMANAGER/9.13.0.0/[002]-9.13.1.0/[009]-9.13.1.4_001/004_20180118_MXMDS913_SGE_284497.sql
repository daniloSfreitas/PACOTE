PROMPT ======================================================================
PROMPT == DEMANDA......: 284497
PROMPT == SISTEMA......: Estoque
PROMPT == RESPONSAVEL..: THIAGO LUIZ SANTOS COUTINHO
PROMPT == DATA.........: 17/01/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
VALUES (
   (SELECT MAX(cdr_idcampo)+1 FROM GRECAMPOS_CDR),
   (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'NOTA_NT'),
   'NOTA_NT.NT_DOCUMENTO',
   'N�mero Documento',
   0,
   'N� Documento')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 284497
PROMPT ======================================================================