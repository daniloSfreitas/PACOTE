PROMPT ======================================================================
PROMPT == DEMANDA......: 290268
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: JULIANO MENEZES
PROMPT == DATA.........: 13/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO TIPOENUMERADO_TENU VALUES ('TPENU_CDVERSAONFE', 'NFE_4.00', 'NF-e 4.00')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 290268
PROMPT ======================================================================