PROMPT ======================================================================
PROMPT == DEMANDA......: 289839
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: ANDERSON LOPES GIOVANETTI
PROMPT == DATA.........: 17/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (35344, 'Documentos sem informa��o da chave NFE/CTE ou munic�pios de origem/destino', 'Documentos sem informa��o da chave NFE/CTE ou munic�pios de origem/destino')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('EFD', 35344, 18, 3000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35344, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35344, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35344, 'EXC')
/

CREATE OR REPLACE FUNCTION GET_CONTACONTABILESCRITURA
(PT_CDEMPRESA  IN CHAR,
PT_CDFILIAL   IN CHAR DEFAULT NULL,
PT_CDESTOQUE  IN CHAR DEFAULT NULL,
PT_CDPRODSERV IN CHAR DEFAULT NULL,
PT_OPERACAO IN CHAR,
PT_TPOPERACAO IN CHAR,
PT_GRUPO     IN CHAR DEFAULT NULL,
PT_CDPARTICIPANTE IN CHAR DEFAULT NULL,
PT_TPPARTICIPANTE IN CHAR DEFAULT NULL)
RETURN CHAR
IS
  VR_CONTACTB      SPEDDOCFIS_SDF.SDF_CONTACTB%TYPE;
  VR_GRUPOPAGREC   PARAMCUSREC_PCR.PCR_GRUPO%TYPE;
  FUNCTION GET_CONTA_GRUPOPAGREC(PT_CDGRUPO IN CHAR, PT_OPERACAO IN CHAR)
    RETURN CHAR IS
    VR_CONTACONTABIL VARCHAR2(15);
    CURSOR CS_GET_CONTA_GRPAG IS
      SELECT GPA_CTBGRUPO FROM GRPAG_GPA WHERE GPA_CDGRUPO = PT_CDGRUPO;
    CURSOR CS_GET_CONTA_GRREC IS
      SELECT GRE_CTBGRUPO FROM GRREC_GRE WHERE GRE_CDGRUPO = PT_CDGRUPO;
  BEGIN
    IF PT_OPERACAO = 'S' THEN
      BEGIN
        FOR REC_CONTA_GRREC IN CS_GET_CONTA_GRREC LOOP
          BEGIN
            VR_CONTACONTABIL := REC_CONTA_GRREC.GRE_CTBGRUPO;
          END;
        END LOOP;
      END;
    ELSE
      BEGIN
        FOR REC_CONTA_GRPAG IN CS_GET_CONTA_GRPAG LOOP
          BEGIN
            VR_CONTACONTABIL := REC_CONTA_GRPAG.GPA_CTBGRUPO;
          END;
        END LOOP;
      END;
    END IF;
    RETURN(VR_CONTACONTABIL);
  END;
  FUNCTION GET_CONTA_GRUPO_PARTICIPANTE (PTPCLIFOR IN CHAR, PCDPARTICIPANTE IN CHAR, PCDEMPRESA IN CHAR, PCDFILIAL IN CHAR) RETURN CHAR IS
    VR_CONTACONTABIL VARCHAR2(15);
    VR_CONTADOR NUMBER(9);
    CURSOR CS_GET_CONTA_GRPAG IS
        SELECT  FGI.FGI_CODEMP, FGI.FGI_CODFOR, GPA.GPA_CTBGRUPO
          FROM FGPAGIR_FGI FGI, GRPAG_GPA GPA, EMPGERAL_EMP EMP
        WHERE FGI.FGI_CODEMP = EMP.EMP_CODIGO
            AND FGI.FGI_CODGRPAG = GPA.GPA_CDGRUPO
            AND FGI.FGI_CODEMP = PCDEMPRESA
            AND FGI.FGI_CODFOR = PCDPARTICIPANTE
            AND (FGI.FGI_CODFILIAL = PCDFILIAL OR FGI_CODFILIAL IS NULL)
            AND (FGI_CODMOEDA = EMP.EMP_MOEDACOR OR FGI_CODMOEDA IS NULL)
        GROUP BY FGI.FGI_CODEMP, FGI.FGI_CODFOR, GPA.GPA_CTBGRUPO;
    CURSOR CS_GET_CONTA_GRREC IS
        SELECT  CGI.CGI_CODEMP, CGI.CGI_CODFOR, GRE.GRE_CTBGRUPO
          FROM CGRECIR_CGI CGI, GRREC_GRE GRE, EMPGERAL_EMP EMP
        WHERE CGI.CGI_CODEMP = EMP.EMP_CODIGO
            AND CGI.CGI_CODGRPAG = GRE.GRE_CDGRUPO
            AND CGI.CGI_CODEMP = PCDEMPRESA
            AND CGI.CGI_CODFOR = PCDPARTICIPANTE
            AND (CGI.CGI_CODFILIAL = PCDFILIAL  OR TRIM(CGI_CODFILIAL) IS NULL)
            AND (CGI_CODMOEDA = EMP.EMP_MOEDACOR OR CGI_CODMOEDA IS NULL)
        GROUP BY CGI.CGI_CODEMP, CGI.CGI_CODFOR, GRE.GRE_CTBGRUPO;
  BEGIN
   VR_CONTADOR := 0;
    IF PTPCLIFOR = 'C' THEN
      BEGIN
        FOR REC_CONTA_GRREC IN CS_GET_CONTA_GRREC LOOP
          BEGIN
            VR_CONTACONTABIL := REC_CONTA_GRREC.GRE_CTBGRUPO;
            VR_CONTADOR := VR_CONTADOR + 1;
            IF VR_CONTADOR > 1
             THEN BEGIN VR_CONTACONTABIL := ''; END; END IF;
          END;
        END LOOP;
      END;
    ELSE
      BEGIN
        FOR REC_CONTA_GRPAG IN CS_GET_CONTA_GRPAG LOOP
          BEGIN
            VR_CONTACONTABIL := REC_CONTA_GRPAG.GPA_CTBGRUPO;
            VR_CONTADOR := VR_CONTADOR + 1;
            IF VR_CONTADOR > 1
             THEN BEGIN VR_CONTACONTABIL := ''; END; END IF;
          END;
        END LOOP;
      END;
    END IF;
    RETURN(VR_CONTACONTABIL);
  END;
  PROCEDURE GET_CONTACONTABILITEM(PT_CDEMPRESA  IN CHAR,
                                  PT_CDESTOQUE  IN CHAR,
                                  PT_CDPRODSERV IN CHAR,
                                  PT_TPOPERACAO IN CHAR,
                                  PT_CDFILIAL   IN CHAR,
                                  PT_CONTA      IN OUT CHAR,
                                  PT_GRUPO      IN OUT CHAR,
                                  PT_TIPO       IN CHAR) IS
    VR_GRUPOPRODSERV         VARCHAR2(15);
    VR_TIPOPRODSERV          VARCHAR2(2);
    VR_GRUPOSUPERIORPRODSERV VARCHAR2(15);
    VR_QRY_CONTAITEM         LONG;
    CS_CONTAITEM             SYS_REFCURSOR;
    CURSOR CS_GET_GRUPOSUPERIOR IS
      SELECT GRT_NOSUP
        FROM GRPTIP_GRT
       WHERE GRT_TPPROD = VR_TIPOPRODSERV
         AND GRT_CODIGO = VR_GRUPOPRODSERV;
    CURSOR CS_GET_DADOSPRODSERV IS
      SELECT PRD_GRUPO, PRD_TPPROD
        FROM PRODUTO_PRD
       WHERE PRD_ITEM = PT_CDPRODSERV;
  BEGIN
    FOR REC_DADOSPRODSERV IN CS_GET_DADOSPRODSERV LOOP
      BEGIN
        VR_GRUPOPRODSERV := REC_DADOSPRODSERV.PRD_GRUPO;
        VR_TIPOPRODSERV  := REC_DADOSPRODSERV.PRD_TPPROD;
      END;
    END LOOP;
    FOR REC_GRUPOSUPERIOR IN CS_GET_GRUPOSUPERIOR LOOP
      BEGIN
        VR_GRUPOSUPERIORPRODSERV := REC_GRUPOSUPERIOR.GRT_NOSUP;
      END;
    END LOOP;
    VR_QRY_CONTAITEM := '';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  ' SELECT TRIM(PCR_CNTCUSTO), TRIM(PCR_GRUPO)                        ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '  FROM (SELECT CASE                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '              WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                       (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                       (PCR_GRTPPROD <> '' '') AND (PCR_PRODUTO <> '' '')           ';
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                AND (PCR_GRTPPROD = ''' ||  VR_GRUPOPRODSERV || ''')         ';
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                  THEN 1                                                           ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '              WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                        (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                        (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                 THEN 2                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '              WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                        (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD = '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                        (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO <> '' '')        ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                 THEN 3                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '              WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                         (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD = '' '') AND       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                         (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO <> '' '')        ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                 THEN 4                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '               WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                         (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                         (PCR_GRTPPROD <> '' '')                                      ';
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                AND (PCR_GRTPPROD = ''' ||   VR_GRUPOPRODSERV || ''')         ';
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       AND (PCR_PRODUTO = '' '')                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN 5                                                                ';
   IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      BEGIN
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '             WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       (PCR_GRTPPROD = ''' ||  VR_GRUPOSUPERIORPRODSERV || ''') AND  ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       (PCR_PRODUTO = '' '')                                    ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 THEN 6                                                                ';
      END;
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      THEN  7                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD <> '' '') AND (PCR_PRODUTO <> '' '')       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      THEN 8                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD <> '' '')                                      ';
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                AND (PCR_GRTPPROD = ''' || VR_GRUPOPRODSERV || ''')         ';
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       AND (PCR_PRODUTO = '' '')                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 THEN 9                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '') ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  THEN  10             ';
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      BEGIN
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '            WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND    ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND       ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD <> '' '') AND (PCR_GRTPPROD = ''' || VR_GRUPOSUPERIORPRODSERV || ''') AND ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_PRODUTO = '' '')                                                           ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '               THEN 11                                                                                      ';
      END;
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD = '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN 12                                                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD = '' '') AND       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN 13                                                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD <> '' '') AND (PCR_PRODUTO <> '' '')           ';
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                AND (PCR_GRTPPROD = ''' || VR_GRUPOPRODSERV || ''')         ';
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN 14                                                           ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN 15                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD = '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO <> '' '')        ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN  16                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD = '' '') AND       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO <> '' '')        ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN 17                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD <> '' '')                                      ';
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  AND (PCR_GRTPPROD = ''' ||  VR_GRUPOPRODSERV || ''')         ';
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    AND (PCR_PRODUTO = '' '')                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN 18                                                                ';
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      BEGIN
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '             WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                      (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                      (PCR_GRTPPROD = ''' ||  VR_GRUPOSUPERIORPRODSERV || ''') AND  ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                      (PCR_PRODUTO = '' '')                                    ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '               THEN 19                                                                ';
      END;
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN 20                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD <> '' '') AND (PCR_PRODUTO <> '' '')       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN 21                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD <> '' '')                                      ';
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                AND (PCR_GRTPPROD = ''' ||  VR_GRUPOPRODSERV || ''')         ';
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       AND (PCR_PRODUTO = '' '')                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN 22                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN  23 ';
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      BEGIN
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '            WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND    ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND       ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 (PCR_GRTPPROD <> '' '') AND (PCR_GRTPPROD = ''' || VR_GRUPOSUPERIORPRODSERV || ''') AND ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 (PCR_PRODUTO = '' '')                                                           ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '             THEN 24                                                                                      ';
      END;
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD = '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 THEN 25                                                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD = '' '') AND       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 THEN 26                                                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 ELSE                                                              ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  1000                                                             ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '               END ORDEM,                                                          ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '               PCR_CNTCUSTO, TPO_TIPO, PCR_GRUPO                                   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '          FROM PARAMCUSREC_PCR, TPOPER_TPO WHERE TPO_CODIGO = PCR_TPOPER           ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND PCR_EMPRESA = ''' || PT_CDEMPRESA || '''                             ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND PCR_TPOPER =  ''' || PT_TPOPERACAO || '''                            ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND (                                                                   ';
    IF PT_CDESTOQUE IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '         NVL(PCR_TPESTOQUE, '' '') = ''' ||  PT_CDESTOQUE || ''' OR                      ';
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                NVL(PCR_TPESTOQUE, '' '') = '' '')                                 ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND (                                                                   ';
    IF PT_CDFILIAL IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '         NVL(PCR_CDFILIAL, '' '') = ''' || PT_CDFILIAL || ''' OR                      ';
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                NVL(PCR_CDFILIAL, '' '') = '' '')                                             ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND (                                                                   ';
    IF VR_TIPOPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '         NVL(PCR_TIPOPROD, '' '') = ''' || VR_TIPOPRODSERV || ''' OR                    ';
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                NVL(PCR_TIPOPROD, '' '') = '' '')                                              ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND (                                                                   ';
    IF PT_CDPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '         NVL(PCR_PRODUTO, '' '') = ''' || PT_CDPRODSERV || ''' OR                       ';
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                NVL(PCR_PRODUTO, '' '') = '' '')                                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND (                                                                   ';
    IF VR_GRUPOPRODSERV IS NOT NULL THEN
      BEGIN
        IF VR_GRUPOSUPERIORPRODSERV IS NULL THEN
          VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '     NVL(PCR_GRTPPROD, '' '') = ''' || VR_GRUPOPRODSERV || ''' OR                       ';
        ELSE
          VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '     ((NVL(PCR_GRTPPROD, '' '') = ''' || VR_GRUPOPRODSERV || ''') OR (NVL(PCR_GRTPPROD, '' '') = ''' || VR_GRUPOSUPERIORPRODSERV || ''')) OR ';
        END IF;
      END;
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                NVL(PCR_GRTPPROD, '' '') = '' '')                                  ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '         ORDER BY ORDEM,                                                           ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  PCR_EMPRESA, TPO_TIPO,                                           ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  DECODE(NVL(PCR_CDFILIAL,'' ''), '' '', 1, 0),                    ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  PCR_TPOPER,                                                      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  DECODE(PCR_PRODUTO, '' '', 1, 0),                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  DECODE(PCR_GRTPPROD, '' '', 1, 0),                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  DECODE(PCR_TIPOPROD, '' '', 1, 0),                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  DECODE(PCR_TPESTOQUE, '' '', 1, 0)) A                            ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || ' WHERE ROWNUM = 1                                                                  ';
   OPEN CS_CONTAITEM FOR VR_QRY_CONTAITEM;
    LOOP
      FETCH CS_CONTAITEM
        INTO PT_CONTA, PT_GRUPO;
      EXIT WHEN CS_CONTAITEM%NOTFOUND;
    END LOOP;
    CLOSE CS_CONTAITEM;
  END;
BEGIN
   GET_CONTACONTABILITEM(PT_CDEMPRESA,
                                  PT_CDESTOQUE,
                                  PT_CDPRODSERV,
                                  PT_TPOPERACAO,
                                  PT_CDFILIAL,
                                  VR_CONTACTB,
                                  VR_GRUPOPAGREC,
                                  PT_OPERACAO);
      IF TRIM(PT_GRUPO) IS NOT NULL
       THEN VR_GRUPOPAGREC := TRIM(PT_GRUPO); END IF;
      IF TRIM(VR_CONTACTB) IS NULL AND TRIM(VR_GRUPOPAGREC) IS NOT NULL THEN
        BEGIN
          VR_CONTACTB := GET_CONTA_GRUPOPAGREC(TRIM(VR_GRUPOPAGREC), TRIM(PT_OPERACAO));
        END;
      END IF;
      IF TRIM(VR_CONTACTB) IS NULL AND TRIM(VR_GRUPOPAGREC) IS NULL THEN
        BEGIN
          VR_CONTACTB := GET_CONTA_GRUPO_PARTICIPANTE (PT_TPPARTICIPANTE, PT_CDPARTICIPANTE, PT_CDEMPRESA, PT_CDFILIAL);
        END;
      END IF;
  RETURN(TRIM(VR_CONTACTB));
END;
/

CREATE OR REPLACE FUNCTION GET_CONTACONTABILESCRITURAFIN
(PT_CDEMPRESA  IN CHAR,
PT_CDFILIAL   IN CHAR,
PT_CDPARTICIPANTE IN CHAR,
PT_DOCFISCAL IN CHAR,
PT_DTEMISSAO IN DATE,
PT_OPERACAO IN CHAR
)
RETURN CHAR
IS
VR_CONTACONTABIL VARCHAR2(15);
VR_CONTADOR NUMBER(9);
VR_SUGERIR  VARCHAR(1);
VR_CDPARAM PARAMS_PAR.PAR_CDPARAM%TYPE;
CURSOR CUR_CONTATCP IS
SELECT  GPA_CTBGRUPO AS CONTACONTABIL
  FROM (SELECT TCP_CDEMPORI , TCP_CDFILIAL, TCP_CDFOR,  TCP_DOCFISCAL, PGR_CDGRUPO, GPA_CTBGRUPO, VLR
                         , RANK() OVER (PARTITION BY TCP_CDEMPORI , TCP_CDFILIAL, TCP_CDFOR,  TCP_DOCFISCAL ORDER BY VLR DESC) ORDEM
              FROM  (SELECT TCP.TCP_CDEMPORI , TCP.TCP_CDFILIAL, TCP.TCP_CDFOR,  TCP.TCP_DOCFISCAL, PGR.PGR_CDGRUPO, GPA.GPA_CTBGRUPO, SUM(PGR.PGR_VLRGRUPO) VLR
                            FROM TITCPGR_PGR PGR, TITCP_TCP TCP, GRPAG_GPA GPA, INTMODTCP_IMP IMP,  INTEGMODULOS_ITM ITM
                          WHERE  PGR_CDFOR = TCP_CDFOR
                               AND PGR_NOTITULO = TCP_NOTITULO
                               AND PGR.PGR_CDGRUPO = GPA.GPA_CDGRUPO
                               AND GPA.GPA_CTBGRUPO IS NOT NULL
                               AND IMP.IMP_CDFOR =  TCP_CDFOR
                               AND IMP.IMP_NOTITULO = TCP_NOTITULO
                               AND IMP.IMP_SQINTEGRACAO = ITM.ITM_SQINTEGRACAO
                               AND ITM.ITM_TPINTEGRACAO IN (1, 4, 8)
                               AND TCP.TCP_DTEMISSAO = PT_DTEMISSAO
                               AND TCP.TCP_CDEMPORI = PT_CDEMPRESA
                               AND TCP.TCP_CDFILIAL = PT_CDFILIAL
                               AND TCP.TCP_CDFOR = PT_CDPARTICIPANTE
                               AND TCP.TCP_DOCFISCAL = PT_DOCFISCAL
                           GROUP BY TCP.TCP_CDEMPORI , TCP.TCP_CDFILIAL, TCP.TCP_CDFOR, TCP.TCP_DOCFISCAL, PGR.PGR_CDGRUPO, GPA.GPA_CTBGRUPO)
                ) WHERE ORDEM = 1;
CURSOR CUR_CONTATCR IS
SELECT GRE_CTBGRUPO AS CONTACONTABIL
  FROM (SELECT TCR_CDEMPORI , TCR_CDFILIAL, TCR_CDCLIENTE, TCR_DOCFISCAL, RGR_CDGRUPO, GRE_CTBGRUPO, VLR
                         , RANK() OVER (PARTITION BY TCR_CDEMPORI , TCR_CDFILIAL, TCR_CDCLIENTE, TCR_DOCFISCAL ORDER BY VLR DESC) ORDEM
              FROM  (SELECT TCR.TCR_CDEMPORI , TCR.TCR_CDFILIAL, TCR.TCR_CDCLIENTE, TCR.TCR_DOCFISCAL, RGR.RGR_CDGRUPO, GRE.GRE_CTBGRUPO, SUM(RGR.RGR_VLRGRUPO) VLR
                            FROM TITCRGR_RGR RGR, TITCR_TCR TCR, GRREC_GRE GRE, INTMODTCR_IMR IMR,  INTEGMODULOS_ITM ITM
                          WHERE RGR.RGR_CDCLIENTE = TCR.TCR_CDCLIENTE
                               AND RGR_NOTITULO = TCR_NOTITULO
                               AND RGR.RGR_CDGRUPO = GRE.GRE_CDGRUPO
                               AND GRE.GRE_CDGRUPO IS NOT NULL
                               AND IMR.IMR_CDCLIENTE =  TCR_CDCLIENTE
                               AND IMR.IMR_NOTITULO = TCR_NOTITULO
                               AND IMR.IMR_SQINTEGRACAO = ITM.ITM_SQINTEGRACAO
                               AND ITM.ITM_TPINTEGRACAO IN (0, 7)
                               AND TCR.TCR_DTEMISSAO = PT_DTEMISSAO
                               AND TCR.TCR_CDEMPORI = PT_CDEMPRESA
                               AND TCR.TCR_CDFILIAL = PT_CDFILIAL
                               AND TCR.TCR_CDCLIENTE = PT_CDPARTICIPANTE
                               AND TCR.TCR_DOCFISCAL = PT_DOCFISCAL
                           GROUP BY TCR.TCR_CDEMPORI , TCR.TCR_CDFILIAL, TCR.TCR_CDCLIENTE, TCR.TCR_DOCFISCAL, RGR.RGR_CDGRUPO, GRE.GRE_CTBGRUPO)
                ) WHERE ORDEM = 1;
BEGIN
  VR_SUGERIR := 'N';
  VR_CDPARAM :=  'wPAREFDSUGERIRCONTAAPARTIRFINANCEIRO'||PT_CDEMPRESA||PT_CDFILIAL;
  SELECT NVL(MAX(PAR_VLPARAM), 'N') INTO VR_SUGERIR FROM PARAMS_PAR WHERE PAR_CDPARAM = VR_CDPARAM;
  VR_CONTACONTABIL := '';
   IF  VR_SUGERIR = 'S' THEN
    BEGIN
       VR_CONTADOR := 0;
       IF PT_OPERACAO = 'S' THEN
         BEGIN
           FOR REC_CONTATCR IN CUR_CONTATCR LOOP
             BEGIN
               VR_CONTACONTABIL := REC_CONTATCR.CONTACONTABIL;
               VR_CONTADOR := VR_CONTADOR + 1;
               IF VR_CONTADOR > 1
                THEN BEGIN VR_CONTACONTABIL := ''; END; END IF;
             END;
           END LOOP;
         END;
       ELSE
         BEGIN
           FOR REC_CONTATCP IN CUR_CONTATCP LOOP
             BEGIN
               VR_CONTACONTABIL := REC_CONTATCP.CONTACONTABIL;
               VR_CONTADOR := VR_CONTADOR + 1;
               IF VR_CONTADOR > 1
                THEN BEGIN VR_CONTACONTABIL := ''; END; END IF;
             END;
           END LOOP;
         END;
       END IF;
    END;
   END IF;
   RETURN(VR_CONTACONTABIL);
END;
/

CREATE OR REPLACE FUNCTION GET_SALDOPERIODOANTERIORIPI (PSIPI_SQAPUIPI IN NUMBER)
RETURN NUMBER
AS
VL_SD_ANT_IPI NUMBER;
VL_DEB_IPI NUMBER;
VL_CRED_IPI NUMBER;
VL_OD_IPI NUMBER;
VL_OC_IPI NUMBER;
VL_SC_IPI NUMBER;
VL_SD_IPI NUMBER;
BEGIN
VL_SD_ANT_IPI := 0;
VL_DEB_IPI := 0;
VL_CRED_IPI := 0;
VL_OD_IPI := 0;
VL_OC_IPI := 0;
VL_SC_IPI := 0;
VL_SD_IPI := 0;
  EFDPROC_APURACAO_IPI(PSIPI_SQAPUIPI, VL_SD_ANT_IPI, VL_DEB_IPI, VL_CRED_IPI , VL_OD_IPI , VL_OC_IPI , VL_SC_IPI , VL_SD_IPI);
  RETURN  VL_SC_IPI;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 289839
PROMPT ======================================================================