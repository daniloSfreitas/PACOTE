PROMPT ======================================================================
PROMPT == DEMANDA......: 283016
PROMPT == SISTEMA......: Compras
PROMPT == RESPONSAVEL..: NIKOLAS DE AGUIAR PONTES
PROMPT == DATA.........: 11/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

DROP INDEX REQGRPAG_MDGP_IDX
/

CREATE INDEX REQGRPAG_MDGP_IDX on REQGRPAG_MDGP (MDGP_NUMERO, MDGP_DESCRICAO, MDGP_CCPAG, MDGP_CCUSTO, MDGP_SEQ)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283016
PROMPT ======================================================================