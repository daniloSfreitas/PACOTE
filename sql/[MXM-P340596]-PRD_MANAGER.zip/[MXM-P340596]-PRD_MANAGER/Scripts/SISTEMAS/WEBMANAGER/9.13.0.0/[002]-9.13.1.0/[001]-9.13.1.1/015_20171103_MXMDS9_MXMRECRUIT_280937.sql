PROMPT ======================================================================
PROMPT == DEMANDA......: 280937
PROMPT == SISTEMA......: MXM-RECRUITMENT
PROMPT == RESPONSAVEL..: PALOMA CASSIA CAMPELO DE OLIVEIRA
PROMPT == DATA.........: 01/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRETABELARELVISAL_TRV (TRV_IDTABELARELVISAO, TRV_NRVISAO, TRV_NRTABELA, TRV_NMLISTATABREL, TRV_NMCONDICAOTABREL)
VALUES
((SELECT MAX(TRV_IDTABELARELVISAO) +1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECPROCRECRUTAMENTO_PRC RECPROC')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECPROCRECRUTAMENTO_PRC RECPROC'),
 NULL, NULL)
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
                     'Data de abertura', --Descri��o do filtro na tela onde imprime o relat�rio
             0,
             1,
             '',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'RECPROC.PRC_DTCRIACAO', 'Data de abertura'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
                     'Requisitante',
             0,
             2,
             'CNTUSUARIO_USU',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'RECPROC.PRC_IDUSUARIOREQUISITANTE', 'Requisitante'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
                     'Remunera��o proposta',
             0,
             3,
             '',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'RECPROC.PRC_VLREMUNERACAO', 'Remunera��o proposta'
            )
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'RECPROC.PRC_IDRECRUTAMENTO', 'C�digo', 2,
    'C�digo')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'DECODE(RECPROC.PRC_IDRECRUTAMENTO, NULL, NULL , RECPROC.PRC_IDRECRUTAMENTO || ''  -  '' || RECPROC.PRC_DSPROCESSO)',
    'C�digo + Descri��o', 2, 'Processo')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'RECPROC.PRC_DTFINALIZACAO',
    'Encerramento', 1, 'Encerramento')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'RECPROC.PRC_DTDEADLINE',
    'Prazo da contrata��o', 1, 'Prazo contrata��o')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'RECPROC.PRC_OBSERVACOES',
    'Observa��o', 0, 'Observa��o')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'RECPROC.PRC_DSPROCESSO',
    'Descri��o', 0, 'Descri��o')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'RECPROC.PRC_VLVAGASDISPONIVEIS',
    'Quantidade de vagas dispon�veis', 2, 'Vagas dispon�veis')
/

INSERT INTO GRETABELARELVISAL_TRV (TRV_IDTABELARELVISAO, TRV_NRVISAO, TRV_NRTABELA, TRV_NMLISTATABREL, TRV_NMCONDICAOTABREL)
VALUES
(
(SELECT MAX(TRV_IDTABELARELVISAO) +1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECPROCRECRUTAMENTO_PRC RECPROC')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECFILIAL_FIL'),
 NULL, 'RECPROC.PRC_IDFILIAL = RECFILIAL_FIL.FIL_IDFILIAL')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'RECPROC.PRC_DTCRIACAO',
    'Abertura', 1, 'Abertura')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'DECODE(RECPROC.PRC_DTFINALIZACAO, NULL, ''N�o'', ''Sim'')',
    'Encerrado', 0, 'Processo encerrado')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'RECPROC.PRC_DTALTERACAO',
    'Alterado em', 0, 'Data de altera��o')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'DECODE(RECPROC.PRC_STATUSCONTRATACAO, 0, ''Sim'', ''N�o'')',
    'Contrata��o realizada', 0, 'Contrato realizado')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'RECPROC.PRC_USCRIACAO',
    'Criado por', 0, 'Criador processo')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'DECODE(RECPROC.PRC_STATUSCONTRATACAO, 0, ''Em andamento'', 1, ''Finalizado com contrata��es'', ''Finalizado sem contrata��es'')',
    'Status da contrata��o', 0, 'St. contrata��o')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC RECPROC'),
    'RECPROC.PRC_VLREMUNERACAO',
    'Valor da remunera��o', 3, 'Remunera��o')
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'Filial',
             0,
             2,
             'RECFILIAL_FIL',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECFILIAL_FIL')),
             'RECFILIAL_FIL.FIL_IDFILIAL', 'Filial'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'Aprovador',
             0,
             2,
             'CNTUSUARIO_USU',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'RECPROC.PRC_IDUSUARIOGERENTE', 'Aprovador'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'Processo criado por',
             0,
             2,
             'CNTUSUARIO_USU',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'RECPROC.PRC_USCRIACAO', 'Processo criado por'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'Processo alterado por',
             0,
             2,
             'CNTUSUARIO_USU',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'RECPROC.PRC_USALTERACAO', 'Processo alterado por'
            )
/

INSERT INTO GRETABELARELVISAL_TRV (TRV_IDTABELARELVISAO, TRV_NRVISAO, TRV_NRTABELA, TRV_NMLISTATABREL, TRV_NMCONDICAOTABREL)
VALUES
(
(SELECT MAX(TRV_IDTABELARELVISAO) +1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECPROCRECRUTAMENTO_PRC RECPROC')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECEMPRESA_EMP'),
 NULL,
'RECPROC.PRC_IDFILIAL = RECFILIAL_FIL.FIL_IDFILIAL AND RECFILIAL_FIL.FIL_IDEMPRESA = RECEMPRESA_EMP.EMP_IDEMPRESA')
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'Empresa',
             0,
             2,
             'RECEMPRESA_EMP',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECEMPRESA_EMP')),
             'RECEMPRESA_EMP.EMP_IDEMPRESA', 'Empresa'
            )
/

INSERT INTO GRETABELARELVISAL_TRV (TRV_IDTABELARELVISAO, TRV_NRVISAO, TRV_NRTABELA, TRV_NMLISTATABREL, TRV_NMCONDICAOTABREL)
VALUES
(
(SELECT MAX(TRV_IDTABELARELVISAO) +1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECPROCRECRUTAMENTO_PRC RECPROC')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECDEPARTAMENTO_DEP'),
 NULL, 'RECPROC.PRC_IDDEPARTAMENTO = RECDEPARTAMENTO_DEP.DEP_IDDEPARTAMENTO')
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'Departamento',
             0,
             2,
             'RECDEPARTAMENTO_DEP',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECDEPARTAMENTO_DEP')),
             'RECDEPARTAMENTO_DEP.DEP_IDDEPARTAMENTO', 'Departamento'
            )
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECDEPARTAMENTO_DEP'),
    'DECODE(RECDEPARTAMENTO_DEP.DEP_IDDEPARTAMENTO, NULL, NULL, RECDEPARTAMENTO_DEP.DEP_IDDEPARTAMENTO || '' - '' || RECDEPARTAMENTO_DEP.DEP_NMDEPARTAMENTO)',
    'C�digo + Descri��o', 0, 'Departamento')
/

Insert into GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
 Values
   ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECDEPARTAMENTO_DEP'),
    'RECDEPARTAMENTO_DEP.DEP_IDDEPARTAMENTO',
    'Id do departamento', 0, 'Id. departamento')
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPO = 'Nome do departamento'
WHERE CDR_DSCAMPOTABELA = 'RECDEPARTAMENTO_DEP.DEP_NMDEPARTAMENTO'
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'Processo',
             0,
             2,
             'RECPROCRECRUTAMENTO_PRC',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'RECPROC.PRC_IDRECRUTAMENTO', 'Processo de recrutamento'
            )
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280937
PROMPT ======================================================================