PROMPT ======================================================================
PROMPT == DEMANDA......: 280374
PROMPT == SISTEMA......: MXM-RECRUITMENT
PROMPT == RESPONSAVEL..: RODRIGO SCHOTT CARDOSO
PROMPT == DATA.........: 20/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRETABDICDADOS_TDR (TDR_IDTABELA, TDR_NMTABELA, TDR_DSTABELA, TDR_NRFORCARJOIN)
VALUES ((SELECT MAX(TDR_IDTABELA)+1 FROM GRETABDICDADOS_TDR),'RECCARGO_CAR', 'Cargo', 0)
/

INSERT INTO GRETABDICDADOS_TDR (TDR_IDTABELA, TDR_NMTABELA, TDR_DSTABELA, TDR_NRFORCARJOIN)
VALUES ((SELECT MAX(TDR_IDTABELA)+1 FROM GRETABDICDADOS_TDR),'VW_RECCARGO_CAR', 'Cargo', 0)
/

CREATE OR REPLACE FORCE VIEW VW_RECCARGO_CAR (
                                       CAR_IDCARGO,
                                       CAR_NMCARGO,
                                       REC_IDUSUARIOCRIACAO,
                                       REC_IDUSUARIOALTERACAO,
                                       REC_DTCRIACAO,
                                       REC_DTALTERACAO)
AS SELECT CAR_IDCARGO, CAR_NMCARGO,
          REC_IDUSUARIOCRIACAO, REC_IDUSUARIOALTERACAO,
          REC_DTCRIACAO, REC_DTALTERACAO
     FROM RECCARGO_CAR
/

INSERT INTO GRETABELARELVISAL_TRV (TRV_IDTABELARELVISAO, TRV_NRVISAO, TRV_NRTABELA,TRV_NMLISTATABREL, TRV_NMCONDICAOTABREL)
VALUES
((SELECT MAX(TRV_IDTABELARELVISAO) +1 FROM GRETABELARELVISAL_TRV),
  (SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECPROCRECRUTAMENTO_PRC')),
  (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='VW_RECCARGO_CAR'),
   NULL,
  'RECPROCRECRUTAMENTO_PRC.PRC_IDCARGO = VW_RECCARGO_CAR.CAR_IDCARGO ' )
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO, CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
 (SELECT MAX(CDR_IDCAMPO) +1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='VW_RECCARGO_CAR'),
 'VW_RECCARGO_CAR.CAR_NMCARGO'
 ,'Nome do cargo',0,'Nm. cargo')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO, CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
 (SELECT MAX(CDR_IDCAMPO) +1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='VW_RECCARGO_CAR'),
 'DECODE( VW_RECCARGO_CAR.CAR_IDCARGO, NULL, NULL , VW_RECCARGO_CAR.CAR_IDCARGO || ''  -  '' || VW_RECCARGO_CAR.CAR_NMCARGO )'
 ,'C�digo + Descri��o',0,'Cargo')
/

UPDATE GRETABELARELVISAL_TRV
 SET TRV_NMCONDICAOTABREL = 'RECENTREVISTA_ENT.ENT_IDENTREVISTADOR = USUARIOENTREVISTADOR.USU_IDUSUARIO (+)'
 WHERE TRV_NMCONDICAOTABREL = 'RECENTREVISTA_ENT.ENT_IDENTREVISTADOR = USUARIOENTREVISTADOR.USU_IDUSUARIO'
/

DELETE FROM GRECAMPOS_CDR WHERE CDR_DSCAMPOTABELA = 'RECPROCRECRUTAMENTO_PRC.PRC_IDCARGO'
/

UPDATE grefiltrocampotab_fct
   SET FCT_DSFILTRO = 'Candidato ex-funcion�rio',
          fct_dsfiltrocabecalho = 'Candidato ex-funcion�rio'
 WHERE FCT_NMCAMPO  = 'RECCANDIDATO_CAN.CAN_VBTRABALHOU'
     AND FCT_TPFILTRO = 1
     AND FCT_NRVISAO  = (SELECT vdr_idvisao
                                         FROM grevisaotab_vdr
                                       WHERE vdr_nrtabela     = (SELECT tdr_idtabela
                                                                                FROM gretabdicdados_tdr
                                                                              WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPO = 'Prazo da contrata��o'
WHERE CDR_DSCAMPOTABELA = 'RECPROCRECRUTAMENTO_PRC.PRC_DTDEADLINE'
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPOTABELACABECALHO = 'Departamento'
WHERE CDR_DSCAMPOTABELA = 'RECDEPARTAMENTO_DEP.DEP_NMDEPARTAMENTO'
/

UPDATE GRECAMPOS_CDR
   SET CDR_DSCAMPOTABELACABECALHO = 'C�digo',
                       CDR_DSCAMPO = 'C�digo'
 WHERE CDR_DSCAMPOTABELA = 'RECPROCRECRUTAMENTO_PRC.PRC_IDRECRUTAMENTO'
/

UPDATE GRECAMPOS_CDR
   SET CDR_DSCAMPOTABELACABECALHO = 'Abertura',
                       CDR_DSCAMPO = 'Abertura'
 WHERE CDR_DSCAMPOTABELA = 'RECPROCRECRUTAMENTO_PRC.PRC_DTCRIACAO'
/

UPDATE GRECAMPOS_CDR
   SET CDR_DSCAMPOTABELACABECALHO = 'Encerramento',
                       CDR_DSCAMPO = 'Encerramento'
 WHERE CDR_DSCAMPOTABELA = 'RECPROCRECRUTAMENTO_PRC.PRC_DTFINALIZACAO'
/

UPDATE GRECAMPOS_CDR
   SET CDR_DSCAMPOTABELACABECALHO = 'Documento'
 WHERE CDR_DSCAMPOTABELA = 'RECCANDIDATO_CAN.CAN_DSDOCUMENTO'
/

UPDATE GRECAMPOS_CDR
   SET CDR_DSCAMPO = 'C�digo + Nome'
 WHERE CDR_DSCAMPOTABELA = 'DECODE( RECCANDIDATO_CAN.CAN_IDCANDIDATO, NULL, NULL , RECCANDIDATO_CAN.CAN_IDCANDIDATO || ''  -  '' || RECCANDIDATO_CAN.CAN_NMCANDIDATO )'
/

INSERT INTO GREVISAOTAB_VDR (VDR_IDVISAO,VDR_NRTABELA,VDR_CDSISTEMA,VRD_DSVISAO,VRD_NRFUNCAO)
VALUES (
(SELECT MAX(VDR_IDVISAO) +1 FROM GREVISAOTAB_VDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
'MXMRECRUIT',
'Candidato',
'11808')
/

INSERT INTO GRETABELARELVISAL_TRV (TRV_IDTABELARELVISAO, TRV_NRVISAO, TRV_NRTABELA, TRV_NMLISTATABREL, TRV_NMCONDICAOTABREL)
VALUES (
(SELECT MAX(TRV_IDTABELARELVISAO) +1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
NULL,
NULL)
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES (
     (SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Candidato',
             0,
             2,
             'RECCANDIDATO_CAN',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_IDCANDIDATO',
             'Candidato' )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES (
     (SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Alterado por',
             0,
             2,
             'CNTUSUARIO_USU',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_USALTERADOPOR',
             'Alterado por' )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES (
     (SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Cadastrado por',
             0,
             2,
             'CNTUSUARIO_USU',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_IDCADASTRADOPOR',
             'Cadastrado por' )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES (
     (SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Candidato ativo',
             1,
             0,
             'RECCANDIDATO_CAN',
             '',
             '',
             'DECODE(CAN_VBINATIVACAO, 0, ''S'', ''N'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_VBINATIVACAO',
             'Candidato ativo' )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES (
     (SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Ex-funcion�rio',
             1,
             0,
             'RECCANDIDATO_CAN',
             '',
             '',
             'DECODE(CAN_VBINATIVACAO, 0, ''N'', ''S'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_VBTRABALHOU',
             'Ex-funcion�rio' )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES (
     (SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Nacionalidade',
             0,
             0,
             '',
             '',
             '',
             '',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_DSPAIS',
             'Nacionalidade' )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES (
     (SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Nascimento',
             0,
             1,
             '',
             '',
             '',
             '',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_DTNASCIMENTO',
             'Nascimento' )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES (
     (SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Profiss�o',
             0,
             0,
             '',
             '',
             '',
             '',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_DSPROFISSAO',
             'Profiss�o' )
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280374
PROMPT ======================================================================