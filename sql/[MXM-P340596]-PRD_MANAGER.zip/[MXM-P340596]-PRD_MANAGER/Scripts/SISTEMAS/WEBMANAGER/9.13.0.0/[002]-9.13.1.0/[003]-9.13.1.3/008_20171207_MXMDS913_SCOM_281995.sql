PROMPT ======================================================================
PROMPT == DEMANDA......: 281995
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: WANDER ANJOS COSTA SILVA
PROMPT == DATA.........: 29/11/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='MOVIST_MST'),
'MOVIST_MST.MST_DTCOMPETENCIA','Data Compet�ncia',1,'Compet�ncia')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 281995
PROMPT ======================================================================