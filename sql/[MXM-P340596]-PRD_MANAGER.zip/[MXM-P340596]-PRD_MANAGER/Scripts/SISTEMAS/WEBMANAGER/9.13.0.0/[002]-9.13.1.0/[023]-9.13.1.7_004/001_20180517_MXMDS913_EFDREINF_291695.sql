PROMPT ======================================================================
PROMPT == DEMANDA......: 291695
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: KAROLLYNE MENDES DA SILVA
PROMPT == DATA.........: 17/05/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27649, 'Consulta de XML de eventos', 'Consulta de XML de eventos')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('EFDREINF', 27649, 10, 2000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27649, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27649, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27649, 'EXC')
/

CREATE OR REPLACE VIEW VW_RNF2010
(tcp_cdempori, tcp_cdfilial, tcp_cdfor, for_codigo, for_nome, tcp_notitulo, tcp_dtentrada, rpc_nrfatcadobra, ief_cdstatus, ief_cdrecibo, ief_nrevento, for_cgc, rpc_nrserie, rpc_nrdocumento, tcp_dtemissao, rpc_vltitulo, tcp_obs, rpc_tpservico, rpc_cdatividade, rpi_dedm, rpi_dedt, rpi_deda, rpi_base, rpi_inss, rpi_sret, rpi_nret, rpi_baseadc2, rpi_adc2, rpi_baseadc3, rpi_adc3, rpi_baseadc4, rpi_adc4, rpi_adct, tcp_totinss, rpi_nretadc, rpi_nrprocref, trt_nrmoo, drf_perc, fco_cdobra, ief_dtenvio, rpc_dtatualizacao)
AS
SELECT tcp.tcp_cdempori,
       tcp.tcp_cdfilial,
       tcp.tcp_cdfor,
       forn.for_codigo,
       forn.for_nome,
       tcp.tcp_notitulo,
       tcp.tcp_dtentrada,
       rpc.rpc_nrfatcadobra,
       CASE
         WHEN (ief.ief_cdstatus IS NULL AND trt.trt_idtrt IS NULL) THEN
          -1
         WHEN (ief.ief_cdstatus IS NULL) THEN
          0
         ELSE
          ief.ief_cdstatus
       END AS ief_cdstatus,
       ief.ief_cdrecibo,
       ief.ief_nrevento,
       forn.for_cgc,
       rpc.rpc_nrserie,
       rpc.rpc_nrdocumento,
       tcp.tcp_dtemissao,
       NVL(rpc.rpc_vltitulo, 0),
       tcp.tcp_obs,
       rts.rts_cdtpservico AS rpc_tpservico,
       cas.cas_cdatividade AS rpc_cdatividade,
       rpi.rpi_dedm,
       rpi.rpi_dedt,
       rpi.rpi_deda,
       rpi.rpi_base,
       rpi.rpi_vlimp as rpi_inss,
       NVL(rpi.rpi_sret, 0),
       NVL(rpi.rpi_nret, 0),
       NVL(rpi.rpi_baseadc2, 0),
       NVL(rpi.rpi_adc2, 0),
       NVL(rpi.rpi_baseadc3, 0),
       NVL(rpi.rpi_adc3, 0),
       NVL(rpi.rpi_baseadc4, 0),
       NVL(rpi.rpi_adc4, 0),
       (NVL(rpi.rpi_adc2, 0) + NVL(rpi.rpi_adc3, 0) + NVL(rpi.rpi_adc4, 0)) AS rpi_adct,
       tcp.tcp_inss AS tcp_totinss,
       0 AS rpi_nretadc,
       rpi.rpi_nrprocref,
       trt_nrmoo,
       drf_perc,
       fco.fco_cdobra,
       ief_dtenvio,
       NVL(rpc_dtalteracao, rpc_dtinclusao) as rpc_dtatualizacao
  FROM titcp_tcp tcp
  JOIN emp emp ON emp.emp_codigo = tcp.tcp_cdempori
  JOIN darf_drf drf ON drf.drf_codplconta = emp.emp_codplconta
                   AND drf.drf_codigo = tcp.tcp_cdinss
  JOIN fornec_for forn ON forn.for_codigo = tcp.tcp_cdfor
                      AND forn.for_cgc IS NOT NULL
                      AND forn.for_tipessoa = 'J'
  JOIN rnftcpcomp_rpc rpc ON rpc.rpc_cdfor = tcp.tcp_cdfor
                         AND rpc.rpc_notitulo = tcp.tcp_notitulo
                         AND rpc.rpc_tprepasse IS NULL
  JOIN rnfinttpservico_rts rts ON rts.rts_idrts = rpc.rpc_nrrts
  LEFT JOIN efdspedcodativscp_cas cas ON cas.cas_idatividade =
                                         rpc.rpc_nrcas
  LEFT JOIN (SELECT rpi_nrrpc,
                    SUM(rpi_vlimp) AS rpi_vlimp,
                    SUM(rpi_base) AS rpi_base,
                    SUM(rpi_dedm) AS rpi_dedm,
                    SUM(rpi_dedt) AS rpi_dedt,
                    SUM(rpi_deda) AS rpi_deda,
                    SUM(rpi_baseadc2) AS rpi_baseadc2,
                    SUM(rpi_adc2) AS rpi_adc2,
                    SUM(rpi_baseadc3) AS rpi_baseadc3,
                    SUM(rpi_adc3) AS rpi_adc3,
                    SUM(rpi_baseadc4) AS rpi_baseadc4,
                    SUM(rpi_adc4) AS rpi_adc4,
                    SUM(rpi_sret) AS rpi_sret,
                    SUM(rpi_nret) AS rpi_nret,
                    MAX(rpi_nrprocref) AS rpi_nrprocref
               FROM (SELECT rpi_nrrpc,
                            rta_tpitemcalc AS rpi_tpcompimp,
                            DECODE(rta_tpitemcalc, 'B', rpi_vlimp, NULL) rpi_vlimp,
                            DECODE(rta_tpitemcalc, 'B', rpi_vlbaseimp, NULL) rpi_base,
                            DECODE(rta_tpitemcalc, 'M', rpi_vlbaseimp, NULL) rpi_dedm,
                            DECODE(rta_tpitemcalc, 'T', rpi_vlbaseimp, NULL) rpi_dedt,
                            DECODE(rta_tpitemcalc, 'A', rpi_vlbaseimp, NULL) rpi_deda,
                            DECODE(rta_tpitemcalc, '2', rpi_vlbaseimp, NULL) rpi_baseadc2,
                            DECODE(rta_tpitemcalc, '2', rpi_vlimp, NULL) rpi_adc2,
                            DECODE(rta_tpitemcalc, '3', rpi_vlbaseimp, NULL) rpi_baseadc3,
                            DECODE(rta_tpitemcalc, '3', rpi_vlimp, NULL) rpi_adc3,
                            DECODE(rta_tpitemcalc, '4', rpi_vlbaseimp, NULL) rpi_baseadc4,
                            DECODE(rta_tpitemcalc, '4', rpi_vlimp, NULL) rpi_adc4,
                            DECODE(rta_tpitemcalc, 'S', rpi_vlimp, NULL) rpi_sret,
                            DECODE(rta_tpitemcalc, 'N', rpi_vlimp, NULL) rpi_nret,
                            rpi_nrprocref
                       FROM rnftcpcompimp_rpi
                       JOIN rnfinttpcalcadic_rta ON rta_idrta = rpi_nrrta)
              GROUP BY rpi_nrrpc) rpi ON rpi.rpi_nrrpc = rpc.rpc_idrpc
  LEFT JOIN rnftitcpreinf_trt trt ON trt.trt_nrrpc = rpc.rpc_idrpc
  LEFT JOIN rnfinfenviosreinf_ief ief ON trt_nrief = ief.ief_idief
  LEFT JOIN fatcadobra_fco fco ON fco_idfatcadobra = rpc_nrfatcadobra
 WHERE tcp_cdinss IS NOT NULL
/

CREATE OR REPLACE VIEW VW_RNF2020
(tcr_cdempori, tcr_cdfilial, tcr_cdcliente, cli_codigo, cli_nome, tcr_notitulo, rrc_nrfatcadobra, ief_cdstatus, ief_cdrecibo, ief_nrevento, cli_cgc, rrc_nrserie, rrc_nrdocumento, tcr_dtemissao, rrc_vltitulo, tcr_obs, rrc_tpservico, rrc_cdatividade, rri_dedm, rri_dedt, rri_deda, rri_base, rri_inss, rri_sret, rri_nret, rri_baseadc2, rri_adc2, rri_baseadc3, rri_adc3, rri_baseadc4, rri_adc4, rri_adct, tcr_totinss, rri_nretadc, rri_nrprocref, tru_nrmoo, drf_perc, fco_cdobra, ief_dtenvio, rrc_dtatualizacao)
AS
SELECT tcr.tcr_cdempori,
       tcr.tcr_cdfilial,
       tcr.tcr_cdcliente,
       cli.cli_codigo,
       cli.cli_nome,
       tcr.tcr_notitulo,
       rrc.rrc_nrfatcadobra,
       CASE
         WHEN (ief.ief_cdstatus IS NULL AND tru.tru_idtru IS NULL) THEN
          -1
         WHEN (ief.ief_cdstatus IS NULL) THEN
          0
         ELSE
          ief.ief_cdstatus
       END AS ief_cdstatus,
       ief.ief_cdrecibo,
       ief.ief_nrevento,
       cli.cli_cgc,
       rrc.rrc_nrserie,
       rrc.rrc_nrdocumento,
       tcr.tcr_dtemissao,
       NVL(rrc.rrc_vltitulo, 0),
       tcr.tcr_obs,
       rts.rts_cdtpservico AS rrc_tpservico,
       cas.cas_cdatividade AS rrc_cdatividade,
       rri.rri_dedm,
       rri.rri_dedt,
       rri.rri_deda,
       rri.rri_base,
       rri.rri_vlimp as rri_inss,
       NVL(rri.rri_sret, 0),
       NVL(rri.rri_nret, 0),
       NVL(rri.rri_baseadc2, 0),
       NVL(rri.rri_adc2, 0),
       NVL(rri.rri_baseadc3, 0),
       NVL(rri.rri_adc3, 0),
       NVL(rri.rri_baseadc4, 0),
       NVL(rri.rri_adc4, 0),
       (NVL(rri.rri_adc2, 0) + NVL(rri.rri_adc3, 0) + NVL(rri.rri_adc4, 0)) AS rri_adct,
       tcr.tcr_inss AS tcr_totinss,
       0 AS rri_nretadc,
       rri.rri_nrprocref,
       tru_nrmoo,
       drf_perc,
       fco.fco_cdobra,
       ief_dtenvio,
       nvl(rrc_dtalteracao, rrc_dtinclusao) as rrc_dtatualizacao
  FROM titcr_tcr tcr
  JOIN emp emp ON emp.emp_codigo = tcr.tcr_cdempori
  JOIN darf_drf drf ON drf.drf_codplconta = emp.emp_codplconta
                   AND drf.drf_codigo = tcr.tcr_cdinss
  JOIN cliente_cli cli ON cli.cli_codigo = tcr.tcr_cdcliente
                      AND cli.cli_cgc IS NOT NULL
  JOIN rnftcrcomp_rrc rrc ON rrc.rrc_cdcliente = tcr.tcr_cdcliente
                         AND rrc.rrc_notitulo = tcr.tcr_notitulo
                         AND rrc.rrc_tprepasse IS NULL
  JOIN rnfinttpservico_rts rts ON rts.rts_idrts = rrc.rrc_nrrts
  LEFT JOIN efdspedcodativscp_cas cas ON cas.cas_idatividade =
                                         rrc.rrc_nrcas
  LEFT JOIN (SELECT rri_nrrrc,
                    SUM(rri_vlimp) AS rri_vlimp,
                    SUM(rri_base) AS rri_base,
                    SUM(rri_dedm) AS rri_dedm,
                    SUM(rri_dedt) AS rri_dedt,
                    SUM(rri_deda) AS rri_deda,
                    SUM(rri_baseadc2) AS rri_baseadc2,
                    SUM(rri_adc2) AS rri_adc2,
                    SUM(rri_baseadc3) AS rri_baseadc3,
                    SUM(rri_adc3) AS rri_adc3,
                    SUM(rri_baseadc4) AS rri_baseadc4,
                    SUM(rri_adc4) AS rri_adc4,
                    SUM(rri_sret) AS rri_sret,
                    SUM(rri_nret) AS rri_nret,
                    MAX(rri_nrprocref) AS rri_nrprocref
               FROM (SELECT rri_nrrrc,
                            rta_tpitemcalc AS rri_tpcompimp,
                            DECODE(rta_tpitemcalc, 'B', rri_vlimp, NULL) rri_vlimp,
                            DECODE(rta_tpitemcalc, 'B', rri_vlbaseimp, NULL) rri_base,
                            DECODE(rta_tpitemcalc, 'M', rri_vlbaseimp, NULL) rri_dedm,
                            DECODE(rta_tpitemcalc, 'T', rri_vlbaseimp, NULL) rri_dedt,
                            DECODE(rta_tpitemcalc, 'A', rri_vlbaseimp, NULL) rri_deda,
                            DECODE(rta_tpitemcalc, '2', rri_vlbaseimp, NULL) rri_baseadc2,
                            DECODE(rta_tpitemcalc, '2', rri_vlimp, NULL) rri_adc2,
                            DECODE(rta_tpitemcalc, '3', rri_vlbaseimp, NULL) rri_baseadc3,
                            DECODE(rta_tpitemcalc, '3', rri_vlimp, NULL) rri_adc3,
                            DECODE(rta_tpitemcalc, '4', rri_vlbaseimp, NULL) rri_baseadc4,
                            DECODE(rta_tpitemcalc, '4', rri_vlimp, NULL) rri_adc4,
                            DECODE(rta_tpitemcalc, 'S', rri_vlimp, NULL) rri_sret,
                            DECODE(rta_tpitemcalc, 'N', rri_vlimp, NULL) rri_nret,
                            rri_nrprocref
                       FROM rnftcrcompimp_rri
                       JOIN rnfinttpcalcadic_rta ON rta_idrta = rri_nrrta)
              GROUP BY rri_nrrrc) rri ON rri.rri_nrrrc = rrc.rrc_idrrc
  LEFT JOIN rnftitcrreinf_tru tru ON tru.tru_nrrrc = rrc.rrc_idrrc
  LEFT JOIN rnfinfenviosreinf_ief ief ON tru.tru_nrief = ief.ief_idief
  LEFT JOIN fatcadobra_fco fco ON fco_idfatcadobra = rrc.rrc_nrfatcadobra
 WHERE tcr_cdinss IS NOT NULL
/

CREATE OR REPLACE VIEW VW_RNF2030 AS
SELECT TCR.TCR_CDEMPORI
     , TCR.TCR_CDFILIAL
     , TCR.TCR_CDCLIENTE
     , CLI.CLI_CODIGO
     , CLI.CLI_NOME
     , TCR.TCR_NOTITULO
     , TCR.TCR_DTEMISSAO
     , TCR.TCR_OBS
     , CASE
       WHEN (IEF.IEF_CDSTATUS IS NULL AND TRU.TRU_IDTRU IS NULL) THEN -1
       WHEN (IEF.IEF_CDSTATUS IS NULL) THEN 0
       ELSE IEF.IEF_CDSTATUS END AS IEF_CDSTATUS
     , IEF.IEF_CDRECIBO
     , IEF.IEF_NREVENTO
     , CLI.CLI_CGC
     , RRC.RRC_TPREPASSE
     , RRC.RRC_DSREPASSE
     , NVL(RRC.RRC_VLTITULO, 0) AS RRC_VLTITULO
     , RRI.RRI_VLIMP AS RRI_INSS
     , RRI.RRI_NRPROCREF
     , RRI.RRI_NRET
     , TCR.TCR_INSS AS TCR_TOTINSS
     , TRU_NRMOO
     , IEF_DTENVIO
     , NVL(RRC_DTALTERACAO, RRC_DTINCLUSAO) AS RRC_DTATUALIZACAO
  FROM TITCR_TCR TCR
  JOIN EMP EMP                   ON EMP.EMP_CODIGO = TCR.TCR_CDEMPORI
  JOIN DARF_DRF DRF              ON DRF.DRF_CODPLCONTA = EMP.EMP_CODPLCONTA AND DRF.DRF_CODIGO = TCR.TCR_CDINSS
  JOIN CLIENTE_CLI CLI           ON CLI.CLI_CODIGO = TCR.TCR_CDCLIENTE AND CLI.CLI_CGC IS NOT NULL
  JOIN RNFTCRCOMP_RRC RRC        ON RRC.RRC_CDCLIENTE = TCR.TCR_CDCLIENTE AND RRC.RRC_NOTITULO = TCR.TCR_NOTITULO AND RRC.RRC_TPREPASSE IS NOT NULL
  LEFT
  JOIN (SELECT RRI_NRRRC
             , SUM(RRI_VLIMP) AS RRI_VLIMP
             , SUM(RRI_BASE) AS RRI_BASE
             , SUM(RRI_DEDM) AS RRI_DEDM
             , SUM(RRI_DEDT) AS RRI_DEDT
             , SUM(RRI_DEDA) AS RRI_DEDA
             , SUM(RRI_ADC2) AS RRI_ADC2
             , SUM(RRI_ADC3) AS RRI_ADC3
             , SUM(RRI_ADC4) AS RRI_ADC4
             , SUM(RRI_SRET) AS RRI_SRET
             , SUM(RRI_NRET) AS RRI_NRET
             , MAX (RRI_NRPROCREF) AS RRI_NRPROCREF
          FROM (SELECT RRI_NRRRC,
                       RTA_TPITEMCALC AS RRI_TPCOMPIMP,
                       DECODE(RTA_TPITEMCALC, 'B', RRI_VLIMP, NULL) RRI_VLIMP,
                       DECODE(RTA_TPITEMCALC, 'B', RRI_VLBASEIMP, NULL) RRI_BASE,
                       DECODE(RTA_TPITEMCALC, 'M', RRI_VLBASEIMP, NULL) RRI_DEDM,
                       DECODE(RTA_TPITEMCALC, 'T', RRI_VLBASEIMP, NULL) RRI_DEDT,
                       DECODE(RTA_TPITEMCALC, 'A', RRI_VLBASEIMP, NULL) RRI_DEDA,
                       DECODE(RTA_TPITEMCALC, '2', RRI_VLIMP, NULL) RRI_ADC2,
                       DECODE(RTA_TPITEMCALC, '3', RRI_VLIMP, NULL) RRI_ADC3,
                       DECODE(RTA_TPITEMCALC, '4', RRI_VLIMP, NULL) RRI_ADC4,
                       DECODE(RTA_TPITEMCALC, 'S', RRI_VLIMP, NULL) RRI_SRET,
                       DECODE(RTA_TPITEMCALC, 'N', RRI_VLIMP, NULL) RRI_NRET,
                       RRI_NRPROCREF
                  FROM RNFTCRCOMPIMP_RRI
                  JOIN RNFINTTPCALCADIC_RTA ON RTA_IDRTA = RRI_NRRTA)
                 GROUP BY RRI_NRRRC) RRI ON RRI.RRI_NRRRC = RRC.RRC_IDRRC
  LEFT
  JOIN RNFTITCRREINF_TRU TRU ON TRU.TRU_NRRRC = RRC.RRC_IDRRC
  LEFT
  JOIN RNFINFENVIOSREINF_IEF IEF ON TRU.TRU_NRIEF = IEF.IEF_IDIEF
 WHERE TCR_CDINSS IS NOT NULL
/

CREATE OR REPLACE VIEW VW_RNF2040 AS
SELECT TCP.TCP_CDEMPORI
     , TCP.TCP_CDFILIAL
     , TCP.TCP_CDFOR
     , FORN.FOR_CODIGO
     , FORN.FOR_NOME
     , TCP.TCP_NOTITULO
     , TCP.TCP_DTENTRADA
     , TCP.TCP_OBS
     , CASE
       WHEN (IEF.IEF_CDSTATUS IS NULL AND TRT.TRT_IDTRT IS NULL) THEN -1
       WHEN (IEF.IEF_CDSTATUS IS NULL) THEN 0
       ELSE IEF.IEF_CDSTATUS END AS IEF_CDSTATUS
     , IEF.IEF_CDRECIBO
     , IEF_NREVENTO
     , FORN.FOR_CGC
     , RPC.RPC_TPREPASSE
     , RPC.RPC_DSREPASSE
     , NVL(RPC.RPC_VLTITULO, 0) AS RPC_VLTITULO
     , RPI.RPI_VLIMP AS RPI_INSS
     , RPI.RPI_NRPROCREF
     , RPI.RPI_NRET
     , TCP.TCP_INSS AS TCP_TOTINSS
     , TRT_NRMOO
     , IEF_DTENVIO
     , NVL(RPC_DTALTERACAO, RPC_DTINCLUSAO) AS RPC_DTATUALIZACAO
  FROM TITCP_TCP TCP
  JOIN EMP EMP                   ON EMP.EMP_CODIGO = TCP.TCP_CDEMPORI
  JOIN DARF_DRF DRF              ON DRF.DRF_CODPLCONTA = EMP.EMP_CODPLCONTA AND DRF.DRF_CODIGO = TCP.TCP_CDINSS
  JOIN FORNEC_FOR FORN           ON FORN.FOR_CODIGO = TCP.TCP_CDFOR AND FORN.FOR_CGC IS NOT NULL AND FORN.FOR_TIPESSOA = 'J'
  JOIN RNFTCPCOMP_RPC RPC        ON RPC.RPC_CDFOR = TCP.TCP_CDFOR AND RPC.RPC_NOTITULO = TCP.TCP_NOTITULO AND RPC.RPC_TPREPASSE IS NOT NULL
  LEFT
  JOIN (SELECT RPI_NRRPC
             , SUM(RPI_VLIMP) AS RPI_VLIMP
             , SUM(RPI_BASE) AS RPI_BASE
             , SUM(RPI_DEDM) AS RPI_DEDM
             , SUM(RPI_DEDT) AS RPI_DEDT
             , SUM(RPI_DEDA) AS RPI_DEDA
             , SUM(RPI_ADC2) AS RPI_ADC2
             , SUM(RPI_ADC3) AS RPI_ADC3
             , SUM(RPI_ADC4) AS RPI_ADC4
             , SUM(RPI_SRET) AS RPI_SRET
             , SUM(RPI_NRET) AS RPI_NRET
             , MAX (RPI_NRPROCREF) AS RPI_NRPROCREF
          FROM (SELECT RPI_NRRPC,
                       RTA_TPITEMCALC AS RPI_TPCOMPIMP,
                       DECODE(RTA_TPITEMCALC, 'B', RPI_VLIMP, NULL) RPI_VLIMP,
                       DECODE(RTA_TPITEMCALC, 'B', RPI_VLBASEIMP, NULL) RPI_BASE,
                       DECODE(RTA_TPITEMCALC, 'M', RPI_VLBASEIMP, NULL) RPI_DEDM,
                       DECODE(RTA_TPITEMCALC, 'T', RPI_VLBASEIMP, NULL) RPI_DEDT,
                       DECODE(RTA_TPITEMCALC, 'A', RPI_VLBASEIMP, NULL) RPI_DEDA,
                       DECODE(RTA_TPITEMCALC, '2', RPI_VLIMP, NULL) RPI_ADC2,
                       DECODE(RTA_TPITEMCALC, '3', RPI_VLIMP, NULL) RPI_ADC3,
                       DECODE(RTA_TPITEMCALC, '4', RPI_VLIMP, NULL) RPI_ADC4,
                       DECODE(RTA_TPITEMCALC, 'S', RPI_VLIMP, NULL) RPI_SRET,
                       DECODE(RTA_TPITEMCALC, 'N', RPI_VLIMP, NULL) RPI_NRET,
                       RPI_NRPROCREF
                  FROM RNFTCPCOMPIMP_RPI
                  JOIN RNFINTTPCALCADIC_RTA ON RTA_IDRTA = RPI_NRRTA)
                 GROUP BY RPI_NRRPC) RPI ON RPI.RPI_NRRPC = RPC.RPC_IDRPC
  LEFT
  JOIN RNFTITCPREINF_TRT TRT ON TRT.TRT_NRRPC = RPC.RPC_IDRPC
  LEFT
  JOIN RNFINFENVIOSREINF_IEF IEF ON TRT.TRT_NRIEF = IEF.IEF_IDIEF
 WHERE TCP_CDINSS IS NOT NULL
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 291695
PROMPT ======================================================================