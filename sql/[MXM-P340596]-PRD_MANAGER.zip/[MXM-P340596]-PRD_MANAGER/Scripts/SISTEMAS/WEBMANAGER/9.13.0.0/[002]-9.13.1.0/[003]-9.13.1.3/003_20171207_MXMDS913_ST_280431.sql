PROMPT ======================================================================
PROMPT == DEMANDA......: 280431
PROMPT == SISTEMA......: Tesouraria
PROMPT == RESPONSAVEL..: LUANA MARIA DE SOUZA
PROMPT == DATA.........: 24/11/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_VALORCOTACAOBORDEROPAG
( PT_MoeTit IN CHAR, -- Moeda do Titulo
  PT_DtPag IN DATE, -- Data da baixa
  PT_EmpTit IN CHAR, -- Empresa do titulo
  PT_VlrCotBxEmp2m IN NUMBER, -- Valor da Cota��o da baixa da 2� moeda da empresa (TCP_VLRCOTACAOBXEMP2M)
  PT_VlrCotPrEmp2m IN NUMBER, ---- Valor da Cota��o da provis�o da 2� moeda da empresa (TCP_VLRCOTACAOPREMP2M)
  PT_VlrCotBx IN NUMBER, -- Valor da Cota��o da Baixa (TCP_VLRCOTACAOBX)
  PT_VlrCotPr IN NUMBER -- Valor da Cota��o na Provis�o (TCP_VLRCOTACAOPR)
  )
  RETURN NUMBER
IS
  VR_MDN_VALOR               MOEDIN_MDN.MDN_VALOR%TYPE;
  VR_EMP_SEGMOEDAEMP   EMPGERAL_EMP.EMP_SEGMOEDAEMP%TYPE;
  VR_VlrCot NUMBER;
  CURSOR CS_EMPRESA IS
   SELECT EMP_SEGMOEDAEMP
     FROM EMPGERAL_EMP
   WHERE EMP_CODIGO = PT_EmpTit;
  CURSOR CS_MOEDIN1 IS
    SELECT MDN_VALOR
      FROM MOEDIN_MDN
    WHERE MDN_CODIGO = PT_MoeTit
        AND MDN_DATA = PT_DtPag;
  CURSOR CS_MOEDIN2 IS
    SELECT MDN_VALOR
           FROM  MOEDIN_MDN
           WHERE MDN_CODIGO = VR_EMP_SEGMOEDAEMP
             AND MDN_DATA   =  PT_DtPag;
BEGIN
  OPEN CS_MOEDIN1;
  FETCH CS_MOEDIN1 INTO VR_MDN_VALOR;
  IF CS_MOEDIN1%NOTFOUND THEN
    OPEN CS_EMPRESA;
    FETCH CS_EMPRESA INTO VR_EMP_SEGMOEDAEMP;
    CLOSE CS_EMPRESA;
    OPEN CS_MOEDIN2;
    FETCH CS_MOEDIN2 INTO VR_MDN_VALOR;
    IF CS_MOEDIN2%NOTFOUND THEN
        IF (VR_EMP_SEGMOEDAEMP IS NOT NULL AND  PT_MoeTit <> VR_EMP_SEGMOEDAEMP)THEN
           IF PT_VlrCotBxEmp2m > 0
             THEN VR_VlrCot := PT_VlrCotBxEmp2m;
             ELSE VR_VlrCot := PT_VlrCotPrEmp2m;
           END IF;
        ELSE
           IF PT_VlrCotBx > 0
           THEN VR_VlrCot := PT_VlrCotBx;
           ELSE VR_VlrCot := PT_VlrCotPr;
           END IF;
        END IF;
    ELSE
      VR_VlrCot := VR_MDN_VALOR;
    END IF;
    CLOSE CS_MOEDIN2;
  ELSE
    VR_VlrCot := VR_MDN_VALOR;
  END IF;
  CLOSE CS_MOEDIN1;
  RETURN (VR_VlrCot);
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280431
PROMPT ======================================================================