PROMPT ======================================================================
PROMPT == DEMANDA......: 287918
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: ANDERSON MALHEIROS MARTINS
PROMPT == DATA.........: 11/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

Insert into MXS_FUNCAOSISTEMA_MXFS
   (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP)
 Values
   ('SCP', 4296, 5, 4000)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287918
PROMPT ======================================================================