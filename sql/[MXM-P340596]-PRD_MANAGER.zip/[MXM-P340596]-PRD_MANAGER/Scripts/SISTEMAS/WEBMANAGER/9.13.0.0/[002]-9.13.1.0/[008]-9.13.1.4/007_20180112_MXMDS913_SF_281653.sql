PROMPT ======================================================================
PROMPT == DEMANDA......: 281653
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: THIAGO FERREIRA BARBOSA
PROMPT == DATA.........: 28/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE ALTCLIENTE_CLI
(PCLI_CODIGO          IN CHAR,
 PCLI_NOME            IN CHAR,
 PCLI_NOMEFANT        IN CHAR,
 PCLI_FAX             IN CHAR,
 PCLI_TIPESSOA        IN CHAR,
 PCLI_ENDERECO        IN CHAR,
 PCLI_NUMENDERECO     IN CHAR DEFAULT NULL,
 PCLI_COMPENDERECO    IN CHAR DEFAULT NULL,
 PCLI_BAIRRO          IN CHAR,
 PCLI_CIDADE          IN CHAR,
 PCLI_UF              IN CHAR,
 PCLI_PAIS            IN CHAR,
 PCLI_CEP             IN CHAR,
 PCLI_TELEFONE        IN CHAR,
 PCLI_CGC             IN CHAR,
 PCLI_INSCRICAO       IN CHAR,
 PCLI_DTMOV           IN DATE,
 PCLI_DTNASC          IN DATE,
 PCLI_NAOPEDIR        IN CHAR,
 PCLI_EMAIL           IN CHAR,
 PCLI_INSCMUNIC       IN CHAR,
 PCLI_TIPOINSC        IN CHAR,
 PCLI_ATIVO           IN CHAR,
 PCLI_MICROEMPRESA    IN CHAR,
 PCLI_INSCSUFRAMA     IN CHAR,
 PCLI_ORGEXP          IN CHAR,
 PCLI_DTEXP           IN DATE,
 PCLI_PROF            IN CHAR,
 PCLI_CDNACIONALIDADE IN CHAR,
 PCLI_ESTCIV          IN CHAR,
 PCLI_DTALT           IN DATE DEFAULT SYSDATE,
 PCLI_USRALT          IN CHAR DEFAULT GET_USER_MXM,
 PCLI_GRPEMPRESARIAL  IN CHAR DEFAULT NULL,
 PCLI_CDPAIS          IN CHAR DEFAULT NULL,
 PCLI_VBPRURAL        IN CHAR DEFAULT 'N',
 PCLI_TPINDIEDEST     IN CHAR DEFAULT NULL,
 PCLI_DTINATIVO       IN DATE DEFAULT NULL)
AS
 nRows        INTEGER;
 nCursor      INTEGER;
 nPAR_DBLMXM  INTEGER;
 CURSOR PARAMS IS
  SELECT TO_NUMBER(NVL(PAR_VLPARAM,0))
   FROM PARAMS_PAR
   WHERE PAR_CDPARAM = 'wPAR_DBLMXM';
BEGIN
 UPDATE CLIENTE_CLI
    SET CLI_NOME            = PCLI_NOME,
        CLI_NOMEFANT        = PCLI_NOMEFANT,
        CLI_FAX             = PCLI_FAX,
        CLI_TIPESSOA        = PCLI_TIPESSOA,
        CLI_ENDERECO        = PCLI_ENDERECO,
        CLI_NUMENDERECO     = PCLI_NUMENDERECO,
        CLI_COMPENDERECO    = PCLI_COMPENDERECO,
        CLI_BAIRRO          = PCLI_BAIRRO,
        CLI_CIDADE          = PCLI_CIDADE,
        CLI_UF              = PCLI_UF,
        CLI_PAIS            = PCLI_PAIS,
        CLI_CEP             = PCLI_CEP,
        CLI_TELEFONE        = PCLI_TELEFONE,
        CLI_CGC             = PCLI_CGC,
        CLI_INSCRICAO       = PCLI_INSCRICAO,
        CLI_DTMOV           = PCLI_DTMOV,
        CLI_DTNASC          = PCLI_DTNASC,
        CLI_EMAIL           = PCLI_EMAIL,
        CLI_INSCMUNIC       = PCLI_INSCMUNIC,
        CLI_TIPOINSC        = PCLI_TIPOINSC,
        CLI_ATIVO           = PCLI_ATIVO,
        CLI_MICROEMPRESA    = PCLI_MICROEMPRESA,
        CLI_INSCSUFRAMA     = PCLI_INSCSUFRAMA,
        CLI_ORGEXP          = PCLI_ORGEXP,
        CLI_DTEXP           = PCLI_DTEXP,
        CLI_PROF            = PCLI_PROF,
        CLI_CDNACIONALIDADE = PCLI_CDNACIONALIDADE,
        CLI_ESTCIV          = PCLI_ESTCIV,
        CLI_DTALT           = SYSDATE,
        CLI_USRALT          = GET_USER_MXM,
        CLI_GRPEMPRESARIAL  = PCLI_GRPEMPRESARIAL,
        CLI_CDPAIS          = PCLI_CDPAIS,
        CLI_VBPRURAL        = PCLI_VBPRURAL,
        CLI_TPINDIEDEST     = PCLI_TPINDIEDEST,
        CLI_DTINATIVO       = PCLI_DTINATIVO
  WHERE CLI_CODIGO          = PCLI_CODIGO;
 -- processamentos dos links --
 OPEN  PARAMS;
 FETCH PARAMS INTO nPAR_DBLMXM;
 IF PARAMS%FOUND THEN
  nCursor := dbms_sql.open_cursor;
  WHILE nPAR_DBLMXM > 0 LOOP
   DBMS_SQL.PARSE(nCursor,
                  'UPDATE CLIENTE_CLI@DBLMXM'       || TO_CHAR(nPAR_DBLMXM)                       ||
                  '   SET CLI_NOME            = ''' || REPLACE(PCLI_NOME,CHR(39),CHR(96))         || ''',' ||
                  '       CLI_NOMEFANT        = ''' || REPLACE(PCLI_NOMEFANT,CHR(39),CHR(96))     || ''',' ||
                  '       CLI_FAX             = ''' || PCLI_FAX                                   || ''',' ||
                  '       CLI_TIPESSOA        = ''' || PCLI_TIPESSOA                              || ''',' ||
                  '       CLI_ENDERECO        = ''' || REPLACE(PCLI_ENDERECO,CHR(39),CHR(96))     || ''',' ||
                  '       CLI_NUMENDERECO     = ''' || PCLI_NUMENDERECO                           || ''',' ||
                  '       CLI_COMPENDERECO    = ''' || REPLACE(PCLI_COMPENDERECO,CHR(39),CHR(96)) || ''',' ||
                  '       CLI_BAIRRO          = ''' || REPLACE(PCLI_BAIRRO  ,CHR(39),CHR(96))     || ''',' ||
                  '       CLI_CIDADE          = ''' || REPLACE(PCLI_CIDADE  ,CHR(39),CHR(96))     || ''',' ||
                  '       CLI_UF              = ''' || PCLI_UF                                    || ''',' ||
                  '       CLI_PAIS            = ''' || PCLI_PAIS                                  || ''',' ||
                  '       CLI_CEP             = ''' || PCLI_CEP                                   || ''',' ||
                  '       CLI_TELEFONE        = ''' || PCLI_TELEFONE                              || ''',' ||
                  '       CLI_CGC             = ''' || PCLI_CGC                                   || ''',' ||
                  '       CLI_INSCRICAO       = ''' || PCLI_INSCRICAO                             || ''',' ||
                  '       CLI_DTMOV           =       :PCLI_DTMOV,'                               ||
                  '       CLI_DTNASC          =       :PCLI_DTNASC,'                              ||
                  '       CLI_EMAIL           = ''' || PCLI_EMAIL                                 || ''',' ||
                  '       CLI_INSCMUNIC       = ''' || PCLI_INSCMUNIC                             || ''',' ||
                  '       CLI_TIPOINSC        = ''' || PCLI_TIPOINSC                              || ''',' ||
                  '       CLI_ATIVO           = ''' || PCLI_ATIVO                                 || ''',' ||
                  '       CLI_MICROEMPRESA    = ''' || PCLI_MICROEMPRESA                          || ''',' ||
                  '       CLI_INSCSUFRAMA     = ''' || PCLI_INSCSUFRAMA                           || ''',' ||
                  '       CLI_ORGEXP          = ''' || PCLI_ORGEXP                                || ''',' ||
                  '       CLI_DTEXP           = ''' || PCLI_DTEXP                                 || ''',' ||
                  '       CLI_PROF            = ''' || PCLI_PROF                                  || ''',' ||
                  '       CLI_CDNACIONALIDADE = ''' || PCLI_CDNACIONALIDADE                       || ''',' ||
                  '       CLI_ESTCIV          = ''' || PCLI_ESTCIV                                || ''',' ||
                  '       CLI_DTALT           = ''' || PCLI_DTALT                                 || ''',' ||
                  '       CLI_USRALT          = ''' || PCLI_USRALT                                || ''',' ||
                  '       CLI_GRPEMPRESARIAL  = ''' || PCLI_GRPEMPRESARIAL                        || ''',' ||
                  '       CLI_CDPAIS          = ''' || PCLI_CDPAIS                                || ''',' ||
                  '       CLI_VBPRURAL        = ''' || PCLI_VBPRURAL                              || ''',' ||
                  '       CLI_TPINDIEDEST     = ''' || PCLI_TPINDIEDEST                           || ''' ' ||
                  ' WHERE CLI_CODIGO          = ''' || PCLI_CODIGO                                || ''' ',
                  nCursor);
   dbms_sql.bind_variable(nCursor, 'PCLI_DTMOV' , PCLI_DTMOV);
   dbms_sql.bind_variable(nCursor, 'PCLI_DTNASC', PCLI_DTNASC);
   nRows := dbms_sql.execute(nCursor);
   nPAR_DBLMXM := nPAR_DBLMXM - 1;
  END LOOP;
  dbms_sql.close_cursor(nCursor);
 END IF;
 CLOSE PARAMS;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 281653
PROMPT ======================================================================