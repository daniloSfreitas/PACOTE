PROMPT ======================================================================
PROMPT == DEMANDA......: 286793
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: Camilla Batista de Lima
PROMPT == DATA.........: 01/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE SPEDITDOCFISSERV_IDFS MODIFY IDFS_DESCCOMPL VARCHAR2(250)
/

ALTER TABLE TI_ARQSPEDITDOCFISSRV_TIDFS MODIFY TIDFS_DESCCOMPL VARCHAR2(250)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 286793
PROMPT ======================================================================