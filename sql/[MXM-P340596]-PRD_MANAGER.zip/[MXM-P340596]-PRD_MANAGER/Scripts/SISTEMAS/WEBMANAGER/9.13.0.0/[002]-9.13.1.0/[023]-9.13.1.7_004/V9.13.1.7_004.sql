PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.7_004 gerados em 17/05/2018 
PROMPT ============================================================= 

@@001_20180517_MXMDS913_EFDREINF_291695.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.7_004');

COMMIT;
