PROMPT ======================================================================
PROMPT == DEMANDA......: 281088
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: ANDRE LUIZ PEREIRA FONTES
PROMPT == DATA.........: 01/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGC020(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGC020         VARCHAR2(4) := 'C020';
   CURSOR CS_REGC020 IS
      SELECT SEQ1_EFDLEDFREGISTROC020_C03.NEXTVAL AS IDLEDFREGISTROC020
           , PT_IDMODESCRITURACAO AS NRLME
           , CT_REGC020 AS REG020
           , IND_OPER
           , IND_EMIT
           , CLIFOR
           , COD_PART
           , COD_MOD
           , COD_SIT
           , SER
           , NUM_DOC
           , DT_DOC
           , DT_E_S
           , COD_NAT
           , VL_DOC
           , IND_PGTO
           , VL_DESC
           , VL_MERC
           , IND_FRT
           , VL_FRT
           , VL_SEG
           , VL_OUT_DA
           , VL_BC_ICMS
           , VL_ICMS
           , VL_BC_ST
           , VL_ST
           , VL_IPI
           , COD_INF_OBS
        FROM (SELECT DECODE(TPO_TIPO, 'E', '0', '1') AS IND_OPER
                   , DECODE(SDF_EMITENTE, 'P', '0', '1') AS IND_EMIT
                   , DECODE(SDF_SITDOC, '02', '', SDF_CLIFOR) AS CLIFOR
                   , DECODE(SDF_SITDOC, '02', '', TRIM(SDF_CDCLIFOR)) AS COD_PART
                   , SDF_MODELO AS COD_MOD
                   , NVL(SDF_SITDOC, '00') AS COD_SIT
                   , SDF_SERIE AS SER
                   , SDF_DOCUMENTO AS NUM_DOC
                   , TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY') AS DT_DOC
                   , DECODE(TPO_TIPO, 'E', TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'), TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')) AS DT_E_S
                   , MAX(SDF_TPOP) AS COD_NAT
                   , SUM(ROUND(SDF_VLTOTAL, 2)) AS VL_DOC
                   , DECODE(SDF_INDPAG, 2, 1, SDF_INDPAG) AS IND_PGTO
                   , SUM(ROUND(SDF_VLTOTDESC, 2)) AS VL_DESC
                   , SUM(ROUND(SDF_VLESPEC, 2)) AS VL_MERC
                   , DECODE(SDF_INDTPFRETE,  2, 1,  9, 0,  SDF_INDTPFRETE) AS IND_FRT
                   , SUM(ROUND(SDF_VLFRETE, 2)) AS VL_FRT
                   , SUM(ROUND(SDF_VLSEGUROS, 2)) AS VL_SEG
                   , SUM(ROUND(SDF_DESPESASAC, 2)) AS VL_OUT_DA
                   , SUM(ROUND(SDF_VLBCICMS, 2)) AS VL_BC_ICMS
                   , SUM(ROUND(SDF_VLICMS, 2)) AS VL_ICMS
                   , SUM(ROUND(SDF_VLBCICMSST, 2)) AS VL_BC_ST
                   , SUM(ROUND(SDF_VLICMSST, 2)) AS VL_ST
                   , SUM(ROUND(SDF_VLIPI, 2)) AS VL_IPI
                   , '' AS COD_INF_OBS
                FROM SPEDDOCFIS_SDF, TPOPER_TPO
               WHERE SDF_TPOP = TPO_CODIGO
                 AND SDF_SQDOCFIS IN (SELECT SQDOCFIS
                                        FROM (SELECT SDF_SQDOCFIS AS SQDOCFIS
                                                   , SUM(IDF_VLICMSUFREMETENTE) AS IDF_VLICMSUFREMETENTE
                                                   , SUM(IDF_VLICMSUFDESTINO) AS IDF_VLICMSUFDESTINO
                                                FROM SPEDDOCFIS_SDF, SPEDITDOCFIS_IDF, EFDLEDFMODELOESCRIT_LME
                                               WHERE IDF_SQDOCFIS = SDF_SQDOCFIS
                                                 AND SDF_CDEMPRESA = LME_CDEMPRESA
                                                 AND SDF_CDFILIAL = LME_CDFILIAL
                                                 AND SDF_DATAESCR >= LME_DTINI
                                                 AND SDF_DATAESCR <= LME_DTFIN
                                                 AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                                                 AND SDF_MODELO IN ('01', '04', '55')
                                                 AND SDF_SITDOC <> '02'
                                              GROUP BY SDF_SQDOCFIS)
                                       WHERE ((NVL(IDF_VLICMSUFDESTINO, 0) + NVL(IDF_VLICMSUFREMETENTE, 0)) = 0))
              GROUP BY DECODE(TPO_TIPO, 'E', '0', '1')
                     , DECODE(SDF_EMITENTE, 'P', '0', '1')
                     , SDF_CLIFOR
                     , TRIM(SDF_CDCLIFOR)
                     , SDF_MODELO
                     , SDF_SITDOC
                     , SDF_SERIE
                     , SDF_DOCUMENTO
                     , TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')
                     , DECODE(TPO_TIPO, 'E', TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'), TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY'))
                     , DECODE(SDF_INDPAG, 2, 1, SDF_INDPAG)
                     , DECODE(SDF_INDTPFRETE,  2, 1,  9, 0,  SDF_INDTPFRETE));
   TYPE TP_CS_REGC020 IS TABLE OF CS_REGC020%ROWTYPE
                            INDEX BY PLS_INTEGER;
   TB_CS_REGC020      TP_CS_REGC020;
BEGIN
   OPEN CS_REGC020;
   LOOP
      FETCH CS_REGC020
        BULK COLLECT INTO TB_CS_REGC020
      LIMIT 1000;
      EXIT WHEN TB_CS_REGC020.COUNT = 0;
      FORALL I IN TB_CS_REGC020.FIRST .. TB_CS_REGC020.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROC020_C03
         VALUES TB_CS_REGC020(I);
   END LOOP;
   CLOSE CS_REGC020;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGC020%ISOPEN
         THEN
            CLOSE CS_REGC020;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCREGC020DIFAL(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGC020         VARCHAR2(4) := 'C020';
   CURSOR CS_REGC020 IS
      SELECT SEQ1_EFDLEDFREGISTROC020_C03.NEXTVAL AS IDLEDFREGISTROC020
           , PT_IDMODESCRITURACAO AS NRLME
           , CT_REGC020 AS REG020
           , IND_OPER
           , IND_EMIT
           , CLIFOR
           , COD_PART
           , COD_MOD
           , COD_SIT
           , SER
           , NUM_DOC
           , DT_DOC
           , DT_E_S
           , COD_NAT
           , VL_DOC
           , IND_PGTO
           , VL_DESC
           , VL_MERC
           , IND_FRT
           , VL_FRT
           , VL_SEG
           , VL_OUT_DA
           , VL_BC_ICMS
           , VL_ICMS
           , VL_BC_ST
           , VL_ST
           , VL_IPI
           , COD_INF_OBS
        FROM (SELECT DECODE(TPO_TIPO, 'E', '0', '1') AS IND_OPER
                   , DECODE(SDF_EMITENTE, 'P', '0', '1') AS IND_EMIT
                   , DECODE(SDF_SITDOC, '02', '', SDF_CLIFOR) AS CLIFOR
                   , DECODE(SDF_SITDOC, '02', '', TRIM(SDF_CDCLIFOR)) AS COD_PART
                   , SDF_MODELO AS COD_MOD
                   , NVL(SDF_SITDOC, '00') AS COD_SIT
                   , SDF_SERIE AS SER
                   , SDF_DOCUMENTO AS NUM_DOC
                   , TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY') AS DT_DOC
                   , DECODE(TPO_TIPO, 'E', TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'), TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')) AS DT_E_S
                   , MAX(SDF_TPOP) AS COD_NAT
                   , SUM(ROUND(SDF_VLTOTAL, 2)) AS VL_DOC
                   , DECODE(SDF_INDPAG, 2, 1, SDF_INDPAG) AS IND_PGTO
                   , SUM(ROUND(SDF_VLTOTDESC, 2)) AS VL_DESC
                   , SUM(ROUND(SDF_VLESPEC, 2)) AS VL_MERC
                   , DECODE(SDF_INDTPFRETE,  2, 1,  9, 0,  SDF_INDTPFRETE) AS IND_FRT
                   , SUM(ROUND(SDF_VLFRETE, 2)) AS VL_FRT
                   , SUM(ROUND(SDF_VLSEGUROS, 2)) AS VL_SEG
                   , SUM(ROUND(SDF_DESPESASAC, 2)) AS VL_OUT_DA
                   , SUM(ROUND(SDF_VLBCICMS, 2)) AS VL_BC_ICMS
                   , SUM(ROUND(SDF_VLICMS, 2)) AS VL_ICMS
                   , SUM(ROUND(SDF_VLBCICMSST, 2)) AS VL_BC_ST
                   , DECODE(TPO_TIPO, 'S', SUM(ROUND(IDF.IDF_VLICMSUFREMETENTE, 2)), SUM(ROUND(IDF.IDF_VLICMSUFDESTINO, 2))) AS VL_ST
                   , SUM(ROUND(SDF_VLIPI, 2)) AS VL_IPI
                   , 'DIFALEC87DF' AS COD_INF_OBS
                FROM SPEDDOCFIS_SDF
                   , TPOPER_TPO
                   , (SELECT SDF_SQDOCFIS AS SQDOCFIS
                           , SUM(IDF_VLICMSUFREMETENTE) AS IDF_VLICMSUFREMETENTE
                           , SUM(IDF_VLICMSUFDESTINO) AS IDF_VLICMSUFDESTINO
                        FROM SPEDDOCFIS_SDF, SPEDITDOCFIS_IDF, EFDLEDFMODELOESCRIT_LME
                       WHERE IDF_SQDOCFIS = SDF_SQDOCFIS
                         AND SDF_CDEMPRESA = LME_CDEMPRESA
                         AND SDF_CDFILIAL = LME_CDFILIAL
                         AND SDF_DATAESCR >= LME_DTINI
                         AND SDF_DATAESCR <= LME_DTFIN
                         AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                         AND SDF_MODELO IN ('01', '04', '55')
                         AND ((NVL(IDF_VLICMSUFDESTINO, 0) + NVL(IDF_VLICMSUFREMETENTE, 0)) > 0)
                         AND SDF_SITDOC <> '02'
                      GROUP BY SDF_SQDOCFIS) IDF
               WHERE SDF_TPOP = TPO_CODIGO
                 AND SDF_SQDOCFIS = IDF.SQDOCFIS
                 AND SDF_SQDOCFIS IN (SELECT SQDOCFIS
                                        FROM (SELECT SDF_SQDOCFIS AS SQDOCFIS
                                                   , SUM(IDF_VLICMSUFREMETENTE) AS IDF_VLICMSUFREMETENTE
                                                   , SUM(IDF_VLICMSUFDESTINO) AS IDF_VLICMSUFDESTINO
                                                FROM SPEDDOCFIS_SDF, SPEDITDOCFIS_IDF, EFDLEDFMODELOESCRIT_LME
                                               WHERE IDF_SQDOCFIS = SDF_SQDOCFIS
                                                 AND SDF_CDEMPRESA = LME_CDEMPRESA
                                                 AND SDF_CDFILIAL = LME_CDFILIAL
                                                 AND SDF_DATAESCR >= LME_DTINI
                                                 AND SDF_DATAESCR <= LME_DTFIN
                                                 AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                                                 AND SDF_MODELO IN ('01', '04', '55')
                                                 AND SDF_SITDOC <> '02'
                                              GROUP BY SDF_SQDOCFIS)
                                       WHERE ((NVL(IDF_VLICMSUFDESTINO, 0) + NVL(IDF_VLICMSUFREMETENTE, 0)) > 0))
              GROUP BY DECODE(TPO_TIPO, 'E', '0', '1')
                     , DECODE(SDF_EMITENTE, 'P', '0', '1')
                     , SDF_CLIFOR
                     , TRIM(SDF_CDCLIFOR)
                     , SDF_MODELO
                     , SDF_SITDOC
                     , SDF_SERIE
                     , SDF_DOCUMENTO
                     , TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')
                     , DECODE(TPO_TIPO, 'E', TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'), TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY'))
                     , DECODE(SDF_INDPAG, 2, 1, SDF_INDPAG)
                     , DECODE(SDF_INDTPFRETE,  2, 1,  9, 0,  SDF_INDTPFRETE)
                     , TPO_TIPO);
   TYPE TP_CS_REGC020 IS TABLE OF CS_REGC020%ROWTYPE
                            INDEX BY PLS_INTEGER;
   TB_CS_REGC020      TP_CS_REGC020;
BEGIN
   OPEN CS_REGC020;
   LOOP
      FETCH CS_REGC020
        BULK COLLECT INTO TB_CS_REGC020
      LIMIT 1000;
      EXIT WHEN TB_CS_REGC020.COUNT = 0;
      FORALL I IN TB_CS_REGC020.FIRST .. TB_CS_REGC020.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROC020_C03
         VALUES TB_CS_REGC020(I);
   END LOOP;
   CLOSE CS_REGC020;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGC020%ISOPEN
         THEN
            CLOSE CS_REGC020;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGE020(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGE020         VARCHAR2(4) := 'E020';
   CURSOR CS_REGE020 IS
      SELECT SEQ1_EFDLEDFREGISTROE020_E02.NEXTVAL AS IDLEDFREGISTROE020
           , PT_IDMODESCRITURACAO AS NRLME
           , CT_REGE020 AS REGE020
           , IND_OPER
           , IND_EMIT
           , CLIFOR
           , COD_PART
           , COD_MOD
           , COD_SIT
           , SER
           , NUM_DOC
           , DT_DOC
           , NUM_LCTO
           , DT_E_S
           , VL_CONT
           , VL_BC_ICMS
           , VL_ICMS
           , VL_ST
           , VL_COMPL
           , IND_COMPL
           , VL_ISNT_ICMS
           , VL_OUT_ICMS
           , VL_BC_IPI
           , VL_IPI
           , VL_ISNT_IPI
           , VL_OUT_IPI
           , COD_INF_OBS
        FROM (SELECT DECODE(TPO_TIPO, 'E', '0', '1') AS IND_OPER
                   , DECODE(SDF_EMITENTE, 'P', '0', '1') AS IND_EMIT
                   , SDF_CLIFOR AS CLIFOR
                   , TRIM(SDF_CDCLIFOR) AS COD_PART
                   , SDF_MODELO AS COD_MOD
                   , SDF_SITDOC AS COD_SIT
                   , SDF_SERIE AS SER
                   , SDF_DOCUMENTO AS NUM_DOC
                   , TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY') AS DT_DOC
                   , 0 AS NUM_LCTO
                   , DECODE(TPO_TIPO, 'E', TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'), TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')) AS DT_E_S
                   , SUM(ROUND(IDF_VLCONTABIL, 2)) AS VL_CONT
                   , SUM(ROUND(IDF_VLBCICMS, 2)) AS VL_BC_ICMS
                   , SUM(ROUND(IDF_VLICMS, 2)) AS VL_ICMS
                   , SUM(ROUND(IDF_VLBCICMSST, 2)) AS VL_ST
                   , SDF_VLTOTALCOMPLEMENTAR AS VL_COMPL
                   , NVL(SDF_TPINDCOMPLEMENTAR, '00') AS IND_COMPL
                   , SUM(IDF_VLBIICMS) AS VL_ISNT_ICMS
                   , SUM(IDF_VLBOICMS) AS VL_OUT_ICMS
                   , SUM(IDF_VLBCIPI) AS VL_BC_IPI
                   , SUM(IDF_VLIPI) AS VL_IPI
                   , SUM(IDF_VLBIIPI) AS VL_ISNT_IPI
                   , SUM(IDF_VLBOIPI) AS VL_OUT_IPI
                   , '' AS COD_INF_OBS
                FROM SPEDDOCFIS_SDF
                   , SPEDITDOCFIS_IDF
                   , TPOPER_TPO
               WHERE SDF_SQDOCFIS = IDF_SQDOCFIS
			     AND SDF_TPOP = TPO_CODIGO
                 AND SDF_SQDOCFIS IN (SELECT SQDOCFIS
                                        FROM (SELECT SDF_SQDOCFIS AS SQDOCFIS
                                                   , SUM(IDF_VLICMSUFREMETENTE) AS IDF_VLICMSUFREMETENTE
                                                   , SUM(IDF_VLICMSUFDESTINO) AS IDF_VLICMSUFDESTINO
                                                FROM SPEDDOCFIS_SDF, SPEDITDOCFIS_IDF, EFDLEDFMODELOESCRIT_LME
                                               WHERE IDF_SQDOCFIS = SDF_SQDOCFIS
                                                 AND SDF_CDEMPRESA = LME_CDEMPRESA
                                                 AND SDF_CDFILIAL = LME_CDFILIAL
                                                 AND SDF_DATAESCR >= LME_DTINI
                                                 AND SDF_DATAESCR <= LME_DTFIN
                                                 AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                                                 AND SDF_MODELO IN ('01', '04', '55')
                                              GROUP BY SDF_SQDOCFIS)
                                       WHERE ((NVL(IDF_VLICMSUFDESTINO, 0) + NVL(IDF_VLICMSUFREMETENTE, 0)) = 0))
              GROUP BY DECODE(TPO_TIPO, 'E', '0', '1')
                     , DECODE(SDF_EMITENTE, 'P', '0', '1')
                     , SDF_CLIFOR
                     , SDF_CDCLIFOR
                     , SDF_MODELO
                     , SDF_SITDOC
                     , SDF_SERIE
                     , SDF_DOCUMENTO
                     , TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')
                     , DECODE(TPO_TIPO, 'E', TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'), TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY'))
                     , SDF_VLTOTALCOMPLEMENTAR
                     , NVL(SDF_TPINDCOMPLEMENTAR, '00'));
   TYPE TP_CS_REGE020 IS TABLE OF CS_REGE020%ROWTYPE INDEX BY PLS_INTEGER;
   TB_CS_REGE020      TP_CS_REGE020;
BEGIN
   OPEN CS_REGE020;
   LOOP
      FETCH CS_REGE020 BULK COLLECT INTO TB_CS_REGE020 LIMIT 1000;
      EXIT WHEN TB_CS_REGE020.COUNT = 0;
      FORALL I IN TB_CS_REGE020.FIRST .. TB_CS_REGE020.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROE020_E02 VALUES TB_CS_REGE020(I);
   END LOOP;
   CLOSE CS_REGE020;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGE020%ISOPEN
         THEN
            CLOSE CS_REGE020;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCREGE020DIFAL(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
  VR_MENSAGEM_ERRO VARCHAR2(500);
  CT_REGE020       VARCHAR2(4) := 'E020';
  CURSOR CS_REGE020 IS
    SELECT SEQ1_EFDLEDFREGISTROE020_E02.NEXTVAL AS IDLEDFREGISTROE020,
           PT_IDMODESCRITURACAO                 AS NRLME,
           CT_REGE020                           AS REGE020,
           IND_OPER,
           IND_EMIT,
           CLIFOR,
           COD_PART,
           COD_MOD,
           COD_SIT,
           SER,
           NUM_DOC,
           DT_DOC,
           NUM_LCTO,
           DT_E_S,
           VL_CONT,
           VL_BC_ICMS,
           VL_ICMS,
           VL_ST,
           VL_COMPL,
           IND_COMPL,
           VL_ISNT_ICMS,
           VL_OUT_ICMS,
           VL_BC_IPI,
           VL_IPI,
           VL_ISNT_IPI,
           VL_OUT_IPI,
           COD_INF_OBS
      FROM (SELECT DECODE(TPO_TIPO, 'E', '0', '1') AS IND_OPER,
                   DECODE(SDF_EMITENTE, 'P', '0', '1') AS IND_EMIT,
                   SDF_CLIFOR AS CLIFOR,
                   TRIM(SDF_CDCLIFOR) AS COD_PART,
                   SDF_MODELO AS COD_MOD,
                   SDF_SITDOC AS COD_SIT,
                   SDF_SERIE AS SER,
                   SDF_DOCUMENTO AS NUM_DOC,
                   TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY') AS DT_DOC,
                   0 AS NUM_LCTO,
                   DECODE(TPO_TIPO,
                          'E',
                          TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'),
                          TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')) AS DT_E_S,
                   SUM(ROUND(IDF_VLCONTABIL, 2)) AS VL_CONT,
                   SUM(ROUND(IDF_VLBCICMS, 2)) AS VL_BC_ICMS,
                   SUM(ROUND(IDF_VLICMS, 2)) AS VL_ICMS,
                   DECODE(TPO_TIPO,
                          'S',
                          SUM(ROUND(IDF_VLICMSUFREMETENTE, 2)),
                          SUM(ROUND(IDF_VLICMSUFDESTINO, 2))) AS VL_ST,
                   SDF_VLTOTALCOMPLEMENTAR AS VL_COMPL,
                   NVL(SDF_TPINDCOMPLEMENTAR, '00') AS IND_COMPL,
                   SUM(IDF_VLBIICMS) AS VL_ISNT_ICMS,
                   SUM(IDF_VLBOICMS) AS VL_OUT_ICMS,
                   SUM(IDF_VLBCIPI) AS VL_BC_IPI,
                   SUM(IDF_VLIPI) AS VL_IPI,
                   SUM(IDF_VLBIIPI) AS VL_ISNT_IPI,
                   SUM(IDF_VLBOIPI) AS VL_OUT_IPI,
                   'DIFALEC87DF' AS COD_INF_OBS
              FROM SPEDDOCFIS_SDF,
                   SPEDITDOCFIS_IDF,
                   TPOPER_TPO
             WHERE SDF_SQDOCFIS = IDF_SQDOCFIS
               AND SDF_TPOP = TPO_CODIGO
                 AND SDF_SQDOCFIS IN (SELECT SQDOCFIS
                                        FROM (SELECT SDF_SQDOCFIS AS SQDOCFIS
                                                   , SUM(IDF_VLICMSUFREMETENTE) AS IDF_VLICMSUFREMETENTE
                                                   , SUM(IDF_VLICMSUFDESTINO) AS IDF_VLICMSUFDESTINO
                                                FROM SPEDDOCFIS_SDF, SPEDITDOCFIS_IDF, EFDLEDFMODELOESCRIT_LME
                                               WHERE IDF_SQDOCFIS = SDF_SQDOCFIS
                                                 AND SDF_CDEMPRESA = LME_CDEMPRESA
                                                 AND SDF_CDFILIAL = LME_CDFILIAL
                                                 AND SDF_DATAESCR >= LME_DTINI
                                                 AND SDF_DATAESCR <= LME_DTFIN
                                                 AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                                                 AND SDF_MODELO IN ('01', '04', '55')
                                              GROUP BY SDF_SQDOCFIS)
                                       WHERE ((NVL(IDF_VLICMSUFDESTINO, 0) + NVL(IDF_VLICMSUFREMETENTE, 0)) > 0))
             GROUP BY DECODE(TPO_TIPO, 'E', '0', '1'),
                      DECODE(SDF_EMITENTE, 'P', '0', '1'),
                      SDF_CLIFOR,
                      SDF_CDCLIFOR,
                      SDF_MODELO,
                      SDF_SITDOC,
                      SDF_SERIE,
                      SDF_DOCUMENTO,
                      TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY'),
                      DECODE(TPO_TIPO,
                             'E',
                             TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'),
                             TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')),
                      SDF_VLTOTALCOMPLEMENTAR,
                      NVL(SDF_TPINDCOMPLEMENTAR, '00'),
                      TPO_TIPO);
  TYPE TP_CS_REGE020 IS TABLE OF CS_REGE020%ROWTYPE INDEX BY PLS_INTEGER;
  TB_CS_REGE020 TP_CS_REGE020;
BEGIN
  OPEN CS_REGE020;
  LOOP
    FETCH CS_REGE020 BULK COLLECT
      INTO TB_CS_REGE020 LIMIT 1000;
    EXIT WHEN TB_CS_REGE020.COUNT = 0;
    FORALL I IN TB_CS_REGE020.FIRST .. TB_CS_REGE020.LAST SAVE EXCEPTIONS
      INSERT INTO EFDLEDFREGISTROE020_E02 VALUES TB_CS_REGE020 (I);
  END LOOP;
  CLOSE CS_REGE020;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      VR_MENSAGEM_ERRO := SUBSTR('Mensagem do Sistema: "' || SQLERRM,
                                 1,
                                 499) || '"';
      IF CS_REGE020%ISOPEN THEN
        CLOSE CS_REGE020;
      END IF;
      RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
    END;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 281088
PROMPT ======================================================================