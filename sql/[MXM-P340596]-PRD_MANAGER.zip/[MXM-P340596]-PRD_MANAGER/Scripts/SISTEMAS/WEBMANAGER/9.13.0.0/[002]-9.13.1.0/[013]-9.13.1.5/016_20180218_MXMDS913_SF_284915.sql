PROMPT ======================================================================
PROMPT == DEMANDA......: 284915
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: LUCIANO VARGAS DE MATTOS
PROMPT == DATA.........: 18/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRUPOCOLNOTAFISCAL_GCNF
   SET GCNF_CONDICAO = 'FAT_CDEMPRESA=DISS_CDEMPRESA(+) AND FAT_CDFILIAL=DISS_CDFILIAL(+) AND FAT_NF=DISS_NUMERO(+) AND FAT_CDEMPRESA=EEN_CODIGO AND FAT_CDFILIAL=EEN_CDEND AND EEN_CODIGO=PEMP_CDEMPRESA AND EEN_CDEND=PEMP_CDFILIAL AND PEMP_CODMUN=TMP.TMI_CODIGO'
 WHERE GCNF_CDGRUPO = 'RPS02'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 284915
PROMPT ======================================================================