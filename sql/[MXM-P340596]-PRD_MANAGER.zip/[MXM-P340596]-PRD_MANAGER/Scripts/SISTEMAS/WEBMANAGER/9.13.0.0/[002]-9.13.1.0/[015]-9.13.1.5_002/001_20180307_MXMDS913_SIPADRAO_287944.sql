/*
        07/03/2018
      Ajuste solicitado por Thiago Barbosa.
         
		O Script que consta no pacote de atualiza��o acompanha as normas e padr�es estabelecidos pela MXM sendo a aplica��o referenciando ao objeto fora do padr�o, 
		afim de evitar erro no Hash o script est� acompanhando a aplica��o e na pr�xima demanda constar� a corre��o para o padr�o estabelecido.


*/






PROMPT ======================================================================
PROMPT == DEMANDA......: 287944
PROMPT == SISTEMA......: Integra��o Padr�o
PROMPT == RESPONSAVEL..: THIAGO FERREIRA BARBOSA
PROMPT == DATA.........: 05/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_PROCESSOATIVO_INTERFACE
(
  P_CODPROCESSO  IN VARCHAR2
)
  RETURN INTEGER
IS
  VR_TOT INTEGER;
BEGIN
  /*mesmo select das trigger na ti_gera*/
  SELECT COUNT(*)
    INTO VR_TOT
    FROM TI_PROCESSOS_INTERFACE_TPI
   WHERE TPI_CODIGO = P_CODPROCESSO
     AND TPI_ATIVO = 'S'
     AND TPI_IDORIGEM IN (SELECT COALESCE(TRIM((SELECT PAR_VLPARAM
                                                 FROM PARAMS_PAR
                                                WHERE PAR_CDPARAM =
                                                      'INTEGRACAO_ORIGEM_IMPORTACAO_REST')),
                                          TRIM((SELECT PAR_VLPARAM
                                                 FROM PARAMS_PAR
                                                WHERE PAR_CDPARAM =
                                                      'INTEGRACAO_ORIGEM_IMPORTACAO')),
                                          (SELECT TO_CHAR(TOI_IDORIGEM)
                                             FROM TINORIGEMIMPORTACAO_TOI
                                            WHERE TOI_VBPROCESSASRV = 'S'
                                              AND ROWNUM = 1))
                            FROM DUAL);
  RETURN VR_TOT;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287944
PROMPT ======================================================================