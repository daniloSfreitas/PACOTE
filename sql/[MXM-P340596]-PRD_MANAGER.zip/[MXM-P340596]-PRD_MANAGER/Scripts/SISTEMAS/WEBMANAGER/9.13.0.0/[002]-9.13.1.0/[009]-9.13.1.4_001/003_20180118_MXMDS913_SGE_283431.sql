PROMPT ======================================================================
PROMPT == DEMANDA......: 283431
PROMPT == SISTEMA......: Estoque
PROMPT == RESPONSAVEL..: JOSE BARBOSA DA SILVA JUNIOR
PROMPT == DATA.........: 17/01/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE CAMPOAJUDA_CAJU
   SET CAJU_FORMATFIELD = 'dd/mm/yy'
  WHERE CAJU_CODIGO = '756'
   AND CAJU_NUMCAMPO IN('RIE_DTINICIO', 'RIE_DTFIM')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283431
PROMPT ======================================================================