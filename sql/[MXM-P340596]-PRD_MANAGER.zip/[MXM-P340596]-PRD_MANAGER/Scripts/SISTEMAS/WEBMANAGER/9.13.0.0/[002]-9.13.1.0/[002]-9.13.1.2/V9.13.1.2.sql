PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.2 gerados em 17/11/2017 
PROMPT ============================================================= 

@@001_20171117_MXMDS913_SCO_281574.sql
@@002_20171117_MXMDS913_SGV_281308.sql
@@003_20171117_MXMDS913_EFDREINF_281776.sql
@@004_20171117_MXMDS913_SF_280662.sql
@@005_20171117_MXMDS913_SCB_276476.sql
@@006_20171117_MXMDS913_EFD_280167.sql
@@007_20171117_MXMDS913_SGE_281527.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.2');

COMMIT;
