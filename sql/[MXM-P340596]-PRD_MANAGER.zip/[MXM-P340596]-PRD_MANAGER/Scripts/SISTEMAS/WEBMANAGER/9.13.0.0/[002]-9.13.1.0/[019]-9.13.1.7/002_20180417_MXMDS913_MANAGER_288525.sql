PROMPT ======================================================================
PROMPT == DEMANDA......: 288525
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: WANDER ANJOS COSTA SILVA
PROMPT == DATA.........: 28/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

Insert into MXS_FUNCAOSISTEMA_MXFS
   (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP)
 Values
   ('SCOM', 1393, 3, 1000)
/

INSERT INTO BENEFRENDEXTDIRF_BRED (BRED_CODIGO, BRED_DESC)
       VALUES ('500', 'A fonte pagadora � matriz da benefici�ria no exterior')
/

INSERT INTO BENEFRENDEXTDIRF_BRED (BRED_CODIGO, BRED_DESC)
       VALUES ('510', 'A fonte pagadora � filial, sucursal ou ag�ncia de benefici�ria no exterior')
/

INSERT INTO BENEFRENDEXTDIRF_BRED (BRED_CODIGO, BRED_DESC)
       VALUES ('520', 'A fonte pagadora � controlada ou coligada da benefici�ria no exterior')
/

INSERT INTO BENEFRENDEXTDIRF_BRED (BRED_CODIGO, BRED_DESC)
       VALUES ('530', 'A fonte pagadora � controladora ou coligada da benefici�ria no exterior')
/

INSERT INTO BENEFRENDEXTDIRF_BRED (BRED_CODIGO, BRED_DESC)
       VALUES ('540', 'A fonte pagadora e a benefici�ria no exterior est�o sob controle societ�rio ou administrativo comum')
/

INSERT INTO BENEFRENDEXTDIRF_BRED (BRED_CODIGO, BRED_DESC)
       VALUES ('550', 'A fonte pagadora e a benefici�ria no exterior t�m participa��o societ�ria no capital de uma terceira pessoa jur�dica')
/

INSERT INTO BENEFRENDEXTDIRF_BRED (BRED_CODIGO, BRED_DESC)
       VALUES ('560', 'A fonte pagadora ou a benefici�ria no exterior mantenha contrato de exclusividade como agente, distribuidor ou concession�rio')
/

INSERT INTO BENEFRENDEXTDIRF_BRED (BRED_CODIGO, BRED_DESC)
       VALUES ('570', 'A fonte pagadora e a benefici�ria mant�m acordo de atua��o conjunta')
/

INSERT INTO BENEFRENDEXTDIRF_BRED (BRED_CODIGO, BRED_DESC)
       VALUES ('900', 'N�o h� rela��o entre a fonte pagadora e a benefici�ria no exterior')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 288525
PROMPT ======================================================================