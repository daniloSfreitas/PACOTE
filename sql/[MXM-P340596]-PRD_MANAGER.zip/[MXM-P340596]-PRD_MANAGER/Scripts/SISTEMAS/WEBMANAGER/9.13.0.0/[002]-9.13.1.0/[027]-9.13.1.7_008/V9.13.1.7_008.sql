PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.7_008 gerados em 18/06/2018 
PROMPT ============================================================= 

@@000_20180618_MXMDS913_ADMDADOS_9.13.1.7_007.sql
@@001_20180618_MXMDS913_EFDREINF_293403.sql
@@002_20180618_MXMDS913_SF_294201.sql
@@003_20180618_MXMDS913_SIP_293158.sql
@@999_20180618_MXMDS913_ADMDADOS_9.13.1.7_008.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.7_008');

COMMIT;
