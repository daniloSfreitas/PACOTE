PROMPT ======================================================================
PROMPT == DEMANDA......: 279927
PROMPT == SISTEMA......: Patrimonio
PROMPT == RESPONSAVEL..: VICTOR SANTOS DE MELLO
PROMPT == DATA.........: 01/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRETABELARELVISAL_TRV
SET TRV_NMLISTATABREL = 'CCUSTO_CC', TRV_NMCONDICAOTABREL = 'VW_PATRIMON_PAT.PAT_CDEMPRESA = EMP.EMP_CODIGO(+) AND EMP.EMP_CODCENTCUS = CCUSTO_CC.CC_CODCENT'
WHERE TRV_NRVISAO =
        (SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR
                WHERE VDR_NRTABELA =
                    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR
                        WHERE TDR_NMTABELA = 'VW_PATRIMON_PAT'))
                        AND TRV_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE
                        TDR_NMTABELA = 'VW_EMPCLASSESPE_VCE EMP')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279927
PROMPT ======================================================================