PROMPT ======================================================================
PROMPT == DEMANDA......: 286241
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: LUANA MARIA DE SOUZA
PROMPT == DATA.........: 16/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRETABELARELVISAL_TRV (TRV_IDTABELARELVISAO,TRV_NRVISAO,TRV_NRTABELA,TRV_NMLISTATABREL,TRV_NMCONDICAOTABREL)
VALUES (
(SELECT MAX(TRV_IDTABELARELVISAO)+1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='TITCP_TCPR')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='EMPEND'),
'REQCOMPRA_RCO, IREQCOMPRA_IRC',
'REQCOMPRA_RCO.RCO_NUMERO = IREQCOMPRA_IRC.IRC_NUMERO AND REQCOMPRA_RCO.RCO_EMPRESA = EMPEND.EEN_CODIGO AND IREQCOMPRA_IRC.IRC_FILIAL = EMPEND.EEN_CDEND(+)'
)
/

INSERT INTO GRETABELARELVISAL_TRV (TRV_IDTABELARELVISAO,TRV_NRVISAO,TRV_NRTABELA,TRV_NMLISTATABREL,TRV_NMCONDICAOTABREL)
VALUES (
(SELECT MAX(TRV_IDTABELARELVISAO)+1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='ANTECCP_ACPR')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='EMPEND'),
'REQCOMPRA_RCO, IREQCOMPRA_IRC',
'REQCOMPRA_RCO.RCO_NUMERO = IREQCOMPRA_IRC.IRC_NUMERO AND REQCOMPRA_RCO.RCO_EMPRESA = EMPEND.EEN_CODIGO AND IREQCOMPRA_IRC.IRC_FILIAL = EMPEND.EEN_CDEND(+)'
)
/

INSERT INTO grefiltrocampotab_fct
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'ANTECCP_ACPR')),
   'Data de Aprova��o',
   0,
   1,
   '',
   '',
   '',
   '',
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'ANTECCP_ACPR'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'LINHAAPROVLOC_LAA')),
   'LINHAAPROVLOC_LAA.LAA_DTAPROVACAO',
   'Data de Aprova��o')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 286241
PROMPT ======================================================================