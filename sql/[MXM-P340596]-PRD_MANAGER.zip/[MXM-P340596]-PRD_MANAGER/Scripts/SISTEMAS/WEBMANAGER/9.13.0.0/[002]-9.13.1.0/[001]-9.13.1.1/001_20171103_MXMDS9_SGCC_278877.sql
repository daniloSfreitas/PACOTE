PROMPT ======================================================================
PROMPT == DEMANDA......: 278877
PROMPT == SISTEMA......: Contratos de Compras
PROMPT == RESPONSAVEL..: WANDER ANJOS COSTA SILVA
PROMPT == DATA.........: 19/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (35311, 'Listagem do Contrato', 'Listagem do Contrato')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGCC', 35311, 34, 3000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35311, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35311, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35311, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 278877
PROMPT ======================================================================