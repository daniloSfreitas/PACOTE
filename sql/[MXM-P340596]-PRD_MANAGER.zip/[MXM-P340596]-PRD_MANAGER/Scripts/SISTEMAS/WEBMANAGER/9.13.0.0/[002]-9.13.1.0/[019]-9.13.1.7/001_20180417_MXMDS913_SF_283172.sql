PROMPT ======================================================================
PROMPT == DEMANDA......: 283172
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: FRANCIMAR SANTIAGO NUNES
PROMPT == DATA.........: 28/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO ERROMSG_ERM VALUES('CANF0019', 'Conta cont�bil de Vendas Canceladas n�o parametrizada no Grupo de Recebimento.')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283172
PROMPT ======================================================================