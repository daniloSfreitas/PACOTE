PROMPT ======================================================================
PROMPT == DEMANDA......: 288032
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: LUCAS PEREIRA D AMICO
PROMPT == DATA.........: 04/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO TIPOENUMERADO_TENU VALUES ('TPENU_TIPOMOLESTIA','01','In�cio da mol�stia grave')
/

INSERT INTO TIPOENUMERADO_TENU VALUES ('TPENU_TIPOMOLESTIA','02','Fim da mol�stia grave')
/

ALTER TABLE HISTFOR_HFR ADD HFR_TIPO VARCHAR2(2)
/

comment on column HISTFOR_HFR.HFR_TIPO
  is 'Inicialmente utilizar para detalhamento quando for mol�stia grave na DIRF/Reinf Pessoa f�sica.'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 288032
PROMPT ======================================================================