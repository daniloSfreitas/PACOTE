PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.3_003 gerados em 28/12/2017 
PROMPT ============================================================= 

@@001_20171228_MXMDS913_SF_282012.sql
@@002_20171229_MXMDS913_Ajuste.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.3_003');

COMMIT;
