PROMPT ======================================================================
PROMPT == DEMANDA......: 286998
PROMPT == SISTEMA......: Financeiro
PROMPT == RESPONSAVEL..: Sistema MANTIS - PAT 263852
PROMPT == DATA.........: 26/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRETABELARELVISAL_TRV
       SET TRV_NMCONDICAOTABREL = 'PARAMCTBSCPACRDEC_PCAD.PCAD_CDEMPRESA = EMP.EMP_CODIGO(+)'
           , TRV_NRTABELA = (SELECT TDR_IDTABELA
                                              FROM GRETABDICDADOS_TDR 
                                            WHERE TDR_NMTABELA = 'VW_EMPCLASSESPE_VCE EMP')   
WHERE TRV_NRVISAO = (SELECT VDR_IDVISAO
                                          FROM GREVISAOTAB_VDR
                                        WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA
                                                                                  FROM GRETABDICDADOS_TDR
                                                                                WHERE TDR_NMTABELA = 'PARAMCTBSCPACRDEC_PCAD'))
      AND TRV_NRTABELA =  (SELECT TDR_IDTABELA
                                             FROM GRETABDICDADOS_TDR
                                           WHERE TDR_NMTABELA = 'EMPGERAL_EMP')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 286998
PROMPT ======================================================================