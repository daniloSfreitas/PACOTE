PROMPT ======================================================================
PROMPT == DEMANDA......: 287892
PROMPT == SISTEMA......: Integra��o Padr�o
PROMPT == RESPONSAVEL..: WESLEY RAPOSO
PROMPT == DATA.........: 19/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

create table TINERROMSGIMPLANTADOR_TEI
(
  TEI_SQPROCESSO   VARCHAR2(9),
  TEI_SQREGISTRO   VARCHAR2(9),
  TEI_DSPROCESSO   VARCHAR2(100),
  TEI_CDCAMPOBUSCA VARCHAR2(20),
  TEI_CDERRO       VARCHAR2(200),
  TEI_CDPROCESSO   VARCHAR2(2)
)
/

comment on table TINERROMSGIMPLANTADOR_TEI
  is 'Tabela que armazenar� os erros gerados durante a importa��o do Implantador'
/

comment on column TINERROMSGIMPLANTADOR_TEI.TEI_SQPROCESSO
  is 'Sequencia do processo do SiImplantador'
/

comment on column TINERROMSGIMPLANTADOR_TEI.TEI_SQREGISTRO
  is 'Sequencia do Registro'
/

comment on column TINERROMSGIMPLANTADOR_TEI.TEI_DSPROCESSO
  is 'Descri��o do processo que est� sendo importado'
/

comment on column TINERROMSGIMPLANTADOR_TEI.TEI_CDCAMPOBUSCA
  is 'C�digo do campo para realizar a busca'
/

comment on column TINERROMSGIMPLANTADOR_TEI.TEI_CDERRO
  is 'C�digo do Erro gerado durante a importa��o'
/

comment on column TINERROMSGIMPLANTADOR_TEI.TEI_CDPROCESSO
  is '1 - Plano de contas / 2 - Centro de Custo / 3 - Fluxo de Caixa / 4 - Clientes / 5 - Fornecedores / 6 - Produtos / 7 - Grupos de Recebimento / 8 - Grupos de pagamento / 13 - Grupo Patrimonial / 14 - Item patrimonial / 15 - Tipo de Produto.'
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27316, 'Replica��o de Par�metros', 'Replica��o de Par�metros')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('IMPLANTADOR', 27316, 2, 2000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27316, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27316, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27316, 'EXC')
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (35117, 'Contas Cont�beis n�o Relacionadas � Nenhuma Parametriza��o Cont�bil', 'Contas Cont�beis n�o Relacionadas � Nenhuma Parametriza��o Cont�bil')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('IMPLANTADOR', 35117, 10, 3000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35117, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35117, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35117, 'EXC')
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (35118, 'Impostos n�o Utilizados em Grupos de Recebimento ou Pagamento', 'Impostos n�o Utilizados em Grupos de Recebimento ou Pagamento')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('IMPLANTADOR', 35118, 11, 3000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35118, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35118, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35118, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287892
PROMPT ======================================================================