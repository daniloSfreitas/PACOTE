PROMPT ======================================================================
PROMPT == DEMANDA......: 288186
PROMPT == SISTEMA......: Patrimonio
PROMPT == RESPONSAVEL..: ANA CAROLINA ARAUJO FIGUEIREDO
PROMPT == DATA.........: 16/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE CALCDEPMEN (
   CODEMP       IN   CHAR,
   ITEMINI      IN   CHAR,
   ANEXINI      IN   CHAR,
   ITEMFIM      IN   CHAR,
   ANEXFIM      IN   CHAR,
   DTAQUIS1     IN   DATE,
   DTAQUIS2     IN   DATE,
   CCUSTO1      IN   CHAR,
   CCUSTO2      IN   CHAR,
   CDPROJETO1   IN   CHAR,
   CDPROJETO2   IN   CHAR,
   GRPAT1       IN   CHAR,
   GRPAT2       IN   CHAR,
   CODPLAN      IN   CHAR,
   DTBASE       IN   DATE,
   CONTABIL     IN   CHAR,
   TODOS        IN   CHAR
)
AS
   VCODEMP                   VARCHAR2 (04);
   VPATRIM                   VARCHAR2 (10);
   VANEXO                    VARCHAR2 (03);
   VCCUSTO                   VARCHAR2 (15);
   ACCUSTO                   VARCHAR2 (15);
   VLOCAL                    VARCHAR2 (10);
   VRESPONS                  VARCHAR2 (30);
   VDIADEPR                  VARCHAR2 (02);
   LANCTO                    VARCHAR2 (06);
   LOTE                      VARCHAR2 (06);
   GRPAT                     VARCHAR2 (06);
   VAUX                      VARCHAR2 (10);
   VMOEDA                    VARCHAR2 (03);
   VMOEDAL                   VARCHAR2 (03);
   AMTMOEDA                  VARCHAR2 (01);
   VSEQUENCIAL               NUMBER;
   VSTACCUSTO                NUMBER;
   VULTMOV1                  DATE;
   VULTMOV2                  DATE;
   VULTDATA1                 DATE;
   VULTDATA2                 DATE;
   VPRIDPDT1                 DATE;
   VPRIDPDT2                 DATE;
   VULTDTLCT1                DATE;
   VULTDTLCT2                DATE;
   VDATATMP                  DATE;
   VDTAQUIS                  DATE;
   VDTPDEPRES1               DATE;
   VDTPDEPRES2               DATE;
   VAQUIS1                   NUMBER;
   VACRBEM1                  NUMBER;
   VDEPREC1                  NUMBER;
   VACRDEP1                  NUMBER;
   VPERCDEP1                 NUMBER;
   VAQUIS2                   NUMBER;
   VACRBEM2                  NUMBER;
   VDEPREC2                  NUMBER;
   VACRDEP2                  NUMBER;
   VPERCDEP2                 NUMBER;
   VMVDEP                    NUMBER;
   VSALDO                    NUMBER;
   A                         NUMBER;
   VVALORMAXDEP1             NUMBER;
   -- Valor residual limite, ser� depreciado o item at� esse valor
   VVALORMAXDEP2             NUMBER;
   -- Valor residual limite, ser� depreciado o item at� esse valor
   VACHOU                    BOOLEAN;
   VACHOU1                   BOOLEAN;
   VACHOU2                   BOOLEAN;
   VDEPPRO1                  BOOLEAN;
   VGRPATRIM                 VARCHAR2 (06);
   VGRCONT                   VARCHAR2 (01);
   VCTADEP                   VARCHAR2 (15);
   VDESPDEP                  VARCHAR2 (15);
   VHISTORICO                VARCHAR2 (200);
   HISTORICO                 VARCHAR2 (200);
   VTOTDEP                   NUMBER;
   VTOTDEP1                  NUMBER;
   VGEROUMOV                 VARCHAR2 (01);
   VDATALIBPER               DATE;
   VDATALIBPERSAP            DATE;
   VCDPROJETO                VARCHAR2 (20);
   VULTIMAORDEMUSADA         NUMBER (10);
   VGRUPOPATRIMONIAL         VARCHAR2 (6);
   VULTITEMCTB               VARCHAR2 (15);
   VGRUPOPATRIPROPORCIONAL   VARCHAR2 (1);
   VSEQMOVSAP                NUMBER;
   VSEQMOVSAP1               NUMBER;
   CURSOR PEGAITEM                                                                        -- Pega faixa seleta de itens
   IS
      SELECT PAT_CDEMPRESA, PAT_CDPATRIMO, PAT_CDANEXO, PAT_PDEP1, PAT_PDEP2, PAT_ULTMOV1, PAT_ULTMOV2,
             PAT_VLMAXDEPREC1, PAT_VLMAXDEPREC2, PAT_CDPROJETO, PAT_GRPATRIM, GPAT_VBPROPORCIONAL
        FROM PATRIMON_PAT, GRPATRIM_GPAT
       WHERE PAT_GRPATRIM = GPAT_CODIGO
         AND PAT_CDPATRIMO >= ITEMINI
         AND PAT_CDANEXO >= ANEXINI
         AND PAT_CDPATRIMO <= ITEMFIM
         AND PAT_CDANEXO <= ANEXFIM
         AND (TO_DATE (DTAQUIS1, 'DD/MM/RR') IS NULL
              OR TO_DATE (PAT_DTAQUIS, 'DD/MM/RR') >= TO_DATE (DTAQUIS1, 'DD/MM/RR')
             )
         AND (TO_DATE (DTAQUIS2, 'DD/MM/RR') IS NULL
              OR TO_DATE (PAT_DTAQUIS, 'DD/MM/RR') <= TO_DATE (DTAQUIS2, 'DD/MM/RR')
             )
         AND (CCUSTO1 IS NULL OR PAT_NOCCUSTO >= CCUSTO1)
         AND (CCUSTO2 IS NULL OR PAT_NOCCUSTO <= CCUSTO2)
         AND (CDPROJETO1 IS NULL OR PAT_CDPROJETO >= CDPROJETO1)
         AND (CDPROJETO2 IS NULL OR PAT_CDPROJETO <= CDPROJETO2)
         AND (GRPAT1 IS NULL OR PAT_GRPATRIM >= GRPAT1)
         AND (GRPAT2 IS NULL OR PAT_GRPATRIM <= GRPAT2)
         AND PAT_CDEMPRESA = CODEMP
         AND TO_DATE (PAT_DTBAIXA, 'DD/MM/RR') IS NULL
         AND ((PAT_DEPRTOT1 IS NULL) OR ((PAT_DEPRTOT2 IS NULL) AND (PAT_DEPREC2 > 0)))
         AND (PAT_PERCDEP1 > 0 OR EXISTS (SELECT 1
                                            FROM GRPATRIM_GPAT
                                           WHERE GPAT_CODIGO = PAT_GRPATRIM AND GPAT_IDTAXADEPRECIACAO IS NOT NULL))
         AND NOT TO_DATE (PAT_PDEP1, 'DD/MM/RR') IS NULL
         AND (   TO_DATE (PAT_PDEP1, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
              OR TO_DATE (PAT_PDEP2, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
             )
         AND (   (   TO_DATE (PAT_ULTMOV1, 'DD/MM/RR') IS NULL
                  OR TO_DATE (PAT_ULTMOV1, 'DD/MM/RR') < TO_DATE (DTBASE, 'DD/MM/RR')
                 )
              OR (   TO_DATE (PAT_ULTMOV2, 'DD/MM/RR') IS NULL
                  OR TO_DATE (PAT_ULTMOV2, 'DD/MM/RR') < TO_DATE (DTBASE, 'DD/MM/RR')
                 )
             );
   CURSOR PEGAITEM1                                                                    -- Pega todos os itens da empresa
   IS
      SELECT PAT_CDEMPRESA, PAT_CDPATRIMO, PAT_CDANEXO, PAT_PDEP1, PAT_PDEP2, PAT_ULTMOV1, PAT_ULTMOV2,
             PAT_VLMAXDEPREC1, PAT_VLMAXDEPREC2, PAT_CDPROJETO, PAT_GRPATRIM, GPAT_VBPROPORCIONAL
        FROM PATRIMON_PAT, GRPATRIM_GPAT
       WHERE PAT_GRPATRIM = GPAT_CODIGO
         AND (TO_DATE (DTAQUIS1, 'DD/MM/RR') IS NULL OR PAT_DTAQUIS >= TO_DATE (DTAQUIS1, 'DD/MM/RR'))
         AND (TO_DATE (DTAQUIS2, 'DD/MM/RR') IS NULL
              OR TO_DATE (PAT_DTAQUIS, 'DD/MM/RR') <= TO_DATE (DTAQUIS2, 'DD/MM/RR')
             )
         AND (CCUSTO1 IS NULL OR PAT_NOCCUSTO >= CCUSTO1)
         AND (CCUSTO2 IS NULL OR PAT_NOCCUSTO <= CCUSTO2)
         AND (CDPROJETO1 IS NULL OR PAT_CDPROJETO >= CDPROJETO1)
         AND (CDPROJETO2 IS NULL OR PAT_CDPROJETO <= CDPROJETO2)
         AND (GRPAT1 IS NULL OR PAT_GRPATRIM >= GRPAT1)
         AND (GRPAT2 IS NULL OR PAT_GRPATRIM <= GRPAT2)
         AND PAT_CDEMPRESA = CODEMP
         AND TO_DATE (PAT_DTBAIXA, 'DD/MM/RR') IS NULL
         AND ((PAT_DEPRTOT1 IS NULL) OR ((PAT_DEPRTOT2 IS NULL) AND (PAT_DEPREC2 > 0)))
         AND (PAT_PERCDEP1 > 0 OR EXISTS (SELECT 1
                                            FROM GRPATRIM_GPAT
                                           WHERE GPAT_CODIGO = PAT_GRPATRIM AND GPAT_IDTAXADEPRECIACAO IS NOT NULL))
         AND NOT TO_DATE (PAT_PDEP1, 'DD/MM/RR') IS NULL
         AND (   TO_DATE (PAT_PDEP1, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
              OR TO_DATE (PAT_PDEP2, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
             )
         AND (   (   TO_DATE (PAT_ULTMOV1, 'DD/MM/RR') IS NULL
                  OR TO_DATE (PAT_ULTMOV1, 'DD/MM/RR') < TO_DATE (DTBASE, 'DD/MM/RR')
                 )
              OR (   TO_DATE (PAT_ULTMOV2, 'DD/MM/RR') IS NULL
                  OR TO_DATE (PAT_ULTMOV2, 'DD/MM/RR') < TO_DATE (DTBASE, 'DD/MM/RR')
                 )
             );
   CURSOR ULTDATA1                                                             -- Data do proximo movimento na 1a. moeda
   IS
      SELECT MAX (ADD_MONTHS (LAST_DAY (MSAP_DATA), 1))
        FROM MOVSAP_MSAP
       WHERE MSAP_CDEMPRESA = CODEMP
         AND MSAP_CDPATRIMO = VPATRIM
         AND MSAP_CDANEXO = VANEXO
         AND (MSAP_TPMOV = 'D' OR MSAP_TPMOV = 'A');
   CURSOR ULTDATA2                                                             -- Data do proximo movimento na 2a. moeda
   IS
      SELECT MAX (ADD_MONTHS (LAST_DAY (MSAP_DATA1), 1))
        FROM MOVSAP1_MSAP
       WHERE MSAP_CDEMPRESA1 = CODEMP
         AND MSAP_CDPATRIMO1 = VPATRIM
         AND MSAP_CDANEXO1 = VANEXO
         AND (MSAP_TPMOV1 = 'D' OR MSAP_TPMOV1 = 'A');
   CURSOR JATEMMOV1                                              -- Verifica se ja possui movimento da 1a. moeda na data
   IS
      SELECT MSAP_CDPATRIMO
        FROM MOVSAP_MSAP
       WHERE MSAP_CDEMPRESA = CODEMP
         AND MSAP_CDPATRIMO = VPATRIM
         AND MSAP_CDANEXO = VANEXO
         AND MSAP_TPMOV = 'D'
         AND TO_DATE (MSAP_DATA, 'DD/MM/RR') >= TO_DATE (VPRIDPDT1, 'DD/MM/RR');
   CURSOR JATEMMOV2                                              -- Verifica se ja possui movimento da 2a. moeda na data
   IS
      SELECT MSAP_CDPATRIMO1
        FROM MOVSAP1_MSAP
       WHERE MSAP_CDEMPRESA1 = CODEMP
         AND MSAP_CDPATRIMO1 = VPATRIM
         AND MSAP_CDANEXO1 = VANEXO
         AND MSAP_TPMOV1 = 'D'
         AND TO_DATE (MSAP_DATA1, 'DD/MM/RR') >= TO_DATE (VPRIDPDT2, 'DD/MM/RR');
   CURSOR LANCAMENTO
-- Pega faixa seleta de itens e seus valores para o lancamento contabil na 1a. moeda
   IS
      SELECT   CTADEP, CTADESPDEP, NOCCUSTO, GRPATRIM, CONTABIL, DATA, SUM (NVL (TTOT1, 0)) AS TOT1,
               SUM (NVL (TTOT2, 0)) AS TOT2, PROJETO
          FROM (SELECT   CGPAT_CTADEP AS CTADEP,
                         DECODE (A.PLC_CCUSTO,
                                 'S', DECODE (B.PLC_CCUSTO, 'N', NULL, CGPAT_CTADESPDEP),
                                 DECODE (B.PLC_CCUSTO, 'S', CGPAT_CTADESPDEP, NULL)
                                ) AS CTADESPDEP,
                         DECODE (A.PLC_CCUSTO, 'N', NULL, PAT_NOCCUSTO) AS NOCCUSTO, PAT_GRPATRIM AS GRPATRIM,
                         GPAT_CONTABIL AS CONTABIL, TO_DATE (MSAP_DATA, 'DD/MM/RR') AS DATA,
                         SUM (NVL (MSAP_VDEP, 0)) AS TTOT1, 0 AS TTOT2, PAT_CDPROJETO AS PROJETO
                    FROM PATRIMON_PAT, MOVSAP_MSAP, GRPATCTB_CGPAT, GRPATRIM_GPAT, PLANOCTA_PLC A, PLANOCTA_PLC B
                   WHERE PAT_CDPATRIMO >= ITEMINI
                     AND PAT_CDANEXO >= ANEXINI
                     AND PAT_CDPATRIMO <= ITEMFIM
                     AND PAT_CDANEXO <= ANEXFIM
                     AND (CCUSTO1 IS NULL OR PAT_NOCCUSTO >= CCUSTO1)
                     AND (CCUSTO2 IS NULL OR PAT_NOCCUSTO <= CCUSTO2)
                     AND (CDPROJETO1 IS NULL OR PAT_CDPROJETO >= CDPROJETO1)
                     AND (CDPROJETO2 IS NULL OR PAT_CDPROJETO <= CDPROJETO2)
                     AND (GRPAT1 IS NULL OR PAT_GRPATRIM >= GRPAT1)
                     AND (GRPAT2 IS NULL OR PAT_GRPATRIM <= GRPAT2)
                     AND PAT_CDEMPRESA = CODEMP
                     AND TO_DATE (PAT_DTBAIXA, 'DD/MM/RR') IS NULL
                     AND (PAT_PERCDEP1 > 0 OR GPAT_IDTAXADEPRECIACAO IS NOT NULL)
                     AND PAT_CDEMPRESA = MSAP_CDEMPRESA
                     AND PAT_CDPATRIMO = MSAP_CDPATRIMO
                     AND PAT_CDANEXO = MSAP_CDANEXO
                     AND PAT_GRPATRIM = GPAT_CODIGO
                     AND GPAT_CODIGO = CGPAT_CODIGO
                     AND PAT_CDEMPRESA = CGPAT_CDEMPRESA
                     AND A.PLC_NOCONTAB = CGPAT_CTADEP
                     AND A.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND B.PLC_NOCONTAB = CGPAT_CTADESPDEP
                     AND B.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND TO_DATE (MSAP_DATA, 'DD/MM/RR') >= TO_DATE (VULTDTLCT1, 'DD/MM/RR')
                     AND TO_DATE (MSAP_DATA, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
                     AND MSAP_TPMOV = 'D'
                GROUP BY CGPAT_CTADEP,
                         CGPAT_CTADESPDEP,
                         PAT_NOCCUSTO,
                         A.PLC_CCUSTO,
                         B.PLC_CCUSTO,
                         PAT_GRPATRIM,
                         GPAT_CONTABIL,
                         TO_DATE (MSAP_DATA, 'DD/MM/RR'),
                         PAT_CDPROJETO
                UNION ALL
                SELECT   DECODE (A.PLC_CCUSTO,
                                 'S', DECODE (B.PLC_CCUSTO, 'N', NULL, CGPAT_CTADEP),
                                 DECODE (B.PLC_CCUSTO, 'S', CGPAT_CTADEP, NULL)
                                ) AS CTADEP,
                         CGPAT_CTADESPDEP AS CTADESPDEP, DECODE (A.PLC_CCUSTO, 'N', NULL, PAT_NOCCUSTO) AS NOCCUSTO,
                         PAT_GRPATRIM AS GRPATRIM, GPAT_CONTABIL AS CONTABIL, MSAP_DATA AS DATA,
                         SUM (NVL (MSAP_VDEP, 0)) AS TTOT1, 0 AS TTOT2, PAT_CDPROJETO AS PROJETO
                    FROM PATRIMON_PAT, MOVSAP_MSAP, GRPATCTB_CGPAT, GRPATRIM_GPAT, PLANOCTA_PLC A, PLANOCTA_PLC B
                   WHERE PAT_CDPATRIMO >= ITEMINI
                     AND PAT_CDANEXO >= ANEXINI
                     AND PAT_CDPATRIMO <= ITEMFIM
                     AND PAT_CDANEXO <= ANEXFIM
                     AND (CCUSTO1 IS NULL OR PAT_NOCCUSTO >= CCUSTO1)
                     AND (CCUSTO2 IS NULL OR PAT_NOCCUSTO <= CCUSTO2)
                     AND (CDPROJETO1 IS NULL OR PAT_CDPROJETO >= CDPROJETO1)
                     AND (CDPROJETO2 IS NULL OR PAT_CDPROJETO <= CDPROJETO2)
                     AND (GRPAT1 IS NULL OR PAT_GRPATRIM >= GRPAT1)
                     AND (GRPAT2 IS NULL OR PAT_GRPATRIM <= GRPAT2)
                     AND PAT_CDEMPRESA = CODEMP
                     AND PAT_DTBAIXA IS NULL
                     AND (PAT_PERCDEP1 > 0 OR GPAT_IDTAXADEPRECIACAO IS NOT NULL)
                     AND PAT_CDEMPRESA = MSAP_CDEMPRESA
                     AND PAT_CDPATRIMO = MSAP_CDPATRIMO
                     AND PAT_CDANEXO = MSAP_CDANEXO
                     AND PAT_GRPATRIM = GPAT_CODIGO
                     AND GPAT_CODIGO = CGPAT_CODIGO
                     AND PAT_CDEMPRESA = CGPAT_CDEMPRESA
                     AND B.PLC_NOCONTAB = CGPAT_CTADEP
                     AND B.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND A.PLC_NOCONTAB = CGPAT_CTADESPDEP
                     AND A.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND TO_DATE (MSAP_DATA, 'DD/MM/RR') >= TO_DATE (VULTDTLCT1, 'DD/MM/RR')
                     AND TO_DATE (MSAP_DATA, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
                     AND MSAP_TPMOV = 'D'
                GROUP BY CGPAT_CTADEP,
                         CGPAT_CTADESPDEP,
                         PAT_NOCCUSTO,
                         B.PLC_CCUSTO,
                         A.PLC_CCUSTO,
                         PAT_GRPATRIM,
                         GPAT_CONTABIL,
                         MSAP_DATA,
                         PAT_CDPROJETO
                UNION ALL
                SELECT   CGPAT_CTADEP AS CTADEP,
                         DECODE (A.PLC_CCUSTO,
                                 'S', DECODE (B.PLC_CCUSTO, 'N', NULL, CGPAT_CTADESPDEP),
                                 DECODE (B.PLC_CCUSTO, 'S', CGPAT_CTADESPDEP, NULL)
                                ) AS CTADESPDEP,
                         DECODE (A.PLC_CCUSTO, 'N', NULL, PAT_NOCCUSTO) AS NOCCUSTO, PAT_GRPATRIM AS GRPATRIM,
                         GPAT_CONTABIL AS CONTABIL, MSAP_DATA1 AS DATA, 0 AS TTOT1, SUM (NVL (MSAP_VDEP1, 0)) AS TTOT2,
                         PAT_CDPROJETO AS PROJETO
                    FROM PATRIMON_PAT, MOVSAP1_MSAP, GRPATCTB_CGPAT, GRPATRIM_GPAT, PLANOCTA_PLC A, PLANOCTA_PLC B
                   WHERE PAT_CDPATRIMO >= ITEMINI
                     AND PAT_CDANEXO >= ANEXINI
                     AND PAT_CDPATRIMO <= ITEMFIM
                     AND PAT_CDANEXO <= ANEXFIM
                     AND (CCUSTO1 IS NULL OR PAT_NOCCUSTO >= CCUSTO1)
                     AND (CCUSTO2 IS NULL OR PAT_NOCCUSTO <= CCUSTO2)
                     AND (CDPROJETO1 IS NULL OR PAT_CDPROJETO >= CDPROJETO1)
                     AND (CDPROJETO2 IS NULL OR PAT_CDPROJETO <= CDPROJETO2)
                     AND (GRPAT1 IS NULL OR PAT_GRPATRIM >= GRPAT1)
                     AND (GRPAT2 IS NULL OR PAT_GRPATRIM <= GRPAT2)
                     AND PAT_CDEMPRESA = CODEMP
                     AND PAT_DTBAIXA IS NULL
                     AND PAT_PERCDEP2 > 0
                     AND PAT_CDEMPRESA = MSAP_CDEMPRESA1
                     AND PAT_CDPATRIMO = MSAP_CDPATRIMO1
                     AND PAT_CDANEXO = MSAP_CDANEXO1
                     AND PAT_GRPATRIM = GPAT_CODIGO
                     AND GPAT_CODIGO = CGPAT_CODIGO
                     AND PAT_CDEMPRESA = CGPAT_CDEMPRESA
                     AND A.PLC_NOCONTAB = CGPAT_CTADEP
                     AND A.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND B.PLC_NOCONTAB = CGPAT_CTADESPDEP
                     AND B.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND TO_DATE (MSAP_DATA1, 'DD/MM/RR') >= TO_DATE (VULTDTLCT1, 'DD/MM/RR')
                     AND TO_DATE (MSAP_DATA1, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
                     AND MSAP_TPMOV1 = 'D'
                GROUP BY CGPAT_CTADEP,
                         CGPAT_CTADESPDEP,
                         PAT_NOCCUSTO,
                         A.PLC_CCUSTO,
                         B.PLC_CCUSTO,
                         PAT_GRPATRIM,
                         GPAT_CONTABIL,
                         MSAP_DATA1,
                         PAT_CDPROJETO
                UNION ALL
                SELECT   DECODE (A.PLC_CCUSTO,
                                 'S', DECODE (B.PLC_CCUSTO, 'N', NULL, CGPAT_CTADEP),
                                 DECODE (B.PLC_CCUSTO, 'S', CGPAT_CTADEP, NULL)
                                ) AS CTADEP,
                         CGPAT_CTADESPDEP AS CTADESPDEP, DECODE (A.PLC_CCUSTO, 'N', NULL, PAT_NOCCUSTO) AS NOCCUSTO,
                         PAT_GRPATRIM AS GRPATRIM, GPAT_CONTABIL AS CONTABIL, MSAP_DATA1 AS DATA, 0 AS TTOT1,
                         SUM (NVL (MSAP_VDEP1, 0)) AS TTOT2, PAT_CDPROJETO AS PROJETO
                    FROM PATRIMON_PAT, MOVSAP1_MSAP, GRPATCTB_CGPAT, GRPATRIM_GPAT, PLANOCTA_PLC A, PLANOCTA_PLC B
                   WHERE PAT_CDPATRIMO >= ITEMINI
                     AND PAT_CDANEXO >= ANEXINI
                     AND PAT_CDPATRIMO <= ITEMFIM
                     AND PAT_CDANEXO <= ANEXFIM
                     AND (CCUSTO1 IS NULL OR PAT_NOCCUSTO >= CCUSTO1)
                     AND (CCUSTO2 IS NULL OR PAT_NOCCUSTO <= CCUSTO2)
                     AND (CDPROJETO1 IS NULL OR PAT_CDPROJETO >= CDPROJETO1)
                     AND (CDPROJETO2 IS NULL OR PAT_CDPROJETO <= CDPROJETO2)
                     AND (GRPAT1 IS NULL OR PAT_GRPATRIM >= GRPAT1)
                     AND (GRPAT2 IS NULL OR PAT_GRPATRIM <= GRPAT2)
                     AND PAT_CDEMPRESA = CODEMP
                     AND PAT_DTBAIXA IS NULL
                     AND PAT_PERCDEP2 > 0
                     AND PAT_CDEMPRESA = MSAP_CDEMPRESA1
                     AND PAT_CDPATRIMO = MSAP_CDPATRIMO1
                     AND PAT_CDANEXO = MSAP_CDANEXO1
                     AND PAT_GRPATRIM = GPAT_CODIGO
                     AND GPAT_CODIGO = CGPAT_CODIGO
                     AND PAT_CDEMPRESA = CGPAT_CDEMPRESA
                     AND B.PLC_NOCONTAB = CGPAT_CTADEP
                     AND B.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND A.PLC_NOCONTAB = CGPAT_CTADESPDEP
                     AND A.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND TO_DATE (MSAP_DATA1, 'DD/MM/RR') >= TO_DATE (VULTDTLCT1, 'DD/MM/RR')
                     AND TO_DATE (MSAP_DATA1, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
                     AND MSAP_TPMOV1 = 'D'
                GROUP BY CGPAT_CTADEP,
                         CGPAT_CTADESPDEP,
                         PAT_NOCCUSTO,
                         B.PLC_CCUSTO,
                         A.PLC_CCUSTO,
                         PAT_GRPATRIM,
                         GPAT_CONTABIL,
                         MSAP_DATA1,
                         PAT_CDPROJETO)
      GROUP BY CTADEP, CTADESPDEP, NOCCUSTO, GRPATRIM, CONTABIL, DATA, PROJETO
      ORDER BY GRPATRIM, DATA, CTADESPDEP, CTADEP, NOCCUSTO, CONTABIL;
   CURSOR LANCAMENTOA
-- Pega todos os itens e seus valores para o lancamento contabil na 1a. moeda
   IS
      SELECT   CTADEP, CTADESPDEP, NOCCUSTO, GRPATRIM, CONTABIL, DATA, SUM (NVL (TTOT1, 0)) AS TOT1,
               SUM (NVL (TTOT2, 0)) AS TOT2, PROJETO
          FROM (SELECT   CGPAT_CTADEP AS CTADEP,
                         DECODE (A.PLC_CCUSTO,
                                 'S', DECODE (B.PLC_CCUSTO, 'N', NULL, CGPAT_CTADESPDEP),
                                 DECODE (B.PLC_CCUSTO, 'S', CGPAT_CTADESPDEP, NULL)
                                ) AS CTADESPDEP,
                         DECODE (A.PLC_CCUSTO, 'N', NULL, PAT_NOCCUSTO) AS NOCCUSTO, PAT_GRPATRIM AS GRPATRIM,
                         GPAT_CONTABIL AS CONTABIL, MSAP_DATA AS DATA, SUM (NVL (MSAP_VDEP, 0)) AS TTOT1, 0 AS TTOT2,
                         PAT_CDPROJETO AS PROJETO
                    FROM PATRIMON_PAT, MOVSAP_MSAP, GRPATCTB_CGPAT, GRPATRIM_GPAT, PLANOCTA_PLC A, PLANOCTA_PLC B
                   WHERE (CCUSTO1 IS NULL OR PAT_NOCCUSTO >= CCUSTO1)
                     AND (CCUSTO2 IS NULL OR PAT_NOCCUSTO <= CCUSTO2)
                     AND (CDPROJETO1 IS NULL OR PAT_CDPROJETO >= CDPROJETO1)
                     AND (CDPROJETO2 IS NULL OR PAT_CDPROJETO <= CDPROJETO2)
                     AND (GRPAT1 IS NULL OR PAT_GRPATRIM >= GRPAT1)
                     AND (GRPAT2 IS NULL OR PAT_GRPATRIM <= GRPAT2)
                     AND PAT_CDEMPRESA = CODEMP
                     AND PAT_DTBAIXA IS NULL
                     AND (PAT_PERCDEP1 > 0 OR GPAT_IDTAXADEPRECIACAO IS NOT NULL)
                     AND PAT_CDEMPRESA = MSAP_CDEMPRESA
                     AND PAT_CDPATRIMO = MSAP_CDPATRIMO
                     AND PAT_CDANEXO = MSAP_CDANEXO
                     AND PAT_GRPATRIM = GPAT_CODIGO
                     AND GPAT_CODIGO = CGPAT_CODIGO
                     AND PAT_CDEMPRESA = CGPAT_CDEMPRESA
                     AND A.PLC_NOCONTAB = CGPAT_CTADEP
                     AND A.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND B.PLC_NOCONTAB = CGPAT_CTADESPDEP
                     AND B.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND TO_DATE (MSAP_DATA, 'DD/MM/RR') >= TO_DATE (VULTDTLCT1, 'DD/MM/RR')
                     AND TO_DATE (MSAP_DATA, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
                     AND MSAP_TPMOV = 'D'
                GROUP BY CGPAT_CTADEP,
                         CGPAT_CTADESPDEP,
                         PAT_NOCCUSTO,
                         A.PLC_CCUSTO,
                         B.PLC_CCUSTO,
                         PAT_GRPATRIM,
                         GPAT_CONTABIL,
                         MSAP_DATA,
                         PAT_CDPROJETO
                UNION ALL
                SELECT   DECODE (A.PLC_CCUSTO,
                                 'S', DECODE (B.PLC_CCUSTO, 'N', NULL, CGPAT_CTADEP),
                                 DECODE (B.PLC_CCUSTO, 'S', CGPAT_CTADEP, NULL)
                                ) AS CTADEP,
                         CGPAT_CTADESPDEP AS CTADESPDEP, DECODE (A.PLC_CCUSTO, 'N', NULL, PAT_NOCCUSTO) AS NOCCUSTO,
                         PAT_GRPATRIM AS GRPATRIM, GPAT_CONTABIL AS CONTABIL, MSAP_DATA AS DATA,
                         SUM (NVL (MSAP_VDEP, 0)) AS TTOT1, 0 AS TTOT2, PAT_CDPROJETO AS PROJETO
                    FROM PATRIMON_PAT, MOVSAP_MSAP, GRPATCTB_CGPAT, GRPATRIM_GPAT, PLANOCTA_PLC A, PLANOCTA_PLC B
                   WHERE (CCUSTO1 IS NULL OR PAT_NOCCUSTO >= CCUSTO1)
                     AND (CCUSTO2 IS NULL OR PAT_NOCCUSTO <= CCUSTO2)
                     AND (CDPROJETO1 IS NULL OR PAT_CDPROJETO >= CDPROJETO1)
                     AND (CDPROJETO2 IS NULL OR PAT_CDPROJETO <= CDPROJETO2)
                     AND (GRPAT1 IS NULL OR PAT_GRPATRIM >= GRPAT1)
                     AND (GRPAT2 IS NULL OR PAT_GRPATRIM <= GRPAT2)
                     AND PAT_CDEMPRESA = CODEMP
                     AND TO_DATE (PAT_DTBAIXA, 'DD/MM/RR') IS NULL
                     AND (PAT_PERCDEP1 > 0 OR GPAT_IDTAXADEPRECIACAO IS NOT NULL)
                     AND PAT_CDEMPRESA = MSAP_CDEMPRESA
                     AND PAT_CDPATRIMO = MSAP_CDPATRIMO
                     AND PAT_CDANEXO = MSAP_CDANEXO
                     AND PAT_GRPATRIM = GPAT_CODIGO
                     AND GPAT_CODIGO = CGPAT_CODIGO
                     AND PAT_CDEMPRESA = CGPAT_CDEMPRESA
                     AND B.PLC_NOCONTAB = CGPAT_CTADEP
                     AND B.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND A.PLC_NOCONTAB = CGPAT_CTADESPDEP
                     AND A.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND TO_DATE (MSAP_DATA, 'DD/MM/RR') >= TO_DATE (VULTDTLCT1, 'DD/MM/RR')
                     AND TO_DATE (MSAP_DATA, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
                     AND MSAP_TPMOV = 'D'
                GROUP BY CGPAT_CTADEP,
                         CGPAT_CTADESPDEP,
                         PAT_NOCCUSTO,
                         B.PLC_CCUSTO,
                         A.PLC_CCUSTO,
                         PAT_GRPATRIM,
                         GPAT_CONTABIL,
                         MSAP_DATA,
                         PAT_CDPROJETO
                UNION ALL
                SELECT   CGPAT_CTADEP AS CTADEP,
                         DECODE (A.PLC_CCUSTO,
                                 'S', DECODE (B.PLC_CCUSTO, 'N', NULL, CGPAT_CTADESPDEP),
                                 DECODE (B.PLC_CCUSTO, 'S', CGPAT_CTADESPDEP, NULL)
                                ) AS CTADESPDEP,
                         DECODE (A.PLC_CCUSTO, 'N', NULL, PAT_NOCCUSTO) AS NOCCUSTO, PAT_GRPATRIM AS GRPATRIM,
                         GPAT_CONTABIL AS CONTABIL, MSAP_DATA1 AS DATA, 0 AS TTOT1, SUM (NVL (MSAP_VDEP1, 0)) AS TTOT2,
                         PAT_CDPROJETO AS PROJETO
                    FROM PATRIMON_PAT, MOVSAP1_MSAP, GRPATCTB_CGPAT, GRPATRIM_GPAT, PLANOCTA_PLC A, PLANOCTA_PLC B
                   WHERE (CCUSTO1 IS NULL OR PAT_NOCCUSTO >= CCUSTO1)
                     AND (CCUSTO2 IS NULL OR PAT_NOCCUSTO <= CCUSTO2)
                     AND (CDPROJETO1 IS NULL OR PAT_CDPROJETO >= CDPROJETO1)
                     AND (CDPROJETO2 IS NULL OR PAT_CDPROJETO <= CDPROJETO2)
                     AND (GRPAT1 IS NULL OR PAT_GRPATRIM >= GRPAT1)
                     AND (GRPAT2 IS NULL OR PAT_GRPATRIM <= GRPAT2)
                     AND PAT_CDEMPRESA = CODEMP
                     AND TO_DATE (PAT_DTBAIXA, 'DD/MM/RR') IS NULL
                     AND PAT_PERCDEP2 > 0
                     AND PAT_CDEMPRESA = MSAP_CDEMPRESA1
                     AND PAT_CDPATRIMO = MSAP_CDPATRIMO1
                     AND PAT_CDANEXO = MSAP_CDANEXO1
                     AND PAT_GRPATRIM = GPAT_CODIGO
                     AND GPAT_CODIGO = CGPAT_CODIGO
                     AND PAT_CDEMPRESA = CGPAT_CDEMPRESA
                     AND A.PLC_NOCONTAB = CGPAT_CTADEP
                     AND A.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND B.PLC_NOCONTAB = CGPAT_CTADESPDEP
                     AND B.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND TO_DATE (MSAP_DATA1, 'DD/MM/RR') >= TO_DATE (VULTDTLCT1, 'DD/MM/RR')
                     AND TO_DATE (MSAP_DATA1, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
                     AND MSAP_TPMOV1 = 'D'
                GROUP BY CGPAT_CTADEP,
                         CGPAT_CTADESPDEP,
                         PAT_NOCCUSTO,
                         A.PLC_CCUSTO,
                         B.PLC_CCUSTO,
                         PAT_GRPATRIM,
                         GPAT_CONTABIL,
                         MSAP_DATA1,
                         PAT_CDPROJETO
                UNION ALL
                SELECT   DECODE (A.PLC_CCUSTO,
                                 'S', DECODE (B.PLC_CCUSTO, 'N', NULL, CGPAT_CTADEP),
                                 DECODE (B.PLC_CCUSTO, 'S', CGPAT_CTADEP, NULL)
                                ) AS CTADEP,
                         CGPAT_CTADESPDEP AS CTADESPDEP, DECODE (A.PLC_CCUSTO, 'N', NULL, PAT_NOCCUSTO) AS NOCCUSTO,
                         PAT_GRPATRIM AS GRPATRIM, GPAT_CONTABIL AS CONTABIL, MSAP_DATA1 AS DATA, 0 AS TTOT1,
                         SUM (NVL (MSAP_VDEP1, 0)) AS TTOT2, PAT_CDPROJETO AS PROJETO
                    FROM PATRIMON_PAT, MOVSAP1_MSAP, GRPATCTB_CGPAT, GRPATRIM_GPAT, PLANOCTA_PLC A, PLANOCTA_PLC B
                   WHERE (CCUSTO1 IS NULL OR PAT_NOCCUSTO >= CCUSTO1)
                     AND (CCUSTO2 IS NULL OR PAT_NOCCUSTO <= CCUSTO2)
                     AND (CDPROJETO1 IS NULL OR PAT_CDPROJETO >= CDPROJETO1)
                     AND (CDPROJETO2 IS NULL OR PAT_CDPROJETO <= CDPROJETO2)
                     AND (GRPAT1 IS NULL OR PAT_GRPATRIM >= GRPAT1)
                     AND (GRPAT2 IS NULL OR PAT_GRPATRIM <= GRPAT2)
                     AND PAT_CDEMPRESA = CODEMP
                     AND TO_DATE (PAT_DTBAIXA, 'DD/MM/RR') IS NULL
                     AND PAT_PERCDEP2 > 0
                     AND PAT_CDEMPRESA = MSAP_CDEMPRESA1
                     AND PAT_CDPATRIMO = MSAP_CDPATRIMO1
                     AND PAT_CDANEXO = MSAP_CDANEXO1
                     AND PAT_GRPATRIM = GPAT_CODIGO
                     AND GPAT_CODIGO = CGPAT_CODIGO
                     AND PAT_CDEMPRESA = CGPAT_CDEMPRESA
                     AND B.PLC_NOCONTAB = CGPAT_CTADEP
                     AND B.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND A.PLC_NOCONTAB = CGPAT_CTADESPDEP
                     AND A.PLC_CODPLANO = CGPAT_CODPLCONTA
                     AND TO_DATE (MSAP_DATA1, 'DD/MM/RR') >= TO_DATE (VULTDTLCT1, 'DD/MM/RR')
                     AND TO_DATE (MSAP_DATA1, 'DD/MM/RR') <= TO_DATE (DTBASE, 'DD/MM/RR')
                     AND MSAP_TPMOV1 = 'D'
                GROUP BY CGPAT_CTADEP,
                         CGPAT_CTADESPDEP,
                         PAT_NOCCUSTO,
                         B.PLC_CCUSTO,
                         A.PLC_CCUSTO,
                         PAT_GRPATRIM,
                         GPAT_CONTABIL,
                         MSAP_DATA1,
                         PAT_CDPROJETO)
      GROUP BY CTADEP, CTADESPDEP, NOCCUSTO, GRPATRIM, CONTABIL, DATA, PROJETO
      ORDER BY GRPATRIM, DATA, CTADESPDEP, CTADEP, NOCCUSTO, CONTABIL;
   CURSOR PGITEM
   -- Pega itens para marcar o numero do lancamento contabil da 1a. moeda
   IS
      SELECT PAT_CDPATRIMO, PAT_CDANEXO
        FROM PATRIMON_PAT
       WHERE PAT_CDPATRIMO >= ITEMINI
         AND PAT_CDANEXO >= ANEXINI
         AND PAT_CDPATRIMO <= ITEMFIM
         AND PAT_CDANEXO <= ANEXFIM
         AND (TO_DATE (DTAQUIS1, 'DD/MM/RR') IS NULL
              OR TO_DATE (PAT_DTAQUIS, 'DD/MM/RR') >= TO_DATE (DTAQUIS1, 'DD/MM/RR')
             )
         AND (TO_DATE (DTAQUIS2, 'DD/MM/RR') IS NULL
              OR TO_DATE (PAT_DTAQUIS, 'DD/MM/RR') <= TO_DATE (DTAQUIS2, 'DD/MM/RR')
             )
         AND (VCCUSTO IS NULL OR PAT_NOCCUSTO = VCCUSTO)
         AND (VGRPATRIM IS NULL OR PAT_GRPATRIM = VGRPATRIM)
         AND PAT_CDEMPRESA = CODEMP
         AND TO_DATE (PAT_DTBAIXA, 'DD/MM/RR') IS NULL;
   CURSOR PGITEM1
   -- Pega itens para marcar o numero do lancamento contabil da 2a. moeda
   IS
      SELECT PAT_CDPATRIMO, PAT_CDANEXO
        FROM PATRIMON_PAT
       WHERE (TO_DATE (DTAQUIS1, 'DD/MM/RR') IS NULL
              OR TO_DATE (PAT_DTAQUIS, 'DD/MM/RR') >= TO_DATE (DTAQUIS1, 'DD/MM/RR')
             )
         AND (TO_DATE (DTAQUIS2, 'DD/MM/RR') IS NULL
              OR TO_DATE (PAT_DTAQUIS, 'DD/MM/RR') <= TO_DATE (DTAQUIS2, 'DD/MM/RR')
             )
         AND (VCCUSTO IS NULL OR PAT_NOCCUSTO = VCCUSTO)
         AND (VGRPATRIM IS NULL OR PAT_GRPATRIM = VGRPATRIM)
         AND PAT_CDEMPRESA = CODEMP
         AND TO_DATE (PAT_DTBAIXA, 'DD/MM/RR') IS NULL;
   CURSOR PARAMDIA                                                                    -- Pega dia do lancamento contabil
   IS
      SELECT PAR_VLPARAM
        FROM PARAMS_PAR
       WHERE PAR_CDPARAM = 'wSAP_DIADEPREC';
   CURSOR PARAMHIST                                                             -- Pega historico do lancamento contabil
   IS
      SELECT RTRIM (LTRIM (PAR_VLPARAM))
        FROM PARAMS_PAR
       WHERE PAR_CDPARAM = 'wSAP_HISTDEPRECIACAO';
   CURSOR SEGURANCA
   -- Seguranca para efetuar lancamento da depreciacao na 1a. moeda
   IS
      SELECT MSAP_CDEMPRESA, MSAP_CDPATRIMO, MSAP_CDANEXO
        FROM MOVSAP_MSAP
       WHERE MSAP_CDEMPRESA = CODEMP
         AND MSAP_CDPATRIMO = VPATRIM
         AND MSAP_CDANEXO = VANEXO
         AND MSAP_TPMOV = 'D'
         AND TO_CHAR (MSAP_DATA, 'DD/MM/RR') = TO_CHAR (VULTDATA1, 'DD/MM/RR');
   CURSOR SEGURANCA1
   -- Seguranca para efetuar lancamento da depreciacao na 2a. moeda
   IS
      SELECT MSAP_CDEMPRESA1, MSAP_CDPATRIMO1, MSAP_CDANEXO1
        FROM MOVSAP1_MSAP
       WHERE MSAP_CDEMPRESA1 = CODEMP
         AND MSAP_CDPATRIMO1 = VPATRIM
         AND MSAP_CDANEXO1 = VANEXO
         AND MSAP_TPMOV1 = 'D'
         AND TO_CHAR (MSAP_DATA1, 'DD/MM/RR') = TO_CHAR (VULTDATA2, 'DD/MM/RR');
   CURSOR PERIODOLIBSCB
   IS
      SELECT DATA
        FROM (SELECT LIB_DATA AS DATA
                FROM LIBERACAO_LIB
               WHERE LIB_CDEMPRESA = CODEMP
                 AND LIB_CDSISTEMA = 'SCB'
                 AND TO_CHAR (LIB_DATA, 'DD/MM/RR') = TO_CHAR (VULTDATA1, 'DD/MM/RR')
              UNION
              SELECT LPG_DATA AS DATA
                FROM LIBPERGRUPO_LPG LPG, MXS_PERFILUSUARIO_MXPU MXPU
               WHERE LPG.LPG_EMPRESA = CODEMP
                 AND LPG.LPG_CDSISTEMA = 'SCB'
                 AND LPG.LPG_PERFILACESSO = MXPU.MXPU_PERFILACESSO
                 AND MXPU.MXPU_USUARIO = GET_USER_MXM
                 AND TO_CHAR (LPG_DATA, 'DD/MM/RR') = TO_CHAR (VULTDATA1, 'DD/MM/RR'));
   CURSOR PERIODOLIBSAP
   IS
      SELECT LIB_DATA
        FROM LIBERACAO_LIB
       WHERE LIB_CDEMPRESA = CODEMP
         AND LIB_CDSISTEMA = 'SAP'
         AND TO_CHAR (LIB_DATA, 'DD/MM/RR') = TO_CHAR (VULTDATA1, 'DD/MM/RR');
BEGIN
   VMVDEP := 0;
   VSALDO := 0;
   VULTDTLCT1 := '';
   VULTDTLCT2 := '';
   VMOEDA := NULL;
   VDIADEPR := '';
   VGEROUMOV := 'N';
   VULTITEMCTB := '';
   -- Verifica 2a. Moeda --------
   SELECT EMP_SEGMOEDA
     INTO VMOEDA
     FROM EMP
    WHERE EMP_CODIGO = CODEMP;
-------------------------------
-- Pega dia do lancamento da depreciacao ----
   OPEN PARAMDIA;
   FETCH PARAMDIA
    INTO VDIADEPR;
   VACHOU2 := PARAMDIA%FOUND;
   CLOSE PARAMDIA;
---------------------------------------------
-- Verifica "Flag" de controle para depreciar toda a empresa ----
   IF TODOS = 'N'
   THEN
      OPEN PEGAITEM;
      FETCH PEGAITEM
       INTO VCODEMP, VPATRIM, VANEXO, VPRIDPDT1, VPRIDPDT2, VULTMOV1, VULTMOV2, VVALORMAXDEP1, VVALORMAXDEP2,
            VCDPROJETO, VGRUPOPATRIMONIAL, VGRUPOPATRIPROPORCIONAL;
      VACHOU := PEGAITEM%FOUND;
   ELSE
      OPEN PEGAITEM1;
      FETCH PEGAITEM1
       INTO VCODEMP, VPATRIM, VANEXO, VPRIDPDT1, VPRIDPDT2, VULTMOV1, VULTMOV2, VVALORMAXDEP1, VVALORMAXDEP2,
            VCDPROJETO, VGRUPOPATRIMONIAL, VGRUPOPATRIPROPORCIONAL;
      VACHOU := PEGAITEM1%FOUND;
   END IF;
-----------------------------------------------------------------
   WHILE VACHOU
   LOOP
      -- Verifica se item ja possui movimento de primeira depreciac?o na 1a. moeda ------
      OPEN JATEMMOV1;
      FETCH JATEMMOV1
       INTO VAUX;
      VACHOU1 := JATEMMOV1%FOUND;
      IF NOT VACHOU1 OR VULTMOV1 IS NULL
      -- Se nao achou e nao existe dt. do ultimo movimento
      THEN
         VULTMOV1 := VPRIDPDT1;
      END IF;
      VULTDATA1 := NULL;
-----------------------------------------------------------------------------------
      IF VACHOU1                                                                           -- Se ja existir movimento ou
         OR VULTMOV1 > VULTDATA1
      -- a data e ultimo movimento for maior que a data do movimento a ser lancado
      THEN
         -- Pega a data do novo movimento ---
         OPEN ULTDATA1;
         FETCH ULTDATA1
          INTO VULTDATA1;
         CLOSE ULTDATA1;
------------------------------------
         IF (VULTMOV1 > VULTDATA1)
                                  -- Se a data do ultimo movimento for maior que a do novo movimento
            OR (VULTDATA1 IS NULL)                                       -- ou nao existe data para o proximo movimento
         THEN
            BEGIN
               IF (VULTMOV1 < DTBASE) OR (VULTDATA1 IS NULL)
-- Se a data o ultimo movimento for menor que data base (suspensao da depreciacao) ou nao existir data do ultimo movimento
               THEN
                  VULTDATA1 := DTBASE;
               -- A data do proximo movimento recebe a data base
               ELSE
                  VULTDATA1 := VULTMOV1;
               -- A data do proximo movimento recebe a data do ultimo movimento
               END IF;
            END;
         END IF;
      END IF;
      CLOSE JATEMMOV1;
      IF VULTDATA1 IS NULL                                                           -- Se o ultimo movimento nao existe
      THEN
         VULTDATA1 := VULTMOV1;
      END IF;
      -- Se existe dia de lancamento diferenciado, muda a 1a. vez na entrada do "loop" -----
      IF VACHOU2
      THEN
         IF     TO_CHAR (VULTDATA1, 'MM') = '02'                                             -- Se for mes de fevereiro
            AND (VDIADEPR = '29'                                                                       -- e o dia for 29
                 OR VDIADEPR = '30')                                                                            -- ou 30
         THEN
            VULTDATA1 := VULTDATA1;
         -- Mantem o ultimo dia do mes como ja esta
         ELSE
            -- Muda o dia do lancamento da depreciacao na 1a. Moeda ---
            VDIADEPR := TO_CHAR (LAST_DAY (VULTDATA1), 'DD');
            VULTDATA1 := TO_DATE (VDIADEPR || '/' || TO_CHAR (VULTDATA1, 'MM/YYYY'), 'DD/MM/YYYY');
-----------------------------------------------------------
         END IF;
      END IF;
--------------------------------------------------------------------------------------
-- "Loop" de lancamentos de depreciacao na 1a. moeda ---
      WHILE TO_CHAR (DTBASE, 'YYYY/MM') >= TO_CHAR (VULTDATA1, 'YYYY/MM')
      -- Enquanto a database for maior ou igual que a data de lancamento
      LOOP
         -- Verifica se o per�odo est� liberado para movimenta��o patrimonial
         OPEN PERIODOLIBSAP;
         FETCH PERIODOLIBSAP
          INTO VDATALIBPERSAP;
         IF NOT PERIODOLIBSAP%FOUND
         THEN
            RAISE_APPLICATION_ERROR
               (-20000,
                   'PER�ODO DE '
                || TO_CHAR (VULTDATA1, 'DD/MM/RR')
                || ' BLOQUEADO PARA MOVIMENTA��O PATRIMONIAL. FAVOR LIBER�-LO PARA EXECU��O DESTE PROCESSO. - PATRIMONIO: '
                || VPATRIM
               );
         END IF;
         -- Monta o valor residual atual do item a ser depreciado na 1a. moeda --------
         SELECT NVL (PAT_AQUIS1, 0), NVL (PAT_ACRBEM1, 0), NVL (PAT_DEPREC1, 0), NVL (PAT_ACRDEP1, 0),
                NVL (PAT_AQUIS2, 0), PAT_GRPATRIM, PAT_NOCCUSTO, PAT_LOCAL, PAT_RESPONSAVEL, PAT_DTAQUIS, PAT_PDEP1
           INTO VAQUIS1, VACRBEM1, VDEPREC1, VACRDEP1,
                VAQUIS2, GRPAT, VCCUSTO, VLOCAL, VRESPONS, VDTAQUIS, VDTPDEPRES1
           FROM PATRIMON_PAT
          WHERE PAT_CDEMPRESA = VCODEMP AND PAT_CDPATRIMO = VPATRIM AND PAT_CDANEXO = VANEXO;
         -- Obter taxa de depreciacao e ordem se usado taxa variavel
         PRC_DEPRECIACAOPATRIMONIO (VCODEMP, VPATRIM, VANEXO, VPERCDEP1, VULTIMAORDEMUSADA);
------------------------------------------------------------------------------
         -- Verifica se a data de aquisi��o esta dentro do mes da 1� deprecia��o
         IF ((TO_CHAR (VULTDATA1, 'MM/YYYY') = TO_CHAR (VDTAQUIS, 'MM/YYYY')) AND (VGRUPOPATRIPROPORCIONAL = 'S'))
         THEN
            VMVDEP :=
                 (  (((VAQUIS1 + VACRBEM1) - NVL (VVALORMAXDEP1, '0')) * (VPERCDEP1 / 100 / 12))
                  / TO_CHAR (LAST_DAY (VDTPDEPRES1), 'DD')
                 )
               * (TO_CHAR (VDTPDEPRES1, 'DD') - TO_CHAR (VDTAQUIS, 'DD'));
                                                             -- Valor proporcional de dias a ser depreciado na 1a. moeda
         ELSE
            VMVDEP := ((VAQUIS1 + VACRBEM1) - NVL (VVALORMAXDEP1, '0')) * (VPERCDEP1 / 100 / 12);
                                                                                 -- Valor a ser depreciado na 1a. moeda
         END IF;
         VSALDO := (VAQUIS1 + VACRBEM1) - (VDEPREC1 + VACRDEP1) - NVL (VVALORMAXDEP1, '0');
                                                                                       -- Saldo do item a ser depreciado
         IF ((VSALDO > 0) AND (VMVDEP <> 0)
            )                              -- Se o saldo for maior que zero e o valor da deprecia��o for maior que zero.
         THEN
            -- Verica se o item pode ser depreciado -------
            OPEN SEGURANCA;
            FETCH SEGURANCA
             INTO VCODEMP, VPATRIM, VANEXO;
-----------------------------------------------
            IF NOT SEGURANCA%FOUND
            -- Se nao encontrou nada (item apto a ser depreciado)
            THEN
               IF VSALDO > VMVDEP
                                 -- Se o saldo o item for maior que o valor do lancamento
               THEN
                  -- Efetua lancamento de depreciacao no valor do movimento ---
                  VGEROUMOV := 'S';
                  -- Carrega a data de lan�amento cont�bil apenas se for gerar movimenta��o para a data de deprecia��o
                  IF (VULTDTLCT1 > VULTDATA1)
                                             -- S� pode atualizar a data de contabiliza��o caso a data de deprecia��o
                     OR (VULTDTLCT1 IS NULL)
-- seja menor que a contabilizar j� caregada ou ainda n�o tenha alguma data de contabiliza��o
                  THEN
                     VULTDTLCT1 := VULTDATA1;
                     VULTITEMCTB := VPATRIM;
                  END IF;
                  VDATATMP :=
                     GET_DATA_CORRIGIDA (TO_NUMBER (TO_CHAR (DTBASE, 'DD')),
                                         TO_NUMBER (TO_CHAR (VULTDATA1, 'MM')),
                                         TO_NUMBER (TO_CHAR (VULTDATA1, 'RRRR'))
                                        );
                  VSEQMOVSAP := NULL;
                  INSMOVSAP_MSAP (VCODEMP,
                                  VPATRIM,
                                  VANEXO,
                                  VDATATMP,
                                  'D',
                                  VCCUSTO,
                                  VLOCAL,
                                  VRESPONS,
                                  0,
                                  VMVDEP,
                                  VPERCDEP1,
                                  0,
                                  0,
                                  0,
                                  '',
                                  '',
                                  VULTIMAORDEMUSADA,
                                  VSEQMOVSAP
                                 );
-------------------------------------------------------------
               ELSE
                  -- Efetua lancamento de depreciacao no valor do saldo residual ---
                  VGEROUMOV := 'S';
                  -- Carrega a data de lan�amento cont�bil apenas se for gerar movimenta��o para a data de deprecia��o
                  IF (VULTDTLCT1 > VULTDATA1)
                                             -- S� pode atualizar a data de contabiliza��o caso a data de deprecia��o
                     OR (VULTDTLCT1 IS NULL)
-- seja menor que a contabilizar j� caregada ou ainda n�o tenha alguma data de contabiliza��o
                  THEN
                     VULTDTLCT1 := VULTDATA1;
                  END IF;
                  VDATATMP :=
                     GET_DATA_CORRIGIDA (TO_NUMBER (TO_CHAR (DTBASE, 'DD')),
                                         TO_NUMBER (TO_CHAR (VULTDATA1, 'MM')),
                                         TO_NUMBER (TO_CHAR (VULTDATA1, 'RRRR'))
                                        );
                  VSEQMOVSAP := NULL;
                  INSMOVSAP_MSAP (VCODEMP,
                                  VPATRIM,
                                  VANEXO,
                                  VDATATMP,
                                  'D',
                                  VCCUSTO,
                                  VLOCAL,
                                  VRESPONS,
                                  0,
                                  VSALDO,
                                  VPERCDEP1,
                                  0,
                                  0,
                                  0,
                                  '',
                                  '',
                                  VULTIMAORDEMUSADA,
                                  VSEQMOVSAP
                                 );
------------------------------------------------------------------
               END IF;
            END IF;
            CLOSE SEGURANCA;
         END IF;
         IF VSALDO > 0                                                          -- Se o saldo do item for maior que zero
         THEN
            -- Pega proxima provavel data de lancamento do item --
            OPEN ULTDATA1;
            FETCH ULTDATA1
             INTO VULTDATA1;
            CLOSE ULTDATA1;
------------------------------------------------------
            IF VACHOU2                                                      -- Se existe dia de lancamento diferenciado
            THEN
               IF     (TO_CHAR (VULTDATA1, 'MM') = '02')                                     -- Se for mes de fevereiro
                  AND (VDIADEPR = '29'                                                                 -- e o dia for 29
                       OR VDIADEPR = '30')                                                                      -- ou 30
               THEN
                  VULTDATA1 := VULTDATA1;
               -- Mantem o ultimo dia do mes como ja esta
               ELSE
                  -- Muda o dia do lancamento da depreciacao na 1a. Moeda ---
                  VDIADEPR := TO_CHAR (LAST_DAY (VULTDATA1), 'DD');
                  VULTDATA1 := TO_DATE (VDIADEPR || '/' || TO_CHAR (VULTDATA1, 'MM/YYYY'), 'DD/MM/YYYY');
               END IF;
               IF (TO_CHAR (VULTDTLCT1, 'MM') = '02') AND (VDIADEPR = '29' OR VDIADEPR = '30')
               THEN
                  VULTDTLCT1 := VULTDTLCT1;
               ELSE
                  -- Muda o dia do lancamento contabil na 2a. Moeda ---------
                  VDIADEPR := TO_CHAR (LAST_DAY (VULTDTLCT1), 'DD');
                  VULTDTLCT1 := TO_DATE (VDIADEPR || '/' || TO_CHAR (VULTDTLCT1, 'MM/YYYY'), 'DD/MM/YYYY');
-----------------------------------------------------------
               END IF;
            END IF;
         ELSE
            VULTDATA1 := DTBASE + 1;
         -- Forca a saida o "loop" de lancamentos na 1a. moeda
         END IF;
         CLOSE PERIODOLIBSAP;
      END LOOP;
      IF NOT VMOEDA IS NULL                                                                  -- Se existir segunda moeda
         OR (VAQUIS2 <> 0 AND NOT VAQUIS2 IS NULL)
      -- ou valor da aquisicao na 2a. moeda nao for diferente de zero e nao nulo
      THEN
         -- Verifica se item ja possui movimento de primeira depreciac?o na 2a. moeda ------
         OPEN JATEMMOV2;
         FETCH JATEMMOV2
          INTO VAUX;
         VACHOU1 := JATEMMOV2%FOUND;
         IF NOT VACHOU1 OR VULTMOV2 IS NULL
         -- Se nao achou e nao existe dt. do ultimo movimento
         THEN
            VULTMOV2 := VPRIDPDT2;
         END IF;
         VULTDATA2 := NULL;
-----------------------------------------------------------------------------------
         IF VACHOU1                                                                        -- Se ja existir movimento ou
            OR VULTMOV2 > VULTDATA2
         -- a data e ultimo movimento for maior que a data do movimento a ser lancado
         THEN
            -- Pega a data do novo movimento ---
            OPEN ULTDATA2;
            FETCH ULTDATA2
             INTO VULTDATA2;
            CLOSE ULTDATA2;
------------------------------------
            IF (VULTMOV2 > VULTDATA2)
                                     -- Se a data do ultimo movimento for maior que a do novo movimento
               OR (VULTDATA2 IS NULL)                                    -- ou nao existe data para o proximo movimento
            THEN
               BEGIN
                  IF (VULTMOV2 < DTBASE) OR (VULTDATA2 IS NULL)
-- Se a data o ultimo movimento for menor que data base (suspensao da depreciacao)
                  THEN
                     VULTDATA2 := DTBASE;
                  -- A data do proximo movimento recebe a data base
                  ELSE
                     VULTDATA2 := VULTMOV2;
                  -- A data do proximo movimento recebe a data do ultimo movimento
                  END IF;
               END;
            END IF;
         END IF;
         CLOSE JATEMMOV2;
         IF VULTDATA2 IS NULL                                                        -- Se o ultimo movimento nao existe
         THEN
            VULTDATA2 := VULTMOV2;
         END IF;
         VULTDTLCT2 := VULTDATA2;
                           -- Inicializa data de lancamento contabil 2a. moeda
         -- Se existe dia de lancamento diferenciado, muda a 1a. vez na entrada do "loop" -----
         IF VACHOU2
         THEN
            IF TO_CHAR (VULTDATA2, 'MM') = '02'
                                               -- Se for mes de fevereiro
               AND (VDIADEPR = '29'                                                                   -- e o dia for 29
                    OR VDIADEPR = '30')                                                                        -- ou 30
            THEN
               VULTDATA2 := VULTDATA2;
            -- Mantem o ultimo dia do mes como ja esta
            ELSE
               -- Muda o dia do lancamento da depreciacao na 1a. Moeda ---
               IF VULTDATA2 IS NOT NULL
               THEN
                  VDIADEPR := TO_CHAR (LAST_DAY (VULTDATA2), 'DD');
                  VULTDATA2 := TO_DATE (VDIADEPR || '/' || TO_CHAR (VULTDATA2, 'MM/YYYY'), 'DD/MM/YYYY');
               END IF;
-----------------------------------------------------------
            END IF;
         END IF;
--------------------------------------------------------------------------------------
-- "Loop" de lancamentos de depreciacao na 2a. moeda ---
         WHILE TO_CHAR (DTBASE, 'YYYY/MM') >= TO_CHAR (VULTDATA2, 'YYYY/MM')
         -- Enquanto a database for maior que a data de lancamento
         LOOP
            -- Monta o valor residual atual do item a ser depreciado na 2a. moeda --------
            SELECT NVL (PAT_AQUIS2, 0), NVL (PAT_ACRBEM2, 0), NVL (PAT_DEPREC2, 0), NVL (PAT_ACRDEP2, 0),
                   NVL (PAT_PERCDEP2, 0), PAT_GRPATRIM, PAT_NOCCUSTO, PAT_LOCAL, PAT_RESPONSAVEL, PAT_DTAQUIS,
                   PAT_PDEP2
              INTO VAQUIS2, VACRBEM2, VDEPREC2, VACRDEP2,
                   VPERCDEP2, GRPAT, VCCUSTO, VLOCAL, VRESPONS, VDTAQUIS,
                   VDTPDEPRES2
              FROM PATRIMON_PAT
             WHERE PAT_CDEMPRESA = VCODEMP AND PAT_CDPATRIMO = VPATRIM AND PAT_CDANEXO = VANEXO;
------------------------------------------------------------------------------
         -- Verifica se a data de aquisi��o esta dentro do mes da 1� deprecia��o
            IF ((TO_CHAR (VULTDATA2, 'MM/YYYY') = TO_CHAR (VDTPDEPRES2, 'MM/YYYY')) AND (VGRUPOPATRIPROPORCIONAL = 'S')
               )
            THEN
               VMVDEP :=
                    (((VAQUIS2 + VACRBEM2) * (VPERCDEP2 / 100 / 12)) / TO_CHAR (LAST_DAY (VDTPDEPRES2), 'DD'))
                  * (TO_CHAR (VDTPDEPRES2, 'DD') - TO_CHAR (VDTAQUIS, 'DD'));
            -- Valor proporcional de dias a ser depreciado na 2a. moeda
            ELSE
               VMVDEP := (VAQUIS2 + VACRBEM2) * (VPERCDEP2 / 100 / 12);
            -- Valor a ser depreciado na 2a. moeda
            END IF;
            VSALDO := (VAQUIS2 + VACRBEM2) - (VDEPREC2 + VACRDEP2) - NVL (VVALORMAXDEP2, '0');
                                                                                       -- Saldo do item a ser depreciado
            IF (VSALDO > 0)                                                            -- Se o saldo for maior que zero.
            THEN
               -- Verica se o item pode ser depreciado -------
               OPEN SEGURANCA1;
               FETCH SEGURANCA1
                INTO VCODEMP, VPATRIM, VANEXO;
-----------------------------------------------
               IF NOT SEGURANCA1%FOUND
               -- Se nao encontrou nada (item apto a ser depreciado)
               THEN
                  IF VULTDTLCT2 IS NULL
                  -- Se a 1a. data de lancamento contabil nao estiver inicializada
                  THEN
                     VULTDTLCT2 := VULTDATA2;
                  -- 1a. data de lancamento contabil recebe a data do 1o. movimento
                  END IF;
                  IF VSALDO > VMVDEP
                                    -- Se o saldo o item for maior que o valor do lancamento
                  THEN
                     -- Efetua lancamento de depreciacao no valor do movimento ---
                     VGEROUMOV := 'S';
                     -- Carrega a data de lan�amento cont�bil apenas se for gerar movimenta��o para a data de deprecia��o
                     IF (VULTDTLCT1 > VULTDATA1)
                                                -- S� pode atualizar a data de contabiliza��o caso a data de deprecia��o
                        OR (VULTDTLCT1 IS NULL)
-- seja menor que a contabilizar j� caregada ou ainda n�o tenha alguma data de contabiliza��o
                     THEN
                        VULTDTLCT1 := VULTDATA1;
                     END IF;
                     VDATATMP :=
                        GET_DATA_CORRIGIDA (TO_NUMBER (TO_CHAR (DTBASE, 'DD')),
                                            TO_NUMBER (TO_CHAR (VULTDATA2, 'MM')),
                                            TO_NUMBER (TO_CHAR (VULTDATA2, 'RRRR'))
                                           );
                     VSEQMOVSAP1 := NULL;
                     INSMOVSAP1_MSAP (VCODEMP,
                                      VPATRIM,
                                      VANEXO,
                                      VDATATMP,
                                      'D',
                                      VCCUSTO,
                                      VLOCAL,
                                      VRESPONS,
                                      0,
                                      VMVDEP,
                                      VPERCDEP2,
                                      0,
                                      0,
                                      0,
                                      '',
                                      '',
                                      VSEQMOVSAP1
                                     );
-------------------------------------------------------------
                  ELSE
                     -- Efetua lancamento de depreciacao no valor do saldo residual ---
                     VGEROUMOV := 'S';
                     -- Carrega a data de lan�amento cont�bil apenas se for gerar movimenta��o para a data de deprecia��o
                     IF (VULTDTLCT1 > VULTDATA1)
                                                -- S� pode atualizar a data de contabiliza��o caso a data de deprecia��o
                        OR (VULTDTLCT1 IS NULL)
-- seja menor que a contabilizar j� caregada ou ainda n�o tenha alguma data de contabiliza��o
                     THEN
                        VULTDTLCT1 := VULTDATA1;
                     END IF;
                     VDATATMP :=
                        GET_DATA_CORRIGIDA (TO_NUMBER (TO_CHAR (DTBASE, 'DD')),
                                            TO_NUMBER (TO_CHAR (VULTDATA2, 'MM')),
                                            TO_NUMBER (TO_CHAR (VULTDATA2, 'RRRR'))
                                           );
                     VSEQMOVSAP1 := NULL;
                     INSMOVSAP1_MSAP (VCODEMP,
                                      VPATRIM,
                                      VANEXO,
                                      VDATATMP,
                                      'D',
                                      VCCUSTO,
                                      VLOCAL,
                                      VRESPONS,
                                      0,
                                      VSALDO,
                                      VPERCDEP2,
                                      0,
                                      0,
                                      0,
                                      '',
                                      '',
                                      VSEQMOVSAP1
                                     );
-------------------------------------------------------------
                  END IF;
               END IF;
               CLOSE SEGURANCA1;
            END IF;
            IF VSALDO > 0                                                       -- Se o saldo do item for maior que zero
            THEN
               -- Pega proxima provavel data de lancamento do item --
               OPEN ULTDATA2;
               FETCH ULTDATA2
                INTO VULTDATA2;
               CLOSE ULTDATA2;
------------------------------------------------------
               IF VACHOU2                                                   -- Se existe dia de lancamento diferenciado
               THEN
                  IF TO_CHAR (VULTDATA2, 'MM') = '02'
                     -- Se for mes de fevereiro
                     AND (VDIADEPR = '29'                                                             -- e o dia for 29
                          OR VDIADEPR = '30')                                                                  -- ou 30
                  THEN
                     VULTDATA2 := VULTDATA2;
                  -- Mantem o ultimo dia do mes como ja esta
                  ELSE
                     -- Muda o dia do lancamento da depreciacao na 1a. Moeda ---
                     IF VULTDATA2 IS NOT NULL
                     THEN
                        VDIADEPR := TO_CHAR (LAST_DAY (VULTDATA2), 'DD');
                        VULTDATA2 := TO_DATE (VDIADEPR || '/' || TO_CHAR (VULTDATA2, 'MM/YYYY'), 'DD/MM/YYYY');
-----------------------------------------------------------
                     END IF;
                  END IF;
                  IF (TO_CHAR (VULTDTLCT2, 'mm') = '02') AND (VDIADEPR = '29' OR VDIADEPR = '30')
                  THEN
                     VULTDTLCT2 := VULTDTLCT2;
                  ELSE
                     -- Muda o dia do lancamento contabil na 2a. Moeda ---------
                     IF VULTDATA2 IS NOT NULL
                     THEN
                        VDIADEPR := TO_CHAR (LAST_DAY (VULTDTLCT2), 'DD');
                        VULTDTLCT2 := TO_DATE (VDIADEPR || '/' || TO_CHAR (VULTDTLCT2, 'MM/YYYY'), 'DD/MM/YYYY');
-----------------------------------------------------------
                     END IF;
                  END IF;
               END IF;
            ELSE
               VULTDATA2 := DTBASE + 1;
            -- Forca a saida o "loop" de lancamentos na 2a. moeda
            END IF;
         END LOOP;
      END IF;
      -- Verifica "Flag" de controle para depreciar toda a empresa, e pegar item seguinte ----
      IF TODOS = 'N'
      THEN
         FETCH PEGAITEM
          INTO VCODEMP, VPATRIM, VANEXO, VPRIDPDT1, VPRIDPDT2, VULTMOV1, VULTMOV2, VVALORMAXDEP1, VVALORMAXDEP2,
               VCDPROJETO, VGRUPOPATRIMONIAL, VGRUPOPATRIPROPORCIONAL;
         VACHOU := PEGAITEM%FOUND;
      ELSE
         FETCH PEGAITEM1
          INTO VCODEMP, VPATRIM, VANEXO, VPRIDPDT1, VPRIDPDT2, VULTMOV1, VULTMOV2, VVALORMAXDEP1, VVALORMAXDEP2,
               VCDPROJETO, VGRUPOPATRIMONIAL, VGRUPOPATRIPROPORCIONAL;
         VACHOU := PEGAITEM1%FOUND;
      END IF;
   END LOOP;
   IF TODOS = 'N'
   THEN
      CLOSE PEGAITEM;
   ELSE
      CLOSE PEGAITEM1;
   END IF;
   -- Gera lancamentos contabeis
   IF CONTABIL = 'S' AND NOT VULTDTLCT1 IS NULL AND VGEROUMOV = 'S'
   THEN
      IF VULTDTLCT1 > DTBASE
      THEN
         VULTDTLCT1 := DTBASE;
      END IF;
      IF TODOS = 'N'
      THEN
         OPEN LANCAMENTO;
         FETCH LANCAMENTO
          INTO VCTADEP, VDESPDEP, VCCUSTO, VGRPATRIM, VGRCONT, VULTDATA1, VTOTDEP, VTOTDEP1, VCDPROJETO;
         VACHOU := LANCAMENTO%FOUND;
      ELSE
         OPEN LANCAMENTOA;
         FETCH LANCAMENTOA
          INTO VCTADEP, VDESPDEP, VCCUSTO, VGRPATRIM, VGRCONT, VULTDATA1, VTOTDEP, VTOTDEP1, VCDPROJETO;
         VACHOU := LANCAMENTOA%FOUND;
      END IF;
      SELECT DECODE (SUM (NVL (PAT_DEPREC2, 0)), 0, 'N', 'S')
        INTO AMTMOEDA
        FROM PATRIMON_PAT
       WHERE PAT_GRPATRIM = VGRPATRIM;
      IF NOT VACHOU
      THEN
         IF VGRCONT = 'S' OR VGRCONT IS NULL
         THEN
            RAISE_APPLICATION_ERROR (-20000,
                                        'NAO FORAM ENCONTRADAS CONTAS PARA CONTABILIZACAO DA DEPRECIACAO DA EMPRESA '
                                     || CODEMP
                                     || ' ITEM PATRIMONIAL DO GRUPO '
                                     || VGRUPOPATRIMONIAL
                                    );
         END IF;
      END IF;
      WHILE VACHOU
      LOOP
         SELECT LTRIM (TO_CHAR (TO_NUMBER (PAR_VLPARAM) + 1, '000000'))
           INTO LANCTO
           FROM PARAMS_PAR
          WHERE PAR_CDPARAM = 'wPAR_NAUTOLANC';
         UPDATE PARAMS_PAR
            SET PAR_VLPARAM = LANCTO
          WHERE PAR_CDPARAM = 'wPAR_NAUTOLANC';
         LOTE := 'SAP_DP';
         HISTORICO := '';
         OPEN PARAMHIST;
         FETCH PARAMHIST
          INTO VHISTORICO;
         CLOSE PARAMHIST;
         IF (VHISTORICO = '') OR (VHISTORICO IS NULL)
         THEN
            VHISTORICO := 'DEPRECIACAO/AMORTIZACAO @D DO GRUPO @G';
         END IF;
         FOR A IN 1 .. LENGTH (VHISTORICO)
         LOOP
            IF SUBSTR (VHISTORICO, A, 1) = '@'
            THEN
               IF SUBSTR (VHISTORICO, A, 2) = '@D'
               THEN
                  HISTORICO := HISTORICO || TO_CHAR (VULTDATA1, 'MM/YYYY');
               END IF;
               IF SUBSTR (VHISTORICO, A, 2) = '@G'
               THEN
                  HISTORICO := HISTORICO || VGRPATRIM;
               END IF;
            ELSE
               IF A > 1
               THEN
                  IF SUBSTR (VHISTORICO, A - 1, 1) <> '@'
                  THEN
                     HISTORICO := HISTORICO || SUBSTR (VHISTORICO, A, 1);
                  END IF;
               ELSE
                  HISTORICO := HISTORICO || SUBSTR (VHISTORICO, A, 1);
               END IF;
            END IF;
         END LOOP;
         OPEN PERIODOLIBSCB;
         FETCH PERIODOLIBSCB
          INTO VDATALIBPER;
         IF NOT PERIODOLIBSCB%FOUND
         THEN
            RAISE_APPLICATION_ERROR
                            (-20000,
                                'PER�ODO DE '
                             || TO_CHAR (VULTDATA1, 'DD/MM/RR')
                             || ' BLOQUEADO PARA CONTABILIZA��O. FAVOR LIBER�-LO PARA EXECU��O DESTE PROCESSO. Conta: '
                             || VCTADEP
                             || '| Centro de Custo: '
                             || VCCUSTO
                             || ' | Valor: '
                             || VTOTDEP
                             || ' Patrim�nio: ('
                             || VULTITEMCTB
                             || ')'
                            );
         END IF;
         IF PERIODOLIBSCB%FOUND AND VGRCONT = 'S'
         THEN
            IF (VCTADEP IS NOT NULL AND VDESPDEP IS NOT NULL) OR (VCTADEP IS NULL AND VDESPDEP IS NULL)
            THEN
               VSTACCUSTO := VALIDCCUST (CODEMP, CODPLAN, VCTADEP, VCCUSTO);
               IF VSTACCUSTO >= 1
               THEN
                  IF VSTACCUSTO = 2
                  -- nao pode ter centro de custo, assim limpo o mesmo.
                  THEN
                     ACCUSTO := '';
                  ELSE
                     ACCUSTO := VCCUSTO;
                  END IF;
                  IF VTOTDEP1 = 0 AND AMTMOEDA = 'N'
                  THEN
                     VMOEDAL := '';
                  ELSE
                     VMOEDAL := VMOEDA;
                  END IF;
                  INSLANCCTB_LCT (CODEMP,
                                  LOTE,
                                  VULTDATA1,
                                  LTRIM (LANCTO),
                                  '1',
                                  VCTADEP,
                                  ACCUSTO,
                                  HISTORICO,
                                  'C',
                                  ABS (VTOTDEP),
                                  ABS (VTOTDEP1),
                                  '',
                                  VMOEDAL,
                                  '',
                                  '',
                                  VCDPROJETO
                                 );
               --Se o resultado do valida centro de custo for 0 ou -1 ou -2
               ELSE
                  IF VSTACCUSTO = -2
                  THEN
                     RAISE_APPLICATION_ERROR (-20000,
                                              'CENTRO DE CUSTO ' || VCCUSTO || ' INATIVO PARA GERAR CONTABILIZAC?O. '
                                             );
                  ELSE
                     IF VSTACCUSTO < 0 OR VCCUSTO IS NULL
                     THEN
                        RAISE_APPLICATION_ERROR
                                     (-20000,
                                      'CENTRO DE CUSTO OBRIGATORIO PARA CONTABILIZAR O(S) PATRIMONIO(S) INFORMADO(S). '
                                     );
                     ELSE
                        RAISE_APPLICATION_ERROR (-20000,
                                                 'CENTRO DE CUSTO ' || VCCUSTO || ' INVALIDO PARA CONTA ' || VCTADEP
                                                 || '.'
                                                );
                     END IF;
                  END IF;
               END IF;
               VSTACCUSTO := VALIDCCUST (CODEMP, CODPLAN, VDESPDEP, VCCUSTO);
               IF VSTACCUSTO >= 1
               THEN
                  IF VSTACCUSTO = 2
                  -- nao pode ter centro de custo, assim limpo o mesmo.
                  THEN
                     ACCUSTO := '';
                  ELSE
                     ACCUSTO := VCCUSTO;
                  END IF;
                  IF VTOTDEP1 = 0 AND AMTMOEDA = 'N'
                  THEN
                     VMOEDAL := '';
                  ELSE
                     VMOEDAL := VMOEDA;
                  END IF;
                  INSLANCCTB_LCT (CODEMP,
                                  LOTE,
                                  VULTDATA1,
                                  LTRIM (LANCTO),
                                  '2',
                                  VDESPDEP,
                                  ACCUSTO,
                                  HISTORICO,
                                  'D',
                                  ABS (VTOTDEP),
                                  ABS (VTOTDEP1),
                                  '',
                                  VMOEDAL,
                                  '',
                                  '',
                                  VCDPROJETO
                                 );
               ELSE
                  IF VSTACCUSTO = -2
                  THEN
                     RAISE_APPLICATION_ERROR (-20000,
                                              'CENTRO DE CUSTO ' || VCCUSTO || ' INATIVO PARA GERAR CONTABILIZAC?O. '
                                             );
                  ELSE
                     IF VSTACCUSTO < 0 OR VCCUSTO IS NULL
                     THEN
                        RAISE_APPLICATION_ERROR
                                  (-20000,
                                      'CENTRO DE CUSTO OBRIGATORIO PARA CONTABILIZAR O(S) PATRIMONIO(S) INFORMADO(S). '
                                   || VPATRIM
                                  );
                     ELSE
                        RAISE_APPLICATION_ERROR (-20000,
                                                 'CENTRO DE CUSTO ' || VCCUSTO || ' INVALIDO PARA CONTA ' || VDESPDEP
                                                 || '.'
                                                );
                     END IF;
                  END IF;
               END IF;
               IF TODOS = 'N'
               THEN
                  OPEN PGITEM;
                  FETCH PGITEM
                   INTO VPATRIM, VANEXO;
                  VACHOU2 := PGITEM%FOUND;
               ELSE
                  OPEN PGITEM1;
                  FETCH PGITEM1
                   INTO VPATRIM, VANEXO;
                  VACHOU2 := PGITEM1%FOUND;
               END IF;
               WHILE VACHOU2 AND VGRCONT = 'S'
               LOOP
                  UPDATE MOVSAP_MSAP
                     SET MSAP_LANCCTB = LANCTO
                   WHERE MSAP_CDPATRIMO = VPATRIM
                     AND MSAP_CDANEXO = VANEXO
                     AND (VCCUSTO IS NULL OR MSAP_CCUSTO = VCCUSTO)
                     AND MSAP_CDEMPRESA = CODEMP
                     AND MSAP_TPMOV = 'D'
                     AND TO_DATE (MSAP_DATA, 'DD/MM/RR') = TO_DATE (VULTDATA1, 'DD/MM/RR');
                  IF TODOS = 'N'
                  THEN
                     FETCH PGITEM
                      INTO VPATRIM, VANEXO;
                     VACHOU2 := PGITEM%FOUND;
                  ELSE
                     FETCH PGITEM1
                      INTO VPATRIM, VANEXO;
                     VACHOU2 := PGITEM1%FOUND;
                  END IF;
               END LOOP;
               IF TODOS = 'N'
               THEN
                  CLOSE PGITEM;
               ELSE
                  CLOSE PGITEM1;
               END IF;
               IF TODOS = 'N'
               THEN
                  FETCH LANCAMENTO
                   INTO VCTADEP, VDESPDEP, VCCUSTO, VGRPATRIM, VGRCONT, VULTDATA1, VTOTDEP, VTOTDEP1, VCDPROJETO;
                  VACHOU := LANCAMENTO%FOUND;
               ELSE
                  FETCH LANCAMENTOA
                   INTO VCTADEP, VDESPDEP, VCCUSTO, VGRPATRIM, VGRCONT, VULTDATA1, VTOTDEP, VTOTDEP1, VCDPROJETO;
                  VACHOU := LANCAMENTOA%FOUND;
               END IF;
            ELSE
               /* ------------------------------------------------------------
                   Contas que nao permitem centro de custo
               ------------------------------------------------------------  */
               VSEQUENCIAL := 1;
               IF VCTADEP IS NULL AND VDESPDEP IS NOT NULL
               THEN
                  WHILE VACHOU AND VDESPDEP IS NOT NULL AND VCTADEP IS NULL
                  LOOP
                     VSTACCUSTO := VALIDCCUST (CODEMP, CODPLAN, VDESPDEP, VCCUSTO);
                     IF VSTACCUSTO >= 1
                     THEN
                        IF VSTACCUSTO = 2
                        -- nao pode ter centro de custo, assim limpo o mesmo.
                        THEN
                           ACCUSTO := '';
                        ELSE
                           ACCUSTO := VCCUSTO;
                        END IF;
                        IF VTOTDEP1 = 0 AND AMTMOEDA = 'N'
                        THEN
                           VMOEDAL := '';
                        ELSE
                           VMOEDAL := VMOEDA;
                        END IF;
                        INSLANCCTB_LCT (CODEMP,
                                        LOTE,
                                        VULTDATA1,
                                        LTRIM (LANCTO),
                                        TO_CHAR (VSEQUENCIAL),
                                        VDESPDEP,
                                        ACCUSTO,
                                        HISTORICO,
                                        'D',
                                        ABS (VTOTDEP),
                                        ABS (VTOTDEP1),
                                        '',
                                        VMOEDAL,
                                        '',
                                        '',
                                        VCDPROJETO
                                       );
                     ELSE
                        IF VSTACCUSTO = -2
                        THEN
                           RAISE_APPLICATION_ERROR (-20000,
                                                       'CENTRO DE CUSTO '
                                                    || VCCUSTO
                                                    || ' INATIVO PARA GERAR CONTABILIZAC?O. '
                                                   );
                        ELSE
                           IF VSTACCUSTO < 0 OR VCCUSTO IS NULL
                           THEN
                              RAISE_APPLICATION_ERROR
                                     (-20000,
                                      'CENTRO DE CUSTO OBRIGATORIO PARA CONTABILIZAR O(S) PATRIMONIO(S) INFORMADO(S). '
                                     );
                           ELSE
                              RAISE_APPLICATION_ERROR (-20000,
                                                          'CENTRO DE CUSTO '
                                                       || VCCUSTO
                                                       || ' INVALIDO PARA CONTA '
                                                       || VDESPDEP
                                                       || '.'
                                                      );
                           END IF;
                        END IF;
                     END IF;
                     VSEQUENCIAL := VSEQUENCIAL + 1;
                     IF TODOS = 'N'
                     THEN
                        OPEN PGITEM;
                        FETCH PGITEM
                         INTO VPATRIM, VANEXO;
                        VACHOU2 := PGITEM%FOUND;
                     ELSE
                        OPEN PGITEM1;
                        FETCH PGITEM1
                         INTO VPATRIM, VANEXO;
                        VACHOU2 := PGITEM1%FOUND;
                     END IF;
                     WHILE VACHOU2 AND VGRCONT = 'S'
                     LOOP
                        UPDATE MOVSAP_MSAP
                           SET MSAP_LANCCTB = LANCTO
                         WHERE MSAP_CDPATRIMO = VPATRIM
                           AND MSAP_CDANEXO = VANEXO
                           AND (VCCUSTO IS NULL OR MSAP_CCUSTO = VCCUSTO)
                           AND MSAP_CDEMPRESA = CODEMP
                           AND MSAP_TPMOV = 'D'
                           AND TO_DATE (MSAP_DATA, 'DD/MM/RR') = TO_DATE (VULTDATA1, 'DD/MM/RR');
                        IF TODOS = 'N'
                        THEN
                           FETCH PGITEM
                            INTO VPATRIM, VANEXO;
                           VACHOU2 := PGITEM%FOUND;
                        ELSE
                           FETCH PGITEM1
                            INTO VPATRIM, VANEXO;
                           VACHOU2 := PGITEM1%FOUND;
                        END IF;
                     END LOOP;
                     IF TODOS = 'N'
                     THEN
                        CLOSE PGITEM;
                     ELSE
                        CLOSE PGITEM1;
                     END IF;
                     IF TODOS = 'N'
                     THEN
                        FETCH LANCAMENTO
                         INTO VCTADEP, VDESPDEP, VCCUSTO, VGRPATRIM, VGRCONT, VULTDATA1, VTOTDEP, VTOTDEP1, VCDPROJETO;
                        VACHOU := LANCAMENTO%FOUND;
                     ELSE
                        FETCH LANCAMENTOA
                         INTO VCTADEP, VDESPDEP, VCCUSTO, VGRPATRIM, VGRCONT, VULTDATA1, VTOTDEP, VTOTDEP1, VCDPROJETO;
                        VACHOU := LANCAMENTOA%FOUND;
                     END IF;
                  END LOOP;
               END IF;
               IF VCTADEP IS NOT NULL AND VDESPDEP IS NULL
               THEN
                  WHILE VACHOU AND VCTADEP IS NOT NULL AND VDESPDEP IS NULL
                  LOOP
                     VSTACCUSTO := VALIDCCUST (CODEMP, CODPLAN, VCTADEP, VCCUSTO);
                     IF VSTACCUSTO >= 1
                     THEN
                        IF VSTACCUSTO = 2
                        -- nao pode ter centro de custo, assim limpo o mesmo.
                        THEN
                           ACCUSTO := '';
                        ELSE
                           ACCUSTO := VCCUSTO;
                        END IF;
                        IF VTOTDEP1 = 0 AND AMTMOEDA = 'N'
                        THEN
                           VMOEDAL := '';
                        ELSE
                           VMOEDAL := VMOEDA;
                        END IF;
                        INSLANCCTB_LCT (CODEMP,
                                        LOTE,
                                        VULTDATA1,
                                        LTRIM (LANCTO),
                                        TO_CHAR (VSEQUENCIAL),
                                        VCTADEP,
                                        ACCUSTO,
                                        HISTORICO,
                                        'C',
                                        ABS (VTOTDEP),
                                        ABS (VTOTDEP1),
                                        '',
                                        VMOEDAL,
                                        '',
                                        '',
                                        VCDPROJETO
                                       );
                     ELSE
                        IF VSTACCUSTO = -2
                        THEN
                           RAISE_APPLICATION_ERROR (-20000,
                                                       'CENTRO DE CUSTO '
                                                    || VCCUSTO
                                                    || ' INATIVO PARA GERAR CONTABILIZAC?O. '
                                                   );
                        ELSE
                           IF VSTACCUSTO < 0 OR VCCUSTO IS NULL
                           THEN
                              RAISE_APPLICATION_ERROR
                                     (-20000,
                                      'CENTRO DE CUSTO OBRIGATORIO PARA CONTABILIZAR O(S) PATRIMONIO(S) INFORMADO(S). '
                                     );
                           ELSE
                              RAISE_APPLICATION_ERROR (-20000,
                                                          'CENTRO DE CUSTO '
                                                       || VCCUSTO
                                                       || ' INVALIDO PARA CONTA '
                                                       || VCTADEP
                                                       || '.'
                                                      );
                           END IF;
                        END IF;
                     END IF;
                     VSEQUENCIAL := VSEQUENCIAL + 1;
                     IF TODOS = 'N'
                     THEN
                        OPEN PGITEM;
                        FETCH PGITEM
                         INTO VPATRIM, VANEXO;
                        VACHOU2 := PGITEM%FOUND;
                     ELSE
                        OPEN PGITEM1;
                        FETCH PGITEM1
                         INTO VPATRIM, VANEXO;
                        VACHOU2 := PGITEM1%FOUND;
                     END IF;
                     WHILE VACHOU2 AND VGRCONT = 'S'
                     LOOP
                        UPDATE MOVSAP_MSAP
                           SET MSAP_LANCCTB = LANCTO
                         WHERE MSAP_CDPATRIMO = VPATRIM
                           AND MSAP_CDANEXO = VANEXO
                           AND (VCCUSTO IS NULL OR MSAP_CCUSTO = VCCUSTO)
                           AND MSAP_CDEMPRESA = CODEMP
                           AND MSAP_TPMOV = 'D'
                           AND MSAP_DATA = VULTDATA1;
                        IF TODOS = 'N'
                        THEN
                           FETCH PGITEM
                            INTO VPATRIM, VANEXO;
                           VACHOU2 := PGITEM%FOUND;
                        ELSE
                           FETCH PGITEM1
                            INTO VPATRIM, VANEXO;
                           VACHOU2 := PGITEM1%FOUND;
                        END IF;
                     END LOOP;
                     IF TODOS = 'N'
                     THEN
                        CLOSE PGITEM;
                     ELSE
                        CLOSE PGITEM1;
                     END IF;
                     IF TODOS = 'N'
                     THEN
                        FETCH LANCAMENTO
                         INTO VCTADEP, VDESPDEP, VCCUSTO, VGRPATRIM, VGRCONT, VULTDATA1, VTOTDEP, VTOTDEP1, VCDPROJETO;
                        VACHOU := LANCAMENTO%FOUND;
                     ELSE
                        FETCH LANCAMENTOA
                         INTO VCTADEP, VDESPDEP, VCCUSTO, VGRPATRIM, VGRCONT, VULTDATA1, VTOTDEP, VTOTDEP1, VCDPROJETO;
                        VACHOU := LANCAMENTOA%FOUND;
                     END IF;
                  END LOOP;
               END IF;
            END IF;
         ELSE
            IF TODOS = 'N'
            THEN
               FETCH LANCAMENTO
                INTO VCTADEP, VDESPDEP, VCCUSTO, VGRPATRIM, VGRCONT, VULTDATA1, VTOTDEP, VTOTDEP1, VCDPROJETO;
               VACHOU := LANCAMENTO%FOUND;
            ELSE
               FETCH LANCAMENTOA
                INTO VCTADEP, VDESPDEP, VCCUSTO, VGRPATRIM, VGRCONT, VULTDATA1, VTOTDEP, VTOTDEP1, VCDPROJETO;
               VACHOU := LANCAMENTOA%FOUND;
            END IF;
         END IF;
         CLOSE PERIODOLIBSCB;
      END LOOP;
      IF TODOS = 'N'
      THEN
         CLOSE LANCAMENTO;
      ELSE
         CLOSE LANCAMENTOA;
      END IF;
   END IF;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 288186
PROMPT ======================================================================