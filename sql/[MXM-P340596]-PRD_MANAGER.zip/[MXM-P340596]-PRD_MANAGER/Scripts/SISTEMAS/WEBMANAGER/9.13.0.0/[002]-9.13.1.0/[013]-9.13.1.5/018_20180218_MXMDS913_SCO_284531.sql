PROMPT ======================================================================
PROMPT == DEMANDA......: 284531
PROMPT == SISTEMA......: Compras
PROMPT == RESPONSAVEL..: ANDERSON LOPES GIOVANETTI
PROMPT == DATA.........: 18/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE TRIGGER LANCCTB_LCT_TRX
BEFORE INSERT OR UPDATE OR DELETE ON LANCCTB_LCT FOR EACH ROW
DECLARE
  PLCONTAB        VARCHAR(4);
  PLCCUSTO        VARCHAR(4);
  NOCONTAB        VARCHAR(15);
  ATIVA           VARCHAR(1);
  CCATIVO         VARCHAR(1);
  NOTITCP         VARCHAR(20);
  NOTITCR         VARCHAR(20);
  SQPROCESSO      NUMBER;
  NO_CONCILI      VARCHAR(8);
  DTINATIVACAO    DATE;
  SEGMOEDAEMPRESA EMPGERAL_EMP.EMP_SEGMOEDAEMP%TYPE;
  EXISTERELEMPPRJCC       CHAR(1);
  EXISTERELEMPPRJCCEMPCC CHAR(1);
  CURSOR CONTASUPERIOR IS
    SELECT PLC_NOCONTAB
      FROM PLANOCTA_PLC
     WHERE PLC_CODPLANO = PLCONTAB
       AND NOCONTAB LIKE PLC_NOCONTAB || '%';
  CURSOR CONTA_ATIVA IS
    SELECT PLC_ATIVO, PLC_DTINATIVACAO
      FROM PLANOCTA_PLC
     WHERE PLC_CODPLANO = :NEW.LCT_PLCONTAB
       AND PLC_NOCONTAB = :NEW.LCT_NOCONTAB;
  CURSOR CC_ATIVO IS
    SELECT CC_ATIVO
      FROM CCUSTO_CC
     WHERE CC_CODCENT = :NEW.LCT_PLCCUSTO
       AND CC_CODIGO = :NEW.LCT_NOCCUSTO;
  CURSOR CONCILIACAO_AUTOMATICA IS
    SELECT ICPCT_NOTITCP, ICPCT_NOTITCR, ICPCT_SQPROCESSO
      FROM ITCONPROCCTBTIT_ICPCT
     WHERE ICPCT_CDEMPRESA = :OLD.LCT_CDEMPRESA
       AND ICPCT_LOTE = :OLD.LCT_LOTE
       AND ICPCT_DATA = :OLD.LCT_DATA
       AND ICPCT_LANCCTB = :OLD.LCT_LANCCTB
       AND ICPCT_SEQ = :OLD.LCT_SEQ;
  CURSOR CHAVE_CONCILIACAO_AUTO IS
    SELECT PCCT_NOCONSIL
      FROM PROCCONCCTBTIT_PCCT
     WHERE PCCT_SQPROCESSO = SQPROCESSO;
  CURSOR SEGUNDAMOEDAEMPRESA IS
    SELECT EMP_SEGMOEDAEMP
      FROM EMPGERAL_EMP
     WHERE EMP_CODIGO = :NEW.LCT_CDEMPRESA;
  CURSOR REL_EMP_PRJ_CC IS
    SELECT 1
      FROM SCBRELEMPPRJ_RP1
          ,SCBREMPPRJCC_RP2
     WHERE RP2_CDRP1 = RP1_IDRP1
       AND RP1_CDEMPRESA = :NEW.LCT_CDEMPRESA
       AND RP2_CDCC = :NEW.LCT_NOCCUSTO
       AND RP1_CDPRJ = :NEW.LCT_CDPROJETO;
  CURSOR REL_EMP_CC IS
    SELECT 1
      FROM SCBRELEMPPRJ_RP1
          ,SCBREMPPRJCC_RP2
     WHERE RP2_CDRP1 = RP1_IDRP1
       AND RP1_CDEMPRESA = :NEW.LCT_CDEMPRESA
       AND RP1_CDPRJ = :NEW.LCT_CDPROJETO;
BEGIN
  /*N�o executar a trigger quando est� alterando a chave de concilia��o, neste caso n�o
  precisa recalcular o saldo, o custo desta atualiza��o em clientes com muitos registros
  na LANCCTB_LCT � muito custoso gerando lentid�o no processo*/
  IF ((NVL(:OLD.LCT_NOCONSIL, '**') = NVL(:NEW.LCT_NOCONSIL, '**')) OR INSERTING OR DELETING) THEN
    IF INSERTING OR UPDATING THEN
      OPEN REL_EMP_CC;
        FETCH REL_EMP_CC INTO EXISTERELEMPPRJCCEMPCC;
      CLOSE REL_EMP_CC;
      IF :NEW.LCT_CDPROJETO IS NOT NULL AND (TRIM(:NEW.LCT_NOCCUSTO) IS NOT NULL) AND EXISTERELEMPPRJCCEMPCC IS NOT NULL
        THEN BEGIN
          OPEN REL_EMP_PRJ_CC;
            FETCH REL_EMP_PRJ_CC INTO EXISTERELEMPPRJCC;
          CLOSE REL_EMP_PRJ_CC;
          IF EXISTERELEMPPRJCC IS NULL THEN
            RAISE_APPLICATION_ERROR(-20000,
                                    'Projeto n�o relacionado ao Centro de Custo Informado. ' ||
                                    ' Projeto: ' || :NEW.LCT_CDPROJETO ||
                                    ' Centro de Custo: ' || :NEW.LCT_NOCCUSTO ||'.');
          END IF;
        END;
      END IF;
    END IF;
    IF DELETING OR UPDATING THEN
    --
    OPEN CONTA_ATIVA;
    FETCH CONTA_ATIVA
      INTO ATIVA, DTINATIVACAO;
    IF DELETING AND ATIVA = 'N' AND :OLD.LCT_FLGCCINAT IS NULL AND
       DTINATIVACAO <= :NEW.LCT_DATA THEN
      RAISE_APPLICATION_ERROR(-20000,
                              '> Conta Contabil ' || :NEW.LCT_NOCONTAB ||
                              ' esta inativa');
    END IF;
    IF UPDATING AND ATIVA = 'N' AND :NEW.LCT_FLGCCINAT IS NULL THEN
      RAISE_APPLICATION_ERROR(-20000,
                              '> Conta Contabil ' || :NEW.LCT_NOCONTAB ||
                              ' esta inativa');
    END IF;
    CLOSE CONTA_ATIVA;
    OPEN CC_ATIVO;
    FETCH CC_ATIVO
      INTO CCATIVO;
    IF CCATIVO = 'N' AND :OLD.LCT_FLGCCINAT IS NULL THEN
      RAISE_APPLICATION_ERROR(-20000,
                              'Centro de Custo ' || :NEW.LCT_NOCCUSTO ||
                              ' esta inativo');
    END IF;
    CLOSE CC_ATIVO;
    --Teste de altera��o de lan�amento cont�bil consiliado que estava faltando.
    IF DELETING AND :OLD.LCT_NOCONSIL IS NOT NULL THEN
      RAISE_APPLICATION_ERROR(-20000,
                              'Lancamento conciliado nao pode ser modificado. Empresa ' ||
                              :OLD.LCT_CDEMPRESA || ', conta contabil ' ||
                              :OLD.LCT_NOCONTAB ||
                              ' e chave de conciliacao ' ||
                              :OLD.LCT_NOCONSIL || '.');
    END IF;
    --{Novos testes da consilia��o autom�tica.}
    IF DELETING THEN
      --Verifica se o lan�amento possui consilia��o.
      IF :OLD.LCT_NOCONSIL IS NOT NULL THEN
        RAISE_APPLICATION_ERROR(-20000,
                                'Lancamento conciliado nao pode ser modificado. Empresa ' ||
                                :OLD.LCT_CDEMPRESA || ', conta contabil ' ||
                                :OLD.LCT_NOCONTAB ||
                                ' e chave de conciliacao ' ||
                                :OLD.LCT_NOCONSIL || '.');
      ELSE
        OPEN CONCILIACAO_AUTOMATICA;
        FETCH CONCILIACAO_AUTOMATICA
          INTO NOTITCP, NOTITCR, SQPROCESSO;
        CLOSE CONCILIACAO_AUTOMATICA;
        --Verifica se o lan�amento possui consilia��o autom�tica.
        IF NOTITCP IS NOT NULL OR NOTITCR IS NOT NULL THEN
          OPEN CHAVE_CONCILIACAO_AUTO;
          FETCH CHAVE_CONCILIACAO_AUTO
            INTO NO_CONCILI;
          CLOSE CHAVE_CONCILIACAO_AUTO;
          RAISE_APPLICATION_ERROR(-20000,
                                  'T�tulo conciliado auto. nao pode ser modificado. Chave Conc.: ' ||
                                  NO_CONCILI || ', Empresa ' ||
                                  :OLD.LCT_CDEMPRESA || ',  e Lancamento ' ||
                                  :OLD.LCT_LANCCTB || '.');
        END IF;
      END IF;
    END IF;
  END IF;
  IF INSERTING THEN
    SELECT EMP_CODPLCONTA, EMP_CODCENTCUS
      INTO PLCONTAB, PLCCUSTO
      FROM EMPGERAL_EMP
     WHERE EMP_CODIGO = :NEW.LCT_CDEMPRESA;
    NOCONTAB := :NEW.LCT_NOCONTAB;
  ELSE
    SELECT EMP_CODPLCONTA, EMP_CODCENTCUS
      INTO PLCONTAB, PLCCUSTO
      FROM EMPGERAL_EMP
     WHERE EMP_CODIGO = :OLD.LCT_CDEMPRESA;
    NOCONTAB := :OLD.LCT_NOCONTAB;
  END IF;
  OPEN CONTASUPERIOR;
  FETCH CONTASUPERIOR
    INTO NOCONTAB;
  WHILE CONTASUPERIOR%FOUND LOOP
    --Realiza o Lan�amento Negativo se for exclus�o ou atualiza��o. No segundo caso o sistema ir� lan�ar o valor novo positivo
    IF UPDATING OR DELETING THEN
      INSERT INTO CUSTOMES_MEN
        (CMES_CDEMPRESA,
         CMES_PLCONTAB,
         CMES_NOCONTAB,
         CMES_PLCCUSTO,
         CMES_NOCCUSTO,
         ANOMES,
         CREDITO,
         DEBITO,
         CREDITOM,
         DEBITOM,
         CR_ENCERR,
         DB_ENCERR,
         CR_ENCERRM,
         DB_ENCERRM,
         CMES_QTDLANC,
         CMES_TIPO)
      VALUES
        (:OLD.LCT_CDEMPRESA,
         PLCONTAB,
         NOCONTAB,
         PLCCUSTO,
         :OLD.LCT_NOCCUSTO,
         TO_CHAR(:OLD.LCT_DATA, 'YYYYMM'),
         DECODE(:OLD.LCT_DC, 'C', - :OLD.LCT_VALOR, 0),
         DECODE(:OLD.LCT_DC, 'D', - :OLD.LCT_VALOR, 0),
         DECODE(:OLD.LCT_DC, 'C', - :OLD.LCT_VALORM, 0),
         DECODE(:OLD.LCT_DC, 'D', - :OLD.LCT_VALORM, 0),
         DECODE(:OLD.LCT_LOTE,
                'ENCERR',
                DECODE(:OLD.LCT_DC, 'C', - :OLD.LCT_VALOR, 0),
                0),
         DECODE(:OLD.LCT_LOTE,
                'ENCERR',
                DECODE(:OLD.LCT_DC, 'D', - :OLD.LCT_VALOR, 0),
                0),
         DECODE(:OLD.LCT_LOTE,
                'ENCERR',
                DECODE(:OLD.LCT_DC, 'C', - :OLD.LCT_VALORM, 0),
                0),
         DECODE(:OLD.LCT_LOTE,
                'ENCERR',
                DECODE(:OLD.LCT_DC, 'D', - :OLD.LCT_VALORM, 0),
                0),
         -1,
         2);
    END IF;
    --Se for inserir ou atualizar ir� incluir o valor positivo.
    IF INSERTING OR UPDATING THEN
      INSERT INTO CUSTOMES_MEN
        (CMES_CDEMPRESA,
         CMES_PLCONTAB,
         CMES_NOCONTAB,
         CMES_PLCCUSTO,
         CMES_NOCCUSTO,
         ANOMES,
         CREDITO,
         DEBITO,
         CREDITOM,
         DEBITOM,
         CR_ENCERR,
         DB_ENCERR,
         CR_ENCERRM,
         DB_ENCERRM,
         CMES_QTDLANC,
         CMES_TIPO)
      VALUES
        (:NEW.LCT_CDEMPRESA,
         PLCONTAB,
         NOCONTAB,
         PLCCUSTO,
         :NEW.LCT_NOCCUSTO,
         TO_CHAR(:NEW.LCT_DATA, 'YYYYMM'),
         DECODE(:NEW.LCT_DC, 'C', :NEW.LCT_VALOR, 0),
         DECODE(:NEW.LCT_DC, 'D', :NEW.LCT_VALOR, 0),
         DECODE(:NEW.LCT_DC, 'C', :NEW.LCT_VALORM, 0),
         DECODE(:NEW.LCT_DC, 'D', :NEW.LCT_VALORM, 0),
         DECODE(:NEW.LCT_LOTE,
                'ENCERR',
                DECODE(:NEW.LCT_DC, 'C', :NEW.LCT_VALOR, 0),
                0),
         DECODE(:NEW.LCT_LOTE,
                'ENCERR',
                DECODE(:NEW.LCT_DC, 'D', :NEW.LCT_VALOR, 0),
                0),
         DECODE(:NEW.LCT_LOTE,
                'ENCERR',
                DECODE(:NEW.LCT_DC, 'C', :NEW.LCT_VALORM, 0),
                0),
         DECODE(:NEW.LCT_LOTE,
                'ENCERR',
                DECODE(:NEW.LCT_DC, 'D', :NEW.LCT_VALORM, 0),
                0),
         1,
         1);
    END IF;
    FETCH CONTASUPERIOR
      INTO NOCONTAB;
  END LOOP;
  CLOSE CONTASUPERIOR;
  --
  --Valida��es Adicionais
  IF INSERTING OR UPDATING THEN
    --
    OPEN CONTA_ATIVA;
    FETCH CONTA_ATIVA
      INTO ATIVA, DTINATIVACAO;
    IF ATIVA = 'N' AND :NEW.LCT_FLGCCINAT IS NULL AND
       DTINATIVACAO <= :NEW.LCT_DATA THEN
      RAISE_APPLICATION_ERROR(-20000,
                              '>>Conta Contabil ' || :NEW.LCT_NOCONTAB ||
                              ' esta inativa');
    END IF;
    CLOSE CONTA_ATIVA;
    OPEN CC_ATIVO;
    FETCH CC_ATIVO
      INTO CCATIVO;
    IF CCATIVO = 'N' AND :NEW.LCT_FLGCCINAT IS NULL THEN
      RAISE_APPLICATION_ERROR(-20000,
                              'Centro de Custo ' || :NEW.LCT_NOCCUSTO ||
                              'esta inativo');
    END IF;
    CLOSE CC_ATIVO;
    IF :NEW.LCT_VALORM > 0 AND :NEW.LCT_TPLANC IS NULL THEN
      OPEN SEGUNDAMOEDAEMPRESA;
      FETCH SEGUNDAMOEDAEMPRESA
        INTO SEGMOEDAEMPRESA;
      :NEW.LCT_TPLANC := SEGMOEDAEMPRESA;
      CLOSE SEGUNDAMOEDAEMPRESA;
    END IF;
    IF (:NEW.LCT_VALORM = 0 OR :NEW.LCT_VALORM IS NULL) AND
       (:NEW.LCT_TPLANC IS NOT NULL) AND
       (:NEW.LCT_LOTE <> 'LVCAMB') AND
       (:NEW.LCT_LOTE <> 'SCP_BX') AND
       (:NEW.LCT_LOTE <> 'SCR_BX') THEN
      :NEW.LCT_TPLANC := '';
    END IF;
  END IF;
  IF INSERTING THEN
   :NEW.LCT_USINCLUSAO := GET_USER_MXM;
  END IF;
END IF;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 284531
PROMPT ======================================================================