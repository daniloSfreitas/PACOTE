PROMPT ======================================================================
PROMPT == DEMANDA......: 282831
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: LUIZ GUSTAVO FERREIRA SODRE
PROMPT == DATA.........: 11/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE SPEDTABUF_TUF
   SET TUF_DESCRICAO = 'Distrito Federal'
WHERE TUF_CODIGO = '53'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282831
PROMPT ======================================================================