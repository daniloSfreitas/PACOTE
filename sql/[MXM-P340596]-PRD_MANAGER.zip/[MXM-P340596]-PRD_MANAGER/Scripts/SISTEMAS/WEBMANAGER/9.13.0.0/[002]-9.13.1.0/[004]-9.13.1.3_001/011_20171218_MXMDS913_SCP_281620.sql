PROMPT ======================================================================
PROMPT == DEMANDA......: 281620
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: MARCOS FELIPE DE CARVALHO FIGUEIRED
PROMPT == DATA.........: 14/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GREFILTROCAMPOTAB_FCT F SET
         F.FCT_NMCONDCAMPOCHB = 'CASE WHEN 
((SELECT ANTECCPPRESTCONTA_APC.APC_DOCANTEC FROM ANTECCPPRESTCONTA_APC
 WHERE ANTECCPPRESTCONTA_APC.APC_CDFOR = ANTECCP_ACP.ACP_CDFOR
 AND ANTECCPPRESTCONTA_APC.APC_DOCANTEC = ANTECCP_ACP.ACP_DOCANTEC 
 GROUP BY ANTECCPPRESTCONTA_APC.APC_DOCANTEC HAVING COUNT(*) = 1) IS NULL
 AND ANTECCP_ACP.ACP_TPCAD = ''A'') THEN ''S''  ELSE ''N'' END'
         WHERE FCT_NRVISAO =
               (SELECT VDR_IDVISAO
                  FROM GREVISAOTAB_VDR
                 WHERE VDR_NRTABELA =
                       (SELECT TDR_IDTABELA
                          FROM GRETABDICDADOS_TDR
                         WHERE TDR_NMTABELA = 'ANTECCP_ACP'))
           AND FCT_NMCAMPO = 'ANTECCPPRESTCONTA_APC.APC_DOCANTEC'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 281620
PROMPT ======================================================================