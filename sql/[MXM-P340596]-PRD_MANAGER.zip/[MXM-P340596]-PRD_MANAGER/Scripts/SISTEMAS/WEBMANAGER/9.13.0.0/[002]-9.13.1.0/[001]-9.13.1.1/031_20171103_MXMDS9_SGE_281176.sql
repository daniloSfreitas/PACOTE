PROMPT ======================================================================
PROMPT == DEMANDA......: 281176
PROMPT == SISTEMA......: Estoque
PROMPT == RESPONSAVEL..: RODRIGO DA PAZ DO NASCIMENTO
PROMPT == DATA.........: 01/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

  alter table PARCONSMEDIO_PCM add PCM_CDTPPRODUTO VARCHAR2(2)
/

alter table PARCONSMEDIO_PCM add PCM_IDPARCONSMEDIO number(12)
/

update PARCONSMEDIO_PCM
   set PCM_IDPARCONSMEDIO = rownum
 where PCM_IDPARCONSMEDIO is null
/

alter table PARCONSMEDIO_PCM modify PCM_IDPARCONSMEDIO not null
/

DECLARE
CONTADOR NUMBER;
BEGIN
SELECT NVL(MAX(PCM_IDPARCONSMEDIO), 0) INTO CONTADOR FROM PARCONSMEDIO_PCM;
EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQ1_PARCONSMEDIO_PCM START WITH ' || TO_CHAR(CONTADOR + 1) || ' INCREMENT BY 1 MAXVALUE 999999999999 NOCYCLE NOCACHE NOORDER';
END;
/

alter table PARCONSMEDIO_PCM
  add constraint PK_PARCONSMEDIO_PCM primary key (PCM_IDPARCONSMEDIO)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 281176
PROMPT ======================================================================