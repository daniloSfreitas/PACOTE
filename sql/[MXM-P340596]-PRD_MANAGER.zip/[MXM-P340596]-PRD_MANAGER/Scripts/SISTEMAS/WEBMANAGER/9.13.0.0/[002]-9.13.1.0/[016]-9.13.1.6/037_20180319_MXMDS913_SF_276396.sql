PROMPT ======================================================================
PROMPT == DEMANDA......: 276396
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: Eduardo Lopes de Oliveira
PROMPT == DATA.........: 19/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE FATPRORROGACAOICMS_FPI ADD FPI_TPPRAZO NUMBER(1) NULL
/

COMMENT ON COLUMN FATPRORROGACAOICMS_FPI.FPI_TPPRAZO IS 'Representa se a prorroga��o ser� em 1� Prazo(1) ou 2�(2) Prazo'
/

CREATE OR REPLACE PROCEDURE PRC_INSFATPRORROGACAOICMS_FPI(PFPI_IDFATPRORROGACAOICMS IN OUT NUMBER,
                                                          PFPI_CDEMPRESA            IN CHAR,
                                                          PFPI_CDFILIAL             IN CHAR,
                                                          PFPI_CDFATURA             IN NUMBER,
                                                          PFPI_CDITEM               IN CHAR,
                                                          PFPI_NRSEQUENCIA          IN NUMBER,
                                                          PFPI_CDREGISTROEVENTO     IN NUMBER DEFAULT NULL,
                                                          PFPI_QTPEDIDO             IN NUMBER,
                                                          PFPI_TPPRAZO              IN NUMBER) AS
BEGIN
  IF PFPI_IDFATPRORROGACAOICMS IS NULL THEN
    SELECT SEQ1_FATPRORROGACAOICMS_FPI.NEXTVAL
      INTO PFPI_IDFATPRORROGACAOICMS
      FROM DUAL;
  END IF;
  INSERT INTO FATPRORROGACAOICMS_FPI
    (FPI_IDFATPRORROGACAOICMS,
     FPI_CDEMPRESA,
     FPI_CDFILIAL,
     FPI_CDFATURA,
     FPI_CDITEM,
     FPI_NRSEQUENCIA,
     FPI_CDREGISTROEVENTO,
     FPI_QTPEDIDO,
     FPI_TPPRAZO,
     FPI_DTINCLUSAO,
     FPI_USINCLUSAO)
  VALUES
    (PFPI_IDFATPRORROGACAOICMS,
     PFPI_CDEMPRESA,
     PFPI_CDFILIAL,
     PFPI_CDFATURA,
     PFPI_CDITEM,
     PFPI_NRSEQUENCIA,
     PFPI_CDREGISTROEVENTO,
     PFPI_QTPEDIDO,
     PFPI_TPPRAZO,
     SYSDATE,
     GET_USER_MXM);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATPRORROGACAOICMS_FPI(PFPI_IDFATPRORROGACAOICMS IN NUMBER,
                                                          PFPI_CDEMPRESA            IN CHAR,
                                                          PFPI_CDFILIAL             IN CHAR,
                                                          PFPI_CDFATURA             IN NUMBER,
                                                          PFPI_CDITEM               IN CHAR,
                                                          PFPI_NRSEQUENCIA          IN NUMBER,
                                                          PFPI_CDREGISTROEVENTO     IN NUMBER DEFAULT NULL,
                                                          PFPI_QTPEDIDO             IN NUMBER,
                                                          PFPI_TPPRAZO              IN NUMBER) AS
BEGIN
  UPDATE FATPRORROGACAOICMS_FPI
     SET FPI_IDFATPRORROGACAOICMS = PFPI_IDFATPRORROGACAOICMS,
         FPI_CDEMPRESA            = PFPI_CDEMPRESA,
         FPI_CDFILIAL             = PFPI_CDFILIAL,
         FPI_CDFATURA             = PFPI_CDFATURA,
         FPI_CDITEM               = PFPI_CDITEM,
         FPI_NRSEQUENCIA          = PFPI_NRSEQUENCIA,
         FPI_CDREGISTROEVENTO     = PFPI_CDREGISTROEVENTO,
         FPI_QTPEDIDO             = PFPI_QTPEDIDO,
         FPI_TPPRAZO              = PFPI_TPPRAZO,
         FPI_DTALTERACAO          = SYSDATE,
         FPI_USALTERACAO          = GET_USER_MXM
   WHERE FPI_IDFATPRORROGACAOICMS = PFPI_IDFATPRORROGACAOICMS;
END;
/

ALTER TABLE FATCANCPRORROGICMS_FCP  ADD FCP_CDREGISTROEVENTOENVIO NUMBER(10)
/

COMMENT ON COLUMN FATCANCPRORROGICMS_FCP.FCP_CDREGISTROEVENTOENVIO IS 'Identificador de registro do envio de prorroga��o.'
/

CREATE INDEX IN1_FATCANCPRORROGICMS_FCP ON FATCANCPRORROGICMS_FCP (FCP_CDREGISTROEVENTOENVIO)
/

ALTER TABLE FATCANCPRORROGICMS_FCP
ADD CONSTRAINT FK3_FATCANCPRORROGICMS_FCP FOREIGN KEY (FCP_CDREGISTROEVENTOENVIO)
REFERENCES NFEREGISTROEVENTO_RGE (RGE_IDREGISTROEVENTO)
/

CREATE OR REPLACE PROCEDURE PRC_INSFATCANCPRORROGICMS_FCP(PFCP_IDFATCANCPRORROGICMS  IN OUT NUMBER,
                                                          PFCP_CDFATPRORROGACAOICMS  IN NUMBER,
                                                          PFCP_CDREGISTROEVENTO      IN NUMBER DEFAULT NULL,
                                                          PFCP_CDREGISTROEVENTOENVIO IN NUMBER DEFAULT NULL) AS
BEGIN
  IF PFCP_IDFATCANCPRORROGICMS IS NULL THEN
    SELECT SEQ1_FATCANCPRORROGICMS_FCP.NEXTVAL
      INTO PFCP_IDFATCANCPRORROGICMS
      FROM DUAL;
  END IF;
  INSERT INTO FATCANCPRORROGICMS_FCP
    (FCP_IDFATCANCPRORROGICMS,
     FCP_CDFATPRORROGACAOICMS,
     FCP_CDREGISTROEVENTO,
     FCP_CDREGISTROEVENTOENVIO,
     FCP_DTINCLUSAO,
     FCP_USINCLUSAO)
  VALUES
    (PFCP_IDFATCANCPRORROGICMS,
     PFCP_CDFATPRORROGACAOICMS,
     PFCP_CDREGISTROEVENTO,
     PFCP_CDREGISTROEVENTOENVIO,
     SYSDATE,
     GET_USER_MXM);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATCANCPRORROGICMS_FCP(PFCP_IDFATCANCPRORROGICMS  IN NUMBER,
                                                          PFCP_CDFATPRORROGACAOICMS  IN NUMBER,
                                                          PFCP_CDREGISTROEVENTO      IN NUMBER DEFAULT NULL,
                                                          PFCP_CDREGISTROEVENTOENVIO IN NUMBER DEFAULT NULL) AS
BEGIN
  UPDATE FATCANCPRORROGICMS_FCP
     SET FCP_IDFATCANCPRORROGICMS  = PFCP_IDFATCANCPRORROGICMS,
         FCP_CDFATPRORROGACAOICMS  = PFCP_CDFATPRORROGACAOICMS,
         FCP_CDREGISTROEVENTO      = PFCP_CDREGISTROEVENTO,
         FCP_CDREGISTROEVENTOENVIO = PFCP_CDREGISTROEVENTOENVIO,
         FCP_DTALTERACAO           = SYSDATE,
         FCP_USALTERACAO           = GET_USER_MXM
   WHERE FCP_IDFATCANCPRORROGICMS = PFCP_IDFATCANCPRORROGICMS;
END;
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('PPI0010', 'Prazo m�ximo para a primeira prorroga��o expirou.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('PPI0011', 'Prazo m�ximo para a segunda prorroga��o expirou.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('PPI0012', 'Prazo m�ximo para a segunda prorroga��o a partir da emiss�o do primeiro prazo expirou.')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276396
PROMPT ======================================================================