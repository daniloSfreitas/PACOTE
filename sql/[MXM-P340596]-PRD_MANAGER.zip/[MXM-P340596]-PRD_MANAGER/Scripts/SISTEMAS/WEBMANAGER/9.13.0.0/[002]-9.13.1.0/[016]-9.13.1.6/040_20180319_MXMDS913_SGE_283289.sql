PROMPT ======================================================================
PROMPT == DEMANDA......: 283289
PROMPT == SISTEMA......: Estoque
PROMPT == RESPONSAVEL..: MANOEL ALVES FERREIRA NETO
PROMPT == DATA.........: 19/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (35325, 'Relatorio de Requisi��es Atendidas', 'Relatorio de Requisi��es Atendidas')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGE', 35325, 53, 3000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35325, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35325, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35325, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283289
PROMPT ======================================================================