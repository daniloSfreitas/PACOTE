PROMPT ======================================================================
PROMPT == DEMANDA......: 280167
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: JULIANO MENEZES
PROMPT == DATA.........: 17/11/2017
PROMPT == BASE.........: MXMDS912
PROMPT == OWNER DESTINO: MXMDS912
PROMPT ======================================================================

SET DEFINE OFF;

drop index SPEDVALDECLA_SVD_UK
/

ALTER TABLE SPEDVALDECLA_SVD ADD (CONSTRAINT UK1_SPEDVALDECLA_SVD 
UNIQUE (SVD_SQAPUICMS, SVD_UF,SVD_CDINFADIC, SVD_DESCCOMP)) 
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280167
PROMPT ======================================================================