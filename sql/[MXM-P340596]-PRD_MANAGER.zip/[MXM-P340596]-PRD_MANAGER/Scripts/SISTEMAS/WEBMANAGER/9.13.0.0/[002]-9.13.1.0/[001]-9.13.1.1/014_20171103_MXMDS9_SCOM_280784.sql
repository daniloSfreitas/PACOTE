PROMPT ======================================================================
PROMPT == DEMANDA......: 280784
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: Julian Alves
PROMPT == DATA.........: 01/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DROP INDEX UK_PARAMCUSREC_PCR
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280784
PROMPT ======================================================================