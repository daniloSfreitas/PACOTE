PROMPT ======================================================================
PROMPT == DEMANDA......: 287021
PROMPT == SISTEMA......: Frete
PROMPT == RESPONSAVEL..: LEONARDO OLIVEIRA GOMES
PROMPT == DATA.........: 02/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE PARAMS_PAR
   SET PAR_VLPARAM = '02/07/2018'
 WHERE PAR_CDPARAM = 'PARDATALIMITENFE3.10'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287021
PROMPT ======================================================================

/*
===============================================================================================
     Data: 29/06/2018  11:40
	 Solicitante:  Filipe
	 Motivo: Conforme informado pelo Igor e Alan o script ser� disponibilizado pelo SAU, script inclu�do por precau��o
===============================================================================================     
*/

PROMPT ======================================================================
PROMPT == DEMANDA......: 294919
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: JOSE BARBOSA DA SILVA JUNIOR
PROMPT == DATA.........: 21/06/2018
PROMPT == BASE.........: MXMDS9132
PROMPT == OWNER DESTINO: MXMDS9132
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE PARAMS_PAR
   SET PAR_VLPARAM = '02/08/2018'
 WHERE PAR_CDPARAM = 'PARDATALIMITENFE3.10'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 294919
PROMPT ======================================================================