PROMPT ======================================================================
PROMPT == DEMANDA......: 284490
PROMPT == SISTEMA......: Contratos de Compras
PROMPT == RESPONSAVEL..: JONATHAS DUARTE PEREIRA
PROMPT == DATA.........: 11/01/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (35331, 'Posi��o financeira do contrato', 'Posi��o financeira do contrato')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGCC', 35331, 6, 3000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35331, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35331, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35331, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 284490
PROMPT ======================================================================