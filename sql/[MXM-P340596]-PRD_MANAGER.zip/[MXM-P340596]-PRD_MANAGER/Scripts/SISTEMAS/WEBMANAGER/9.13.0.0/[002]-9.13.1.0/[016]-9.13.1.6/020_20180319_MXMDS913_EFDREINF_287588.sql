PROMPT ======================================================================
PROMPT == DEMANDA......: 287588
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: MAXUEL RIBEIRO SANTANA
PROMPT == DATA.........: 09/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

DROP TABLE mxm_scp_fgi
/

DROP TABLE mxm_scr_cgi
/

drop trigger trg1_fgpagir_fgi
/

drop trigger trg2_fgpagir_fgi
/

drop trigger trg1_cgrecir_cgi
/

drop trigger trg2_cgrecir_cgi
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287588
PROMPT ======================================================================