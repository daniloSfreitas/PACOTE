PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o [013]-9.13.1.4_003 gerados em 02/02/2018 
PROMPT ============================================================= 

@@001_20180202_MXMDS913_MXMRECRUIT_285721.sql
@@002_20180202_MXMDS913_MXMRECRUIT_285648.sql
@@003_20180202_MXMDS913_MANAGER_285386.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.4_003');

COMMIT;
