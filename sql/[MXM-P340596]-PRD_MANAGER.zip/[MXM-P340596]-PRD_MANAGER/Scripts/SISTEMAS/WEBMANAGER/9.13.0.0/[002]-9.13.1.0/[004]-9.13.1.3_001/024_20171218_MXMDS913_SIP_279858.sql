PROMPT ======================================================================
PROMPT == DEMANDA......: 279858
PROMPT == SISTEMA......: Vendas
PROMPT == RESPONSAVEL..: JULIO FRANCIS P DOS SANTOS MENDONCA
PROMPT == DATA.........: 18/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE COMPRADORES_CPR MODIFY CRP_DESCRICAO VARCHAR2(40)
/

CREATE OR REPLACE PROCEDURE INSPARAMSGE_PSGE(PSGG_CDEMPRESA                 IN CHAR,
                                             PSGG_ALIQPIS                   IN NUMBER,
                                             PSGG_ALIQCOFINS                IN NUMBER,
                                             PSGG_CODOBS                    IN CHAR,
                                             PSGG_CTBICMSIPI                IN CHAR,
                                             PSGG_CTBISS                    IN CHAR,
                                             PSGG_CTBIIMPORT                IN CHAR,
                                             PSGG_CTBFTI                    IN CHAR,
                                             PSGG_CTBPISCOFINS              IN CHAR,
                                             PSGG_CTBACRDEC                 IN CHAR,
                                             PSGG_ALIQFTI                   IN NUMBER,
                                             PSGG_DIFCODFAB                 IN CHAR,
                                             PSGG_CODOBSSUF                 IN CHAR,
                                             PSGG_EMITAUTOMOVI              IN CHAR,
                                             PSGG_MODTERMORESP              IN CHAR,
                                             PSGG_LOGOSGE                   IN CHAR,
                                             PSGG_DTMOVINT                  IN CHAR,
                                             PSGG_VALIDARELESTPROD          IN CHAR,
                                             PSGG_RELMOEDA                  IN CHAR DEFAULT NULL,
                                             PSGG_ORDLTSRVALIDDOC           IN CHAR DEFAULT NULL,
                                             PSGG_VALIDAPERTINENCIAPRODEMP  IN CHAR DEFAULT NULL,
                                             PSGG_SERVIPIICMSTRIB           IN CHAR DEFAULT NULL,
                                             PSGG_SERVIPIICMSOUTRAS         IN CHAR DEFAULT NULL,
                                             PSGG_SERVIPITRIBICMSOUTRAS     IN CHAR DEFAULT NULL,
                                             PSGG_SERVIPIOUTRASICMSTRIB     IN CHAR DEFAULT NULL,
                                             PSGG_DEVCUSMEDIO               IN CHAR DEFAULT NULL,
                                             PSGG_LOTESERIE                 IN CHAR DEFAULT NULL,
                                             PSGG_REGINTERNO                IN CHAR DEFAULT NULL,
                                             PSGG_CUSTOESPECIF              IN CHAR DEFAULT NULL,
                                             PSGG_MODELOAMEM                IN CHAR DEFAULT NULL,
                                             PSGG_CCUSTORELCONTAB           IN CHAR DEFAULT NULL,
                                             PSGG_UTILCUSTOUNIT             IN CHAR DEFAULT NULL,
                                             PSGG_VALIDACCUSTODESTINACAO    IN CHAR DEFAULT NULL,
                                             PSGG_INFORMACCUSTODESTINACAO   IN CHAR DEFAULT NULL,
                                             PSGG_VALORIZATRANSFALMOX       IN CHAR DEFAULT NULL,
                                             PSGG_EXIBESQNOTAHISTORICO      IN CHAR DEFAULT NULL,
                                             PSGG_ACRESCOBSMOV              IN CHAR DEFAULT NULL,
                                             PSGG_PREFIXOLOTESERIE          IN CHAR DEFAULT 'N',
                                             PSGG_SQLOTESERIEINICIAL        IN CHAR DEFAULT NULL,
                                             PSGG_SQLOTESERIEFINAL          IN CHAR DEFAULT NULL,
                                             PSGG_SQLOTESERIEALERTA         IN CHAR DEFAULT NULL,
                                             PSGG_SQLOTESERIEULTIMO         IN CHAR DEFAULT NULL,
                                             PSGG_SERIESQLOTESERIE          IN CHAR DEFAULT NULL,
                                             PSGG_LOTESERIEAUTOMATICO       IN CHAR DEFAULT 'N',
                                             PSGG_MESMOLSAUTOCDPRODIGUAIS   IN CHAR DEFAULT 'N',
                                             PSGG_VBITEMSUBTRANSFFIL        IN CHAR DEFAULT 'N',
                                             PSGG_EXIBIRCODFABRICANTE       IN CHAR DEFAULT 'N',
                                             PSGG_INFNRREQINTHISTLANCCONT   IN CHAR DEFAULT 'N',
                                             PSGG_ATIVARCOMPORSALDOFINALMOX IN CHAR DEFAULT 'N',
                                             PSGG_PODETROCARLOCALPRDINVENT  IN CHAR DEFAULT 'N') AS
BEGIN
  INSERT INTO PARAMSGE_PSGE
    (PSGE_CDEMPRESA,
     PSGE_ALIQPIS,
     PSGE_ALIQCOFINS,
     PSGE_CTBICMSIPI,
     PSGE_CTBISS,
     PSGE_CTBIIMPORT,
     PSGE_CTBFTI,
     PSGE_CTBPISCOFINS,
     PSGE_CODOBS,
     PSGE_CTBACRDEC,
     PSGE_ALIQFTI,
     PSGE_DIFCODFAB,
     PSGE_CODOBSSUF,
     PSGE_EMITAUTOMOVI,
     PSGE_MODTERMORESP,
     PSGE_LOGOSGE,
     PSGE_DTMOVINT,
     PSGE_VALIDARELESTPROD,
     PSGE_RELMOEDA,
     PSGE_ORDLTSRVALIDDOC,
     PSGE_VALIDAPERTINENCIAPRODEMP,
     PSGE_SERVIPIICMSTRIB,
     PSGE_SERVIPIICMSOUTRAS,
     PSGE_SERVIPITRIBICMSOUTRAS,
     PSGE_SERVIPIOUTRASICMSTRIB,
     PSGE_DEVCUSMEDIO,
     PSGE_LOTESERIE,
     PSGE_REGINTERNO,
     PSGE_CUSTOESPECIF,
     PSGE_MODELOAMEM,
     PSGE_CCUSTORELCONTAB,
     PSGE_UTILCUSTOUNIT,
     PSGE_VALIDACCUSTODESTINACAO,
     PSGE_INFORMACCUSTODESTINACAO,
     PSGE_VALORIZATRANSFALMOX,
     PSGE_EXIBESQNOTAHISTORICO,
     PSGE_ACRESCOBSMOV,
     PSGE_PREFIXOLOTESERIE,
     PSGE_SQLOTESERIEINICIAL,
     PSGE_SQLOTESERIEFINAL,
     PSGE_SQLOTESERIEALERTA,
     PSGE_SQLOTESERIEULTIMO,
     PSGE_SERIESQLOTESERIE,
     PSGE_LOTESERIEAUTOMATICO,
     PSGE_MESMOLSAUTOCDPRODIGUAIS,
     PSGE_VBITEMSUBTRANSFFIL,
     PSGE_EXIBIRCODFABRICANTE,
     PSGE_INFNRREQINTHISTLANCCONT,
     PSGE_ATIVARCOMPORSALDOFINALMOX,
     PSGE_PODETROCARLOCALPRDINVENT,
     PSGE_IDPARAMSGE)
  VALUES
    (PSGG_CDEMPRESA,
     PSGG_ALIQPIS,
     PSGG_ALIQCOFINS,
     PSGG_CTBICMSIPI,
     PSGG_CTBISS,
     PSGG_CTBIIMPORT,
     PSGG_CTBFTI,
     PSGG_CTBPISCOFINS,
     PSGG_CODOBS,
     PSGG_CTBACRDEC,
     PSGG_ALIQFTI,
     PSGG_DIFCODFAB,
     PSGG_CODOBSSUF,
     PSGG_EMITAUTOMOVI,
     PSGG_MODTERMORESP,
     PSGG_LOGOSGE,
     PSGG_DTMOVINT,
     PSGG_VALIDARELESTPROD,
     PSGG_RELMOEDA,
     PSGG_ORDLTSRVALIDDOC,
     PSGG_VALIDAPERTINENCIAPRODEMP,
     PSGG_SERVIPIICMSTRIB,
     PSGG_SERVIPIICMSOUTRAS,
     PSGG_SERVIPITRIBICMSOUTRAS,
     PSGG_SERVIPIOUTRASICMSTRIB,
     PSGG_DEVCUSMEDIO,
     PSGG_LOTESERIE,
     PSGG_REGINTERNO,
     PSGG_CUSTOESPECIF,
     PSGG_MODELOAMEM,
     PSGG_CCUSTORELCONTAB,
     NVL(PSGG_UTILCUSTOUNIT, 'N'),
     NVL(PSGG_VALIDACCUSTODESTINACAO, 'N'),
     PSGG_INFORMACCUSTODESTINACAO,
     PSGG_VALORIZATRANSFALMOX,
     NVL(PSGG_EXIBESQNOTAHISTORICO, 'N'),
     NVL(PSGG_ACRESCOBSMOV, 'N'),
     PSGG_PREFIXOLOTESERIE,
     PSGG_SQLOTESERIEINICIAL,
     PSGG_SQLOTESERIEFINAL,
     PSGG_SQLOTESERIEALERTA,
     PSGG_SQLOTESERIEULTIMO,
     PSGG_SERIESQLOTESERIE,
     PSGG_LOTESERIEAUTOMATICO,
     PSGG_MESMOLSAUTOCDPRODIGUAIS,
     NVL(PSGG_VBITEMSUBTRANSFFIL, 'N'),
     PSGG_EXIBIRCODFABRICANTE,
     PSGG_INFNRREQINTHISTLANCCONT,
     PSGG_ATIVARCOMPORSALDOFINALMOX,
     PSGG_PODETROCARLOCALPRDINVENT,
     SEQ1_PARAMSGE_PSGE.NEXTVAL);
END;
/

CREATE OR REPLACE FUNCTION GET_DESC_SERV_MANAGER(pEMPRESA  IN CHAR,
                                                 pFILIAL   IN CHAR,
                                                 pCDFATURA IN NUMBER)
  RETURN VARCHAR2 IS
  vDESCRICAO_ITEM_NFSE    VARCHAR2(2000);
  vDESCRICAO_PRODUTO_NFSE VARCHAR2(2000);
  vRETORNO_FUNCAO         VARCHAR2(2000);
  vDESCRICAO              VARCHAR2(2000);
  vDESCRICAOAUX           VARCHAR2(2000);
  vDESCRICAOPRODUTO       VARCHAR2(2000);

  vPARAMDETALHAITEM    PARAMS_PAR.PAR_VLPARAM%TYPE;
  vPARAMITEMDESCRALT   PARAMS_PAR.PAR_VLPARAM%TYPE;
  vPARAMIMPSEGDESC     PARAMS_PAR.PAR_VLPARAM%TYPE;
  vPARAMIMPPRIMSEGDESC PARAMS_PAR.PAR_VLPARAM%TYPE;
  vIFAT_QUANTIDADE     ITFATURA_IFAT.IFAT_QUANTIDADE%TYPE;
  vIFAT_PRECOINF       ITFATURA_IFAT.IFAT_PRECOINF%TYPE;
  vIFAT_VLRPROD        ITFATURA_IFAT.IFAT_VLRPROD%TYPE;

  CURSOR CONSULTA IS
    SELECT DISTINCT LTRIM(IFAT_DESCRICAO),
                    IFAT_QUANTIDADE,
                    IFAT_PRECOINF,
                    IFAT_VLRPROD
      FROM ITFATURA_IFAT
     WHERE IFAT_CDEMPRESA = pEMPRESA
       AND IFAT_CDFILIAL = pFILIAL
       AND IFAT_CDFATURA = pCDFATURA
     ORDER BY IFAT_SEQUENCIA;

  CURSOR CONSULTAPRODUTO IS
    SELECT LTRIM(PRD_DESCRICAO),
           IFAT_QUANTIDADE,
           IFAT_PRECOINF,
           IFAT_VLRPROD
      FROM ITFATURA_IFAT, PRODUTO_PRD
     WHERE IFAT_CDEMPRESA = pEMPRESA
       AND IFAT_CDFILIAL = pFILIAL
       AND IFAT_CDFATURA = pCDFATURA
       AND PRD_ITEM = IFAT_ITEM
     ORDER BY PRD_DESCRICAO;

  CURSOR PARAMS(pCDPARAM IN CHAR) IS
    SELECT DECODE(UPPER(TRIM(PAR_VLPARAM)),
                  'FALSE',
                  'N',
                  'TRUE',
                  'S',
                  UPPER(TRIM(PAR_VLPARAM)))
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = pCDPARAM || pEMPRESA || pFILIAL;
BEGIN
  vDESCRICAO_ITEM_NFSE    := NULL;
  vDESCRICAO_PRODUTO_NFSE := NULL;
  vRETORNO_FUNCAO         := NULL;
  vDESCRICAOAUX           := NULL;

  vPARAMDETALHAITEM    := 'N';
  vPARAMITEMDESCRALT   := 'N';
  vPARAMIMPSEGDESC     := 'N';
  vPARAMIMPPRIMSEGDESC := 'N';

  OPEN PARAMS('PARNFEDETALHARITENS');
  FETCH PARAMS
    INTO vPARAMDETALHAITEM;
  CLOSE PARAMS;

  OPEN PARAMS('PermitirAlterarDescricaoItem');
  FETCH PARAMS
    INTO vPARAMITEMDESCRALT;
  CLOSE PARAMS;

  OPEN PARAMS('ImpSegDesc');
  FETCH PARAMS
    INTO vPARAMIMPSEGDESC;
  CLOSE PARAMS;

  OPEN PARAMS('ImpPrimSegDesc');
  FETCH PARAMS
    INTO vPARAMIMPPRIMSEGDESC;
  CLOSE PARAMS;

  OPEN CONSULTA;
  FETCH CONSULTA
    INTO vDescricao, vIFAT_QUANTIDADE, vIFAT_PRECOINF, vIFAT_VLRPROD;

  WHILE CONSULTA%FOUND LOOP
    IF (vDESCRICAOAUX IS NULL) OR (vDESCRICAOAUX <> vDescricao) THEN
      IF vPARAMDETALHAITEM = 'S' THEN
        vDescricao := vDescricao || ' (Qtd.: ' || (vIFAT_QUANTIDADE) ||
                      ' Vlr Unt: R$:' || vIFAT_PRECOINF || '  R$ ' ||
                      (vIFAT_VLRPROD) || ') ';
      END IF;
    
      IF vDESCRICAO_ITEM_NFSE IS NULL THEN
        vDESCRICAO_ITEM_NFSE := vDescricao;
      ELSE
        IF LENGTH(LTRIM(vDESCRICAO_ITEM_NFSE) || CHR(13) || vDescricao) <= 2000 THEN
          vDESCRICAO_ITEM_NFSE := LTRIM(vDESCRICAO_ITEM_NFSE) || CHR(13) ||
                                  vDescricao;
        END IF;
      END IF;
    END IF;
  
    vDESCRICAOAUX := vDescricao;
  
    FETCH CONSULTA
      INTO vDescricao, vIFAT_QUANTIDADE, vIFAT_PRECOINF, vIFAT_VLRPROD;
  END LOOP;

  CLOSE CONSULTA;

  vDESCRICAOAUX := NULL;

  OPEN CONSULTAPRODUTO;
  FETCH CONSULTAPRODUTO
    INTO vDESCRICAOPRODUTO, vIFAT_QUANTIDADE, vIFAT_PRECOINF, vIFAT_VLRPROD;

  WHILE CONSULTAPRODUTO%FOUND LOOP
    IF (vDESCRICAOAUX IS NULL) OR (vDESCRICAOAUX <> vDESCRICAOPRODUTO) THEN
      IF vPARAMDETALHAITEM = 'S' THEN
        vDESCRICAOPRODUTO := vDESCRICAOPRODUTO || ' (Qtd.: ' ||
                             (vIFAT_QUANTIDADE) || ' Vlr Unt: R$:' ||
                             vIFAT_PRECOINF || '  R$ ' || (vIFAT_VLRPROD) || ') ';
      END IF;
    
      IF vDESCRICAO_PRODUTO_NFSE IS NULL THEN
        vDESCRICAO_PRODUTO_NFSE := vDESCRICAOPRODUTO;
      ELSE
        IF LENGTH(LTRIM(vDESCRICAO_PRODUTO_NFSE)) <= 2000 THEN
          vDESCRICAO_PRODUTO_NFSE := LTRIM(vDESCRICAO_PRODUTO_NFSE) ||
                                     CHR(13) || vDESCRICAOPRODUTO;
        END IF;
      END IF;
    END IF;
  
    vDESCRICAOAUX := vDESCRICAOPRODUTO;
  
    FETCH CONSULTAPRODUTO
      INTO vDESCRICAOPRODUTO,
           vIFAT_QUANTIDADE,
           vIFAT_PRECOINF,
           vIFAT_VLRPROD;
  END LOOP;

  CLOSE CONSULTAPRODUTO;

  IF (vPARAMITEMDESCRALT = 'S') OR (vPARAMIMPSEGDESC = 'S') OR
     (vPARAMIMPPRIMSEGDESC = 'S') THEN
    IF (vDESCRICAO_ITEM_NFSE IS NOT NULL) THEN
      vRETORNO_FUNCAO := vDESCRICAO_ITEM_NFSE;
    END IF;
  ELSE
    IF (vPARAMITEMDESCRALT = 'N') AND (vDESCRICAO_PRODUTO_NFSE IS NOT NULL) THEN
      vRETORNO_FUNCAO := vDESCRICAO_PRODUTO_NFSE;
    END IF;
  END IF;

  RETURN LTRIM(vRETORNO_FUNCAO);
END;
/

CREATE OR REPLACE FUNCTION GET_DESC_SERVICO_NFSE (
	pEMPRESA  IN CHAR
	,pFILIAL   IN CHAR
	,pCDFATURA IN NUMBER
) RETURN VARCHAR2 IS
BEGIN
  /*
   Esta function foi criada desta forma para que seja utilizada por algum projeto 
   especifico que necessite de alterar a descri��o do servi�o no NFS-e.
   Quando o projeto especifico precisar realizar alguma especializa��o
   dever� subistituir a fun��o chamada abaixo pela fun��o do projeto especifico
   e subir o script de forma especifica, nunca devemos subir essa fun��o no
   pacote de script padr�o do ERP sem que seja com a fun��o GET_DESC_SERV_MANAGER.
   
   -- EQUIPE DESENVOVIMENTO FATURAMENTO 
   Caso tenha alguma altera��o de parametros nesta fun��o, a altera��o deve ser feita na fun��o do 
   modulo hospitalar.
 */

  RETURN LTRIM(GET_DESC_SERV_MANAGER(pEMPRESA, pFILIAL, pCDFATURA));
END;

/

CREATE OR REPLACE FUNCTION GET_DT_VENC_NFSE_MANAGER (
	PEMPRESA  IN CHAR
	,PFILIAL   IN CHAR 
	,PCDCLIFOR IN CHAR
	,PNF IN NUMBER
	,PNOTITULO IN CHAR
	,PNUMPARCELA IN CHAR
) RETURN VARCHAR2 IS
	vRETORNO_FUNCAO VARCHAR2(2000);
BEGIN
	vRETORNO_FUNCAO := NULL;
	
	vRETORNO_FUNCAO := TO_DATE(GET_TITULO_SCR(PEMPRESA, PFILIAL, PCDCLIFOR, PNF, PNOTITULO, PNUMPARCELA, 'TCR_DTVENCIME'), 'DD/MM/YYYY');
									
	RETURN(vRETORNO_FUNCAO);
END;
/

CREATE OR REPLACE FUNCTION GET_DATA_VENCIMENTO_NFSE (
	pEMPRESA  IN CHAR
	,pFILIAL   IN CHAR 
	,PCDCLIFOR IN CHAR
	,PNF IN NUMBER
	,PNOTITULO IN CHAR
	,PNUMPARCELA IN CHAR
) RETURN VARCHAR2 IS
BEGIN
  /*Esta function foi criada desta forma para que seja utilizada por algum projeto 
   especifico que necessite de alterar a exibi��o das informa��es da data de vencimento da nota fiscal de servi�o.
   Quando o projeto especifico precisar realizar alguma especializa��o
   dever� subistituir a fun��o chamada abaixo pela fun��o do projeto especifico
   e subir o script de forma especifica, nunca devemos subir essa fun��o no
   pacote de script padr�o do ERP sem que seja com a fun��o GET_DESC_SERV_MANAGER.
   
   -- EQUIPE DESENVOVIMENTO FATURAMENTO 
   Caso tenha alguma altera��o de parametros nesta fun��o, a altera��o deve ser feita na fun��o do 
   modulo hospitalar.
 */

  RETURN LTRIM(GET_DT_VENC_NFSE_MANAGER(pEMPRESA, pFILIAL, PCDCLIFOR,PNF,PNOTITULO, PNUMPARCELA));
END;
/

CREATE OR REPLACE FUNCTION GET_DESCRICAO_ITEM_NFSE (
	pEMPRESA  IN CHAR
	,pFILIAL   IN CHAR
	,pCDFATURA IN NUMBER
) RETURN VARCHAR2 IS
	vDESCRICAO_ITEM_NFSE    VARCHAR2(2000);
	vRETORNO_FUNCAO         VARCHAR2(2000);
	vMSG                    VARCHAR2(2000);
	vOBS                    VARCHAR2(2000);
	STR_DTVENCIME         	VARCHAR2(2000);
	
	vPARAMOBS             PARAMS_PAR.PAR_VLPARAM%TYPE;
	vPARAMDESCR           PARAMS_PAR.PAR_VLPARAM%TYPE;
	vPARAMNAOEXIBIRDTVENC PARAMS_PAR.PAR_VLPARAM%TYPE;
	vCDCLIFOR             FATURAS_FAT.FAT_CDCLIFOR%TYPE;
	vNF                   FATURAS_FAT.FAT_NF%TYPE;
	vDTVENCIME            FATURAS_FAT.FAT_DTVENCIME%TYPE;
	vNOTITULO             FATURAS_FAT.FAT_NOTITULO%TYPE;
	vTPOPER               FATURAS_FAT.FAT_TPOPER%TYPE;
	vIFAT_QUANTIDADE      ITFATURA_IFAT.IFAT_QUANTIDADE%TYPE;
	vIFAT_PRECOINF        ITFATURA_IFAT.IFAT_PRECOINF%TYPE;
	vIFAT_VLRPROD         ITFATURA_IFAT.IFAT_VLRPROD%TYPE;

	CURSOR CONSULTAMSG IS
		SELECT 
			A.MFA_MENS1 || ' ' || A.MFA_MENS2 || ' ' || A.MFA_MENS3 || ' ' ||
				B.MFA_MENS1 || ' ' || B.MFA_MENS2 || ' ' || B.MFA_MENS3 || ' ' ||
				C.MFA_MENS1 || ' ' || C.MFA_MENS2 || ' ' || C.MFA_MENS3
		FROM 
			FATURAS_FAT, 
			MENSFAT_MFA A, 
			MENSFAT_MFA B, 
			MENSFAT_MFA C
		WHERE 
			FAT_CDEMPRESA = pEMPRESA
			AND FAT_CDFILIAL = pFILIAL
			AND FAT_CDFATURA = pCDFATURA
			AND FAT_MENSFAT = A.MFA_CODIGO(+)
			AND FAT_MENSFAT2 = B.MFA_CODIGO(+)
			AND FAT_MENSFAT3 = C.MFA_CODIGO(+);
			
		CURSOR FATURA IS
			SELECT 
				FAT_CDCLIFOR
				,FAT_NF
				,FAT_DTVENCIME
				,FAT_NOTITULO
				,FAT_TPOPER
				,FAT_OBS
			FROM 
				FATURAS_FAT
			WHERE 
				FAT_CDEMPRESA = pEMPRESA
				AND FAT_CDFILIAL = pFILIAL
				AND FAT_CDFATURA = pCDFATURA;
				
		CURSOR PARAMS(pCDPARAM IN CHAR) IS
			SELECT 
				DECODE(UPPER(TRIM(PAR_VLPARAM)), 'FALSE', 'N', 'TRUE', 'S',  UPPER(TRIM(PAR_VLPARAM)))
			FROM 
				PARAMS_PAR
			WHERE 
				PAR_CDPARAM = pCDPARAM || pEMPRESA || pFILIAL;
BEGIN
	vDESCRICAO_ITEM_NFSE    := NULL;
	vRETORNO_FUNCAO         := NULL;
	vPARAMDESCR             := 'N';
	vPARAMOBS               := 'N';
	vPARAMNAOEXIBIRDTVENC   := 'N';

	OPEN PARAMS('PARNFSDESCITENS');
	FETCH PARAMS INTO vPARAMDESCR;
	CLOSE PARAMS;

	OPEN PARAMS('PARNFSOBSDESCSERV');
	FETCH PARAMS INTO vPARAMOBS;
	CLOSE PARAMS;

	OPEN PARAMS('PARNFSNAOEXIBIRDTVENC');
	FETCH PARAMS INTO vPARAMNAOEXIBIRDTVENC;
	CLOSE PARAMS;
	
	IF vPARAMDESCR = 'S' THEN 
		vDESCRICAO_ITEM_NFSE := GET_DESC_SERVICO_NFSE(pEMPRESA, pFILIAL, pCDFATURA);
	END IF;

	OPEN FATURA;
	FETCH FATURA INTO vCDCLIFOR, vNF, vDTVENCIME, vNOTITULO, vTPOPER, vOBS;
	CLOSE FATURA;

	OPEN CONSULTAMSG;
	FETCH CONSULTAMSG INTO vMSG;
	CLOSE CONSULTAMSG;

	IF vMSG IS NOT NULL THEN
		IF (INSTR(vDESCRICAO_ITEM_NFSE, vMSG) > 0) OR (INSTR(vMSG, vDESCRICAO_ITEM_NFSE) > 0) THEN
			vMSG := '';
		ELSE
			vMSG := vMSG || CHR(13);
		END IF;
	END IF;

	IF vPARAMOBS = 'S' THEN
		vDESCRICAO_ITEM_NFSE    := vDESCRICAO_ITEM_NFSE || CHR(13) || CHR(13) || vOBS;
	END IF;

	IF (vPARAMNAOEXIBIRDTVENC = 'N') THEN
		STR_DTVENCIME := GET_DATA_VENCIMENTO_NFSE(pEMPRESA, pFILIAL, vCDCLIFOR,vNF, vNOTITULO, 1); 
		
		IF (STR_DTVENCIME IS NOT NULL) THEN
			vDESCRICAO_ITEM_NFSE    := vDESCRICAO_ITEM_NFSE || CHR(13) || CHR(13) || '** VENCIMENTO => ' || STR_DTVENCIME;
		END IF;
	END IF;

	vRETORNO_FUNCAO :=  VMSG ||CHR(13)|| vDESCRICAO_ITEM_NFSE;
	
	RETURN LTRIM(vRETORNO_FUNCAO);
END; 
/

CREATE OR REPLACE FUNCTION GET_OBS_FATURA_NFSE_MANAGER (
	pEMPRESA   IN CHAR
	,pFILIAL   IN CHAR
	,pCDFATURA IN NUMBER
) RETURN VARCHAR2 IS
	vFAT_OBS	FATURAS_FAT.FAT_OBS%TYPE;
BEGIN
	vFAT_OBS := NULL;
	BEGIN
		SELECT
			FAT_OBS
		INTO
			vFAT_OBS
		FROM
			FATURAS_FAT
		WHERE
			FAT_CDEMPRESA    = pEMPRESA
			AND FAT_CDFILIAL = pFILIAL
			AND FAT_CDFATURA = pCDFATURA;
	EXCEPTION
		WHEN NO_DATA_FOUND THEN vFAT_OBS := NULL;
	END;
  RETURN VFAT_OBS;
END;
/

CREATE OR REPLACE FUNCTION GET_OBS_FATURA_NFSE (
	pEMPRESA   IN CHAR
	,pFILIAL   IN CHAR
	,pCDFATURA IN NUMBER
) RETURN VARCHAR2 IS
BEGIN
  /*
   Esta function foi criada desta forma para que seja utilizada por algum projeto
   especifico que necessite de alterar a observa��o do servi�o no NFS-e.
   Quando o projeto especifico precisar realizar alguma especializa��o
   dever� subistituir a fun��o chamada abaixo pela fun��o do projeto especifico
   e subir o script de forma especifica, nunca devemos subir essa fun��o no
   pacote de script padr�o do ERP sem que seja com a fun��o GET_OBS_FATURA_NFSE_MANAGER.
   -- EQUIPE DESENVOVIMENTO FATURAMENTO
   Caso tenha alguma altera��o de parametros nesta fun��o, a altera��o deve ser feita na fun��o do
   modulo hospitalar.
 */
  RETURN LTRIM(GET_OBS_FATURA_NFSE_MANAGER(pEMPRESA, pFILIAL, pCDFATURA));
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279858
PROMPT ======================================================================