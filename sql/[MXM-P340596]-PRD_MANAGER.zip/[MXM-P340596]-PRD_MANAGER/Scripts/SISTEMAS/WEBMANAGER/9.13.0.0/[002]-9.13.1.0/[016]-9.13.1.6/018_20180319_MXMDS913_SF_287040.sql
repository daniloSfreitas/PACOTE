PROMPT ======================================================================
PROMPT == DEMANDA......: 287040
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: LUCIANO VARGAS DE MATTOS
PROMPT == DATA.........: 05/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE ITFATURA_IFAT
   SET IFAT_VLRPMC = 0
 WHERE IFAT_VLRPMC < 0
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287040
PROMPT ======================================================================