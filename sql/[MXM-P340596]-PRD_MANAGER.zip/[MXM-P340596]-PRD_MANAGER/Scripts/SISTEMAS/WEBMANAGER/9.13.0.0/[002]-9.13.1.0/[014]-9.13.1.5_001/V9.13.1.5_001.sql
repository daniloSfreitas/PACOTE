PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.5_001 gerados em 27/02/2018 
PROMPT ============================================================= 

@@001_20180227_MXMDS913_MXMCONNECT_286178.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.5_001');

COMMIT;
