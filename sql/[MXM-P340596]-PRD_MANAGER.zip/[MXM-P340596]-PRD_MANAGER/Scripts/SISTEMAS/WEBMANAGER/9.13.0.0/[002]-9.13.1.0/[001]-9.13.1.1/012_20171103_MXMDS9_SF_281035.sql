PROMPT ======================================================================
PROMPT == DEMANDA......: 281035
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: RODRIGO DA PAZ DO NASCIMENTO
PROMPT == DATA.........: 31/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DROP INDEX UK1_FATPISCOFINS_PCO
/

ALTER TABLE FATPISCOFINS_PCO DROP CONSTRAINT UK1_FATPISCOFINS_PCO CASCADE DROP INDEX
/

ALTER TABLE FATPISCOFINS_PCO ADD
 (CONSTRAINT UK1_FATPISCOFINS_PCO
     UNIQUE (PCO_CDEMPRESA,
             PCO_CDFILIAL,
             PCO_CDCLASSFISCAL,
             PCO_CDTPOPER,
             PCO_CDCLIENTE,
             PCO_CDFORNECEDOR,
             PCO_CDTPPRODUTO,
             PCO_CDGRPRODUTO,
             PCO_CDPRODUTO,
             PCO_CDGREMPRESARIAL,
             PCO_TPTIPOPER,
             PCO_CDNCM
             )
 )
/

DROP INDEX UK1_FATIPIDIFER_IPD
/

ALTER TABLE FATIPIDIFER_IPD DROP CONSTRAINT UK1_FATIPIDIFER_IPD CASCADE DROP INDEX
/

ALTER TABLE FATIPIDIFER_IPD ADD
 (CONSTRAINT UK1_FATIPIDIFER_IPD
     UNIQUE (IPD_CDEMPRESA,
             IPD_CDFILIAL,
             IPD_CDCLASSFISCAL,
             IPD_CDTPOPER,
             IPD_CDCLIENTE,
             IPD_CDFORNECEDOR,
             IPD_CDTPPRODUTO,
             IPD_CDGRPRODUTO,
             IPD_CDPRODUTO,
             IPD_CDGREMPRESARIAL,
             IPD_TPTIPOPER,
             IPD_CDNCM
             )
 )
/

DROP INDEX UK1_FATICMSSTDIFER_ISD
/

ALTER TABLE FATICMSSTDIFER_ISD DROP CONSTRAINT UK1_FATICMSSTDIFER_ISD CASCADE DROP INDEX
/

ALTER TABLE FATICMSSTDIFER_ISD  ADD
 (CONSTRAINT UK1_FATICMSSTDIFER_ISD
     UNIQUE (ISD_CDEMPRESA,
             ISD_CDUFORIGEM,
             ISD_CDUFDESTINO,
             ISD_CDCLASSFISCAL,
             ISD_CDTPOPER,
             ISD_CDCLIENTE,
             ISD_CDFORNECEDOR,
             ISD_CDTPPRODUTO,
             ISD_CDGRPRODUTO,
             ISD_CDPRODUTO,
             ISD_CDGREMPRESARIAL,
             ISD_TPTIPOPER,
             ISD_CDNCM)
 )
/

DROP INDEX UFICMSDIFER_UID_UN1
/

ALTER TABLE UFICMSDIFER_UID DROP CONSTRAINT UK1_UFICMSDIFER_UID CASCADE DROP INDEX
/

ALTER TABLE UFICMSDIFER_UID  ADD
 (CONSTRAINT UK1_UFICMSDIFER_UID
     UNIQUE (UID_UFORIGEM,
             UID_CDEMPRESA,
             UID_TPPROD,
             UID_GRUPO,
             UID_ITEM,
             UID_UFDESTINO,
             UID_TPOPER,
             UID_CDCLIENTE,
             UID_CDFORNECEDOR,
             UID_CDCLASSFISCAL,
             UID_CDGREMPRESARIAL,
             UID_TPTIPOPER,
             UID_CDNCM)
 )
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 281035
PROMPT ======================================================================