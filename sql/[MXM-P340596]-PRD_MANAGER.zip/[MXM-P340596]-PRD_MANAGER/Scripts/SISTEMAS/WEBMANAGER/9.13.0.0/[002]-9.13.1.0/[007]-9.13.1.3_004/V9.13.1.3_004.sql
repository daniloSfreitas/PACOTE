PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.3_004 gerados em 02/01/2018 
PROMPT ============================================================= 

@@001_20170102_MXMDS913_SGE_282320.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.3_004');

COMMIT;
