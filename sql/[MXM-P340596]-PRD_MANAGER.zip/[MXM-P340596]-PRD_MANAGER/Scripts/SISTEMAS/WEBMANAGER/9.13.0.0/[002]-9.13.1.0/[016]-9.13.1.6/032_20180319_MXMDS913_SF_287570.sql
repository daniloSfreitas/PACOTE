PROMPT ======================================================================
PROMPT == DEMANDA......: 287570
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: THIAGO LUIZ SANTOS COUTINHO
PROMPT == DATA.........: 19/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO SPEDLISTSERVLC116_SLS (SLS_CODIGO, SLS_DESCSERVICO, SLS_DESCRESUMIDA, SLS_GRUPOSERV, SLS_DTINICIO, SLS_DTFIM) VALUES ('1725', 'Inser��o de textos, desenhos e outros materiais de propaganda e publicidade, em qualquer meio', 'Inser��o de textos, desenhos e outros materiais de propaganda e publicidade, em', '17', TO_DATE('30/12/2016', 'DD/MM/YYYY'), NULL)
/

INSERT INTO SPEDLISTSERVLC116_SLS (SLS_CODIGO, SLS_DESCSERVICO, SLS_DESCRESUMIDA, SLS_GRUPOSERV, SLS_DTINICIO, SLS_DTFIM) VALUES ('0109','Disponibiliza��o, sem cess�o definitiva, de conte�dos de �udio, v�deo, imagem e texto por meio da internet, respeitada a imunidade de livros, jornais e peri�dico', 'Disponibiliza��o, sem cess�o definitiva, de conte�dos de �udio, v�deo, imagem e ', '1', TO_DATE('30/12/2016', 'DD/MM/YYYY'), NULL)
/

INSERT INTO SPEDLISTSERVLC116_SLS (SLS_CODIGO, SLS_DESCSERVICO, SLS_DESCRESUMIDA, SLS_GRUPOSERV, SLS_DTINICIO, SLS_DTFIM) VALUES ('0606', 'Aplica��o de tatuagens, piercings e cong�neres', 'Aplica��o de tatuagens, piercings e cong�neres', '6', TO_DATE('30/12/2016', 'DD/MM/YYYY'), NULL)
/

INSERT INTO SPEDLISTSERVLC116_SLS (SLS_CODIGO, SLS_DESCSERVICO, SLS_DESCRESUMIDA, SLS_GRUPOSERV, SLS_DTINICIO, SLS_DTFIM) VALUES ('1414', 'Guincho intramunicipal, guindaste e i�amento', 'Guincho intramunicipal, guindaste e i�amento', '14', TO_DATE('30/12/2016', 'DD/MM/YYYY'), NULL)
/

INSERT INTO SPEDLISTSERVLC116_SLS (SLS_CODIGO, SLS_DESCSERVICO, SLS_DESCRESUMIDA, SLS_GRUPOSERV, SLS_DTINICIO, SLS_DTFIM) VALUES ('1602','Outros servi�os de transporte de natureza municipal', 'Outros servi�os de transporte de natureza municipal', '16', TO_DATE('30/12/2016', 'DD/MM/YYYY'), NULL)
/

INSERT INTO SPEDLISTSERVLC116_SLS (SLS_CODIGO, SLS_DESCSERVICO, SLS_DESCRESUMIDA, SLS_GRUPOSERV, SLS_DTINICIO, SLS_DTFIM) VALUES ('2505','Cess�o de uso de espa�os em cemit�rios para sepultamento', 'Cess�o de uso de espa�os em cemit�rios para sepultamento', '25', TO_DATE('30/12/2016', 'DD/MM/YYYY'), NULL)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287570
PROMPT ======================================================================