PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.7_006 gerados em 28/05/2018 
PROMPT ============================================================= 

@@001_20180528_MXMDS913_EFDREINF_293303.sql
@@999_20180606_MXMDS913_ADMDADOS_9.13.1.7_006.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.7_006');

COMMIT;
