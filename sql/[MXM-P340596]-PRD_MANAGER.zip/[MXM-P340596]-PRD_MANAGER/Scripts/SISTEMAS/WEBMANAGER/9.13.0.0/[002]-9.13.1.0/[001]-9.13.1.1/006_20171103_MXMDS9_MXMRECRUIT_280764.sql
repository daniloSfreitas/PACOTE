PROMPT ======================================================================
PROMPT == DEMANDA......: 280764
PROMPT == SISTEMA......: MXM-RECRUITMENT
PROMPT == RESPONSAVEL..: PALOMA CASSIA CAMPELO DE OLIVEIRA
PROMPT == DATA.........: 26/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRETABDICDADOS_TDR
(TDR_IDTABELA, TDR_NMTABELA, TDR_DSTABELA, TDR_NRFORCARJOIN)
VALUES ((SELECT MAX(TDR_IDTABELA)+1 FROM GRETABDICDADOS_TDR),'RECPROCRECRUTAMENTO_PRC RECPROC', 'Processo', 0)
/

INSERT INTO GREVISAOTAB_VDR
    (
        VDR_IDVISAO,
        VDR_NRTABELA,
        VDR_CDSISTEMA,
        VRD_DSVISAO,
        VRD_NRFUNCAO
    )
VALUES
    (
        (SELECT MAX(VDR_IDVISAO) +1 FROM GREVISAOTAB_VDR),
        (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECPROCRECRUTAMENTO_PRC RECPROC'),
        'MXMRECRUIT',
        'Processos',
        '35243'
    )
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280764
PROMPT ======================================================================