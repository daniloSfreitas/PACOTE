PROMPT ======================================================================
PROMPT == DEMANDA......: 288228
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: JULIO OLIVEIRA
PROMPT == DATA.........: 19/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO ERROMSG_ERM VALUES ('FAT0146','N�o pode utilizar inscri��o estadual de substitui��o tribut�ria (IE-ST) nas opera��es internas.')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 288228
PROMPT ======================================================================