PROMPT ======================================================================
PROMPT == DEMANDA......: 285776
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: HUMBERTO COELHO DE CAMPOS MENDONCA
PROMPT == DATA.........: 13/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (40553, 'Concilia��o das Contas Cont�beis', 'Concilia��o das Contas Cont�beis')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('EFD', 40553, 25, 4000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40553, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40553, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40553, 'EXC')
/

ALTER TABLE FATITFATIMPOSTO_IFI ADD IFI_VLICMSDESONERADO NUMBER(15,2)
/

ALTER TABLE FATITFATIMPOSTO_IFI ADD IFI_CDMOTIVOICMSDESONERADO NUMBER(2)
/

ALTER TABLE FATITFATIMPOSTO_IFI ADD IFI_VLBICMSNAOTRIBUTADO NUMBER(15,2)
/

ALTER TABLE FATITFATIMPOSTO_IFI ADD IFI_PECREDITOPRESUMIDO NUMBER(15,2)
/

ALTER TABLE FATITFATIMPOSTO_IFI ADD IFI_VLCREDITOPRESUMIDO NUMBER(15,2)
/

COMMENT ON COLUMN FATITFATIMPOSTO_IFI.IFI_VLICMSDESONERADO  is 'Valor do ICMS Desonerado'
/

COMMENT ON COLUMN FATITFATIMPOSTO_IFI.IFI_CDMOTIVOICMSDESONERADO  is 'C�digo do motivo do ICMS Desonerado'
/

COMMENT ON COLUMN FATITFATIMPOSTO_IFI.IFI_VLBICMSNAOTRIBUTADO  is 'Base ICMS n�o tributado'
/

COMMENT ON COLUMN FATITFATIMPOSTO_IFI.IFI_PECREDITOPRESUMIDO  is 'Percentual Cr�dito Presumido ICMS da opera��o anterior que ir� incidir no ST'
/

COMMENT ON COLUMN FATITFATIMPOSTO_IFI.IFI_VLCREDITOPRESUMIDO  is 'Valor Cr�dito Presumido ICMS da opera��o anterior que ir� incidir no ST'
/

ALTER TABLE FATITFATIMPOSTO_IFI ADD IFI_CDNOCONTAB VARCHAR2(15) DEFAULT NULL
/

COMMENT ON COLUMN FATITFATIMPOSTO_IFI .IFI_CDNOCONTAB IS 'CONTA CONT�BIL DO ITEM'
/

ALTER TABLE FATITFATIMPOSTO_IFI ADD IFI_CDNOCCUSTO VARCHAR2(15) DEFAULT NULL
/

COMMENT ON COLUMN FATITFATIMPOSTO_IFI .IFI_CDNOCCUSTO IS 'CENTRO DE CUSTO DO ITEM'
/

CREATE OR REPLACE PROCEDURE PRC_INSFATITFATIMPOSTO_IFI(PIFI_IDIMPOSTO               IN OUT NUMBER,
                                                       PIFI_CDEMPRESA               IN CHAR,
                                                       PIFI_CDFILIAL                IN CHAR,
                                                       PIFI_CDFATURA                IN NUMBER,
                                                       PIFI_CDITEM                  IN CHAR,
                                                       PIFI_SQITEM                  IN NUMBER,
                                                       PIFI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                       PIFI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                       PIFI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                       PIFI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                       PIFI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                       PIFI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                       PIFI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                       PIFI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                       PIFI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                       PIFI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                       PIFI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                       PIFI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                       PIFI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                       PIFI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                       PIFI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                       PIFI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                       PIFI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                       PIFI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                       PIFI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIFI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIFI_DTINCLUSAO              IN DATE DEFAULT SYSDATE,
                                                       PIFI_USINCLUSAO              IN CHAR DEFAULT NULL,
                                                       PIFI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIFI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                       PIFI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                       PIFI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                       PIFI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                       PIFI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                       PIFI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                       PIFI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                       PIFI_CDNCM                   IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                       PIFI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                       PIFI_VLFCPST                 IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSDESONERADO        IN NUMBER DEFAULT NULL,
                                                       PIFI_CDMOTIVOICMSDESONERADO  IN NUMBER DEFAULT NULL,
                                                       PIFI_VLBICMSNAOTRIBUTADO     IN NUMBER DEFAULT NULL,
                                                       PIFI_PECREDITOPRESUMIDO      IN NUMBER DEFAULT NULL,
                                                       PIFI_VLCREDITOPRESUMIDO      IN NUMBER DEFAULT NULL,
                                                       PIFI_CDNOCONTAB              IN CHAR DEFAULT NULL,
                                                       PIFI_CDNOCCUSTO              IN CHAR DEFAULT NULL) AS
BEGIN
  IF PIFI_IDIMPOSTO IS NULL THEN
    SELECT SEQ1_FATITFATIMPOSTO_IFI.NEXTVAL INTO PIFI_IDIMPOSTO FROM DUAL;
  END IF;
  INSERT INTO FATITFATIMPOSTO_IFI
    (IFI_IDIMPOSTO,
     IFI_CDEMPRESA,
     IFI_CDFILIAL,
     IFI_CDFATURA,
     IFI_CDITEM,
     IFI_SQITEM,
     IFI_PEICMS,
     IFI_PEINCICMS,
     IFI_TPCONDTRIBICMS,
     IFI_CDPREFIXOCSTICMS,
     IFI_CDCSTICMS,
     IFI_CDDETBCSTICMS,
     IFI_CDDETBCICMS,
     IFI_CDCFOICMS,
     IFI_VBGERABASESUPERIORICMS,
     IFI_VBGERACUSTOICMS,
     IFI_VBGERACIAPICMS,
     IFI_CDCSTICMSST,
     IFI_CDDETBCSTICMSST,
     IFI_CDDETBCICMSST,
     IFI_TPCALCULOICMSST,
     IFI_VBACREDECREICMSST,
     IFI_VLPMCICMSST,
     IFI_PEMVAICMSST,
     IFI_PEALIQINTERNAICMSST,
     IFI_PEREDUCAOICMSST,
     IFI_PEREDUCAONORMALICMSST,
     IFI_CDCSTIPI,
     IFI_PEALIQIPI,
     IFI_TPCONDTRIBIPI,
     IFI_VBGERABASESUPIPI,
     IFI_VBBCICMSIPI,
     IFI_VBSOBREPRECOTABIPI,
     IFI_VBREDBASEICMSIPI,
     IFI_VBGERACUSTOIPI,
     IFI_VBNAOCOMPOEPISCOF,
     IFI_VBNAOCUMULATIVOPISCOF,
     IFI_CDCSTPIS,
     IFI_VBGERACUSTOPIS,
     IFI_PEALIQPIS,
     IFI_TPCONDTRIBPIS,
     IFI_PEREDBASEPIS,
     IFI_PEPAUTADOPIS,
     IFI_CDCSTCOFINS,
     IFI_VBGERACUSTOCOFINS,
     IFI_PEALIQCOFINS,
     IFI_TPCONDTRIBCOFINS,
     IFI_PEREDBASECOFINS,
     IFI_PEPAUTADOCOFINS,
     IFI_CDCSTNATBASECREDPISCOF,
     IFI_TPINDNATFRETEPISCOF,
     IFI_CDINDNATFRETEPISCOF,
     IFI_DTINCLUSAO,
     IFI_USINCLUSAO,
     IFI_PEICMSUFDEST,
     IFI_PEICMSINTERPARTILHA,
     IFI_VLDEVOLUCAOICMSST,
     IFI_PEICMSINTERESTADUAL,
     IFI_VLBASEFCP,
     IFI_PEFECP,
     IFI_VLFECP,
     IFI_VLICMSUFDEST,
     IFI_VLICMSUFREMET,
     IFI_PEDIFERIMENTO,
     IFI_VLICMSOPERACAO,
     IFI_CDNCM,
     IFI_VBCALCIMPOSTONOVOICMS,
     IFI_VBCALCIMPOSTONOVOIPI,
     IFI_VBCALCIMPOSTONOVOPIS,
     IFI_VBCALCIMPOSTONOVOCOFINS,
     IFI_VBCALCIMPOSTONOVOICMSST,
     IFI_VLBASEFCPST,
     IFI_PEFCPST,
     IFI_VLFCPST,
     IFI_VLICMSDESONERADO,
     IFI_CDMOTIVOICMSDESONERADO,
     IFI_VLBICMSNAOTRIBUTADO,
     IFI_PECREDITOPRESUMIDO,
     IFI_VLCREDITOPRESUMIDO,
     IFI_CDNOCONTAB,
     IFI_CDNOCCUSTO)
  VALUES
    (PIFI_IDIMPOSTO,
     PIFI_CDEMPRESA,
     PIFI_CDFILIAL,
     PIFI_CDFATURA,
     PIFI_CDITEM,
     PIFI_SQITEM,
     PIFI_PEICMS,
     PIFI_PEINCICMS,
     PIFI_TPCONDTRIBICMS,
     PIFI_CDPREFIXOCSTICMS,
     PIFI_CDCSTICMS,
     PIFI_CDDETBCSTICMS,
     PIFI_CDDETBCICMS,
     PIFI_CDCFOICMS,
     PIFI_VBGERABASESUPERIORICMS,
     PIFI_VBGERACUSTOICMS,
     PIFI_VBGERACIAPICMS,
     PIFI_CDCSTICMSST,
     PIFI_CDDETBCSTICMSST,
     PIFI_CDDETBCICMSST,
     PIFI_TPCALCULOICMSST,
     PIFI_VBACREDECREICMSST,
     PIFI_VLPMCICMSST,
     PIFI_PEMVAICMSST,
     PIFI_PEALIQINTERNAICMSST,
     PIFI_PEREDUCAOICMSST,
     PIFI_PEREDUCAONORMALICMSST,
     PIFI_CDCSTIPI,
     PIFI_PEALIQIPI,
     PIFI_TPCONDTRIBIPI,
     PIFI_VBGERABASESUPIPI,
     PIFI_VBBCICMSIPI,
     PIFI_VBSOBREPRECOTABIPI,
     PIFI_VBREDBASEICMSIPI,
     PIFI_VBGERACUSTOIPI,
     PIFI_VBNAOCOMPOEPISCOF,
     PIFI_VBNAOCUMULATIVOPISCOF,
     PIFI_CDCSTPIS,
     PIFI_VBGERACUSTOPIS,
     PIFI_PEALIQPIS,
     PIFI_TPCONDTRIBPIS,
     PIFI_PEREDBASEPIS,
     PIFI_PEPAUTADOPIS,
     PIFI_CDCSTCOFINS,
     PIFI_VBGERACUSTOCOFINS,
     PIFI_PEALIQCOFINS,
     PIFI_TPCONDTRIBCOFINS,
     PIFI_PEREDBASECOFINS,
     PIFI_PEPAUTADOCOFINS,
     PIFI_CDCSTNATBASECREDPISCOF,
     PIFI_TPINDNATFRETEPISCOF,
     PIFI_CDINDNATFRETEPISCOF,
     NVL(PIFI_DTINCLUSAO, SYSDATE),
     NVL(PIFI_USINCLUSAO, GET_USER_MXM),
     PIFI_PEICMSUFDEST,
     PIFI_PEICMSINTERPARTILHA,
     PIFI_VLDEVOLUCAOICMSST,
     PIFI_PEICMSINTERESTADUAL,
     PIFI_VLBASEFCP,
     PIFI_PEFECP,
     PIFI_VLFECP,
     PIFI_VLICMSUFDEST,
     PIFI_VLICMSUFREMET,
     PIFI_PEDIFERIMENTO,
     PIFI_VLICMSOPERACAO,
     PIFI_CDNCM,
     PIFI_VBCALCIMPOSTONOVOICMS,
     PIFI_VBCALCIMPOSTONOVOIPI,
     PIFI_VBCALCIMPOSTONOVOPIS,
     PIFI_VBCALCIMPOSTONOVOCOFINS,
     PIFI_VBCALCIMPOSTONOVOICMSST,
     PIFI_VLBASEFCPST,
     PIFI_PEFCPST,
     PIFI_VLFCPST,
     PIFI_VLICMSDESONERADO,
     PIFI_CDMOTIVOICMSDESONERADO,
     PIFI_VLBICMSNAOTRIBUTADO,
     PIFI_PECREDITOPRESUMIDO,
     PIFI_VLCREDITOPRESUMIDO,
     PIFI_CDNOCONTAB,
     PIFI_CDNOCCUSTO);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATITFATIMPOSTO_IFI(PIFI_IDIMPOSTO               IN NUMBER,
                                                       PIFI_CDEMPRESA               IN CHAR,
                                                       PIFI_CDFILIAL                IN CHAR,
                                                       PIFI_CDFATURA                IN NUMBER,
                                                       PIFI_CDITEM                  IN CHAR,
                                                       PIFI_SQITEM                  IN NUMBER,
                                                       PIFI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                       PIFI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                       PIFI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                       PIFI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                       PIFI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                       PIFI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                       PIFI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                       PIFI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                       PIFI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                       PIFI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                       PIFI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                       PIFI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                       PIFI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                       PIFI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                       PIFI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                       PIFI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                       PIFI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                       PIFI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                       PIFI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIFI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIFI_DTINCLUSAO              IN DATE DEFAULT SYSDATE,
                                                       PIFI_USINCLUSAO              IN CHAR DEFAULT NULL,
                                                       PIFI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIFI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                       PIFI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                       PIFI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                       PIFI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                       PIFI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                       PIFI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                       PIFI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                       PIFI_CDNCM                   IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                       PIFI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                       PIFI_VLFCPST                 IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSDESONERADO        IN NUMBER DEFAULT NULL,
                                                       PIFI_CDMOTIVOICMSDESONERADO  IN NUMBER DEFAULT NULL,
                                                       PIFI_VLBICMSNAOTRIBUTADO     IN NUMBER DEFAULT NULL,
                                                       PIFI_PECREDITOPRESUMIDO      IN NUMBER DEFAULT NULL,
                                                       PIFI_VLCREDITOPRESUMIDO      IN NUMBER DEFAULT NULL,
                                                       PIFI_CDNOCONTAB              IN CHAR DEFAULT NULL,
                                                       PIFI_CDNOCCUSTO              IN CHAR DEFAULT NULL) AS
BEGIN
  UPDATE FATITFATIMPOSTO_IFI
     SET IFI_CDEMPRESA               = PIFI_CDEMPRESA,
         IFI_CDFILIAL                = PIFI_CDFILIAL,
         IFI_CDFATURA                = PIFI_CDFATURA,
         IFI_CDITEM                  = PIFI_CDITEM,
         IFI_SQITEM                  = PIFI_SQITEM,
         IFI_PEICMS                  = PIFI_PEICMS,
         IFI_PEINCICMS               = PIFI_PEINCICMS,
         IFI_TPCONDTRIBICMS          = PIFI_TPCONDTRIBICMS,
         IFI_CDPREFIXOCSTICMS        = PIFI_CDPREFIXOCSTICMS,
         IFI_CDCSTICMS               = PIFI_CDCSTICMS,
         IFI_CDDETBCSTICMS           = PIFI_CDDETBCSTICMS,
         IFI_CDDETBCICMS             = PIFI_CDDETBCICMS,
         IFI_CDCFOICMS               = PIFI_CDCFOICMS,
         IFI_VBGERABASESUPERIORICMS  = PIFI_VBGERABASESUPERIORICMS,
         IFI_VBGERACUSTOICMS         = PIFI_VBGERACUSTOICMS,
         IFI_VBGERACIAPICMS          = PIFI_VBGERACIAPICMS,
         IFI_CDCSTICMSST             = PIFI_CDCSTICMSST,
         IFI_CDDETBCSTICMSST         = PIFI_CDDETBCSTICMSST,
         IFI_CDDETBCICMSST           = PIFI_CDDETBCICMSST,
         IFI_TPCALCULOICMSST         = PIFI_TPCALCULOICMSST,
         IFI_VBACREDECREICMSST       = PIFI_VBACREDECREICMSST,
         IFI_VLPMCICMSST             = PIFI_VLPMCICMSST,
         IFI_PEMVAICMSST             = PIFI_PEMVAICMSST,
         IFI_PEALIQINTERNAICMSST     = PIFI_PEALIQINTERNAICMSST,
         IFI_PEREDUCAOICMSST         = PIFI_PEREDUCAOICMSST,
         IFI_PEREDUCAONORMALICMSST   = PIFI_PEREDUCAONORMALICMSST,
         IFI_CDCSTIPI                = PIFI_CDCSTIPI,
         IFI_PEALIQIPI               = PIFI_PEALIQIPI,
         IFI_TPCONDTRIBIPI           = PIFI_TPCONDTRIBIPI,
         IFI_VBGERABASESUPIPI        = PIFI_VBGERABASESUPIPI,
         IFI_VBBCICMSIPI             = PIFI_VBBCICMSIPI,
         IFI_VBSOBREPRECOTABIPI      = PIFI_VBSOBREPRECOTABIPI,
         IFI_VBREDBASEICMSIPI        = PIFI_VBREDBASEICMSIPI,
         IFI_VBGERACUSTOIPI          = PIFI_VBGERACUSTOIPI,
         IFI_VBNAOCOMPOEPISCOF       = PIFI_VBNAOCOMPOEPISCOF,
         IFI_VBNAOCUMULATIVOPISCOF   = PIFI_VBNAOCUMULATIVOPISCOF,
         IFI_CDCSTPIS                = PIFI_CDCSTPIS,
         IFI_VBGERACUSTOPIS          = PIFI_VBGERACUSTOPIS,
         IFI_PEALIQPIS               = PIFI_PEALIQPIS,
         IFI_TPCONDTRIBPIS           = PIFI_TPCONDTRIBPIS,
         IFI_PEREDBASEPIS            = PIFI_PEREDBASEPIS,
         IFI_PEPAUTADOPIS            = PIFI_PEPAUTADOPIS,
         IFI_CDCSTCOFINS             = PIFI_CDCSTCOFINS,
         IFI_VBGERACUSTOCOFINS       = PIFI_VBGERACUSTOCOFINS,
         IFI_PEALIQCOFINS            = PIFI_PEALIQCOFINS,
         IFI_TPCONDTRIBCOFINS        = PIFI_TPCONDTRIBCOFINS,
         IFI_PEREDBASECOFINS         = PIFI_PEREDBASECOFINS,
         IFI_PEPAUTADOCOFINS         = PIFI_PEPAUTADOCOFINS,
         IFI_CDCSTNATBASECREDPISCOF  = PIFI_CDCSTNATBASECREDPISCOF,
         IFI_TPINDNATFRETEPISCOF     = PIFI_TPINDNATFRETEPISCOF,
         IFI_CDINDNATFRETEPISCOF     = PIFI_CDINDNATFRETEPISCOF,
         IFI_DTINCLUSAO              = NVL(PIFI_DTINCLUSAO, SYSDATE),
         IFI_USINCLUSAO              = NVL(PIFI_USINCLUSAO, GET_USER_MXM),
         IFI_PEICMSUFDEST            = PIFI_PEICMSUFDEST,
         IFI_PEICMSINTERPARTILHA     = PIFI_PEICMSINTERPARTILHA,
         IFI_VLDEVOLUCAOICMSST       = PIFI_VLDEVOLUCAOICMSST,
         IFI_PEICMSINTERESTADUAL     = PIFI_PEICMSINTERESTADUAL,
         IFI_VLBASEFCP               = PIFI_VLBASEFCP,
         IFI_PEFECP                  = PIFI_PEFECP,
         IFI_VLFECP                  = PIFI_VLFECP,
         IFI_VLICMSUFDEST            = PIFI_VLICMSUFDEST,
         IFI_VLICMSUFREMET           = PIFI_VLICMSUFREMET,
         IFI_PEDIFERIMENTO           = PIFI_PEDIFERIMENTO,
         IFI_VLICMSOPERACAO          = PIFI_VLICMSOPERACAO,
         IFI_CDNCM                   = PIFI_CDNCM,
         IFI_VBCALCIMPOSTONOVOICMS   = PIFI_VBCALCIMPOSTONOVOICMS,
         IFI_VBCALCIMPOSTONOVOIPI    = PIFI_VBCALCIMPOSTONOVOIPI,
         IFI_VBCALCIMPOSTONOVOPIS    = PIFI_VBCALCIMPOSTONOVOPIS,
         IFI_VBCALCIMPOSTONOVOCOFINS = PIFI_VBCALCIMPOSTONOVOCOFINS,
         IFI_VBCALCIMPOSTONOVOICMSST = PIFI_VBCALCIMPOSTONOVOICMSST,
         IFI_VLBASEFCPST             = PIFI_VLBASEFCPST,
         IFI_PEFCPST                 = PIFI_PEFCPST,
         IFI_VLFCPST                 = PIFI_VLFCPST,
         IFI_VLICMSDESONERADO        = PIFI_VLICMSDESONERADO,
         IFI_CDMOTIVOICMSDESONERADO  = PIFI_CDMOTIVOICMSDESONERADO,
         IFI_VLBICMSNAOTRIBUTADO     = PIFI_VLBICMSNAOTRIBUTADO,
         IFI_PECREDITOPRESUMIDO      = PIFI_PECREDITOPRESUMIDO,
         IFI_VLCREDITOPRESUMIDO      = PIFI_VLCREDITOPRESUMIDO,
         IFI_CDNOCONTAB              = PIFI_CDNOCONTAB,
         IFI_CDNOCCUSTO              = PIFI_CDNOCCUSTO
   WHERE IFI_IDIMPOSTO = PIFI_IDIMPOSTO;
END;
/

ALTER TABLE SGEITMOVIMPOSTO_MVI ADD MVI_VLICMSDESONERADO NUMBER(15,2)
/

ALTER TABLE SGEITMOVIMPOSTO_MVI ADD MVI_CDMOTIVOICMSDESONERADO NUMBER(2)
/

ALTER TABLE SGEITMOVIMPOSTO_MVI ADD MVI_VLBICMSNAOTRIBUTADO NUMBER(15,2)
/

ALTER TABLE SGEITMOVIMPOSTO_MVI ADD MVI_PECREDITOPRESUMIDO NUMBER(15,2)
/

ALTER TABLE SGEITMOVIMPOSTO_MVI ADD MVI_VLCREDITOPRESUMIDO NUMBER(15,2)
/

COMMENT ON COLUMN SGEITMOVIMPOSTO_MVI.MVI_VLICMSDESONERADO  is 'Valor do ICMS Desonerado'
/

COMMENT ON COLUMN SGEITMOVIMPOSTO_MVI.MVI_CDMOTIVOICMSDESONERADO  is 'C�digo do motivo do ICMS Desonerado'
/

COMMENT ON COLUMN SGEITMOVIMPOSTO_MVI.MVI_VLBICMSNAOTRIBUTADO  is 'Base ICMS n�o tributado'
/

COMMENT ON COLUMN SGEITMOVIMPOSTO_MVI.MVI_PECREDITOPRESUMIDO  is 'Percentual Cr�dito Presumido ICMS da opera��o anterior que ir� incidir no ST'
/

COMMENT ON COLUMN SGEITMOVIMPOSTO_MVI.MVI_VLCREDITOPRESUMIDO  is 'Valor Cr�dito Presumido ICMS da opera��o anterior que ir� incidir no ST'
/

ALTER TABLE SGEITMOVIMPOSTO_MVI ADD MVI_CDNOCONTAB VARCHAR2(15) DEFAULT NULL
/

COMMENT ON COLUMN SGEITMOVIMPOSTO_MVI .MVI_CDNOCONTAB IS 'CONTA CONT�BIL DO ITEM'
/

ALTER TABLE SGEITMOVIMPOSTO_MVI ADD MVI_CDNOCCUSTO VARCHAR2(15) DEFAULT NULL
/

COMMENT ON COLUMN SGEITMOVIMPOSTO_MVI .MVI_CDNOCCUSTO IS 'CENTRO DE CUSTO DO ITEM'
/

CREATE OR REPLACE PROCEDURE PRC_INSSGEITMOVIMPOSTO_MVI(PMVI_IDIMPOSTO               IN OUT NUMBER,
                                                       PMVI_SQNOTA                  IN NUMBER,
                                                       PMVI_SQITEM                  IN NUMBER,
                                                       PMVI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                       PMVI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                       PMVI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                       PMVI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                       PMVI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                       PMVI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                       PMVI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                       PMVI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                       PMVI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                       PMVI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                       PMVI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                       PMVI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                       PMVI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                       PMVI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                       PMVI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                       PMVI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                       PMVI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                       PMVI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                       PMVI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PMVI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PMVI_DTINCLUSAO              IN DATE DEFAULT SYSDATE,
                                                       PMVI_USINCLUSAO              IN CHAR DEFAULT NULL,
                                                       PMVI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PMVI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                       PMVI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                       PMVI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                       PMVI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                       PMVI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                       PMVI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                       PMVI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                       PMVI_CDNCM                   IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                       PMVI_VLSTDEVIDONAENTRADA     IN CHAR DEFAULT NULL,
                                                       PMVI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                       PMVI_VLFCPST                 IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSDESONERADO        IN NUMBER DEFAULT NULL,
                                                       PMVI_CDMOTIVOICMSDESONERADO  IN NUMBER DEFAULT NULL,
                                                       PMVI_VLBICMSNAOTRIBUTADO     IN NUMBER DEFAULT NULL,
                                                       PMVI_PECREDITOPRESUMIDO      IN NUMBER DEFAULT NULL,
                                                       PMVI_VLCREDITOPRESUMIDO      IN NUMBER DEFAULT NULL,
                                                       PMVI_CDNOCONTAB              IN CHAR DEFAULT NULL,
                                                       PMVI_CDNOCCUSTO              IN CHAR DEFAULT NULL) AS
BEGIN
  IF PMVI_IDIMPOSTO IS NULL THEN
    SELECT SEQ1_SGEITMOVIMPOSTO_MVI.NEXTVAL INTO PMVI_IDIMPOSTO FROM DUAL;
  END IF;
  INSERT INTO SGEITMOVIMPOSTO_MVI
    (MVI_IDIMPOSTO,
     MVI_SQNOTA,
     MVI_SQITEM,
     MVI_PEICMS,
     MVI_PEINCICMS,
     MVI_TPCONDTRIBICMS,
     MVI_CDPREFIXOCSTICMS,
     MVI_CDCSTICMS,
     MVI_CDDETBCSTICMS,
     MVI_CDDETBCICMS,
     MVI_CDCFOICMS,
     MVI_VBGERABASESUPERIORICMS,
     MVI_VBGERACUSTOICMS,
     MVI_VBGERACIAPICMS,
     MVI_CDCSTICMSST,
     MVI_CDDETBCSTICMSST,
     MVI_CDDETBCICMSST,
     MVI_TPCALCULOICMSST,
     MVI_VBACREDECREICMSST,
     MVI_VLPMCICMSST,
     MVI_PEMVAICMSST,
     MVI_PEALIQINTERNAICMSST,
     MVI_PEREDUCAOICMSST,
     MVI_PEREDUCAONORMALICMSST,
     MVI_CDCSTIPI,
     MVI_PEALIQIPI,
     MVI_TPCONDTRIBIPI,
     MVI_VBGERABASESUPIPI,
     MVI_VBBCICMSIPI,
     MVI_VBSOBREPRECOTABIPI,
     MVI_VBREDBASEICMSIPI,
     MVI_VBGERACUSTOIPI,
     MVI_VBNAOCOMPOEPISCOF,
     MVI_VBNAOCUMULATIVOPISCOF,
     MVI_CDCSTPIS,
     MVI_VBGERACUSTOPIS,
     MVI_PEALIQPIS,
     MVI_TPCONDTRIBPIS,
     MVI_PEREDBASEPIS,
     MVI_PEPAUTADOPIS,
     MVI_CDCSTCOFINS,
     MVI_VBGERACUSTOCOFINS,
     MVI_PEALIQCOFINS,
     MVI_TPCONDTRIBCOFINS,
     MVI_PEREDBASECOFINS,
     MVI_PEPAUTADOCOFINS,
     MVI_CDCSTNATBASECREDPISCOF,
     MVI_TPINDNATFRETEPISCOF,
     MVI_CDINDNATFRETEPISCOF,
     MVI_DTINCLUSAO,
     MVI_USINCLUSAO,
     MVI_PEICMSUFDEST,
     MVI_PEICMSINTERPARTILHA,
     MVI_VLDEVOLUCAOICMSST,
     MVI_PEICMSINTERESTADUAL,
     MVI_VLBASEFCP,
     MVI_PEFECP,
     MVI_VLFECP,
     MVI_VLICMSUFDEST,
     MVI_VLICMSUFREMET,
     MVI_PEDIFERIMENTO,
     MVI_VLICMSOPERACAO,
     MVI_CDNCM,
     MVI_VBCALCIMPOSTONOVOICMS,
     MVI_VBCALCIMPOSTONOVOIPI,
     MVI_VBCALCIMPOSTONOVOPIS,
     MVI_VBCALCIMPOSTONOVOCOFINS,
     MVI_VBCALCIMPOSTONOVOICMSST,
     MVI_VLSTDEVIDONAENTRADA,
     MVI_VLBASEFCPST,
     MVI_PEFCPST,
     MVI_VLFCPST,
     MVI_VLICMSDESONERADO,
     MVI_CDMOTIVOICMSDESONERADO,
     MVI_VLBICMSNAOTRIBUTADO,
     MVI_PECREDITOPRESUMIDO,
     MVI_VLCREDITOPRESUMIDO,
     MVI_CDNOCONTAB,
     MVI_CDNOCCUSTO)
  VALUES
    (PMVI_IDIMPOSTO,
     PMVI_SQNOTA,
     PMVI_SQITEM,
     PMVI_PEICMS,
     PMVI_PEINCICMS,
     PMVI_TPCONDTRIBICMS,
     PMVI_CDPREFIXOCSTICMS,
     PMVI_CDCSTICMS,
     PMVI_CDDETBCSTICMS,
     PMVI_CDDETBCICMS,
     PMVI_CDCFOICMS,
     PMVI_VBGERABASESUPERIORICMS,
     PMVI_VBGERACUSTOICMS,
     PMVI_VBGERACIAPICMS,
     PMVI_CDCSTICMSST,
     PMVI_CDDETBCSTICMSST,
     PMVI_CDDETBCICMSST,
     PMVI_TPCALCULOICMSST,
     PMVI_VBACREDECREICMSST,
     PMVI_VLPMCICMSST,
     PMVI_PEMVAICMSST,
     PMVI_PEALIQINTERNAICMSST,
     PMVI_PEREDUCAOICMSST,
     PMVI_PEREDUCAONORMALICMSST,
     PMVI_CDCSTIPI,
     PMVI_PEALIQIPI,
     PMVI_TPCONDTRIBIPI,
     PMVI_VBGERABASESUPIPI,
     PMVI_VBBCICMSIPI,
     PMVI_VBSOBREPRECOTABIPI,
     PMVI_VBREDBASEICMSIPI,
     PMVI_VBGERACUSTOIPI,
     PMVI_VBNAOCOMPOEPISCOF,
     PMVI_VBNAOCUMULATIVOPISCOF,
     PMVI_CDCSTPIS,
     PMVI_VBGERACUSTOPIS,
     PMVI_PEALIQPIS,
     PMVI_TPCONDTRIBPIS,
     PMVI_PEREDBASEPIS,
     PMVI_PEPAUTADOPIS,
     PMVI_CDCSTCOFINS,
     PMVI_VBGERACUSTOCOFINS,
     PMVI_PEALIQCOFINS,
     PMVI_TPCONDTRIBCOFINS,
     PMVI_PEREDBASECOFINS,
     PMVI_PEPAUTADOCOFINS,
     PMVI_CDCSTNATBASECREDPISCOF,
     PMVI_TPINDNATFRETEPISCOF,
     PMVI_CDINDNATFRETEPISCOF,
     NVL(PMVI_DTINCLUSAO, SYSDATE),
     NVL(PMVI_USINCLUSAO, GET_USER_MXM),
     PMVI_PEICMSUFDEST,
     PMVI_PEICMSINTERPARTILHA,
     PMVI_VLDEVOLUCAOICMSST,
     PMVI_PEICMSINTERESTADUAL,
     PMVI_VLBASEFCP,
     PMVI_PEFECP,
     PMVI_VLFECP,
     PMVI_VLICMSUFDEST,
     PMVI_VLICMSUFREMET,
     PMVI_PEDIFERIMENTO,
     PMVI_VLICMSOPERACAO,
     PMVI_CDNCM,
     PMVI_VBCALCIMPOSTONOVOICMS,
     PMVI_VBCALCIMPOSTONOVOIPI,
     PMVI_VBCALCIMPOSTONOVOPIS,
     PMVI_VBCALCIMPOSTONOVOCOFINS,
     PMVI_VBCALCIMPOSTONOVOICMSST,
     PMVI_VLSTDEVIDONAENTRADA,
     PMVI_VLBASEFCPST,
     PMVI_PEFCPST,
     PMVI_VLFCPST,
     PMVI_VLICMSDESONERADO,
     PMVI_CDMOTIVOICMSDESONERADO,
     PMVI_VLBICMSNAOTRIBUTADO,
     PMVI_PECREDITOPRESUMIDO,
     PMVI_VLCREDITOPRESUMIDO,
     PMVI_CDNOCONTAB,
     PMVI_CDNOCCUSTO);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSGEITMOVIMPOSTO_MVI(PMVI_IDIMPOSTO               IN NUMBER,
                                                       PMVI_SQNOTA                  IN NUMBER,
                                                       PMVI_SQITEM                  IN NUMBER,
                                                       PMVI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                       PMVI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                       PMVI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                       PMVI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                       PMVI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                       PMVI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                       PMVI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                       PMVI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                       PMVI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                       PMVI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                       PMVI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                       PMVI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                       PMVI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                       PMVI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                       PMVI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                       PMVI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                       PMVI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                       PMVI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                       PMVI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PMVI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PMVI_DTINCLUSAO              IN DATE DEFAULT SYSDATE,
                                                       PMVI_USINCLUSAO              IN CHAR DEFAULT NULL,
                                                       PMVI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PMVI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                       PMVI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                       PMVI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                       PMVI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                       PMVI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                       PMVI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                       PMVI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                       PMVI_CDNCM                   IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                       PMVI_VLSTDEVIDONAENTRADA     IN NUMBER DEFAULT NULL,
                                                       PMVI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                       PMVI_VLFCPST                 IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSDESONERADO        IN NUMBER DEFAULT NULL,
                                                       PMVI_CDMOTIVOICMSDESONERADO  IN NUMBER DEFAULT NULL,
                                                       PMVI_VLBICMSNAOTRIBUTADO     IN NUMBER DEFAULT NULL,
                                                       PMVI_PECREDITOPRESUMIDO      IN NUMBER DEFAULT NULL,
                                                       PMVI_VLCREDITOPRESUMIDO      IN NUMBER DEFAULT NULL,
                                                       PMVI_CDNOCONTAB              IN CHAR DEFAULT NULL,
                                                       PMVI_CDNOCCUSTO              IN CHAR DEFAULT NULL) AS
BEGIN
  UPDATE SGEITMOVIMPOSTO_MVI
     SET MVI_SQNOTA                  = PMVI_SQNOTA,
         MVI_SQITEM                  = PMVI_SQITEM,
         MVI_PEICMS                  = PMVI_PEICMS,
         MVI_PEINCICMS               = PMVI_PEINCICMS,
         MVI_TPCONDTRIBICMS          = PMVI_TPCONDTRIBICMS,
         MVI_CDPREFIXOCSTICMS        = PMVI_CDPREFIXOCSTICMS,
         MVI_CDCSTICMS               = PMVI_CDCSTICMS,
         MVI_CDDETBCSTICMS           = PMVI_CDDETBCSTICMS,
         MVI_CDDETBCICMS             = PMVI_CDDETBCICMS,
         MVI_CDCFOICMS               = PMVI_CDCFOICMS,
         MVI_VBGERABASESUPERIORICMS  = PMVI_VBGERABASESUPERIORICMS,
         MVI_VBGERACUSTOICMS         = PMVI_VBGERACUSTOICMS,
         MVI_VBGERACIAPICMS          = PMVI_VBGERACIAPICMS,
         MVI_CDCSTICMSST             = PMVI_CDCSTICMSST,
         MVI_CDDETBCSTICMSST         = PMVI_CDDETBCSTICMSST,
         MVI_CDDETBCICMSST           = PMVI_CDDETBCICMSST,
         MVI_TPCALCULOICMSST         = PMVI_TPCALCULOICMSST,
         MVI_VBACREDECREICMSST       = PMVI_VBACREDECREICMSST,
         MVI_VLPMCICMSST             = PMVI_VLPMCICMSST,
         MVI_PEMVAICMSST             = PMVI_PEMVAICMSST,
         MVI_PEALIQINTERNAICMSST     = PMVI_PEALIQINTERNAICMSST,
         MVI_PEREDUCAOICMSST         = PMVI_PEREDUCAOICMSST,
         MVI_PEREDUCAONORMALICMSST   = PMVI_PEREDUCAONORMALICMSST,
         MVI_CDCSTIPI                = PMVI_CDCSTIPI,
         MVI_PEALIQIPI               = PMVI_PEALIQIPI,
         MVI_TPCONDTRIBIPI           = PMVI_TPCONDTRIBIPI,
         MVI_VBGERABASESUPIPI        = PMVI_VBGERABASESUPIPI,
         MVI_VBBCICMSIPI             = PMVI_VBBCICMSIPI,
         MVI_VBSOBREPRECOTABIPI      = PMVI_VBSOBREPRECOTABIPI,
         MVI_VBREDBASEICMSIPI        = PMVI_VBREDBASEICMSIPI,
         MVI_VBGERACUSTOIPI          = PMVI_VBGERACUSTOIPI,
         MVI_VBNAOCOMPOEPISCOF       = PMVI_VBNAOCOMPOEPISCOF,
         MVI_VBNAOCUMULATIVOPISCOF   = PMVI_VBNAOCUMULATIVOPISCOF,
         MVI_CDCSTPIS                = PMVI_CDCSTPIS,
         MVI_VBGERACUSTOPIS          = PMVI_VBGERACUSTOPIS,
         MVI_PEALIQPIS               = PMVI_PEALIQPIS,
         MVI_TPCONDTRIBPIS           = PMVI_TPCONDTRIBPIS,
         MVI_PEREDBASEPIS            = PMVI_PEREDBASEPIS,
         MVI_PEPAUTADOPIS            = PMVI_PEPAUTADOPIS,
         MVI_CDCSTCOFINS             = PMVI_CDCSTCOFINS,
         MVI_VBGERACUSTOCOFINS       = PMVI_VBGERACUSTOCOFINS,
         MVI_PEALIQCOFINS            = PMVI_PEALIQCOFINS,
         MVI_TPCONDTRIBCOFINS        = PMVI_TPCONDTRIBCOFINS,
         MVI_PEREDBASECOFINS         = PMVI_PEREDBASECOFINS,
         MVI_PEPAUTADOCOFINS         = PMVI_PEPAUTADOCOFINS,
         MVI_CDCSTNATBASECREDPISCOF  = PMVI_CDCSTNATBASECREDPISCOF,
         MVI_TPINDNATFRETEPISCOF     = PMVI_TPINDNATFRETEPISCOF,
         MVI_CDINDNATFRETEPISCOF     = PMVI_CDINDNATFRETEPISCOF,
         MVI_DTINCLUSAO              = NVL(PMVI_DTINCLUSAO, SYSDATE),
         MVI_USINCLUSAO              = NVL(PMVI_USINCLUSAO, GET_USER_MXM),
         MVI_PEICMSUFDEST            = PMVI_PEICMSUFDEST,
         MVI_PEICMSINTERPARTILHA     = PMVI_PEICMSINTERPARTILHA,
         MVI_VLDEVOLUCAOICMSST       = PMVI_VLDEVOLUCAOICMSST,
         MVI_PEICMSINTERESTADUAL     = PMVI_PEICMSINTERESTADUAL,
         MVI_VLBASEFCP               = PMVI_VLBASEFCP,
         MVI_PEFECP                  = PMVI_PEFECP,
         MVI_VLFECP                  = PMVI_VLFECP,
         MVI_VLICMSUFDEST            = PMVI_VLICMSUFDEST,
         MVI_VLICMSUFREMET           = PMVI_VLICMSUFREMET,
         MVI_CDNCM                   = PMVI_CDNCM,
         MVI_VBCALCIMPOSTONOVOICMS   = PMVI_VBCALCIMPOSTONOVOICMS,
         MVI_VBCALCIMPOSTONOVOIPI    = PMVI_VBCALCIMPOSTONOVOIPI,
         MVI_VBCALCIMPOSTONOVOPIS    = PMVI_VBCALCIMPOSTONOVOPIS,
         MVI_VBCALCIMPOSTONOVOCOFINS = PMVI_VBCALCIMPOSTONOVOCOFINS,
         MVI_VBCALCIMPOSTONOVOICMSST = PMVI_VBCALCIMPOSTONOVOICMSST,
         MVI_VLSTDEVIDONAENTRADA     = PMVI_VLSTDEVIDONAENTRADA,
         MVI_PEDIFERIMENTO           = PMVI_PEDIFERIMENTO,
         MVI_VLICMSOPERACAO          = PMVI_VLICMSOPERACAO,
         MVI_VLBASEFCPST             = PMVI_VLBASEFCPST,
         MVI_PEFCPST                 = PMVI_PEFCPST,
         MVI_VLFCPST                 = PMVI_VLFCPST,
         MVI_VLICMSDESONERADO        = PMVI_VLICMSDESONERADO,
         MVI_CDMOTIVOICMSDESONERADO  = PMVI_CDMOTIVOICMSDESONERADO,
         MVI_VLBICMSNAOTRIBUTADO     = PMVI_VLBICMSNAOTRIBUTADO,
         MVI_PECREDITOPRESUMIDO      = PMVI_PECREDITOPRESUMIDO,
         MVI_VLCREDITOPRESUMIDO      = PMVI_VLCREDITOPRESUMIDO,
         MVI_CDNOCONTAB              = PMVI_CDNOCONTAB,
         MVI_CDNOCCUSTO              = PMVI_CDNOCCUSTO
   WHERE MVI_IDIMPOSTO = PMVI_IDIMPOSTO;
END;
/

ALTER TABLE SCOITPEDCOMPIMPOSTO_IPB ADD IPB_CDNOCONTAB VARCHAR2(15) DEFAULT NULL
/

ALTER TABLE SCOITPEDCOMPIMPOSTO_IPB ADD IPB_CDNOCCUSTO VARCHAR2(15) DEFAULT NULL
/

COMMENT ON COLUMN SCOITPEDCOMPIMPOSTO_IPB .IPB_CDNOCCUSTO IS 'CENTRO DE CUSTO DO ITEM'
/

COMMENT ON COLUMN SCOITPEDCOMPIMPOSTO_IPB .IPB_CDNOCONTAB IS 'CONTA CONT�BIL DO ITEM'
/

CREATE OR REPLACE PROCEDURE PRC_INSSCOITPEDCOMPIMPOSTO_IPB
(
  PIPB_IDIMPOSTO               IN OUT NUMBER,
  PIPB_CDEMPRESA               IN CHAR,
  PIPB_CDATENDIMENTO           IN CHAR,
  PIPB_NRITEM                  IN NUMBER,
  PIPB_CDREQUISIC              IN CHAR,
  PIPB_CDNOTITULO              IN CHAR,
  PIPB_PEICMS                  IN NUMBER DEFAULT NULL,
  PIPB_PEINCICMS               IN NUMBER DEFAULT NULL,
  PIPB_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
  PIPB_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
  PIPB_CDCSTICMS               IN CHAR DEFAULT NULL,
  PIPB_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
  PIPB_CDDETBCICMS             IN CHAR DEFAULT NULL,
  PIPB_CDCFOICMS               IN CHAR DEFAULT NULL,
  PIPB_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
  PIPB_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
  PIPB_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
  PIPB_CDCSTICMSST             IN CHAR DEFAULT NULL,
  PIPB_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
  PIPB_CDDETBCICMSST           IN CHAR DEFAULT NULL,
  PIPB_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
  PIPB_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
  PIPB_VLPMCICMSST             IN NUMBER DEFAULT NULL,
  PIPB_PEMVAICMSST             IN NUMBER DEFAULT NULL,
  PIPB_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
  PIPB_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
  PIPB_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
  PIPB_CDCSTIPI                IN CHAR DEFAULT NULL,
  PIPB_PEALIQIPI               IN NUMBER DEFAULT NULL,
  PIPB_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
  PIPB_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
  PIPB_VBBCICMSIPI             IN CHAR DEFAULT NULL,
  PIPB_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
  PIPB_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
  PIPB_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
  PIPB_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
  PIPB_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
  PIPB_CDCSTPIS                IN CHAR DEFAULT NULL,
  PIPB_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
  PIPB_PEALIQPIS               IN NUMBER DEFAULT NULL,
  PIPB_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
  PIPB_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
  PIPB_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
  PIPB_CDCSTCOFINS             IN CHAR DEFAULT NULL,
  PIPB_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
  PIPB_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
  PIPB_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
  PIPB_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
  PIPB_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
  PIPB_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
  PIPB_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
  PIPB_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
  PIPB_PEALIQINTERNAICMSDEST   IN NUMBER DEFAULT NULL,
  PIPB_PEPARTILHAENTREESTADOS  IN NUMBER DEFAULT NULL,
  PIPB_PEFECP                  IN NUMBER DEFAULT NULL,
  PIPB_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
  PIPB_VLBCICMS                IN NUMBER DEFAULT NULL,
  PIPB_VLICMS                  IN NUMBER DEFAULT NULL,
  PIPB_VLBASEISENTAICMS        IN NUMBER DEFAULT NULL,
  PIPB_VLBASEOUTRASICMS        IN NUMBER DEFAULT NULL,
  PIPB_VLREDBCICMS             IN NUMBER DEFAULT NULL,
  PIPB_VLDIFERENCIALALIQICMS   IN NUMBER DEFAULT NULL,
  PIPB_VLICMSDIFERIDO          IN NUMBER DEFAULT NULL,
  PIPB_VLICMSNAOCREDITADO      IN NUMBER DEFAULT NULL,
  PIPB_VLBCICMSST              IN NUMBER DEFAULT NULL,
  PIPB_VLICMSST                IN NUMBER DEFAULT NULL,
  PIPB_VLICMSSTNAOCREDITADO    IN NUMBER DEFAULT NULL,
  PIPB_VLBCIPI                 IN NUMBER DEFAULT NULL,
  PIPB_VLIPI                   IN NUMBER DEFAULT NULL,
  PIPB_VLBASEISENTAIPI         IN NUMBER DEFAULT NULL,
  PIPB_VLBASEOUTRASIPI         IN NUMBER DEFAULT NULL,
  PIPB_VLIPINAOCREDITADO       IN NUMBER DEFAULT NULL,
  PIPB_VLBCPIS                 IN NUMBER DEFAULT NULL,
  PIPB_VLPIS                   IN NUMBER DEFAULT NULL,
  PIPB_VLPISNAOCREDITADO       IN NUMBER DEFAULT NULL,
  PIPB_VLBCCOFINS              IN NUMBER DEFAULT NULL,
  PIPB_VLCOFINS                IN NUMBER DEFAULT NULL,
  PIPB_VLCOFINSNAOCREDITADO    IN NUMBER DEFAULT NULL,
  PIPB_VLBCII                  IN NUMBER DEFAULT NULL,
  PIPB_PEALIQUOTAII            IN NUMBER DEFAULT NULL,
  PIPB_VLII                    IN NUMBER DEFAULT NULL,
  PIPB_VLDESCONTO              IN NUMBER DEFAULT NULL,
  PIPB_VLBCISS                 IN NUMBER DEFAULT NULL,
  PIPB_PEALIQISS               IN NUMBER DEFAULT NULL,
  PIPB_VLISS                   IN NUMBER DEFAULT NULL,
  PIPB_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
  PIPB_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
  PIPB_CDNCM                   IN CHAR DEFAULT NULL,
  PIPB_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
  PIPB_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
  PIPB_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
  PIPB_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
  PIPB_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
  PIPB_CDNOCONTAB IN CHAR DEFAULT NULL,
  PIPB_CDNOCCUSTO IN CHAR DEFAULT NULL
) AS
BEGIN
  IF PIPB_IDIMPOSTO IS NULL THEN
    SELECT SEQ1_SCOITPEDCOMPIMPOSTO_IPB.NEXTVAL
      INTO PIPB_IDIMPOSTO
      FROM DUAL;
  END IF;
  INSERT INTO SCOITPEDCOMPIMPOSTO_IPB
    (IPB_IDIMPOSTO,
     IPB_CDEMPRESA,
     IPB_CDATENDIMENTO,
     IPB_NRITEM,
     IPB_CDREQUISIC,
     IPB_CDNOTITULO,
     IPB_PEICMS,
     IPB_PEINCICMS,
     IPB_TPCONDTRIBICMS,
     IPB_CDPREFIXOCSTICMS,
     IPB_CDCSTICMS,
     IPB_CDDETBCSTICMS,
     IPB_CDDETBCICMS,
     IPB_CDCFOICMS,
     IPB_VBGERABASESUPERIORICMS,
     IPB_VBGERACUSTOICMS,
     IPB_VBGERACIAPICMS,
     IPB_CDCSTICMSST,
     IPB_CDDETBCSTICMSST,
     IPB_CDDETBCICMSST,
     IPB_TPCALCULOICMSST,
     IPB_VBACREDECREICMSST,
     IPB_VLPMCICMSST,
     IPB_PEMVAICMSST,
     IPB_PEALIQINTERNAICMSST,
     IPB_PEREDUCAOICMSST,
     IPB_PEREDUCAONORMALICMSST,
     IPB_CDCSTIPI,
     IPB_PEALIQIPI,
     IPB_TPCONDTRIBIPI,
     IPB_VBGERABASESUPIPI,
     IPB_VBBCICMSIPI,
     IPB_VBSOBREPRECOTABIPI,
     IPB_VBREDBASEICMSIPI,
     IPB_VBGERACUSTOIPI,
     IPB_VBNAOCOMPOEPISCOF,
     IPB_VBNAOCUMULATIVOPISCOF,
     IPB_CDCSTPIS,
     IPB_VBGERACUSTOPIS,
     IPB_PEALIQPIS,
     IPB_TPCONDTRIBPIS,
     IPB_PEREDBASEPIS,
     IPB_PEPAUTADOPIS,
     IPB_CDCSTCOFINS,
     IPB_VBGERACUSTOCOFINS,
     IPB_PEALIQCOFINS,
     IPB_TPCONDTRIBCOFINS,
     IPB_PEREDBASECOFINS,
     IPB_PEPAUTADOCOFINS,
     IPB_CDCSTNATBASECREDPISCOF,
     IPB_TPINDNATFRETEPISCOF,
     IPB_CDINDNATFRETEPISCOF,
     IPB_DTINCLUSAO,
     IPB_USINCLUSAO,
     IPB_PEALIQINTERNAICMSDEST,
     IPB_PEPARTILHAENTREESTADOS,
     IPB_PEFECP,
     IPB_VLDEVOLUCAOICMSST,
     IPB_VLBCICMS,
     IPB_VLICMS,
     IPB_VLBASEISENTAICMS,
     IPB_VLBASEOUTRASICMS,
     IPB_VLREDBCICMS,
     IPB_VLDIFERENCIALALIQICMS,
     IPB_VLICMSDIFERIDO,
     IPB_VLICMSNAOCREDITADO,
     IPB_VLBCICMSST,
     IPB_VLICMSST,
     IPB_VLICMSSTNAOCREDITADO,
     IPB_VLBCIPI,
     IPB_VLIPI,
     IPB_VLBASEISENTAIPI,
     IPB_VLBASEOUTRASIPI,
     IPB_VLIPINAOCREDITADO,
     IPB_VLBCPIS,
     IPB_VLPIS,
     IPB_VLPISNAOCREDITADO,
     IPB_VLBCCOFINS,
     IPB_VLCOFINS,
     IPB_VLCOFINSNAOCREDITADO,
     IPB_VLBCII,
     IPB_PEALIQUOTAII,
     IPB_VLII,
     IPB_VLDESCONTO,
     IPB_VLBCISS,
     IPB_PEALIQISS,
     IPB_VLISS,
     IPB_PEDIFERIMENTO,
     IPB_VLICMSOPERACAO,
     IPB_CDNCM,
     IPB_VBCALCIMPOSTONOVOICMS,
     IPB_VBCALCIMPOSTONOVOIPI,
     IPB_VBCALCIMPOSTONOVOPIS,
     IPB_VBCALCIMPOSTONOVOCOFINS,
     IPB_VBCALCIMPOSTONOVOICMSST, 
     IPB_CDNOCONTAB,
     IPB_CDNOCCUSTO)
  VALUES
    (PIPB_IDIMPOSTO,
     PIPB_CDEMPRESA,
     PIPB_CDATENDIMENTO,
     PIPB_NRITEM,
     PIPB_CDREQUISIC,
     PIPB_CDNOTITULO,
     PIPB_PEICMS,
     PIPB_PEINCICMS,
     PIPB_TPCONDTRIBICMS,
     PIPB_CDPREFIXOCSTICMS,
     PIPB_CDCSTICMS,
     PIPB_CDDETBCSTICMS,
     PIPB_CDDETBCICMS,
     PIPB_CDCFOICMS,
     PIPB_VBGERABASESUPERIORICMS,
     PIPB_VBGERACUSTOICMS,
     PIPB_VBGERACIAPICMS,
     PIPB_CDCSTICMSST,
     PIPB_CDDETBCSTICMSST,
     PIPB_CDDETBCICMSST,
     PIPB_TPCALCULOICMSST,
     PIPB_VBACREDECREICMSST,
     PIPB_VLPMCICMSST,
     PIPB_PEMVAICMSST,
     PIPB_PEALIQINTERNAICMSST,
     PIPB_PEREDUCAOICMSST,
     PIPB_PEREDUCAONORMALICMSST,
     PIPB_CDCSTIPI,
     PIPB_PEALIQIPI,
     PIPB_TPCONDTRIBIPI,
     PIPB_VBGERABASESUPIPI,
     PIPB_VBBCICMSIPI,
     PIPB_VBSOBREPRECOTABIPI,
     PIPB_VBREDBASEICMSIPI,
     PIPB_VBGERACUSTOIPI,
     PIPB_VBNAOCOMPOEPISCOF,
     PIPB_VBNAOCUMULATIVOPISCOF,
     PIPB_CDCSTPIS,
     PIPB_VBGERACUSTOPIS,
     PIPB_PEALIQPIS,
     PIPB_TPCONDTRIBPIS,
     PIPB_PEREDBASEPIS,
     PIPB_PEPAUTADOPIS,
     PIPB_CDCSTCOFINS,
     PIPB_VBGERACUSTOCOFINS,
     PIPB_PEALIQCOFINS,
     PIPB_TPCONDTRIBCOFINS,
     PIPB_PEREDBASECOFINS,
     PIPB_PEPAUTADOCOFINS,
     PIPB_CDCSTNATBASECREDPISCOF,
     PIPB_TPINDNATFRETEPISCOF,
     PIPB_CDINDNATFRETEPISCOF,
     SYSDATE,
     GET_USER_MXM,
     PIPB_PEALIQINTERNAICMSDEST,
     PIPB_PEPARTILHAENTREESTADOS,
     PIPB_PEFECP,
     PIPB_VLDEVOLUCAOICMSST,
     PIPB_VLBCICMS,
     PIPB_VLICMS,
     PIPB_VLBASEISENTAICMS,
     PIPB_VLBASEOUTRASICMS,
     PIPB_VLREDBCICMS,
     PIPB_VLDIFERENCIALALIQICMS,
     PIPB_VLICMSDIFERIDO,
     PIPB_VLICMSNAOCREDITADO,
     PIPB_VLBCICMSST,
     PIPB_VLICMSST,
     PIPB_VLICMSSTNAOCREDITADO,
     PIPB_VLBCIPI,
     PIPB_VLIPI,
     PIPB_VLBASEISENTAIPI,
     PIPB_VLBASEOUTRASIPI,
     PIPB_VLIPINAOCREDITADO,
     PIPB_VLBCPIS,
     PIPB_VLPIS,
     PIPB_VLPISNAOCREDITADO,
     PIPB_VLBCCOFINS,
     PIPB_VLCOFINS,
     PIPB_VLCOFINSNAOCREDITADO,
     PIPB_VLBCII,
     PIPB_PEALIQUOTAII,
     PIPB_VLII,
     PIPB_VLDESCONTO,
     PIPB_VLBCISS,
     PIPB_PEALIQISS,
     PIPB_VLISS,
     PIPB_PEDIFERIMENTO,
     PIPB_VLICMSOPERACAO,
     PIPB_CDNCM,
     PIPB_VBCALCIMPOSTONOVOICMS,
     PIPB_VBCALCIMPOSTONOVOIPI,
     PIPB_VBCALCIMPOSTONOVOPIS,
     PIPB_VBCALCIMPOSTONOVOCOFINS,
     PIPB_VBCALCIMPOSTONOVOICMSST,
     PIPB_CDNOCONTAB,
     PIPB_CDNOCCUSTO);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSCOITPEDCOMPIMPOSTO_IPB
(
  PIPB_IDIMPOSTO               IN NUMBER,
  PIPB_CDEMPRESA               IN CHAR,
  PIPB_CDATENDIMENTO           IN CHAR,
  PIPB_NRITEM                  IN NUMBER,
  PIPB_CDREQUISIC              IN CHAR,
  PIPB_CDNOTITULO              IN CHAR,
  PIPB_PEICMS                  IN NUMBER DEFAULT NULL,
  PIPB_PEINCICMS               IN NUMBER DEFAULT NULL,
  PIPB_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
  PIPB_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
  PIPB_CDCSTICMS               IN CHAR DEFAULT NULL,
  PIPB_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
  PIPB_CDDETBCICMS             IN CHAR DEFAULT NULL,
  PIPB_CDCFOICMS               IN CHAR DEFAULT NULL,
  PIPB_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
  PIPB_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
  PIPB_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
  PIPB_CDCSTICMSST             IN CHAR DEFAULT NULL,
  PIPB_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
  PIPB_CDDETBCICMSST           IN CHAR DEFAULT NULL,
  PIPB_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
  PIPB_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
  PIPB_VLPMCICMSST             IN NUMBER DEFAULT NULL,
  PIPB_PEMVAICMSST             IN NUMBER DEFAULT NULL,
  PIPB_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
  PIPB_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
  PIPB_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
  PIPB_CDCSTIPI                IN CHAR DEFAULT NULL,
  PIPB_PEALIQIPI               IN NUMBER DEFAULT NULL,
  PIPB_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
  PIPB_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
  PIPB_VBBCICMSIPI             IN CHAR DEFAULT NULL,
  PIPB_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
  PIPB_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
  PIPB_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
  PIPB_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
  PIPB_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
  PIPB_CDCSTPIS                IN CHAR DEFAULT NULL,
  PIPB_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
  PIPB_PEALIQPIS               IN NUMBER DEFAULT NULL,
  PIPB_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
  PIPB_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
  PIPB_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
  PIPB_CDCSTCOFINS             IN CHAR DEFAULT NULL,
  PIPB_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
  PIPB_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
  PIPB_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
  PIPB_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
  PIPB_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
  PIPB_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
  PIPB_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
  PIPB_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
  PIPB_PEALIQINTERNAICMSDEST   IN NUMBER DEFAULT NULL,
  PIPB_PEPARTILHAENTREESTADOS  IN NUMBER DEFAULT NULL,
  PIPB_PEFECP                  IN NUMBER DEFAULT NULL,
  PIPB_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
  PIPB_VLBCICMS                IN NUMBER DEFAULT NULL,
  PIPB_VLICMS                  IN NUMBER DEFAULT NULL,
  PIPB_VLBASEISENTAICMS        IN NUMBER DEFAULT NULL,
  PIPB_VLBASEOUTRASICMS        IN NUMBER DEFAULT NULL,
  PIPB_VLREDBCICMS             IN NUMBER DEFAULT NULL,
  PIPB_VLDIFERENCIALALIQICMS   IN NUMBER DEFAULT NULL,
  PIPB_VLICMSDIFERIDO          IN NUMBER DEFAULT NULL,
  PIPB_VLICMSNAOCREDITADO      IN NUMBER DEFAULT NULL,
  PIPB_VLBCICMSST              IN NUMBER DEFAULT NULL,
  PIPB_VLICMSST                IN NUMBER DEFAULT NULL,
  PIPB_VLICMSSTNAOCREDITADO    IN NUMBER DEFAULT NULL,
  PIPB_VLBCIPI                 IN NUMBER DEFAULT NULL,
  PIPB_VLIPI                   IN NUMBER DEFAULT NULL,
  PIPB_VLBASEISENTAIPI         IN NUMBER DEFAULT NULL,
  PIPB_VLBASEOUTRASIPI         IN NUMBER DEFAULT NULL,
  PIPB_VLIPINAOCREDITADO       IN NUMBER DEFAULT NULL,
  PIPB_VLBCPIS                 IN NUMBER DEFAULT NULL,
  PIPB_VLPIS                   IN NUMBER DEFAULT NULL,
  PIPB_VLPISNAOCREDITADO       IN NUMBER DEFAULT NULL,
  PIPB_VLBCCOFINS              IN NUMBER DEFAULT NULL,
  PIPB_VLCOFINS                IN NUMBER DEFAULT NULL,
  PIPB_VLCOFINSNAOCREDITADO    IN NUMBER DEFAULT NULL,
  PIPB_VLBCII                  IN NUMBER DEFAULT NULL,
  PIPB_PEALIQUOTAII            IN NUMBER DEFAULT NULL,
  PIPB_VLII                    IN NUMBER DEFAULT NULL,
  PIPB_VLDESCONTO              IN NUMBER DEFAULT NULL,
  PIPB_VLBCISS                 IN NUMBER DEFAULT NULL,
  PIPB_PEALIQISS               IN NUMBER DEFAULT NULL,
  PIPB_VLISS                   IN NUMBER DEFAULT NULL,
  PIPB_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
  PIPB_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
  PIPB_CDNCM                   IN CHAR DEFAULT NULL,
  PIPB_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
  PIPB_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
  PIPB_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
  PIPB_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
  PIPB_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
  PIPB_CDNOCONTAB IN CHAR DEFAULT NULL,
  PIPB_CDNOCCUSTO IN CHAR DEFAULT NULL 
) AS
BEGIN
  UPDATE SCOITPEDCOMPIMPOSTO_IPB
     SET IPB_IDIMPOSTO               = PIPB_IDIMPOSTO,
         IPB_CDEMPRESA               = PIPB_CDEMPRESA,
         IPB_CDATENDIMENTO           = PIPB_CDATENDIMENTO,
         IPB_NRITEM                  = PIPB_NRITEM,
         IPB_CDREQUISIC              = PIPB_CDREQUISIC,
         IPB_CDNOTITULO              = PIPB_CDNOTITULO,
         IPB_PEICMS                  = PIPB_PEICMS,
         IPB_PEINCICMS               = PIPB_PEINCICMS,
         IPB_TPCONDTRIBICMS          = PIPB_TPCONDTRIBICMS,
         IPB_CDPREFIXOCSTICMS        = PIPB_CDPREFIXOCSTICMS,
         IPB_CDCSTICMS               = PIPB_CDCSTICMS,
         IPB_CDDETBCSTICMS           = PIPB_CDDETBCSTICMS,
         IPB_CDDETBCICMS             = PIPB_CDDETBCICMS,
         IPB_CDCFOICMS               = PIPB_CDCFOICMS,
         IPB_VBGERABASESUPERIORICMS  = PIPB_VBGERABASESUPERIORICMS,
         IPB_VBGERACUSTOICMS         = PIPB_VBGERACUSTOICMS,
         IPB_VBGERACIAPICMS          = PIPB_VBGERACIAPICMS,
         IPB_CDCSTICMSST             = PIPB_CDCSTICMSST,
         IPB_CDDETBCSTICMSST         = PIPB_CDDETBCSTICMSST,
         IPB_CDDETBCICMSST           = PIPB_CDDETBCICMSST,
         IPB_TPCALCULOICMSST         = PIPB_TPCALCULOICMSST,
         IPB_VBACREDECREICMSST       = PIPB_VBACREDECREICMSST,
         IPB_VLPMCICMSST             = PIPB_VLPMCICMSST,
         IPB_PEMVAICMSST             = PIPB_PEMVAICMSST,
         IPB_PEALIQINTERNAICMSST     = PIPB_PEALIQINTERNAICMSST,
         IPB_PEREDUCAOICMSST         = PIPB_PEREDUCAOICMSST,
         IPB_PEREDUCAONORMALICMSST   = PIPB_PEREDUCAONORMALICMSST,
         IPB_CDCSTIPI                = PIPB_CDCSTIPI,
         IPB_PEALIQIPI               = PIPB_PEALIQIPI,
         IPB_TPCONDTRIBIPI           = PIPB_TPCONDTRIBIPI,
         IPB_VBGERABASESUPIPI        = PIPB_VBGERABASESUPIPI,
         IPB_VBBCICMSIPI             = PIPB_VBBCICMSIPI,
         IPB_VBSOBREPRECOTABIPI      = PIPB_VBSOBREPRECOTABIPI,
         IPB_VBREDBASEICMSIPI        = PIPB_VBREDBASEICMSIPI,
         IPB_VBGERACUSTOIPI          = PIPB_VBGERACUSTOIPI,
         IPB_VBNAOCOMPOEPISCOF       = PIPB_VBNAOCOMPOEPISCOF,
         IPB_VBNAOCUMULATIVOPISCOF   = PIPB_VBNAOCUMULATIVOPISCOF,
         IPB_CDCSTPIS                = PIPB_CDCSTPIS,
         IPB_VBGERACUSTOPIS          = PIPB_VBGERACUSTOPIS,
         IPB_PEALIQPIS               = PIPB_PEALIQPIS,
         IPB_TPCONDTRIBPIS           = PIPB_TPCONDTRIBPIS,
         IPB_PEREDBASEPIS            = PIPB_PEREDBASEPIS,
         IPB_PEPAUTADOPIS            = PIPB_PEPAUTADOPIS,
         IPB_CDCSTCOFINS             = PIPB_CDCSTCOFINS,
         IPB_VBGERACUSTOCOFINS       = PIPB_VBGERACUSTOCOFINS,
         IPB_PEALIQCOFINS            = PIPB_PEALIQCOFINS,
         IPB_TPCONDTRIBCOFINS        = PIPB_TPCONDTRIBCOFINS,
         IPB_PEREDBASECOFINS         = PIPB_PEREDBASECOFINS,
         IPB_PEPAUTADOCOFINS         = PIPB_PEPAUTADOCOFINS,
         IPB_CDCSTNATBASECREDPISCOF  = PIPB_CDCSTNATBASECREDPISCOF,
         IPB_TPINDNATFRETEPISCOF     = PIPB_TPINDNATFRETEPISCOF,
         IPB_CDINDNATFRETEPISCOF     = PIPB_CDINDNATFRETEPISCOF,
         IPB_DTALTERACAO             = SYSDATE,
         IPB_USALTERACAO             = GET_USER_MXM,
         IPB_PEALIQINTERNAICMSDEST   = PIPB_PEALIQINTERNAICMSDEST,
         IPB_PEPARTILHAENTREESTADOS  = PIPB_PEPARTILHAENTREESTADOS,
         IPB_PEFECP                  = PIPB_PEFECP,
         IPB_VLDEVOLUCAOICMSST       = PIPB_VLDEVOLUCAOICMSST,
         IPB_VLBCICMS                = PIPB_VLBCICMS,
         IPB_VLICMS                  = PIPB_VLICMS,
         IPB_VLBASEISENTAICMS        = PIPB_VLBASEISENTAICMS,
         IPB_VLBASEOUTRASICMS        = PIPB_VLBASEOUTRASICMS,
         IPB_VLREDBCICMS             = PIPB_VLREDBCICMS,
         IPB_VLDIFERENCIALALIQICMS   = PIPB_VLDIFERENCIALALIQICMS,
         IPB_VLICMSDIFERIDO          = PIPB_VLICMSDIFERIDO,
         IPB_VLICMSNAOCREDITADO      = PIPB_VLICMSNAOCREDITADO,
         IPB_VLBCICMSST              = PIPB_VLBCICMSST,
         IPB_VLICMSST                = PIPB_VLICMSST,
         IPB_VLICMSSTNAOCREDITADO    = PIPB_VLICMSSTNAOCREDITADO,
         IPB_VLBCIPI                 = PIPB_VLBCIPI,
         IPB_VLIPI                   = PIPB_VLIPI,
         IPB_VLBASEISENTAIPI         = PIPB_VLBASEISENTAIPI,
         IPB_VLBASEOUTRASIPI         = PIPB_VLBASEOUTRASIPI,
         IPB_VLIPINAOCREDITADO       = PIPB_VLIPINAOCREDITADO,
         IPB_VLBCPIS                 = PIPB_VLBCPIS,
         IPB_VLPIS                   = PIPB_VLPIS,
         IPB_VLPISNAOCREDITADO       = PIPB_VLPISNAOCREDITADO,
         IPB_VLBCCOFINS              = PIPB_VLBCCOFINS,
         IPB_VLCOFINS                = PIPB_VLCOFINS,
         IPB_VLCOFINSNAOCREDITADO    = PIPB_VLCOFINSNAOCREDITADO,
         IPB_VLBCII                  = PIPB_VLBCII,
         IPB_PEALIQUOTAII            = PIPB_PEALIQUOTAII,
         IPB_VLII                    = PIPB_VLII,
         IPB_VLDESCONTO              = PIPB_VLDESCONTO,
         IPB_VLBCISS                 = PIPB_VLBCISS,
         IPB_PEALIQISS               = PIPB_PEALIQISS,
         IPB_VLISS                   = PIPB_VLISS,
         IPB_PEDIFERIMENTO           = PIPB_PEDIFERIMENTO,
         IPB_VLICMSOPERACAO          = PIPB_VLICMSOPERACAO,
         IPB_CDNCM                   = PIPB_CDNCM,
         IPB_VBCALCIMPOSTONOVOICMS   = PIPB_VBCALCIMPOSTONOVOICMS,
         IPB_VBCALCIMPOSTONOVOIPI    = PIPB_VBCALCIMPOSTONOVOIPI,
         IPB_VBCALCIMPOSTONOVOPIS    = PIPB_VBCALCIMPOSTONOVOPIS,
         IPB_VBCALCIMPOSTONOVOCOFINS = PIPB_VBCALCIMPOSTONOVOCOFINS,
         IPB_VBCALCIMPOSTONOVOICMSST = PIPB_VBCALCIMPOSTONOVOICMSST,
         IPB_CDNOCONTAB = PIPB_CDNOCONTAB,
         IPB_CDNOCCUSTO = PIPB_CDNOCCUSTO
   WHERE IPB_IDIMPOSTO = PIPB_IDIMPOSTO;
END;
/

ALTER TABLE SPEDITDOCFIS_IDF ADD IDF_VLICMSDESONERADO NUMBER(15,2)
/

ALTER TABLE SPEDITDOCFIS_IDF ADD IDF_CDMOTIVOICMSDESONERADO NUMBER(2)
/

ALTER TABLE SPEDITDOCFIS_IDF ADD IDF_PECREDITOPRESUMIDO     NUMBER(15,2)
/

ALTER TABLE SPEDITDOCFIS_IDF ADD IDF_VLCREDITOPRESUMIDO     NUMBER(15,2)
/

comment on column SPEDITDOCFIS_IDF.IDF_VLICMSDESONERADO  is 'Valor do ICMS Desonerado'
/

comment on column SPEDITDOCFIS_IDF.IDF_CDMOTIVOICMSDESONERADO is 'C�digo do motivo do ICMS Desonerado'
/

comment on column SPEDITDOCFIS_IDF.IDF_PECREDITOPRESUMIDO is 'Percentual Cr�dito Presumido ICMS da opera��o anterior que ir� incidir no ST'
/

comment on column SPEDITDOCFIS_IDF.IDF_VLCREDITOPRESUMIDO is 'Valor Cr�dito Presumido ICMS da opera��o anterior que ir� incidir no ST'
/

ALTER TABLE SPEDITDOCFIS_IDF ADD IDF_VBCTAPORPROC NUMBER(1) DEFAULT 0
/

COMMENT ON COLUMN SPEDITDOCFIS_IDF.IDF_VBCTAPORPROC IS 'Indica se a informa��o da conta cont�bil foi preenchida por processamento - 0 = N�o 1 = Sim'
/

ALTER TABLE SPEDITDOCFISSERV_IDFS ADD IDFS_VBCTAPORPROC NUMBER(1) DEFAULT 0
/

COMMENT ON COLUMN SPEDITDOCFISSERV_IDFS.IDFS_VBCTAPORPROC IS 'Indica se a informa��o da conta cont�bil foi preenchida por processamento - 0 = N�o 1 = Sim'
/

ALTER TABLE SPEDDOCFIS_SDF ADD SDF_VBCTAPORPROC NUMBER(1) DEFAULT 0
/

COMMENT ON COLUMN SPEDDOCFIS_SDF.SDF_VBCTAPORPROC IS 'Indica se a informa��o da conta cont�bil foi preenchida por processamento - 0 = N�o 1 = Sim'
/

ALTER TABLE SPEDDOCGERACRD_SDGC ADD SDGC_VBCTAPORPROC NUMBER(1) DEFAULT 0
/

COMMENT ON COLUMN SPEDDOCGERACRD_SDGC.SDGC_VBCTAPORPROC IS 'Indica se a informa��o da conta cont�bil foi preenchida por processamento - 0 = N�o 1 = Sim'
/

CREATE OR REPLACE PROCEDURE INSSPEDITDOCFIS_IDF(PIDF_SQITDOCFIS               IN OUT NUMBER,
                                                PIDF_SQDOCFIS                 IN NUMBER,
                                                PIDF_NUMSEQ                   IN NUMBER,
                                                PIDF_ITEM                     IN CHAR,
                                                PIDF_QUANTIDADE               IN NUMBER,
                                                PIDF_UNIDADE                  IN CHAR,
                                                PIDF_VLITEM                   IN NUMBER,
                                                PIDF_VLDESC                   IN NUMBER,
                                                PIDF_MOVFIS                   IN NUMBER,
                                                PIDF_ORIGEM                   IN NUMBER,
                                                PIDF_CSTICMS                  IN CHAR,
                                                PIDF_CFOP                     IN CHAR,
                                                PIDF_VLBCICMS                 IN NUMBER,
                                                PIDF_ALIQICMS                 IN NUMBER,
                                                PIDF_VLICMS                   IN NUMBER,
                                                PIDF_VLBCICMSST               IN NUMBER,
                                                PIDF_ALIQICMSST               IN NUMBER,
                                                PIDF_VLICMSST                 IN NUMBER,
                                                PIDF_STNAOCREDITADO           IN NUMBER,
                                                PIDF_VLREDBC                  IN NUMBER,
                                                PIDF_CSTIPI                   IN CHAR,
                                                PIDF_CODENQ                   IN CHAR,
                                                PIDF_VLBCIPI                  IN NUMBER,
                                                PIDF_ALIQIPI                  IN NUMBER,
                                                PIDF_VLIPI                    IN NUMBER,
                                                PIDF_CSTPIS                   IN CHAR,
                                                PIDF_VLBCPIS                  IN NUMBER DEFAULT 0,
                                                PIDF_ALIQPIS                  IN NUMBER DEFAULT 0,
                                                PIDF_QTDBCPIS                 IN NUMBER DEFAULT 0,
                                                PIDF_ALIQPISR                 IN NUMBER DEFAULT 0,
                                                PIDF_VLPIS                    IN NUMBER DEFAULT 0,
                                                PIDF_VLBCPISRET               IN NUMBER,
                                                PIDF_ALIQPISRET               IN NUMBER,
                                                PIDF_VLPISRET                 IN NUMBER,
                                                PIDF_CSTCOFINS                IN CHAR,
                                                PIDF_VLBCCOFINS               IN NUMBER DEFAULT 0,
                                                PIDF_ALIQCOFINS               IN NUMBER DEFAULT 0,
                                                PIDF_QTDBCCOFINS              IN NUMBER DEFAULT 0,
                                                PIDF_ALIQCOFINSR              IN NUMBER DEFAULT 0,
                                                PIDF_VLCOFINS                 IN NUMBER DEFAULT 0,
                                                PIDF_VLBCCOFINSRET            IN NUMBER,
                                                PIDF_ALIQCOFINSRET            IN NUMBER,
                                                PIDF_VLCOFINSRET              IN NUMBER,
                                                PIDF_CLASSE                   IN CHAR,
                                                PIDF_INDREC                   IN NUMBER,
                                                PIDF_CLIFOR                   IN CHAR,
                                                PIDF_CDCLIENTE                IN CHAR,
                                                PIDF_CDFOR                    IN CHAR,
                                                PIDF_VLSERV                   IN NUMBER,
                                                PIDF_VLOUTDESP                IN NUMBER,
                                                PIDF_VLUNTITEM                IN NUMBER,
                                                PIDF_NOCONTAB                 IN CHAR,
                                                PIDF_INDAPURIPI               IN NUMBER,
                                                PIDF_IPINAOCRED               IN NUMBER,
                                                PIDF_TPOP                     IN CHAR,
                                                PIDF_VLBIICMS                 IN NUMBER,
                                                PIDF_VLBOICMS                 IN NUMBER,
                                                PIDF_VLBIIPI                  IN NUMBER,
                                                PIDF_VLBOIPI                  IN NUMBER,
                                                PIDF_CODMUNORI                IN CHAR,
                                                PIDF_CODMUNDES                IN CHAR,
                                                PIDF_PLACAVEIC                IN CHAR,
                                                PIDF_UFPLACAVEIC              IN CHAR,
                                                PIDF_ACEITAITRESINF           IN NUMBER,
                                                PIDF_ACEITALOTEINF            IN NUMBER,
                                                PIDF_CDPATRIMO                IN CHAR,
                                                PIDF_CDANEXO                  IN CHAR,
                                                PIDF_VLCONTABIL               IN NUMBER,
                                                PIDF_IPINAOCREDITADO          IN NUMBER,
                                                PIDF_CDDECRESCIMO             IN CHAR,
                                                PIDF_NATBCCRED                IN CHAR,
                                                PIDF_INDNATFRETE              IN NUMBER,
                                                PIDF_VLBCII                   IN NUMBER DEFAULT 0,
                                                PIDF_ALIQII                   IN NUMBER DEFAULT 0,
                                                PIDF_VLII                     IN NUMBER DEFAULT 0,
                                                PIDF_PEMVAST                  IN NUMBER DEFAULT NULL,
                                                PIDF_CDCENTROCUSTO            IN CHAR,
                                                PIDF_VLCOMPLEMENTARDF         IN NUMBER DEFAULT NULL,
                                                PIDF_VLICMSNAOESCRITURADO     IN NUMBER DEFAULT 0,
                                                PIDF_VLPISNAOESCRITURADO      IN NUMBER DEFAULT 0,
                                                PIDF_VLCOFINSNAOESCRITURADO   IN NUMBER DEFAULT 0,
                                                PIDF_VLDIFALEMPFIL            IN NUMBER DEFAULT 0,
                                                PIDF_VLSUFRAMA                IN NUMBER DEFAULT 0,
                                                PIDF_PEALIQUOTAFECP           IN NUMBER DEFAULT 0,
                                                PIDF_PEALIQUOTAUFDESTINO      IN NUMBER DEFAULT 0,
                                                PIDF_PEALIQUOTAINTERESTADUAL  IN NUMBER DEFAULT 0,
                                                PIDF_PEICMSPARTILHAPROVISORIA IN NUMBER DEFAULT 0,
                                                PIDF_VLICMSFECPUFDEST         IN NUMBER DEFAULT 0,
                                                PIDF_VLICMSUFDESTINO          IN NUMBER DEFAULT 0,
                                                PIDF_VLICMSUFREMETENTE        IN NUMBER DEFAULT 0,
                                                PIDF_VLICMSDESONERADO         IN NUMBER DEFAULT 0,
                                                PIDF_CDMOTIVOICMSDESONERADO   IN NUMBER DEFAULT 0,
                                                PIDF_PECREDITOPRESUMIDO       IN NUMBER DEFAULT 0,
                                                PIDF_VLCREDITOPRESUMIDO       IN NUMBER DEFAULT 0,
                                                PIDF_VBCTAPORPROC       IN NUMBER DEFAULT 0) AS
BEGIN
  IF PIDF_SQITDOCFIS IS NULL THEN
    SELECT SEQ_IDF_SQITDOCFIS.NEXTVAL INTO PIDF_SQITDOCFIS FROM DUAL;
  END IF;
  INSERT INTO SPEDITDOCFIS_IDF
    (IDF_SQITDOCFIS,
     IDF_SQDOCFIS,
     IDF_NUMSEQ,
     IDF_ITEM,
     IDF_QUANTIDADE,
     IDF_UNIDADE,
     IDF_VLITEM,
     IDF_VLDESC,
     IDF_MOVFIS,
     IDF_ORIGEM,
     IDF_CSTICMS,
     IDF_CFOP,
     IDF_VLBCICMS,
     IDF_ALIQICMS,
     IDF_VLICMS,
     IDF_VLBCICMSST,
     IDF_ALIQICMSST,
     IDF_VLICMSST,
     IDF_STNAOCREDITADO,
     IDF_VLREDBC,
     IDF_CSTIPI,
     IDF_CODENQ,
     IDF_VLBCIPI,
     IDF_ALIQIPI,
     IDF_VLIPI,
     IDF_CSTPIS,
     IDF_VLBCPIS,
     IDF_ALIQPIS,
     IDF_QTDBCPIS,
     IDF_ALIQPISR,
     IDF_VLPIS,
     IDF_VLBCPISRET,
     IDF_ALIQPISRET,
     IDF_VLPISRET,
     IDF_CSTCOFINS,
     IDF_VLBCCOFINS,
     IDF_ALIQCOFINS,
     IDF_QTDBCCOFINS,
     IDF_ALIQCOFINSR,
     IDF_VLCOFINS,
     IDF_VLBCCOFINSRET,
     IDF_ALIQCOFINSRET,
     IDF_VLCOFINSRET,
     IDF_CLASSE,
     IDF_INDREC,
     IDF_CLIFOR,
     IDF_CDCLIENTE,
     IDF_CDFOR,
     IDF_VLSERV,
     IDF_VLOUTDESP,
     IDF_VLUNTITEM,
     IDF_NOCONTAB,
     IDF_INDAPURIPI,
     IDF_IPINAOCRED,
     IDF_TPOP,
     IDF_VLBIICMS,
     IDF_VLBOICMS,
     IDF_VLBIIPI,
     IDF_VLBOIPI,
     IDF_CODMUNORI,
     IDF_CODMUNDES,
     IDF_PLACAVEIC,
     IDF_UFPLACAVEIC,
     IDF_ACEITAITRESINF,
     IDF_ACEITALOTEINF,
     IDF_CDPATRIMO,
     IDF_CDANEXO,
     IDF_VLCONTABIL,
     IDF_IPINAOCREDITADO,
     IDF_CDDECRESCIMO,
     IDF_NATBCCRED,
     IDF_INDNATFRETE,
     IDF_VLBCII,
     IDF_ALIQII,
     IDF_VLII,
     IDF_PEMVAST,
     IDF_CDCENTROCUSTO,
     IDF_VLCOMPLEMENTARDF,
     IDF_VLICMSNAOESCRITURADO,
     IDF_VLPISNAOESCRITURADO,
     IDF_VLCOFINSNAOESCRITURADO,
     IDF_VLDIFALEMPFIL,
     IDF_VLSUFRAMA,
     IDF_PEALIQUOTAFECP,
     IDF_PEALIQUOTAUFDESTINO,
     IDF_PEALIQUOTAINTERESTADUAL,
     IDF_PEICMSPARTILHAPROVISORIA,
     IDF_VLICMSFECPUFDEST,
     IDF_VLICMSUFDESTINO,
     IDF_VLICMSUFREMETENTE,
     IDF_VLICMSDESONERADO,
     IDF_CDMOTIVOICMSDESONERADO,
     IDF_PECREDITOPRESUMIDO,
     IDF_VLCREDITOPRESUMIDO,
     IDF_VBCTAPORPROC)
  VALUES
    (PIDF_SQITDOCFIS,
     PIDF_SQDOCFIS,
     PIDF_NUMSEQ,
     PIDF_ITEM,
     PIDF_QUANTIDADE,
     PIDF_UNIDADE,
     PIDF_VLITEM,
     PIDF_VLDESC,
     PIDF_MOVFIS,
     PIDF_ORIGEM,
     PIDF_CSTICMS,
     PIDF_CFOP,
     PIDF_VLBCICMS,
     PIDF_ALIQICMS,
     PIDF_VLICMS,
     PIDF_VLBCICMSST,
     PIDF_ALIQICMSST,
     PIDF_VLICMSST,
     PIDF_STNAOCREDITADO,
     PIDF_VLREDBC,
     PIDF_CSTIPI,
     PIDF_CODENQ,
     PIDF_VLBCIPI,
     PIDF_ALIQIPI,
     PIDF_VLIPI,
     PIDF_CSTPIS,
     PIDF_VLBCPIS,
     PIDF_ALIQPIS,
     PIDF_QTDBCPIS,
     PIDF_ALIQPISR,
     PIDF_VLPIS,
     PIDF_VLBCPISRET,
     PIDF_ALIQPISRET,
     PIDF_VLPISRET,
     PIDF_CSTCOFINS,
     PIDF_VLBCCOFINS,
     PIDF_ALIQCOFINS,
     PIDF_QTDBCCOFINS,
     PIDF_ALIQCOFINSR,
     PIDF_VLCOFINS,
     PIDF_VLBCCOFINSRET,
     PIDF_ALIQCOFINSRET,
     PIDF_VLCOFINSRET,
     PIDF_CLASSE,
     PIDF_INDREC,
     PIDF_CLIFOR,
     PIDF_CDCLIENTE,
     PIDF_CDFOR,
     PIDF_VLSERV,
     PIDF_VLOUTDESP,
     PIDF_VLUNTITEM,
     PIDF_NOCONTAB,
     PIDF_INDAPURIPI,
     PIDF_IPINAOCRED,
     PIDF_TPOP,
     PIDF_VLBIICMS,
     PIDF_VLBOICMS,
     PIDF_VLBIIPI,
     PIDF_VLBOIPI,
     PIDF_CODMUNORI,
     PIDF_CODMUNDES,
     PIDF_PLACAVEIC,
     PIDF_UFPLACAVEIC,
     PIDF_ACEITAITRESINF,
     PIDF_ACEITALOTEINF,
     PIDF_CDPATRIMO,
     PIDF_CDANEXO,
     PIDF_VLCONTABIL,
     PIDF_IPINAOCREDITADO,
     PIDF_CDDECRESCIMO,
     PIDF_NATBCCRED,
     PIDF_INDNATFRETE,
     PIDF_VLBCII,
     PIDF_ALIQII,
     PIDF_VLII,
     PIDF_PEMVAST,
     PIDF_CDCENTROCUSTO,
     PIDF_VLCOMPLEMENTARDF,
     PIDF_VLICMSNAOESCRITURADO,
     PIDF_VLPISNAOESCRITURADO,
     PIDF_VLCOFINSNAOESCRITURADO,
     PIDF_VLDIFALEMPFIL,
     PIDF_VLSUFRAMA,
     PIDF_PEALIQUOTAFECP,
     PIDF_PEALIQUOTAUFDESTINO,
     PIDF_PEALIQUOTAINTERESTADUAL,
     PIDF_PEICMSPARTILHAPROVISORIA,
     PIDF_VLICMSFECPUFDEST,
     PIDF_VLICMSUFDESTINO,
     PIDF_VLICMSUFREMETENTE,
     PIDF_VLICMSDESONERADO,
     PIDF_CDMOTIVOICMSDESONERADO,
     PIDF_PECREDITOPRESUMIDO,
     PIDF_VLCREDITOPRESUMIDO,
     PIDF_VBCTAPORPROC);
END INSSPEDITDOCFIS_IDF;
/

CREATE OR REPLACE PROCEDURE ALTSPEDITDOCFIS_IDF(PIDF_SQITDOCFIS               IN OUT NUMBER,
                                                PIDF_SQDOCFIS                 IN NUMBER,
                                                PIDF_NUMSEQ                   IN NUMBER,
                                                PIDF_ITEM                     IN CHAR,
                                                PIDF_QUANTIDADE               IN NUMBER,
                                                PIDF_UNIDADE                  IN CHAR,
                                                PIDF_VLITEM                   IN NUMBER,
                                                PIDF_VLDESC                   IN NUMBER,
                                                PIDF_MOVFIS                   IN NUMBER,
                                                PIDF_ORIGEM                   IN NUMBER,
                                                PIDF_CSTICMS                  IN CHAR,
                                                PIDF_CFOP                     IN CHAR,
                                                PIDF_VLBCICMS                 IN NUMBER,
                                                PIDF_ALIQICMS                 IN NUMBER,
                                                PIDF_VLICMS                   IN NUMBER,
                                                PIDF_VLBCICMSST               IN NUMBER,
                                                PIDF_ALIQICMSST               IN NUMBER,
                                                PIDF_VLICMSST                 IN NUMBER,
                                                PIDF_STNAOCREDITADO           IN NUMBER,
                                                PIDF_VLREDBC                  IN NUMBER,
                                                PIDF_CSTIPI                   IN CHAR,
                                                PIDF_CODENQ                   IN CHAR,
                                                PIDF_VLBCIPI                  IN NUMBER,
                                                PIDF_ALIQIPI                  IN NUMBER,
                                                PIDF_VLIPI                    IN NUMBER,
                                                PIDF_CSTPIS                   IN CHAR,
                                                PIDF_VLBCPIS                  IN NUMBER DEFAULT 0,
                                                PIDF_ALIQPIS                  IN NUMBER DEFAULT 0,
                                                PIDF_QTDBCPIS                 IN NUMBER DEFAULT 0,
                                                PIDF_ALIQPISR                 IN NUMBER DEFAULT 0,
                                                PIDF_VLPIS                    IN NUMBER DEFAULT 0,
                                                PIDF_VLBCPISRET               IN NUMBER,
                                                PIDF_ALIQPISRET               IN NUMBER,
                                                PIDF_VLPISRET                 IN NUMBER,
                                                PIDF_CSTCOFINS                IN CHAR,
                                                PIDF_VLBCCOFINS               IN NUMBER DEFAULT 0,
                                                PIDF_ALIQCOFINS               IN NUMBER DEFAULT 0,
                                                PIDF_QTDBCCOFINS              IN NUMBER DEFAULT 0,
                                                PIDF_ALIQCOFINSR              IN NUMBER DEFAULT 0,
                                                PIDF_VLCOFINS                 IN NUMBER DEFAULT 0,
                                                PIDF_VLBCCOFINSRET            IN NUMBER,
                                                PIDF_ALIQCOFINSRET            IN NUMBER,
                                                PIDF_VLCOFINSRET              IN NUMBER,
                                                PIDF_CLASSE                   IN CHAR,
                                                PIDF_INDREC                   IN NUMBER,
                                                PIDF_CLIFOR                   IN CHAR,
                                                PIDF_CDCLIENTE                IN CHAR,
                                                PIDF_CDFOR                    IN CHAR,
                                                PIDF_VLSERV                   IN NUMBER,
                                                PIDF_VLOUTDESP                IN NUMBER,
                                                PIDF_VLUNTITEM                IN NUMBER,
                                                PIDF_NOCONTAB                 IN CHAR,
                                                PIDF_INDAPURIPI               IN NUMBER,
                                                PIDF_IPINAOCRED               IN NUMBER,
                                                PIDF_TPOP                     IN CHAR,
                                                PIDF_VLBIICMS                 IN NUMBER,
                                                PIDF_VLBOICMS                 IN NUMBER,
                                                PIDF_VLBIIPI                  IN NUMBER,
                                                PIDF_VLBOIPI                  IN NUMBER,
                                                PIDF_CODMUNORI                IN CHAR,
                                                PIDF_CODMUNDES                IN CHAR,
                                                PIDF_PLACAVEIC                IN CHAR,
                                                PIDF_UFPLACAVEIC              IN CHAR,
                                                PIDF_ACEITAITRESINF           IN NUMBER,
                                                PIDF_ACEITALOTEINF            IN NUMBER,
                                                PIDF_CDPATRIMO                IN CHAR,
                                                PIDF_CDANEXO                  IN CHAR,
                                                PIDF_VLCONTABIL               IN NUMBER,
                                                PIDF_IPINAOCREDITADO          IN NUMBER,
                                                PIDF_CDDECRESCIMO             IN CHAR,
                                                PIDF_NATBCCRED                IN CHAR,
                                                PIDF_INDNATFRETE              IN NUMBER,
                                                PIDF_VLBCII                   IN NUMBER DEFAULT 0,
                                                PIDF_ALIQII                   IN NUMBER DEFAULT 0,
                                                PIDF_VLII                     IN NUMBER DEFAULT 0,
                                                PIDF_PEMVAST                  IN NUMBER DEFAULT NULL,
                                                PIDF_CDCENTROCUSTO            IN CHAR,
                                                PIDF_VLCOMPLEMENTARDF         IN NUMBER DEFAULT NULL,
                                                PIDF_VLICMSNAOESCRITURADO     IN NUMBER DEFAULT 0,
                                                PIDF_VLPISNAOESCRITURADO      IN NUMBER DEFAULT 0,
                                                PIDF_VLCOFINSNAOESCRITURADO   IN NUMBER DEFAULT 0,
                                                PIDF_VLDIFALEMPFIL            IN NUMBER DEFAULT 0,
                                                PIDF_VLSUFRAMA                IN NUMBER DEFAULT 0,
                                                PIDF_PEALIQUOTAFECP           IN NUMBER DEFAULT 0,
                                                PIDF_PEALIQUOTAUFDESTINO      IN NUMBER DEFAULT 0,
                                                PIDF_PEALIQUOTAINTERESTADUAL  IN NUMBER DEFAULT 0,
                                                PIDF_PEICMSPARTILHAPROVISORIA IN NUMBER DEFAULT 0,
                                                PIDF_VLICMSFECPUFDEST         IN NUMBER DEFAULT 0,
                                                PIDF_VLICMSUFDESTINO          IN NUMBER DEFAULT 0,
                                                PIDF_VLICMSUFREMETENTE        IN NUMBER DEFAULT 0,
                                                PIDF_VLICMSDESONERADO         IN NUMBER DEFAULT 0,
                                                PIDF_CDMOTIVOICMSDESONERADO   IN NUMBER DEFAULT 0,
                                                PIDF_PECREDITOPRESUMIDO       IN NUMBER DEFAULT 0,
                                                PIDF_VLCREDITOPRESUMIDO       IN NUMBER DEFAULT 0,
                                                PIDF_VBCTAPORPROC       IN NUMBER DEFAULT 0) AS
BEGIN
  UPDATE SPEDITDOCFIS_IDF
     SET IDF_SQDOCFIS                 = PIDF_SQDOCFIS,
         IDF_NUMSEQ                   = PIDF_NUMSEQ,
         IDF_ITEM                     = PIDF_ITEM,
         IDF_QUANTIDADE               = PIDF_QUANTIDADE,
         IDF_UNIDADE                  = PIDF_UNIDADE,
         IDF_VLITEM                   = PIDF_VLITEM,
         IDF_VLDESC                   = PIDF_VLDESC,
         IDF_MOVFIS                   = PIDF_MOVFIS,
         IDF_ORIGEM                   = PIDF_ORIGEM,
         IDF_CSTICMS                  = PIDF_CSTICMS,
         IDF_CFOP                     = PIDF_CFOP,
         IDF_VLBCICMS                 = PIDF_VLBCICMS,
         IDF_ALIQICMS                 = PIDF_ALIQICMS,
         IDF_VLICMS                   = PIDF_VLICMS,
         IDF_VLBCICMSST               = PIDF_VLBCICMSST,
         IDF_ALIQICMSST               = PIDF_ALIQICMSST,
         IDF_VLICMSST                 = PIDF_VLICMSST,
         IDF_STNAOCREDITADO           = PIDF_STNAOCREDITADO,
         IDF_VLREDBC                  = PIDF_VLREDBC,
         IDF_CSTIPI                   = PIDF_CSTIPI,
         IDF_CODENQ                   = PIDF_CODENQ,
         IDF_VLBCIPI                  = PIDF_VLBCIPI,
         IDF_ALIQIPI                  = PIDF_ALIQIPI,
         IDF_VLIPI                    = PIDF_VLIPI,
         IDF_CSTPIS                   = PIDF_CSTPIS,
         IDF_VLBCPIS                  = PIDF_VLBCPIS,
         IDF_ALIQPIS                  = PIDF_ALIQPIS,
         IDF_QTDBCPIS                 = PIDF_QTDBCPIS,
         IDF_ALIQPISR                 = PIDF_ALIQPISR,
         IDF_VLPIS                    = PIDF_VLPIS,
         IDF_VLBCPISRET               = PIDF_VLBCPISRET,
         IDF_ALIQPISRET               = PIDF_ALIQPISRET,
         IDF_VLPISRET                 = PIDF_VLPISRET,
         IDF_CSTCOFINS                = PIDF_CSTCOFINS,
         IDF_VLBCCOFINS               = PIDF_VLBCCOFINS,
         IDF_ALIQCOFINS               = PIDF_ALIQCOFINS,
         IDF_QTDBCCOFINS              = PIDF_QTDBCCOFINS,
         IDF_ALIQCOFINSR              = PIDF_ALIQCOFINSR,
         IDF_VLCOFINS                 = PIDF_VLCOFINS,
         IDF_VLBCCOFINSRET            = PIDF_VLBCCOFINSRET,
         IDF_ALIQCOFINSRET            = PIDF_ALIQCOFINSRET,
         IDF_VLCOFINSRET              = PIDF_VLCOFINSRET,
         IDF_CLASSE                   = PIDF_CLASSE,
         IDF_INDREC                   = PIDF_INDREC,
         IDF_CLIFOR                   = PIDF_CLIFOR,
         IDF_CDCLIENTE                = PIDF_CDCLIENTE,
         IDF_CDFOR                    = PIDF_CDFOR,
         IDF_VLSERV                   = PIDF_VLSERV,
         IDF_VLOUTDESP                = PIDF_VLOUTDESP,
         IDF_VLUNTITEM                = PIDF_VLUNTITEM,
         IDF_NOCONTAB                 = PIDF_NOCONTAB,
         IDF_INDAPURIPI               = PIDF_INDAPURIPI,
         IDF_IPINAOCRED               = PIDF_IPINAOCRED,
         IDF_TPOP                     = PIDF_TPOP,
         IDF_VLBIICMS                 = PIDF_VLBIICMS,
         IDF_VLBOICMS                 = PIDF_VLBOICMS,
         IDF_VLBIIPI                  = PIDF_VLBIIPI,
         IDF_VLBOIPI                  = PIDF_VLBOIPI,
         IDF_CODMUNORI                = PIDF_CODMUNORI,
         IDF_CODMUNDES                = PIDF_CODMUNDES,
         IDF_PLACAVEIC                = PIDF_PLACAVEIC,
         IDF_UFPLACAVEIC              = PIDF_UFPLACAVEIC,
         IDF_ACEITAITRESINF           = PIDF_ACEITAITRESINF,
         IDF_ACEITALOTEINF            = PIDF_ACEITALOTEINF,
         IDF_CDPATRIMO                = PIDF_CDPATRIMO,
         IDF_CDANEXO                  = PIDF_CDANEXO,
         IDF_VLCONTABIL               = PIDF_VLCONTABIL,
         IDF_IPINAOCREDITADO          = PIDF_IPINAOCREDITADO,
         IDF_CDDECRESCIMO             = PIDF_CDDECRESCIMO,
         IDF_NATBCCRED                = PIDF_NATBCCRED,
         IDF_INDNATFRETE              = PIDF_INDNATFRETE,
         IDF_VLBCII                   = PIDF_VLBCII,
         IDF_ALIQII                   = PIDF_ALIQII,
         IDF_VLII                     = PIDF_VLII,
         IDF_PEMVAST                  = PIDF_PEMVAST,
         IDF_CDCENTROCUSTO            = PIDF_CDCENTROCUSTO,
         IDF_VLCOMPLEMENTARDF         = PIDF_VLCOMPLEMENTARDF,
         IDF_VLICMSNAOESCRITURADO     = PIDF_VLICMSNAOESCRITURADO,
         IDF_VLPISNAOESCRITURADO      = PIDF_VLPISNAOESCRITURADO,
         IDF_VLCOFINSNAOESCRITURADO   = PIDF_VLCOFINSNAOESCRITURADO,
         IDF_VLDIFALEMPFIL            = PIDF_VLDIFALEMPFIL,
         IDF_VLSUFRAMA                = PIDF_VLSUFRAMA,
         IDF_PEALIQUOTAFECP           = PIDF_PEALIQUOTAFECP,
         IDF_PEALIQUOTAUFDESTINO      = PIDF_PEALIQUOTAUFDESTINO,
         IDF_PEALIQUOTAINTERESTADUAL  = PIDF_PEALIQUOTAINTERESTADUAL,
         IDF_PEICMSPARTILHAPROVISORIA = PIDF_PEICMSPARTILHAPROVISORIA,
         IDF_VLICMSFECPUFDEST         = PIDF_VLICMSFECPUFDEST,
         IDF_VLICMSUFDESTINO          = PIDF_VLICMSUFDESTINO,
         IDF_VLICMSUFREMETENTE        = PIDF_VLICMSUFREMETENTE,
         IDF_VLICMSDESONERADO         = PIDF_VLICMSDESONERADO,
         IDF_CDMOTIVOICMSDESONERADO   = PIDF_CDMOTIVOICMSDESONERADO,
         IDF_PECREDITOPRESUMIDO       = PIDF_PECREDITOPRESUMIDO,
         IDF_VLCREDITOPRESUMIDO       = PIDF_VLCREDITOPRESUMIDO,
         IDF_VBCTAPORPROC             = PIDF_VBCTAPORPROC
   WHERE IDF_SQITDOCFIS = PIDF_SQITDOCFIS;
END ALTSPEDITDOCFIS_IDF;
/

CREATE OR REPLACE PROCEDURE INSSPEDITDOCFISSERV_IDFS
(PIDFS_SQITDOCFISSERV IN OUT NUMBER,
 PIDFS_SQDOCFISSERV IN NUMBER,
 PIDFS_NUMSEQ IN NUMBER,
 PIDFS_ITEM IN CHAR,
 PIDFS_VLITEM IN NUMBER,
 PIDFS_VLDESC IN NUMBER,
 PIDFS_CDDESC IN CHAR,
 PIDFS_VLDEDUCAO IN NUMBER,
 PIDFS_CDDEDUCAO IN CHAR,
 PIDFS_NATBCCRED IN CHAR,
 PIDFS_ORIGCRED IN CHAR,
 PIDFS_CSTPIS IN CHAR,
 PIDFS_VLBCPIS IN NUMBER,
 PIDFS_ALIQPIS IN NUMBER,
 PIDFS_VLPIS IN NUMBER,
 PIDFS_CSTCOFINS IN CHAR,
 PIDFS_VLBCCOFINS IN NUMBER,
 PIDFS_ALIQCOFINS IN NUMBER,
 PIDFS_VLCOFINS IN NUMBER,
 PIDFS_VLBCISS IN NUMBER,
 PIDFS_ALIQISS IN NUMBER,
 PIDFS_VLISS IN NUMBER,
 PIDFS_VLBIISS IN NUMBER,
 PIDFS_CODCTA IN CHAR,
 PIDFS_CODCCUS IN CHAR,
 PIDFS_DTAPROPRIACAO IN DATE,
 PIDFS_DESCCOMPL IN CHAR,
 PIDFS_VBCTAPORPROC IN NUMBER DEFAULT 0
)
AS
BEGIN
IF PIDFS_SQITDOCFISSERV IS NULL THEN
 SELECT SEQ_IDFS_SQITDOCFISSERV.NEXTVAL INTO PIDFS_SQITDOCFISSERV FROM DUAL;
END IF;
  INSERT INTO SPEDITDOCFISSERV_IDFS(
      IDFS_SQITDOCFISSERV,
      IDFS_SQDOCFISSERV,
      IDFS_NUMSEQ,
      IDFS_ITEM,
      IDFS_VLITEM,
      IDFS_VLDESC,
      IDFS_CDDESC,
      IDFS_VLDEDUCAO,
      IDFS_CDDEDUCAO,
      IDFS_NATBCCRED,
      IDFS_ORIGCRED,
      IDFS_CSTPIS,
      IDFS_VLBCPIS,
      IDFS_ALIQPIS,
      IDFS_VLPIS,
      IDFS_CSTCOFINS,
      IDFS_VLBCCOFINS,
      IDFS_ALIQCOFINS,
      IDFS_VLCOFINS,
      IDFS_VLBCISS,
      IDFS_ALIQISS,
      IDFS_VLISS,
      IDFS_VLBIISS,
      IDFS_CODCTA,
      IDFS_CODCCUS,
      IDFS_DTAPROPRIACAO,
      IDFS_DESCCOMPL,
      IDFS_VBCTAPORPROC
) VALUES (
      PIDFS_SQITDOCFISSERV,
      PIDFS_SQDOCFISSERV,
      PIDFS_NUMSEQ,
      PIDFS_ITEM,
      PIDFS_VLITEM,
      PIDFS_VLDESC,
      PIDFS_CDDESC,
      PIDFS_VLDEDUCAO,
      PIDFS_CDDEDUCAO,
      PIDFS_NATBCCRED,
      PIDFS_ORIGCRED,
      PIDFS_CSTPIS,
      PIDFS_VLBCPIS,
      PIDFS_ALIQPIS,
      PIDFS_VLPIS,
      PIDFS_CSTCOFINS,
      PIDFS_VLBCCOFINS,
      PIDFS_ALIQCOFINS,
      PIDFS_VLCOFINS,
      PIDFS_VLBCISS,
      PIDFS_ALIQISS,
      PIDFS_VLISS,
      PIDFS_VLBIISS,
      PIDFS_CODCTA,
      PIDFS_CODCCUS,
      PIDFS_DTAPROPRIACAO,
      PIDFS_DESCCOMPL,
      PIDFS_VBCTAPORPROC
);
END;
/

CREATE OR REPLACE PROCEDURE ALTSPEDITDOCFISSERV_IDFS
(PIDFS_SQITDOCFISSERV IN OUT NUMBER,
 PIDFS_SQDOCFISSERV IN NUMBER,
 PIDFS_NUMSEQ IN NUMBER,
 PIDFS_ITEM IN CHAR,
 PIDFS_VLITEM IN NUMBER,
 PIDFS_VLDESC IN NUMBER,
 PIDFS_CDDESC IN CHAR,
 PIDFS_VLDEDUCAO IN NUMBER,
 PIDFS_CDDEDUCAO IN CHAR,
 PIDFS_NATBCCRED IN CHAR,
 PIDFS_ORIGCRED IN CHAR,
 PIDFS_CSTPIS IN CHAR,
 PIDFS_VLBCPIS IN NUMBER,
 PIDFS_ALIQPIS IN NUMBER,
 PIDFS_VLPIS IN NUMBER,
 PIDFS_CSTCOFINS IN CHAR,
 PIDFS_VLBCCOFINS IN NUMBER,
 PIDFS_ALIQCOFINS IN NUMBER,
 PIDFS_VLCOFINS IN NUMBER,
 PIDFS_VLBCISS IN NUMBER,
 PIDFS_ALIQISS IN NUMBER,
 PIDFS_VLISS IN NUMBER,
 PIDFS_VLBIISS IN NUMBER,
 PIDFS_CODCTA IN CHAR,
 PIDFS_CODCCUS IN CHAR,
 PIDFS_DTAPROPRIACAO IN DATE,
 PIDFS_DESCCOMPL IN CHAR,
 PIDFS_VBCTAPORPROC IN NUMBER DEFAULT 0
)
AS
BEGIN
  UPDATE SPEDITDOCFISSERV_IDFS
   SET IDFS_SQDOCFISSERV = PIDFS_SQDOCFISSERV,
       IDFS_NUMSEQ = PIDFS_NUMSEQ,
       IDFS_ITEM = PIDFS_ITEM,
       IDFS_VLITEM = PIDFS_VLITEM,
       IDFS_VLDESC = PIDFS_VLDESC,
       IDFS_CDDESC = PIDFS_CDDESC,
       IDFS_VLDEDUCAO = PIDFS_VLDEDUCAO,
       IDFS_CDDEDUCAO = PIDFS_CDDEDUCAO,
       IDFS_NATBCCRED = PIDFS_NATBCCRED,
       IDFS_ORIGCRED = PIDFS_ORIGCRED,
       IDFS_CSTPIS = PIDFS_CSTPIS,
       IDFS_VLBCPIS = PIDFS_VLBCPIS,
       IDFS_ALIQPIS = PIDFS_ALIQPIS,
       IDFS_VLPIS = PIDFS_VLPIS,
       IDFS_CSTCOFINS = PIDFS_CSTCOFINS,
       IDFS_VLBCCOFINS = PIDFS_VLBCCOFINS,
       IDFS_ALIQCOFINS = PIDFS_ALIQCOFINS,
       IDFS_VLCOFINS = PIDFS_VLCOFINS,
       IDFS_VLBCISS = PIDFS_VLBCISS,
       IDFS_ALIQISS = PIDFS_ALIQISS,
       IDFS_VLISS = PIDFS_VLISS,
       IDFS_VLBIISS = PIDFS_VLBIISS,
       IDFS_CODCTA = PIDFS_CODCTA,
       IDFS_CODCCUS = PIDFS_CODCCUS,
       IDFS_DTAPROPRIACAO = PIDFS_DTAPROPRIACAO,
       IDFS_DESCCOMPL = PIDFS_DESCCOMPL,
       IDFS_VBCTAPORPROC  = PIDFS_VBCTAPORPROC
   WHERE IDFS_SQITDOCFISSERV = PIDFS_SQITDOCFISSERV;
END;
/

CREATE OR REPLACE PROCEDURE INSSPEDDOCFIS_SDF(PSDF_SQDOCFIS                   IN OUT NUMBER
                                            , PSDF_CDEMPRESA                  IN     CHAR
                                            , PSDF_CDFILIAL                   IN     CHAR
                                            , PSDF_TPOP                       IN     CHAR
                                            , PSDF_MODELO                     IN     CHAR
                                            , PSDF_SERIE                      IN     CHAR
                                            , PSDF_SUBSERIE                   IN     CHAR
                                            , PSDF_EMITENTE                   IN     CHAR
                                            , PSDF_CLIFOR                     IN     CHAR
                                            , PSDF_CDCLIFOR                   IN     CHAR
                                            , PSDF_DOCUMENTO                  IN     CHAR
                                            , PSDF_DATAEMISS                  IN     DATE
                                            , PSDF_DATAENTR                   IN     DATE
                                            , PSDF_DATAESCR                   IN     DATE
                                            , PSDF_SITDOC                     IN     CHAR
                                            , PSDF_VLTOTAL                    IN     NUMBER
                                            , PSDF_CHAVENFE                   IN     CHAR
                                            , PSDF_INDPAG                     IN     CHAR
                                            , PSDF_CLASSECONS                 IN     CHAR
                                            , PSDF_VLBCICMS                   IN     NUMBER
                                            , PSDF_VLICMS                     IN     NUMBER
                                            , PSDF_VLBCICMSST                 IN     NUMBER
                                            , PSDF_VLICMSST                   IN     NUMBER
                                            , PSDF_VLPIS                      IN     NUMBER
                                            , PSDF_VLCOFINS                   IN     NUMBER
                                            , PSDF_VLPISST                    IN     NUMBER
                                            , PSDF_VLCOFINSST                 IN     NUMBER
                                            , PSDF_VLIPI                      IN     NUMBER
                                            , PSDF_VLTOTDESC                  IN     NUMBER
                                            , PSDF_VLESPEC                    IN     NUMBER
                                            , PSDF_VLSERNTRIB                 IN     NUMBER
                                            , PSDF_VLTERCEIROS                IN     NUMBER
                                            , PSDF_VLSEGUROS                  IN     NUMBER
                                            , PSDF_DESPESASAC                 IN     NUMBER
                                            , PSDF_ABATNTRIB                  IN     NUMBER
                                            , PSDF_INDTPFRETE                 IN     CHAR
                                            , PSDF_VLFRETE                    IN     NUMBER
                                            , PSDF_CONTABINF                  IN     NUMBER
                                            , PSDF_IMPOSTOINF                 IN     NUMBER
                                            , PSDF_VLBIICMS                   IN     NUMBER
                                            , PSDF_VLBOICMS                   IN     NUMBER
                                            , PSDF_VLBIIPI                    IN     NUMBER
                                            , PSDF_VLBOIPI                    IN     NUMBER
                                            , PSDF_ISAJUSTE                   IN     NUMBER
                                            , PSDF_CODUTILIZACAO              IN     NUMBER
                                            , PSDF_TPCTE                      IN     CHAR
                                            , PSDF_CHAVECTE                   IN     CHAR
                                            , PSDF_CHAVECTE_REF               IN     CHAR
                                            , PSDF_CDINFCOMP                  IN     CHAR
                                            , PSDF_CONTACTB                   IN     CHAR
                                            , PSDF_VBIMPORTADO                IN     NUMBER
                                            , PSDF_VLSERVNT                   IN     NUMBER
                                            , PSDF_VLBCISSQN                  IN     NUMBER
                                            , PSDF_VLISSQN                    IN     NUMBER
                                            , PSDF_VLBCIRRF                   IN     NUMBER
                                            , PSDF_VLIRRF                     IN     NUMBER
                                            , PSDF_VLBCPREV                   IN     NUMBER
                                            , PSDF_VLPREV                     IN     NUMBER
                                            , PSDF_INDEMITENTE                IN     CHAR
                                            , PSDF_INDTITULO                  IN     CHAR
                                            , PSDF_DESCTITULO                 IN     CHAR
                                            , PSDF_NUMTITULO                  IN     CHAR
                                            , PSDF_QTDPARCELAS                IN     NUMBER
                                            , PSDF_VLTOTALTITULO              IN     NUMBER
                                            , PSDF_CLIFORTRANSP               IN     CHAR
                                            , PSDF_CDCLIFORTRANSP             IN     CHAR
                                            , PSDF_VEICULOID                  IN     CHAR
                                            , PSDF_QTDVOLUME                  IN     NUMBER
                                            , PSDF_PESOBRT                    IN     NUMBER
                                            , PSDF_PESOLIQ                    IN     NUMBER
                                            , PSDF_IDUF                       IN     CHAR
                                            , PSDF_VBIMPORTADOXML             IN     NUMBER
                                            , PSDF_SEGMOEDA                   IN     CHAR
                                            , PSDF_TAXASEGMOEDA               IN     NUMBER
                                            , PSDF_UFOPER                     IN     CHAR
                                            , PSDF_OPER                       IN     CHAR
                                            , PSDF_TPLIGACAO                  IN     CHAR
                                            , PSDF_GRUPOTENSAO                IN     CHAR
                                            , PSDF_TPASSINANTE                IN     CHAR
                                            , PSDF_CDENDCLIFOR                IN     CHAR
                                            , PSDF_SYSTEM                     IN     CHAR
                                            , PSDF_ALIQIRRF                   IN     NUMBER DEFAULT NULL
                                            , PSDF_ALIQCSLL                   IN     NUMBER DEFAULT NULL
                                            , PSDF_BCCSLL                     IN     NUMBER DEFAULT NULL
                                            , PSDF_VLCSLL                     IN     NUMBER DEFAULT NULL
                                            , PSDF_ALIQINSS                   IN     NUMBER DEFAULT NULL
                                            , PSDF_VOLESPEC                   IN     CHAR DEFAULT NULL
                                            , PSDF_VIATTRANSP                 IN     CHAR DEFAULT NULL
                                            , PSDF_CDTIPOTITULO               IN     CHAR DEFAULT NULL
                                            , PSDF_TPESTOQUE                  IN     CHAR DEFAULT NULL
                                            , PSDF_VLTOTALCANC                IN     NUMBER DEFAULT NULL
                                            , PSDF_VLTOTALII                  IN     NUMBER DEFAULT NULL
                                            , PSDF_VBNAOALTERACONTABILIDADE   IN     NUMBER DEFAULT NULL
                                            , PSDF_TPINDCOMPLEMENTAR          IN     CHAR DEFAULT NULL
                                            , PSDF_VLTOTALCOMPLEMENTAR        IN     NUMBER DEFAULT NULL
                                            , PSDF_CDMUNORIGEM IN CHAR DEFAULT NULL
                                            , PSDF_CDMUNDEST IN CHAR DEFAULT NULL
                                            , PSDF_VBCTAPORPROC IN NUMBER DEFAULT 0
                                            ) AS
BEGIN
   IF PSDF_SQDOCFIS IS NULL
   THEN
      SELECT SEQ_SDF_SQDOCFIS.NEXTVAL INTO PSDF_SQDOCFIS FROM DUAL;
   END IF;
   INSERT INTO SPEDDOCFIS_SDF(SDF_SQDOCFIS
                            , SDF_CDEMPRESA
                            , SDF_CDFILIAL
                            , SDF_TPOP
                            , SDF_MODELO
                            , SDF_SERIE
                            , SDF_SUBSERIE
                            , SDF_EMITENTE
                            , SDF_CLIFOR
                            , SDF_CDCLIFOR
                            , SDF_DOCUMENTO
                            , SDF_DATAEMISS
                            , SDF_DATAENTR
                            , SDF_DATAESCR
                            , SDF_SITDOC
                            , SDF_VLTOTAL
                            , SDF_CHAVENFE
                            , SDF_INDPAG
                            , SDF_CLASSECONS
                            , SDF_VLBCICMS
                            , SDF_VLICMS
                            , SDF_VLBCICMSST
                            , SDF_VLICMSST
                            , SDF_VLPIS
                            , SDF_VLCOFINS
                            , SDF_VLPISST
                            , SDF_VLCOFINSST
                            , SDF_VLIPI
                            , SDF_VLTOTDESC
                            , SDF_VLESPEC
                            , SDF_VLSERNTRIB
                            , SDF_VLTERCEIROS
                            , SDF_VLSEGUROS
                            , SDF_DESPESASAC
                            , SDF_ABATNTRIB
                            , SDF_INDTPFRETE
                            , SDF_VLFRETE
                            , SDF_CONTABINF
                            , SDF_IMPOSTOINF
                            , SDF_VLBIICMS
                            , SDF_VLBOICMS
                            , SDF_VLBIIPI
                            , SDF_VLBOIPI
                            , SDF_ISAJUSTE
                            , SDF_CODUTILIZACAO
                            , SDF_TPCTE
                            , SDF_CHAVECTE
                            , SDF_CHAVECTE_REF
                            , SDF_CDINFCOMP
                            , SDF_CONTACTB
                            , SDF_VBIMPORTADO
                            , SDF_VLSERVNT
                            , SDF_VLBCISSQN
                            , SDF_VLISSQN
                            , SDF_VLBCIRRF
                            , SDF_VLIRRF
                            , SDF_VLBCPREV
                            , SDF_VLPREV
                            , SDF_INDEMITENTE
                            , SDF_INDTITULO
                            , SDF_DESCTITULO
                            , SDF_NUMTITULO
                            , SDF_QTDPARCELAS
                            , SDF_VLTOTALTITULO
                            , SDF_CLIFORTRANSP
                            , SDF_CDCLIFORTRANSP
                            , SDF_VEICULOID
                            , SDF_QTDVOLUME
                            , SDF_PESOBRT
                            , SDF_PESOLIQ
                            , SDF_IDUF
                            , SDF_VBIMPORTADOXML
                            , SDF_SEGMOEDA
                            , SDF_TAXASEGMOEDA
                            , SDF_UFOPER
                            , SDF_OPER
                            , SDF_TPLIGACAO
                            , SDF_GRUPOTENSAO
                            , SDF_TPASSINANTE
                            , SDF_CDENDCLIFOR
                            , SDF_SYSTEM
                            , SDF_ALIQIRRF
                            , SDF_ALIQCSLL
                            , SDF_BCCSLL
                            , SDF_VLCSLL
                            , SDF_ALIQINSS
                            , SDF_VOLESPEC
                            , SDF_VIATTRANSP
                            , SDF_CDTIPOTITULO
                            , SDF_TPESTOQUE
                            , SDF_VLTOTALCANC
                            , SDF_VLTOTALII
                            , SDF_VBNAOALTERACONTABILIDADE
                            , SDF_USINCLUSAO
                            , SDF_DTINCLUSAO
                            , SDF_USALTERACAO
                            , SDF_DTALTERACAO
                            , SDF_TPINDCOMPLEMENTAR
                            , SDF_VLTOTALCOMPLEMENTAR
                            , SDF_CDMUNORIGEM
                            , SDF_CDMUNDEST
                            , SDF_VBCTAPORPROC )
   VALUES (PSDF_SQDOCFIS
         , PSDF_CDEMPRESA
         , PSDF_CDFILIAL
         , PSDF_TPOP
         , PSDF_MODELO
         , PSDF_SERIE
         , PSDF_SUBSERIE
         , PSDF_EMITENTE
         , PSDF_CLIFOR
         , PSDF_CDCLIFOR
         , PSDF_DOCUMENTO
         , PSDF_DATAEMISS
         , PSDF_DATAENTR
         , PSDF_DATAESCR
         , PSDF_SITDOC
         , PSDF_VLTOTAL
         , PSDF_CHAVENFE
         , PSDF_INDPAG
         , PSDF_CLASSECONS
         , PSDF_VLBCICMS
         , PSDF_VLICMS
         , PSDF_VLBCICMSST
         , PSDF_VLICMSST
         , PSDF_VLPIS
         , PSDF_VLCOFINS
         , PSDF_VLPISST
         , PSDF_VLCOFINSST
         , PSDF_VLIPI
         , PSDF_VLTOTDESC
         , PSDF_VLESPEC
         , PSDF_VLSERNTRIB
         , PSDF_VLTERCEIROS
         , PSDF_VLSEGUROS
         , PSDF_DESPESASAC
         , PSDF_ABATNTRIB
         , PSDF_INDTPFRETE
         , PSDF_VLFRETE
         , PSDF_CONTABINF
         , PSDF_IMPOSTOINF
         , PSDF_VLBIICMS
         , PSDF_VLBOICMS
         , PSDF_VLBIIPI
         , PSDF_VLBOIPI
         , PSDF_ISAJUSTE
         , PSDF_CODUTILIZACAO
         , PSDF_TPCTE
         , PSDF_CHAVECTE
         , PSDF_CHAVECTE_REF
         , PSDF_CDINFCOMP
         , PSDF_CONTACTB
         , PSDF_VBIMPORTADO
         , PSDF_VLSERVNT
         , PSDF_VLBCISSQN
         , PSDF_VLISSQN
         , PSDF_VLBCIRRF
         , PSDF_VLIRRF
         , PSDF_VLBCPREV
         , PSDF_VLPREV
         , PSDF_INDEMITENTE
         , PSDF_INDTITULO
         , PSDF_DESCTITULO
         , PSDF_NUMTITULO
         , PSDF_QTDPARCELAS
         , PSDF_VLTOTALTITULO
         , PSDF_CLIFORTRANSP
         , PSDF_CDCLIFORTRANSP
         , PSDF_VEICULOID
         , PSDF_QTDVOLUME
         , PSDF_PESOBRT
         , PSDF_PESOLIQ
         , PSDF_IDUF
         , PSDF_VBIMPORTADOXML
         , PSDF_SEGMOEDA
         , PSDF_TAXASEGMOEDA
         , PSDF_UFOPER
         , PSDF_OPER
         , PSDF_TPLIGACAO
         , PSDF_GRUPOTENSAO
         , PSDF_TPASSINANTE
         , PSDF_CDENDCLIFOR
         , PSDF_SYSTEM
         , PSDF_ALIQIRRF
         , PSDF_ALIQCSLL
         , PSDF_BCCSLL
         , PSDF_VLCSLL
         , PSDF_ALIQINSS
         , PSDF_VOLESPEC
         , PSDF_VIATTRANSP
         , PSDF_CDTIPOTITULO
         , PSDF_TPESTOQUE
         , PSDF_VLTOTALCANC
         , PSDF_VLTOTALII
         , PSDF_VBNAOALTERACONTABILIDADE
         , GET_USER_MXM
         , SYSDATE
         , NULL
         , NULL
         , PSDF_TPINDCOMPLEMENTAR
         , PSDF_VLTOTALCOMPLEMENTAR
         , PSDF_CDMUNORIGEM
         , PSDF_CDMUNDEST
         , PSDF_VBCTAPORPROC);
END;
/

CREATE OR REPLACE PROCEDURE ALTSPEDDOCFIS_SDF (PSDF_SQDOCFIS                   IN OUT NUMBER
                                            , PSDF_CDEMPRESA                  IN     CHAR
                                            , PSDF_CDFILIAL                   IN     CHAR
                                            , PSDF_TPOP                       IN     CHAR
                                            , PSDF_MODELO                     IN     CHAR
                                            , PSDF_SERIE                      IN     CHAR
                                            , PSDF_SUBSERIE                   IN     CHAR
                                            , PSDF_EMITENTE                   IN     CHAR
                                            , PSDF_CLIFOR                     IN     CHAR
                                            , PSDF_CDCLIFOR                   IN     CHAR
                                            , PSDF_DOCUMENTO                  IN     CHAR
                                            , PSDF_DATAEMISS                  IN     DATE
                                            , PSDF_DATAENTR                   IN     DATE
                                            , PSDF_DATAESCR                   IN     DATE
                                            , PSDF_SITDOC                     IN     CHAR
                                            , PSDF_VLTOTAL                    IN     NUMBER
                                            , PSDF_CHAVENFE                   IN     CHAR
                                            , PSDF_INDPAG                     IN     CHAR
                                            , PSDF_CLASSECONS                 IN     CHAR
                                            , PSDF_VLBCICMS                   IN     NUMBER
                                            , PSDF_VLICMS                     IN     NUMBER
                                            , PSDF_VLBCICMSST                 IN     NUMBER
                                            , PSDF_VLICMSST                   IN     NUMBER
                                            , PSDF_VLPIS                      IN     NUMBER
                                            , PSDF_VLCOFINS                   IN     NUMBER
                                            , PSDF_VLPISST                    IN     NUMBER
                                            , PSDF_VLCOFINSST                 IN     NUMBER
                                            , PSDF_VLIPI                      IN     NUMBER
                                            , PSDF_VLTOTDESC                  IN     NUMBER
                                            , PSDF_VLESPEC                    IN     NUMBER
                                            , PSDF_VLSERNTRIB                 IN     NUMBER
                                            , PSDF_VLTERCEIROS                IN     NUMBER
                                            , PSDF_VLSEGUROS                  IN     NUMBER
                                            , PSDF_DESPESASAC                 IN     NUMBER
                                            , PSDF_ABATNTRIB                  IN     NUMBER
                                            , PSDF_INDTPFRETE                 IN     CHAR
                                            , PSDF_VLFRETE                    IN     NUMBER
                                            , PSDF_CONTABINF                  IN     NUMBER
                                            , PSDF_IMPOSTOINF                 IN     NUMBER
                                            , PSDF_VLBIICMS                   IN     NUMBER
                                            , PSDF_VLBOICMS                   IN     NUMBER
                                            , PSDF_VLBIIPI                    IN     NUMBER
                                            , PSDF_VLBOIPI                    IN     NUMBER
                                            , PSDF_ISAJUSTE                   IN     NUMBER
                                            , PSDF_CODUTILIZACAO              IN     NUMBER
                                            , PSDF_TPCTE                      IN     CHAR
                                            , PSDF_CHAVECTE                   IN     CHAR
                                            , PSDF_CHAVECTE_REF               IN     CHAR
                                            , PSDF_CDINFCOMP                  IN     CHAR
                                            , PSDF_CONTACTB                   IN     CHAR
                                            , PSDF_VBIMPORTADO                IN     NUMBER
                                            , PSDF_VLSERVNT                   IN     NUMBER
                                            , PSDF_VLBCISSQN                  IN     NUMBER
                                            , PSDF_VLISSQN                    IN     NUMBER
                                            , PSDF_VLBCIRRF                   IN     NUMBER
                                            , PSDF_VLIRRF                     IN     NUMBER
                                            , PSDF_VLBCPREV                   IN     NUMBER
                                            , PSDF_VLPREV                     IN     NUMBER
                                            , PSDF_INDEMITENTE                IN     CHAR
                                            , PSDF_INDTITULO                  IN     CHAR
                                            , PSDF_DESCTITULO                 IN     CHAR
                                            , PSDF_NUMTITULO                  IN     CHAR
                                            , PSDF_QTDPARCELAS                IN     NUMBER
                                            , PSDF_VLTOTALTITULO              IN     NUMBER
                                            , PSDF_CLIFORTRANSP               IN     CHAR
                                            , PSDF_CDCLIFORTRANSP             IN     CHAR
                                            , PSDF_VEICULOID                  IN     CHAR
                                            , PSDF_QTDVOLUME                  IN     NUMBER
                                            , PSDF_PESOBRT                    IN     NUMBER
                                            , PSDF_PESOLIQ                    IN     NUMBER
                                            , PSDF_IDUF                       IN     CHAR
                                            , PSDF_VBIMPORTADOXML             IN     NUMBER
                                            , PSDF_SEGMOEDA                   IN     CHAR
                                            , PSDF_TAXASEGMOEDA               IN     NUMBER
                                            , PSDF_UFOPER                     IN     CHAR
                                            , PSDF_OPER                       IN     CHAR
                                            , PSDF_TPLIGACAO                  IN     CHAR
                                            , PSDF_GRUPOTENSAO                IN     CHAR
                                            , PSDF_TPASSINANTE                IN     CHAR
                                            , PSDF_CDENDCLIFOR                IN     CHAR
                                            , PSDF_SYSTEM                     IN     CHAR
                                            , PSDF_ALIQIRRF                   IN     NUMBER DEFAULT NULL
                                            , PSDF_ALIQCSLL                   IN     NUMBER DEFAULT NULL
                                            , PSDF_BCCSLL                     IN     NUMBER DEFAULT NULL
                                            , PSDF_VLCSLL                     IN     NUMBER DEFAULT NULL
                                            , PSDF_ALIQINSS                   IN     NUMBER DEFAULT NULL
                                            , PSDF_VOLESPEC                   IN     CHAR DEFAULT NULL
                                            , PSDF_VIATTRANSP                 IN     CHAR DEFAULT NULL
                                            , PSDF_CDTIPOTITULO               IN     CHAR DEFAULT NULL
                                            , PSDF_TPESTOQUE                  IN     CHAR DEFAULT NULL
                                            , PSDF_VLTOTALCANC                IN     NUMBER DEFAULT NULL
                                            , PSDF_VLTOTALII                  IN     NUMBER DEFAULT NULL
                                            , PSDF_VBNAOALTERACONTABILIDADE   IN     NUMBER DEFAULT NULL
                                            , PSDF_TPINDCOMPLEMENTAR          IN     CHAR DEFAULT NULL
                                            , PSDF_VLTOTALCOMPLEMENTAR        IN     NUMBER DEFAULT NULL
                                            , PSDF_CDMUNORIGEM IN CHAR DEFAULT NULL
                                            , PSDF_CDMUNDEST IN CHAR DEFAULT NULL
                                            , PSDF_VBCTAPORPROC IN NUMBER DEFAULT 0) AS
BEGIN
   UPDATE SPEDDOCFIS_SDF
      SET SDF_CDEMPRESA                  = PSDF_CDEMPRESA
        , SDF_CDFILIAL                   = PSDF_CDFILIAL
        , SDF_TPOP                       = PSDF_TPOP
        , SDF_MODELO                     = PSDF_MODELO
        , SDF_SERIE                      = PSDF_SERIE
        , SDF_SUBSERIE                   = PSDF_SUBSERIE
        , SDF_EMITENTE                   = PSDF_EMITENTE
        , SDF_CLIFOR                     = PSDF_CLIFOR
        , SDF_CDCLIFOR                   = PSDF_CDCLIFOR
        , SDF_DOCUMENTO                  = PSDF_DOCUMENTO
        , SDF_DATAEMISS                  = PSDF_DATAEMISS
        , SDF_DATAENTR                   = PSDF_DATAENTR
        , SDF_DATAESCR                   = PSDF_DATAESCR
        , SDF_SITDOC                     = PSDF_SITDOC
        , SDF_VLTOTAL                    = PSDF_VLTOTAL
        , SDF_CHAVENFE                   = PSDF_CHAVENFE
        , SDF_INDPAG                     = PSDF_INDPAG
        , SDF_CLASSECONS                 = PSDF_CLASSECONS
        , SDF_VLBCICMS                   = PSDF_VLBCICMS
        , SDF_VLICMS                     = PSDF_VLICMS
        , SDF_VLBCICMSST                 = PSDF_VLBCICMSST
        , SDF_VLICMSST                   = PSDF_VLICMSST
        , SDF_VLPIS                      = PSDF_VLPIS
        , SDF_VLCOFINS                   = PSDF_VLCOFINS
        , SDF_VLPISST                    = PSDF_VLPISST
        , SDF_VLCOFINSST                 = PSDF_VLCOFINSST
        , SDF_VLIPI                      = PSDF_VLIPI
        , SDF_VLTOTDESC                  = PSDF_VLTOTDESC
        , SDF_VLESPEC                    = PSDF_VLESPEC
        , SDF_VLSERNTRIB                 = PSDF_VLSERNTRIB
        , SDF_VLTERCEIROS                = PSDF_VLTERCEIROS
        , SDF_VLSEGUROS                  = PSDF_VLSEGUROS
        , SDF_DESPESASAC                 = PSDF_DESPESASAC
        , SDF_ABATNTRIB                  = PSDF_ABATNTRIB
        , SDF_INDTPFRETE                 = PSDF_INDTPFRETE
        , SDF_VLFRETE                    = PSDF_VLFRETE
        , SDF_CONTABINF                  = PSDF_CONTABINF
        , SDF_IMPOSTOINF                 = PSDF_IMPOSTOINF
        , SDF_VLBIICMS                   = PSDF_VLBIICMS
        , SDF_VLBOICMS                   = PSDF_VLBOICMS
        , SDF_VLBIIPI                    = PSDF_VLBIIPI
        , SDF_VLBOIPI                    = PSDF_VLBOIPI
        , SDF_ISAJUSTE                   = PSDF_ISAJUSTE
        , SDF_CODUTILIZACAO              = PSDF_CODUTILIZACAO
        , SDF_TPCTE                      = PSDF_TPCTE
        , SDF_CHAVECTE                   = PSDF_CHAVECTE
        , SDF_CHAVECTE_REF               = PSDF_CHAVECTE_REF
        , SDF_CDINFCOMP                  = PSDF_CDINFCOMP
        , SDF_CONTACTB                   = PSDF_CONTACTB
        , SDF_VBIMPORTADO                = PSDF_VBIMPORTADO
        , SDF_VLSERVNT                   = PSDF_VLSERVNT
        , SDF_VLBCISSQN                  = PSDF_VLBCISSQN
        , SDF_VLISSQN                    = PSDF_VLISSQN
        , SDF_VLBCIRRF                   = PSDF_VLBCIRRF
        , SDF_VLIRRF                     = PSDF_VLIRRF
        , SDF_VLBCPREV                   = PSDF_VLBCPREV
        , SDF_VLPREV                     = PSDF_VLPREV
        , SDF_INDEMITENTE                = PSDF_INDEMITENTE
        , SDF_INDTITULO                  = PSDF_INDTITULO
        , SDF_DESCTITULO                 = PSDF_DESCTITULO
        , SDF_NUMTITULO                  = PSDF_NUMTITULO
        , SDF_QTDPARCELAS                = PSDF_QTDPARCELAS
        , SDF_VLTOTALTITULO              = PSDF_VLTOTALTITULO
        , SDF_CLIFORTRANSP               = PSDF_CLIFORTRANSP
        , SDF_CDCLIFORTRANSP             = PSDF_CDCLIFORTRANSP
        , SDF_VEICULOID                  = PSDF_VEICULOID
        , SDF_QTDVOLUME                  = PSDF_QTDVOLUME
        , SDF_PESOBRT                    = PSDF_PESOBRT
        , SDF_PESOLIQ                    = PSDF_PESOLIQ
        , SDF_IDUF                       = PSDF_IDUF
        , SDF_VBIMPORTADOXML             = PSDF_VBIMPORTADOXML
        , SDF_SEGMOEDA                   = PSDF_SEGMOEDA
        , SDF_TAXASEGMOEDA               = PSDF_TAXASEGMOEDA
        , SDF_UFOPER                     = PSDF_UFOPER
        , SDF_OPER                       = PSDF_OPER
        , SDF_TPLIGACAO                  = PSDF_TPLIGACAO
        , SDF_GRUPOTENSAO                = PSDF_GRUPOTENSAO
        , SDF_TPASSINANTE                = PSDF_TPASSINANTE
        , SDF_CDENDCLIFOR                = PSDF_CDENDCLIFOR
        , SDF_SYSTEM                     = PSDF_SYSTEM
        , SDF_ALIQIRRF                   = PSDF_ALIQIRRF
        , SDF_ALIQCSLL                   = PSDF_ALIQCSLL
        , SDF_BCCSLL                     = PSDF_BCCSLL
        , SDF_VLCSLL                     = PSDF_VLCSLL
        , SDF_ALIQINSS                   = PSDF_ALIQINSS
        , SDF_VOLESPEC                   = PSDF_VOLESPEC
        , SDF_VIATTRANSP                 = PSDF_VIATTRANSP
        , SDF_CDTIPOTITULO               = PSDF_CDTIPOTITULO
        , SDF_TPESTOQUE                  = PSDF_TPESTOQUE
        , SDF_VLTOTALCANC                = PSDF_VLTOTALCANC
        , SDF_VLTOTALII                  = PSDF_VLTOTALII
        , SDF_VBNAOALTERACONTABILIDADE   = PSDF_VBNAOALTERACONTABILIDADE
        , SDF_USALTERACAO                = GET_USER_MXM
        , SDF_DTALTERACAO                = SYSDATE
        , SDF_TPINDCOMPLEMENTAR          = PSDF_TPINDCOMPLEMENTAR
        , SDF_VLTOTALCOMPLEMENTAR        = PSDF_VLTOTALCOMPLEMENTAR
        , SDF_CDMUNORIGEM =  PSDF_CDMUNORIGEM
        , SDF_CDMUNDEST = PSDF_CDMUNDEST
        , SDF_VBCTAPORPROC = PSDF_VBCTAPORPROC
    WHERE SDF_SQDOCFIS = PSDF_SQDOCFIS;
END;
/

CREATE OR REPLACE PROCEDURE INSSPEDDOCGERACRD_SDGC
(PSDGC_SQDOCGERACRD IN OUT NUMBER,
 PSDGC_CDEMPRESA IN CHAR,
 PSDGC_CDFILIAL IN CHAR,
 PSDGC_DATAOPER IN DATE,
 PSDGC_INDOPER IN NUMBER,
 PSDGC_CLIFOR IN CHAR,
 PSDGC_CDCLIFOR IN CHAR,
 PSDGC_CDENDCLIFOR IN CHAR,
 PSDGC_ITEM IN CHAR,
 PSDGC_VLOPER IN NUMBER,
 PSDGC_INDORIGCRED IN CHAR,
 PSDGC_CSTPIS IN CHAR,
 PSDGC_VLBCPIS IN NUMBER,
 PSDGC_ALIQPIS IN NUMBER,
 PSDGC_VLPIS IN NUMBER,
 PSDGC_CSTCOFINS IN CHAR,
 PSDGC_VLBCCOFINS IN NUMBER,
 PSDGC_ALIQCOFINS IN NUMBER,
 PSDGC_VLCOFINS IN NUMBER,
 PSDGC_NATBCCRED IN CHAR,
 PSDGC_CODPLANO IN CHAR,
 PSDGC_NOCONTAB IN CHAR,
 PSDGC_CODCENT IN CHAR,
 PSDGC_CODCCUSTO IN CHAR,
 PSDGC_DESCDOCOPER IN CHAR,
 PSDGC_SITDOCOPER IN CHAR,
 PSDGC_DATAESCR IN DATE,
 PSDGC_CDTPOPER IN CHAR,
 PSDGC_VBCONTABINF IN NUMBER,
 PSDGC_NRATIVSUJCONTRIBRECBRU IN NUMBER DEFAULT NULL,
 PSDGC_NRTITRECIBO IN CHAR DEFAULT NULL,
 PSDGC_TPPAGAMENTO IN CHAR DEFAULT NULL,
 PSDGC_CDSISTEMA IN CHAR DEFAULT NULL,
 PSDGC_VBCTAPORPROC IN NUMBER DEFAULT 0
)
AS
BEGIN
IF PSDGC_SQDOCGERACRD IS NULL THEN
 SELECT SEQ_SDGC_SQDOCGERACRD.NEXTVAL INTO PSDGC_SQDOCGERACRD FROM DUAL;
END IF;
  INSERT INTO SPEDDOCGERACRD_SDGC(
      SDGC_SQDOCGERACRD,
      SDGC_CDEMPRESA,
      SDGC_CDFILIAL,
      SDGC_DATAOPER,
      SDGC_INDOPER,
      SDGC_CLIFOR,
      SDGC_CDCLIFOR,
      SDGC_CDENDCLIFOR,
      SDGC_ITEM,
      SDGC_VLOPER,
      SDGC_INDORIGCRED,
      SDGC_CSTPIS,
      SDGC_VLBCPIS,
      SDGC_ALIQPIS,
      SDGC_VLPIS,
      SDGC_CSTCOFINS,
      SDGC_VLBCCOFINS,
      SDGC_ALIQCOFINS,
      SDGC_VLCOFINS,
      SDGC_NATBCCRED,
      SDGC_CODPLANO,
      SDGC_NOCONTAB,
      SDGC_CODCENT,
      SDGC_CODCCUSTO,
      SDGC_DESCDOCOPER,
      SDGC_SITDOCOPER,
      SDGC_DATAESCR,
      SDGC_CDTPOPER,
      SDGC_VBCONTABINF,
      SDGC_NRATIVSUJCONTRIBRECBRU,
      SDGC_NRTITRECIBO,
      SDGC_TPPAGAMENTO,
      SDGC_CDSISTEMA,
      SDGC_USINCLUSAO,
      SDGC_DTINCLUSAO,
      SDGC_USALTERACAO,
      SDGC_DTALTERACAO,
      SDGC_VBCTAPORPROC
) VALUES (
      PSDGC_SQDOCGERACRD,
      PSDGC_CDEMPRESA,
      PSDGC_CDFILIAL,
      PSDGC_DATAOPER,
      PSDGC_INDOPER,
      PSDGC_CLIFOR,
      PSDGC_CDCLIFOR,
      PSDGC_CDENDCLIFOR,
      PSDGC_ITEM,
      PSDGC_VLOPER,
      PSDGC_INDORIGCRED,
      PSDGC_CSTPIS,
      PSDGC_VLBCPIS,
      PSDGC_ALIQPIS,
      PSDGC_VLPIS,
      PSDGC_CSTCOFINS,
      PSDGC_VLBCCOFINS,
      PSDGC_ALIQCOFINS,
      PSDGC_VLCOFINS,
      PSDGC_NATBCCRED,
      PSDGC_CODPLANO,
      PSDGC_NOCONTAB,
      PSDGC_CODCENT,
      PSDGC_CODCCUSTO,
      PSDGC_DESCDOCOPER,
      PSDGC_SITDOCOPER,
      PSDGC_DATAESCR,
      PSDGC_CDTPOPER,
      PSDGC_VBCONTABINF,
      PSDGC_NRATIVSUJCONTRIBRECBRU,
      PSDGC_NRTITRECIBO,
      PSDGC_TPPAGAMENTO,
      PSDGC_CDSISTEMA,
      USER,
      SYSDATE,
      NULL,
      NULL,
      PSDGC_VBCTAPORPROC
);
END;
/

CREATE OR REPLACE PROCEDURE ALTSPEDDOCGERACRD_SDGC
(PSDGC_SQDOCGERACRD IN OUT NUMBER,
 PSDGC_CDEMPRESA IN CHAR,
 PSDGC_CDFILIAL IN CHAR,
 PSDGC_DATAOPER IN DATE,
 PSDGC_INDOPER IN NUMBER,
 PSDGC_CLIFOR IN CHAR,
 PSDGC_CDCLIFOR IN CHAR,
 PSDGC_CDENDCLIFOR IN CHAR,
 PSDGC_ITEM IN CHAR,
 PSDGC_VLOPER IN NUMBER,
 PSDGC_INDORIGCRED IN CHAR,
 PSDGC_CSTPIS IN CHAR,
 PSDGC_VLBCPIS IN NUMBER,
 PSDGC_ALIQPIS IN NUMBER,
 PSDGC_VLPIS IN NUMBER,
 PSDGC_CSTCOFINS IN CHAR,
 PSDGC_VLBCCOFINS IN NUMBER,
 PSDGC_ALIQCOFINS IN NUMBER,
 PSDGC_VLCOFINS IN NUMBER,
 PSDGC_NATBCCRED IN CHAR,
 PSDGC_CODPLANO IN CHAR,
 PSDGC_NOCONTAB IN CHAR,
 PSDGC_CODCENT IN CHAR,
 PSDGC_CODCCUSTO IN CHAR,
 PSDGC_DESCDOCOPER IN CHAR,
 PSDGC_SITDOCOPER IN CHAR,
 PSDGC_DATAESCR IN DATE,
 PSDGC_CDTPOPER IN CHAR,
 PSDGC_VBCONTABINF IN NUMBER,
 PSDGC_NRATIVSUJCONTRIBRECBRU IN NUMBER DEFAULT NULL,
 PSDGC_NRTITRECIBO IN CHAR DEFAULT NULL,
 PSDGC_TPPAGAMENTO IN CHAR DEFAULT NULL,
 PSDGC_CDSISTEMA IN CHAR,
 PSDGC_VBCTAPORPROC NUMBER DEFAULT 0
)
AS
BEGIN
  UPDATE SPEDDOCGERACRD_SDGC
   SET SDGC_CDEMPRESA = PSDGC_CDEMPRESA,
       SDGC_CDFILIAL = PSDGC_CDFILIAL,
       SDGC_DATAOPER = PSDGC_DATAOPER,
       SDGC_INDOPER = PSDGC_INDOPER,
       SDGC_CLIFOR = PSDGC_CLIFOR,
       SDGC_CDCLIFOR = PSDGC_CDCLIFOR,
       SDGC_CDENDCLIFOR = PSDGC_CDENDCLIFOR,
       SDGC_ITEM = PSDGC_ITEM,
       SDGC_VLOPER = PSDGC_VLOPER,
       SDGC_INDORIGCRED = PSDGC_INDORIGCRED,
       SDGC_CSTPIS = PSDGC_CSTPIS,
       SDGC_VLBCPIS = PSDGC_VLBCPIS,
       SDGC_ALIQPIS = PSDGC_ALIQPIS,
       SDGC_VLPIS = PSDGC_VLPIS,
       SDGC_CSTCOFINS = PSDGC_CSTCOFINS,
       SDGC_VLBCCOFINS = PSDGC_VLBCCOFINS,
       SDGC_ALIQCOFINS = PSDGC_ALIQCOFINS,
       SDGC_VLCOFINS = PSDGC_VLCOFINS,
       SDGC_NATBCCRED = PSDGC_NATBCCRED,
       SDGC_CODPLANO = PSDGC_CODPLANO,
       SDGC_NOCONTAB = PSDGC_NOCONTAB,
       SDGC_CODCENT = PSDGC_CODCENT,
       SDGC_CODCCUSTO = PSDGC_CODCCUSTO,
       SDGC_DESCDOCOPER = PSDGC_DESCDOCOPER,
       SDGC_SITDOCOPER = PSDGC_SITDOCOPER,
       SDGC_DATAESCR = PSDGC_DATAESCR,
       SDGC_CDTPOPER = PSDGC_CDTPOPER,
       SDGC_VBCONTABINF = PSDGC_VBCONTABINF,
       SDGC_NRATIVSUJCONTRIBRECBRU = PSDGC_NRATIVSUJCONTRIBRECBRU,
       SDGC_NRTITRECIBO = PSDGC_NRTITRECIBO,
       SDGC_TPPAGAMENTO = PSDGC_TPPAGAMENTO,
       SDGC_CDSISTEMA = PSDGC_CDSISTEMA,
       SDGC_USALTERACAO = GET_USER_MXM,
       SDGC_DTALTERACAO = SYSDATE,
       SDGC_VBCTAPORPROC = PSDGC_VBCTAPORPROC
   WHERE SDGC_SQDOCGERACRD = PSDGC_SQDOCGERACRD;
END;
/

CREATE OR REPLACE FUNCTION GET_CONTACONTABILESCRITURA
(PT_CDEMPRESA  IN CHAR,
PT_CDFILIAL   IN CHAR DEFAULT NULL,
PT_CDESTOQUE  IN CHAR DEFAULT NULL,
PT_CDPRODSERV IN CHAR DEFAULT NULL,
PT_OPERACAO IN CHAR, 
PT_TPOPERACAO IN CHAR,
PT_GRUPO     IN CHAR DEFAULT NULL, 
PT_CDPARTICIPANTE IN CHAR DEFAULT NULL, 
PT_TPPARTICIPANTE IN CHAR DEFAULT NULL)
RETURN CHAR 
IS 
  VR_CONTACTB      SPEDDOCFIS_SDF.SDF_CONTACTB%TYPE;
  VR_GRUPOPAGREC   PARAMCUSREC_PCR.PCR_GRUPO%TYPE;
    
  FUNCTION GET_CONTA_GRUPOPAGREC(PT_CDGRUPO IN CHAR, PT_OPERACAO IN CHAR)
    RETURN CHAR IS
    VR_CONTACONTABIL VARCHAR2(15);
    CURSOR CS_GET_CONTA_GRPAG IS
      SELECT GPA_CTBGRUPO FROM GRPAG_GPA WHERE GPA_CDGRUPO = PT_CDGRUPO;
  
    CURSOR CS_GET_CONTA_GRREC IS
      SELECT GRE_CTBGRUPO FROM GRREC_GRE WHERE GRE_CDGRUPO = PT_CDGRUPO;
  BEGIN
    IF PT_OPERACAO = 'S' THEN
      BEGIN
        FOR REC_CONTA_GRREC IN CS_GET_CONTA_GRREC LOOP
          BEGIN
            VR_CONTACONTABIL := REC_CONTA_GRREC.GRE_CTBGRUPO;
          END;
        END LOOP;
      END;
    ELSE
      BEGIN
        FOR REC_CONTA_GRPAG IN CS_GET_CONTA_GRPAG LOOP
          BEGIN
            VR_CONTACONTABIL := REC_CONTA_GRPAG.GPA_CTBGRUPO;
          END;
        END LOOP;
      END;
    END IF;
  
    RETURN(VR_CONTACONTABIL);
  END;


  FUNCTION GET_CONTA_GRUPO_PARTICIPANTE (PTPCLIFOR IN CHAR, PCDPARTICIPANTE IN CHAR, PCDEMPRESA IN CHAR, PCDFILIAL IN CHAR) RETURN CHAR IS 
    VR_CONTACONTABIL VARCHAR2(15);
    VR_CONTADOR NUMBER(9);
    CURSOR CS_GET_CONTA_GRPAG IS
  SELECT FGI_CODEMP, FGI_CODFOR, GPA_CTBGRUPO FROM ( 
  SELECT FGI_CODEMP, FGI_CODFOR, GPA_CTBGRUPO, MIN(ORDEM) ORDEM, COUNT(1) AS QTD
    FROM (SELECT  CASE WHEN FGI_CODFILIAL IS NOT NULL AND FGI_CODMOEDA IS NOT NULL AND SPCC_CODNAT = '04' THEN 1 
                                     WHEN FGI_CODFILIAL IS NOT NULL AND SPCC_CODNAT = '04'THEN 2 
                                     WHEN FGI_CODMOEDA IS NOT NULL AND SPCC_CODNAT = '04' THEN 3 
                                     WHEN FGI_CODFILIAL IS NOT NULL AND FGI_CODMOEDA IS NOT NULL  THEN 4 
                                     WHEN FGI_CODFILIAL IS NOT NULL THEN 5 
                                     WHEN FGI_CODMOEDA IS NOT NULL THEN 6        
                                     ELSE 7
                                   END ORDEM, 
                    FGI.FGI_CODEMP, FGI.FGI_CODFOR, FGI.FGI_CODFILIAL, FGI_CODMOEDA
                   ,GPA.GPA_CTBGRUPO, SPCC_CODNAT
                  FROM FGPAGIR_FGI FGI, GRPAG_GPA GPA, EMPGERAL_EMP EMP, SPEDPARCCONTAB_SPCC SPCC
                WHERE FGI.FGI_CODEMP = EMP.EMP_CODIGO 
                    AND FGI.FGI_CODGRPAG = GPA.GPA_CDGRUPO
                    AND GPA.GPA_CTBGRUPO = SPCC.SPCC_NOCONTAB(+)
                    AND (EMP.EMP_CODPLCONTA = SPCC.SPCC_PLCONTAB  OR SPCC.SPCC_PLCONTAB IS NULL)                      
                    AND FGI.FGI_CODEMP = PCDEMPRESA
                    AND FGI.FGI_CODFOR = PCDPARTICIPANTE
                    AND (FGI.FGI_CODFILIAL = PCDFILIAL OR FGI_CODFILIAL IS NULL)
                    AND (FGI_CODMOEDA = EMP.EMP_MOEDACOR OR FGI_CODMOEDA IS NULL)
                GROUP BY FGI.FGI_CODEMP, FGI.FGI_CODFOR, FGI.FGI_CODFILIAL, FGI_CODMOEDA, GPA.GPA_CTBGRUPO, SPCC_CODNAT    
                ORDER BY ORDEM ASC)
                GROUP BY FGI_CODEMP, FGI_CODFOR, GPA_CTBGRUPO
        ORDER BY QTD DESC, ORDEM ASC) WHERE ROWNUM = 1; 
  
    CURSOR CS_GET_CONTA_GRREC IS
     SELECT CGI_CODEMP, CGI_CODFOR, GRE_CTBGRUPO FROM (   
      SELECT CGI_CODEMP, CGI_CODFOR, GRE_CTBGRUPO, MIN(ORDEM) ORDEM, COUNT(1) AS QTD
        FROM (
        SELECT 
          CASE WHEN CGI_CODFILIAL IS NOT NULL AND CGI_CODMOEDA IS NOT NULL AND SPCC_CODNAT = '04' THEN 1 
               WHEN CGI_CODFILIAL IS NOT NULL AND SPCC_CODNAT = '04' THEN 2 
               WHEN CGI_CODMOEDA IS NOT NULL AND SPCC_CODNAT = '04' THEN 3 
               WHEN CGI_CODFILIAL IS NOT NULL AND CGI_CODMOEDA IS NOT NULL THEN 4 
               WHEN CGI_CODFILIAL IS NOT NULL THEN 5 
               WHEN CGI_CODMOEDA IS NOT NULL THEN 6 
               ELSE 7
           END ORDEM,
            CGI.CGI_CODEMP, CGI.CGI_CODFOR,  CGI.CGI_CODFILIAL, CGI_CODMOEDA
           ,GRE.GRE_CTBGRUPO
          FROM CGRECIR_CGI CGI, GRREC_GRE GRE, EMPGERAL_EMP EMP, SPEDPARCCONTAB_SPCC SPCC
        WHERE CGI.CGI_CODEMP = EMP.EMP_CODIGO 
            AND CGI.CGI_CODGRPAG = GRE.GRE_CDGRUPO
            AND GRE.GRE_CTBGRUPO = SPCC.SPCC_NOCONTAB(+)
            AND (EMP.EMP_CODPLCONTA = SPCC.SPCC_PLCONTAB  OR SPCC.SPCC_PLCONTAB IS NULL)                
            AND CGI.CGI_CODEMP = PCDEMPRESA
            AND CGI.CGI_CODFOR = PCDPARTICIPANTE
            AND (CGI.CGI_CODFILIAL = PCDFILIAL OR CGI_CODFILIAL IS NULL)
            AND (CGI_CODMOEDA = EMP.EMP_MOEDACOR OR CGI_CODMOEDA IS NULL)
        GROUP BY CGI.CGI_CODEMP, CGI.CGI_CODFOR, CGI.CGI_CODFILIAL, CGI_CODMOEDA, GRE.GRE_CTBGRUPO, SPCC_CODNAT     
        ORDER BY ORDEM ASC)
        GROUP BY CGI_CODEMP, CGI_CODFOR, GRE_CTBGRUPO
        ORDER BY QTD DESC, ORDEM ASC) WHERE ROWNUM = 1; 
         
  BEGIN
   VR_CONTADOR := 0; 
   
    IF PTPCLIFOR = 'C' THEN
      BEGIN
        FOR REC_CONTA_GRREC IN CS_GET_CONTA_GRREC LOOP
          BEGIN
            VR_CONTACONTABIL := REC_CONTA_GRREC.GRE_CTBGRUPO;
            
            VR_CONTADOR := VR_CONTADOR + 1; 
            
            IF VR_CONTADOR > 1 
             THEN BEGIN VR_CONTACONTABIL := ''; END; END IF; 
          END;
        END LOOP;
      END;
    ELSE
      BEGIN
        FOR REC_CONTA_GRPAG IN CS_GET_CONTA_GRPAG LOOP
          BEGIN
            VR_CONTACONTABIL := REC_CONTA_GRPAG.GPA_CTBGRUPO;
            
            VR_CONTADOR := VR_CONTADOR + 1; 
            
            IF VR_CONTADOR > 1 
             THEN BEGIN VR_CONTACONTABIL := ''; END; END IF; 
           
          END;
        END LOOP;
      END;
    END IF;
  
    RETURN(VR_CONTACONTABIL);
  END;


  PROCEDURE GET_CONTACONTABILITEM(PT_CDEMPRESA  IN CHAR,
                                  PT_CDESTOQUE  IN CHAR,
                                  PT_CDPRODSERV IN CHAR,
                                  PT_TPOPERACAO IN CHAR,
                                  PT_CDFILIAL   IN CHAR,
                                  PT_CONTA      IN OUT CHAR,
                                  PT_GRUPO      IN OUT CHAR,
                                  PT_TIPO       IN CHAR) IS
  
    VR_GRUPOPRODSERV         VARCHAR2(15);
    VR_TIPOPRODSERV          VARCHAR2(2);
    VR_GRUPOSUPERIORPRODSERV VARCHAR2(15);
    VR_QRY_CONTAITEM         LONG;
    CS_CONTAITEM             SYS_REFCURSOR;
    CURSOR CS_GET_GRUPOSUPERIOR IS
      SELECT GRT_NOSUP
        FROM GRPTIP_GRT
       WHERE GRT_TPPROD = VR_TIPOPRODSERV
         AND GRT_CODIGO = VR_GRUPOPRODSERV;
    CURSOR CS_GET_DADOSPRODSERV IS
      SELECT PRD_GRUPO, PRD_TPPROD
        FROM PRODUTO_PRD
       WHERE PRD_ITEM = PT_CDPRODSERV;
  BEGIN
    FOR REC_DADOSPRODSERV IN CS_GET_DADOSPRODSERV LOOP
      BEGIN
        VR_GRUPOPRODSERV := REC_DADOSPRODSERV.PRD_GRUPO;
        VR_TIPOPRODSERV  := REC_DADOSPRODSERV.PRD_TPPROD;
      END;
    END LOOP;
    FOR REC_GRUPOSUPERIOR IN CS_GET_GRUPOSUPERIOR LOOP
      BEGIN
        VR_GRUPOSUPERIORPRODSERV := REC_GRUPOSUPERIOR.GRT_NOSUP;
      END;
    END LOOP;
    VR_QRY_CONTAITEM := '';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  ' SELECT TRIM(PCR_CNTCUSTO), TRIM(PCR_GRUPO)                        ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '  FROM (SELECT CASE                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '              WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                       (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                       (PCR_GRTPPROD <> '' '') AND (PCR_PRODUTO <> '' '')           ';
    
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                AND (PCR_GRTPPROD = ''' ||  VR_GRUPOPRODSERV || ''')         ';
    END IF;
    
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                  THEN 1                                                           ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '              WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                        (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                        (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                 THEN 2                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '              WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                        (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD = '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                        (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO <> '' '')        ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                 THEN 3                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '              WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                         (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD = '' '') AND       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                         (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO <> '' '')        ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                 THEN 4                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '               WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                         (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                         (PCR_GRTPPROD <> '' '')                                      ';
    
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                AND (PCR_GRTPPROD = ''' ||   VR_GRUPOPRODSERV || ''')         ';
    END IF;
    
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       AND (PCR_PRODUTO = '' '')                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN 5                                                                ';
   
   IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      BEGIN
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '             WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       (PCR_GRTPPROD = ''' ||  VR_GRUPOSUPERIORPRODSERV || ''') AND  ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       (PCR_PRODUTO = '' '')                                    ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 THEN 6                                                                ';
      END;
    END IF;

    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      THEN  7                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD <> '' '') AND (PCR_PRODUTO <> '' '')       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      THEN 8                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD <> '' '')                                      ';
    
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                AND (PCR_GRTPPROD = ''' || VR_GRUPOPRODSERV || ''')         ';
    END IF;
    
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       AND (PCR_PRODUTO = '' '')                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 THEN 9                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '') ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  THEN  10             ';
    
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      BEGIN
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '            WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') <> '' '') AND (PCR_TPOPER IS NOT NULL) AND    ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND       ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD <> '' '') AND (PCR_GRTPPROD = ''' || VR_GRUPOSUPERIORPRODSERV || ''') AND ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_PRODUTO = '' '')                                                           ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '               THEN 11                                                                                      ';
      END;
    END IF;

    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD = '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN 12                                                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD = '' '') AND       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN 13                                                               ';
  
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD <> '' '') AND (PCR_PRODUTO <> '' '')           ';
    
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                AND (PCR_GRTPPROD = ''' || VR_GRUPOPRODSERV || ''')         ';
    END IF;
    
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN 14                                                           ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN 15                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD = '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO <> '' '')        ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN  16                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD = '' '') AND       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO <> '' '')        ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                   THEN 17                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD <> '' '')                                      ';
    
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  AND (PCR_GRTPPROD = ''' ||  VR_GRUPOPRODSERV || ''')         ';
    END IF;
    
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    AND (PCR_PRODUTO = '' '')                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN 18                                                                ';
    
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      BEGIN
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '             WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                      (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                      (PCR_GRTPPROD = ''' ||  VR_GRUPOSUPERIORPRODSERV || ''') AND  ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '                      (PCR_PRODUTO = '' '')                                    ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM ||  '               THEN 19                                                                ';
      END;
    END IF;
    
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD <> '' '') AND     ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN 20                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD <> '' '') AND (PCR_PRODUTO <> '' '')       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN 21                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD <> '' '')                                      ';
    
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                AND (PCR_GRTPPROD = ''' ||  VR_GRUPOPRODSERV || ''')         ';
    END IF;
    
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                       AND (PCR_PRODUTO = '' '')                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN 22                                                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                    THEN  23 ';
    
    IF VR_GRUPOSUPERIORPRODSERV IS NOT NULL THEN
      BEGIN
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '            WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND    ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD <> '' '') AND       ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 (PCR_GRTPPROD <> '' '') AND (PCR_GRTPPROD = ''' || VR_GRUPOSUPERIORPRODSERV || ''') AND ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 (PCR_PRODUTO = '' '')                                                           ';
        VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '             THEN 24                                                                                      ';
      END;
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_TPESTOQUE <> '' '') AND (PCR_TIPOPROD = '' '') AND      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                      (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 THEN 25                                                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 WHEN (PCR_EMPRESA IS NOT NULL) AND (NVL(PCR_CDFILIAL,'' '') = '' '') AND (PCR_TPOPER IS NOT NULL) AND   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_TPESTOQUE = '' '') AND (PCR_TIPOPROD = '' '') AND       ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                           (PCR_GRTPPROD = '' '') AND (PCR_PRODUTO = '' '')         ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 THEN 26                                                               ';
  
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                 ELSE                                                              ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  1000                                                             ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '               END ORDEM,                                                          ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '               PCR_CNTCUSTO, TPO_TIPO, PCR_GRUPO                                   ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '          FROM PARAMCUSREC_PCR, TPOPER_TPO WHERE TPO_CODIGO = PCR_TPOPER           ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND PCR_EMPRESA = ''' || PT_CDEMPRESA || '''                             ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND PCR_TPOPER =  ''' || PT_TPOPERACAO || '''                            ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND (                                                                   ';
    
    IF PT_CDESTOQUE IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '         NVL(PCR_TPESTOQUE, '' '') = ''' ||  PT_CDESTOQUE || ''' OR                      ';
    END IF;
    
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                NVL(PCR_TPESTOQUE, '' '') = '' '')                                 ';
  
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND (                                                                   ';
    
    IF PT_CDFILIAL IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '         NVL(PCR_CDFILIAL, '' '') = ''' || PT_CDFILIAL || ''' OR                      ';
    END IF;
    
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                NVL(PCR_CDFILIAL, '' '') = '' '')                                             ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND (                                                                   ';
    
    IF VR_TIPOPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '         NVL(PCR_TIPOPROD, '' '') = ''' || VR_TIPOPRODSERV || ''' OR                    ';
    END IF;
    
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                NVL(PCR_TIPOPROD, '' '') = '' '')                                              ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND (                                                                   ';
    
    IF PT_CDPRODSERV IS NOT NULL THEN
      VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '         NVL(PCR_PRODUTO, '' '') = ''' || PT_CDPRODSERV || ''' OR                       ';
    END IF;
    
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                NVL(PCR_PRODUTO, '' '') = '' '')                                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '           AND (                                                                   ';
    
    IF VR_GRUPOPRODSERV IS NOT NULL THEN
      BEGIN
        IF VR_GRUPOSUPERIORPRODSERV IS NULL THEN
          VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '     NVL(PCR_GRTPPROD, '' '') = ''' || VR_GRUPOPRODSERV || ''' OR                       ';
        ELSE
          VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '     ((NVL(PCR_GRTPPROD, '' '') = ''' || VR_GRUPOPRODSERV || ''') OR (NVL(PCR_GRTPPROD, '' '') = ''' || VR_GRUPOSUPERIORPRODSERV || ''')) OR ';
        END IF;
      END;
    END IF;
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                NVL(PCR_GRTPPROD, '' '') = '' '')                                  ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '         ORDER BY ORDEM,                                                           ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  PCR_EMPRESA, TPO_TIPO,                                           ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  DECODE(NVL(PCR_CDFILIAL,'' ''), '' '', 1, 0),                    ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  PCR_TPOPER,                                                      ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  DECODE(PCR_PRODUTO, '' '', 1, 0),                                ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  DECODE(PCR_GRTPPROD, '' '', 1, 0),                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  DECODE(PCR_TIPOPROD, '' '', 1, 0),                               ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || '                  DECODE(PCR_TPESTOQUE, '' '', 1, 0)) A                            ';
    VR_QRY_CONTAITEM := VR_QRY_CONTAITEM || ' WHERE ROWNUM = 1                                                                  ';

   OPEN CS_CONTAITEM FOR VR_QRY_CONTAITEM;
    LOOP
      FETCH CS_CONTAITEM
        INTO PT_CONTA, PT_GRUPO;
      EXIT WHEN CS_CONTAITEM%NOTFOUND;
    END LOOP;
    CLOSE CS_CONTAITEM;
  END;

BEGIN
   
   GET_CONTACONTABILITEM(PT_CDEMPRESA,
                                  PT_CDESTOQUE,
                                  PT_CDPRODSERV,
                                  PT_TPOPERACAO,
                                  PT_CDFILIAL,
                                  VR_CONTACTB,
                                  VR_GRUPOPAGREC,
                                  PT_OPERACAO);


      IF TRIM(PT_GRUPO) IS NOT NULL
       THEN VR_GRUPOPAGREC := TRIM(PT_GRUPO); END IF;
          
      IF TRIM(VR_CONTACTB) IS NULL AND TRIM(VR_GRUPOPAGREC) IS NOT NULL THEN
        BEGIN
          VR_CONTACTB := GET_CONTA_GRUPOPAGREC(TRIM(VR_GRUPOPAGREC), TRIM(PT_OPERACAO));
        END;
      END IF;
      
      IF TRIM(VR_CONTACTB) IS NULL AND TRIM(VR_GRUPOPAGREC) IS NULL THEN
        BEGIN
          VR_CONTACTB := GET_CONTA_GRUPO_PARTICIPANTE (PT_TPPARTICIPANTE, PT_CDPARTICIPANTE, PT_CDEMPRESA, PT_CDFILIAL);
        END;
      END IF;       
   
  RETURN(TRIM(VR_CONTACTB));
END;
/

CREATE OR REPLACE VIEW VW_DOCUMENTOSSEMCONTACONTABIL AS
SELECT
TBL.*, GET_CONTACONTABILESCRITURA(CDEMPRESA,CDFILIAL   ,CDESTOQUE  ,CDPRODSERV ,OPERACAO ,TPOPERACAO,CDGRPPAGREC ,PARTICIPANTE,TPCLIFOR) CONTACONTABIL
 FROM
(
    SELECT S.SDF_SYSTEM AS SISTEMA,
                S.SDF_CDEMPRESA AS CDEMPRESA,
                S.SDF_CDFILIAL   AS CDFILIAL,
                S.SDF_MODELO AS MODELO,
               '0' AS TPDOCFIS,
               NVL(S.SDF_TPESTOQUE,
                      CASE WHEN S.SDF_SYSTEM = 'SF' THEN (SELECT FAT_TPESTOQUE  FROM FATURAS_FAT FAT, INTMODFAT_IMF IMF, INTMODSDF_IMS IMS
                                                                                    WHERE FAT.FAT_CDEMPRESA = IMF.IMF_CDEMPRESA
                                                                                        AND FAT.FAT_CDFILIAL = IMF.IMF_CDFILIAL
                                                                                        AND FAT.FAT_CDFATURA = IMF.IMF_CDFATURA
                                                                                        AND IMF.IMF_SQINTEGRACAO = IMS.IMS_SQINTEGRACAO
                                                                                        AND IMS.IMS_SQDOCFIS = S.SDF_SQDOCFIS)   END
                   ) AS CDESTOQUE,
                S.SDF_SQDOCFIS   AS IDDOCFIS,
                I.IDF_SQITDOCFIS AS IDITEM,
                TPO.TPO_TIPO  AS OPERACAO,
                I.IDF_TPOP       AS TPOPERACAO,
                TPO.TPO_DESCRICAO AS DSTPOPERACAO,
                NULL AS CDGRPPAGREC,
                I.IDF_ITEM       AS CDPRODSERV,
                PRD.PRD_DESCRICAO DSPRODSERV ,
                I.IDF_CFOP AS CFOP,
               S.SDF_DOCUMENTO AS DOCUMENTO,
               S.SDF_CLIFOR AS TPCLIFOR ,
               S.SDF_CDCLIFOR AS PARTICIPANTE,
               S.SDF_DATAESCR AS DATAESCRITURACAO
      FROM SPEDDOCFIS_SDF S, SPEDITDOCFIS_IDF I, TPOPER_TPO TPO, PRODUTO_PRD PRD
     WHERE S.SDF_SQDOCFIS = I.IDF_SQDOCFIS
       AND I.IDF_TPOP = TPO.TPO_CODIGO
       AND I.IDF_ITEM = PRD.PRD_ITEM
       AND TRIM(I.IDF_NOCONTAB) IS NULL
       AND S.SDF_MODELO NOT IN  ('07', '08', '09', '10', '11', '26', '57', '27', '67')
       AND S.SDF_EMITENTE = 'P'
--       AND TPO.TPO_NRECPISCOFINS = 'N'
UNION
    SELECT S.SDF_SYSTEM AS SISTEMA,
                S.SDF_CDEMPRESA AS CDEMPRESA,
                S.SDF_CDFILIAL   AS CDFILIAL,
                S.SDF_MODELO AS MODELO,
               '0' AS TPDOCFIS,
               NVL(S.SDF_TPESTOQUE,
                      CASE WHEN S.SDF_SYSTEM = 'SF' THEN (SELECT FAT_TPESTOQUE  FROM FATURAS_FAT FAT, INTMODFAT_IMF IMF, INTMODSDF_IMS IMS
                                                                                    WHERE FAT.FAT_CDEMPRESA = IMF.IMF_CDEMPRESA
                                                                                        AND FAT.FAT_CDFILIAL = IMF.IMF_CDFILIAL
                                                                                        AND FAT.FAT_CDFATURA = IMF.IMF_CDFATURA
                                                                                        AND IMF.IMF_SQINTEGRACAO = IMS.IMS_SQINTEGRACAO
                                                                                        AND IMS.IMS_SQDOCFIS = S.SDF_SQDOCFIS)   END
                   ) AS CDESTOQUE,
                S.SDF_SQDOCFIS   AS IDDOCFIS,
                I.IDF_SQITDOCFIS AS IDITEM,
                TPO.TPO_TIPO  AS OPERACAO,
                I.IDF_TPOP       AS TPOPERACAO,
                TPO.TPO_DESCRICAO AS DSTPOPERACAO,
                NULL AS CDGRPPAGREC,
                I.IDF_ITEM       AS CDPRODSERV,
                PRD.PRD_DESCRICAO,
                I.IDF_CFOP AS CFOP,
               S.SDF_DOCUMENTO AS DOCUMENTO,
               S.SDF_CLIFOR AS TPCLIFOR ,
               S.SDF_CDCLIFOR AS PARTICIPANTE,
               S.SDF_DATAESCR AS DATAESCRITURACAO
      FROM SPEDDOCFIS_SDF S, SPEDITDOCFIS_IDF I, TPOPER_TPO TPO, PRODUTO_PRD PRD
     WHERE S.SDF_SQDOCFIS = I.IDF_SQDOCFIS
       AND I.IDF_TPOP = TPO.TPO_CODIGO
       AND TRIM(I.IDF_NOCONTAB) IS NULL
       AND S.SDF_MODELO NOT IN  ('07', '08', '09', '10', '11', '26', '57', '27', '67')
       AND S.SDF_EMITENTE = 'T'
       AND I.IDF_ITEM = PRD.PRD_ITEM
  --     AND  (SELECT SUM(I2.IDF_VLBCPIS + I2.IDF_VLBCCOFINS) FROM SPEDITDOCFIS_IDF I2 WHERE I2.IDF_SQDOCFIS = I.IDF_SQDOCFIS) > 0
UNION
    SELECT S.SDF_SYSTEM AS SISTEMA,
                S.SDF_CDEMPRESA AS CDEMPRESA,
                S.SDF_CDFILIAL   AS CDFILIAL,
                S.SDF_MODELO AS MODELO,
               '0' AS TPDOCFIS,
               NVL(S.SDF_TPESTOQUE,
                      CASE WHEN S.SDF_SYSTEM = 'SF' THEN (SELECT FAT_TPESTOQUE  FROM FATURAS_FAT FAT, INTMODFAT_IMF IMF, INTMODSDF_IMS IMS
                                                                                    WHERE FAT.FAT_CDEMPRESA = IMF.IMF_CDEMPRESA
                                                                                        AND FAT.FAT_CDFILIAL = IMF.IMF_CDFILIAL
                                                                                        AND FAT.FAT_CDFATURA = IMF.IMF_CDFATURA
                                                                                        AND IMF.IMF_SQINTEGRACAO = IMS.IMS_SQINTEGRACAO
                                                                                        AND IMS.IMS_SQDOCFIS = S.SDF_SQDOCFIS)   END
                   ) AS CDESTOQUE,
                S.SDF_SQDOCFIS   AS IDDOCFIS,
                I.IDF_SQITDOCFIS AS IDITEM,
                TPO.TPO_TIPO  AS OPERACAO,
                I.IDF_TPOP       AS TPOPERACAO,
                TPO.TPO_DESCRICAO AS DSTPOPERACAO,
                NULL AS CDGRPPAGREC,
                I.IDF_ITEM       AS CDPRODSERV,
                PRD.PRD_DESCRICAO,
                I.IDF_CFOP AS CFOP,
               S.SDF_DOCUMENTO AS DOCUMENTO,
               S.SDF_CLIFOR AS TPCLIFOR ,
               S.SDF_CDCLIFOR AS PARTICIPANTE,
               S.SDF_DATAESCR AS DATAESCRITURACAO
      FROM SPEDDOCFIS_SDF S, SPEDITDOCFIS_IDF I, TPOPER_TPO TPO, PRODUTO_PRD PRD
     WHERE S.SDF_SQDOCFIS = I.IDF_SQDOCFIS
       AND I.IDF_TPOP = TPO.TPO_CODIGO
       AND S.SDF_EMITENTE = 'P'
--       AND TPO.TPO_NRECPISCOFINS = 'N'
       AND I.IDF_ITEM = PRD.PRD_ITEM
       AND TRIM(S.SDF_CONTACTB) IS NULL
       AND S.SDF_MODELO IN  ('07', '08', '09', '10', '11', '26', '57', '27', '67')
UNION
    SELECT S.SDF_SYSTEM AS SISTEMA,
                S.SDF_CDEMPRESA AS CDEMPRESA,
                S.SDF_CDFILIAL   AS CDFILIAL,
                S.SDF_MODELO AS MODELO,
               '0' AS TPDOCFIS,
               NVL(S.SDF_TPESTOQUE,
                      CASE WHEN S.SDF_SYSTEM = 'SF' THEN (SELECT FAT_TPESTOQUE  FROM FATURAS_FAT FAT, INTMODFAT_IMF IMF, INTMODSDF_IMS IMS
                                                                                    WHERE FAT.FAT_CDEMPRESA = IMF.IMF_CDEMPRESA
                                                                                        AND FAT.FAT_CDFILIAL = IMF.IMF_CDFILIAL
                                                                                        AND FAT.FAT_CDFATURA = IMF.IMF_CDFATURA
                                                                                        AND IMF.IMF_SQINTEGRACAO = IMS.IMS_SQINTEGRACAO
                                                                                        AND IMS.IMS_SQDOCFIS = S.SDF_SQDOCFIS)   END
                   ) AS CDESTOQUE,
                S.SDF_SQDOCFIS   AS IDDOCFIS,
                I.IDF_SQITDOCFIS AS IDITEM,
                TPO.TPO_TIPO  AS OPERACAO,
                I.IDF_TPOP       AS TPOPERACAO,
                TPO.TPO_DESCRICAO AS DSTPOPERACAO,
                NULL AS CDGRPPAGREC,
                I.IDF_ITEM       AS CDPRODSERV,
                PRD.PRD_DESCRICAO,
                I.IDF_CFOP AS CFOP,
               S.SDF_DOCUMENTO AS DOCUMENTO,
               S.SDF_CLIFOR AS TPCLIFOR ,
               S.SDF_CDCLIFOR AS PARTICIPANTE,
               S.SDF_DATAESCR AS DATAESCRITURACAO
      FROM SPEDDOCFIS_SDF S, SPEDITDOCFIS_IDF I, TPOPER_TPO TPO, PRODUTO_PRD PRD
    WHERE S.SDF_SQDOCFIS = I.IDF_SQDOCFIS
       AND I.IDF_TPOP = TPO.TPO_CODIGO
       AND I.IDF_ITEM = PRD.PRD_ITEM
       AND S.SDF_EMITENTE = 'T'
       AND TRIM(S.SDF_CONTACTB) IS NULL
--       AND  (SELECT SUM(I2.IDF_VLBCPIS + I2.IDF_VLBCCOFINS) FROM SPEDITDOCFIS_IDF I2 WHERE I2.IDF_SQDOCFIS = I.IDF_SQDOCFIS) > 0
       AND S.SDF_MODELO IN  ('07', '08', '09', '10', '11', '26', '57', '27', '67')
UNION
   SELECT  S.SDFS_SYSTEM AS SISTEMA,
           S.SDFS_CDEMPRESA AS CDEMPRESA,
           S.SDFS_CDFILIAL       AS CDFILIAL,
           'SRV' AS MODELO,
           '2' AS TPDOCFIS,
          CASE WHEN S.SDFS_SYSTEM = 'SF' THEN (SELECT FAT_TPESTOQUE  FROM FATURAS_FAT FAT, INTMODFAT_IMF IMF, INTMODSERV_IMSV IMSV
                                                                        WHERE FAT.FAT_CDEMPRESA = IMF.IMF_CDEMPRESA
                                                                            AND FAT.FAT_CDFILIAL = IMF.IMF_CDFILIAL
                                                                            AND FAT.FAT_CDFATURA = IMF.IMF_CDFATURA
                                                                            AND IMF.IMF_SQINTEGRACAO = IMSV.IMSV_SQINTEGRACAO
                                                                            AND IMSV.IMSV_SQDOCFISSERV = S.SDFS_SQDOCFISSERV)
          ELSE NULL  END
           AS CDESTOQUE,
           S.SDFS_SQDOCFISSERV   AS IDDOCFIS,
            I.IDFS_SQITDOCFISSERV AS IDITEM,
           TPO.TPO_TIPO  AS OPERACAO,
           S.SDFS_TPOP           AS TPOPERACAO,
           TPO.TPO_DESCRICAO AS DSTPOPERACAO,
           TRIM(S.SDFS_CDGRPPAGREC) AS CDGRPPAGREC,
           I.IDFS_ITEM           AS CDPRODSERV,
           PRD.PRD_DESCRICAO,
           NULL AS CFOP,
            S.SDFS_DOCUMENTO AS DOCUMENTO,
            S.SDFS_CLIFOR AS TPCLIFOR,
            S.SDFS_CDCLIFOR AS PARTICIPANTE,
            S.SDFS_DATAESCR AS DATAESCRITURACAO
      FROM SPEDDOCFISSERV_SDFS S, SPEDITDOCFISSERV_IDFS I, TPOPER_TPO TPO, PRODUTO_PRD PRD
     WHERE S.SDFS_SQDOCFISSERV = I.IDFS_SQDOCFISSERV
       AND S.SDFS_TPOP = TPO.TPO_CODIGO
       AND S.SDFS_EMITENTE = 'P'
       AND I.IDFS_ITEM = PRD.PRD_ITEM
--       AND TPO.TPO_NRECPISCOFINS = 'N'
       AND TRIM(I.IDFS_CODCTA) IS NULL
UNION
   SELECT  S.SDFS_SYSTEM AS SISTEMA,
           S.SDFS_CDEMPRESA AS CDEMPRESA,
           S.SDFS_CDFILIAL       AS CDFILIAL,
           'SRV' AS MODELO,
           '2' AS TPDOCFIS,
          CASE WHEN S.SDFS_SYSTEM = 'SF' THEN (SELECT FAT_TPESTOQUE  FROM FATURAS_FAT FAT, INTMODFAT_IMF IMF, INTMODSERV_IMSV IMSV
                                                                        WHERE FAT.FAT_CDEMPRESA = IMF.IMF_CDEMPRESA
                                                                            AND FAT.FAT_CDFILIAL = IMF.IMF_CDFILIAL
                                                                            AND FAT.FAT_CDFATURA = IMF.IMF_CDFATURA
                                                                            AND IMF.IMF_SQINTEGRACAO = IMSV.IMSV_SQINTEGRACAO
                                                                            AND IMSV.IMSV_SQDOCFISSERV = S.SDFS_SQDOCFISSERV)
          ELSE NULL  END
           AS CDESTOQUE,
           S.SDFS_SQDOCFISSERV   AS IDDOCFIS,
            I.IDFS_SQITDOCFISSERV AS IDITEM,
           TPO.TPO_TIPO  AS OPERACAO,
           S.SDFS_TPOP           AS TPOPERACAO,
           TPO.TPO_DESCRICAO AS DSTPOPERACAO,
           TRIM(S.SDFS_CDGRPPAGREC) AS CDGRPPAGREC,
           I.IDFS_ITEM           AS CDPRODSERV,
           PRD.PRD_DESCRICAO,
           NULL AS CFOP,
            S.SDFS_DOCUMENTO AS DOCUMENTO,
            S.SDFS_CLIFOR AS TPCLIFOR,
            S.SDFS_CDCLIFOR AS PARTICIPANTE,
            S.SDFS_DATAESCR AS DATAESCRITURACAO
      FROM SPEDDOCFISSERV_SDFS S, SPEDITDOCFISSERV_IDFS I, TPOPER_TPO TPO, PRODUTO_PRD PRD
     WHERE S.SDFS_SQDOCFISSERV = I.IDFS_SQDOCFISSERV
       AND S.SDFS_TPOP = TPO.TPO_CODIGO
       AND I.IDFS_ITEM = PRD.PRD_ITEM
       AND TRIM(I.IDFS_CODCTA) IS NULL
       AND S.SDFS_EMITENTE = 'T'
--       AND  (SELECT SUM(I2.IDFS_VLBCPIS + I2.IDFS_VLBCCOFINS) FROM SPEDITDOCFISSERV_IDFS I2 WHERE I2.IDFS_SQDOCFISSERV = I.IDFS_SQDOCFISSERV) > 0
UNION
SELECT S.SDGC_CDSISTEMA AS SISTEMA,
            S.SDGC_CDEMPRESA AS CDEMPRESA,
            S.SDGC_CDFILIAL    AS CDFILIAL,
            NULL AS MODELO,
            '4' AS TPDOCFIS,
            NULL AS CDESTOQUE,
            S.SDGC_SQDOCGERACRD   AS IDDOCFIS,
            NULL AS IDITEM,
            TPO.TPO_TIPO  AS OPERACAO,
            S.SDGC_CDTPOPER       AS TPOPERACAO,
            TPO.TPO_DESCRICAO AS DSTPOPERACAO,
            NULL AS CDGRPPAGREC,
            S.SDGC_ITEM   AS CDPRODSERV,
            PRD.PRD_DESCRICAO,
            NULL AS CFOP,
            S.SDGC_NRTITRECIBO AS DOCUMENTO,
            S.SDGC_CLIFOR AS TPCLIFOR ,
            S.SDGC_CDCLIFOR AS PARTICIPANTE,
            S.SDGC_DATAESCR AS DATAESCRITURACAO
  FROM SPEDDOCGERACRD_SDGC S, PRODUTO_PRD PRD, TPOPER_TPO TPO
WHERE S.SDGC_ITEM = PRD.PRD_ITEM(+)
     AND S.SDGC_CDTPOPER = TPO.TPO_CODIGO
     AND TRIM(S.SDGC_NOCONTAB) IS NULL
) TBL
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 285776
PROMPT ======================================================================