PROMPT ======================================================================
PROMPT == DEMANDA......: 283424
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: ANDERSON EIJI NOGUTI
PROMPT == DATA.........: 14/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE MXRPT_CAMPO_MCMP MODIFY(MCMP_DSREFERENCIA VARCHAR2(255))
/

ALTER TABLE MXRPT_CAMPO_MCMP MODIFY(MCMP_NMCAMPO VARCHAR2(255))
/

ALTER TABLE MXRPT_CAMPO_MCMP MODIFY(MCMP_DSLABEL VARCHAR2(255))
/

ALTER TABLE MXRPT_PARAMETRO_MPAR MODIFY(MPAR_DSLABEL VARCHAR2(255))
/

ALTER TABLE MXS_PERFILAMBIENTEAMBIENTE_PAA MODIFY(PAA_CDAMBIENTE VARCHAR2(20))
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283424
PROMPT ======================================================================