PROMPT ======================================================================
PROMPT == DEMANDA......: 285398
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: ANDERSON EIJI NOGUTI
PROMPT == DATA.........: 18/01/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_MXCHANGESTRING (
   p_string   IN   VARCHAR2,
   p_invert   IN   NUMBER DEFAULT 0
)
   RETURN VARCHAR2
IS
   v_keynum       NUMBER;
   v_string_rtn   VARCHAR2 (4000);
   v_string_tmp   VARCHAR2 (4000);
   v_split        CHAR (1)        := 'O';
   v_chrseq       NUMBER;
   v_string_len   VARCHAR2 (4000);
BEGIN
   IF p_invert = 0
   THEN
      v_keynum := ROUND (DBMS_RANDOM.VALUE (2, 99));
      v_string_rtn := v_keynum || v_split;
      FOR i1 IN 1 .. NVL (LENGTH (p_string), 0)
      LOOP
         v_string_rtn :=
               v_string_rtn
            || TO_CHAR (ASCII (SUBSTR (p_string, i1, 1)) + i1 + v_keynum)
            || v_split;
      END LOOP;
      RETURN v_string_rtn;
   ELSE
      v_keynum := SUBSTR (p_string, 0, INSTR (p_string, v_split) - 1);
      v_string_tmp := SUBSTR (p_string, INSTR (p_string, v_split));
      IF    NVL(v_keynum,0) < 1
         OR SUBSTR (p_string, -1) <> v_split
      THEN
         RETURN '**Formato incorreto**';
      ELSE
         v_string_rtn := '';
         v_chrseq := 0;
         LOOP
            EXIT WHEN NVL (LENGTH (v_string_tmp), 0) = 0;
            IF (SUBSTR (v_string_tmp, 0, 1) = v_split)
            THEN
               v_string_tmp := SUBSTR (v_string_tmp, 2);
            ELSE
               v_chrseq := v_chrseq + 1;
               v_string_rtn :=
                     v_string_rtn
                  || CHR (TO_NUMBER (  SUBSTR (v_string_tmp,
                                               0,
                                                 INSTR (v_string_tmp, v_split)
                                               - 1
                                              )
                                     - v_chrseq
                                     - v_keynum
                                    )
                         );
               v_string_tmp :=
                          SUBSTR (v_string_tmp, INSTR (v_string_tmp, v_split));
            END IF;
         END LOOP;
         RETURN v_string_rtn;
      END IF;
   END IF;
EXCEPTION
   WHEN OTHERS
   THEN
      RETURN '**Formato incorreto**';
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 285398
PROMPT ======================================================================