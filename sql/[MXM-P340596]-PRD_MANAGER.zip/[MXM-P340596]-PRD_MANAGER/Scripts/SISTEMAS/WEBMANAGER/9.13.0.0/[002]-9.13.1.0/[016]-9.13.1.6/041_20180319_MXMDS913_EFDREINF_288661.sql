PROMPT ======================================================================
PROMPT == DEMANDA......: 288661
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: Sistema MANTIS - PAT 263852
PROMPT == DATA.........: 19/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE VIEW VW_RNFMODELOENVIO_MOO AS
SELECT MOO_IDMOO,
       MOO_CDMODELO,
       MOO_NRRN1,
       'Per�odo: ' || MOO_DSPERIODO || ' - Ambiente: ' ||
       DECODE(MOO_CDAMBIENTE,1,'Produ��o',
       3,'Homologa��o', 9,'Homologa��o') AS PERIODO
  FROM RNFMODELOENVIO_MOO
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 288661
PROMPT ======================================================================