PROMPT ======================================================================
PROMPT == DEMANDA......: 282191
PROMPT == SISTEMA......: Compras
PROMPT == RESPONSAVEL..: ERICA LIMA BOTELHO
PROMPT == DATA.........: 27/11/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

comment on table ITPEDCOMPRAEXC_IPCE
  is 'Tabela de log que armazena os itens do pedido que foram exclu�dos'
/

ALTER TABLE ITPEDCOMPRAEXC_IPCE DROP CONSTRAINT ITPEDCOMPRAEXC_IPCE_PKX CASCADE DROP INDEX
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282191
PROMPT ======================================================================