PROMPT ======================================================================
PROMPT == DEMANDA......: 285518
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: JOSE BARBOSA DA SILVA JUNIOR
PROMPT == DATA.........: 02/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE PRC_EFDPREPRELGENERICSRV (PSQPROCESSO NUMBER, PSQREGISTRO NUMBER)
AS
   VSR1_IDRELACIONAMENTO    NUMBER;
   VSR2_IDRELACIONAMENTO    NUMBER;
   ERR_MSG                  VARCHAR2 (500);
   CURSOR CUR_CBSR1
   IS
      SELECT SR1_IDRELACIONAMENTO
        FROM EFDCBRELGENERICSRV_SR1;
   CURSOR CUR_PREPRELACIONAMENTO
   IS
      SELECT   TSDFS_EMITENTE AS SR2_TPEMISSAO, NULL AS SR2_CDITEMMANAGER, TIDFS_CDITEM AS SR2_CDITEMEXTERNO,
               TSDFS_CDCLIFOR AS SR2_CDPARTICIPANTE, NULL AS SR2_TPPARTICIPANTE, NULL AS SR2_CDTPOPER,
               TSDFS_CDEMPRESA AS SR2_CDEMPRESA, TSDFS_CDFILIAL AS SR2_CDFILIAL, NULL AS SR2_CDCONDPAG,
               NULL AS SR2_CDTPCOBRANCA, NULL AS SR2_CDGRUPOPAGREC,
               NULL AS SR2_DTVIGENCIAINICIAL,
               NULL AS SR2_DTVIGENCIAFINAL, SYSDATE AS SR2_DTCADASTRO, TRIM (GET_USER_MXM) AS SR2_USCADASTRO,
               NULL AS SR2_DTALTERACAO, NULL AS SR2_USALTERACAO
          FROM TI_ARQSPEDDOCFISSERV_TSDFS TS, TI_ARQSPEDITDOCFISSRV_TIDFS TI
         WHERE TS.TSDFS_SQPROCESSO = PSQPROCESSO
           AND TS.TSDFS_SQPROCESSO = TI.TIDFS_SQPROCESSO
           AND TS.TSDFS_SQREGISTRO = TI.TIDFS_SQREGISTRO
           AND (PSQREGISTRO IS NULL OR TI.TIDFS_SQREGISTRO = PSQREGISTRO)
           AND NOT EXISTS (
                  SELECT 1
                    FROM EFDDTRELGENERICSRV_SR2 SR2
                   WHERE TS.TSDFS_EMITENTE = SR2.SR2_TPEMISSAO
                     AND TI.TIDFS_CDITEM = SR2.SR2_CDITEMEXTERNO
                     AND TS.TSDFS_CDCLIFOR = SR2.SR2_CDPARTICIPANTE
                     AND TS.TSDFS_CDEMPRESA = SR2.SR2_CDEMPRESA
                     AND TS.TSDFS_CDFILIAL = SR2.SR2_CDFILIAL)
      GROUP BY TSDFS_EMITENTE, TIDFS_CDITEM, TSDFS_CDCLIFOR, TSDFS_CDEMPRESA, TSDFS_CDFILIAL;
   TYPE TP_PREPRELACIONAMENTO IS TABLE OF CUR_PREPRELACIONAMENTO%ROWTYPE
      INDEX BY PLS_INTEGER;
   TBL_PREPRELACIONAMENTO   TP_PREPRELACIONAMENTO;
   -- TABLE A TEMPORARIA PARA GRAVAR OS ERROS
   VSQERRO                  NUMBER;
   TYPE TP_TBLERRO IS TABLE OF TI_ERROSPEDDOCFISSRV_TESDFS%ROWTYPE
      INDEX BY PLS_INTEGER;
   TBL_ERRO                 TP_TBLERRO;
BEGIN
   VSR1_IDRELACIONAMENTO := NULL;
   ERR_MSG := '01.Erro ao preparar relacionamento.';
   OPEN CUR_CBSR1;
   FETCH CUR_CBSR1
    INTO VSR1_IDRELACIONAMENTO;
   CLOSE CUR_CBSR1;
   IF VSR1_IDRELACIONAMENTO IS NULL
   THEN
      BEGIN
         VSR1_IDRELACIONAMENTO := 1000;
         PRC_INSEFDCBRELGENERICSRV_SR1 (VSR1_IDRELACIONAMENTO);
      END;
   ELSE
      VSR1_IDRELACIONAMENTO := 1000;
   END IF;
   IF VSR1_IDRELACIONAMENTO IS NOT NULL
   THEN
      BEGIN
         ERR_MSG := '02.Erro ao preparar relacionamento';
         OPEN CUR_PREPRELACIONAMENTO;
         LOOP
            FETCH CUR_PREPRELACIONAMENTO
            BULK COLLECT INTO TBL_PREPRELACIONAMENTO LIMIT 2000;
            EXIT WHEN TBL_PREPRELACIONAMENTO.COUNT = 0;
            FOR IDX IN 1 .. TBL_PREPRELACIONAMENTO.COUNT
            LOOP
               BEGIN
                  VSR2_IDRELACIONAMENTO := NULL;
                  PRC_INSEFDDTRELGENERICSRV_SR2 (VSR2_IDRELACIONAMENTO,
                                                 VSR1_IDRELACIONAMENTO,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_TPEMISSAO,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_CDITEMMANAGER,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_CDITEMEXTERNO,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_CDPARTICIPANTE,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_TPPARTICIPANTE,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_CDTPOPER,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_CDEMPRESA,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_CDFILIAL,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_CDCONDPAG,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_CDTPCOBRANCA,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_CDGRUPOPAGREC,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_DTVIGENCIAINICIAL,
                                                 TBL_PREPRELACIONAMENTO (IDX).SR2_DTVIGENCIAFINAL
                                                );
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     BEGIN
                        VSQERRO := TBL_ERRO.COUNT + 1;
                        TBL_ERRO (VSQERRO).TESDFS_SQPROCESSO := PSQPROCESSO;
                        TBL_ERRO (VSQERRO).TESDFS_SQREGISTRO := NULL;
                        TBL_ERRO (VSQERRO).TESDFS_SQERRO := -VSQERRO;
                        TBL_ERRO (VSQERRO).TESDFS_CDERRO := 'INTDFS121';
                        TBL_ERRO (VSQERRO).TESDFS_VBFATAL := 1;
                        TBL_ERRO (VSQERRO).TESDFS_MENSAGEM :=
                              'Participante: '
                           || TBL_PREPRELACIONAMENTO (IDX).SR2_CDPARTICIPANTE
                           || '. Servi�o:'
                           || TBL_PREPRELACIONAMENTO (IDX).SR2_CDITEMEXTERNO
                           || '. Mensagem do Sistema: '
                           || SUBSTR (SQLERRM, 1, 100);
                     END;
               END;
            END LOOP;
            COMMIT;
            -- GRAVA ERROS ENCONTRADOS DURANTE O LOOP.
            IF TBL_ERRO.COUNT > 0
            THEN
               BEGIN
                  FORALL I IN TBL_ERRO.FIRST .. TBL_ERRO.LAST SAVE EXCEPTIONS
                     INSERT INTO TI_ERROSPEDDOCFISSRV_TESDFS
                          VALUES TBL_ERRO (I);
               END;
               TBL_ERRO.DELETE;
            END IF;
         END LOOP;
         CLOSE CUR_PREPRELACIONAMENTO;
      END;
   END IF;
   COMMIT;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         ERR_MSG := SUBSTR ('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CUR_PREPRELACIONAMENTO%ISOPEN
         THEN
            CLOSE CUR_PREPRELACIONAMENTO;
         END IF;
         IF CUR_CBSR1%ISOPEN
         THEN
            CLOSE CUR_CBSR1;
         END IF;
         RAISE_APPLICATION_ERROR (-20000, ERR_MSG);
      END;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 285518
PROMPT ======================================================================