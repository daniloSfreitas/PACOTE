PROMPT ======================================================================
PROMPT == DEMANDA......: 282619
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: ANDRE LUIZ PEREIRA FONTES
PROMPT == DATA.........: 15/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGE020(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGE020         VARCHAR2(4) := 'E020';
   CURSOR CS_REGE020 IS
      SELECT SEQ1_EFDLEDFREGISTROE020_E02.NEXTVAL AS IDLEDFREGISTROE020
           , PT_IDMODESCRITURACAO AS NRLME
           , CT_REGE020 AS REGE020
           , IND_OPER
           , IND_EMIT
           , CLIFOR
           , COD_PART
           , COD_MOD
           , COD_SIT
           , SER
           , NUM_DOC
           , DT_DOC
           , NUM_LCTO
           , DT_E_S
           , VL_CONT
           , VL_BC_ICMS
           , VL_ICMS
           , VL_ST
           , VL_COMPL
           , IND_COMPL
           , VL_ISNT_ICMS
           , VL_OUT_ICMS
           , VL_BC_IPI
           , VL_IPI
           , VL_ISNT_IPI
           , VL_OUT_IPI
           , COD_INF_OBS
        FROM (SELECT DECODE(TPO_TIPO, 'E', '0', '1') AS IND_OPER
                   , DECODE(SDF_EMITENTE, 'P', '0', '1') AS IND_EMIT
                   , SDF_CLIFOR AS CLIFOR
                   , TRIM(SDF_CDCLIFOR) AS COD_PART
                   , SDF_MODELO AS COD_MOD
                   , SDF_SITDOC AS COD_SIT
                   , SDF_SERIE AS SER
                   , SDF_DOCUMENTO AS NUM_DOC
                   , TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY') AS DT_DOC
                   , 0 AS NUM_LCTO
                   , DECODE(TPO_TIPO, 'E', TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'), TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')) AS DT_E_S
                   , SUM(ROUND(IDF_VLCONTABIL, 2)) AS VL_CONT
                   , SUM(ROUND(IDF_VLBCICMS, 2)) AS VL_BC_ICMS
                   , SUM(ROUND(IDF_VLICMS, 2)) AS VL_ICMS
                   , SUM(ROUND(IDF_VLICMSST, 2)) AS VL_ST
                   , SDF_VLTOTALCOMPLEMENTAR AS VL_COMPL
                   , NVL(SDF_TPINDCOMPLEMENTAR, '00') AS IND_COMPL
                   , SUM(IDF_VLBIICMS) AS VL_ISNT_ICMS
                   , SUM(IDF_VLBOICMS) AS VL_OUT_ICMS
                   , SUM(IDF_VLBCIPI) AS VL_BC_IPI
                   , SUM(IDF_VLIPI) AS VL_IPI
                   , SUM(IDF_VLBIIPI) AS VL_ISNT_IPI
                   , SUM(IDF_VLBOIPI) AS VL_OUT_IPI
                   , '' AS COD_INF_OBS
                FROM SPEDDOCFIS_SDF
                   , SPEDITDOCFIS_IDF
                   , TPOPER_TPO
               WHERE SDF_SQDOCFIS = IDF_SQDOCFIS
			     AND SDF_TPOP = TPO_CODIGO
                 AND SDF_SQDOCFIS IN (SELECT SQDOCFIS
                                        FROM (SELECT SDF_SQDOCFIS AS SQDOCFIS
                                                   , SUM(IDF_VLICMSUFREMETENTE) AS IDF_VLICMSUFREMETENTE
                                                   , SUM(IDF_VLICMSUFDESTINO) AS IDF_VLICMSUFDESTINO
                                                FROM SPEDDOCFIS_SDF, SPEDITDOCFIS_IDF, EFDLEDFMODELOESCRIT_LME
                                               WHERE IDF_SQDOCFIS = SDF_SQDOCFIS
                                                 AND SDF_CDEMPRESA = LME_CDEMPRESA
                                                 AND SDF_CDFILIAL = LME_CDFILIAL
                                                 AND SDF_DATAESCR >= LME_DTINI
                                                 AND SDF_DATAESCR <= LME_DTFIN
                                                 AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                                                 AND SDF_MODELO IN ('01', '04', '55')
                                              GROUP BY SDF_SQDOCFIS)
                                       WHERE ((NVL(IDF_VLICMSUFDESTINO, 0) + NVL(IDF_VLICMSUFREMETENTE, 0)) = 0))
              GROUP BY DECODE(TPO_TIPO, 'E', '0', '1')
                     , DECODE(SDF_EMITENTE, 'P', '0', '1')
                     , SDF_CLIFOR
                     , SDF_CDCLIFOR
                     , SDF_MODELO
                     , SDF_SITDOC
                     , SDF_SERIE
                     , SDF_DOCUMENTO
                     , TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')
                     , DECODE(TPO_TIPO, 'E', TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'), TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY'))
                     , SDF_VLTOTALCOMPLEMENTAR
                     , NVL(SDF_TPINDCOMPLEMENTAR, '00'));
   TYPE TP_CS_REGE020 IS TABLE OF CS_REGE020%ROWTYPE INDEX BY PLS_INTEGER;
   TB_CS_REGE020      TP_CS_REGE020;
BEGIN
   OPEN CS_REGE020;
   LOOP
      FETCH CS_REGE020 BULK COLLECT INTO TB_CS_REGE020 LIMIT 1000;
      EXIT WHEN TB_CS_REGE020.COUNT = 0;
      FORALL I IN TB_CS_REGE020.FIRST .. TB_CS_REGE020.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROE020_E02 VALUES TB_CS_REGE020(I);
   END LOOP;
   CLOSE CS_REGE020;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGE020%ISOPEN
         THEN
            CLOSE CS_REGE020;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGE360(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGE360         VARCHAR2(4) := 'E360';
   VR_ICMSSTSAIDA_E360 CHAR(1);
   CURSOR CS_REGE360 IS
      SELECT SEQ1_EFDLEDFREGISTROE360_E17.NEXTVAL AS IDLEDFREGISTROE360
           , PT_IDMODESCRITURACAO AS NRLME
           , CT_REGE360 AS REGE360
           , VL_01
           , VL_02
           , VL_03
           , VL_04
           , VL_05
           , VL_06
           , VL_07
           , VL_08
           , VL_09
           , VL_10
           , VL_11
           , VL_12
           , VL_13
           , DECODE(VL_12 - VL_13, ABS(VL_12 - VL_13), VL_12 - VL_13, 0) AS VL_14
           , VL_15
           , DECODE(VR_ICMSSTSAIDA_E360, 'S', VL_16, 0)
           , NVL(VL_17, 0) AS VL_17
           , VL_18
           , VL_19
           , DECODE( SIGN(VL_12 - VL_13), 1, (VL_12 - VL_13) + NVL(VL_17, 0) + VL_18 + VL_19 + VL_20, 0) AS VL_20
           , VL_99
        FROM (SELECT SUM(VL_01) AS VL_01
                   , SUM(VL_02) AS VL_02
                   , SUM(VL_03) AS VL_03
                   , SUM(VL_01 + VL_02 + VL_03) AS VL_04
                   , SUM(VL_05) AS VL_05
                   , SUM(VL_06) AS VL_06
                   , SUM(VL_07) AS VL_07
                   , SUM(VL_05 + VL_06 + VL_07) AS VL_08
                   , SUM(VL_09) AS VL_09
                   , SUM(VL_05 + VL_06 + VL_07 + VL_09) AS VL_10
                   , DECODE(
                        SUM((VL_05 + VL_06 + VL_07 + VL_09) - (VL_01 + VL_02 + VL_03))
                      , ABS(SUM((VL_05 + VL_06 + VL_07 + VL_09) - (VL_01 + VL_02 + VL_03))), SUM(
                                                                                                (VL_05 + VL_06 + VL_07 + VL_09) -
                                                                                                (VL_01 + VL_02 + VL_03))
                      , 0)
                        AS VL_11
                   , DECODE(
                        SUM((VL_01 + VL_02 + VL_03) - (VL_05 + VL_06 + VL_07 + VL_09))
                      , ABS(SUM((VL_01 + VL_02 + VL_03) - (VL_05 + VL_06 + VL_07 + VL_09))), SUM(
                                                                                                (VL_01 + VL_02 + VL_03) -
                                                                                                (VL_05 + VL_06 + VL_07 + VL_09))
                      , 0)
                        AS VL_12
                   , SUM(VL_13) AS VL_13
                   , SUM(VL_15) AS VL_15
                   , SUM(VL_16) AS VL_16
                   , SUM(VL_17) AS VL_17
                   , SUM(VL_18) AS VL_18
                   , SUM(VL_19) AS VL_19
                   , SUM(VL_20) AS VL_20
                   , SUM(VL_15 + VL_16) AS VL_99
                FROM (SELECT VL_01
                           , VL_02
                           , VL_03
                           , VL_05
                           , VL_06
                           , VL_07
                           , VL_09
                           , VL_13
                           , (E350_VL_OR + VL_15) AS VL_15
               , CASE WHEN (E330_VL_ST > E350_VL_OR) THEN (E330_VL_ST - E350_VL_OR) WHEN (E330_VL_ST = E350_VL_OR) THEN 0 ELSE E330_VL_ST END AS VL_16
                           , VL_17
                           , VL_18
                           , VL_19
                           , VL_20
                        FROM (SELECT NVL(SUM(DECODE(E02_TPINDOPER, 1, E02_VLICMS, 0)), 0) AS VL_01
                                   , 0 AS VL_02
                                   , 0 AS VL_03
                                   , NVL(SUM(DECODE(E02_TPINDOPER, 0, E02_VLICMS, 0)), 0) AS VL_05
                                   , 0 AS VL_06
                                   , 0 AS VL_07
                                   , 0 AS VL_09
                                   , 0 AS VL_13
                                   , NVL(SUM(DECODE(E02_TPINDOPER, 0, E02_VLST, 0)), 0) AS VL_15
                                   , NVL(SUM(DECODE(E02_TPINDOPER, 1, E02_VLST, 0)), 0) AS VL_16
                                   , 0 AS VL_17
                                   , 0 AS VL_18
                                   , 0 AS VL_19
                                   , 0 AS VL_20
                                FROM EFDLEDFREGISTROE020_E02
                               WHERE E02_NRLME = PT_IDMODESCRITURACAO)
                           , (SELECT SUM(E14_VLST) AS E330_VL_ST
                                FROM EFDLEDFREGISTROE330_E14
                               WHERE E14_TPINDTOT IN (4, 8)
                                 AND E14_NRLME = PT_IDMODESCRITURACAO)
                           , (SELECT SUM(E16_VLOR) AS E350_VL_OR
                                FROM EFDLEDFREGISTROE350_E16
                               WHERE E16_CDOR IN ('020', '030', '001')
                                 AND E16_NRLME = PT_IDMODESCRITURACAO)
                      UNION ALL
                      SELECT NVL(SUM(DECODE(E10_TPINDOPER, 1, E10_VLICMS, 0)), 0) AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , NVL(SUM(DECODE(E10_TPINDOPER, 0, E10_VLICMS, 0)), 0) AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
               , 0 AS VL_20
                        FROM EFDLEDFREGISTROE120_E10
                       WHERE E10_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT NVL(SUM(E07_VLICMSP), 0) AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , 0 AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
               , 0 AS VL_20
                        FROM EFDLEDFREGISTROE085_E07
                       WHERE E07_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT NVL(SUM(DECODE(E08_TPINDOPER, 1, E08_VLICMS, 0)), 0) AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , NVL(SUM(DECODE(E08_TPINDOPER, 0, E08_VLICMS, 0)), 0) AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
                           , 0 AS VL_20
                        FROM EFDLEDFREGISTROE100_E08
                       WHERE E08_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT 0 AS VL_01
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '1', E15_VLAJ, 0)), 0) AS VL_02
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '2', E15_VLAJ, 0)), 0) AS VL_03
                           , 0 AS VL_05
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '4', E15_VLAJ, 0)), 0) AS VL_06
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '5', E15_VLAJ, 0)), 0) AS VL_07
                           , 0 AS VL_09
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '6', E15_VLAJ, 0)), 0) AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
                           , 0 AS VL_20
                        FROM EFDLEDFREGISTROE340_E15
                       WHERE E15_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT 0 AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , 0 AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , CRA.CRA_VLSALDO AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
                           , 0 AS VL_20
                        FROM SPEDSALCREDANT_CRA CRA, EFDLEDFMODELOESCRIT_LME LME
                       WHERE CRA.CRA_TPIMPOSTO = '0'
                         AND CRA.CRA_CDEMPRESA = LME.LME_CDEMPRESA
                         AND CRA.CRA_CDFILIAL = LME.LME_CDFILIAL
                         AND CRA.CRA_PERIODO + 1 = LME.LME_DTINI
                         AND LME.LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT 0 AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , 0 AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , SUM(DECODE(OIR_CDOBRIGACAO, '020', OIR_VLOBRIGACAO, 0)) AS VL_17
                           , SUM(DECODE(OIR_CDOBRIGACAO, '004', OIR_VLOBRIGACAO, 0)) AS VL_18
               , SUM(DECODE(OIR_CDOBRIGACAO, '005', OIR_VLOBRIGACAO, 0)) AS VL_19
               , SUM(DECODE(OIR_CDOBRIGACAO, '999', OIR_VLOBRIGACAO, 0)) AS VL_20
                        FROM (SELECT DECODE(SAI_ICMSTPOPERACAO, 3, DECODE(SAI_UF, 'DF', '020', '999'), OIR_CDOBRIGACAO) AS OIR_CDOBRIGACAO
                                   , OIR_VLOBRIGACAO
                                FROM SPEDAPUICMS_SAI, SPEDOBICMSREC_OIR, EFDLEDFMODELOESCRIT_LME
                               WHERE SAI_SQAPUICMS = OIR_SQAPUICMS
                                 AND SAI_CDEMPRESA = LME_CDEMPRESA
                                 AND SAI_CDFILIAL = LME_CDFILIAL
                                 AND SAI_DATAINI >= LME_DTINI
                                 AND SAI_DATAFIM <= LME_DTFIN
                                 AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO)));
   TYPE TP_CS_REGE360 IS TABLE OF CS_REGE360%ROWTYPE
                            INDEX BY PLS_INTEGER;
   TB_CS_REGE360      TP_CS_REGE360;
BEGIN
    VR_ICMSSTSAIDA_E360 := 'S';
    FOR REC_PARAMS_PAR IN
       (SELECT PAR.PAR_VLPARAM FROM PARAMS_PAR PAR, EFDLEDFMODELOESCRIT_LME LME WHERE
               PAR.PAR_CDEMP = LME.LME_CDEMPRESA
           AND PAR.PAR_CDFILIAL = LME.LME_CDFILIAL
           AND PAR.PAR_CDPARAM = 'wPAR_LevarICMSSTSaidasLEDF'
           AND LME.LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO) LOOP
    VR_ICMSSTSAIDA_E360 := NVL(REC_PARAMS_PAR.PAR_VLPARAM,'S');
    END LOOP;
   OPEN CS_REGE360;
   LOOP
      FETCH CS_REGE360
        BULK COLLECT INTO TB_CS_REGE360
      LIMIT 100;
      EXIT WHEN TB_CS_REGE360.COUNT = 0;
      FORALL I IN TB_CS_REGE360.FIRST .. TB_CS_REGE360.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROE360_E17
         VALUES TB_CS_REGE360(I);
   END LOOP;
   CLOSE CS_REGE360;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGE360%ISOPEN
         THEN
            CLOSE CS_REGE360;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282619
PROMPT ======================================================================