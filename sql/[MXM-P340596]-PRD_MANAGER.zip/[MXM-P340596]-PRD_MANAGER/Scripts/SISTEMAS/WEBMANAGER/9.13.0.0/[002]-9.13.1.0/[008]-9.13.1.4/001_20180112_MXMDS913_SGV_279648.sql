PROMPT ======================================================================
PROMPT == DEMANDA......: 279648
PROMPT == SISTEMA......: Sistema de gest�o de viagens
PROMPT == RESPONSAVEL..: DIOGO DE FREITAS RODRIGUES
PROMPT == DATA.........: 09/01/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

create table SGVALUGUELAUTOMOVEL_AAV
(
  AAV_IDALUGUELAUTO      NUMBER not null,
  AAV_NRSEQVIAGEM        NUMBER not null,
  AAV_DTRETIRADA         DATE   not null,
  AAV_DTDEVOLUCAO        DATE   not null,
  AAV_NRQUANTIDADEDIA   NUMBER not null,
  AAV_VLALUGUELESTIMADO  NUMBER(15,2),
  AAV_VLALUGUELREALIZADO NUMBER(15,2),
  AAV_DSJUSTIFICATIVA    VARCHAR2(400)
)
/

comment on table SGVALUGUELAUTOMOVEL_AAV
  is 'Tabela de aluguel de automovel para a solicitacao de viagem'
/

comment on column SGVALUGUELAUTOMOVEL_AAV.AAV_IDALUGUELAUTO
  is 'Identificador do registro'
/

comment on column SGVALUGUELAUTOMOVEL_AAV.AAV_NRSEQVIAGEM
  is 'Identificador da sequencia da informa��o de viagem'
/

comment on column SGVALUGUELAUTOMOVEL_AAV.AAV_DTRETIRADA
  is 'Data da retirada do automovel'
/

comment on column SGVALUGUELAUTOMOVEL_AAV.AAV_DTDEVOLUCAO
  is 'Data da devolucao do automovel'
/

comment on column SGVALUGUELAUTOMOVEL_AAV.AAV_NRQUANTIDADEDIA
  is 'Quantidade de dia de aluguel do automovel'
/

comment on column SGVALUGUELAUTOMOVEL_AAV.AAV_VLALUGUELESTIMADO
  is 'Valor estimado do aluguel do veiculo'
/

comment on column SGVALUGUELAUTOMOVEL_AAV.AAV_VLALUGUELREALIZADO
  is 'Valor realizado do aluguel do veiculo'
/

comment on column SGVALUGUELAUTOMOVEL_AAV.AAV_DSJUSTIFICATIVA
  is 'Texto livre para cada etapa do aluguel do automovel'
/

alter table SGVALUGUELAUTOMOVEL_AAV
  add constraint PK_SGVALUGUELAUTOMOVEL_AAV primary key (AAV_IDALUGUELAUTO)
/

alter table SGVALUGUELAUTOMOVEL_AAV
  add constraint FK1_SGVALUGUELAUTOMOVEL_AAV foreign key (AAV_NRSEQVIAGEM)
  references SGVSEQVIAGEM_SGV (SGV_IDSEQVIAGEM) on delete cascade
/

create sequence SEQ1_SGVALUGUELAUTOMOVEL_AAV
minvalue 1
maxvalue 999999999999
start with 1
increment by 1
nocache
/

CREATE OR REPLACE PROCEDURE PRC_INSSGVALUGUELAUTOMOVEL_AAV(
 PAAV_IDALUGUELAUTO      IN OUT NUMBER
,PAAV_NRSEQVIAGEM        IN NUMBER
,PAAV_DTRETIRADA         IN DATE
,PAAV_DTDEVOLUCAO        IN DATE
,PAAV_NRQUANTIDADEDIA   IN NUMBER
,PAAV_VLALUGUELESTIMADO  IN NUMBER
,PAAV_VLALUGUELREALIZADO IN NUMBER
,PAAV_DSJUSTIFICATIVA    IN CHAR
)
AS
BEGIN
  IF PAAV_IDALUGUELAUTO IS NULL THEN
   SELECT SEQ1_SGVALUGUELAUTOMOVEL_AAV.NEXTVAL INTO PAAV_IDALUGUELAUTO FROM DUAL;
  END IF;
  INSERT INTO SGVALUGUELAUTOMOVEL_AAV(
    AAV_IDALUGUELAUTO
   ,AAV_NRSEQVIAGEM
   ,AAV_DTRETIRADA
   ,AAV_DTDEVOLUCAO
   ,AAV_NRQUANTIDADEDIA
   ,AAV_VLALUGUELESTIMADO
   ,AAV_VLALUGUELREALIZADO
   ,AAV_DSJUSTIFICATIVA
) VALUES (
    PAAV_IDALUGUELAUTO
   ,PAAV_NRSEQVIAGEM
   ,PAAV_DTRETIRADA
   ,PAAV_DTDEVOLUCAO
   ,PAAV_NRQUANTIDADEDIA
   ,PAAV_VLALUGUELESTIMADO
   ,PAAV_VLALUGUELREALIZADO
   ,PAAV_DSJUSTIFICATIVA
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSGVALUGUELAUTOMOVEL_AAV(
 PAAV_IDALUGUELAUTO      IN NUMBER
,PAAV_NRSEQVIAGEM        IN NUMBER
,PAAV_DTRETIRADA         IN DATE
,PAAV_DTDEVOLUCAO        IN DATE
,PAAV_NRQUANTIDADEDIA   IN NUMBER
,PAAV_VLALUGUELESTIMADO  IN NUMBER
,PAAV_VLALUGUELREALIZADO IN NUMBER
,PAAV_DSJUSTIFICATIVA    IN CHAR
)
AS
BEGIN
  UPDATE SGVALUGUELAUTOMOVEL_AAV
     SET AAV_NRSEQVIAGEM        = PAAV_NRSEQVIAGEM
        ,AAV_DTRETIRADA         = PAAV_DTRETIRADA
        ,AAV_DTDEVOLUCAO        = PAAV_DTDEVOLUCAO
        ,AAV_NRQUANTIDADEDIA   = PAAV_NRQUANTIDADEDIA
        ,AAV_VLALUGUELESTIMADO  = PAAV_VLALUGUELESTIMADO
        ,AAV_VLALUGUELREALIZADO = PAAV_VLALUGUELREALIZADO
        ,AAV_DSJUSTIFICATIVA    = PAAV_DSJUSTIFICATIVA
   WHERE AAV_IDALUGUELAUTO      = PAAV_IDALUGUELAUTO;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCSGVALUGUELAUTOMOVEL_AAV(
 PAAV_IDALUGUELAUTO IN NUMBER
)
AS
BEGIN
  DELETE FROM SGVALUGUELAUTOMOVEL_AAV
   WHERE AAV_IDALUGUELAUTO = PAAV_IDALUGUELAUTO;
END;
/

alter table SGVTRECHOVIAGEM_TRV add TRV_VBSEGUROVIAGEM CHAR(1)
/

comment on column SGVTRECHOVIAGEM_TRV.TRV_VBSEGUROVIAGEM
  is 'Define se o viajente possui seguro viagem'
/

alter table SGVTRECHOVIAGEM_TRV add TRV_VLSEGUROVIAGEM NUMBER(15,2) default 0
/

comment on column SGVTRECHOVIAGEM_TRV.TRV_VLSEGUROVIAGEM
  is 'Valor do Seguro Viagem'
/

CREATE OR REPLACE PROCEDURE PRC_INSSGVTRECHOVIAGEM_TRV(
 PTRV_IDTRECHO IN OUT NUMBER
,PTRV_IDSEQVIAGEM IN NUMBER
,PTRV_CDTIPOTRECHO IN CHAR
,PTRV_CDUFORIGEM IN CHAR
,PTRV_CDUFDESTINO IN CHAR
,PTRV_CDCIDADEORIGEM IN CHAR
,PTRV_CDCIDADEDESTINO IN CHAR
,PTRV_DTTRECHO IN DATE
,PTRV_VLTRECHO IN NUMBER
,PTRV_IDORIGEM IN NUMBER
,PTRV_DSOBSERVACAO IN CHAR
,PTRV_HRTRECHO IN CHAR
,PTRV_HRCHEGADA IN CHAR
,PTRV_CDAEROPORTOORI IN CHAR
,PTRV_CDAEROPORTODES IN CHAR
,PTRV_VBSEGUROVIAGEM IN CHAR
,PTRV_VLSEGUROVIAGEM IN NUMBER
)
AS
BEGIN
  IF PTRV_IDTRECHO IS NULL THEN
   SELECT SEQ1_SGVTRECHOVIAGEM_TRV.NEXTVAL INTO PTRV_IDTRECHO FROM DUAL;
  END IF;
  INSERT INTO SGVTRECHOVIAGEM_TRV(
    TRV_IDTRECHO
   ,TRV_IDSEQVIAGEM
   ,TRV_CDTIPOTRECHO
   ,TRV_CDUFORIGEM
   ,TRV_CDUFDESTINO
   ,TRV_CDCIDADEORIGEM
   ,TRV_CDCIDADEDESTINO
   ,TRV_DTTRECHO
   ,TRV_VLTRECHO
   ,TRV_IDORIGEM
   ,TRV_DSOBSERVACAO
   ,TRV_HRTRECHO
   ,TRV_HRCHEGADA
   ,TRV_CDAEROPORTOORI
   ,TRV_CDAEROPORTODES
   ,TRV_VBSEGUROVIAGEM
   ,TRV_VLSEGUROVIAGEM
) VALUES (
    PTRV_IDTRECHO
   ,PTRV_IDSEQVIAGEM
   ,PTRV_CDTIPOTRECHO
   ,PTRV_CDUFORIGEM
   ,PTRV_CDUFDESTINO
   ,PTRV_CDCIDADEORIGEM
   ,PTRV_CDCIDADEDESTINO
   ,PTRV_DTTRECHO
   ,PTRV_VLTRECHO
   ,PTRV_IDORIGEM
   ,PTRV_DSOBSERVACAO
   ,PTRV_HRTRECHO
   ,PTRV_HRCHEGADA
   ,PTRV_CDAEROPORTOORI
   ,PTRV_CDAEROPORTODES
   ,PTRV_VBSEGUROVIAGEM
   ,PTRV_VLSEGUROVIAGEM
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSGVTRECHOVIAGEM_TRV(
 PTRV_IDTRECHO IN NUMBER
,PTRV_IDSEQVIAGEM IN NUMBER
,PTRV_CDTIPOTRECHO IN CHAR
,PTRV_CDUFORIGEM IN CHAR
,PTRV_CDUFDESTINO IN CHAR
,PTRV_CDCIDADEORIGEM IN CHAR
,PTRV_CDCIDADEDESTINO IN CHAR
,PTRV_DTTRECHO IN DATE
,PTRV_VLTRECHO IN NUMBER
,PTRV_IDORIGEM IN NUMBER
,PTRV_DSOBSERVACAO IN CHAR
,PTRV_HRTRECHO IN CHAR
,PTRV_HRCHEGADA IN CHAR
,PTRV_CDAEROPORTOORI IN CHAR
,PTRV_CDAEROPORTODES IN CHAR
,PTRV_VBSEGUROVIAGEM IN CHAR
,PTRV_VLSEGUROVIAGEM IN CHAR
)
AS
BEGIN
  UPDATE SGVTRECHOVIAGEM_TRV
     SET TRV_IDTRECHO = PTRV_IDTRECHO
        ,TRV_IDSEQVIAGEM = PTRV_IDSEQVIAGEM
        ,TRV_CDTIPOTRECHO = PTRV_CDTIPOTRECHO
        ,TRV_CDUFORIGEM = PTRV_CDUFORIGEM
        ,TRV_CDUFDESTINO = PTRV_CDUFDESTINO
        ,TRV_CDCIDADEORIGEM = PTRV_CDCIDADEORIGEM
        ,TRV_CDCIDADEDESTINO = PTRV_CDCIDADEDESTINO
        ,TRV_DTTRECHO = PTRV_DTTRECHO
        ,TRV_VLTRECHO = PTRV_VLTRECHO
        ,TRV_IDORIGEM = PTRV_IDORIGEM
        ,TRV_DSOBSERVACAO = PTRV_DSOBSERVACAO
        ,TRV_HRTRECHO = PTRV_HRTRECHO
        ,TRV_HRCHEGADA = PTRV_HRCHEGADA
        ,TRV_CDAEROPORTOORI = PTRV_CDAEROPORTOORI
        ,TRV_CDAEROPORTODES = PTRV_CDAEROPORTODES
        ,TRV_VBSEGUROVIAGEM = PTRV_VBSEGUROVIAGEM
        ,TRV_VLSEGUROVIAGEM = PTRV_VLSEGUROVIAGEM
   WHERE TRV_IDTRECHO = PTRV_IDTRECHO;
END;
/

CREATE TABLE SGVITFATURAALUGUELAUTO_IFA
(
  IFA_IDITFATURA  NUMBER                        NOT NULL,
  IFA_NRFATURA    NUMBER                        NOT NULL,
  IFA_NRALUGUELAUTO    NUMBER                        NOT NULL,
  IFA_VLALUGUELAUTO    NUMBER(15,2)                  DEFAULT 0
)
/

COMMENT ON TABLE SGVITFATURAALUGUELAUTO_IFA IS 'Tabela de itens da fatura de aluguel de automovel'
/

COMMENT ON COLUMN SGVITFATURAALUGUELAUTO_IFA.IFA_IDITFATURA IS 'Identificador do registro'
/

COMMENT ON COLUMN SGVITFATURAALUGUELAUTO_IFA.IFA_NRFATURA IS 'Identificador que relaciona o item a fatura'
/

COMMENT ON COLUMN SGVITFATURAALUGUELAUTO_IFA.IFA_NRALUGUELAUTO IS 'Identificador do registro de aluguel de automovel'
/

COMMENT ON COLUMN SGVITFATURAALUGUELAUTO_IFA.IFA_VLALUGUELAUTO IS 'Valor do aluguel na fatura'
/

ALTER TABLE SGVITFATURAALUGUELAUTO_IFA ADD (
  CONSTRAINT PK_SGVITFATURAALUGUELAUTO_IFA
 PRIMARY KEY
 (IFA_IDITFATURA))
/

ALTER TABLE SGVITFATURAALUGUELAUTO_IFA ADD (
  CONSTRAINT FK1_SGVITFATURAALUGUELAUTO_IFA
 FOREIGN KEY (IFA_NRFATURA)
 REFERENCES SGVFATURAVIAGEM_FVG (FVG_IDFATURA),
  CONSTRAINT FK2_SGVITFATURAALUGUELAUTO_IFA
 FOREIGN KEY (IFA_NRALUGUELAUTO)
 REFERENCES SGVALUGUELAUTOMOVEL_AAV (AAV_IDALUGUELAUTO))
/

create sequence SEQ1_SGVITFATURAALUGUELAU_IFA
minvalue 1
maxvalue 999999999999
start with 1
increment by 1
nocache
/

CREATE OR REPLACE VIEW vw_sgvvaloressolicitacao
AS
   SELECT   cdsolicitacao, cdempresa, cdfilial, cdviajante, usurequisitante,
            dtsolicitacao, cdmoeda, idviagem, tipo, idseqviagem, nrordem,
            SUM (NVL (vltrecho, 0)) AS vltrecho,
            SUM (NVL (vlhospedagem, 0)) AS vlhospedagem,
            SUM (NVL (vladtoviagem, 0)) AS vladtoviagem,
            get_sgvtotaldiaria (idviagem, cdmoeda) AS vldiaria,
            SUM
               (NVL (vlaluguelautomovelprevisto, 0)
               ) AS vlaluguelautomovelprevisto,
            SUM (NVL (vlaluguelautomovelreal, 0)) AS vlaluguelautomovelreal,
            SUM (NVL (vlseguro, 0)) AS vlseguro
       FROM (SELECT s.sol_cdsolicitacao AS cdsolicitacao,
                    s.sol_cdempresa AS cdempresa, s.sol_cdfilial AS cdfilial,
                    s.sol_cdviajante AS cdviajante,
                    s.sol_usurequisitante AS usurequisitante,
                    s.sol_dtsolicitacao AS dtsolicitacao,
                    s.sol_cdmoeda AS cdmoeda, v.via_idviagem AS idviagem,
                    v.via_cdtipo AS tipo, q.sgv_idseqviagem AS idseqviagem,
                    q.sgv_nrordem AS nrordem
               FROM sgvsolicitacao_sol s, sgvseqviagem_sgv q, sgvviagem_via v
              WHERE s.sol_idsolicitacao = v.via_idsolicitacao
                AND v.via_idviagem = q.sgv_idviagem) a,
            (SELECT   t.trv_idseqviagem,
                      NVL (SUM (t.trv_vltrecho), 0) AS vltrecho,
                      NVL (SUM (t.trv_vlseguroviagem), 0) AS vlseguro
                 FROM sgvtrechoviagem_trv t
             GROUP BY t.trv_idseqviagem) b,
            (SELECT   hsp_idseqviagem,
                      NVL (SUM (h.hsp_vlhospedagem), 0) AS vlhospedagem
                 FROM sgvhospedagem_hsp h
             GROUP BY hsp_idseqviagem) c,
            (SELECT   adv_idseqviagem,
                      NVL (SUM (a.adv_nrquantidade * a.adv_vladtoviagem),
                           0
                          ) AS vladtoviagem
                 FROM sgvadtoviagem_adv a
             GROUP BY adv_idseqviagem) d,
            (SELECT   aav_nrseqviagem,
                      NVL
                         (SUM (a.aav_vlaluguelestimado),
                          0
                         ) AS vlaluguelautomovelprevisto,
                      NVL
                         (SUM (a.aav_vlaluguelrealizado),
                          0
                         ) AS vlaluguelautomovelreal
                 FROM sgvaluguelautomovel_aav a
             GROUP BY aav_nrseqviagem) e
      WHERE a.idseqviagem = b.trv_idseqviagem(+) AND a.idseqviagem = c.hsp_idseqviagem(+)
            AND a.idseqviagem = d.adv_idseqviagem(+) AND a.idseqviagem = E.AAV_NRSEQVIAGEM(+)
   GROUP BY cdsolicitacao,
            cdempresa,
            cdfilial,
            cdviajante,
            usurequisitante,
            dtsolicitacao,
            cdmoeda,
            idviagem,
            tipo,
            idseqviagem,
            nrordem
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27545, 'Faturamento de aluguel de autom�vel', 'Faturamento de aluguel de autom�vel')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGV', 27545, 10, 2000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27545, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27545, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27545, 'EXC')
/

CREATE OR REPLACE VIEW VW_SGVTOTALSOLICITACAO AS
SELECT VS.CDSOLICITACAO, VS.CDEMPRESA, VS.CDFILIAL, VS.CDVIAJANTE, VS.TIPO, VS.IDVIAGEM, VS.USUREQUISITANTE, VS.DTSOLICITACAO, VS.CDMOEDA,
       (VS.VLTRECHO + VS.VLHOSPEDAGEM + VS.VLADTOVIAGEM + get_sgvtotaldiaria(VS.IDVIAGEM, VS.CDMOEDA)
       + DECODE(VLALUGUELAUTOMOVELREAL, 0, VLALUGUELAUTOMOVELPREVISTO, VLALUGUELAUTOMOVELREAL)) + VLSEGURO AS VLTOTAL
      FROM VW_SGVVALORESSOLICITACAO VS
/

CREATE TABLE SGVITFATURASEGURO_IFS
(
  IFS_IDITFATURA  NUMBER                        NOT NULL,
  IFS_NRFATURA    NUMBER                        NOT NULL,
  IFS_NRSEGURO    NUMBER                        NOT NULL,
  IFS_VLSEGURO    NUMBER(15,2)                  DEFAULT 0
)
/

COMMENT ON TABLE SGVITFATURASEGURO_IFS IS 'Tabela de itens da fatura de seguro'
/

COMMENT ON COLUMN SGVITFATURASEGURO_IFS.IFS_IDITFATURA IS 'Identificador do registro'
/

COMMENT ON COLUMN SGVITFATURASEGURO_IFS.IFS_NRFATURA IS 'Identificador que relaciona o item a fatura'
/

COMMENT ON COLUMN SGVITFATURASEGURO_IFS.IFS_NRSEGURO IS 'Identificador do registro de seguro viagem'
/

COMMENT ON COLUMN SGVITFATURASEGURO_IFS.IFS_VLSEGURO IS 'Valor do seguro na fatura'
/

ALTER TABLE SGVITFATURASEGURO_IFS ADD (
  CONSTRAINT PK_SGVITFATURASEGURO_IFS
 PRIMARY KEY
 (IFS_IDITFATURA))
/

ALTER TABLE SGVITFATURASEGURO_IFS ADD (
  CONSTRAINT FK1_SGVITFATURASEGURO_IFS
 FOREIGN KEY (IFS_NRFATURA)
 REFERENCES SGVFATURAVIAGEM_FVG (FVG_IDFATURA))
/

CREATE INDEX IN1_SGVITFATURASEGURO_IFS ON SGVITFATURASEGURO_IFS (IFS_NRFATURA)
/

create sequence SEQ1_SGVITFATURASEGURO_IFS
minvalue 1
maxvalue 999999999999
start with 1
increment by 1
nocache
/

CREATE OR REPLACE PROCEDURE PRC_INSSGVITFATURASEGURO_IFS(
 PIFS_IDITFATURA IN OUT NUMBER
,PIFS_NRFATURA IN NUMBER
,PIFS_NRSEGURO IN NUMBER
,PIFS_VLSEGURO IN NUMBER DEFAULT NULL
)
AS
BEGIN
  IF PIFS_IDITFATURA IS NULL THEN
   SELECT SEQ1_SGVITFATURASEGURO_IFS.NEXTVAL INTO PIFS_IDITFATURA FROM DUAL;
  END IF;
  INSERT INTO SGVITFATURASEGURO_IFS(
    IFS_IDITFATURA
   ,IFS_NRFATURA
   ,IFS_NRSEGURO
   ,IFS_VLSEGURO
) VALUES (
    PIFS_IDITFATURA
   ,PIFS_NRFATURA
   ,PIFS_NRSEGURO
   ,PIFS_VLSEGURO
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSGVITFATURASEGURO_IFS(
 PIFS_IDITFATURA IN NUMBER
,PIFS_NRFATURA IN NUMBER
,PIFS_NRSEGURO IN NUMBER
,PIFS_VLSEGURO IN NUMBER DEFAULT NULL
)
AS
BEGIN
  UPDATE SGVITFATURASEGURO_IFS
     SET IFS_IDITFATURA = PIFS_IDITFATURA
        ,IFS_NRFATURA = PIFS_NRFATURA
        ,IFS_NRSEGURO = PIFS_NRSEGURO
        ,IFS_VLSEGURO = PIFS_VLSEGURO
   WHERE IFS_IDITFATURA = PIFS_IDITFATURA;
END;
/

CREATE INDEX IN1_SGVALUGUELAUTOMOVEL_AAV ON SGVALUGUELAUTOMOVEL_AAV (AAV_NRSEQVIAGEM)
/

CREATE INDEX IN1_SGVITFATURAALUGUELAUTO_IFA ON SGVITFATURAALUGUELAUTO_IFA (IFA_NRFATURA)
/

CREATE INDEX IN2_SGVITFATURAALUGUELAUTO_IFA ON SGVITFATURAALUGUELAUTO_IFA (IFA_NRALUGUELAUTO)
/

CREATE OR REPLACE PROCEDURE PRC_INSSGVITFATALUGUELAUTO_IFA(
 PIFA_IDITFATURA IN OUT NUMBER
,PIFA_NRFATURA IN NUMBER
,PIFA_NRALUGUELAUTO IN NUMBER
,PIFA_VLALUGUELAUTO IN NUMBER DEFAULT NULL
)
AS
BEGIN
  IF PIFA_IDITFATURA IS NULL THEN
   SELECT SEQ1_SGVITFATURAALUGUELAU_IFA.NEXTVAL INTO PIFA_IDITFATURA FROM DUAL;
  END IF;
  INSERT INTO SGVITFATURAALUGUELAUTO_IFA(
    IFA_IDITFATURA
   ,IFA_NRFATURA
   ,IFA_NRALUGUELAUTO
   ,IFA_VLALUGUELAUTO
) VALUES (
    PIFA_IDITFATURA
   ,PIFA_NRFATURA
   ,PIFA_NRALUGUELAUTO
   ,PIFA_VLALUGUELAUTO
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSGVITFATALUGUELAUTO_IFA(
 PIFA_IDITFATURA IN NUMBER
,PIFA_NRFATURA IN NUMBER
,PIFA_NRALUGUELAUTO IN NUMBER
,PIFA_VLALUGUELAUTO IN NUMBER DEFAULT NULL
)
AS
BEGIN
  UPDATE SGVITFATURAALUGUELAUTO_IFA
     SET IFA_IDITFATURA = PIFA_IDITFATURA
        ,IFA_NRFATURA = PIFA_NRFATURA
        ,IFA_NRALUGUELAUTO = PIFA_NRALUGUELAUTO
        ,IFA_VLALUGUELAUTO = PIFA_VLALUGUELAUTO
   WHERE IFA_IDITFATURA = PIFA_IDITFATURA;
END;
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27565, 'Faturamento de seguro de viagem', 'Faturamento de seguro de viagem')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGV', 27565, 11, 2000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27565, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27565, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27565, 'EXC')
/

CREATE OR REPLACE VIEW vw_sgvvaloressolicitacao
AS
SELECT cdsolicitacao,
       cdempresa,
       cdfilial,
       cdviajante,
       usurequisitante,
       dtsolicitacao,
       cdmoeda,
       idviagem,
       tipo,
       idseqviagem,
       nrordem,
       SUM(NVL(vltrecho, 0)) AS vltrecho,
       SUM(NVL(vlhospedagem, 0)) AS vlhospedagem,
       SUM(NVL(vladtoviagem, 0)) AS vladtoviagem,
       get_sgvtotaldiaria(idviagem, cdmoeda) AS vldiaria,
       SUM(NVL(vlaluguelautomovelprevisto, 0)) AS vlaluguelautomovelprevisto,
       SUM(NVL(vlaluguelautomovelreal, 0)) AS vlaluguelautomovelreal,
       SUM(NVL(vlseguro, 0)) AS vlseguro
  FROM (SELECT s.sol_cdsolicitacao   AS cdsolicitacao,
               s.sol_cdempresa       AS cdempresa,
               s.sol_cdfilial        AS cdfilial,
               s.sol_cdviajante      AS cdviajante,
               s.sol_usurequisitante AS usurequisitante,
               s.sol_dtsolicitacao   AS dtsolicitacao,
               s.sol_cdmoeda         AS cdmoeda,
               v.via_idviagem        AS idviagem,
               v.via_cdtipo          AS tipo,
               q.sgv_idseqviagem     AS idseqviagem,
               q.sgv_nrordem         AS nrordem
          FROM sgvsolicitacao_sol s, sgvseqviagem_sgv q, sgvviagem_via v
         WHERE s.sol_idsolicitacao = v.via_idsolicitacao
           AND v.via_idviagem = q.sgv_idviagem) a,
       (SELECT t.trv_idseqviagem,
               NVL(SUM(t.trv_vltrecho), 0) AS vltrecho,
               NVL(SUM(t.trv_vlseguroviagem), 0) AS vlseguro
          FROM sgvtrechoviagem_trv t
         GROUP BY t.trv_idseqviagem) b,
       (SELECT hsp_idseqviagem,
               NVL(SUM(h.hsp_vlhospedagem), 0) AS vlhospedagem
          FROM sgvhospedagem_hsp h
         GROUP BY hsp_idseqviagem) c,
       (SELECT adv_idseqviagem,
               NVL(SUM(adv.adv_nrquantidade * adv.adv_vladtoviagem), 0) AS vladtoviagem
          FROM sgvadtoviagem_adv adv
         GROUP BY adv_idseqviagem) d,
       (SELECT aav_nrseqviagem,
               NVL(SUM(aav.aav_vlaluguelestimado), 0) AS vlaluguelautomovelprevisto,
               NVL(SUM(aav.aav_vlaluguelrealizado), 0) AS vlaluguelautomovelreal
          FROM sgvaluguelautomovel_aav aav
         GROUP BY aav_nrseqviagem) e
 WHERE a.idseqviagem = b.trv_idseqviagem(+)
   AND a.idseqviagem = c.hsp_idseqviagem(+)
   AND a.idseqviagem = d.adv_idseqviagem(+)
   AND a.idseqviagem = E.AAV_NRSEQVIAGEM(+)
 GROUP BY cdsolicitacao,
          cdempresa,
          cdfilial,
          cdviajante,
          usurequisitante,
          dtsolicitacao,
          cdmoeda,
          idviagem,
          tipo,
          idseqviagem,
          nrordem
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279648
PROMPT ======================================================================