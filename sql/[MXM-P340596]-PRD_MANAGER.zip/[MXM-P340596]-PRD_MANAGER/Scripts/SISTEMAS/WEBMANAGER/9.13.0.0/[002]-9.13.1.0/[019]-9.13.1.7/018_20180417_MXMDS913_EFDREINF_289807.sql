PROMPT ======================================================================
PROMPT == DEMANDA......: 289807
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: REGEANE OLIVEIRA DA SILVA
PROMPT == DATA.........: 17/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM PARAMS_PAR WHERE PAR_CDPARAM = 'PAREFDREINF_VERSAOREINF8X'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 289807
PROMPT ======================================================================