PROMPT ======================================================================
PROMPT == DEMANDA......: 285133
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: ADRIANO DE LIMA CHAGAS
PROMPT == DATA.........: 16/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE prc_cntintfaturamentod0 (
   pidintegracao   IN   NUMBER,
   pcdempresa      IN   VARCHAR2,
   pcdfilial       IN   VARCHAR2,
   pcdfatura       IN   NUMBER,
   pnota           IN   NUMBER,
   pdtnfiscal      IN   DATE,
   pvlnota         IN   NUMBER,
   pcdcliente      IN   VARCHAR2,
   pnmdocumento    IN   VARCHAR2,
   ppath           IN   VARCHAR2
)
AS
   pipc_idintegracaoprestconta   NUMBER;
   vdtini                        DATE;
   vdtfim                        DATE;
   verificador                   VARCHAR2 (3);
   vcheck                        NUMBER (1);
   pift_observacao               VARCHAR2 (400);
   pift_dstipfatura              VARCHAR2 (100);
BEGIN
   IF (    (pidintegracao IS NOT NULL)
       AND (pcdfatura IS NOT NULL)
       AND (pcdcliente IS NOT NULL)
      )
   THEN
      -- verifica se a nota dessa integra��o j� foi enviada
      SELECT COUNT (*)
        INTO vcheck
        FROM cntintegracaoprestconta_ipc
       WHERE ipc_idintegracao = pidintegracao AND ipc_tpprestacaoconta = 0;
      IF (vcheck = 0)
      THEN
         -- inicia tabela _IPC
         prc_inscntintegprestconta_ipc (pipc_idintegracaoprestconta,
                                        0,
                                        0,
                                        pidintegracao,
                                        pcdcliente
                                       );
         -- inicia tabela _IFT
         vdtini := TRUNC (pdtnfiscal, 'MONTH');
         vdtfim := TRUNC (LAST_DAY (pdtnfiscal));
         pift_observacao :=
                     cntintgetendentregafat (pcdfatura, pcdempresa, pcdfilial);
         pift_dstipfatura :=
                    cntintgetdesctipofatura (pcdfatura, pcdempresa, pcdfilial);
         prc_inscntintegracaofatura_ift (pipc_idintegracaoprestconta,
                                         vdtini,
                                         vdtfim,
                                         pvlnota,
                                         pift_observacao,
                                         pcdempresa,
                                         pcdfilial,
                                         pcdfatura,
                                         pnota,
                                         pift_dstipfatura
                                        );
      ELSE
         SELECT ipc_idintegracaoprestconta
           INTO pipc_idintegracaoprestconta
           FROM cntintegracaoprestconta_ipc
          WHERE ipc_idintegracao = pidintegracao AND ipc_tpprestacaoconta = 0;
      END IF;
      -- Inicia tabela _IAR
      SELECT SUBSTR (ppath, INSTR (ppath, '.', -1, 1) + 1, 3)
        INTO verificador
        FROM DUAL;
      IF (verificador = 'xml')
      THEN
         prc_inscntintegarquivo_iar (pipc_idintegracaoprestconta,
                                     ppath,
                                     1,
                                     pnmdocumento
                                    );
      ELSIF (verificador = 'pdf')
      THEN
         prc_inscntintegarquivo_iar (pipc_idintegracaoprestconta,
                                     ppath,
                                     2,
                                     pnmdocumento
                                    );
      END IF;
   END IF;
END;
/

CREATE OR REPLACE PROCEDURE prc_cntintfaturamentod1 (
   pidintegracao   IN   NUMBER,
   pcdempresa      IN   VARCHAR2,
   pcdfilial       IN   VARCHAR2,
   pcdfatura       IN   NUMBER,
   pnota           IN   NUMBER,
   pdtnfiscal      IN   DATE,
   pvlnota         IN   NUMBER,
   pcdcliente      IN   VARCHAR2,
   pnmdocumento    IN   VARCHAR2,
   ppath           IN   VARCHAR2
)
AS
   pipc_idintegracaoprestconta   NUMBER;
   vdtini                        DATE;
   vdtfim                        DATE;
   verificador                   VARCHAR2 (3);
   vcheck                        NUMBER (1);
   pift_observacao               VARCHAR2 (400);
   pift_dstipfatura              VARCHAR2 (100);
BEGIN
   IF (    (pidintegracao IS NOT NULL)
       AND (pcdfatura IS NOT NULL)
       AND (pcdcliente IS NOT NULL)
      )
   THEN
      -- verifica se a nota dessa integra��o j� foi enviada
      SELECT COUNT (*)
        INTO vcheck
        FROM cntintegracaoprestconta_ipc
       WHERE ipc_idintegracao = pidintegracao AND ipc_tpprestacaoconta = 0;
      IF (vcheck = 0)
      THEN
         -- inicia tabela _IPC
         prc_inscntintegprestconta_ipc (pipc_idintegracaoprestconta,
                                        0,
                                        0,
                                        pidintegracao,
                                        pcdcliente
                                       );
         -- inicia tabela _IFT
         vdtini := TRUNC (ADD_MONTHS (pdtnfiscal, -1), 'MONTH');
         vdtfim := TRUNC (LAST_DAY (ADD_MONTHS (pdtnfiscal, -1)));
         pift_observacao :=
                     cntintgetendentregafat (pcdfatura, pcdempresa, pcdfilial);
         pift_dstipfatura :=
                    cntintgetdesctipofatura (pcdfatura, pcdempresa, pcdfilial);
         prc_inscntintegracaofatura_ift (pipc_idintegracaoprestconta,
                                         vdtini,
                                         vdtfim,
                                         pvlnota,
                                         pift_observacao,
                                         pcdempresa,
                                         pcdfilial,
                                         pcdfatura,
                                         pnota,
                                         pift_dstipfatura
                                        );
      ELSE
         SELECT ipc_idintegracaoprestconta
           INTO pipc_idintegracaoprestconta
           FROM cntintegracaoprestconta_ipc
          WHERE ipc_idintegracao = pidintegracao AND ipc_tpprestacaoconta = 0;
      END IF;
      -- Inicia tabela _IAR
      SELECT SUBSTR (ppath, INSTR (ppath, '.', -1, 1) + 1, 3)
        INTO verificador
        FROM DUAL;
      IF (verificador = 'pdf')
      THEN
         prc_inscntintegarquivo_iar (pipc_idintegracaoprestconta,
                                     ppath,
                                     1,
                                     pnmdocumento
                                    );
      ELSIF (verificador = 'xml')
      THEN
         prc_inscntintegarquivo_iar (pipc_idintegracaoprestconta,
                                     ppath,
                                     2,
                                     pnmdocumento
                                    );
      END IF;
   END IF;
END;
/

CREATE OR REPLACE PROCEDURE prc_cntintfaturamentod2 (
   pidintegracao   IN   NUMBER,
   pcdempresa      IN   VARCHAR2,
   pcdfilial       IN   VARCHAR2,
   pcdfatura       IN   NUMBER,
   pnota           IN   NUMBER,
   pdtnfiscal      IN   DATE,
   pvlnota         IN   NUMBER,
   pcdcliente      IN   VARCHAR2,
   pnmdocumento    IN   VARCHAR2,
   ppath           IN   VARCHAR2
)
AS
   pipc_idintegracaoprestconta   NUMBER;
   vdtini                        DATE;
   vdtfim                        DATE;
   verificador                   VARCHAR2 (3);
   vcheck                        NUMBER (1);
   pift_observacao               VARCHAR2 (400);
   pift_dstipfatura              VARCHAR2 (100);
BEGIN
   IF (    (pidintegracao IS NOT NULL)
       AND (pcdfatura IS NOT NULL)
       AND (pcdcliente IS NOT NULL)
      )
   THEN
      -- verifica se a nota dessa integra��o j� foi enviada
      SELECT COUNT (*)
        INTO vcheck
        FROM cntintegracaoprestconta_ipc
       WHERE ipc_idintegracao = pidintegracao AND ipc_tpprestacaoconta = 0;
      IF (vcheck = 0)
      THEN
         -- inicia tabela _IPC
         prc_inscntintegprestconta_ipc (pipc_idintegracaoprestconta,
                                        0,
                                        0,
                                        pidintegracao,
                                        pcdcliente
                                       );
         -- inicia tabela _IFT
         vdtini := TRUNC (pdtnfiscal, 'MONTH');
         vdtfim := TRUNC (LAST_DAY (pdtnfiscal));
         pift_observacao :=
                     cntintgetendentregafat (pcdfatura, pcdempresa, pcdfilial);
         pift_dstipfatura :=
                    cntintgetdesctipofatura (pcdfatura, pcdempresa, pcdfilial);
         prc_inscntintegracaofatura_ift (pipc_idintegracaoprestconta,
                                         vdtini,
                                         vdtfim,
                                         pvlnota,
                                         pift_observacao,
                                         pcdempresa,
                                         pcdfilial,
                                         pcdfatura,
                                         pnota,
                                         pift_dstipfatura
                                        );
      ELSE
         SELECT ipc_idintegracaoprestconta
           INTO pipc_idintegracaoprestconta
           FROM cntintegracaoprestconta_ipc
          WHERE ipc_idintegracao = pidintegracao AND ipc_tpprestacaoconta = 0;
      END IF;
      -- Inicia tabela _IAR
      SELECT SUBSTR (ppath, INSTR (ppath, '.', -1, 1) + 1, 3)
        INTO verificador
        FROM DUAL;
      IF (verificador = 'pdf')
      THEN
         prc_inscntintegarquivo_iar (pipc_idintegracaoprestconta,
                                     ppath,
                                     4,
                                     pnmdocumento
                                    );
      ELSIF (verificador = 'xml')
      THEN
         prc_inscntintegarquivo_iar (pipc_idintegracaoprestconta,
                                     ppath,
                                     2,
                                     pnmdocumento
                                    );
      END IF;
   END IF;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 285133
PROMPT ======================================================================