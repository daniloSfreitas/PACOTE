PROMPT ======================================================================
PROMPT == DEMANDA......: 289570
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: ANDERSON MALHEIROS MARTINS
PROMPT == DATA.........: 17/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;
/*
    INCLUIDO NA DEMANDA 288909
	
ALTER TABLE FORNEC_FOR ADD (FOR_VBENVIARINFORMEREND CHAR(1 BYTE) DEFAULT 'N')
/

*/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR), (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='FORNEC_FOR'),'FORNEC_FOR.FOR_VBENVIARINFORMEREND','Enviar informe rendimento por email',0,'Env. informe email')
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'FORNEC_FOR')),
                 'Env. informe email', --Descri��o do filtro na tela onde imprime o relat�rio
       0,
       0,
                 'FORNEC_FOR',
       '',
       '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'FORNEC_FOR'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'FORNEC_FOR')),
             'FORNEC_FOR.FOR_VBENVIARINFORMEREND', 'Env. informe email' --Descri��o do filtro na montagem do relat�rio
            )
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 289570
PROMPT ======================================================================