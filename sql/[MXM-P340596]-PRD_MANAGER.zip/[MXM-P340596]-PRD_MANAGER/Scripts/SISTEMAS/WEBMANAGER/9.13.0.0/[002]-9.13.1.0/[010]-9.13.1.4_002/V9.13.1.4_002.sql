PROMPT =============================================================
PROMPT Chamador dos scripts da versao 9.13.1.4_002 gerados em 22/01/2018
PROMPT =============================================================

@@001_20180122_MXMDS913_SGE_285461.sql

INSERT INTO VERSAO_VER
	(VER_DATA, VER_VERSAO)
VALUES
	(SYSDATE,'9.13.1.4_002');

COMMIT;
