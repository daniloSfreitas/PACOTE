PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.7_005 gerados em 25/05/2018 
PROMPT ============================================================= 

@@001_20180525_MXMDS913_EFDREINF_292698.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.7_005');

COMMIT;
