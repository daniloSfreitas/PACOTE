PROMPT ======================================================================
PROMPT == DEMANDA......: 285051
PROMPT == SISTEMA......: Contratos de Compras
PROMPT == RESPONSAVEL..: LUANA MARIA DE SOUZA
PROMPT == DATA.........: 15/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE INDCONTRATO_ICNT SET ICNT_ATUAL = 'N' WHERE ICNT_ATUAL IS NULL
/

UPDATE INDCONTRATO_ICNT SET ICNT_ATUAL = 'S' WHERE ICNT_ATUAL  = '*'
/

ALTER TABLE VALORCONTRATO_VCON MODIFY VCON_VALORNOVO NUMBER(23,2)
/

ALTER TABLE VALORCONTRATO_VCON MODIFY VCON_VALORANTIGO NUMBER(23,2)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 285051
PROMPT ======================================================================