PROMPT ======================================================================
PROMPT == DEMANDA......: 283576
PROMPT == SISTEMA......: Sistema MXM Administrador
PROMPT == RESPONSAVEL..: ANDERSON EIJI NOGUTI
PROMPT == DATA.........: 20/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

DECLARE
 N_COUNT INTEGER;
BEGIN
 SELECT COUNT (*) INTO N_COUNT FROM USER_TRIGGERS  WHERE TRIGGER_NAME = 'TRG1_USUEMPRESA_UEM';
 IF N_COUNT>0 THEN
  EXECUTE IMMEDIATE 'DROP TRIGGER TRG1_USUEMPRESA_UEM';
 END IF;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283576
PROMPT ======================================================================