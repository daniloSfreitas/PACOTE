PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.7_002 gerados em 04/05/2018 
PROMPT ============================================================= 

@@001_20180504_MXMDS913_EFDREINF_290657.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.7_002');

COMMIT;
