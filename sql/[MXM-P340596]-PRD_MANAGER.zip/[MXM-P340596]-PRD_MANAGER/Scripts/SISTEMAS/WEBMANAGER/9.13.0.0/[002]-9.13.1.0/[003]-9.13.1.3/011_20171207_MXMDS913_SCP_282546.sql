PROMPT ======================================================================
PROMPT == DEMANDA......: 282546
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: NIKOLAS DE AGUIAR PONTES
PROMPT == DATA.........: 04/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO grefiltrocampotab_fct
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela = (SELECT tdr_idtabela
                             FROM gretabdicdados_tdr
                            WHERE tdr_nmtabela = 'TITCP_TCP')),
   'Data de Faturamento',
   0,
   1,
   '',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'TITCP_TCP'))
       AND trv_nrtabela = (SELECT tdr_idtabela
                             FROM gretabdicdados_tdr
                            WHERE tdr_nmtabela = 'TITCP_TCP')),
   'TITCP_TCP.TCP_DTFATURA',
   'Data de Faturamento')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282546
PROMPT ======================================================================