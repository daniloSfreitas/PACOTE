/*
    Incluindo ajuste da Elimina��o da trigger encontrado no cliente conforme informado pelo Alan.

De: Alan Batista 
Enviada em: quarta-feira, 6 de dezembro de 2017 17:22
Para: Filipe Santos <filipe.santos@mxm.com.br>; Julian Alves <julian.alves@mxm.com.br>; ASPBD <aspbd@mxm.com.br>
Cc: Ulisses Hirata <ulisses.hirata@mxm.com.br>; Camila Guzella Galv�o <camila.galvao@mxm.com.br>; Marcio Gon�alves Vidal <marcio.vidal@mxm.com.br>; Elizabet Vianna <bet@mxm.com.br>; ASP_SAAS <ASP_SAAS@mxm.com.br>; Anderson Lopes <anderson.lopes@mxm.com.br>; Renato Silva <renato.silva@mxm.com.br>
Assunto: RES: EXPEDIA - PRIORIDADE - GO LIVE MIGRA��O WEBMANAGER - CONFIRMADO 

Bom,
Neste caso, � melhor subir um drop dela em nosso pacote pra n�o passarmos mais por este problema.

Atenciosamente,
 
 
Alan da Silva Batista
MXM Sistemas
Gerencia de Desenvolvimento de Software
Tel.: (21) 3233-2300 / (21) 98244-8833
alan.batista@ mxm.com.br
----------------------------------------------
 

De: Filipe Santos 
Enviada em: quarta-feira, 6 de dezembro de 2017 17:02
Para: Alan Batista <alan.batista@mxm.com.br>; Julian Alves <julian.alves@mxm.com.br>; ASPBD <aspbd@mxm.com.br>
Cc: Ulisses Hirata <ulisses.hirata@mxm.com.br>; Camila Guzella Galv�o <camila.galvao@mxm.com.br>; Marcio Gon�alves Vidal <marcio.vidal@mxm.com.br>; Elizabet Vianna <bet@mxm.com.br>; ASP_SAAS <ASP_SAAS@mxm.com.br>; Anderson Lopes <anderson.lopes@mxm.com.br>; Renato Silva <renato.silva@mxm.com.br>
Assunto: RES: EXPEDIA - PRIORIDADE - GO LIVE MIGRA��O WEBMANAGER - CONFIRMADO 

Alan,

                O ambiente do cliente EXPEDIA veio do cliente ACAL. Provavelmente esse trigger j� estava no ambiente.

                Obs.: No PAT 131259 consta a disponibiliza��o desse trigger para o cliente �CENTRO CLINICO GAUCHO LTDA�. Provavelmente, foi enviado da mesma forma para este cliente.




 
Filipe Rocha dos Santos
MXM Sistemas
Desenvolvimento MXM-Manager
Tel.: (21) 3233-2300 
filipe.santos@mxm.com.br
----------------------------------------------
    

De: Alan Batista 
Enviada em: quarta-feira, 6 de dezembro de 2017 16:13
Para: Julian Alves <julian.alves@mxm.com.br>; ASPBD <aspbd@mxm.com.br>
Cc: Ulisses Hirata <ulisses.hirata@mxm.com.br>; Camila Guzella Galv�o <camila.galvao@mxm.com.br>; Marcio Gon�alves Vidal <marcio.vidal@mxm.com.br>; Elizabet Vianna <bet@mxm.com.br>; ASP_SAAS <ASP_SAAS@mxm.com.br>; Anderson Lopes <anderson.lopes@mxm.com.br>; Renato Silva <renato.silva@mxm.com.br>
Assunto: RES: EXPEDIA - PRIORIDADE - GO LIVE MIGRA��O WEBMANAGER - CONFIRMADO 

Pessoal,
Precisamos identificar a origem de cria��o desta trigger. Pe�o que investiguem.

Atenciosamente,
 
 
Alan da Silva Batista
MXM Sistemas
Gerencia de Desenvolvimento de Software
Tel.: (21) 3233-2300 / (21) 98244-8833
alan.batista@ mxm.com.br
----------------------------------------------
    

De: Julian Alves 
Enviada em: quarta-feira, 6 de dezembro de 2017 16:11
Para: ASPBD <aspbd@mxm.com.br>
Cc: Alan Batista <alan.batista@mxm.com.br>; Ulisses Hirata <ulisses.hirata@mxm.com.br>; Camila Guzella Galv�o <camila.galvao@mxm.com.br>; Marcio Gon�alves Vidal <marcio.vidal@mxm.com.br>; Elizabet Vianna <bet@mxm.com.br>; ASP_SAAS <ASP_SAAS@mxm.com.br>; Anderson Lopes <anderson.lopes@mxm.com.br>; Renato Silva <renato.silva@mxm.com.br>
Assunto: RES: EXPEDIA - PRIORIDADE - GO LIVE MIGRA��O WEBMANAGER - CONFIRMADO 

Prezados,

Atrav�s de conex�o remota, identifiquei a exist�ncia da Trigger �INTEGRA_SPED_FORNECEDOR_TRX�, que causava o erro ao cadastrar o fornecedor.

N�o identifiquei a origem desta Trigger, pois n�o foi criada por demanda.
Ao desabilitar esta trigger, o erro n�o ocorre e o Fornecedor � gravado corretamente.

Segue em anexo o Script que dropa a trigger. 

Favor aplicar o Script na base Projetos.


Atenciosamente,
 
 
Julian Alves
MXM Sistemas
Desenvolvimento MXM-Manager
Tel.: (21) 3233-2300 / 98244-0977
julian.alves@mxm.com.br
--------------------------------------------
     

De: Camila Guzella Galv�o 
Enviada em: quarta-feira, 6 de dezembro de 2017 15:35
Para: Marcio Gon�alves Vidal <marcio.vidal@mxm.com.br>; Julian Alves <julian.alves@mxm.com.br>; Elizabet Vianna <bet@mxm.com.br>; ASP_SAAS <ASP_SAAS@mxm.com.br>; Anderson Lopes <anderson.lopes@mxm.com.br>; Renato Silva <renato.silva@mxm.com.br>
Cc: Alan Batista <alan.batista@mxm.com.br>; Ulisses Hirata <ulisses.hirata@mxm.com.br>
Assunto: Re: EXPEDIA - PRIORIDADE - GO LIVE MIGRA��O WEBMANAGER - CONFIRMADO 

Boa tarde Senhores!

Refor�o pedido de prioridade para os PATs do cliente Expedia.

Caso tenha d�vidas, encontro-me � disposi��o para maiores esclarecimentos.
Atenciosamente,

 
Camila Galv�o
      MXM Sistemas
Projetos/Consultoria
      Tel.: (11) 3171-0841 
      Cel.(11) 9 8885-7622
      camila.galvao@mxm.com.br
----------------------------------------------
 


*/


DROP TRIGGER INTEGRA_SPED_FORNECEDOR_TRX
/




/*
      
	  Ajuste solicitado pelo Filipe Verificado atraves do pat 283009

*/

INSERT INTO mxs_funcaoperfil_mxfp
            (mxfp_perfilacesso, mxfp_funcao, mxfp_propriedade)
   SELECT mxfp_perfilacesso, '11158', mxfp_propriedade
     FROM mxs_funcaoperfil_mxfp
    WHERE mxfp_funcao = '1479';
/


Commit;

