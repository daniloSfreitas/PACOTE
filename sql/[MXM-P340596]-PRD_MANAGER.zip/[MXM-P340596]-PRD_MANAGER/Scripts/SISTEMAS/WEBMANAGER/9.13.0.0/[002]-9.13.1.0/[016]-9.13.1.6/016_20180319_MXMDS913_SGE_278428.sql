PROMPT ======================================================================
PROMPT == DEMANDA......: 278428
PROMPT == SISTEMA......: Estoque
PROMPT == RESPONSAVEL..: JULIANO MENEZES
PROMPT == DATA.........: 02/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_PROCCONTABFATBLOQUEADO(
  pEMPRESA IN CHAR,
  pFILIAL  IN CHAR)
RETURN BOOLEAN IS
  VCOUNT NUMBER;
  VCHAVE VARCHAR2(50);
  CURSOR CS_PROCESSOBLOQUEADO IS
    SELECT COUNT(1)
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = VCHAVE;
BEGIN
  VCHAVE := 'BLQCONTABPERFATURAMENTO' || pEMPRESA || pFILIAL;
  OPEN CS_PROCESSOBLOQUEADO;
  FETCH CS_PROCESSOBLOQUEADO INTO VCOUNT;
  CLOSE CS_PROCESSOBLOQUEADO;
  RETURN(VCOUNT > 0);
END;
/

CREATE OR REPLACE FUNCTION GET_PROCCONTABESTBLOQUEADO(
  pEMPRESA IN CHAR,
  pESTOQUE IN CHAR)
RETURN BOOLEAN IS
  VCOUNT NUMBER;
  VCHAVE VARCHAR2(50);
  CURSOR CS_PROCESSOBLOQUEADO IS
    SELECT COUNT(1)
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = VCHAVE;
BEGIN
  VCHAVE := 'BLQCONTABPERESTOQUE' || pEMPRESA || pESTOQUE;
  OPEN CS_PROCESSOBLOQUEADO;
  FETCH CS_PROCESSOBLOQUEADO INTO VCOUNT;
  CLOSE CS_PROCESSOBLOQUEADO;
  RETURN(VCOUNT > 0);
END;
/

CREATE OR REPLACE FUNCTION GET_PERIODOCONTABILBLOQUEADO(
  pEMPRESA IN CHAR,
  pDATA    IN DATE)
RETURN BOOLEAN IS
  VCOUNT NUMBER;
  CURSOR CS_PERIODOLIBERADO IS
    SELECT COUNT(1)
      FROM LIBERACAO_LIB
     WHERE LIB_CDEMPRESA = pEMPRESA
       AND TO_DATE(LIB_DATA, 'DD/MM/RR') = TO_DATE(pDATA, 'DD/MM/RR')
       AND LIB_CDSISTEMA = 'SCB';
  CURSOR CS_PERIODOLIBERADOPORPERFIL IS
    SELECT COUNT(1)
      FROM LIBPERGRUPO_LPG
     WHERE LPG_EMPRESA = pEMPRESA
       AND EXISTS (SELECT NULL
                     FROM MXS_PERFILUSUARIO_MXPU
                    WHERE MXPU_USUARIO      = GET_USER_MXM
                      AND MXPU_PERFILACESSO = LPG_PERFILACESSO )
       AND TO_DATE(LPG_DATA, 'DD/MM/RR') = TO_DATE(pDATA,'DD/MM/RR')
       AND LPG_CDSISTEMA = 'SCB'
       AND LPG_GRPTRB    = -1;
BEGIN
  OPEN CS_PERIODOLIBERADO;
  FETCH CS_PERIODOLIBERADO INTO VCOUNT;
  CLOSE CS_PERIODOLIBERADO;
  IF (VCOUNT = 0) THEN
    OPEN CS_PERIODOLIBERADOPORPERFIL;
    FETCH CS_PERIODOLIBERADOPORPERFIL INTO VCOUNT;
    CLOSE CS_PERIODOLIBERADOPORPERFIL;
    RETURN(VCOUNT = 0);
  ELSE
    RETURN(VCOUNT = 0);
  END IF;
END;
/

CREATE OR REPLACE PROCEDURE GERA_MOVIMENTO_CONTABIL
(
  pEMPRESA      IN CHAR,
  pESTOQUE      IN CHAR,
  pDATA         IN DATE,
  PINDDOCUMENTO IN CHAR,
  pINDGRPPRD    IN CHAR,
  pAGRUPA       IN CHAR DEFAULT NULL
) AS
  ---
  vULTCONTAB    DATE;
  vTIPO         CHAR(1);
  vDOCUMENTO    MOVIMENTO_MOV.MOV_DOCUMENTO%TYPE;
  --vOBSMOV       MOVIMENTO_MOV.MOV_OBS%TYPE;
  vULTDOCUMENTO MOVIMENTO_MOV.MOV_DOCUMENTO%TYPE;
  vSEQLANCCTB   NUMBER(6);
  vLANCCTB      VARCHAR2(6);
  vSEQUENCIA    NUMBER(6);
  vCONTAB1      LANCCTB_LCT.LCT_NOCONTAB%TYPE;
  vCONTAB2      LANCCTB_LCT.LCT_NOCONTAB%TYPE;
  vNOCCUSTO1    LANCCTB_LCT.LCT_NOCCUSTO%TYPE;
  vNOCCUSTO2    LANCCTB_LCT.LCT_NOCCUSTO%TYPE;
  vDC           LANCCTB_LCT.LCT_DC%TYPE;
  vHISTORICO    LANCCTB_LCT.LCT_HISTORICO%TYPE;
  vVALORCTB     LANCCTB_LCT.LCT_VALOR%TYPE;
  vVALORCTBM    LANCCTB_LCT.LCT_VALORM%TYPE;
  vSEGMOEDA     LANCCTB_LCT.LCT_TPLANC%TYPE;
  vCODPLANO     LANCCTB_LCT.LCT_PLCONTAB%TYPE;
  vCONTA        LANCCTB_LCT.LCT_NOCONTAB%TYPE;
  vCCUSTO       CHAR(1);
  --Thiago
  vSEQANT NUMBER(6);
  ---
  vERROR                     BOOLEAN;
  vERRORMSG                  BOOLEAN;
  vEXISTE_PARAM_ULTIMA_DATA  BOOLEAN;
  vALMOX                     MOVIMENTO_MOV.MOV_ALMOXARIFADO%TYPE;
  vITEM                      MOVIMENTO_MOV.MOV_ITEM%TYPE;
  vSALDOQTD                  MOVIMENTO_MOV.MOV_QTD%TYPE;
  vSALDOVALOR                MOVIMENTO_MOV.MOV_VALOR%TYPE;
  vSALDOVALORM               MOVIMENTO_MOV.MOV_VALORM%TYPE;
  vMENSAGEMERRO              VARCHAR2(500);
  VCDPROJETO                 MOVIMENTO_MOV.MOV_CDPROJETO%TYPE;
  VBCustoNormalTransEmpresas PARAMS_PAR.PAR_VLPARAM%TYPE;
  vPERIODOBLOQUEADO          BOOLEAN;
  ---
  vCONTABCOMP NUMBER(1);
  ---
  SGECONT001 EXCEPTION;
  SGECONT002 EXCEPTION;
  SGECONT003 EXCEPTION;
  SGECONT004 EXCEPTION;
  SGECONT005 EXCEPTION;
  SGECONT006 EXCEPTION;
  SGECONT007 EXCEPTION;
  SGECONT008 EXCEPTION;
  SGECONT009 EXCEPTION;
  SGECONT010 EXCEPTION;
  SGECONT011 EXCEPTION;
  SGECONT015 EXCEPTION;
  CURSOR MOV IS
    SELECT RTRIM(TIPO),
           RTRIM(MOV_TIPO),
           RTRIM(CP),
           RTRIM(UP),
           RTRIM(CR),
           RTRIM(UR),
           RTRIM(HP),
           SUM(MOV_VALOR),
           SUM(MOV_VALORM),
           MOV_CDPROJETO
      FROM (SELECT DECODE(PINDDOCUMENTO,
                          'S',
                          A.MOV_DOCUMENTO,
                          NULL) AS TIPO,
                   A.MOV_TIPO,
                   Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                            A.MOV_TPESTOQUE,
                                            A.MOV_ITEM,
                                            A.MOV_OPERACAO,
                                            A.MOV_DOCUMENTO,
                                            A.MOV_OBS,
                                            A.MOV_DESTINACAO,
                                            'CP',
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            A.MOV_SQNOTA) AS CP,
                   --Se for Conta Patrimonial uso Centro de Custo do Parametro. Se for Resultado Posso Usar ccusto do Estoque
                   NVL(Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                                A.MOV_TPESTOQUE,
                                                A.MOV_ITEM,
                                                A.MOV_OPERACAO,
                                                A.MOV_DOCUMENTO,
                                                A.MOV_OBS,
                                                A.MOV_DESTINACAO,
                                                'UP',
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                A.MOV_SQNOTA),
                       A.MOV_NOCCUSTO) AS UP,
                   Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                            A.MOV_TPESTOQUE,
                                            A.MOV_ITEM,
                                            A.MOV_OPERACAO,
                                            A.MOV_DOCUMENTO,
                                            A.MOV_OBS,
                                            A.MOV_DESTINACAO,
                                            'CR',
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            A.MOV_SQNOTA) AS CR,
           NVL(NVL(A.MOV_NOCCUSTO, Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                                A.MOV_TPESTOQUE,
                                                A.MOV_ITEM,
                                                A.MOV_OPERACAO,
                                                A.MOV_DOCUMENTO,
                                                A.MOV_OBS,
                                                A.MOV_DESTINACAO,
                                                'UR',
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                            A.MOV_SQNOTA)),
                   B.MOV_NOCCUSTO) AS UR,
                   Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                            A.MOV_TPESTOQUE,
                                            A.MOV_ITEM,
                                            A.MOV_OPERACAO,
                                            A.MOV_DOCUMENTO,
                                            A.MOV_OBS,
                                            A.MOV_DESTINACAO,
                                            'HP',
                                            PINDDOCUMENTO,
                                            'S',
                                            pINDGRPPRD,
                                            pAGRUPA,
                                            A.MOV_SQNOTA) AS HP,
                   A.MOV_VALOR,
                   A.MOV_VALORM,
                   A.MOV_CDPROJETO
              FROM MOVIMENTO_MOV A,
                   MOVIMENTO_MOV B,
                   TPOPER_TPO,
                   NOTA_NT
             WHERE A.MOV_SQNOTARELTRANSF = B.MOV_SQNOTA(+)
               AND A.MOV_SEQUENCIA = B.MOV_SEQUENCIA(+)
               AND A.MOV_SQNOTA = NT_SQNOTA
               AND A.MOV_CDEMPRESA = pEMPRESA
               AND A.MOV_TPESTOQUE = pESTOQUE
               AND TPO_CODIGO = A.MOV_OPERACAO
               AND TPO_GECONT = 'S'
               AND ((TPO_DEVOLUCAO <> 'N' OR TPO_NOTAFISCAL <> 'S' OR
                   TPO_TIPO <> 'E') OR
                   (TPO_TIPO = 'E' AND TPO_ENTRADATRANSF = 'S' AND
                   NVL(VBCustoNormalTransEmpresas,
                         'N') = 'N') OR (NT_TPNOTA = 13))
               AND A.MOV_DTCONTABILIZADO IS NULL
               AND DECODE(A.MOV_TIPO,
                          'S',
                          DECODE(TPO_NOTAFISCAL,
                                 'S',
                                 DECODE(TPO_DEVOLUCAO,
                                        'S',
                                        'N',
                                        'S'),
                                 'S'),
                          'S') = 'S'
               AND A.MOV_DATA <= pDATA)
     GROUP BY TIPO,
              MOV_TIPO,
              CP,
              UP,
              CR,
              UR,
              HP,
              MOV_CDPROJETO;
  CURSOR CCUSTO IS
    SELECT PLC_CCUSTO
      FROM PLANOCTA_PLC
     WHERE PLC_CODPLANO = VCODPLANO
       AND PLC_NOCONTAB = VCONTA;
  CURSOR CUSTONORMALTRANSEMPRESAS IS
    SELECT PAR_VLPARAM
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = 'wSGE_CustoNormalTransEmpresas';
  FUNCTION EXISTE_PARAM_ULTIMA_DATA
  RETURN BOOLEAN
  AS
    VCOUNT NUMBER;
    CURSOR PARAM_ULTIMA_DATA IS
      SELECT COUNT(1)
        FROM PARAMS_PAR
       WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE;
  BEGIN
    OPEN PARAM_ULTIMA_DATA;
    FETCH PARAM_ULTIMA_DATA INTO VCOUNT;
    CLOSE PARAM_ULTIMA_DATA;
    RETURN(VCOUNT > 0);
  END;
  FUNCTION EXISTE_MENSAGEM_DE_ERRO
  RETURN BOOLEAN
  AS
    VCOUNT NUMBER;
    CURSOR ERROR_COUNT IS
      SELECT COUNT(1)
        FROM ERROPROCESSO_EPC;
  BEGIN
    OPEN ERROR_COUNT;
    FETCH ERROR_COUNT INTO VCOUNT;
    CLOSE ERROR_COUNT;
    RETURN(VCOUNT > 0);
  END;
BEGIN
  vPERIODOBLOQUEADO := GET_PERIODOCONTABILBLOQUEADO(pEMPRESA, pDATA);
  IF vPERIODOBLOQUEADO THEN
    vMENSAGEMERRO := 'Lancamentos em periodo contabil bloqueado. Data: ' || pDATA;
    RAISE SGECONT015;
  END IF;
  ---
  SELECT MIN(MOV_DTCONTABILIZADO)
    INTO vULTCONTAB
    FROM MOVIMENTO_MOV
   WHERE MOV_CDEMPRESA        = pEMPRESA
     AND MOV_TPESTOQUE        = pESTOQUE
     AND MOV_DTCONTABILIZADO IS NOT NULL
     AND MOV_DATA            <= pDATA;
  IF vULTCONTAB >= pDATA THEN
    -- Erro para periodo ja contabilizado -- A descricao consta na tabela de erros para ocodigo abaixo
    RAISE SGECONT001;
  END IF;
  ---
  OPEN CUSTONORMALTRANSEMPRESAS;
  FETCH CUSTONORMALTRANSEMPRESAS INTO VBCustoNormalTransEmpresas;
  CLOSE CUSTONORMALTRANSEMPRESAS;
  OPEN MOV;
  FETCH MOV INTO vDOCUMENTO, vTIPO, vCONTAB1, vNOCCUSTO1, vCONTAB2, vNOCCUSTO2, vHISTORICO, vVALORCTB, vVALORCTBM, VCDPROJETO;
  IF NOT MOV%FOUND THEN
    -- N?o ha movimento a contabilizar -- A descricao consta na tabela de erros para ocodigo abaixo
    RAISE SGECONT002;
  END IF;
  -- VERIFICA SE POSSUI ERRO
  vERROR := PKG_CALCULOCUSTOESTOQUE.EXISTS_ERROR_SALDO(pEMPRESA,
                                                       pESTOQUE,
                                                       NULL,
                                                       NULL);
  -- VERIFICA SE FORMAM INCLUIDAS MENSAGENS DE ERRO
  vERRORMSG := EXISTE_MENSAGEM_DE_ERRO;
  -- SE OUVER ERRO NAO FAZ A CONTABILIZACAO
  IF ((NOT vERROR) AND (NOT vERRORMSG)) THEN
    COMMIT;
    ---
    SELECT EST_SEGMOEDA
      INTO vSEGMOEDA
      FROM ESTOQUES_EST
     WHERE EST_CODIGO = pESTOQUE;
    ---
    vSEQLANCCTB   := 0;
    vULTDOCUMENTO := NULL;
    vLANCCTB      := pESTOQUE;
    vSEQUENCIA    := 0;
    WHILE MOV%FOUND LOOP
      vSEQANT := 0;
      ---
      IF RTRIM(vCONTAB1) IS NULL THEN
        RAISE SGECONT003;
      END IF;
      IF RTRIM(vCONTAB2) IS NULL THEN
        RAISE SGECONT004;
      END IF;
      ---
      IF vNOCCUSTO1 IS NULL THEN
        vNOCCUSTO1 := '               ';
      END IF;
      IF vNOCCUSTO2 IS NULL THEN
        vNOCCUSTO2 := '               ';
      END IF;
      ---
      IF vTIPO = 'S' THEN
        vDC := 'C';
      ELSE
        vDC := 'D';
      END IF;
      ---
      IF vVALORCTB <> 0 OR vVALORCTBM <> 0 OR RTRIM(vCONTAB1) <> RTRIM(vCONTAB2) THEN
        IF (pINDDOCUMENTO = 'S') AND (vULTDOCUMENTO IS NULL OR vULTDOCUMENTO <> vDOCUMENTO) THEN
          vULTDOCUMENTO := vDOCUMENTO;
          vSEQLANCCTB   := vSEQLANCCTB + 1;
          vSEQUENCIA    := 0;
          vLANCCTB      := pESTOQUE || Padr(vSEQLANCCTB, 4, '0');
        END IF;
        ---
        SELECT EMP_CODPLCONTA
          INTO vCODPLANO
          FROM EMP
         WHERE EMP_CODIGO = pEMPRESA;
        ---
        vCONTA := vCONTAB1;
        OPEN CCUSTO;
        FETCH CCUSTO INTO vCCUSTO;
        CLOSE CCUSTO;
        IF vCCUSTO = 'N' THEN
          vNOCCUSTO1 := '               ';
        END IF;
        IF vCCUSTO = 'O' AND TRIM(vNOCCUSTO1) = '' THEN
          RAISE SGECONT005;
        END IF;
        IF vCCUSTO = 'E' THEN
          BEGIN
            SELECT RCC_NOCCUSTO
              INTO vNOCCUSTO1
              FROM RELCTACC_RCC
             WHERE RCC_CDEMPRESA = pEMPRESA
               AND RCC_NOCONTAB  = vCONTAB1
               AND RCC_NOCCUSTO  = vNOCCUSTO1;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              RAISE SGECONT006;
          END;
        END IF;
        ---
        vSEQUENCIA := vSEQUENCIA + 1;
        ---
        SELECT DECODE(COUNT(PLC_NOCONTAB), 0, 0, 1)
          INTO vCONTABCOMP
          FROM PLANOCTA_PLC
         WHERE PLC_NOCONTAB = vCONTAB1
           AND PLC_SA       = 'A';
        IF vCONTABCOMP = 0 THEN
          -- Conta de estoque inexistente -- A descricao consta na tabela de erros para ocodigo abaixo
          RAISE SGECONT007;
        END IF;
        ---
        INSLANCCTB_LCT(pEMPRESA,
                       'SGE_CC',
                       pDATA,
                       vLANCCTB,
                       vSEQUENCIA,
                       vCONTAB1,
                       vNOCCUSTO1,
                       vHISTORICO,
                       vDC,
                       vVALORCTB,
                       vVALORCTBM,
                       '',
                       vSEGMOEDA,
                       null,
                       null,
                       VCDPROJETO);
        ---
        IF vTIPO = 'S' THEN
          vDC := 'D';
        ELSE
          vDC := 'C';
        END IF;
        ---
        vCONTA := vCONTAB2;
        OPEN CCUSTO;
        FETCH CCUSTO INTO vCCUSTO;
        CLOSE CCUSTO;
        IF vCCUSTO = 'N' THEN
          vNOCCUSTO2 := '               ';
        END IF;
        IF vCCUSTO = 'O' AND vNOCCUSTO2 = '               ' THEN
          RAISE SGECONT008;
        END IF;
        IF vCCUSTO = 'E' THEN
          BEGIN
            SELECT RCC_NOCCUSTO
              INTO vNOCCUSTO2
              FROM RELCTACC_RCC
             WHERE RCC_CDEMPRESA = pEMPRESA
               AND RCC_NOCONTAB  = vCONTAB2
               AND RCC_NOCCUSTO  = vNOCCUSTO2;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              RAISE SGECONT009;
          END;
        END IF;
        --
        IF pAGRUPA = 'S' THEN
          BEGIN
            SELECT MAX(LCT_SEQ)
              INTO vSEQANT
              FROM LANCCTB_LCT
             WHERE LCT_CDEMPRESA = pEMPRESA
               AND LCT_DATA      = pDATA
               AND LCT_LOTE      = 'SGE_CC'
               AND LCT_LANCCTB   = vLANCCTB
               AND LCT_NOCONTAB  = vCONTAB2
               AND LCT_DC        = vDC
               AND LCT_NOCCUSTO  = vNOCCUSTO2;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              vSEQANT := -1;
          END;
          IF vSEQANT IS NULL THEN
            vSEQANT := -1;
          END IF;
        END IF;
        IF vSEQANT <= 0 THEN
          vSEQUENCIA := vSEQUENCIA + 1;
          INSLANCCTB_LCT(pEMPRESA,
                         'SGE_CC',
                         pDATA,
                         vLANCCTB,
                         vSEQUENCIA,
                         vCONTAB2,
                         vNOCCUSTO2,
                         vHISTORICO,
                         vDC,
                         vVALORCTB,
                         vVALORCTBM,
                         '',
                         vSEGMOEDA,
                         null,
                         null,
                         VCDPROJETO);
        ELSE
          UPDATE LANCCTB_LCT
             SET LCT_VALOR  = LCT_VALOR + vVALORCTB,
                 LCT_VALORM = LCT_VALORM + vVALORCTBM
           WHERE LCT_CDEMPRESA = pEMPRESA
             AND LCT_DATA      = pDATA
             AND LCT_LOTE      = 'SGE_CC'
             AND LCT_LANCCTB   = vLANCCTB
             AND LCT_SEQ       = vSEQANT;
        END IF;
      END IF;
      ---
      FETCH MOV INTO vDOCUMENTO,
                     vTIPO,
                     vCONTAB1,
                     vNOCCUSTO1,
                     vCONTAB2,
                     vNOCCUSTO2,
                     vHISTORICO,
                     vVALORCTB,
                     vVALORCTBM,
                     VCDPROJETO;
      ---
    END LOOP;
    ---
    CLOSE MOV;
    ---
    /*
       Ira verificar a existencia de erros gerados pelo processo e que foram
       armazenados na tabela ERROPROCESSO_EPC.
       Caso existam erros, o processo de contabilizacao n?o sera comitado, e sera feito um rollback do processo
    */
    vERRORMSG := EXISTE_MENSAGEM_DE_ERRO;
    IF NOT vERRORMSG THEN
      BEGIN
        COMMIT;
        ---
        UPDATE MOVIMENTO_MOV
           SET MOV_DTCONTABILIZADO = pDATA
         WHERE MOV_CDEMPRESA        = pEMPRESA
           AND MOV_TPESTOQUE        = pESTOQUE
           AND MOV_DATA            <= pDATA
           AND MOV_DTCONTABILIZADO IS NULL;
        vEXISTE_PARAM_ULTIMA_DATA := EXISTE_PARAM_ULTIMA_DATA;
        IF NOT vEXISTE_PARAM_ULTIMA_DATA THEN
          INSERT INTO PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
          VALUES ('SGE_DTCONTABILIZAESTOQUE' ||pEMPRESA || pESTOQUE, TO_CHAR(pDATA,'DD/MM/YYYY'), USER, SYSDATE, null, null, null, null, null, null);
        ELSE
          UPDATE PARAMS_PAR
             SET PAR_VLPARAM = TO_CHAR(pDATA,'DD/MM/YYYY')
           WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE'||pEMPRESA || pESTOQUE;
        END IF;
        RAISE SGECONT011;
      END;
    ELSE
      BEGIN
        ROLLBACK;
      END;
    END IF;
    ---
    -- FIM VARIAVEL ERRO
  ELSE
    -- PEGAR O PRIMEIRO ERRO GERADO E JOGAR NA TELA, ALTERAR POSTARIORMENTE A TELA PARA BUSCAR TODOS OS ERROS GERADOS NA TABELA DE ERRO
    BEGIN
      SELECT ERROCALCULOCUSTO_ECC.ECC_ALMOXARIFADO,
             ERROCALCULOCUSTO_ECC.ECC_ITEM,
             ERROCALCULOCUSTO_ECC.ECC_SALDO,
             ERROCALCULOCUSTO_ECC.ECC_SALDOVALOR,
             ERROCALCULOCUSTO_ECC.ECC_SALDOVALORM
        INTO vALMOX,
             vITEM,
             vSALDOQTD,
             vSALDOVALOR,
             vSALDOVALORM
        FROM ERROCALCULOCUSTO_ECC
       WHERE ECC_CDEMPRESA = pEMPRESA
         AND ECC_TPESTOQUE = pESTOQUE
         AND ROWNUM        = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        vALMOX       := NULL;
        vITEM        := NULL;
        vSALDOQTD    := NULL;
        vSALDOVALOR  := NULL;
        vSALDOVALORM := NULL;
    END;
    ---
    IF (vSALDOQTD IS NOT NULL) OR (vSALDOVALOR IS NOT NULL) OR (vSALDOVALORM IS NOT NULL) THEN
      vMENSAGEMERRO := 'Item: ' || vITEM;
      IF vALMOX IS NOT NULL THEN
        vMENSAGEMERRO := vMENSAGEMERRO || ', Almoxarifado: ' || vALMOX;
      END IF;
      vMENSAGEMERRO := vMENSAGEMERRO || ' saldo de quantidade: ' || vSALDOQTD;
      vMENSAGEMERRO := vMENSAGEMERRO || ' saldo de valor:      ' || vSALDOVALOR;
      IF vSALDOVALORM <> 0 THEN
        vMENSAGEMERRO := vMENSAGEMERRO || ' saldo de valor na segunda moeda:      ' || vSALDOVALORM;
      END IF;
      RAISE SGECONT010;
    END IF;
  END IF;
EXCEPTION
  WHEN SGECONT001 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT001', 1, 'Periodo ja contabilizado');
    END;
  WHEN SGECONT002 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT002', 1, 'N?o ha movimento a contabilizar');
    END;
  WHEN SGECONT003 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT003', 1, 'Conta de estoque n?o parametrizada para o seguinte lancamento: ' || RTRIM(vHISTORICO));
    END;
  WHEN SGECONT004 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT004', 1, 'Conta de destinac?o ou contra-partida n?o parametrizada para o seguinte lancamento: ' || RTRIM(vHISTORICO));
    END;
  WHEN SGECONT005 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT005', 1, 'Conta Contabil ' || vCONTAB1 || ' com centro de custo obrigatorio.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT006 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT006', 1, 'Conta Contabil ' || vCONTAB1 || ' n?o aceita o centro de custo ' || vNOCCUSTO1 || '.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT007 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT007', 1, 'Conta de estoque inexistente');
    END;
  WHEN SGECONT008 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT008', 1, 'Conta Contabil ' || vCONTAB2 || ' com centro de custo obrigatorio.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT009 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT009', 1, 'Conta Contabil ' || vCONTAB2 || ' n?o aceita o centro de custo ' || vNOCCUSTO2 || '.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT010 THEN
    BEGIN
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT010', 1, vMENSAGEMERRO);
    END;
  WHEN SGECONT011 THEN
    BEGIN
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT011', 0, 'Gerac?o do custo e contabilizac?o concluidos.');
    END;
  WHEN SGECONT015 THEN
    BEGIN
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT015', 1, vMENSAGEMERRO);
    END;
END;
/

CREATE OR REPLACE PROCEDURE DESFAZ_MOVIMENTO_CONTABIL
(
  pEMPRESA IN CHAR,
  pESTOQUE IN CHAR,
  pDATA    IN DATE
)
AS
  vDATA                     DATE;
  vLANCCTB                  VARCHAR2(6);
  vEXISTE_PARAM_ULTIMA_DATA BOOLEAN;
  vULTCONTAB                MOVIMENTO_MOV.MOV_DTCONTABILIZADO%TYPE;
  vPERIODOBLOQUEADO         BOOLEAN;
  vMENSAGEMERRO             VARCHAR2(500);
  SGECONT015     EXCEPTION;
  ---
  CURSOR ULTIMA_CONTABILIZACAO_MOV IS
    SELECT MAX(MOV_DTCONTABILIZADO)
      FROM MOVIMENTO_MOV
     WHERE MOV_CDEMPRESA        = pEMPRESA
       AND MOV_TPESTOQUE        = pESTOQUE
       AND MOV_DTCONTABILIZADO IS NOT NULL
       AND MOV_DATA            <= pDATA;
  ---
  CURSOR DOCS IS
    SELECT DISTINCT LCT_DATA, LCT_LANCCTB
      FROM LANCCTB_LCT
     WHERE LCT_CDEMPRESA = pEMPRESA
       AND LCT_LOTE      = 'SGE_CC'
       AND LCT_DATA     >= pDATA
       AND (LCT_LANCCTB = pESTOQUE OR LCT_LANCCTB LIKE pESTOQUE || '____');
  FUNCTION EXISTE_PARAM_ULTIMA_DATA RETURN BOOLEAN AS
    VCOUNT NUMBER;
    CURSOR PARAM_ULTIMA_DATA IS
      SELECT COUNT(1)
        FROM PARAMS_PAR
       WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE;
  BEGIN
    OPEN PARAM_ULTIMA_DATA;
    FETCH PARAM_ULTIMA_DATA INTO VCOUNT;
    CLOSE PARAM_ULTIMA_DATA;
    RETURN(VCOUNT > 0);
  END;
BEGIN
  vPERIODOBLOQUEADO := GET_PERIODOCONTABILBLOQUEADO(pEMPRESA, pDATA);
  IF vPERIODOBLOQUEADO THEN
      vMENSAGEMERRO := 'Lancamentos em periodo contabil bloqueado. Data: ' || pDATA;
      RAISE SGECONT015;
  END IF;
  UPDATE MOVIMENTO_MOV
     SET MOV_DTCONTABILIZADO = NULL
   WHERE MOV_TPESTOQUE        = pESTOQUE
     AND MOV_CDEMPRESA        = pEMPRESA
     AND MOV_DTCONTABILIZADO >= pDATA;
  ---
  OPEN DOCS;
  FETCH DOCS INTO vDATA, vLANCCTB;
  WHILE DOCS%FOUND LOOP
    EXCLANCCTB_LCT(pEMPRESA, 'SGE_CC', vDATA, vLANCCTB);
    FETCH DOCS INTO vDATA, vLANCCTB;
  END LOOP;
  CLOSE DOCS;
  ----------------------------------------------------------------------
  --- SO PARA DESFAZER O DOCUMENTO DA VERSAO ANTERIOR ------------------
  EXCLANCCTB_LCT(pEMPRESA, 'CCE' || pESTOQUE, LAST_DAY(pDATA), 'CCE' || pESTOQUE); ---
  ----------------------------------------------------------------------
  ---
  OPEN ULTIMA_CONTABILIZACAO_MOV;
  FETCH ULTIMA_CONTABILIZACAO_MOV INTO vULTCONTAB;
  CLOSE ULTIMA_CONTABILIZACAO_MOV;
  vEXISTE_PARAM_ULTIMA_DATA := EXISTE_PARAM_ULTIMA_DATA;
  IF NOT vEXISTE_PARAM_ULTIMA_DATA THEN
    INSERT INTO PARAMS_PAR
      (PAR_CDPARAM,
       PAR_VLPARAM,
       PAR_CADASTRADO,
       PAR_DTCADASTRADO,
       PAR_HOMOLOGADO,
       PAR_DTHOMOLOGADO,
       PAR_CDEMP,
       PAR_CDFILIAL,
       PAR_CODOBS,
       PAR_SEPARADOROBS)
    VALUES
      ('SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE,
       TO_CHAR(vULTCONTAB, 'DD/MM/YYYY'),
       USER,
       SYSDATE,
       null,
       null,
       null,
       null,
       null,
       null);
  ELSE
    UPDATE PARAMS_PAR
       SET PAR_VLPARAM = TO_CHAR(vULTCONTAB, 'DD/MM/YYYY')
     WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE;
  END IF;
EXCEPTION
  WHEN SGECONT015 THEN
    BEGIN
      RAISE_APPLICATION_ERROR(-20000, vMENSAGEMERRO);
      --INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT015', 1, vMENSAGEMERRO);
    END;
END;
/

CREATE OR REPLACE FUNCTION GET_PROCCONTABFATBLOQUEADO(
  pEMPRESA IN CHAR,
  pFILIAL  IN CHAR)
RETURN BOOLEAN IS
  VCOUNT NUMBER;
  VCHAVE VARCHAR2(50);
  CURSOR CS_PROCESSOBLOQUEADO IS
    SELECT COUNT(1)
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = VCHAVE;
BEGIN
  VCHAVE := 'BLQCONTABPERFATURAMENTO' || pEMPRESA || pFILIAL;
  OPEN CS_PROCESSOBLOQUEADO;
  FETCH CS_PROCESSOBLOQUEADO INTO VCOUNT;
  CLOSE CS_PROCESSOBLOQUEADO;
  RETURN(VCOUNT > 0);
END;
/

CREATE OR REPLACE FUNCTION GET_PROCCONTABESTBLOQUEADO(
  pEMPRESA IN CHAR,
  pESTOQUE IN CHAR)
RETURN BOOLEAN IS
  VCOUNT NUMBER;
  VCHAVE VARCHAR2(50);
  CURSOR CS_PROCESSOBLOQUEADO IS
    SELECT COUNT(1)
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = VCHAVE;
BEGIN
  VCHAVE := 'BLQCONTABPERESTOQUE' || pEMPRESA || pESTOQUE;
  OPEN CS_PROCESSOBLOQUEADO;
  FETCH CS_PROCESSOBLOQUEADO INTO VCOUNT;
  CLOSE CS_PROCESSOBLOQUEADO;
  RETURN(VCOUNT > 0);
END;
/

CREATE OR REPLACE FUNCTION GET_PERIODOCONTABILBLOQUEADO(
  pEMPRESA IN CHAR,
  pDATA    IN DATE)
RETURN BOOLEAN IS
  VCOUNT NUMBER;
  CURSOR CS_PERIODOLIBERADO IS
    SELECT COUNT(1)
      FROM LIBERACAO_LIB
     WHERE LIB_CDEMPRESA = pEMPRESA
       AND TO_DATE(LIB_DATA, 'DD/MM/RR') = TO_DATE(pDATA, 'DD/MM/RR')
       AND LIB_CDSISTEMA = 'SCB';
  CURSOR CS_PERIODOLIBERADOPORPERFIL IS
    SELECT COUNT(1)
      FROM LIBPERGRUPO_LPG
     WHERE LPG_EMPRESA = pEMPRESA
       AND EXISTS (SELECT NULL
                     FROM MXS_PERFILUSUARIO_MXPU
                    WHERE MXPU_USUARIO      = GET_USER_MXM
                      AND MXPU_PERFILACESSO = LPG_PERFILACESSO )
       AND TO_DATE(LPG_DATA, 'DD/MM/RR') = TO_DATE(pDATA,'DD/MM/RR')
       AND LPG_CDSISTEMA = 'SCB'
       AND LPG_GRPTRB    = -1;
BEGIN
  OPEN CS_PERIODOLIBERADO;
  FETCH CS_PERIODOLIBERADO INTO VCOUNT;
  CLOSE CS_PERIODOLIBERADO;
  IF (VCOUNT = 0) THEN
    OPEN CS_PERIODOLIBERADOPORPERFIL;
    FETCH CS_PERIODOLIBERADOPORPERFIL INTO VCOUNT;
    CLOSE CS_PERIODOLIBERADOPORPERFIL;
    RETURN(VCOUNT = 0);
  ELSE
    RETURN(VCOUNT = 0);
  END IF;
END;
/

CREATE OR REPLACE PROCEDURE GERA_MOVIMENTO_CONTABIL
(
  pEMPRESA      IN CHAR,
  pESTOQUE      IN CHAR,
  pDATA         IN DATE,
  PINDDOCUMENTO IN CHAR,
  pINDGRPPRD    IN CHAR,
  pAGRUPA       IN CHAR DEFAULT NULL
) AS
  ---
  vULTCONTAB    DATE;
  vTIPO         CHAR(1);
  vDOCUMENTO    MOVIMENTO_MOV.MOV_DOCUMENTO%TYPE;
  --vOBSMOV       MOVIMENTO_MOV.MOV_OBS%TYPE;
  vULTDOCUMENTO MOVIMENTO_MOV.MOV_DOCUMENTO%TYPE;
  vSEQLANCCTB   NUMBER(6);
  vLANCCTB      VARCHAR2(6);
  vSEQUENCIA    NUMBER(6);
  vCONTAB1      LANCCTB_LCT.LCT_NOCONTAB%TYPE;
  vCONTAB2      LANCCTB_LCT.LCT_NOCONTAB%TYPE;
  vNOCCUSTO1    LANCCTB_LCT.LCT_NOCCUSTO%TYPE;
  vNOCCUSTO2    LANCCTB_LCT.LCT_NOCCUSTO%TYPE;
  vDC           LANCCTB_LCT.LCT_DC%TYPE;
  vHISTORICO    LANCCTB_LCT.LCT_HISTORICO%TYPE;
  vVALORCTB     LANCCTB_LCT.LCT_VALOR%TYPE;
  vVALORCTBM    LANCCTB_LCT.LCT_VALORM%TYPE;
  vSEGMOEDA     LANCCTB_LCT.LCT_TPLANC%TYPE;
  vCODPLANO     LANCCTB_LCT.LCT_PLCONTAB%TYPE;
  vCONTA        LANCCTB_LCT.LCT_NOCONTAB%TYPE;
  vCCUSTO       CHAR(1);
  --Thiago
  vSEQANT NUMBER(6);
  ---
  vERROR                     BOOLEAN;
  vERRORMSG                  BOOLEAN;
  vEXISTE_PARAM_ULTIMA_DATA  BOOLEAN;
  vALMOX                     MOVIMENTO_MOV.MOV_ALMOXARIFADO%TYPE;
  vITEM                      MOVIMENTO_MOV.MOV_ITEM%TYPE;
  vSALDOQTD                  MOVIMENTO_MOV.MOV_QTD%TYPE;
  vSALDOVALOR                MOVIMENTO_MOV.MOV_VALOR%TYPE;
  vSALDOVALORM               MOVIMENTO_MOV.MOV_VALORM%TYPE;
  vMENSAGEMERRO              VARCHAR2(500);
  VCDPROJETO                 MOVIMENTO_MOV.MOV_CDPROJETO%TYPE;
  VBCustoNormalTransEmpresas PARAMS_PAR.PAR_VLPARAM%TYPE;
  vPERIODOBLOQUEADO          BOOLEAN;
  ---
  vCONTABCOMP NUMBER(1);
  ---
  SGECONT001 EXCEPTION;
  SGECONT002 EXCEPTION;
  SGECONT003 EXCEPTION;
  SGECONT004 EXCEPTION;
  SGECONT005 EXCEPTION;
  SGECONT006 EXCEPTION;
  SGECONT007 EXCEPTION;
  SGECONT008 EXCEPTION;
  SGECONT009 EXCEPTION;
  SGECONT010 EXCEPTION;
  SGECONT011 EXCEPTION;
  SGECONT015 EXCEPTION;
  CURSOR MOV IS
    SELECT RTRIM(TIPO),
           RTRIM(MOV_TIPO),
           RTRIM(CP),
           RTRIM(UP),
           RTRIM(CR),
           RTRIM(UR),
           RTRIM(HP),
           SUM(MOV_VALOR),
           SUM(MOV_VALORM),
           MOV_CDPROJETO
      FROM (SELECT DECODE(PINDDOCUMENTO,
                          'S',
                          A.MOV_DOCUMENTO,
                          NULL) AS TIPO,
                   A.MOV_TIPO,
                   Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                            A.MOV_TPESTOQUE,
                                            A.MOV_ITEM,
                                            A.MOV_OPERACAO,
                                            A.MOV_DOCUMENTO,
                                            A.MOV_OBS,
                                            A.MOV_DESTINACAO,
                                            'CP',
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            A.MOV_SQNOTA) AS CP,
                   --Se for Conta Patrimonial uso Centro de Custo do Parametro. Se for Resultado Posso Usar ccusto do Estoque
                   NVL(Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                                A.MOV_TPESTOQUE,
                                                A.MOV_ITEM,
                                                A.MOV_OPERACAO,
                                                A.MOV_DOCUMENTO,
                                                A.MOV_OBS,
                                                A.MOV_DESTINACAO,
                                                'UP',
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                A.MOV_SQNOTA),
                       A.MOV_NOCCUSTO) AS UP,
                   Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                            A.MOV_TPESTOQUE,
                                            A.MOV_ITEM,
                                            A.MOV_OPERACAO,
                                            A.MOV_DOCUMENTO,
                                            A.MOV_OBS,
                                            A.MOV_DESTINACAO,
                                            'CR',
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            A.MOV_SQNOTA) AS CR,
           NVL(NVL(A.MOV_NOCCUSTO, Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                                A.MOV_TPESTOQUE,
                                                A.MOV_ITEM,
                                                A.MOV_OPERACAO,
                                                A.MOV_DOCUMENTO,
                                                A.MOV_OBS,
                                                A.MOV_DESTINACAO,
                                                'UR',
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                            A.MOV_SQNOTA)),
                   B.MOV_NOCCUSTO) AS UR,
                   Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                            A.MOV_TPESTOQUE,
                                            A.MOV_ITEM,
                                            A.MOV_OPERACAO,
                                            A.MOV_DOCUMENTO,
                                            A.MOV_OBS,
                                            A.MOV_DESTINACAO,
                                            'HP',
                                            PINDDOCUMENTO,
                                            'S',
                                            pINDGRPPRD,
                                            pAGRUPA,
                                            A.MOV_SQNOTA) AS HP,
                   A.MOV_VALOR,
                   A.MOV_VALORM,
                   A.MOV_CDPROJETO
              FROM MOVIMENTO_MOV A,
                   MOVIMENTO_MOV B,
                   TPOPER_TPO,
                   NOTA_NT
             WHERE A.MOV_SQNOTARELTRANSF = B.MOV_SQNOTA(+)
               AND A.MOV_SEQUENCIA = B.MOV_SEQUENCIA(+)
               AND A.MOV_SQNOTA = NT_SQNOTA
               AND A.MOV_CDEMPRESA = pEMPRESA
               AND A.MOV_TPESTOQUE = pESTOQUE
               AND TPO_CODIGO = A.MOV_OPERACAO
               AND TPO_GECONT = 'S'
               AND ((TPO_DEVOLUCAO <> 'N' OR TPO_NOTAFISCAL <> 'S' OR
                   TPO_TIPO <> 'E') OR
                   (TPO_TIPO = 'E' AND TPO_ENTRADATRANSF = 'S' AND
                   NVL(VBCustoNormalTransEmpresas,
                         'N') = 'N') OR (NT_TPNOTA = 13))
               AND A.MOV_DTCONTABILIZADO IS NULL
               AND DECODE(A.MOV_TIPO,
                          'S',
                          DECODE(TPO_NOTAFISCAL,
                                 'S',
                                 DECODE(TPO_DEVOLUCAO,
                                        'S',
                                        'N',
                                        'S'),
                                 'S'),
                          'S') = 'S'
               AND A.MOV_DATA <= pDATA)
     GROUP BY TIPO,
              MOV_TIPO,
              CP,
              UP,
              CR,
              UR,
              HP,
              MOV_CDPROJETO;
  CURSOR CCUSTO IS
    SELECT PLC_CCUSTO
      FROM PLANOCTA_PLC
     WHERE PLC_CODPLANO = VCODPLANO
       AND PLC_NOCONTAB = VCONTA;
  CURSOR CUSTONORMALTRANSEMPRESAS IS
    SELECT PAR_VLPARAM
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = 'wSGE_CustoNormalTransEmpresas';
  FUNCTION EXISTE_PARAM_ULTIMA_DATA
  RETURN BOOLEAN
  AS
    VCOUNT NUMBER;
    CURSOR PARAM_ULTIMA_DATA IS
      SELECT COUNT(1)
        FROM PARAMS_PAR
       WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE;
  BEGIN
    OPEN PARAM_ULTIMA_DATA;
    FETCH PARAM_ULTIMA_DATA INTO VCOUNT;
    CLOSE PARAM_ULTIMA_DATA;
    RETURN(VCOUNT > 0);
  END;
  FUNCTION EXISTE_MENSAGEM_DE_ERRO
  RETURN BOOLEAN
  AS
    VCOUNT NUMBER;
    CURSOR ERROR_COUNT IS
      SELECT COUNT(1)
        FROM ERROPROCESSO_EPC;
  BEGIN
    OPEN ERROR_COUNT;
    FETCH ERROR_COUNT INTO VCOUNT;
    CLOSE ERROR_COUNT;
    RETURN(VCOUNT > 0);
  END;
BEGIN
  vPERIODOBLOQUEADO := GET_PERIODOCONTABILBLOQUEADO(pEMPRESA, pDATA);
  IF vPERIODOBLOQUEADO THEN
    vMENSAGEMERRO := 'Lancamentos em periodo contabil bloqueado. Data: ' || pDATA;
    RAISE SGECONT015;
  END IF;
  ---
  SELECT MIN(MOV_DTCONTABILIZADO)
    INTO vULTCONTAB
    FROM MOVIMENTO_MOV
   WHERE MOV_CDEMPRESA        = pEMPRESA
     AND MOV_TPESTOQUE        = pESTOQUE
     AND MOV_DTCONTABILIZADO IS NOT NULL
     AND MOV_DATA            <= pDATA;
  IF vULTCONTAB >= pDATA THEN
    -- Erro para periodo ja contabilizado -- A descricao consta na tabela de erros para ocodigo abaixo
    RAISE SGECONT001;
  END IF;
  ---
  OPEN CUSTONORMALTRANSEMPRESAS;
  FETCH CUSTONORMALTRANSEMPRESAS INTO VBCustoNormalTransEmpresas;
  CLOSE CUSTONORMALTRANSEMPRESAS;
  OPEN MOV;
  FETCH MOV INTO vDOCUMENTO, vTIPO, vCONTAB1, vNOCCUSTO1, vCONTAB2, vNOCCUSTO2, vHISTORICO, vVALORCTB, vVALORCTBM, VCDPROJETO;
  IF NOT MOV%FOUND THEN
    -- N?o ha movimento a contabilizar -- A descricao consta na tabela de erros para ocodigo abaixo
    RAISE SGECONT002;
  END IF;
  -- VERIFICA SE POSSUI ERRO
  vERROR := PKG_CALCULOCUSTOESTOQUE.EXISTS_ERROR_SALDO(pEMPRESA,
                                                       pESTOQUE,
                                                       NULL,
                                                       NULL);
  -- VERIFICA SE FORMAM INCLUIDAS MENSAGENS DE ERRO
  vERRORMSG := EXISTE_MENSAGEM_DE_ERRO;
  -- SE OUVER ERRO NAO FAZ A CONTABILIZACAO
  IF ((NOT vERROR) AND (NOT vERRORMSG)) THEN
    COMMIT;
    ---
    SELECT EST_SEGMOEDA
      INTO vSEGMOEDA
      FROM ESTOQUES_EST
     WHERE EST_CODIGO = pESTOQUE;
    ---
    vSEQLANCCTB   := 0;
    vULTDOCUMENTO := NULL;
    vLANCCTB      := pESTOQUE;
    vSEQUENCIA    := 0;
    WHILE MOV%FOUND LOOP
      vSEQANT := 0;
      ---
      IF RTRIM(vCONTAB1) IS NULL THEN
        RAISE SGECONT003;
      END IF;
      IF RTRIM(vCONTAB2) IS NULL THEN
        RAISE SGECONT004;
      END IF;
      ---
      IF vNOCCUSTO1 IS NULL THEN
        vNOCCUSTO1 := '               ';
      END IF;
      IF vNOCCUSTO2 IS NULL THEN
        vNOCCUSTO2 := '               ';
      END IF;
      ---
      IF vTIPO = 'S' THEN
        vDC := 'C';
      ELSE
        vDC := 'D';
      END IF;
      ---
      IF vVALORCTB <> 0 OR vVALORCTBM <> 0 OR RTRIM(vCONTAB1) <> RTRIM(vCONTAB2) THEN
        IF (pINDDOCUMENTO = 'S') AND (vULTDOCUMENTO IS NULL OR vULTDOCUMENTO <> vDOCUMENTO) THEN
          vULTDOCUMENTO := vDOCUMENTO;
          vSEQLANCCTB   := vSEQLANCCTB + 1;
          vSEQUENCIA    := 0;
          vLANCCTB      := pESTOQUE || Padr(vSEQLANCCTB, 4, '0');
        END IF;
        ---
        SELECT EMP_CODPLCONTA
          INTO vCODPLANO
          FROM EMP
         WHERE EMP_CODIGO = pEMPRESA;
        ---
        vCONTA := vCONTAB1;
        OPEN CCUSTO;
        FETCH CCUSTO INTO vCCUSTO;
        CLOSE CCUSTO;
        IF vCCUSTO = 'N' THEN
          vNOCCUSTO1 := '               ';
        END IF;
        IF vCCUSTO = 'O' AND TRIM(vNOCCUSTO1) = '' THEN
          RAISE SGECONT005;
        END IF;
        IF vCCUSTO = 'E' THEN
          BEGIN
            SELECT RCC_NOCCUSTO
              INTO vNOCCUSTO1
              FROM RELCTACC_RCC
             WHERE RCC_CDEMPRESA = pEMPRESA
               AND RCC_NOCONTAB  = vCONTAB1
               AND RCC_NOCCUSTO  = vNOCCUSTO1;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              RAISE SGECONT006;
          END;
        END IF;
        ---
        vSEQUENCIA := vSEQUENCIA + 1;
        ---
        SELECT DECODE(COUNT(PLC_NOCONTAB), 0, 0, 1)
          INTO vCONTABCOMP
          FROM PLANOCTA_PLC
         WHERE PLC_NOCONTAB = vCONTAB1
           AND PLC_SA       = 'A';
        IF vCONTABCOMP = 0 THEN
          -- Conta de estoque inexistente -- A descricao consta na tabela de erros para ocodigo abaixo
          RAISE SGECONT007;
        END IF;
        ---
        INSLANCCTB_LCT(pEMPRESA,
                       'SGE_CC',
                       pDATA,
                       vLANCCTB,
                       vSEQUENCIA,
                       vCONTAB1,
                       vNOCCUSTO1,
                       vHISTORICO,
                       vDC,
                       vVALORCTB,
                       vVALORCTBM,
                       '',
                       vSEGMOEDA,
                       null,
                       null,
                       VCDPROJETO);
        ---
        IF vTIPO = 'S' THEN
          vDC := 'D';
        ELSE
          vDC := 'C';
        END IF;
        ---
        vCONTA := vCONTAB2;
        OPEN CCUSTO;
        FETCH CCUSTO INTO vCCUSTO;
        CLOSE CCUSTO;
        IF vCCUSTO = 'N' THEN
          vNOCCUSTO2 := '               ';
        END IF;
        IF vCCUSTO = 'O' AND vNOCCUSTO2 = '               ' THEN
          RAISE SGECONT008;
        END IF;
        IF vCCUSTO = 'E' THEN
          BEGIN
            SELECT RCC_NOCCUSTO
              INTO vNOCCUSTO2
              FROM RELCTACC_RCC
             WHERE RCC_CDEMPRESA = pEMPRESA
               AND RCC_NOCONTAB  = vCONTAB2
               AND RCC_NOCCUSTO  = vNOCCUSTO2;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              RAISE SGECONT009;
          END;
        END IF;
        --
        IF pAGRUPA = 'S' THEN
          BEGIN
            SELECT MAX(LCT_SEQ)
              INTO vSEQANT
              FROM LANCCTB_LCT
             WHERE LCT_CDEMPRESA = pEMPRESA
               AND LCT_DATA      = pDATA
               AND LCT_LOTE      = 'SGE_CC'
               AND LCT_LANCCTB   = vLANCCTB
               AND LCT_NOCONTAB  = vCONTAB2
               AND LCT_DC        = vDC
               AND LCT_NOCCUSTO  = vNOCCUSTO2;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              vSEQANT := -1;
          END;
          IF vSEQANT IS NULL THEN
            vSEQANT := -1;
          END IF;
        END IF;
        IF vSEQANT <= 0 THEN
          vSEQUENCIA := vSEQUENCIA + 1;
          INSLANCCTB_LCT(pEMPRESA,
                         'SGE_CC',
                         pDATA,
                         vLANCCTB,
                         vSEQUENCIA,
                         vCONTAB2,
                         vNOCCUSTO2,
                         vHISTORICO,
                         vDC,
                         vVALORCTB,
                         vVALORCTBM,
                         '',
                         vSEGMOEDA,
                         null,
                         null,
                         VCDPROJETO);
        ELSE
          UPDATE LANCCTB_LCT
             SET LCT_VALOR  = LCT_VALOR + vVALORCTB,
                 LCT_VALORM = LCT_VALORM + vVALORCTBM
           WHERE LCT_CDEMPRESA = pEMPRESA
             AND LCT_DATA      = pDATA
             AND LCT_LOTE      = 'SGE_CC'
             AND LCT_LANCCTB   = vLANCCTB
             AND LCT_SEQ       = vSEQANT;
        END IF;
      END IF;
      ---
      FETCH MOV INTO vDOCUMENTO,
                     vTIPO,
                     vCONTAB1,
                     vNOCCUSTO1,
                     vCONTAB2,
                     vNOCCUSTO2,
                     vHISTORICO,
                     vVALORCTB,
                     vVALORCTBM,
                     VCDPROJETO;
      ---
    END LOOP;
    ---
    CLOSE MOV;
    ---
    /*
       Ira verificar a existencia de erros gerados pelo processo e que foram
       armazenados na tabela ERROPROCESSO_EPC.
       Caso existam erros, o processo de contabilizacao n?o sera comitado, e sera feito um rollback do processo
    */
    vERRORMSG := EXISTE_MENSAGEM_DE_ERRO;
    IF NOT vERRORMSG THEN
      BEGIN
        COMMIT;
        ---
        UPDATE MOVIMENTO_MOV
           SET MOV_DTCONTABILIZADO = pDATA
         WHERE MOV_CDEMPRESA        = pEMPRESA
           AND MOV_TPESTOQUE        = pESTOQUE
           AND MOV_DATA            <= pDATA
           AND MOV_DTCONTABILIZADO IS NULL;
        vEXISTE_PARAM_ULTIMA_DATA := EXISTE_PARAM_ULTIMA_DATA;
        IF NOT vEXISTE_PARAM_ULTIMA_DATA THEN
          INSERT INTO PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
          VALUES ('SGE_DTCONTABILIZAESTOQUE' ||pEMPRESA || pESTOQUE, TO_CHAR(pDATA,'DD/MM/YYYY'), USER, SYSDATE, null, null, null, null, null, null);
        ELSE
          UPDATE PARAMS_PAR
             SET PAR_VLPARAM = TO_CHAR(pDATA,'DD/MM/YYYY')
           WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE'||pEMPRESA || pESTOQUE;
        END IF;
        RAISE SGECONT011;
      END;
    ELSE
      BEGIN
        ROLLBACK;
      END;
    END IF;
    ---
    -- FIM VARIAVEL ERRO
  ELSE
    -- PEGAR O PRIMEIRO ERRO GERADO E JOGAR NA TELA, ALTERAR POSTARIORMENTE A TELA PARA BUSCAR TODOS OS ERROS GERADOS NA TABELA DE ERRO
    BEGIN
      SELECT ERROCALCULOCUSTO_ECC.ECC_ALMOXARIFADO,
             ERROCALCULOCUSTO_ECC.ECC_ITEM,
             ERROCALCULOCUSTO_ECC.ECC_SALDO,
             ERROCALCULOCUSTO_ECC.ECC_SALDOVALOR,
             ERROCALCULOCUSTO_ECC.ECC_SALDOVALORM
        INTO vALMOX,
             vITEM,
             vSALDOQTD,
             vSALDOVALOR,
             vSALDOVALORM
        FROM ERROCALCULOCUSTO_ECC
       WHERE ECC_CDEMPRESA = pEMPRESA
         AND ECC_TPESTOQUE = pESTOQUE
         AND ROWNUM        = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        vALMOX       := NULL;
        vITEM        := NULL;
        vSALDOQTD    := NULL;
        vSALDOVALOR  := NULL;
        vSALDOVALORM := NULL;
    END;
    ---
    IF (vSALDOQTD IS NOT NULL) OR (vSALDOVALOR IS NOT NULL) OR (vSALDOVALORM IS NOT NULL) THEN
      vMENSAGEMERRO := 'Item: ' || vITEM;
      IF vALMOX IS NOT NULL THEN
        vMENSAGEMERRO := vMENSAGEMERRO || ', Almoxarifado: ' || vALMOX;
      END IF;
      vMENSAGEMERRO := vMENSAGEMERRO || ' saldo de quantidade: ' || vSALDOQTD;
      vMENSAGEMERRO := vMENSAGEMERRO || ' saldo de valor:      ' || vSALDOVALOR;
      IF vSALDOVALORM <> 0 THEN
        vMENSAGEMERRO := vMENSAGEMERRO || ' saldo de valor na segunda moeda:      ' || vSALDOVALORM;
      END IF;
      RAISE SGECONT010;
    END IF;
  END IF;
EXCEPTION
  WHEN SGECONT001 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT001', 1, 'Periodo ja contabilizado');
    END;
  WHEN SGECONT002 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT002', 1, 'N?o ha movimento a contabilizar');
    END;
  WHEN SGECONT003 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT003', 1, 'Conta de estoque n?o parametrizada para o seguinte lancamento: ' || RTRIM(vHISTORICO));
    END;
  WHEN SGECONT004 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT004', 1, 'Conta de destinac?o ou contra-partida n?o parametrizada para o seguinte lancamento: ' || RTRIM(vHISTORICO));
    END;
  WHEN SGECONT005 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT005', 1, 'Conta Contabil ' || vCONTAB1 || ' com centro de custo obrigatorio.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT006 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT006', 1, 'Conta Contabil ' || vCONTAB1 || ' n?o aceita o centro de custo ' || vNOCCUSTO1 || '.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT007 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT007', 1, 'Conta de estoque inexistente');
    END;
  WHEN SGECONT008 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT008', 1, 'Conta Contabil ' || vCONTAB2 || ' com centro de custo obrigatorio.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT009 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT009', 1, 'Conta Contabil ' || vCONTAB2 || ' n?o aceita o centro de custo ' || vNOCCUSTO2 || '.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT010 THEN
    BEGIN
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT010', 1, vMENSAGEMERRO);
    END;
  WHEN SGECONT011 THEN
    BEGIN
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT011', 0, 'Gerac?o do custo e contabilizac?o concluidos.');
    END;
  WHEN SGECONT015 THEN
    BEGIN
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT015', 1, vMENSAGEMERRO);
    END;
END;
/

aLTER TABLE paramimpostos_pinp ADD PINP_CDICMSSTDEVCONT VARCHAR2(15) NULL
/

ALTER TABLE paramimpostos_pinp ADD PINP_CDICMSSTDEVCONTCP VARCHAR2(15) NULL
/

ALTER TABLE paramimpostos_pinp ADD PINP_CDICMSSTDEVCCUS VARCHAR2(15) NULL
/

ALTER TABLE paramimpostos_pinp ADD PINP_CDICMSSTDEVCCUSCP VARCHAR2(15) NULL
/

COMMENT ON COLUMN paramimpostos_pinp.PINP_CDICMSSTDEVCONT IS 'Codigo da conta contabil de debito para o ICMS ST a devolver'
/

COMMENT ON COLUMN paramimpostos_pinp.PINP_CDICMSSTDEVCONTCP IS 'Codigo da conta contabil de credito para o ICMS ST a devolver'
/

COMMENT ON COLUMN paramimpostos_pinp.PINP_CDICMSSTDEVCCUS IS 'Codigo do centro de custo contabil de debito para o ICMS ST a devolver'
/

COMMENT ON COLUMN paramimpostos_pinp.PINP_CDICMSSTDEVCCUSCP IS 'Codigo do centro de custo contabil de credito para o ICMS ST a devolver'
/

ALTER TABLE paramimpostos_pinp ADD PINP_CDIPIDEVCONT VARCHAR2(15) NULL
/

ALTER TABLE paramimpostos_pinp ADD PINP_CDIPIDEVCONTCP VARCHAR2(15) NULL
/

ALTER TABLE paramimpostos_pinp ADD PINP_CDIPIDEVCCUS VARCHAR2(15) NULL
/

ALTER TABLE paramimpostos_pinp ADD PINP_CDIPIDEVCCUSCP VARCHAR2(15) NULL
/

COMMENT ON COLUMN paramimpostos_pinp.PINP_CDIPIDEVCONT IS 'Codigo da conta contabil de debito para o IPI a devolver'
/

COMMENT ON COLUMN paramimpostos_pinp.PINP_CDIPIDEVCONTCP IS 'Codigo da conta contabil de credito para o IPI a devolver'
/

COMMENT ON COLUMN paramimpostos_pinp.PINP_CDIPIDEVCCUS IS 'Codigo do centro de custo contabil de debito para o IPI a devolver'
/

COMMENT ON COLUMN paramimpostos_pinp.PINP_CDIPIDEVCCUSCP IS 'Codigo do centro de custo contabil de credito para o IPI a devolver'
/

CREATE OR REPLACE PROCEDURE INSPARAMIMPOSTOS_PINP
 (PPINP_EMPRESA         IN CHAR,
  PPINP_TPESTOQUE       IN CHAR,
  PPINP_TPOPER          IN CHAR,
  PPINP_TIPOPROD        IN CHAR,
  PPINP_GRTPPROD        IN CHAR,
  PPINP_PRODUTO         IN CHAR,
  PPINP_ICMSCONT        IN CHAR,
  PPINP_ICMSCONTCP      IN CHAR,
  PPINP_ICMSCCUS        IN CHAR,
  PPINP_ICMSCCUSCP      IN CHAR,
  PPINP_SUBSTRIBCONTCP  IN CHAR,
  PPINP_SUBSTRIBCONT    IN CHAR,
  PPINP_SUBSTRIBCCUS    IN CHAR,
  PPINP_SUBSTRIBCCUSCP  IN CHAR,
  PPINP_IPICONT         IN CHAR,
  PPINP_IPICONTCP       IN CHAR,
  PPINP_IPICCUS         IN CHAR,
  PPINP_IPICCUSCP       IN CHAR,
  PPINP_ISSCONT         IN CHAR,
  PPINP_ISSCONTCP       IN CHAR,
  PPINP_ISSCCUS         IN CHAR,
  PPINP_ISSCCUSCP       IN CHAR,
  PPINP_ISSRETCONT      IN CHAR,
  PPINP_ISSRETCONTCP    IN CHAR,
  PPINP_ISSRETCCUS      IN CHAR,
  PPINP_ISSRETCCUSCP    IN CHAR,
  PPINP_PISCONT         IN CHAR,
  PPINP_PISCONTCP       IN CHAR,
  PPINP_PISCCUS         IN CHAR,
  PPINP_PISCCUSCP       IN CHAR,
  PPINP_COFINSCONT      IN CHAR,
  PPINP_COFINSCONTCP    IN CHAR,
  PPINP_COFINSCCUS      IN CHAR,
  PPINP_COFINSCCUSCP    IN CHAR,
  PPINP_IMPIMPORCONT    IN CHAR,
  PPINP_IMPIMPORCONTCP  IN CHAR,
  PPINP_IMPIMPORCCUS    IN CHAR,
  PPINP_IMPIMPORCCUSCP  IN CHAR,
  PPINP_FTICONT         IN CHAR,
  PPINP_FTICONTCP       IN CHAR,
  PPINP_FTICCUS         IN CHAR,
  PPINP_FTICCUSCP       IN CHAR,
  PPINP_DIFERALIQCONT   IN CHAR DEFAULT NULL,
  PPINP_DIFERALIQCONTCP IN CHAR DEFAULT NULL,
  PPINP_DIFERALIQCCUS   IN CHAR DEFAULT NULL,
  PPINP_DIFERALIQCCUSCP IN CHAR DEFAULT NULL,
  PPINP_CDICMSPARTCONT  IN CHAR DEFAULT NULL,
  PPINP_CDICMSPARTCCUS  IN CHAR DEFAULT NULL,
  PPINP_CDICMSPARTCONTP IN CHAR DEFAULT NULL,
  PPINP_CDICMSPARTCCUSP IN CHAR DEFAULT NULL,
  PPINP_CDICMSSTDEVCONT    IN CHAR DEFAULT NULL,
  PPINP_CDICMSSTDEVCONTCP  IN CHAR DEFAULT NULL,
  PPINP_CDICMSSTDEVCCUS    IN CHAR DEFAULT NULL,
  PPINP_CDICMSSTDEVCCUSCP  IN CHAR DEFAULT NULL,
  PPINP_CDIPIDEVCONT       IN CHAR DEFAULT NULL,
  PPINP_CDIPIDEVCONTCP     IN CHAR DEFAULT NULL,
  PPINP_CDIPIDEVCCUS       IN CHAR DEFAULT NULL,
  PPINP_CDIPIDEVCCUSCP     IN CHAR DEFAULT NULL
)
AS BEGIN
  INSERT INTO PARAMIMPOSTOS_PINP
   (PINP_EMPRESA,
    PINP_TPESTOQUE,
    PINP_TPOPER,
    PINP_TIPOPROD,
    PINP_GRTPPROD,
    PINP_PRODUTO,
    PINP_ICMSCONT,
    PINP_ICMSCONTCP,
    PINP_ICMSCCUS,
    PINP_ICMSCCUSCP,
    PINP_SUBSTRIBCONTCP,
    PINP_SUBSTRIBCONT,
    PINP_SUBSTRIBCCUS,
    PINP_SUBSTRIBCCUSCP,
    PINP_IPICONT,
    PINP_IPICONTCP,
    PINP_IPICCUS,
    PINP_IPICCUSCP,
    PINP_ISSCONT,
    PINP_ISSCONTCP,
    PINP_ISSCCUS,
    PINP_ISSCCUSCP,
    PINP_ISSRETCONT,
    PINP_ISSRETCONTCP,
    PINP_ISSRETCCUS,
    PINP_ISSRETCCUSCP,
    PINP_PISCONT,
    PINP_PISCONTCP,
    PINP_PISCCUS,
    PINP_PISCCUSCP,
    PINP_COFINSCONT,
    PINP_COFINSCONTCP,
    PINP_COFINSCCUS,
    PINP_COFINSCCUSCP,
    PINP_IMPIMPORCONT,
    PINP_IMPIMPORCONTCP,
    PINP_IMPIMPORCCUS,
    PINP_IMPIMPORCCUSCP,
    PINP_FTICONT,
    PINP_FTICONTCP,
    PINP_FTICCUS,
    PINP_FTICCUSCP,
    PINP_DIFERALIQCONT,
    PINP_DIFERALIQCONTCP,
    PINP_DIFERALIQCCUS,
    PINP_DIFERALIQCCUSCP,
    PINP_CDICMSPARTCONT,
    PINP_CDICMSPARTCCUS,
    PINP_CDICMSPARTCONTP,
    PINP_CDICMSPARTCCUSP,
    PINP_CDICMSSTDEVCONT,
    PINP_CDICMSSTDEVCONTCP,
    PINP_CDICMSSTDEVCCUS,
    PINP_CDICMSSTDEVCCUSCP,
    PINP_CDIPIDEVCONT,
    PINP_CDIPIDEVCONTCP,
    PINP_CDIPIDEVCCUS,
    PINP_CDIPIDEVCCUSCP
)
  VALUES
   (PPINP_EMPRESA,
    PPINP_TPESTOQUE,
    PPINP_TPOPER,
    PPINP_TIPOPROD,
    PPINP_GRTPPROD,
    PPINP_PRODUTO,
    PPINP_ICMSCONT,
    PPINP_ICMSCONTCP,
    PPINP_ICMSCCUS,
    PPINP_ICMSCCUSCP,
    PPINP_SUBSTRIBCONTCP,
    PPINP_SUBSTRIBCONT,
    PPINP_SUBSTRIBCCUS,
    PPINP_SUBSTRIBCCUSCP,
    PPINP_IPICONT,
    PPINP_IPICONTCP,
    PPINP_IPICCUS,
    PPINP_IPICCUSCP,
    PPINP_ISSCONT,
    PPINP_ISSCONTCP,
    PPINP_ISSCCUS,
    PPINP_ISSCCUSCP,
    PPINP_ISSRETCONT,
    PPINP_ISSRETCONTCP,
    PPINP_ISSRETCCUS,
    PPINP_ISSRETCCUSCP,
    PPINP_PISCONT,
    PPINP_PISCONTCP,
    PPINP_PISCCUS,
    PPINP_PISCCUSCP,
    PPINP_COFINSCONT,
    PPINP_COFINSCONTCP,
    PPINP_COFINSCCUS,
    PPINP_COFINSCCUSCP,
    PPINP_IMPIMPORCONT,
    PPINP_IMPIMPORCONTCP,
    PPINP_IMPIMPORCCUS,
    PPINP_IMPIMPORCCUSCP,
    PPINP_FTICONT,
    PPINP_FTICONTCP,
    PPINP_FTICCUS,
    PPINP_FTICCUSCP,
    PPINP_DIFERALIQCONT,
    PPINP_DIFERALIQCONTCP,
    PPINP_DIFERALIQCCUS,
    PPINP_DIFERALIQCCUSCP,
    PPINP_CDICMSPARTCONT,
    PPINP_CDICMSPARTCCUS,
    PPINP_CDICMSPARTCONTP,
    PPINP_CDICMSPARTCCUSP,
    PPINP_CDICMSSTDEVCONT,
    PPINP_CDICMSSTDEVCONTCP,
    PPINP_CDICMSSTDEVCCUS,
    PPINP_CDICMSSTDEVCCUSCP,
    PPINP_CDIPIDEVCONT,
    PPINP_CDIPIDEVCONTCP,
    PPINP_CDIPIDEVCCUS,
    PPINP_CDIPIDEVCCUSCP);
END;
/

CREATE OR REPLACE PROCEDURE ALTPARAMIMPOSTOS_PINP
 (PPINP_EMPRESA          IN CHAR,
  PPINP_TPESTOQUE        IN CHAR,
  PPINP_TPOPER           IN CHAR,
  PPINP_TIPOPROD         IN CHAR,
  PPINP_GRTPPROD         IN CHAR,
  PPINP_PRODUTO          IN CHAR,
  PPINP_ICMSCONT         IN CHAR,
  PPINP_ICMSCONTCP       IN CHAR,
  PPINP_ICMSCCUS         IN CHAR,
  PPINP_ICMSCCUSCP       IN CHAR,
  PPINP_SUBSTRIBCONTCP   IN CHAR,
  PPINP_SUBSTRIBCONT     IN CHAR,
  PPINP_SUBSTRIBCCUS     IN CHAR,
  PPINP_SUBSTRIBCCUSCP   IN CHAR,
  PPINP_IPICONT          IN CHAR,
  PPINP_IPICONTCP        IN CHAR,
  PPINP_IPICCUS          IN CHAR,
  PPINP_IPICCUSCP        IN CHAR,
  PPINP_ISSCONT          IN CHAR,
  PPINP_ISSCONTCP        IN CHAR,
  PPINP_ISSCCUS          IN CHAR,
  PPINP_ISSCCUSCP        IN CHAR,
  PPINP_ISSRETCONT       IN CHAR,
  PPINP_ISSRETCONTCP     IN CHAR,
  PPINP_ISSRETCCUS       IN CHAR,
  PPINP_ISSRETCCUSCP     IN CHAR,
  PPINP_PISCONT          IN CHAR,
  PPINP_PISCONTCP        IN CHAR,
  PPINP_PISCCUS          IN CHAR,
  PPINP_PISCCUSCP        IN CHAR,
  PPINP_COFINSCONT       IN CHAR,
  PPINP_COFINSCONTCP     IN CHAR,
  PPINP_COFINSCCUS       IN CHAR,
  PPINP_COFINSCCUSCP     IN CHAR,
  PPINP_IMPIMPORCONT       IN CHAR,
  PPINP_IMPIMPORCONTCP     IN CHAR,
  PPINP_IMPIMPORCCUS       IN CHAR,
  PPINP_IMPIMPORCCUSCP     IN CHAR,
  PPINP_FTICONT            IN CHAR,
  PPINP_FTICONTCP          IN CHAR,
  PPINP_FTICCUS            IN CHAR,
  PPINP_FTICCUSCP          IN CHAR,
  PPINP_CDICMSSTDEVCONT    IN CHAR,
  PPINP_CDICMSSTDEVCONTCP  IN CHAR,
  PPINP_CDICMSSTDEVCCUS    IN CHAR,
  PPINP_CDICMSSTDEVCCUSCP  IN CHAR,
  PPINP_CDIPIDEVCONT       IN CHAR,
  PPINP_CDIPIDEVCONTCP     IN CHAR,
  PPINP_CDIPIDEVCCUS       IN CHAR,
  PPINP_CDIPIDEVCCUSCP     IN CHAR)
AS BEGIN
  UPDATE
    PARAMIMPOSTOS_PINP
  SET
    PINP_ICMSCONT          = PPINP_ICMSCONT,
    PINP_ICMSCONTCP        = PPINP_ICMSCONTCP,
    PINP_ICMSCCUS          = PPINP_ICMSCCUS,
    PINP_ICMSCCUSCP        = PPINP_ICMSCCUSCP,
    PINP_SUBSTRIBCONT      = PPINP_SUBSTRIBCONT,
    PINP_SUBSTRIBCONTCP    = PPINP_SUBSTRIBCONTCP,
    PINP_SUBSTRIBCCUS      = PPINP_SUBSTRIBCCUS,
    PINP_SUBSTRIBCCUSCP    = PPINP_SUBSTRIBCCUSCP,
    PINP_IPICONT           = PPINP_IPICONT,
    PINP_IPICONTCP         = PPINP_IPICONTCP,
    PINP_IPICCUS           = PPINP_IPICCUS,
    PINP_IPICCUSCP         = PPINP_IPICCUSCP,
    PINP_ISSCONT           = PPINP_ISSCONT,
    PINP_ISSCONTCP         = PPINP_ISSCONTCP,
    PINP_ISSCCUS           = PPINP_ISSCCUS,
    PINP_ISSCCUSCP         = PPINP_ISSCCUSCP,
    PINP_ISSRETCONT        = PPINP_ISSRETCONT,
    PINP_ISSRETCONTCP      = PPINP_ISSRETCONTCP,
    PINP_ISSRETCCUS        = PPINP_ISSRETCCUS,
    PINP_ISSRETCCUSCP      = PPINP_ISSRETCCUSCP,
    PINP_PISCONTCP         = PPINP_PISCONTCP,
    PINP_PISCONT           = PPINP_PISCONT,
    PINP_PISCCUS           = PPINP_PISCCUS,
    PINP_PISCCUSCP         = PPINP_PISCCUSCP,
    PINP_COFINSCONT        = PPINP_COFINSCONT,
    PINP_COFINSCONTCP      = PPINP_COFINSCONTCP,
    PINP_COFINSCCUS        = PPINP_COFINSCCUS,
    PINP_COFINSCCUSCP      = PPINP_COFINSCCUSCP,
    PINP_IMPIMPORCONT      = PPINP_IMPIMPORCONT,
    PINP_IMPIMPORCONTCP    = PPINP_IMPIMPORCONTCP,
    PINP_IMPIMPORCCUS      = PPINP_IMPIMPORCCUS,
    PINP_IMPIMPORCCUSCP    = PPINP_IMPIMPORCCUSCP,
    PINP_FTICONTCP         = PPINP_FTICONTCP,
    PINP_FTICONT           = PPINP_FTICONT,
    PINP_FTICCUSCP         = PPINP_FTICCUSCP,
    PINP_FTICCUS           = PPINP_FTICCUS,
    PINP_CDICMSSTDEVCONT   = PINP_CDICMSSTDEVCONT,
    PINP_CDICMSSTDEVCONTCP = PINP_CDICMSSTDEVCONTCP,
    PINP_CDICMSSTDEVCCUS   = PINP_CDICMSSTDEVCCUS,
    PINP_CDICMSSTDEVCCUSCP = PINP_CDICMSSTDEVCCUSCP,
    PINP_CDIPIDEVCONT      = PINP_CDIPIDEVCONT,
    PINP_CDIPIDEVCONTCP    = PINP_CDIPIDEVCONTCP,
    PINP_CDIPIDEVCCUS      = PINP_CDIPIDEVCCUS,
    PINP_CDIPIDEVCCUSCP    = PINP_CDIPIDEVCCUSCP,
    PINP_EXP               = NULL
  WHERE
    PINP_EMPRESA        = PPINP_EMPRESA   AND
    PINP_TPESTOQUE      = PPINP_TPESTOQUE AND
    PINP_TPOPER         = PPINP_TPOPER    AND
    PINP_GRTPPROD       = PPINP_GRTPPROD  AND
    PINP_TIPOPROD       = PPINP_TIPOPROD  AND
    PINP_PRODUTO        = PPINP_PRODUTO;
END;
/

CREATE OR REPLACE PROCEDURE DESFAZ_MOVIMENTO_CONTABIL
(
  pEMPRESA IN CHAR,
  pESTOQUE IN CHAR,
  pDATA    IN DATE
)
AS
  vDATA                     DATE;
  vLANCCTB                  VARCHAR2(6);
  vEXISTE_PARAM_ULTIMA_DATA BOOLEAN;
  vULTCONTAB                MOVIMENTO_MOV.MOV_DTCONTABILIZADO%TYPE;
  vPERIODOBLOQUEADO         BOOLEAN;
  vMENSAGEMERRO             VARCHAR2(500);
  SGECONT015     EXCEPTION;
  ---
  CURSOR ULTIMA_CONTABILIZACAO_MOV IS
    SELECT MAX(MOV_DTCONTABILIZADO)
      FROM MOVIMENTO_MOV
     WHERE MOV_CDEMPRESA        = pEMPRESA
       AND MOV_TPESTOQUE        = pESTOQUE
       AND MOV_DTCONTABILIZADO IS NOT NULL
       AND MOV_DATA            <= pDATA;
  ---
  CURSOR DOCS IS
    SELECT DISTINCT LCT_DATA, LCT_LANCCTB
      FROM LANCCTB_LCT
     WHERE LCT_CDEMPRESA = pEMPRESA
       AND LCT_LOTE      = 'SGE_CC'
       AND LCT_DATA     >= pDATA
       AND (LCT_LANCCTB = pESTOQUE OR LCT_LANCCTB LIKE pESTOQUE || '____');
  FUNCTION EXISTE_PARAM_ULTIMA_DATA RETURN BOOLEAN AS
    VCOUNT NUMBER;
    CURSOR PARAM_ULTIMA_DATA IS
      SELECT COUNT(1)
        FROM PARAMS_PAR
       WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE;
  BEGIN
    OPEN PARAM_ULTIMA_DATA;
    FETCH PARAM_ULTIMA_DATA INTO VCOUNT;
    CLOSE PARAM_ULTIMA_DATA;
    RETURN(VCOUNT > 0);
  END;
BEGIN
  vPERIODOBLOQUEADO := GET_PERIODOCONTABILBLOQUEADO(pEMPRESA, pDATA);
  IF vPERIODOBLOQUEADO THEN
      vMENSAGEMERRO := 'Lancamentos em periodo contabil bloqueado. Data: ' || pDATA;
      RAISE SGECONT015;
  END IF;
  UPDATE MOVIMENTO_MOV
     SET MOV_DTCONTABILIZADO = NULL
   WHERE MOV_TPESTOQUE        = pESTOQUE
     AND MOV_CDEMPRESA        = pEMPRESA
     AND MOV_DTCONTABILIZADO >= pDATA;
  ---
  OPEN DOCS;
  FETCH DOCS INTO vDATA, vLANCCTB;
  WHILE DOCS%FOUND LOOP
    EXCLANCCTB_LCT(pEMPRESA, 'SGE_CC', vDATA, vLANCCTB);
    FETCH DOCS INTO vDATA, vLANCCTB;
  END LOOP;
  CLOSE DOCS;
  ----------------------------------------------------------------------
  --- SO PARA DESFAZER O DOCUMENTO DA VERSAO ANTERIOR ------------------
  EXCLANCCTB_LCT(pEMPRESA, 'CCE' || pESTOQUE, LAST_DAY(pDATA), 'CCE' || pESTOQUE); ---
  ----------------------------------------------------------------------
  ---
  OPEN ULTIMA_CONTABILIZACAO_MOV;
  FETCH ULTIMA_CONTABILIZACAO_MOV INTO vULTCONTAB;
  CLOSE ULTIMA_CONTABILIZACAO_MOV;
  vEXISTE_PARAM_ULTIMA_DATA := EXISTE_PARAM_ULTIMA_DATA;
  IF NOT vEXISTE_PARAM_ULTIMA_DATA THEN
    INSERT INTO PARAMS_PAR
      (PAR_CDPARAM,
       PAR_VLPARAM,
       PAR_CADASTRADO,
       PAR_DTCADASTRADO,
       PAR_HOMOLOGADO,
       PAR_DTHOMOLOGADO,
       PAR_CDEMP,
       PAR_CDFILIAL,
       PAR_CODOBS,
       PAR_SEPARADOROBS)
    VALUES
      ('SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE,
       TO_CHAR(vULTCONTAB, 'DD/MM/YYYY'),
       USER,
       SYSDATE,
       null,
       null,
       null,
       null,
       null,
       null);
  ELSE
    UPDATE PARAMS_PAR
       SET PAR_VLPARAM = TO_CHAR(vULTCONTAB, 'DD/MM/YYYY')
     WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE;
  END IF;
EXCEPTION
  WHEN SGECONT015 THEN
    BEGIN
      RAISE_APPLICATION_ERROR(-20000, vMENSAGEMERRO);
      --INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT015', 1, vMENSAGEMERRO);
    END;
END;
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (40514, 'Libera��o/bloqueio do processo de contabiliza��o', 'Libera��o/bloqueio do processo de contabiliza��o')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGE', 40514, 28, 4000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40514, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40514, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40514, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 278428
PROMPT ======================================================================