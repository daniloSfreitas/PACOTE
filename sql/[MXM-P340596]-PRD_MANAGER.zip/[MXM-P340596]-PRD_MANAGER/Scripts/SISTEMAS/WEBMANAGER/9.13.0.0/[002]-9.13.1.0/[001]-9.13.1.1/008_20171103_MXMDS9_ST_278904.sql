PROMPT ======================================================================
PROMPT == DEMANDA......: 278904
PROMPT == SISTEMA......: Tesouraria
PROMPT == RESPONSAVEL..: MICHAEL EXPEDITO AZEVEDO SOUTO
PROMPT == DATA.........: 31/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FORCE VIEW VW_DIASLIQUIDAFLUXOCAIXA
AS
   (SELECT FCF_SQPROCESSO, FCR_CDEMPRESA, FCF_DATA,
           GET_NEWDATADIASLIQUI (FCF_PGTORCTO,
                                 DECODE (FCF_PGTORCTO,
                                         'P', FCP_CDFOR,
                                         FCP_CDCLIENTE
                                        ),
                                 FCP_DOCUMENTO
                                ) AS DATADIASLIQUI
      FROM FLUXOCAIXAFIN_FCF, FLUXOCAIXAREG_FCR, FLUXOCAIXAPREV_FCP
     WHERE FCF_SQPROCESSO = FCR_SQPROCESSO AND FCP_SQPROCESSO = FCR_SQPROCESSO)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 278904
PROMPT ======================================================================