PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.3_002 gerados em 26/12/2017 
PROMPT ============================================================= 

@@001_20171226_MXMDS913_SF_284034.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.3_002');

COMMIT;
