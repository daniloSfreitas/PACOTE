PROMPT ======================================================================
PROMPT == DEMANDA......: 284203
PROMPT == SISTEMA......: Contratos de Compras
PROMPT == RESPONSAVEL..: LUANA MARIA DE SOUZA
PROMPT == DATA.........: 05/01/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPO = 'Vlr. Parcela Item',
       CDR_DSCAMPOTABELACABECALHO = 'Vlr. Parcela Item'
WHERE CDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'FFINCONCO_FFCC')
    AND CDR_DSCAMPOTABELA = 'FFINCONCO_FFCC.FFCC_VALOR'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 284203
PROMPT ======================================================================