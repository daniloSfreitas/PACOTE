PROMPT ======================================================================
PROMPT == DEMANDA......: 282004
PROMPT == SISTEMA......: Cobranca Escritural
PROMPT == RESPONSAVEL..: JOAO PAULO RODRIGUES JIMENEZ
PROMPT == DATA.........: 05/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION NNMERRILLLYNCH
 (cCdCli      IN CHAR,
  cNoTit      IN CHAR,
  cIdPort    IN CHAR,
  cCart       IN CHAR)
  RETURN VARCHAR
IS
BEGIN
  RETURN (cCdCli||'^1^'||cNoTit||'^2^'||cIdPort||'^3^'||cCart||'^4^');
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282004
PROMPT ======================================================================