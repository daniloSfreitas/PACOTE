PROMPT ======================================================================
PROMPT == DEMANDA......: 284218
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: THIAGO LUIZ SANTOS COUTINHO
PROMPT == DATA.........: 12/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES ('IFAT0014', 'Unidade do Produto com Prefixo de Situa��o Tribut�ria - 3 n�o relacionada com uma Unidade FCI.')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 284218
PROMPT ======================================================================