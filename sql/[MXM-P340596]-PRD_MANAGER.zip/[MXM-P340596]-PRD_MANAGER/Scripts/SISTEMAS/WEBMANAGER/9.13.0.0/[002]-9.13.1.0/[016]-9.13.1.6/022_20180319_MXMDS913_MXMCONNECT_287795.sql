PROMPT ======================================================================
PROMPT == DEMANDA......: 287795
PROMPT == SISTEMA......: MXM CONNECT
PROMPT == RESPONSAVEL..: PALOMA CASSIA CAMPELO DE OLIVEIRA
PROMPT == DATA.........: 12/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRETABELARELVISAL_TRV
(TRV_IDTABELARELVISAO, TRV_NRVISAO, TRV_NRTABELA, TRV_NMLISTATABREL, TRV_NMCONDICAOTABREL)
VALUES
(
(SELECT MAX(TRV_IDTABELARELVISAO) +1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='VW_RECCARGO_CAR'),
 'RECCANDIDATOCARGO_RCC',
 'RECCANDIDATOCARGO_RCC.RCC_IDCARGO(+) = VW_RECCARGO_CAR.CAR_IDCARGO AND RECCANDIDATOCARGO_RCC.RCC_IDCANDIDATO = RECCANDIDATO_CAN.CAN_IDCANDIDATO(+)')
/

UPDATE GRETABDICDADOS_TDR
SET TDR_NRFORCARJOIN = 0
WHERE TDR_IDTABELA IN (
SELECT GRETABELARELVISAL_TRV.TRV_NRTABELA FROM GRETABELARELVISAL_TRV WHERE TRV_NRVISAO =
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'RECPROCRECRUTAMENTO_PRC'))
)
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
                     'Cargo',
             0,
             2,
                     'RECCARGO_CAR',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'VW_RECCARGO_CAR')),
             'VW_RECCARGO_CAR.CAR_IDCARGO', 'Cargo'
            )
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287795
PROMPT ======================================================================