PROMPT ======================================================================
PROMPT == DEMANDA......: 288388
PROMPT == SISTEMA......: Patrimonio
PROMPT == RESPONSAVEL..: Camilla Batista de Lima
PROMPT == DATA.........: 17/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FORCE VIEW VW_MOVSAP_MSAP (PAT_CDEMPRESA,
                                                    PAT_CDPATRIMO,
                                                    PAT_CDANEXO,
                                                    PAT_DESCRICAO,
                                                    PAT_FORNECEDOR,
                                                    PAT_FORNOME,
                                                    PAT_DOCUMENTO,
                                                    PAT_DTAQUIS,
                                                    PAT_LANCAQUIS,
                                                    PAT_GRPATRIM,
                                                    PAT_NOCCUSTO,
                                                    PAT_LOCAL,
                                                    PAT_RESPONSAVEL,
                                                    PAT_NUMSERIE,
                                                    PAT_CODITESTQ,
                                                    PAT_DATARESP,
                                                    PAT_DTBAIXA,
                                                    PAT_MOTBAIXA,
                                                    PAT_VLBAIXA1,
                                                    PAT_VLBAIXA2,
                                                    PAT_LANCBAIXA,
                                                    PAT_INVENTARIO,
                                                    PAT_DATAINV,
                                                    PAT_AQUIS1,
                                                    PAT_ACRBEM1,
                                                    PAT_PDEP1,
                                                    PAT_PERCDEP1,
                                                    PAT_DEPREC1,
                                                    PAT_ACRDEP1,
                                                    PAT_TPDEP1,
                                                    PAT_ULTMOV1,
                                                    PAT_DEPRTOT1,
                                                    PAT_AQUIS2,
                                                    PAT_ACRBEM2,
                                                    PAT_PDEP2,
                                                    PAT_PERCDEP2,
                                                    PAT_DEPREC2,
                                                    PAT_ACRDEP2,
                                                    PAT_TPDEP2,
                                                    PAT_ULTMOV2,
                                                    PAT_DEPRTOT2,
                                                    PAT_SUBGRPATRIM,
                                                    PAT_FILIAL,
                                                    PAT_DESCRCOMPLEM,
                                                    PAT_QUANTIDADE,
                                                    PAT_QTDACRDEC,
                                                    PAT_GARANTIA,
                                                    PAT_GECIAP,
                                                    PAT_TPMOVCIAP,
                                                    PAT_VLMAXDEPREC1,
                                                    PAT_VLMAXDEPREC2,
                                                    PAT_CDPROJETO,
                                                    PAT_USINCLUSAO,
                                                    PAT_NMORDEMTAXAVARIAVEL,
                                                    PAT_CODCENTCUS,
                                                    MSAP_CDEMPRESA,
                                                    MSAP_CDPATRIMO,
                                                    MSAP_CDANEXO,
                                                    MSAP_DATA,
                                                    MSAP_TPMOV,
                                                    MSAP_CCUSTO,
                                                    MSAP_LOCAL,
                                                    MSAP_RESPONSAVEL,
                                                    MSAP_VCOR,
                                                    MSAP_VDEP,
                                                    MSAP_PDEP,
                                                    MSAP_VCDEP,
                                                    MSAP_LANCCTB,
                                                    MSAP_HISTORICO,
                                                    MSAP_QUANTIDADE,
                                                    MSAP_COTACAO,
                                                    MSAP_IDMOVIMENTACAO,
                                                    MSAP_NMORDEMTAXAVARIAVEL,
                                                    VL_SALDO
                                                   )
AS
   SELECT PAT_CDEMPRESA, PAT_CDPATRIMO, PAT_CDANEXO, PAT_DESCRICAO, PAT_FORNECEDOR, PAT_FORNOME, PAT_DOCUMENTO,
          PAT_DTAQUIS, PAT_LANCAQUIS, PAT_GRPATRIM, PAT_NOCCUSTO, PAT_LOCAL, PAT_RESPONSAVEL, PAT_NUMSERIE,
          PAT_CODITESTQ, PAT_DATARESP, PAT_DTBAIXA, PAT_MOTBAIXA, PAT_VLBAIXA1, PAT_VLBAIXA2, PAT_LANCBAIXA,
          PAT_INVENTARIO, PAT_DATAINV, PAT_AQUIS1, PAT_ACRBEM1, PAT_PDEP1, PAT_PERCDEP1, PAT_DEPREC1, PAT_ACRDEP1,
          PAT_TPDEP1, PAT_ULTMOV1, PAT_DEPRTOT1, PAT_AQUIS2, PAT_ACRBEM2, PAT_PDEP2, PAT_PERCDEP2, PAT_DEPREC2,
          PAT_ACRDEP2, PAT_TPDEP2, PAT_ULTMOV2, PAT_DEPRTOT2, PAT_SUBGRPATRIM, PAT_FILIAL, PAT_DESCRCOMPLEM,
          PAT_QUANTIDADE, PAT_QTDACRDEC, PAT_GARANTIA, PAT_GECIAP, PAT_TPMOVCIAP, PAT_VLMAXDEPREC1, PAT_VLMAXDEPREC2,
          PAT_CDPROJETO, PAT_USINCLUSAO, PAT_NMORDEMTAXAVARIAVEL, PAT_CODCENTCUS, MSAP_CDEMPRESA, MSAP_CDPATRIMO,
          MSAP_CDANEXO, MSAP_DATA, MSAP_TPMOV, MSAP_CCUSTO, MSAP_LOCAL, MSAP_RESPONSAVEL, MSAP_VCOR, MSAP_VDEP,
          MSAP_PDEP, MSAP_VCDEP, MSAP_LANCCTB, MSAP_HISTORICO, MSAP_QUANTIDADE, MSAP_COTACAO, MSAP_IDMOVIMENTACAO,
          MSAP_NMORDEMTAXAVARIAVEL,
          DECODE(MSAP_TPMOV,'A',MSAP_VCOR,
                            'B',(MSAP_VCOR - MSAP_VDEP),
                            SUM(MSAP_VCOR - MSAP_VDEP) OVER (PARTITION BY PAT_CDEMPRESA, PAT_CDPATRIMO, PAT_CDANEXO ORDER BY MSAP_DATA)
              ) VL_SALDO
     FROM VW_PATRIMON_PAT, MOVSAP_MSAP
    WHERE MSAP_CDEMPRESA = PAT_CDEMPRESA AND MSAP_CDPATRIMO = PAT_CDPATRIMO AND MSAP_CDANEXO = PAT_CDANEXO
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
         (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='VW_MOVSAP_MSAP'),'VW_MOVSAP_MSAP.VL_SALDO','Saldo',3,'Saldo')
/

UPDATE GRECAMPOS_CDR
   SET CDR_DSCAMPOTABELA = '((SUM (DECODE (MSAP_TPMOV, ''B'', -MSAP_VCOR, MSAP_VCOR)) OVER (PARTITION BY PAT_CDEMPRESA, PAT_CDPATRIMO, PAT_CDANEXO))-(SUM (DECODE (MSAP_TPMOV, ''B'', -MSAP_VDEP, MSAP_VDEP)) OVER (PARTITION BY PAT_CDEMPRESA, PAT_CDPATRIMO, PAT_CDANEXO)))'
 WHERE CDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='VW_MOVSAP_MSAP')
   AND CDR_DSCAMPOTABELA = '(NVL(VW_MOVSAP_MSAP.PAT_AQUIS1,0) + NVL(VW_MOVSAP_MSAP.PAT_ACRBEM1,0))-NVL(VW_MOVSAP_MSAP.PAT_DEPREC1,0) -NVL(VW_MOVSAP_MSAP.PAT_ACRDEP1,0)'
/

UPDATE GRECAMPOS_CDR
   SET CDR_DSCAMPOTABELA = '(SUM(DECODE(MSAP_TPMOV, ''B'', -MSAP_VDEP, MSAP_VDEP)) OVER (PARTITION BY PAT_CDEMPRESA, PAT_CDPATRIMO, PAT_CDANEXO))'
 WHERE CDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='VW_MOVSAP_MSAP')
   AND CDR_DSCAMPOTABELA = 'VW_MOVSAP_MSAP.PAT_DEPREC1'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 288388
PROMPT ======================================================================