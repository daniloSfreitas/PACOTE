PROMPT ======================================================================
PROMPT == DEMANDA......: 287403
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: MARCOS FELIPE DE CARVALHO FIGUEIRED
PROMPT == DATA.........: 01/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE TRIGGER "TMANTITCP_TCP"   BEFORE INSERT OR UPDATE OR DELETE ON TITCP_TCP
FOR EACH ROW
DECLARE
 VALOR_TITULO NUMBER;
 VALOR_BAIXA  NUMBER;
 OLD_VALOR_TITULO NUMBER;
 OLD_VALOR_BAIXA  NUMBER;
BEGIN
  /*Se tem a cota��o informada converte pela cota��o do Titulo*/
  IF DELETING OR UPDATING THEN
    IF NVL(:NEW.TCP_VLRCOTACAOPR, 0) <> 0 THEN
     OLD_VALOR_TITULO := :OLD.TCP_VLRTITULO * :OLD.TCP_VLRCOTACAOPR;
    ELSE
     /*Se n�o tem � devido ao Titulo ser da mesma moeda da empresa*/
     OLD_VALOR_TITULO := :OLD.TCP_VLRTITULO;
    END IF;
    /*Se tem a cota��o informada converte pela cota��o da baixa do Titulo*/
    IF NVL(:OLD.TCP_VLRCOTACAOBX,0) <> 0 THEN
     OLD_VALOR_BAIXA := NVL(:OLD.TCP_VLRPAGO,0) * :OLD.TCP_VLRCOTACAOBX;
    ELSE
     /*Se n�o tem � devido ao Titulo ser da mesma moeda da empresa*/
     OLD_VALOR_BAIXA := NVL(:OLD.TCP_VLRPAGO, 0);
    END IF;
  END IF;
  IF :NEW.TCP_VLRCOTACAOPR <> 0 THEN
   VALOR_TITULO := :NEW.TCP_VLRTITULO * :NEW.TCP_VLRCOTACAOPR;
  ELSE
   /*Se n�o tem � devido ao Titulo ser da mesma moeda da empresa*/
   VALOR_TITULO := :NEW.TCP_VLRTITULO;
  END IF;
  /*Se tem a cota��o informada converte pela cota��o da baixa do Titulo*/
  IF :NEW.TCP_VLRCOTACAOBX <> 0 THEN
   VALOR_BAIXA := NVL(:NEW.TCP_VLRPAGO, 0) * :NEW.TCP_VLRCOTACAOBX;
  ELSE
   /*Se n�o tem � devido ao Titulo ser da mesma moeda da empresa*/
   VALOR_BAIXA := NVL(:NEW.TCP_VLRPAGO, 0);
  END IF;
  IF DELETING THEN
    INSERT INTO LOGDELMXM_LOG(LOG_NMTB, LOG_STR1, LOG_STR2, LOG_DTLOG, LOG_USER)
      VALUES('TITCP_TCP', :OLD.TCP_CDFOR, :OLD.TCP_NOTITULO, SYSDATE, GET_USER_MXM);
     /*A Exclus�o sempre e do Titulo e n�o de baixa*/
     MANFICHAFOR_FFO(:OLD.TCP_CDFOR, 2, -OLD_VALOR_TITULO, -1);
  ELSE
    IF  (INSERTING)
      OR(UPDATING AND (:NEW.TCP_DOCPAGAME IS NULL AND :OLD.TCP_DOCPAGAME IS NULL)
      OR(:NEW.TCP_DOCPAGAME IS NOT NULL AND :OLD.TCP_DOCPAGAME IS NOT NULL))
    THEN
      /*Na exclus�o remover o valor do Saldo da Ficha Financeira*/
      IF (UPDATING) AND (:OLD.TCP_VLRTITULO <> :NEW.TCP_VLRTITULO) THEN
        MANFICHAFOR_FFO(:OLD.TCP_CDFOR, 2, -OLD_VALOR_TITULO, -1);
      END IF;
      /*Insere na tabela de saldo da ficha financeira*/
      IF INSERTING OR ((UPDATING) AND (:OLD.TCP_VLRTITULO <> :NEW.TCP_VLRTITULO)) THEN
        MANFICHAFOR_FFO(:NEW.TCP_CDFOR, 1, VALOR_TITULO, 1);
      END IF;
      /*Procedure de Ajusta durante a inclus�o/altera��o dos titulo*/
      MANTITCPtbs(:NEW.TCP_CDFOR, :NEW.TCP_NOTITULO, :NEW.TCP_CDEMPORI, :NEW.TCP_CDFILIAL, :NEW.TCP_DTEMISSAO, :OLD.TCP_DTEMISSAO,
                  :NEW.TCP_MOEDA, :OLD.TCP_MOEDA, :NEW.TCP_VLRTITULO, :OLD.TCP_VLRTITULO, :NEW.TCP_ANTECIP, :OLD.TCP_ANTECIP,
                  :NEW.TCP_LOTEP, :NEW.TCP_LANCCTBP, :NEW.TCP_OBS);
    ELSE
      IF :NEW.TCP_DOCPAGAME IS NOT NULL
      THEN
        /*Insere a baixa de Titulo na tabela de Saldo da Ficha Financeira*/
        BXFICHAFOR(:NEW.TCP_CDFOR, :NEW.TCP_DTEMISSAO, :NEW.TCP_DTVENCIME, -VALOR_TITULO, :NEW.TCP_MOEDA,
                   :NEW.TCP_DTPAGAME, VALOR_BAIXA, 1);
        -- Realizar baixa de titulo
        BXTITCPtbs(:NEW.TCP_CDFOR, :NEW.TCP_NOTITULO, :NEW.TCP_CDEMPORI, :NEW.TCP_DTEMISSAO, :NEW.TCP_DTVENCIME, :NEW.TCP_DTPROG,
                   :NEW.TCP_VLRTITULO, :NEW.TCP_MOEDA, :NEW.TCP_VLRDESCON, :NEW.TCP_DTDESCONT, :NEW.TCP_PERMANDIA, :NEW.TCP_MULTA,
                   :NEW.TCP_BONIFIDIA, :NEW.TCP_IRRF, :NEW.TCP_CTAPAGAME, :NEW.TCP_DOCPAGAME, :NEW.TCP_DTPAGAME, :NEW.TCP_VLRPAGO,
                   :NEW.TCP_VLRPAGOM, :NEW.TCP_CDFMPAGBAN, :NEW.TCP_NOCHEQUE, :NEW.TCP_ANTECIP);
      ELSE
        /*Retorna o Valoda de Titulo na tabela de Saldo da Ficha Financeira*/
        BXFICHAFOR(:NEW.TCP_CDFOR, :NEW.TCP_DTEMISSAO, :NEW.TCP_DTVENCIME, OLD_VALOR_TITULO, :NEW.TCP_MOEDA,
                   :OLD.TCP_DTPAGAME, -OLD_VALOR_BAIXA, -1);
		-- Valores OLD para cancela a baixa de titulo
        BXTITCPtbs(:OLD.TCP_CDFOR, :OLD.TCP_NOTITULO, :OLD.TCP_CDEMPORI, :OLD.TCP_DTEMISSAO, :OLD.TCP_DTVENCIME, :NEW.TCP_DTPROG,
                   :OLD.TCP_VLRTITULO, :OLD.TCP_MOEDA, :NEW.TCP_VLRDESCON, :NEW.TCP_DTDESCONT, :NEW.TCP_PERMANDIA, :NEW.TCP_MULTA,
                   :NEW.TCP_BONIFIDIA, :NEW.TCP_IRRF, :OLD.TCP_CTAPAGAME, :NEW.TCP_DOCPAGAME, :OLD.TCP_DTPAGAME, :OLD.TCP_VLRPAGO,
                   :OLD.TCP_VLRPAGOM, :NEW.TCP_CDFMPAGBAN, :NEW.TCP_NOCHEQUE, :NEW.TCP_ANTECIP);
      END IF;
    END IF;
  END IF;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287403
PROMPT ======================================================================