PROMPT ======================================================================
PROMPT == DEMANDA......: 286178
PROMPT == SISTEMA......: MXM CONNECT
PROMPT == RESPONSAVEL..: PALOMA CASSIA CAMPELO DE OLIVEIRA
PROMPT == DATA.........: 26/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE CNTEDICAOINFORMATIVO_EIN
ADD (EIN_IDDOCUMENTO NUMBER(10))
/

ALTER TABLE CNTEDICAOINFORMATIVO_EIN MODIFY EIN_DSURLPUBINFORMATIVO NULL
/

Insert into MXS_SISTEMA_MXS
   (MXS_CDSISTEMA, MXS_DESCRICAO, MXS_INSTALACAO)
 Values
   ('CNTADM', 'Connect-Administrator', SYSDATE)
/

Insert into MXS_FUNCAOSISTEMA_MXFS
   (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM)
 Values
   ('CNTADM', 1000, 1)
/

Insert into MXS_FUNCAOSISTEMA_MXFS
   (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM)
 Values
   ('CNTADM', 3000, 3)
/

Insert into MXS_FUNCAOSISTEMA_MXFS
   (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM)
 Values
   ('CNTADM', 4000, 4)
/

Insert into MXS_FUNCAOSISTEMA_MXFS
   (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM)
 Values
   ('CNTADM', 2000, 2)
/

UPDATE MXS_FUNCAOSISTEMA_MXFS 
SET MXFS_CDSISTEMA = 'CNTADM' 
WHERE MXFS_CDFUNCAO IN (10733, --fale conosco
10734, --configuracoes
40290, --meu consumo
10785, --treinamento
10786, --Restri��o para cadastrar usu�rios
110002, --Comunidade
110001, --Usuario
10558, --Importar usu�rio
410001, --Meus dados
5010, --auditoria
40291, --meu layout
40456  --inativar usu�rio
) AND MXFS_CDSISTEMA  = 'MXMCONNECT'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 286178
PROMPT ======================================================================