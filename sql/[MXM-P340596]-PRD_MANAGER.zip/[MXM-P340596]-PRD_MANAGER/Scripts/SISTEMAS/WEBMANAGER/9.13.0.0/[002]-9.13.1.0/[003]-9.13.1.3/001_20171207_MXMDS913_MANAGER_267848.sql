PROMPT ======================================================================
PROMPT == DEMANDA......: 267848
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: Eduardo Lopes de Oliveira
PROMPT == DATA.........: 23/11/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE ORDCOMPRA_ORC MODIFY ORC_OBSERVACAO VARCHAR2(2000)
/

INSERT INTO MXS_FUNCAO_MXF(MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO)VALUES(389026,'Par�metros de Al�quotas de Impostos  - ICMS','Par�metros de Al�quotas de Impostos  - ICMS')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF(MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE)VALUES(389026, 'CON')
/

INSERT INTO MXS_FUNCAO_MXF(MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO)VALUES(385419, 'Par�metros de Al�quotas de Impostos  - ICMS - ST','Par�metros de Al�quotas de Impostos  - ICMS - ST')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF(MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE)VALUES(385419, 'CON')
/

INSERT INTO MXS_FUNCAO_MXF(MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO)VALUES(392172, 'Par�metros de al�quotas de impostos  - IPI', 'Par�metros de al�quotas de impostos  - IPI')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF(MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE)VALUES(392172, 'CON')
/

INSERT INTO MXS_FUNCAO_MXF(MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO)VALUES(382683, 'Par�metros de Al�quotas de Impostos  - PIS/COFINS','Par�metros de Al�quotas de Impostos  - PIS/COFINS')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF(MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE)VALUES(382683, 'CON')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 267848
PROMPT ======================================================================