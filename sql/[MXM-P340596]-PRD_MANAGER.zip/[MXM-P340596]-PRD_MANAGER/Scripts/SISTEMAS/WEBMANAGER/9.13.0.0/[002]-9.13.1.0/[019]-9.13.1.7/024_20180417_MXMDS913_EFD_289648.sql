PROMPT ======================================================================
PROMPT == DEMANDA......: 289648
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 17/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (35343, 'Confer�ncia das informa��es do DIPAM-B para servi�os de transporte', 'Confer�ncia das informa��es do DIPAM-B para servi�os de transporte')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('EFD', 35343, 17, 3000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35343, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35343, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35343, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 289648
PROMPT ======================================================================