PROMPT ======================================================================
PROMPT == DEMANDA......: 283175
PROMPT == SISTEMA......: Compras
PROMPT == RESPONSAVEL..: WALTER FERREIRA NETO
PROMPT == DATA.........: 27/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

Alter table EMAILS_EM modify EM_PARA VARCHAR2(4000)
/

CREATE OR REPLACE PROCEDURE insemails_em (
   pem_de           IN   CHAR,
   pem_para         IN   CHAR,
   pem_cc           IN   CHAR,
   pem_assunto      IN   CHAR,
   pem_texto        IN   CHAR,
   pem_requisicao   IN   CHAR,
   pem_empresa      IN   CHAR,
   pem_pedido       IN   CHAR
)
AS
  vpara  varchar2(4000);
BEGIN
   IF substr(pem_para, 1, 1) = CHR(13)
   THEN
      vpara := RTRIM(LTRIM(substr(pem_para, 2, 4000)));
   ELSE
      vpara := RTRIM(LTRIM(pem_para));
   END IF;
   INSERT INTO emails_em (
                  em_idemail,
                  em_dtcriacao,
                  em_de,
                  em_para,
                  em_cc,
                  em_assunto,
                  em_texto,
                  em_requisicao,
                  em_empresa,
                  em_pedido
               )
        VALUES (
           SEQ1_EMAILS_EM.NEXTVAL,
           SYSDATE,
           pem_de,
           vPARA,
           pem_cc,
           pem_assunto,
           pem_texto,
           pem_requisicao,
           pem_empresa,
           pem_pedido
        );
END;
/

CREATE OR REPLACE PROCEDURE ALTEMAILS_EM
AS BEGIN
   UPDATE EMAILS_EM SET EM_DTENVIO = SYSDATE
          WHERE
               EM_DTENVIO IS NULL;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283175
PROMPT ======================================================================