PROMPT ======================================================================
PROMPT == DEMANDA......: 283076
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: HUMBERTO COELHO DE CAMPOS MENDONCA
PROMPT == DATA.........: 18/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO IN ('DAD0001', 'DAD0002')
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES  ('DAD0001','C�digo do acr�scimo/decr�scimo inexistente.')
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES  ('DAD0002','S� � permitido informar acr�scimo/decr�scimo parametrizado com o Tipo de c�lculo adicional.')
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'DAD0003'
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES ('DAD0003', 'O Valor do desconto n�o pode ser maior que o valor total do documento.')
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'GSDF004'
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES ('GSDF004', 'N�o � permitido alterar lan�amento que possui t�tulo com baixa financeira.')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283076
PROMPT ======================================================================