PROMPT ======================================================================
PROMPT == DEMANDA......: 289032
PROMPT == SISTEMA......: MXM-RECRUITMENT
PROMPT == RESPONSAVEL..: PALOMA CASSIA CAMPELO DE OLIVEIRA
PROMPT == DATA.........: 02/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE SEQUENCE SEQ1_RECTIPOENTREVISTA_TIP
START WITH 1
INCREMENT BY 1
MAXVALUE 99999999
/

ALTER TABLE RECPROCRECRUTCAND_PCD
DROP CONSTRAINT FK3_RECPROCRECRUTCAND_PCD
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (11923, 'Tipo de entrevista', 'Tipo de entrevista')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('MXMRECRUIT', 11923, 8, 1000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11923, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11923, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11923, 'EXC')
/

ALTER TABLE RECCANDIDATO_CAN
ADD (CAN_DSCPF VARCHAR2(18))
/

UPDATE RECCANDIDATO_CAN
SET CAN_DSCPF = CAN_NRCPF
/

ALTER TABLE RECCANDIDATO_CAN
DROP COLUMN CAN_NRCPF
/

COMMENT ON COLUMN RECCANDIDATO_CAN.CAN_DSCPF IS 'CPF do candidato'
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECENTREVISTA_ENT'),
 '(SELECT TIP_DSTIPOENTREVISTA FROM RECTIPOENTREVISTA_TIP WHERE TIP_IDTIPOENTREVISTA = RECENTREVISTA_ENT.ENT_IDTIPOENTREVISTA)',
 'Tipo da entrevista',
  0,
 'Tipo da entrevista')
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
             'Tipo da entrevista',
             0,
             2,
             'RECTIPOENTREVISTA_TIP',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECENTREVISTA_ENT')),
             'RECENTREVISTA_ENT.ENT_IDTIPOENTREVISTA',
             'Tipo da entrevista'
            )
/

ALTER TABLE RECCANDIDATO_CAN
ADD (CAN_VBPORTADORDEFICIENCIA NUMBER(1))
/

ALTER TABLE RECCANDIDATO_CAN
ADD (CAN_DSGRAUINSTRUCAO VARCHAR2(50))
/

ALTER TABLE RECCANDIDATO_CAN
ADD (CAN_DSFORMACAO VARCHAR2(50))
/

ALTER TABLE RECCANDIDATO_CAN
ADD (CAN_DSCATEGORIAHABILITACAO VARCHAR2(30))
/

ALTER TABLE RECCANDIDATO_CAN
ADD (CAN_DSEXPERIENCIACARGO VARCHAR2(30))
/

ALTER TABLE RECCANDIDATO_CAN
ADD (CAN_VLPRETENSAOSALARIAL NUMBER(15,2))
/

COMMENT ON COLUMN RECCANDIDATO_CAN.CAN_VBPORTADORDEFICIENCIA IS 'Identifica se o candidato � portador de defici�ncia.'
/

COMMENT ON COLUMN RECCANDIDATO_CAN.CAN_DSGRAUINSTRUCAO IS 'Identifica o grau de instru��o do candidato. Ex: 1� grau, 2� grau, etc.'
/

COMMENT ON COLUMN RECCANDIDATO_CAN.CAN_DSFORMACAO IS 'Identifica a forma��o profissional do candidato.'
/

COMMENT ON COLUMN RECCANDIDATO_CAN.CAN_DSCATEGORIAHABILITACAO IS 'Identifica a categoria da habilita��o do candidato. Ex: A, B, A e B, etc.'
/

COMMENT ON COLUMN RECCANDIDATO_CAN.CAN_DSEXPERIENCIACARGO IS 'Identifica se o candidato possui exper�ncia no cargo baseada na quantidade de anos.'
/

COMMENT ON COLUMN RECCANDIDATO_CAN.CAN_VLPRETENSAOSALARIAL IS 'Pretens�o de sal�rio do candidato.'
/

INSERT INTO CAMPOAJUDA_CAJU(CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES('Y42', '001', 'TIP_IDTIPOENTREVISTA', 'C�digo', '', '')
/

INSERT INTO CAMPOAJUDA_CAJU(CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES('Y42', '002', 'TIP_DSTIPOENTREVISTA', 'Descri��o', '', '')
/

INSERT INTO JANELAJUDA_JAJU(JAJU_ARQUIVO, JAJU_CODIGO, JAJU_TAMANHO, JAJU_NUMCAMPO, JAJU_COMPRIMENTO, JAJU_PROCURA, JAJU_NOMEPROCURA, JAJU_TODOS,
JAJU_DSFROM, JAJU_DSWHERE, JAJU_DSGROUPBY, JAJU_DSORDERBY)
VALUES('RECTIPOENTREVISTA_TIP', 'Y42', '535', 'TIP_IDTIPOENTREVISTA', 300, 'TIP_DSTIPOENTREVISTA', 'Tipo de entrevista', 'S', '', '', '', 'TIP_DSTIPOENTREVISTA')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
 'RECCANDIDATO_CAN.CAN_DSCPF',
 'CPF',
  0,
 'CPF')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
 'DECODE(RECCANDIDATO_CAN.CAN_VBPORTADORDEFICIENCIA, 0, ''SIM'', ''N�O'')',
 'Pessoa com defici�ncia',
  2,
 'Defici�ncia')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
 'RECCANDIDATO_CAN.CAN_DSGRAUINSTRUCAO',
 'Grau de instru��o',
  0,
 'Grau de instru��o')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
 'RECCANDIDATO_CAN.CAN_DSFORMACAO',
 'Forma��o',
  0,
 'Forma��o')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
 'RECCANDIDATO_CAN.CAN_DSCATEGORIAHABILITACAO',
 'Categoria da habilita��o',
  0,
 'Habilita��o')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
 'RECCANDIDATO_CAN.CAN_DSEXPERIENCIACARGO',
 'Experi�ncia no cargo',
  0,
 'Experi�ncia')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
 (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='RECCANDIDATO_CAN'),
 'RECCANDIDATO_CAN.CAN_VLPRETENSAOSALARIAL',
 'Pretens�o salarial',
  3,
 'Pretens�o salarial')
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Pessoa com defici�ncia',
             1,
             0,
             'RECCANDIDATO_CAN',
             '',
             '',
             'DECODE(CAN_VBPORTADORDEFICIENCIA, 0, ''S'', ''N'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_VBPORTADORDEFICIENCIA',
             'Pessoa com defici�ncia'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Experi�ncia no cargo',
             0,
             0,
             '',
             '',
             '',
             '',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_DSEXPERIENCIACARGO',
             'Experi�ncia no cargo'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'CPF',
             0,
             0,
             '',
             '',
             '',
             '',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_DSCPF',
             'CPF'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Grau de instru��o',
             0,
             0,
             '',
             '',
             '',
             '',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_DSGRAUINSTRUCAO',
             'Grau de instru��o'
            )
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 289032
PROMPT ======================================================================