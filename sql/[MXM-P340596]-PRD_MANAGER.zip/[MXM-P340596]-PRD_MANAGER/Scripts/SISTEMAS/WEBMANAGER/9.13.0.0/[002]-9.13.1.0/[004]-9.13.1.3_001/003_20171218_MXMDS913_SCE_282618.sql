PROMPT ======================================================================
PROMPT == DEMANDA......: 282618
PROMPT == SISTEMA......: Cobranca Escritural
PROMPT == RESPONSAVEL..: MARCEL BRUNO BARREIROS COSTA
PROMPT == DATA.........: 08/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE PARAMS_PAR SET PAR_VLPARAM = 'N'  WHERE PAR_CDPARAM = 'wNUMERACAO_INDEPENDENTE_CADA_BANCO' AND NOT PAR_VLPARAM IN ('S','N')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282618
PROMPT ======================================================================