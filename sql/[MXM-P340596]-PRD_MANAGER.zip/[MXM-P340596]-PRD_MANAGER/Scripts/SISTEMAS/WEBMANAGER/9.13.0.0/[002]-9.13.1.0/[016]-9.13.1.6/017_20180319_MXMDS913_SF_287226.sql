PROMPT ======================================================================
PROMPT == DEMANDA......: 287226
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: DIOGO DE FREITAS RODRIGUES
PROMPT == DATA.........: 02/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_TRIBUTOSFAT(PFAT_CDEMPRESA  IN CHAR,
                                          PFAT_CDFILIAL   IN CHAR,
                                          PFAT_CDFATURA   IN NUMBER)
RETURN CHAR IS
  VRETORNO                 NUMBER(23, 4);
  VTOTTRIB                 NUMBER(23, 4);
  VPARUTILIZACALCIBPT      VARCHAR(5);
  VTPO_TIPO                TPOPER_TPO.TPO_TIPO%TYPE;
  VFAT_USOCONSUMO          FATURAS_FAT.FAT_USOCONSUMO%TYPE;
  VIFAT_TPOPER             ITFATURA_IFAT.IFAT_TPOPER%TYPE;
  VIFAT_QUANTIDADE         ITFATURA_IFAT.IFAT_QUANTIDADE%TYPE;
  VIFAT_PRECOINF           ITFATURA_IFAT.IFAT_PRECOINF%TYPE;
  VIFAT_VLRIPI             ITFATURA_IFAT.IFAT_VLRIPI%TYPE;
  VIFAT_CLFISC             ITFATURA_IFAT.IFAT_CLFISC%TYPE;
  VIFAT_CST                ITFATURA_IFAT.IFAT_CST%TYPE;
  VCIPI_CLFISCAL           CODIPI_CIPI.CIPI_CLFISCAL%TYPE;
  VCIPI_EX                 CODIPI_CIPI.CIPI_EX%TYPE;
  VPEALIQFEDERAL           NFECARGATRIBMEDIAIBPT_CTM.CTM_PEALIQNAC%TYPE;
  VPEALIQESTADUAL          NFECARGATRIBMEDIAIBPT_CTM.CTM_PEALIQEST%TYPE;
  VPEALIQMUNICIPAL         NFECARGATRIBMEDIAIBPT_CTM.CTM_PEALIQMUN%TYPE;
  VTTM_IDTABTRIBMEDIAIBPT  NFETABTRIBMEDIAIBPT_TTM.TTM_IDTABTRIBMEDIAIBPT%TYPE;
  CDUF                     VARCHAR(2);
  VPRD_PRODSERV            PRODUTO_PRD.PRD_PRODSERV%TYPE;
  VTOTTRIBFEDERAL          NUMBER(23, 4);
  VTOTTRIBESTADUAL         NUMBER(23, 4);
  VTOTTRIBMUNICIPAL        NUMBER(23, 4);
  CURSOR CURITFATURA_IFAT IS
    SELECT *
      FROM ITFATURA_IFAT
     WHERE IFAT_CDEMPRESA = PFAT_CDEMPRESA
       AND IFAT_CDFILIAL = PFAT_CDFILIAL
       AND IFAT_CDFATURA = PFAT_CDFATURA;
  RECITFATURA_IFAT CURITFATURA_IFAT%ROWTYPE;
BEGIN
  VRETORNO          := 0;
  VTOTTRIBFEDERAL   := 0;
  VTOTTRIBESTADUAL  := 0;
  VTOTTRIBMUNICIPAL := 0;
  OPEN CURITFATURA_IFAT;
  LOOP
    FETCH CURITFATURA_IFAT INTO RECITFATURA_IFAT;
    EXIT WHEN CURITFATURA_IFAT%NOTFOUND;
    SELECT FAT_USOCONSUMO,
           IFAT_TPOPER,
           IFAT_QUANTIDADE,
           IFAT_PRECOINF,
           IFAT_VLRIPI,
           IFAT_CLFISC,
           IFAT_CST,
           IFAT_VLRICMS + IFAT_VLRISS + IFAT_VLRIPI + IFAT_VLRPIS + IFAT_VLRCOFINS AS TOTTRIB
      INTO VFAT_USOCONSUMO,
           VIFAT_TPOPER,
           VIFAT_QUANTIDADE,
           VIFAT_PRECOINF,
           VIFAT_VLRIPI,
           VIFAT_CLFISC,
           VIFAT_CST,
           VTOTTRIB
      FROM ITFATURA_IFAT
     INNER JOIN FATURAS_FAT
       ON (   (FAT_CDEMPRESA = IFAT_CDEMPRESA)
           AND(FAT_CDFILIAL  = IFAT_CDFILIAL)
           AND(FAT_CDFATURA  = IFAT_CDFATURA))
     INNER JOIN TPOPER_TPO
       ON (IFAT_TPOPER = TPO_CODIGO)
      LEFT OUTER JOIN CODISS_ISS
       ON (   (IFAT_CDEMPRESA = ISS_CDEMPRESA)
           AND(IFAT_CDFILIAL  = ISS_CDFILIAL)
           AND(TPO_NATSERV = ISS_CODIGO))
     WHERE IFAT_CDEMPRESA = RECITFATURA_IFAT.IFAT_CDEMPRESA
       AND IFAT_CDFILIAL  = RECITFATURA_IFAT.IFAT_CDFILIAL
       AND IFAT_CDFATURA  = RECITFATURA_IFAT.IFAT_CDFATURA
       AND IFAT_ITEM      = RECITFATURA_IFAT.IFAT_ITEM
       AND IFAT_SEQUENCIA = RECITFATURA_IFAT.IFAT_SEQUENCIA;
    SELECT TPO_TIPO
      INTO VTPO_TIPO
      FROM TPOPER_TPO
     WHERE TPO_CODIGO = VIFAT_TPOPER;
    SELECT PRD_PRODSERV
      INTO VPRD_PRODSERV
      FROM PRODUTO_PRD
     WHERE PRD_ITEM = RECITFATURA_IFAT.IFAT_ITEM;
    SELECT EEN_UF
      INTO CDUF
      FROM EMPEND_EEN
     WHERE EEN_CODIGO = PFAT_CDEMPRESA
       AND EEN_CDEND  = PFAT_CDFILIAL;
    SELECT TTM_IDTABTRIBMEDIAIBPT
      INTO VTTM_IDTABTRIBMEDIAIBPT
      FROM NFETABTRIBMEDIAIBPT_TTM
     WHERE TTM_VBINATIVO = 'N'
       AND ROWNUM = 1
     ORDER BY TTM_IDTABTRIBMEDIAIBPT DESC;
    IF (   (VTPO_TIPO = 'S')
        AND(VFAT_USOCONSUMO = 'S'))
     THEN
      SELECT PAR_VLPARAM
        INTO VPARUTILIZACALCIBPT
        FROM PARAMS_PAR
       WHERE PAR_CDPARAM = 'PARNFEUTILIZACALIBPT' || PFAT_CDEMPRESA || PFAT_CDFILIAL;
      IF VPARUTILIZACALCIBPT = 'S'
       THEN VPARUTILIZACALCIBPT := 'TRUE';
       ELSE
         IF VPARUTILIZACALCIBPT = 'N'
          THEN VPARUTILIZACALCIBPT := 'FALSE';
         END IF;
      END IF;
      IF UPPER(VPARUTILIZACALCIBPT) = 'TRUE'
       THEN
         SELECT DECODE(CIPI_CLFISCAL, NULL, CIPI_CLFISCALNBS, DECODE(CIPI_CLFISCAL, '', CIPI_CLFISCALNBS, CIPI_CLFISCAL)),
                CIPI_EX
           INTO VCIPI_CLFISCAL, VCIPI_EX
           FROM CODIPI_CIPI
          WHERE CIPI_CODIGO = VIFAT_CLFISC;
         IF (  (VCIPI_EX = '')
             OR(VCIPI_EX IS NULL))
          THEN
            IF (  (SUBSTR(VIFAT_CST, 1, 1) = '0')
                OR(SUBSTR(VIFAT_CST, 1, 1) = '3')
                OR(SUBSTR(VIFAT_CST, 1, 1) = '4')
                OR(SUBSTR(VIFAT_CST, 1, 1) = '5'))
             THEN
               SELECT CTM_PEALIQNAC
                 INTO VPEALIQFEDERAL
                 FROM (SELECT CTM_PEALIQNAC
                         FROM NFECARGATRIBMEDIAIBPT_CTM
                        WHERE CTM_CDNCM = REPLACE(VCIPI_CLFISCAL ,'.','')
                          AND CTM_CDTABTRIBMEDIAIBPT = VTTM_IDTABTRIBMEDIAIBPT
                          AND CTM_CDUF = CDUF
                          AND CTM_CDEX IS NULL
                        UNION ALL
                       SELECT 0
                         FROM DUAL)
                WHERE ROWNUM = 1;
            ELSE
               SELECT CTM_PEALIQIMP
                 INTO VPEALIQFEDERAL
                FROM (SELECT CTM_PEALIQIMP
                        FROM NFECARGATRIBMEDIAIBPT_CTM
                       WHERE CTM_CDNCM = REPLACE(VCIPI_CLFISCAL ,'.','')
                         AND CTM_CDTABTRIBMEDIAIBPT = VTTM_IDTABTRIBMEDIAIBPT
                         AND CTM_CDUF = CDUF
                         AND CTM_CDEX IS NULL
                       UNION ALL
                      SELECT 0
                        FROM DUAL)
               WHERE ROWNUM = 1;
            END IF;
            IF (VPRD_PRODSERV = 'S') THEN
              SELECT CTM_PEALIQMUN
                INTO VPEALIQMUNICIPAL
                FROM (SELECT CTM_PEALIQMUN
                        FROM NFECARGATRIBMEDIAIBPT_CTM
                       WHERE CTM_CDNCM = REPLACE(VCIPI_CLFISCAL, '.', '')
                         AND CTM_CDTABTRIBMEDIAIBPT = VTTM_IDTABTRIBMEDIAIBPT
                         AND CTM_CDUF = CDUF
                         AND CTM_CDEX IS NULL
                      UNION ALL
                      SELECT 0 FROM DUAL)
               WHERE ROWNUM = 1;
            ELSE
              SELECT CTM_PEALIQEST
                INTO VPEALIQESTADUAL
                FROM (SELECT CTM_PEALIQEST
                        FROM NFECARGATRIBMEDIAIBPT_CTM
                       WHERE CTM_CDNCM = REPLACE(VCIPI_CLFISCAL, '.', '')
                         AND CTM_CDTABTRIBMEDIAIBPT = VTTM_IDTABTRIBMEDIAIBPT
                         AND CTM_CDUF = CDUF
                         AND CTM_CDEX IS NULL
                      UNION ALL
                      SELECT 0 FROM DUAL)
               WHERE ROWNUM = 1;
            END IF;
         ELSE
           IF (  (SUBSTR(VIFAT_CST, 1, 1) = '0')
                OR(SUBSTR(VIFAT_CST, 1, 1) = '3')
                OR(SUBSTR(VIFAT_CST, 1, 1) = '4')
                OR(SUBSTR(VIFAT_CST, 1, 1) = '5'))
            THEN
               SELECT CTM_PEALIQNAC
                 INTO VPEALIQFEDERAL
                 FROM (SELECT CTM_PEALIQNAC
                         FROM NFECARGATRIBMEDIAIBPT_CTM
                        WHERE CTM_CDNCM = REPLACE(VCIPI_CLFISCAL ,'.','')
                          AND CTM_CDTABTRIBMEDIAIBPT = VTTM_IDTABTRIBMEDIAIBPT
                          AND CTM_CDUF = CDUF
                          AND CTM_CDEX = VCIPI_EX
                        UNION ALL
                       SELECT 0
                         FROM DUAL)
                WHERE ROWNUM = 1;
            ELSE
               SELECT CTM_PEALIQIMP
                 INTO VPEALIQFEDERAL
                FROM (SELECT CTM_PEALIQIMP
                        FROM NFECARGATRIBMEDIAIBPT_CTM
                       WHERE CTM_CDNCM = REPLACE(VCIPI_CLFISCAL ,'.','')
                         AND CTM_CDTABTRIBMEDIAIBPT = VTTM_IDTABTRIBMEDIAIBPT
                         AND CTM_CDUF = CDUF
                         AND CTM_CDEX = VCIPI_EX
                       UNION ALL
                      SELECT 0
                        FROM DUAL)
               WHERE ROWNUM = 1;
            END IF;
            IF (VPRD_PRODSERV = 'S') THEN
              SELECT CTM_PEALIQMUN
                INTO VPEALIQMUNICIPAL
                FROM (SELECT CTM_PEALIQMUN
                        FROM NFECARGATRIBMEDIAIBPT_CTM
                       WHERE CTM_CDNCM = REPLACE(VCIPI_CLFISCAL, '.', '')
                         AND CTM_CDTABTRIBMEDIAIBPT = VTTM_IDTABTRIBMEDIAIBPT
                         AND CTM_CDUF = CDUF
                         AND CTM_CDEX = VCIPI_EX
                      UNION ALL
                      SELECT 0 FROM DUAL)
               WHERE ROWNUM = 1;
            ELSE
              SELECT CTM_PEALIQEST
                INTO VPEALIQESTADUAL
                FROM (SELECT CTM_PEALIQEST
                        FROM NFECARGATRIBMEDIAIBPT_CTM
                       WHERE CTM_CDNCM = REPLACE(VCIPI_CLFISCAL, '.', '')
                         AND CTM_CDTABTRIBMEDIAIBPT = VTTM_IDTABTRIBMEDIAIBPT
                         AND CTM_CDUF = CDUF
                         AND CTM_CDEX = VCIPI_EX
                      UNION ALL
                      SELECT 0 FROM DUAL)
               WHERE ROWNUM = 1;
            END IF;
          END IF;
        VTOTTRIBFEDERAL   := (VTOTTRIBFEDERAL   + ((((VIFAT_PRECOINF * VIFAT_QUANTIDADE) + VIFAT_VLRIPI) * VPEALIQFEDERAL) / 100));
        VTOTTRIBESTADUAL  := (VTOTTRIBESTADUAL  + ((((VIFAT_PRECOINF * VIFAT_QUANTIDADE) + VIFAT_VLRIPI) * VPEALIQESTADUAL) / 100));
        VTOTTRIBMUNICIPAL := (VTOTTRIBMUNICIPAL + ((((VIFAT_PRECOINF * VIFAT_QUANTIDADE) + VIFAT_VLRIPI) * VPEALIQMUNICIPAL) / 100));
        VRETORNO := (VRETORNO + ROUND((NVL(VTOTTRIBFEDERAL,0) + NVL(VTOTTRIBESTADUAL,0) + NVL(VTOTTRIBMUNICIPAL,0)),2));
      ELSE
        VRETORNO := (VRETORNO + VTOTTRIB);
      END IF;
    END IF;
  END LOOP;
  CLOSE CURITFATURA_IFAT;
  IF (VRETORNO = 0)
   THEN RETURN(NULL);
   ELSE RETURN(VRETORNO);
  END IF;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287226
PROMPT ======================================================================