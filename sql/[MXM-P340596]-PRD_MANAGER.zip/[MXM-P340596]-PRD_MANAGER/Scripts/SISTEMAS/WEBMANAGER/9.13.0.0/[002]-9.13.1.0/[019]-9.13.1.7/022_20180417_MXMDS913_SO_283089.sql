PROMPT ======================================================================
PROMPT == DEMANDA......: 283089
PROMPT == SISTEMA......: Orcamento
PROMPT == RESPONSAVEL..: Camilla Batista de Lima
PROMPT == DATA.........: 17/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27580, 'Informa��o de or�amento por projeto', 'Informa��o de or�amento por projeto')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SO', 27580, 27, 2000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27580, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27580, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27580, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283089
PROMPT ======================================================================