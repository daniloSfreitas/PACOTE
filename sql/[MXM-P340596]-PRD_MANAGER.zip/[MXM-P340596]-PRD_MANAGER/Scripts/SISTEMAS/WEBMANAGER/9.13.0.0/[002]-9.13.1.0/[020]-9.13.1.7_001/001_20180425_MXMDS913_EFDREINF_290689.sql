PROMPT ======================================================================
PROMPT == DEMANDA......: 290689
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: KAROLLYNE MENDES DA SILVA
PROMPT == DATA.........: 19/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE RNFTCPCOMP_RPC MODIFY RPC_NRDOCUMENTO VARCHAR2(15)
/

ALTER TABLE RNFTCRCOMP_RRC MODIFY RRC_NRDOCUMENTO VARCHAR2(15)
/

ALTER TABLE RNFTCPCOMP_RPCR MODIFY RPCR_NRDOCUMENTO VARCHAR2(15)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 290689
PROMPT ======================================================================