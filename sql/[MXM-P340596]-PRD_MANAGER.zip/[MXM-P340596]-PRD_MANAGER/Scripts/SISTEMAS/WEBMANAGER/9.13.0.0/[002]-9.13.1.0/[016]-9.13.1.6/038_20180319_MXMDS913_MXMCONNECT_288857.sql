PROMPT ======================================================================
PROMPT == DEMANDA......: 288857
PROMPT == SISTEMA......: MXM CONNECT
PROMPT == RESPONSAVEL..: PALOMA CASSIA CAMPELO DE OLIVEIRA
PROMPT == DATA.........: 19/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE TABLE RECTIPOENTREVISTA_TIP
(
  TIP_IDTIPOENTREVISTA           NUMBER(8)           NOT NULL,
  TIP_DSTIPOENTREVISTA           VARCHAR2(255 BYTE)  NOT NULL,
  TIP_USINCLUSAO            VARCHAR2(30 BYTE)  NOT NULL,
  TIP_DTINCLUSAO             DATE NOT NULL,
  TIP_USALTERACAO              VARCHAR2(30 BYTE)   NULL,
  TIP_DTALTERACAO               DATE  NULL
)
/

ALTER TABLE RECTIPOENTREVISTA_TIP ADD (
  CONSTRAINT PK_RECTIPOENTREVISTA_TIP
 PRIMARY KEY
 (TIP_IDTIPOENTREVISTA))
/

ALTER TABLE RECENTREVISTA_ENT
ADD (ENT_IDTIPOENTREVISTA NUMBER(8) NULL)
/

ALTER TABLE RECCANDIDATO_CAN
ADD (CAN_NRCPF NUMBER(18) NULL)
/

COMMENT ON COLUMN RECTIPOENTREVISTA_TIP.TIP_IDTIPOENTREVISTA IS 'C�digo do tipo de entrevista'
/

COMMENT ON COLUMN RECTIPOENTREVISTA_TIP.TIP_DSTIPOENTREVISTA IS 'Descri��o do tipo de entrevista'
/

COMMENT ON COLUMN RECTIPOENTREVISTA_TIP.TIP_USINCLUSAO IS 'Us�rio que cadastrou o tipo de entrevista'
/

COMMENT ON COLUMN RECTIPOENTREVISTA_TIP.TIP_DTINCLUSAO IS 'Data em que foi realizado o cadastro do tipo de entrevista'
/

COMMENT ON COLUMN RECTIPOENTREVISTA_TIP.TIP_USALTERACAO IS 'Usu�rio que alterou o tipo de entrevista'
/

COMMENT ON COLUMN RECTIPOENTREVISTA_TIP.TIP_DTALTERACAO IS 'Data em que foi alterado o tipo de entrevista'
/

COMMENT ON TABLE RECTIPOENTREVISTA_TIP IS 'Tabela para cria��o de um tipo de entrevista. Ex.: Din�mica de grupo, Entrevista individual'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 288857
PROMPT ======================================================================