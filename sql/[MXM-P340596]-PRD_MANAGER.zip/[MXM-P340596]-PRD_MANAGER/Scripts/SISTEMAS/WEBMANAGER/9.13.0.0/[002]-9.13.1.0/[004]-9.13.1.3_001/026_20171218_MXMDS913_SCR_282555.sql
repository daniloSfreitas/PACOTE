PROMPT ======================================================================
PROMPT == DEMANDA......: 282555
PROMPT == SISTEMA......: Contas a Receber
PROMPT == RESPONSAVEL..: JOAO PAULO RODRIGUES JIMENEZ
PROMPT == DATA.........: 18/12/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE ANTECIPCRGRP_AGRR DROP PRIMARY KEY CASCADE DROP INDEX
/

ALTER TABLE ANTECIPCRGRP_AGRR ADD CONSTRAINT PK_ANTECIPCRGRP_AGRR PRIMARY KEY (AGRR_CDCLIENTE, AGRR_DOCANTEC, AGRR_SEQ)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282555
PROMPT ======================================================================