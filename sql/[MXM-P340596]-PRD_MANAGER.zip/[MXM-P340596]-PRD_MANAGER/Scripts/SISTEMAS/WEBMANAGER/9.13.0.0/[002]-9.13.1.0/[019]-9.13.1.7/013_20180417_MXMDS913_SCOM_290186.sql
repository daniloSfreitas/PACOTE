PROMPT ======================================================================
PROMPT == DEMANDA......: 290186
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: ANDERSON EIJI NOGUTI
PROMPT == DATA.........: 11/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRECAMPOS_CDR
SET
CDR_DSCAMPOTABELA = 'DECODE(FORNEC_FOR.FOR_TIPESSOA, ''J'', ''Jur�dico'', ''F'', ''F�sico'', ''O'', ''Outros'', ''E'', ''Estrageiro'', ''G'', ''Governamental'')'
WHERE
CDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'FORNEC_FOR')
AND CDR_DSCAMPOTABELA = 'FORNEC_FOR.FOR_TIPESSOA'
/

UPDATE GRECAMPOS_CDR
SET
CDR_DSCAMPO = 'Alterado por',
CDR_DSCAMPOTABELACABECALHO = 'Alterado por'
WHERE
CDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'CLIENTE_CLI')
AND CDR_DSCAMPOTABELA = 'CLIENTE_CLI.CLI_USRALT'
/

INSERT INTO GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
VALUES (
   (SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
   (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'CLIENTE_CLI'),
   'CLIENTE_CLI.CLI_RESPCAD',
   'Cadastrado por',
   0,
   'Cadastrado por')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 290186
PROMPT ======================================================================