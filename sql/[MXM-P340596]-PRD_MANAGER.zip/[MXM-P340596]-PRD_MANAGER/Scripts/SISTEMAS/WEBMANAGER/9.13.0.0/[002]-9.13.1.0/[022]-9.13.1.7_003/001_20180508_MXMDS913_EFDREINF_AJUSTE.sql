/*

Ajuste incluido conforme solicitado pelo Maxuel 

De: Maxuel Santana 
Enviada em: ter�a-feira, 8 de maio de 2018 11:27
Para: admdados <admdados@mxm.com.br>
Cc: Alan Batista <alan.batista@mxm.com.br>; Vanderson Guidi <vanderson.guidi@mxm.com.br>; Elizabet Vianna <bet@mxm.com.br>
Assunto: Ajuste pacote reinf URL de homologa��o. URGENTE. 9.13.1.7 

Filipe,   Bom dia.

Preciso que esse script seja adicionado ao pacote reinf e distribu�do a todos os clientes que receberam o ajuste do reinf fechado na sexta dia 04/05.

*/




DELETE FROM PARAMS_PAR WHERE PAR_CDPARAM IN ('PAREFDREINF_URLRECEPCAOEVENTOSHOMOLOGACAO', 'PAREFDREINF_URLCONSULTAINFORMACOESCONSOLIDHOMOLOGACAO')
/
INSERT INTO PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
VALUES ('PAREFDREINF_URLRECEPCAOEVENTOSHOMOLOGACAO', 'https://preprodefdreinf.receita.fazenda.gov.br/wsreinf/RecepcaoLoteReinf.svc', GET_USER_MXM, SYSDATE, '', NULL, '', '', '', '')
/
INSERT INTO PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
VALUES ('PAREFDREINF_URLCONSULTAINFORMACOESCONSOLIDHOMOLOGACAO', 'https://preprodefdreinf.receita.fazenda.gov.br/wsreinf/ConsultasReinf.svc', GET_USER_MXM, SYSDATE, '', NULL, '', '', '', '')
/
COMMIT
/