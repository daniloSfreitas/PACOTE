PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.4_004 gerados em 06/02/2018 
PROMPT ============================================================= 

@@001_20180206_MXMDS913_EFD_285611.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.4_004');

COMMIT;
