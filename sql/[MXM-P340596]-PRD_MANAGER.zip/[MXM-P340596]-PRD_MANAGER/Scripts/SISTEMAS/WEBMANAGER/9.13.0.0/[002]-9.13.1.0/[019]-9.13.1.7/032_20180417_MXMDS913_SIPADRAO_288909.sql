PROMPT ======================================================================
PROMPT == DEMANDA......: 288909
PROMPT == SISTEMA......: Integra��o Padr�o
PROMPT == RESPONSAVEL..: GABRIEL SPINOLA TRINDADE MARINHO
PROMPT == DATA.........: 17/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE LAYOUTMOD_LYM SET LYM_DESCRICAO = 'Lote Contabil (em desuso)' WHERE LYM_MODELO = 'TITULOS A PAGAR' AND LYM_CAMPO = 'TCP_LOTEP' AND LYM_INDEX = 0
/

UPDATE LAYOUTMOD_LYM LYM
   SET LYM.LYM_TAM = 2000
 WHERE LYM.LYM_MODELO = 'FATURAMENTO'
   AND LYM.LYM_CAMPO  = 'FAT_OBS'
   AND LYM.LYM_SEQ    = 36
   AND LYM.LYM_INDEX  = 0
/

ALTER TABLE TINLOGPROCESSAMENTO_TLP MODIFY(TLP_CDOPERACAO VARCHAR2(30 BYTE))
/

alter table TI_ARQFATURAS_TAFT modify TAFT_TEOBS VARCHAR2(2000)
/

UPDATE LAYOUT_LAY SET LAY_IMPORTACAO = 'Informa��es Complementares' WHERE LAY_MODELO = 'FORNECEDORES' AND   LAY_INDEX = 4
/

UPDATE LAYOUT_LAY SET LAY_IMPORTACAO = 'Informa��es Complementares' WHERE LAY_MODELO = 'CLIENTES' AND   LAY_INDEX = 5
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('FORNECEDORES', 'FORE_TIPESSOA',            8, 'Tipo de Pessoa Estrangeira',        'C',  1, 0, 4)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('FORNECEDORES', 'FORE_NIFEXTDIRF',          9, 'NIF (Fornec.estrangeiro DIRF CGC)', 'C', 30, 0, 4)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('FORNECEDORES', 'FORE_CDBENEFRENDEXTDIRF', 10, 'Benefici�rio Rendimento Exterior',  'C',  3, 0, 4)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('FORNECEDORES', 'FORE_DISPNIF',            11, 'Benefici�rio Dispensado do NIF',    'C',  1, 0, 4)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('FORNECEDORES', 'FORE_PAISDISPNIF',        12, 'Pa�s N�o Exige NIF',                'C',  1, 0, 4)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'FORNECEDORES', 'FORE_TIPESSOA',           'C', 52,  1, 0, '', 4)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'FORNECEDORES', 'FORE_NIFEXTDIRF',         'C', 53, 30, 0, '', 4)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'FORNECEDORES', 'FORE_CDBENEFRENDEXTDIRF', 'C', 83,  3, 0, '', 4)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'FORNECEDORES', 'FORE_DISPNIF',            'C', 86,  1, 0, '', 4)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'FORNECEDORES', 'FORE_PAISDISPNIF',        'C', 87,  1, 0, '', 4)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'FORNECEDORES', 'FORE_TIPESSOA',           'C', 52,  1, 0, 'CV', 4)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'FORNECEDORES', 'FORE_NIFEXTDIRF',         'C', 53, 30, 0, 'CW', 4)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'FORNECEDORES', 'FORE_CDBENEFRENDEXTDIRF', 'C', 83,  3, 0, 'CX', 4)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'FORNECEDORES', 'FORE_DISPNIF',            'C', 86,  1, 0, 'CY', 4)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'FORNECEDORES', 'FORE_PAISDISPNIF',        'C', 87,  1, 0, 'CZ', 4)
/

ALTER TABLE TINARQFORPARPART_FPPA ADD (FPPA_TPPESSOA VARCHAR2(1 BYTE))
/

ALTER TABLE TINARQFORPARPART_FPPA ADD (FPPA_NIFEXTDIRF VARCHAR2(30 BYTE))
/

ALTER TABLE TINARQFORPARPART_FPPA ADD (FPPA_CDBENEFRENDEXTDIRF VARCHAR2(3 BYTE))
/

ALTER TABLE TINARQFORPARPART_FPPA ADD (FPPA_DISPNIF VARCHAR2(1 BYTE))
/

ALTER TABLE TINARQFORPARPART_FPPA ADD (FPPA_PAISDISPNIF VARCHAR2(1 BYTE))
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_TPPESSOA IS 'Tipo de Pessoa (estrangeira)'
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_NIFEXTDIRF IS 'NIF Fornecedor estrangeiro - DIRF campo FOR_CGC'
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_CDBENEFRENDEXTDIRF IS 'C�digo das Informa��es sobre os Benefici�rios dos Rendimentos no Exterior - DIRF'
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_DISPNIF IS 'Benefici�rio Dispensado do NIF'
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_PAISDISPNIF IS 'Pa�s N�o Exige NIF'
/

CREATE OR REPLACE PROCEDURE PRC_INSTINARQFORPARPART_FPPA
(
  PFPPA_IDPROCESSO         IN NUMBER,
  PFPPA_IDREGISTRO         IN NUMBER,
  PFPPA_IDPARPART          IN NUMBER,
  PFPPA_NRINSCESTST        IN CHAR,
  PFPPA_NRCEI              IN CHAR,
  PFPPA_NRNIT              IN CHAR,
  PFPPA_NRINDNATRET        IN CHAR,
  PFPPA_TPASSINANTE        IN CHAR,
  PFPPA_TPSIMPLESNACIONAL  IN CHAR,
  PFPPA_TPCLIENTESERVCOM   IN CHAR,
  PFPPA_TPPESSOA           IN CHAR,
  PFPPA_NIFEXTDIRF         IN CHAR,
  PFPPA_CDBENEFRENDEXTDIRF IN CHAR,
  PFPPA_DISPNIF            IN CHAR,
  PFPPA_PAISDISPNIF        IN CHAR
)
AS BEGIN
  INSERT INTO TINARQFORPARPART_FPPA
  (FPPA_IDPROCESSO, FPPA_IDREGISTRO, FPPA_IDPARPART, FPPA_NRINSCESTST, FPPA_NRCEI, FPPA_NRNIT,
   FPPA_NRINDNATRET, FPPA_TPASSINANTE, FPPA_TPSIMPLESNACIONAL, FPPA_TPCLIENTESERVCOM, 
   FPPA_TPPESSOA, FPPA_NIFEXTDIRF, FPPA_CDBENEFRENDEXTDIRF, FPPA_DISPNIF, FPPA_PAISDISPNIF)
  VALUES
  (PFPPA_IDPROCESSO, PFPPA_IDREGISTRO, PFPPA_IDPARPART, PFPPA_NRINSCESTST, PFPPA_NRCEI, PFPPA_NRNIT,
   PFPPA_NRINDNATRET, PFPPA_TPASSINANTE, PFPPA_TPSIMPLESNACIONAL, PFPPA_TPCLIENTESERVCOM, 
   PFPPA_TPPESSOA, PFPPA_NIFEXTDIRF, PFPPA_CDBENEFRENDEXTDIRF, PFPPA_DISPNIF, PFPPA_PAISDISPNIF);
END;
/

ALTER TABLE TI_ARQFORNEC_TAFO ADD (TAFO_VBENVIARINFORMEREND  VARCHAR2(1 BYTE))
/

COMMENT ON COLUMN TI_ARQFORNEC_TAFO.TAFO_VBENVIARINFORMEREND IS 'Flag Indicativo de envio de informe de rendimento ao fornecedor: S-Sim, N-N�o'
/

CREATE OR REPLACE PROCEDURE INSTI_ARQFORNEC_TAFO
 (PTAFO_SQPROCESSO          IN NUMBER,
  PTAFO_SQREGISTRO          IN NUMBER,
  PTAFO_CODIGO              IN CHAR,
  PTAFO_NOME                IN CHAR,
  PTAFO_ENDERECO            IN CHAR,
  PTAFO_TIPESSOA            IN CHAR,
  PTAFO_BAIRRO              IN CHAR,
  PTAFO_CIDADE              IN CHAR,
  PTAFO_UF                  IN CHAR,
  PTAFO_CEP                 IN CHAR,
  PTAFO_TEL                 IN CHAR,
  PTAFO_FAX                 IN CHAR,
  PTAFO_CGC                 IN CHAR,
  PTAFO_INSCRICAO           IN CHAR,
  PTAFO_DTMOV               IN CHAR,
  PTAFO_DTCAD               IN CHAR,
  PTAFO_DTNASC              IN CHAR,
  PTAFO_NOMEFANT            IN CHAR,
  PTAFO_ATIVO               IN CHAR,
  PTAFO_HOMOLOGADO          IN CHAR,
  PTAFO_QTDDEP              IN CHAR,
  PTAFO_PAIS                IN CHAR,
  PTAFO_INSCINSS            IN CHAR,
  PTAFO_CLASSEINSS          IN CHAR,
  PTAFO_TETOMAX             IN CHAR,
  PTAFO_EMAIL               IN CHAR,
  PTAFO_INSCMUNIP           IN CHAR,
  PTAFO_INSCSUFRAMA         IN CHAR,
  PTAFO_SALBASE             IN CHAR,
  PTAFO_PISPASEP            IN CHAR,
  PTAFO_CATTRAB             IN CHAR,
  PTAFO_COOPERATIVA         IN CHAR DEFAULT NULL,
  PTAFO_SQCBO               IN CHAR,
  PTAFO_STOPERACAO          IN NUMBER,
  PTAFO_CDPAIS              IN CHAR DEFAULT NULL,
  PTAFO_CDCIDADE            IN CHAR DEFAULT NULL,
  PTAFO_NUMENDERECO         IN CHAR DEFAULT NULL,
  PTAFO_COMPENDERECO        IN CHAR DEFAULT NULL,
  PTAFO_VBRURAL             IN CHAR DEFAULT NULL,
  PTAFO_TPINDIEDEST         IN CHAR DEFAULT NULL,
  PTAFO_ESTADOCIVIL         IN CHAR DEFAULT NULL,
  PTAFO_NAC                 IN CHAR DEFAULT NULL,
  PTAFO_VBENVIARINFORMEREND IN CHAR DEFAULT NULL
  )
AS BEGIN
  INSERT INTO TI_ARQFORNEC_TAFO
   (TAFO_SQPROCESSO,
    TAFO_SQREGISTRO,
    TAFO_CODIGO,
    TAFO_NOME,
    TAFO_ENDERECO,
    TAFO_TIPESSOA,
    TAFO_BAIRRO,
    TAFO_CIDADE,
    TAFO_UF,
    TAFO_CEP,
    TAFO_TEL,
    TAFO_FAX,
    TAFO_CGC,
    TAFO_INSCRICAO,
    TAFO_DTMOV,
    TAFO_DTCAD,
    TAFO_DTNASC,
    TAFO_NOMEFANT,
    TAFO_ATIVO,
    TAFO_HOMOLOGADO,
    TAFO_QTDDEP,
    TAFO_PAIS,
    TAFO_INSCINSS,
    TAFO_CLASSEINSS,
    TAFO_TETOMAX,
    TAFO_EMAIL,
    TAFO_INSCMUNIP,
    TAFO_INSCSUFRAMA,
    TAFO_SALBASE,
    TAFO_PISPASEP,
    TAFO_CATTRAB,
    TAFO_SQCBO,
    TAFO_STOPERACAO,
    TAFO_CDPAIS,
    TAFO_CDCIDADE,
    TAFO_NUMENDERECO,
    TAFO_COMPENDERECO,
    TAFO_COOPERATIVA,
    TAFO_VBRURAL,
    TAFO_TPINDIEDEST,
    TAFO_ESTADOCIVIL,
    TAFO_NAC,
    TAFO_VBENVIARINFORMEREND
    )
  VALUES
   (PTAFO_SQPROCESSO,
    PTAFO_SQREGISTRO,
    PTAFO_CODIGO,
    PTAFO_NOME,
    PTAFO_ENDERECO,
    PTAFO_TIPESSOA,
    PTAFO_BAIRRO,
    PTAFO_CIDADE,
    PTAFO_UF,
    PTAFO_CEP,
    PTAFO_TEL,
    PTAFO_FAX,
    PTAFO_CGC,
    PTAFO_INSCRICAO,
    PTAFO_DTMOV,
    PTAFO_DTCAD,
    PTAFO_DTNASC,
    PTAFO_NOMEFANT,
    PTAFO_ATIVO,
    PTAFO_HOMOLOGADO,
    PTAFO_QTDDEP,
    PTAFO_PAIS,
    PTAFO_INSCINSS,
    PTAFO_CLASSEINSS,
    PTAFO_TETOMAX,
    PTAFO_EMAIL,
    PTAFO_INSCMUNIP,
    PTAFO_INSCSUFRAMA,
    PTAFO_SALBASE,
    PTAFO_PISPASEP,
    PTAFO_CATTRAB,
    PTAFO_SQCBO,
    PTAFO_STOPERACAO,
    PTAFO_CDPAIS,
    PTAFO_CDCIDADE,
    PTAFO_NUMENDERECO,
    PTAFO_COMPENDERECO,
    PTAFO_COOPERATIVA,
    PTAFO_VBRURAL,
    PTAFO_TPINDIEDEST,
    PTAFO_ESTADOCIVIL,
    PTAFO_NAC,
    PTAFO_VBENVIARINFORMEREND
    );
END;
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('FORNECEDORES', 'TAFO_VBENVIARINFORMEREND', 34, 'Enviar Informe de Rendimento', 'C', 1, 0, 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'FORNECEDORES', 'TAFO_VBENVIARINFORMEREND', 'C', 651, 1, 0, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'FORNECEDORES', 'TAFO_VBENVIARINFORMEREND', 'C', 651,  1, 0, 'AG', 0)
/

ALTER TABLE TINARQFORPARPART_FPPA DROP CONSTRAINT PK_TINARQFORPARPART_FPPA
/

ALTER TABLE TINARQFORPARPART_FPPA DROP CONSTRAINT FK1_TINARQFORPARPART_FPPA
/

CREATE UNIQUE INDEX TINARQFORPARPART_FPPA_PK ON TINARQFORPARPART_FPPA (FPPA_IDPROCESSO, FPPA_IDREGISTRO, FPPA_IDPARPART)
/

ALTER TABLE TINARQFORPARPART_FPPA ADD (CONSTRAINT PK_TINARQFORPARPART_FPPA PRIMARY KEY (FPPA_IDPROCESSO, FPPA_IDREGISTRO, FPPA_IDPARPART))
/

ALTER TABLE TINARQFORPARPART_FPPA ADD (CONSTRAINT FK1_TINARQFORPARPART_FPPA FOREIGN KEY (FPPA_IDPROCESSO, FPPA_IDREGISTRO) REFERENCES TI_ARQFORNEC_TAFO (TAFO_SQPROCESSO, TAFO_SQREGISTRO))
/

ALTER TABLE TINARQFORPARPART_FPPA DROP COLUMN FPPA_VBINATIVACAO
/

ALTER TABLE TINARQFORPARPART_FPPA DROP COLUMN FPPA_USINATIVACAO
/

ALTER TABLE TINARQFORPARPART_FPPA DROP COLUMN FPPA_DTINATIVACAO
/

ALTER TABLE TINARQFORPARPART_FPPA DROP COLUMN FPPA_USINCLUSAO
/

ALTER TABLE TINARQFORPARPART_FPPA DROP COLUMN FPPA_DTINCLUSAO
/

ALTER TABLE TINARQFORPARPART_FPPA DROP COLUMN FPPA_USALTERACAO
/

ALTER TABLE TINARQFORPARPART_FPPA DROP COLUMN FPPA_DTALTERACAO
/

--ALTER TABLE FORNEC_FOR ADD (FOR_VBENVIARINFORMEREND CHAR(1 BYTE) DEFAULT 'N')
--/

SET SERVEROUT ON 
DECLARE
	vCOUNT NUMBER;
	TYPE tpVARCHAR2_TBL IS TABLE OF VARCHAR2(30);
	vTRIGGERS_TBL tpVARCHAR2_TBL;
	PROCEDURE EXECUTA_COMANDO (
		pCOMANDO IN VARCHAR2
	) IS
	BEGIN
		DBMS_OUTPUT.PUT_LINE(pCOMANDO||';'||CHR(10));
		EXECUTE IMMEDIATE pCOMANDO;
		DBMS_OUTPUT.PUT_LINE('Comanado executado com sucesso.'||CHR(10));
		EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('ORA-20015:'||SQLERRM||CHR(10));
	END EXECUTA_COMANDO;
BEGIN
	vCOUNT:=0;
	SELECT 
		COUNT(1) 
	INTO 
		vCOUNT 
	FROM USER_TAB_COLUMNS 
	WHERE TABLE_NAME='FORNEC_FOR' 
	AND COLUMN_NAME='FOR_VBENVIARINFORMEREND';
	
	IF vCOUNT = 0 THEN
		DBMS_OUTPUT.PUT_LINE('=======================================================');
		DBMS_OUTPUT.PUT_LINE('Adicionando campo FORNEC_FOR.FOR_VBENVIARINFORMEREND...');
		DBMS_OUTPUT.PUT_LINE('=======================================================');
		SELECT 
			TRIGGER_NAME 
		BULK COLLECT INTO 
			vTRIGGERS_TBL
		FROM 	USER_TRIGGERS 
		WHERE 	TABLE_NAME 					= 		'FORNEC_FOR'
		AND 	STATUS 						= 		'ENABLED'
		AND 	UPPER(TRIGGERING_EVENT) 	LIKE 	'%UPDATE%';
		IF vTRIGGERS_TBL.COUNT = 0 THEN
			EXECUTA_COMANDO('ALTER TABLE FORNEC_FOR ADD FOR_VBENVIARINFORMEREND CHAR(1) DEFAULT ''N''');
		ELSE 
			--Desabilitando
			FOR I1 IN vTRIGGERS_TBL.FIRST..vTRIGGERS_TBL.LAST LOOP
				EXECUTA_COMANDO('ALTER TRIGGER "'||vTRIGGERS_TBL(I1)||'" DISABLE');
			END LOOP;
			--Alterando tabela
			EXECUTA_COMANDO('ALTER TABLE FORNEC_FOR ADD FOR_VBENVIARINFORMEREND CHAR(1) DEFAULT ''N''');
			--Habilitando
			FOR I1 IN vTRIGGERS_TBL.FIRST..vTRIGGERS_TBL.LAST LOOP
				EXECUTA_COMANDO('ALTER TRIGGER "'||vTRIGGERS_TBL(I1)||'" ENABLE');
			END LOOP;
		END IF;
	ELSE
		DBMS_OUTPUT.PUT_LINE('=======================================================');
		DBMS_OUTPUT.PUT_LINE('Campo FORNEC_FOR.FOR_VBENVIARINFORMEREND j� existe!');
		DBMS_OUTPUT.PUT_LINE('=======================================================');
	END IF;
END;
/

COMMENT ON COLUMN FORNEC_FOR.FOR_VBENVIARINFORMEREND IS 'Enviar informe de rendimento'
/

CREATE OR REPLACE PROCEDURE INSFORNEC_FOR
 (PFOR_CODIGO              IN CHAR,
  PFOR_NOME                IN CHAR,
  PFOR_ENDERECO            IN CHAR,
  PFOR_NUMENDERECO         IN CHAR DEFAULT NULL,
  PFOR_COMPENDERECO        IN CHAR DEFAULT NULL,
  PFOR_TIPESSOA            IN CHAR,
  PFOR_BAIRRO              IN CHAR,
  PFOR_CIDADE              IN CHAR,
  PFOR_UF                  IN CHAR,
  PFOR_PAIS                IN CHAR,
  PFOR_CEP                 IN CHAR,
  PFOR_TEL                 IN CHAR,
  PFOR_FAX                 IN CHAR,
  PFOR_CGC                 IN CHAR,
  PFOR_INSCRICAO           IN CHAR,
  PFOR_ENDERECO1           IN CHAR,
  PFOR_DTMOV               IN DATE,
  PFOR_DTCAD               IN DATE,
  PFOR_DTNASC              IN DATE,
  PFOR_CODBAIRRO           IN CHAR,
  PFOR_NOMEFANT            IN CHAR,
  PFOR_QTDDEP              IN NUMBER,
  PFOR_INSCINSS            IN CHAR,
  PFOR_CLASSEINSS          IN CHAR,
  PFOR_TETOMAX             IN CHAR,
  PFOR_EMAIL               IN CHAR,
  PFOR_INSCMUNIP           IN CHAR,
  PFOR_INSCSUFRAMA         IN CHAR   DEFAULT NULL,
  PFOR_SALBASE             IN NUMBER DEFAULT 0 ,
  PFOR_PISPASEP            IN CHAR DEFAULT NULL,
  PFOR_SQCBO               IN NUMBER DEFAULT NULL,
  PFOR_CATTRAB             IN CHAR DEFAULT NULL,
  PFOR_COOPERATIVA         IN CHAR DEFAULT 'N',
  PFOR_NAC                 IN CHAR,
  PFOR_ESTADOCIVIL         IN CHAR,
  PFOR_GRPEMPRESARIAL      IN VARCHAR2 DEFAULT NULL,
  PFOR_CDPAIS              IN CHAR DEFAULT NULL,
  PFOR_RESPCAD             IN CHAR DEFAULT GET_USER_MXM,
  PFOR_VBPRURAL            IN CHAR DEFAULT 'N',
  PFOR_TPINDIEDEST         IN CHAR DEFAULT NULL,
  PFOR_VBENVIARINFORMEREND IN CHAR DEFAULT 'N')
AS
  nRows        INTEGER;
  nCursor      INTEGER;
  nPAR_DBLMXM  INTEGER;
  CURSOR PARAMS IS
    SELECT TO_NUMBER(NVL(PAR_VLPARAM,0))
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = 'wPAR_DBLMXM';
BEGIN
  INSERT
    INTO FORNEC_FOR
        (FOR_CODIGO,
         FOR_NOME,
         FOR_ENDERECO,
         FOR_NUMENDERECO,
         FOR_COMPENDERECO,
         FOR_TIPESSOA,
         FOR_BAIRRO,
         FOR_CIDADE,
         FOR_UF,
         FOR_PAIS,
         FOR_CEP,
         FOR_TEL,
         FOR_FAX,
         FOR_CGC,
         FOR_INSCRICAO,
         FOR_ENDERECO1,
         FOR_DTMOV,
         FOR_DTCAD,
         FOR_DTNASC,
         FOR_CODBAIRRO,
         FOR_NOMEFANT,
         FOR_RESPCAD,
         FOR_HOMOLOGADO,
         FOR_QTDDEP,
         FOR_INSCINSS,
         FOR_CLASSEINSS,
         FOR_TETOMAX,
         FOR_EMAIL,
         FOR_INSCMUNIP,
         FOR_INSCSUFRAMA,
         FOR_SALBASE,
         FOR_PISPASEP,
         FOR_SQCBO,
         FOR_CATTRAB,
         FOR_COOPERATIVA,
         FOR_NAC,
         FOR_ESTADOCIVIL,
         FOR_CDPAIS,
         FOR_GRPEMPRESARIAL,
         FOR_VBPRURAL,
         FOR_TPINDIEDEST,
         FOR_VBENVIARINFORMEREND)
  VALUES
        (PFOR_CODIGO,
         PFOR_NOME,
         PFOR_ENDERECO,
         PFOR_NUMENDERECO,
         PFOR_COMPENDERECO,
         PFOR_TIPESSOA,
         PFOR_BAIRRO,
         PFOR_CIDADE,
         PFOR_UF,
         PFOR_PAIS,
         PFOR_CEP,
         PFOR_TEL,
         PFOR_FAX,
         PFOR_CGC,
         PFOR_INSCRICAO,
         PFOR_ENDERECO1,
         PFOR_DTMOV,
         PFOR_DTCAD,
         PFOR_DTNASC,
         PFOR_CODBAIRRO,
         PFOR_NOMEFANT,
         GET_USER_MXM,
         'N',
         PFOR_QTDDEP,
         PFOR_INSCINSS,
         PFOR_CLASSEINSS,
         PFOR_TETOMAX,
         PFOR_EMAIL,
         PFOR_INSCMUNIP,
         PFOR_INSCSUFRAMA,
         PFOR_SALBASE,
         PFOR_PISPASEP,
         PFOR_SQCBO,
         PFOR_CATTRAB,
         PFOR_COOPERATIVA,
         PFOR_NAC,
         PFOR_ESTADOCIVIL,
         PFOR_CDPAIS,
         PFOR_GRPEMPRESARIAL,
         PFOR_VBPRURAL,
         PFOR_TPINDIEDEST,
         PFOR_VBENVIARINFORMEREND);
  -- processamentos dos links --
  OPEN  PARAMS;
  FETCH PARAMS INTO nPAR_DBLMXM;
  IF PARAMS%FOUND THEN
    nCursor := dbms_sql.open_cursor;
    WHILE nPAR_DBLMXM > 0 LOOP
      DBMS_SQL.PARSE(nCursor,
                     'INSERT '                               ||
                     '  INTO FORNEC_FOR@DBLMXM'              || TO_CHAR(nPAR_DBLMXM) ||
                     '      (FOR_CODIGO,'                    ||
                     '       FOR_NOME,'                      ||
                     '       FOR_ENDERECO,'                  ||
                     '       FOR_NUMENDERECO,'               ||
                     '       FOR_COMPENDERECO,'              ||
                     '       FOR_TIPESSOA,'                  ||
                     '       FOR_BAIRRO,'                    ||
                     '       FOR_CIDADE,'                    ||
                     '       FOR_UF,'                        ||
                     '       FOR_PAIS,'                      ||
                     '       FOR_CEP,'                       ||
                     '       FOR_TEL,'                       ||
                     '       FOR_FAX,'                       ||
                     '       FOR_CGC,'                       ||
                     '       FOR_INSCRICAO,'                 ||
                     '       FOR_ENDERECO1,'                 ||
                     '       FOR_DTMOV,'                     ||
                     '       FOR_DTCAD,'                     ||
                     '       FOR_DTNASC,'                    ||
                     '       FOR_CODBAIRRO,'                 ||
                     '       FOR_NOMEFANT,'                  ||
                     '       FOR_RESPCAD,'                   ||
                     '       FOR_HOMOLOGADO,'                ||
                     '       FOR_QTDDEP,'                    ||
                     '       FOR_INSCINSS,'                  ||
                     '       FOR_CLASSEINSS,'                ||
                     '       FOR_TETOMAX,'                   ||
                     '       FOR_EMAIL,'                     ||
                     '       FOR_INSCMUNIP,'                 ||
                     '       FOR_INSCSUFRAMA,'               ||
                     '       FOR_SALBASE,'                   ||
                     '       FOR_PISPASEP,'                  ||
                     '       FOR_SQCBO,'                     ||
                     '       FOR_CATTRAB,'                   ||
                     '       FOR_COOPERATIVA,'               ||
                     '       FOR_NAC,'                       ||
                     '       FOR_ESTADOCIVIL,'               ||
                     '       FOR_CDPAIS,'                    ||
                     '       FOR_GRPEMPRESARIAL,'            ||
                     '       FOR_VBPRURAL,'                  ||
                     '       FOR_TPINDIEDEST,'               ||
                     '       FOR_VBENVIARINFORMEREND)'       ||
                     'VALUES'                                ||
                     '      (''' || PFOR_CODIGO              || ''',''' ||
                                    PFOR_NOME                || ''',''' ||
                                    PFOR_ENDERECO            || ''',''' ||
                                    PFOR_NUMENDERECO         || ''',''' ||
                                    PFOR_COMPENDERECO        || ''',''' ||
                                    PFOR_TIPESSOA            || ''',''' ||
                                    PFOR_BAIRRO              || ''',''' ||
                                    PFOR_CIDADE              || ''',''' ||
                                    PFOR_UF                  || ''',''' ||
                                    PFOR_PAIS                || ''',''' ||
                                    PFOR_CEP                 || ''',''' ||
                                    PFOR_TEL                 || ''',''' ||
                                    PFOR_FAX                 || ''',''' ||
                                    PFOR_CGC                 || ''',''' ||
                                    PFOR_INSCRICAO           || ''',''' ||
                                    PFOR_ENDERECO1           || ''',''' ||
                                    PFOR_DTMOV               || ''',''' ||
                                    PFOR_DTCAD               || ''',''' ||
                                    PFOR_DTNASC              || ''',''' ||
                                    PFOR_CODBAIRRO           || ''',''' ||
                                    PFOR_NOMEFANT            || ''',''' ||
                                    PFOR_RESPCAD             ||
                                    ''', :PNAO  ,'''         ||
                                    PFOR_QTDDEP              || ''',''' ||
                                    PFOR_INSCINSS            || ''',''' ||
                                    PFOR_CLASSEINSS          || ''',''' ||
                                    PFOR_TETOMAX             || ''',''' ||
                                    PFOR_EMAIL               || ''',''' ||
                                    PFOR_INSCMUNIP           || ''',''' ||
                                    PFOR_INSCSUFRAMA         ||
                                    ''', :PFOR_SALBASE,'''   ||
                                    PFOR_PISPASEP            || ''',''' ||
                                    PFOR_SQCBO               || ''',''' ||
                                    PFOR_CATTRAB             || ''',''' ||
                                    PFOR_COOPERATIVA         || ''',''' ||
                                    PFOR_NAC                 || ''',''' ||
                                    PFOR_ESTADOCIVIL         || ''',''' ||
                                    PFOR_CDPAIS              || ''',''' ||
                                    PFOR_GRPEMPRESARIAL      || ''',''' ||
                                    PFOR_VBPRURAL            || ''',''' ||
                                    PFOR_TPINDIEDEST         || ''',''' ||
                                    PFOR_VBENVIARINFORMEREND || ''')',
                     nCursor);
      dbms_sql.bind_variable(nCursor, 'PNAO'          , 'N');
      dbms_sql.bind_variable(nCursor, 'PFOR_SALBASE'  , PFOR_SALBASE);
      nRows       := dbms_sql.EXECUTE(nCursor);
      nPAR_DBLMXM := nPAR_DBLMXM - 1;
    END LOOP;
    dbms_sql.close_cursor(nCursor);
  END IF;
  CLOSE PARAMS;
END;
/

CREATE OR REPLACE PROCEDURE ALTFORNEC_FOR
 (PFOR_CODIGO              IN CHAR,
  PFOR_NOME                IN CHAR,
  PFOR_ENDERECO            IN CHAR,
  PFOR_NUMENDERECO         IN CHAR DEFAULT NULL,
  PFOR_COMPENDERECO        IN CHAR DEFAULT NULL,
  PFOR_TIPESSOA            IN CHAR,
  PFOR_BAIRRO              IN CHAR,
  PFOR_CIDADE              IN CHAR,
  PFOR_UF                  IN CHAR,
  PFOR_PAIS                IN CHAR,
  PFOR_CEP                 IN CHAR,
  PFOR_TEL                 IN CHAR,
  PFOR_FAX                 IN CHAR,
  PFOR_CGC                 IN CHAR,
  PFOR_INSCRICAO           IN CHAR,
  PFOR_ENDERECO1           IN CHAR,
  PFOR_DTMOV               IN CHAR,
  PFOR_DTNASC              IN CHAR,
  PFOR_CODBAIRRO           IN CHAR,
  PFOR_NOMEFANT            IN CHAR,
  PFOR_QTDDEP              IN NUMBER,
  PFOR_INSCINSS            IN CHAR,
  PFOR_CLASSEINSS          IN CHAR,
  PFOR_TETOMAX             IN CHAR,
  PFOR_EMAIL               IN CHAR,
  PFOR_INSCMUNIP           IN CHAR,
  PFOR_INSCSUFRAMA         IN CHAR DEFAULT NULL,
  PFOR_SALBASE             IN NUMBER default 0,
  PFOR_PISPASEP            IN CHAR DEFAULT NULL,
  PFOR_SQCBO               IN CHAR DEFAULT NULL,
  PFOR_CATTRAB             IN CHAR DEFAULT NULL,
  PFOR_COOPERATIVA         IN CHAR DEFAULT 'N',
  PFOR_NAC                 IN CHAR,
  PFOR_ESTADOCIVIL         IN CHAR,
  PFOR_GRPEMPRESARIAL      IN CHAR DEFAULT NULL,
  PFOR_DTINATIV            IN DATE DEFAULT SYSDATE,
  PFOR_USUARIOMOV          IN CHAR DEFAULT USER,
  PFOR_RESPCAD             IN CHAR DEFAULT USER,
  PFOR_CDPAIS              IN CHAR DEFAULT NULL,
  PFOR_VBPRURAL            IN CHAR DEFAULT 'N',
  PFOR_TPINDIEDEST         IN CHAR DEFAULT NULL,
  PFOR_VBENVIARINFORMEREND IN CHAR DEFAULT 'N')
AS
  nRows        INTEGER;
  PNAO         CHAR;
  nCursor      INTEGER;
  nPAR_DBLMXM  INTEGER;
  CURSOR PARAMS IS
    SELECT TO_NUMBER(NVL(PAR_VLPARAM,0))
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = 'wPAR_DBLMXM';
BEGIN
  UPDATE FORNEC_FOR SET
    FOR_NOME                = PFOR_NOME,
    FOR_ENDERECO            = PFOR_ENDERECO,
    FOR_NUMENDERECO         = PFOR_NUMENDERECO,
    FOR_COMPENDERECO        = PFOR_COMPENDERECO,
    FOR_TIPESSOA            = PFOR_TIPESSOA,
    FOR_BAIRRO              = PFOR_BAIRRO,
    FOR_CIDADE              = PFOR_CIDADE,
    FOR_UF                  = PFOR_UF,
    FOR_PAIS                = PFOR_PAIS,
    FOR_CEP                 = PFOR_CEP,
    FOR_TEL                 = PFOR_TEL,
    FOR_FAX                 = PFOR_FAX,
    FOR_CGC                 = PFOR_CGC,
    FOR_INSCRICAO           = PFOR_INSCRICAO,
    FOR_ENDERECO1           = PFOR_ENDERECO1,
    FOR_DTMOV               = PFOR_DTMOV,
    FOR_DTNASC              = PFOR_DTNASC,
    FOR_CODBAIRRO           = PFOR_CODBAIRRO,
    FOR_NOMEFANT            = PFOR_NOMEFANT,
    FOR_USUARIOMOV          = USER,
    FOR_DTINATIV            = SYSDATE,
    FOR_HOMOLOGADO          = 'N',
    FOR_RESPHOMOLOG         = '',
    FOR_DTHOMOLOG           = '',
    FOR_QTDDEP              = PFOR_QTDDEP,
    FOR_INSCINSS            = PFOR_INSCINSS,
    FOR_CLASSEINSS          = PFOR_CLASSEINSS,
    FOR_TETOMAX             = PFOR_TETOMAX,
    FOR_EMAIL               = PFOR_EMAIL,
    FOR_INSCMUNIP           = PFOR_INSCMUNIP,
    FOR_INSCSUFRAMA         = PFOR_INSCSUFRAMA,
    FOR_EXP                 = NULL,
    FOR_SALBASE             = PFOR_SALBASE,
    FOR_PISPASEP            = PFOR_PISPASEP,
    FOR_SQCBO               = PFOR_SQCBO,
    FOR_CATTRAB             = PFOR_CATTRAB,
    FOR_COOPERATIVA         = PFOR_COOPERATIVA,
    FOR_NAC                 = PFOR_NAC,
    FOR_ESTADOCIVIL         = PFOR_ESTADOCIVIL,
    FOR_GRPEMPRESARIAL      = PFOR_GRPEMPRESARIAL,
    FOR_CDPAIS              = PFOR_CDPAIS,
    FOR_VBPRURAL            = PFOR_VBPRURAL,
    FOR_TPINDIEDEST         = PFOR_TPINDIEDEST,
    FOR_VBENVIARINFORMEREND = PFOR_VBENVIARINFORMEREND
  WHERE FOR_CODIGO     = PFOR_CODIGO;
  -- processamentos dos links --
  PNAO := 'N';
  OPEN  PARAMS;
  FETCH PARAMS INTO nPAR_DBLMXM;
  IF PARAMS%FOUND THEN
    nCursor := dbms_sql.open_cursor;
    WHILE nPAR_DBLMXM > 0 LOOP
      DBMS_SQL.PARSE(nCursor,
                     'UPDATE FORNEC_FOR@DBLMXM'            || TO_CHAR(nPAR_DBLMXM)     ||
                     '   SET FOR_NOME                = ''' || PFOR_NOME                || ''',' ||
                     '       FOR_ENDERECO            = ''' || PFOR_ENDERECO            || ''',' ||
                     '       FOR_NUMENDERECO         = ''' || PFOR_NUMENDERECO         || ''',' ||
                     '       FOR_COMPENDERECO        = ''' || PFOR_COMPENDERECO        || ''',' ||
                     '       FOR_TIPESSOA            = ''' || PFOR_TIPESSOA            || ''',' ||
                     '       FOR_BAIRRO              = ''' || PFOR_BAIRRO              || ''',' ||
                     '       FOR_CIDADE              = ''' || PFOR_CIDADE              || ''',' ||
                     '       FOR_UF                  = ''' || PFOR_UF                  || ''',' ||
                     '       FOR_PAIS                = ''' || PFOR_PAIS                || ''',' ||
                     '       FOR_CEP                 = ''' || PFOR_CEP                 || ''',' ||
                     '       FOR_TEL                 = ''' || PFOR_TEL                 || ''',' ||
                     '       FOR_FAX                 = ''' || PFOR_FAX                 || ''',' ||
                     '       FOR_CGC                 = ''' || PFOR_CGC                 || ''',' ||
                     '       FOR_INSCRICAO           = ''' || PFOR_INSCRICAO           || ''',' ||
                     '       FOR_ENDERECO1           = ''' || PFOR_ENDERECO1           || ''',' ||
                     '       FOR_DTMOV               = ''' || PFOR_DTMOV               || ''',' ||
                     '       FOR_DTNASC              = ''' || PFOR_DTNASC              || ''',' ||
                     '       FOR_CODBAIRRO           = ''' || PFOR_CODBAIRRO           || ''',' ||
                     '       FOR_NOMEFANT            = ''' || PFOR_NOMEFANT            || ''',' ||
                     '       FOR_USUARIOMOV          = ''' || USER                     || ''',' ||
                     '       FOR_DTINATIV            = ''' || SYSDATE                  || ''',' ||
                     '       FOR_HOMOLOGADO          = :PNAO, '                        ||
                     '       FOR_RESPHOMOLOG         = ''' || NULL                     || ''',' ||
                     '       FOR_DTHOMOLOG           = ''' || NULL                     || ''',' ||
                     '       FOR_QTDDEP              = ''' || PFOR_QTDDEP              || ''',' ||
                     '       FOR_INSCINSS            = ''' || PFOR_INSCINSS            || ''',' ||
                     '       FOR_CLASSEINSS          = ''' || PFOR_CLASSEINSS          || ''',' ||
                     '       FOR_TETOMAX             = ''' || PFOR_TETOMAX             || ''',' ||
                     '       FOR_EMAIL               = ''' || PFOR_EMAIL               || ''',' ||
                     '       FOR_INSCMUNIP           = ''' || PFOR_INSCMUNIP           || ''',' ||
                     '       FOR_INSCSUFRAMA         = ''' || PFOR_INSCSUFRAMA         || ''',' ||
                     '       FOR_EXP                 = ''' || NULL                     || ''',' ||
                     '       FOR_SALBASE             = :PFOR_SALBASE, '                ||
                     '       FOR_PISPASEP            = ''' || PFOR_PISPASEP            || ''',' ||
                     '       FOR_SQCBO               = ''' || PFOR_SQCBO               || ''',' ||
                     '       FOR_CATTRAB             = ''' || PFOR_CATTRAB             || ''',' ||
                     '       FOR_COOPERATIVA         = ''' || PFOR_COOPERATIVA         || ''',' ||
                     '       FOR_NAC                 = ''' || PFOR_NAC                 || ''',' ||
                     '       FOR_ESTADOCIVIL         = ''' || PFOR_ESTADOCIVIL         || ''',' ||
                     '       FOR_GRPEMPRESARIAL      = ''' || PFOR_GRPEMPRESARIAL      || ''',' ||
                     '       FOR_CDPAIS              = ''' || PFOR_CDPAIS              || ''',' ||
                     '       FOR_VBPRURAL            = ''' || PFOR_VBPRURAL            || ''',' ||
                     '       FOR_TPINDIEDEST         = ''' || PFOR_TPINDIEDEST         || ''',' ||
                     '       FOR_VBENVIARINFORMEREND = ''' || PFOR_VBENVIARINFORMEREND || ''' ' ||
                     ' WHERE FOR_CODIGO              = ''' || PFOR_CODIGO              || '''',
                     nCursor);
      dbms_sql.bind_variable(nCursor, 'PNAO'           , PNAO);
      dbms_sql.bind_variable(nCursor, 'PFOR_SALBASE'   , PFOR_SALBASE);
      nRows       := dbms_sql.execute(nCursor);
      nPAR_DBLMXM := nPAR_DBLMXM - 1;
    END LOOP;
    dbms_sql.close_cursor(nCursor);
  END IF;
  CLOSE PARAMS;
END;
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_BASECALCIRRF  VARCHAR2(23 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_BASECALCINSS  VARCHAR2(23 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_BASECALCISS  VARCHAR2(23 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_BASECALCPIS  VARCHAR2(23 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_BASECALCCOFINS  VARCHAR2(23 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_BASECALCCSOCIAL  VARCHAR2(23 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_BASECALCINSSI  VARCHAR2(23 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_BASECALCSEST  VARCHAR2(23 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_CDREDEXTDIRF  VARCHAR2(3 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_CDTRIBEXTDIRF  VARCHAR2(2 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_CDARRECADSRF  VARCHAR2(7 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_NRFATCADOBRA  VARCHAR2(15 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_CDFORPRINCIPAL  VARCHAR2(15 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_NRTITULOPRINCIPAL  VARCHAR2(20 BYTE))
/

ALTER TABLE TI_PAGARRECEBER_TCPR ADD (TCPR_TPRELACAO  VARCHAR2(50 BYTE))
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_BASECALCIRRF IS 'Valor Base do IRRF'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_BASECALCINSS IS 'Valor Base do INSS'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_BASECALCISS IS 'Valor Base do ISS'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_BASECALCPIS IS 'Valor Base do PIS'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_BASECALCCOFINS IS 'Valor Base do COFINS'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_BASECALCCSOCIAL IS 'Valor Base do CSOCIAL'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_BASECALCINSSI IS 'Valor Base do INSSI'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_BASECALCSEST IS 'Valor Base do CEST'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_CDREDEXTDIRF IS 'C�digo do Tipo de Rendimento - DIRF'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_CDTRIBEXTDIRF IS 'C�digo da Forma de Tributa��o - DIRF'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_CDARRECADSRF IS 'C�digo SRF de arrecada��o do imposto'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_NRFATCADOBRA IS 'C�digo da Obra'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_CDFORPRINCIPAL IS 'C�digo do fornecedor principal'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_NRTITULOPRINCIPAL IS 'N�mero do t�tulo principal'
/

COMMENT ON COLUMN TI_PAGARRECEBER_TCPR.TCPR_TPRELACAO IS 'Tipo de rela��o do t�tulo'
/

CREATE OR REPLACE PROCEDURE INSTI_PAGARRECEBER_TCPR (
    PTCPR_SQPROCESSO        IN NUMBER,
    PTCPR_SQREGISTRO        IN NUMBER,
    PTCPR_STOPERACAO        IN NUMBER,
    PTCPR_IDENTIFICACAO     IN CHAR,
    PTCPR_CDCLIFOR          IN CHAR,
    PTCPR_NUTITULO          IN CHAR,
    PTCPR_DOCFISCAL         IN CHAR,
    PTCPR_EMPEMI            IN CHAR,
    PTCPR_EMPREC            IN CHAR,
    PTCPR_TPTITULO          IN CHAR,
    PTCPR_DTEMISSAO         IN CHAR,
    PTCPR_DTVENCIMENTO      IN CHAR,
    PTCPR_DTPROGRAMACAO     IN CHAR,
    PTCPR_CDMOEDA           IN CHAR,
    PTCPR_VLRTITULO         IN CHAR,
    PTCPR_TPCOBRANCA        IN CHAR,
    PTCPR_BANCO             IN CHAR,
    PTCPR_AGENCIA           IN CHAR,
    PTCPR_PORTADOR          IN CHAR,
    PTCPR_OBS               IN CHAR,
    PTCPR_CCUSTOGER         IN CHAR,
    PTCPR_GRREC             IN CHAR,
    PTCPR_CCCONTABIL        IN CHAR,
    PTCPR_VLMULTA           IN CHAR,
    PTCPR_VLDESCONTO        IN CHAR,
    PTCPR_DTDESCONTO        IN CHAR,
    PTCPR_VLBONIFIC         IN CHAR,
    PTCPR_VLPERMAN          IN CHAR,
    PTCPR_VLANTECIPADO      IN CHAR,
    PTCPR_CDIRRF            IN CHAR,
    PTCPR_VLIRRF            IN CHAR,
    PTCPR_CDINSS            IN CHAR,
    PTCPR_VLINSS            IN CHAR,
    PTCPR_CDISS             IN CHAR,
    PTCPR_VLISS             IN CHAR,
    PTCPR_PEDIDO            IN CHAR,
    PTCPR_CTAPAGAMENTO      IN CHAR,
    PTCPR_DOCPAGAMENTO      IN CHAR,
    PTCPR_DTPAGAMENTO       IN CHAR,
    PTCPR_VLPAGO            IN CHAR,
    PTCPR_BXMOEDA           IN CHAR,
    PTCPR_ENDCOBRANCA       IN CHAR,
    PTCPR_COMISSAO          IN CHAR,
    PTCPR_PERCCOMISSAO      IN CHAR,
    PTCPR_TPCOMISSAO        IN CHAR,
    PTCPR_CDREPRESENTANTE   IN CHAR,
    PTCPR_CONDPAGTO         IN CHAR,
    PTCPR_LOTE              IN CHAR,
    PTCPR_CDPIS             IN CHAR,
    PTCPR_VLPIS             IN CHAR,
    PTCPR_CDCOFINS          IN CHAR,
    PTCPR_VLCOFINS          IN CHAR,
    PTCPR_VLCSOC            IN CHAR,
    PTCPR_CDPROJETO         IN CHAR,
    PTCPR_DTENTRADA         IN CHAR,
    PTCPR_FORMPAGTO         IN CHAR,
    PTCPR_CDINSSI           IN CHAR,
    PTCPR_INSSIDED          IN CHAR,
    PTCPR_INSSI             IN CHAR,
    PTCPR_FILIAL            IN CHAR,
    PTCPR_CDCSOC            IN CHAR,
    PTCPR_VLRCOTACAOPR      IN CHAR,
    PTCPR_VLRCOTACAOBX      IN CHAR,
    PTCPR_CDACRDEC          IN CHAR,
    PTCPR_VLACRDEC          IN CHAR,
    PTCPR_DATACREDITO       IN CHAR,
    PTCPR_TPBAIXA           IN CHAR,
    PTCPR_NOCHEQUE          IN CHAR,
    PTCPR_CHQNOMI           IN CHAR,
    PTCPR_NOMINAL           IN CHAR,
    PTCPR_BXCHQ             IN CHAR,
    PTCPR_CDCONTADOC        IN CHAR DEFAULT NULL,
    PTCPR_PARCELAS          IN CHAR DEFAULT NULL,
    PTCPR_DTBASE            IN CHAR DEFAULT NULL,
    PTCPR_VLTITCACHMONITOR  IN CHAR DEFAULT NULL,
    PTCPR_DTCOMPETENCIA     IN CHAR DEFAULT NULL,
    PTCPR_BASECALCIRRF      IN CHAR DEFAULT NULL,
    PTCPR_BASECALCINSS      IN CHAR DEFAULT NULL,
    PTCPR_BASECALCISS       IN CHAR DEFAULT NULL,
    PTCPR_BASECALCPIS       IN CHAR DEFAULT NULL,
    PTCPR_BASECALCCOFINS    IN CHAR DEFAULT NULL,
    PTCPR_BASECALCCSOCIAL   IN CHAR DEFAULT NULL,
    PTCPR_BASECALCINSSI     IN CHAR DEFAULT NULL,
    PTCPR_BASECALCSEST      IN CHAR DEFAULT NULL,
    PTCPR_CDREDEXTDIRF      IN CHAR DEFAULT NULL,
    PTCPR_CDTRIBEXTDIRF     IN CHAR DEFAULT NULL,
    PTCPR_CDARRECADSRF      IN CHAR DEFAULT NULL,
    PTCPR_NRFATCADOBRA      IN CHAR DEFAULT NULL,
    PTCPR_CDFORPRINCIPAL    IN CHAR DEFAULT NULL,
    PTCPR_NRTITULOPRINCIPAL IN CHAR DEFAULT NULL,
    PTCPR_TPRELACAO         IN CHAR DEFAULT NULL
    )
AS
  BEGIN
    INSERT INTO TI_PAGARRECEBER_TCPR(
    TCPR_SQPROCESSO,
    TCPR_SQREGISTRO,
    TCPR_STOPERACAO,
    TCPR_IDENTIFICACAO,
    TCPR_CDCLIFOR,
    TCPR_NUTITULO,
    TCPR_DOCFISCAL,
    TCPR_EMPEMI,
    TCPR_EMPREC,
    TCPR_TPTITULO,
    TCPR_DTEMISSAO,
    TCPR_DTVENCIMENTO,
    TCPR_DTPROGRAMACAO,
    TCPR_CDMOEDA,
    TCPR_VLRTITULO,
    TCPR_TPCOBRANCA,
    TCPR_BANCO,
    TCPR_AGENCIA,
    TCPR_PORTADOR,
    TCPR_OBS,
    TCPR_CCUSTOGER,
    TCPR_GRREC,
    TCPR_CCCONTABIL,
    TCPR_VLMULTA,
    TCPR_VLDESCONTO,
    TCPR_DTDESCONTO,
    TCPR_VLBONIFIC,
    TCPR_VLPERMAN,
    TCPR_VLANTECIPADO,
    TCPR_CDIRRF,
    TCPR_VLIRRF,
    TCPR_CDINSS,
    TCPR_VLINSS,
    TCPR_CDISS,
    TCPR_VLISS,
    TCPR_PEDIDO,
    TCPR_CTAPAGAMENTO,
    TCPR_DOCPAGAMENTO,
    TCPR_DTPAGAMENTO,
    TCPR_VLPAGO,
    TCPR_BXMOEDA,
    TCPR_ENDCOBRANCA,
    TCPR_COMISSAO,
    TCPR_PERCCOMISSAO,
    TCPR_TPCOMISSAO,
    TCPR_CDREPRESENTANTE,
    TCPR_CONDPAGTO,
    TCPR_LOTE,
    TCPR_CDPIS,
    TCPR_VLPIS,
    TCPR_CDCOFINS,
    TCPR_VLCOFINS,
    TCPR_VLCSOC,
    TCPR_CDPROJETO,
    TCPR_DTENTRADA,
    TCPR_FORMPAGTO,
    TCPR_CDINSSI,
    TCPR_INSSIDED,
    TCPR_INSSI,
    TCPR_FILIAL,
    TCPR_CDCSOC,
    TCPR_VLRCOTACAOPR,
    TCPR_VLRCOTACAOBX,
    TCPR_CDACRDEC,
    TCPR_VLACRDEC,
    TCPR_DATACREDITO,
    TCPR_TPBAIXA,
    TCPR_NOCHEQUE,
    TCPR_CHQNOMI,
    TCPR_NOMINAL,
    TCPR_BXCHQ,
    TCPR_CDCONTADOC,
    TCPR_PARCELAS,
    TCPR_DTBASE,
    TCPR_VLTITCACHMONITOR,
    TCPR_DTCOMPETENCIA,
    TCPR_BASECALCIRRF,
    TCPR_BASECALCINSS,
    TCPR_BASECALCISS,
    TCPR_BASECALCPIS,
    TCPR_BASECALCCOFINS,
    TCPR_BASECALCCSOCIAL,
    TCPR_BASECALCINSSI,
    TCPR_BASECALCSEST,
    TCPR_CDREDEXTDIRF,
    TCPR_CDTRIBEXTDIRF,
    TCPR_CDARRECADSRF,
    TCPR_NRFATCADOBRA,
    TCPR_CDFORPRINCIPAL,   
    TCPR_NRTITULOPRINCIPAL,
    TCPR_TPRELACAO       
    )
      VALUES(
        PTCPR_SQPROCESSO,
        PTCPR_SQREGISTRO,
        PTCPR_STOPERACAO,
        PTCPR_IDENTIFICACAO,
        PTCPR_CDCLIFOR,
        PTCPR_NUTITULO,
        PTCPR_DOCFISCAL,
        PTCPR_EMPEMI,
        PTCPR_EMPREC,
        PTCPR_TPTITULO,
        PTCPR_DTEMISSAO,
        PTCPR_DTVENCIMENTO,
        PTCPR_DTPROGRAMACAO,
        PTCPR_CDMOEDA,
        PTCPR_VLRTITULO,
        PTCPR_TPCOBRANCA,
        PTCPR_BANCO,
        PTCPR_AGENCIA,
        PTCPR_PORTADOR,
        PTCPR_OBS,
        PTCPR_CCUSTOGER,
        PTCPR_GRREC,
        PTCPR_CCCONTABIL,
        PTCPR_VLMULTA,
        PTCPR_VLDESCONTO,
        PTCPR_DTDESCONTO,
        PTCPR_VLBONIFIC,
        PTCPR_VLPERMAN,
        PTCPR_VLANTECIPADO,
        PTCPR_CDIRRF,
        PTCPR_VLIRRF,
        PTCPR_CDINSS,
        PTCPR_VLINSS,
        PTCPR_CDISS,
        PTCPR_VLISS,
        PTCPR_PEDIDO,
        PTCPR_CTAPAGAMENTO,
        PTCPR_DOCPAGAMENTO,
        PTCPR_DTPAGAMENTO,
        PTCPR_VLPAGO,
        PTCPR_BXMOEDA,
        PTCPR_ENDCOBRANCA,
        PTCPR_COMISSAO,
        PTCPR_PERCCOMISSAO,
        PTCPR_TPCOMISSAO,
        PTCPR_CDREPRESENTANTE,
        PTCPR_CONDPAGTO,
        PTCPR_LOTE,
        PTCPR_CDPIS,
        PTCPR_VLPIS,
        PTCPR_CDCOFINS,
        PTCPR_VLCOFINS,
        PTCPR_VLCSOC,
        PTCPR_CDPROJETO,
        PTCPR_DTENTRADA,
        PTCPR_FORMPAGTO,
        PTCPR_CDINSSI,
        PTCPR_INSSIDED,
        PTCPR_INSSI,
        PTCPR_FILIAL,
        PTCPR_CDCSOC,
        PTCPR_VLRCOTACAOPR,
        PTCPR_VLRCOTACAOBX,
        PTCPR_CDACRDEC,
        PTCPR_VLACRDEC,
        PTCPR_DATACREDITO,
        PTCPR_TPBAIXA,
        PTCPR_NOCHEQUE,
        PTCPR_CHQNOMI,
        PTCPR_NOMINAL,
        PTCPR_BXCHQ,
        PTCPR_CDCONTADOC,
        PTCPR_PARCELAS,
        PTCPR_DTBASE,
        PTCPR_VLTITCACHMONITOR,
        PTCPR_DTCOMPETENCIA,
        PTCPR_BASECALCIRRF,
        PTCPR_BASECALCINSS,
        PTCPR_BASECALCISS,
        PTCPR_BASECALCPIS,
        PTCPR_BASECALCCOFINS,
        PTCPR_BASECALCCSOCIAL,
        PTCPR_BASECALCINSSI,
        PTCPR_BASECALCSEST,
        PTCPR_CDREDEXTDIRF,
        PTCPR_CDTRIBEXTDIRF,
        PTCPR_CDARRECADSRF,
        PTCPR_NRFATCADOBRA,
        PTCPR_CDFORPRINCIPAL,   
        PTCPR_NRTITULOPRINCIPAL,
        PTCPR_TPRELACAO                
        );
  END;
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TCP_BASECALCIRRF',    68, 'Valor Base do IRRF', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TCP_BASECALCINSS',    69, 'Valor Base do INSS', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TCP_BASECALCISS',     70, 'Valor Base do ISS', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TCP_BASECALCPIS',     71, 'Valor Base do PIS', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TCP_BASECALCCOFINS',  72, 'Valor Base do COFINS', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TCP_BASECALCCSOCIAL', 73, 'Valor Base do CSOCIAL', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TCP_BASECALCINSSI',   74, 'Valor Base do INSSI', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TCP_BASECALCSEST',    75, 'Valor Base do CSEST', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TCPEX_CDREDEXTDIRF',  76, 'C�digo do Tipo de Rendimento',         'C',  3, 0, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TCPEX_CDTRIBEXTDIRF', 77, 'C�digo da Forma de Tributacao - DIRF', 'C',  2, 0, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TCP_CDARRECADSRF',    78, 'C�digo SRF de arrecada��o do imposto', 'C',  7, 0, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'RPC_NRFATCADOBRA',    79, 'C�digo da Obra',                       'C', 15, 0, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TRL_CDFORPRINCIPAL',    80, 'C�digo do fornecedor principal', 'C', 15, 0, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TRL_NRTITULOPRINCIPAL', 81, 'N�mero do t�tulo principal',     'C', 20, 0, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A PAGAR', 'TRL_TPRELACAO',         82, 'Tipo de rela��o do t�tulo',      'C', 50, 0, 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TCP_BASECALCIRRF',    'N',  859,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TCP_BASECALCINSS',    'N',  882,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TCP_BASECALCISS',     'N',  905,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TCP_BASECALCPIS',     'N',  928,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TCP_BASECALCCOFINS',  'N',  951,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TCP_BASECALCCSOCIAL', 'N',  974,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TCP_BASECALCINSSI',   'N',  997,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TCP_BASECALCSEST',   'N', 1020,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TCPEX_CDREDEXTDIRF',  'C', 1043,   3, 0, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TCPEX_CDTRIBEXTDIRF', 'C', 1046,   2, 0, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TCP_CDARRECADSRF',    'C', 1048,   7, 0, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'RPC_NRFATCADOBRA',    'C', 1055,  15, 0, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TRL_CDFORPRINCIPAL',    'C', 1070,  15, 0, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TRL_NRTITULOPRINCIPAL', 'C', 1085,  20, 0, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A PAGAR', 'TRL_TPRELACAO',         'C', 1105,  50, 0, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TCP_BASECALCIRRF',    'N',  0,  23, 2, 'BO', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TCP_BASECALCINSS',    'N',  0,  23, 2, 'BP', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TCP_BASECALCISS',     'N',  0,  23, 2, 'BQ', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TCP_BASECALCPIS',     'N',  0,  23, 2, 'BR', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TCP_BASECALCCOFINS',  'N',  0,  23, 2, 'BS', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TCP_BASECALCCSOCIAL', 'N',  0,  23, 2, 'BT', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TCP_BASECALCINSSI',   'N',  0,  23, 2, 'BU', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TCP_BASECALCSEST',   'N',  0,  23, 2, 'BV', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TCPEX_CDREDEXTDIRF',  'C',  0,  3, 0, 'BX', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TCPEX_CDTRIBEXTDIRF', 'C',  0,  2, 0, 'BY', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TCP_CDARRECADSRF',    'C',  0,  7, 0, 'BZ', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'RPC_NRFATCADOBRA',    'C',  0, 15, 0, 'CA', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TRL_CDFORPRINCIPAL',    'C',  0, 15, 0, 'CB', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TRL_NRTITULOPRINCIPAL', 'C',  0, 20, 0, 'CC', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A PAGAR', 'TRL_TPRELACAO',         'C',  0, 50, 0, 'CD', 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A RECEBER', 'TCR_BASECALCIRRF', 62, 'Valor Base do IRRF', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A RECEBER', 'TCR_BASECALCINSS', 63, 'Valor Base do INSS', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A RECEBER', 'TCR_BASECALCISS', 64, 'Valor Base do ISS', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A RECEBER', 'TCR_BASECALCPIS', 65, 'Valor Base do PIS', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A RECEBER', 'TCR_BASECALCCOFINS', 66, 'Valor Base do COFINS', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A RECEBER', 'TCR_BASECALCCSOCIAL', 67, 'Valor Base do CSOCIAL', 'N', 23, 2, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX) VALUES ('TITULOS A RECEBER', 'RRC_NRFATCADOBRA', 68, 'C�digo da Obra', 'C', 15, 0, 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A RECEBER', 'TCR_BASECALCIRRF',    'N',  722,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A RECEBER', 'TCR_BASECALCINSS',    'N',  745,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A RECEBER', 'TCR_BASECALCISS',     'N',  768,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A RECEBER', 'TCR_BASECALCPIS',     'N',  791,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A RECEBER', 'TCR_BASECALCCOFINS',  'N',  814,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A RECEBER', 'TCR_BASECALCCSOCIAL', 'N',  837,  23, 2, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('01', 'TITULOS A RECEBER', 'RRC_NRFATCADOBRA',  'C', 860,   15, 0, '', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A RECEBER', 'TCR_BASECALCIRRF',    'N',  0,  23, 2, 'BJ', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A RECEBER', 'TCR_BASECALCINSS',    'N',  0,  23, 2, 'BK', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A RECEBER', 'TCR_BASECALCISS',     'N',  0,  23, 2, 'BL', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A RECEBER', 'TCR_BASECALCPIS',     'N',  0,  23, 2, 'BM', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A RECEBER', 'TCR_BASECALCCOFINS',  'N',  0,  23, 2, 'BN', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A RECEBER', 'TCR_BASECALCCSOCIAL', 'N',  0,  23, 2, 'BO', 0)
/

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_COLUNA, LYC_INDEX) VALUES ('XL', 'TITULOS A RECEBER', 'RRC_NRFATCADOBRA',  'C',  0, 15, 0, 'BP', 0)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 288909
PROMPT ======================================================================