PROMPT ======================================================================
PROMPT == DEMANDA......: 289205
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: LUANA MARIA DE SOUZA
PROMPT == DATA.........: 10/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
VALUES (
   (SELECT MAX(cdr_idcampo)+1 FROM GRECAMPOS_CDR),
   (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'TITCR_TCR'),
   '(SELECT CONTA_CTA.CTA_DESCRICAO FROM CONTA_CTA WHERE CONTA_CTA.CTA_CODIGO = TCR_CTAPAGAME)',
   'Cta. Recebimento - Descri��o',
   0,
   'Cta.Rec. Desc.')
/

UPDATE GRECAMPOS_CDR
      SET CDR_DSCAMPO = 'Conta de Recebimento'
           , CDR_DSCAMPOTABELACABECALHO = 'Cta. Recebimento'
 WHERE CDR_DSCAMPOTABELA = 'TITCR_TCR.TCR_CTAPAGAME'
      AND CDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'TITCR_TCR')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 289205
PROMPT ======================================================================