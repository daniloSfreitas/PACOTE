PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.5_002 gerados em 07/03/2018 
PROMPT ============================================================= 

@@001_20180307_MXMDS913_SIPADRAO_287944.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.5_002');

COMMIT;
