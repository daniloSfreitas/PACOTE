PROMPT ======================================================================
PROMPT == DEMANDA......: 288895
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: MAXUEL RIBEIRO SANTANA
PROMPT == DATA.........: 19/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

insert into EFDSPEDCODATIVSCP_CAS (CAS_IDATIVIDADE, CAS_CDATIVIDADE, CAS_DSATIVIDADE, CAS_DSATIVRESUMIDA, CAS_CDNCM, CAS_NRALIQUOTA, CAS_CDINCIDENCIA, CAS_DTINICIOESCR, CAS_DTFIMESCR, CAS_DTINCLUSAO, CAS_DTALTERACAO, CAS_USINCLUSAO, CAS_USALTERACAO, CAS_VBSERVICO)
values (SEQ1_EFDSPEDCODATIVSCP_CAS.NEXTVAL, 'CPRB_NA', 'C�digo Interno MXM, determina que n�o houve classifica��o da CPRB por atividade espec�fica.', 'C�digo Interno MXM, determina que n�o houve classifica��o da CPRB por atividade espec�fica.', '', 0.00, '', to_date('01-01-2017', 'dd-mm-yyyy'), null, to_date('19-03-2018 18:00:00', 'dd-mm-yyyy hh24:mi:ss'), null, 'GERAL', 'GERAL', 'N')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 288895
PROMPT ======================================================================