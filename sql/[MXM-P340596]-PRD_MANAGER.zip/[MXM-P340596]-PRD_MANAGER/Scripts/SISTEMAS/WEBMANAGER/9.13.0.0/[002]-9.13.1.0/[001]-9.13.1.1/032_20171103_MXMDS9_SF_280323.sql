PROMPT ======================================================================
PROMPT == DEMANDA......: 280323
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: ALINE MELLO PORTO
PROMPT == DATA.........: 01/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE PRDLOTESERIE_PLS
SET PLS_DTVALIDADEINTERNA = NULL
WHERE PLS_DTVALIDADEINTERNA = '01/01/0001'
/

UPDATE PRDLOTESERIE_PLS
SET PLS_DTVALIDADE = NULL
WHERE PLS_DTVALIDADE = '01/01/0001'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280323
PROMPT ======================================================================