PROMPT ======================================================================
PROMPT == DEMANDA......: 287211
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: Eduardo Lopes de Oliveira
PROMPT == DATA.........: 09/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO ERROMSG_ERM(ERM_CDERRO,ERM_DSERRO) VALUES ('IPLS0001', 'Quantidade liberada maior que quantidade pedida.')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287211
PROMPT ======================================================================