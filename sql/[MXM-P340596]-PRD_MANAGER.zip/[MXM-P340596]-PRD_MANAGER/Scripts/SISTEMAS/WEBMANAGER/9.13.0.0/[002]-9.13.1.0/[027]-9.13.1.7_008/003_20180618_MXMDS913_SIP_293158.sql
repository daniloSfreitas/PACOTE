PROMPT ======================================================================
PROMPT == DEMANDA......: 293158
PROMPT == SISTEMA......: Vendas
PROMPT == RESPONSAVEL..: LEONARDO OLIVEIRA GOMES
PROMPT == DATA.........: 18/06/2018
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE ERROMSG_ERM
   SET ERM_DSERRO = 'Clientes estrangeiros s� podem ser utilizados na rotina de informa��o de pedidos para exporta��o'
 WHERE ERM_CDERRO = 'PDV0108'
/

UPDATE ERROMSG_ERM
   SET ERM_DSERRO = 'C�digo de erro Clientes que n�o s�o estrangeiros s� podem ser utilizados na rotina de informa��o de pedidos'
 WHERE ERM_CDERRO = 'PDV0109'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 293158
PROMPT ======================================================================