PROMPT ======================================================================
PROMPT == DEMANDA......: 270085
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: JOSE BARBOSA DA SILVA JUNIOR
PROMPT == DATA.........: 16/01/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE PRODUTO_PRD MODIFY PRD_IDINTERNO VARCHAR2(14)
/

ALTER TABLE PRODUTO_PRD ADD PRD_VBFABRESCNAORELEV CHAR(1)
/

ALTER TABLE PRODUTO_PRD ADD PRD_VBRASTREABILIDADENFE CHAR(1)
/

COMMENT ON COLUMN PRODUTO_PRD.PRD_VBRASTREABILIDADENFE IS 'Flag para preenchimento de rastreabilidade de produtos na NF-e'
/

COMMENT ON COLUMN PRODUTO_PRD.PRD_VBFABRESCNAORELEV IS 'Fabrica��o em escala n�o relevante (referente ao fabricante do produto)'
/

CREATE OR REPLACE PROCEDURE INSPRODUTO_PRD
(
  PPRD_ITEM                  IN CHAR,
  PPRD_DESCRICAO             IN CHAR,
  PPRD_DESCRICAO2            IN CHAR,
  PPRD_PN                    IN CHAR,
  PPRD_ITEMSUBST             IN CHAR,
  PPRD_TPPROD                IN CHAR,
  PPRD_GRUPO                 IN CHAR,
  PPRD_CLFISCAL              IN CHAR,
  PPRD_UNIDCTRL              IN CHAR,
  PPRD_CST                   IN CHAR,
  PPRD_GRCOTAC               IN CHAR,
  PPRD_CLASSE                IN CHAR,
  PPRD_INSPEC                IN CHAR,
  PPRD_FINANC                IN CHAR,
  PPRD_LIBERADO              IN CHAR,
  PPRD_LOCAL                 IN CHAR,
  PPRD_DESTINA               IN CHAR,
  PPRD_OBS                   IN CHAR,
  PPRD_MINIMO                IN NUMBER,
  PPRD_MAXIMO                IN NUMBER,
  PPRD_PONTORES              IN NUMBER,
  PPRD_DIASUPRI              IN NUMBER,
  PPRD_VENDAMIN              IN NUMBER,
  PPRD_SOBINVENTARIO         IN CHAR,
  PPRD_DTINVENTARIO          IN DATE,
  PPRD_PESOLIQUI             IN NUMBER,
  PPRD_UNEGOCIO              IN CHAR,
  PPRD_PERCICMS              IN NUMBER,
  PPRD_PERCICMSSUB           IN NUMBER,
  PPRD_PERCIPI               IN NUMBER,
  PPRD_PERCISS               IN NUMBER,
  PPRD_PRODSERV              IN CHAR,
  PPRD_AGRUPA                IN CHAR,
  PPRD_PRECOSUB              IN NUMBER,
  PPRD_INCICMS               IN NUMBER,
  PPRD_PERCII                IN NUMBER,
  PPRD_PERCIR                IN NUMBER,
  PPRD_ISENTO                IN CHAR,
  PPRD_CODRET                IN CHAR,
  PPRD_SUSPENSO              IN CHAR,
  PPRD_CONDTRIBICMS          IN CHAR,
  PPRD_CONDTRIBIPI           IN CHAR,
  PPRD_FATSEG                IN NUMBER,
  PPRD_VARATEND              IN NUMBER,
  PPRD_LOTESERIE             IN CHAR,
  PPRD_LTCOMPRA              IN NUMBER,
  PPRD_CODPRODDNF            IN CHAR DEFAULT NULL,
  PPRD_VALIDADE              IN CHAR,
  PPRD_VBCREDITOAUTORGSERV   IN CHAR DEFAULT NULL,
  PPRD_TPCREDITOOUTORGSERV   IN NUMBER DEFAULT NULL,
  PPRD_REGISTROINTERNO       IN CHAR DEFAULT NULL,
  PPRD_NAOCALCULARISS        IN CHAR DEFAULT NULL,
  PPRD_FATORDENSIDADE        IN CHAR DEFAULT NULL,
  PPRD_CUSTOBASECALCICMS     IN CHAR DEFAULT 'N',
  PPRD_CUSTOBASEICMSINTEREST IN CHAR DEFAULT 'N',
  PPRD_CODFAB                IN CHAR DEFAULT NULL,
  PPRD_VBSERVFRETE           IN CHAR DEFAULT 'N',
  PPRD_IDINTERNO             IN CHAR DEFAULT NULL,
  PPRD_CDSERVLC116           IN CHAR DEFAULT NULL,
  PPRD_VBFABRESCNAORELEV     IN CHAR DEFAULT 'N',
  PPRD_VBRASTREABILIDADENFE  IN CHAR DEFAULT 'N'
) AS
BEGIN
  INSERT INTO PRODUTO_PRD
    (PRD_ITEM,
     PRD_DESCRICAO,
     PRD_DESCRICAO2,
     PRD_PN,
     PRD_ITEMSUBST,
     PRD_TPPROD,
     PRD_GRUPO,
     PRD_CLFISCAL,
     PRD_UNIDCTRL,
     PRD_CST,
     PRD_GRCOTAC,
     PRD_CLASSE,
     PRD_INSPEC,
     PRD_FINANC,
     PRD_LIBERADO,
     PRD_LOCAL,
     PRD_DESTINA,
     PRD_OBS,
     PRD_MINIMO,
     PRD_MAXIMO,
     PRD_PONTORES,
     PRD_DIASUPRI,
     PRD_VENDAMIN,
     PRD_SOBINVENTARIO,
     PRD_DTINVENTARIO,
     PRD_PESOLIQUI,
     PRD_UNEGOCIO,
     PRD_PERCICMS,
     PRD_PERCICMSSub,
     PRD_PERCIPI,
     PRD_PERCISS,
     PRD_PRODSERV,
     PRD_AGRUPA,
     PRD_PRECOSUB,
     PRD_INCICMS,
     PRD_PERCII,
     PRD_ISENTO,
     PRD_PERCIR,
     PRD_CODRET,
     PRD_SUSPENSO,
     PRD_CONDTRIBICMS,
     PRD_CONDTRIBIPI,
     PRD_FATSEG,
     PRD_DTINC,
     PRD_USERINC,
     PRD_VARATEND,
     PRD_LOTESERIE,
     PRD_LTCOMPRA,
     PRD_CODPRODDNF,
     PRD_VALIDADE,
     PRD_VBCREDITOAUTORGSERV,
     PRD_TPCREDITOOUTORGSERV,
     PRD_REGISTROINTERNO,
     PRD_NAOCALCULARISS,
     PRD_FATORDENSIDADE,
     PRD_CUSTOBASECALCICMS,
     PRD_CUSTOBASEICMSINTEREST,
     PRD_CODFAB,
     PRD_VBSERVFRETE,
     PRD_IDINTERNO,
     PRD_CDSERVLC116,
     PRD_VBFABRESCNAORELEV,
     PRD_VBRASTREABILIDADENFE)
  VALUES
    (PPRD_ITEM,
     PPRD_DESCRICAO,
     PPRD_DESCRICAO2,
     PPRD_PN,
     PPRD_ITEMSUBST,
     PPRD_TPPROD,
     PPRD_GRUPO,
     PPRD_CLFISCAL,
     PPRD_UNIDCTRL,
     PPRD_CST,
     PPRD_GRCOTAC,
     PPRD_CLASSE,
     PPRD_INSPEC,
     PPRD_FINANC,
     PPRD_LIBERADO,
     PPRD_LOCAL,
     PPRD_DESTINA,
     PPRD_OBS,
     PPRD_MINIMO,
     PPRD_MAXIMO,
     PPRD_PONTORES,
     PPRD_DIASUPRI,
     PPRD_VENDAMIN,
     PPRD_SOBINVENTARIO,
     PPRD_DTINVENTARIO,
     NVL(PPRD_PESOLIQUI, 0),
     PPRD_UNEGOCIO,
     PPRD_PERCICMS,
     PPRD_PERCICMSSub,
     PPRD_PERCIPI,
     PPRD_PERCISS,
     PPRD_PRODSERV,
     PPRD_AGRUPA,
     PPRD_PRECOSUB,
     PPRD_INCICMS,
     PPRD_PERCII,
     PPRD_ISENTO,
     PPRD_PERCIR,
     PPRD_CODRET,
     PPRD_SUSPENSO,
     PPRD_CONDTRIBICMS,
     PPRD_CONDTRIBIPI,
     PPRD_FATSEG,
     SYSDATE,
     GET_USER_MXM,
     PPRD_VARATEND,
     PPRD_LOTESERIE,
     PPRD_LTCOMPRA,
     PPRD_CODPRODDNF,
     PPRD_VALIDADE,
     PPRD_VBCREDITOAUTORGSERV,
     NVL(PPRD_TPCREDITOOUTORGSERV, 0),
     PPRD_REGISTROINTERNO,
     NVL(PPRD_NAOCALCULARISS, 'N'),
     NVL(PPRD_FATORDENSIDADE, 'N'),
     PPRD_CUSTOBASECALCICMS,
     PPRD_CUSTOBASEICMSINTEREST,
     PPRD_CODFAB,
     NVL(PPRD_VBSERVFRETE, 'N'),
     PPRD_IDINTERNO,
     PPRD_CDSERVLC116,
     NVL(PPRD_VBFABRESCNAORELEV, 'N'),
     NVL(PPRD_VBRASTREABILIDADENFE, 'N'));
END;
/

CREATE OR REPLACE PROCEDURE ALTPRODUTO_PRD
(
  PPRD_ITEM                  IN CHAR,
  PPRD_DESCRICAO             IN CHAR,
  PPRD_DESCRICAO2            IN CHAR,
  PPRD_PN                    IN CHAR,
  PPRD_ITEMSUBST             IN CHAR,
  PPRD_TPPROD                IN CHAR,
  PPRD_GRUPO                 IN CHAR,
  PPRD_CLFISCAL              IN CHAR,
  PPRD_UNIDCTRL              IN CHAR,
  PPRD_CST                   IN CHAR,
  PPRD_GRCOTAC               IN CHAR,
  PPRD_CLASSE                IN CHAR,
  PPRD_INSPEC                IN CHAR,
  PPRD_FINANC                IN CHAR,
  PPRD_LIBERADO              IN CHAR,
  PPRD_LOCAL                 IN CHAR,
  PPRD_DESTINA               IN CHAR,
  PPRD_OBS                   IN CHAR,
  PPRD_MINIMO                IN NUMBER,
  PPRD_MAXIMO                IN NUMBER,
  PPRD_PONTORES              IN NUMBER,
  PPRD_DIASUPRI              IN NUMBER,
  PPRD_VENDAMIN              IN NUMBER,
  PPRD_SOBINVENTARIO         IN CHAR,
  PPRD_DTINVENTARIO          IN DATE,
  PPRD_PESOLIQUI             IN NUMBER,
  PPRD_UNEGOCIO              IN CHAR,
  PPRD_PERCICMS              IN NUMBER,
  PPRD_PERCICMSSub           IN NUMBER,
  PPRD_PERCIPI               IN NUMBER,
  PPRD_PERCISS               IN NUMBER,
  PPRD_PRODSERV              IN CHAR,
  PPRD_AGRUPA                IN CHAR,
  PPRD_PRECOSUB              IN NUMBER,
  PPRD_INCICMS               IN NUMBER,
  PPRD_PERCII                IN NUMBER,
  PPRD_ISENTO                IN CHAR,
  PPRD_PERCIR                IN NUMBER,
  PPRD_CODRET                IN CHAR,
  PPRD_SUSPENSO              IN CHAR,
  PPRD_CONDTRIBICMS          IN CHAR,
  PPRD_CONDTRIBIPI           IN CHAR,
  PPRD_FATSEG                IN NUMBER,
  PPRD_VARATEND              IN NUMBER,
  PPRD_LOTESERIE             IN CHAR,
  PPRD_LTCOMPRA              IN NUMBER,
  PPRD_CODPRODDNF            IN CHAR DEFAULT NULL,
  PPRD_VALIDADE              IN CHAR,
  PPRD_VBCREDITOAUTORGSERV   IN CHAR DEFAULT NULL,
  PPRD_TPCREDITOOUTORGSERV   IN NUMBER DEFAULT NULL,
  PPRD_REGISTROINTERNO       IN CHAR DEFAULT NULL,
  PPRD_NAOCALCULARISS        IN CHAR DEFAULT NULL,
  PPRD_FATORDENSIDADE        IN CHAR DEFAULT NULL,
  PPRD_CUSTOBASECALCICMS     IN CHAR DEFAULT 'N',
  PPRD_CUSTOBASEICMSINTEREST IN CHAR DEFAULT 'N',
  PPRD_CODFAB                IN CHAR DEFAULT NULL,
  PPRD_VBSERVFRETE           IN CHAR DEFAULT 'N',
  PPRD_IDINTERNO             IN CHAR DEFAULT NULL,
  PPRD_CDSERVLC116           IN CHAR DEFAULT NULL,
  PPRD_VBFABRESCNAORELEV     IN CHAR DEFAULT 'N',
  PPRD_VBRASTREABILIDADENFE  IN CHAR DEFAULT 'N'
) AS
BEGIN
  UPDATE PRODUTO_PRD
     SET PRD_DESCRICAO             = PPRD_DESCRICAO,
         PRD_DESCRICAO2            = PPRD_DESCRICAO2,
         PRD_PN                    = PPRD_PN,
         PRD_ITEMSUBST             = PPRD_ITEMSUBST,
         PRD_TPPROD                = PPRD_TPPROD,
         PRD_GRUPO                 = PPRD_GRUPO,
         PRD_CLFISCAL              = PPRD_CLFISCAL,
         PRD_UNIDCTRL              = PPRD_UNIDCTRL,
         PRD_CST                   = PPRD_CST,
         PRD_GRCOTAC               = PPRD_GRCOTAC,
         PRD_CLASSE                = PPRD_CLASSE,
         PRD_INSPEC                = PPRD_INSPEC,
         PRD_FINANC                = PPRD_FINANC,
         PRD_LIBERADO              = PPRD_LIBERADO,
         PRD_LOCAL                 = PPRD_LOCAL,
         PRD_DESTINA               = PPRD_DESTINA,
         PRD_OBS                   = NVL(PPRD_OBS, PRD_OBS),
         PRD_MINIMO                = PPRD_MINIMO,
         PRD_MAXIMO                = PPRD_MAXIMO,
         PRD_PONTORES              = PPRD_PONTORES,
         PRD_DIASUPRI              = PPRD_DIASUPRI,
         PRD_VENDAMIN              = PPRD_VENDAMIN,
         PRD_SOBINVENTARIO         = PPRD_SOBINVENTARIO,
         PRD_DTINVENTARIO          = PPRD_DTINVENTARIO,
         PRD_PESOLIQUI             = NVL(PPRD_PESOLIQUI, 0),
         PRD_UNEGOCIO              = PPRD_UNEGOCIO,
         PRD_PERCICMS              = PPRD_PERCICMS,
         PRD_PERCICMSSub           = PPRD_PERCICMSSub,
         PRD_PERCIPI               = PPRD_PERCIPI,
         PRD_PERCISS               = PPRD_PERCISS,
         PRD_PRODSERV              = PPRD_PRODSERV,
         PRD_AGRUPA                = PPRD_AGRUPA,
         PRD_PERCII                = PPRD_PERCII,
         PRD_INCICMS               = PPRD_INCICMS,
         PRD_PRECOSUB              = PPRD_PRECOSUB,
         PRD_ISENTO                = PPRD_ISENTO,
         PRD_PERCIR                = PPRD_PERCIR,
         PRD_SUSPENSO              = PPRD_SUSPENSO,
         PRD_CODRET                = PPRD_CODRET,
         PRD_CONDTRIBICMS          = PPRD_CONDTRIBICMS,
         PRD_CONDTRIBIPI           = PPRD_CONDTRIBIPI,
         PRD_EXP                   = NULL,
         PRD_FATSEG                = PPRD_FATSEG,
         PRD_USERALT               = GET_USER_MXM,
         PRD_DTALT                 = SYSDATE,
         PRD_VARATEND              = PPRD_VARATEND,
         PRD_LOTESERIE             = PPRD_LOTESERIE,
         PRD_LTCOMPRA              = PPRD_LTCOMPRA,
         PRD_CODPRODDNF            = PPRD_CODPRODDNF,
         PRD_VALIDADE              = PPRD_VALIDADE,
         PRD_VBCREDITOAUTORGSERV   = PPRD_VBCREDITOAUTORGSERV,
         PRD_TPCREDITOOUTORGSERV   = NVL(PPRD_TPCREDITOOUTORGSERV, 0),
         PRD_REGISTROINTERNO       = PPRD_REGISTROINTERNO,
         PRD_NAOCALCULARISS        = NVL(PPRD_NAOCALCULARISS, 'N'),
         PRD_FATORDENSIDADE        = NVL(PPRD_FATORDENSIDADE, 'N'),
         PRD_CUSTOBASECALCICMS     = PPRD_CUSTOBASECALCICMS,
         PRD_CUSTOBASEICMSINTEREST = PPRD_CUSTOBASEICMSINTEREST,
         PRD_CODFAB                = PPRD_CODFAB,
         PRD_VBSERVFRETE           = NVL(PPRD_VBSERVFRETE, 'N'),
         PRD_IDINTERNO             = PPRD_IDINTERNO,
         PRD_CDSERVLC116           = PPRD_CDSERVLC116,
         PRD_VBFABRESCNAORELEV     = NVL(PPRD_VBFABRESCNAORELEV, 'N'),
         PRD_VBRASTREABILIDADENFE  = NVL(PPRD_VBRASTREABILIDADENFE, 'N')
   WHERE PRD_ITEM = PPRD_ITEM;
END;
/

ALTER TABLE FATITFATIMPOSTO_IFI ADD IFI_VLBASEFCP NUMBER(15,2)
/

ALTER TABLE FATITFATIMPOSTO_IFI ADD IFI_VLBASEFCPST NUMBER(15,2)
/

ALTER TABLE FATITFATIMPOSTO_IFI ADD IFI_PEFCPST NUMBER(15,2)
/

ALTER TABLE FATITFATIMPOSTO_IFI ADD IFI_VLFCPST NUMBER(15,2)
/

COMMENT ON COLUMN FATITFATIMPOSTO_IFI.IFI_VLBASEFCP IS 'VALOR DA BASE DO FCP DO ICMS'
/

COMMENT ON COLUMN FATITFATIMPOSTO_IFI.IFI_VLBASEFCPST IS 'VALOR DA BASE DO FCP DO ICMS-ST'
/

COMMENT ON COLUMN FATITFATIMPOSTO_IFI.IFI_PEFCPST IS 'PERCENTUAL DO FCP DO ICMS-ST'
/

COMMENT ON COLUMN FATITFATIMPOSTO_IFI.IFI_VLFCPST IS 'VALOR DO FCP DO ICMS-ST'
/

CREATE OR REPLACE PROCEDURE PRC_INSFATITFATIMPOSTO_IFI(PIFI_IDIMPOSTO               IN OUT NUMBER,
                                                       PIFI_CDEMPRESA               IN CHAR,
                                                       PIFI_CDFILIAL                IN CHAR,
                                                       PIFI_CDFATURA                IN NUMBER,
                                                       PIFI_CDITEM                  IN CHAR,
                                                       PIFI_SQITEM                  IN NUMBER,
                                                       PIFI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                       PIFI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                       PIFI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                       PIFI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                       PIFI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                       PIFI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                       PIFI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                       PIFI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                       PIFI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                       PIFI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                       PIFI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                       PIFI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                       PIFI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                       PIFI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                       PIFI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                       PIFI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                       PIFI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                       PIFI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                       PIFI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIFI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIFI_DTINCLUSAO              IN DATE DEFAULT SYSDATE,
                                                       PIFI_USINCLUSAO              IN CHAR DEFAULT NULL,
                                                       PIFI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIFI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                       PIFI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                       PIFI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                       PIFI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                       PIFI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                       PIFI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                       PIFI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                       PIFI_CDNCM                   IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                       PIFI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                       PIFI_VLFCPST                 IN NUMBER DEFAULT NULL) AS
BEGIN
  IF PIFI_IDIMPOSTO IS NULL THEN
    SELECT SEQ1_FATITFATIMPOSTO_IFI.NEXTVAL INTO PIFI_IDIMPOSTO FROM DUAL;
  END IF;
  INSERT INTO FATITFATIMPOSTO_IFI
    (IFI_IDIMPOSTO,
     IFI_CDEMPRESA,
     IFI_CDFILIAL,
     IFI_CDFATURA,
     IFI_CDITEM,
     IFI_SQITEM,
     IFI_PEICMS,
     IFI_PEINCICMS,
     IFI_TPCONDTRIBICMS,
     IFI_CDPREFIXOCSTICMS,
     IFI_CDCSTICMS,
     IFI_CDDETBCSTICMS,
     IFI_CDDETBCICMS,
     IFI_CDCFOICMS,
     IFI_VBGERABASESUPERIORICMS,
     IFI_VBGERACUSTOICMS,
     IFI_VBGERACIAPICMS,
     IFI_CDCSTICMSST,
     IFI_CDDETBCSTICMSST,
     IFI_CDDETBCICMSST,
     IFI_TPCALCULOICMSST,
     IFI_VBACREDECREICMSST,
     IFI_VLPMCICMSST,
     IFI_PEMVAICMSST,
     IFI_PEALIQINTERNAICMSST,
     IFI_PEREDUCAOICMSST,
     IFI_PEREDUCAONORMALICMSST,
     IFI_CDCSTIPI,
     IFI_PEALIQIPI,
     IFI_TPCONDTRIBIPI,
     IFI_VBGERABASESUPIPI,
     IFI_VBBCICMSIPI,
     IFI_VBSOBREPRECOTABIPI,
     IFI_VBREDBASEICMSIPI,
     IFI_VBGERACUSTOIPI,
     IFI_VBNAOCOMPOEPISCOF,
     IFI_VBNAOCUMULATIVOPISCOF,
     IFI_CDCSTPIS,
     IFI_VBGERACUSTOPIS,
     IFI_PEALIQPIS,
     IFI_TPCONDTRIBPIS,
     IFI_PEREDBASEPIS,
     IFI_PEPAUTADOPIS,
     IFI_CDCSTCOFINS,
     IFI_VBGERACUSTOCOFINS,
     IFI_PEALIQCOFINS,
     IFI_TPCONDTRIBCOFINS,
     IFI_PEREDBASECOFINS,
     IFI_PEPAUTADOCOFINS,
     IFI_CDCSTNATBASECREDPISCOF,
     IFI_TPINDNATFRETEPISCOF,
     IFI_CDINDNATFRETEPISCOF,
     IFI_DTINCLUSAO,
     IFI_USINCLUSAO,
     IFI_PEICMSUFDEST,
     IFI_PEICMSINTERPARTILHA,
     IFI_VLDEVOLUCAOICMSST,
     IFI_PEICMSINTERESTADUAL,
     IFI_VLBASEFCP,
     IFI_PEFECP,
     IFI_VLFECP,
     IFI_VLICMSUFDEST,
     IFI_VLICMSUFREMET,
     IFI_PEDIFERIMENTO,
     IFI_VLICMSOPERACAO,
     IFI_CDNCM,
     IFI_VBCALCIMPOSTONOVOICMS,
     IFI_VBCALCIMPOSTONOVOIPI,
     IFI_VBCALCIMPOSTONOVOPIS,
     IFI_VBCALCIMPOSTONOVOCOFINS,
     IFI_VBCALCIMPOSTONOVOICMSST,
     IFI_VLBASEFCPST,
     IFI_PEFCPST,
     IFI_VLFCPST)
  VALUES
    (PIFI_IDIMPOSTO,
     PIFI_CDEMPRESA,
     PIFI_CDFILIAL,
     PIFI_CDFATURA,
     PIFI_CDITEM,
     PIFI_SQITEM,
     PIFI_PEICMS,
     PIFI_PEINCICMS,
     PIFI_TPCONDTRIBICMS,
     PIFI_CDPREFIXOCSTICMS,
     PIFI_CDCSTICMS,
     PIFI_CDDETBCSTICMS,
     PIFI_CDDETBCICMS,
     PIFI_CDCFOICMS,
     PIFI_VBGERABASESUPERIORICMS,
     PIFI_VBGERACUSTOICMS,
     PIFI_VBGERACIAPICMS,
     PIFI_CDCSTICMSST,
     PIFI_CDDETBCSTICMSST,
     PIFI_CDDETBCICMSST,
     PIFI_TPCALCULOICMSST,
     PIFI_VBACREDECREICMSST,
     PIFI_VLPMCICMSST,
     PIFI_PEMVAICMSST,
     PIFI_PEALIQINTERNAICMSST,
     PIFI_PEREDUCAOICMSST,
     PIFI_PEREDUCAONORMALICMSST,
     PIFI_CDCSTIPI,
     PIFI_PEALIQIPI,
     PIFI_TPCONDTRIBIPI,
     PIFI_VBGERABASESUPIPI,
     PIFI_VBBCICMSIPI,
     PIFI_VBSOBREPRECOTABIPI,
     PIFI_VBREDBASEICMSIPI,
     PIFI_VBGERACUSTOIPI,
     PIFI_VBNAOCOMPOEPISCOF,
     PIFI_VBNAOCUMULATIVOPISCOF,
     PIFI_CDCSTPIS,
     PIFI_VBGERACUSTOPIS,
     PIFI_PEALIQPIS,
     PIFI_TPCONDTRIBPIS,
     PIFI_PEREDBASEPIS,
     PIFI_PEPAUTADOPIS,
     PIFI_CDCSTCOFINS,
     PIFI_VBGERACUSTOCOFINS,
     PIFI_PEALIQCOFINS,
     PIFI_TPCONDTRIBCOFINS,
     PIFI_PEREDBASECOFINS,
     PIFI_PEPAUTADOCOFINS,
     PIFI_CDCSTNATBASECREDPISCOF,
     PIFI_TPINDNATFRETEPISCOF,
     PIFI_CDINDNATFRETEPISCOF,
     NVL(PIFI_DTINCLUSAO, SYSDATE),
     NVL(PIFI_USINCLUSAO, GET_USER_MXM),
     PIFI_PEICMSUFDEST,
     PIFI_PEICMSINTERPARTILHA,
     PIFI_VLDEVOLUCAOICMSST,
     PIFI_PEICMSINTERESTADUAL,
     PIFI_VLBASEFCP,
     PIFI_PEFECP,
     PIFI_VLFECP,
     PIFI_VLICMSUFDEST,
     PIFI_VLICMSUFREMET,
     PIFI_PEDIFERIMENTO,
     PIFI_VLICMSOPERACAO,
     PIFI_CDNCM,
     PIFI_VBCALCIMPOSTONOVOICMS,
     PIFI_VBCALCIMPOSTONOVOIPI,
     PIFI_VBCALCIMPOSTONOVOPIS,
     PIFI_VBCALCIMPOSTONOVOCOFINS,
     PIFI_VBCALCIMPOSTONOVOICMSST,
     PIFI_VLBASEFCPST,
     PIFI_PEFCPST,
     PIFI_VLFCPST);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATITFATIMPOSTO_IFI(PIFI_IDIMPOSTO               IN NUMBER,
                                                       PIFI_CDEMPRESA               IN CHAR,
                                                       PIFI_CDFILIAL                IN CHAR,
                                                       PIFI_CDFATURA                IN NUMBER,
                                                       PIFI_CDITEM                  IN CHAR,
                                                       PIFI_SQITEM                  IN NUMBER,
                                                       PIFI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                       PIFI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                       PIFI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                       PIFI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                       PIFI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                       PIFI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                       PIFI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                       PIFI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                       PIFI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                       PIFI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                       PIFI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                       PIFI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                       PIFI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                       PIFI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                       PIFI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                       PIFI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                       PIFI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                       PIFI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                       PIFI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                       PIFI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                       PIFI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                       PIFI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                       PIFI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                       PIFI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                       PIFI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIFI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIFI_DTALTERACAO             IN DATE DEFAULT SYSDATE,
                                                       PIFI_USALTERACAO             IN CHAR DEFAULT NULL,
                                                       PIFI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIFI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                       PIFI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                       PIFI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                       PIFI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                       PIFI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                       PIFI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                       PIFI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                       PIFI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                       PIFI_CDNCM                   IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                       PIFI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                       PIFI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                       PIFI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                       PIFI_VLFCPST                 IN NUMBER DEFAULT NULL) AS
BEGIN
  UPDATE FATITFATIMPOSTO_IFI
     SET IFI_CDEMPRESA               = PIFI_CDEMPRESA,
         IFI_CDFILIAL                = PIFI_CDFILIAL,
         IFI_CDFATURA                = PIFI_CDFATURA,
         IFI_CDITEM                  = PIFI_CDITEM,
         IFI_SQITEM                  = PIFI_SQITEM,
         IFI_PEICMS                  = PIFI_PEICMS,
         IFI_PEINCICMS               = PIFI_PEINCICMS,
         IFI_TPCONDTRIBICMS          = PIFI_TPCONDTRIBICMS,
         IFI_CDPREFIXOCSTICMS        = PIFI_CDPREFIXOCSTICMS,
         IFI_CDCSTICMS               = PIFI_CDCSTICMS,
         IFI_CDDETBCSTICMS           = PIFI_CDDETBCSTICMS,
         IFI_CDDETBCICMS             = PIFI_CDDETBCICMS,
         IFI_CDCFOICMS               = PIFI_CDCFOICMS,
         IFI_VBGERABASESUPERIORICMS  = PIFI_VBGERABASESUPERIORICMS,
         IFI_VBGERACUSTOICMS         = PIFI_VBGERACUSTOICMS,
         IFI_VBGERACIAPICMS          = PIFI_VBGERACIAPICMS,
         IFI_CDCSTICMSST             = PIFI_CDCSTICMSST,
         IFI_CDDETBCSTICMSST         = PIFI_CDDETBCSTICMSST,
         IFI_CDDETBCICMSST           = PIFI_CDDETBCICMSST,
         IFI_TPCALCULOICMSST         = PIFI_TPCALCULOICMSST,
         IFI_VBACREDECREICMSST       = PIFI_VBACREDECREICMSST,
         IFI_VLPMCICMSST             = PIFI_VLPMCICMSST,
         IFI_PEMVAICMSST             = PIFI_PEMVAICMSST,
         IFI_PEALIQINTERNAICMSST     = PIFI_PEALIQINTERNAICMSST,
         IFI_PEREDUCAOICMSST         = PIFI_PEREDUCAOICMSST,
         IFI_PEREDUCAONORMALICMSST   = PIFI_PEREDUCAONORMALICMSST,
         IFI_CDCSTIPI                = PIFI_CDCSTIPI,
         IFI_PEALIQIPI               = PIFI_PEALIQIPI,
         IFI_TPCONDTRIBIPI           = PIFI_TPCONDTRIBIPI,
         IFI_VBGERABASESUPIPI        = PIFI_VBGERABASESUPIPI,
         IFI_VBBCICMSIPI             = PIFI_VBBCICMSIPI,
         IFI_VBSOBREPRECOTABIPI      = PIFI_VBSOBREPRECOTABIPI,
         IFI_VBREDBASEICMSIPI        = PIFI_VBREDBASEICMSIPI,
         IFI_VBGERACUSTOIPI          = PIFI_VBGERACUSTOIPI,
         IFI_VBNAOCOMPOEPISCOF       = PIFI_VBNAOCOMPOEPISCOF,
         IFI_VBNAOCUMULATIVOPISCOF   = PIFI_VBNAOCUMULATIVOPISCOF,
         IFI_CDCSTPIS                = PIFI_CDCSTPIS,
         IFI_VBGERACUSTOPIS          = PIFI_VBGERACUSTOPIS,
         IFI_PEALIQPIS               = PIFI_PEALIQPIS,
         IFI_TPCONDTRIBPIS           = PIFI_TPCONDTRIBPIS,
         IFI_PEREDBASEPIS            = PIFI_PEREDBASEPIS,
         IFI_PEPAUTADOPIS            = PIFI_PEPAUTADOPIS,
         IFI_CDCSTCOFINS             = PIFI_CDCSTCOFINS,
         IFI_VBGERACUSTOCOFINS       = PIFI_VBGERACUSTOCOFINS,
         IFI_PEALIQCOFINS            = PIFI_PEALIQCOFINS,
         IFI_TPCONDTRIBCOFINS        = PIFI_TPCONDTRIBCOFINS,
         IFI_PEREDBASECOFINS         = PIFI_PEREDBASECOFINS,
         IFI_PEPAUTADOCOFINS         = PIFI_PEPAUTADOCOFINS,
         IFI_CDCSTNATBASECREDPISCOF  = PIFI_CDCSTNATBASECREDPISCOF,
         IFI_TPINDNATFRETEPISCOF     = PIFI_TPINDNATFRETEPISCOF,
         IFI_CDINDNATFRETEPISCOF     = PIFI_CDINDNATFRETEPISCOF,
         IFI_DTALTERACAO             = NVL(PIFI_DTALTERACAO, SYSDATE),
         IFI_USALTERACAO             = NVL(PIFI_USALTERACAO, GET_USER_MXM),
         IFI_PEICMSUFDEST            = PIFI_PEICMSUFDEST,
         IFI_PEICMSINTERPARTILHA     = PIFI_PEICMSINTERPARTILHA,
         IFI_VLDEVOLUCAOICMSST       = PIFI_VLDEVOLUCAOICMSST,
         IFI_PEICMSINTERESTADUAL     = PIFI_PEICMSINTERESTADUAL,
         IFI_VLBASEFCP               = PIFI_VLBASEFCP,
         IFI_PEFECP                  = PIFI_PEFECP,
         IFI_VLFECP                  = PIFI_VLFECP,
         IFI_VLICMSUFDEST            = PIFI_VLICMSUFDEST,
         IFI_VLICMSUFREMET           = PIFI_VLICMSUFREMET,
         IFI_PEDIFERIMENTO           = PIFI_PEDIFERIMENTO,
         IFI_VLICMSOPERACAO          = PIFI_VLICMSOPERACAO,
         IFI_CDNCM                   = PIFI_CDNCM,
         IFI_VBCALCIMPOSTONOVOICMS   = PIFI_VBCALCIMPOSTONOVOICMS,
         IFI_VBCALCIMPOSTONOVOIPI    = PIFI_VBCALCIMPOSTONOVOIPI,
         IFI_VBCALCIMPOSTONOVOPIS    = PIFI_VBCALCIMPOSTONOVOPIS,
         IFI_VBCALCIMPOSTONOVOCOFINS = PIFI_VBCALCIMPOSTONOVOCOFINS,
         IFI_VBCALCIMPOSTONOVOICMSST = PIFI_VBCALCIMPOSTONOVOICMSST,
         IFI_VLBASEFCPST             = PIFI_VLBASEFCPST,
         IFI_PEFCPST                 = PIFI_PEFCPST,
         IFI_VLFCPST                 = PIFI_VLFCPST
   WHERE IFI_IDIMPOSTO = PIFI_IDIMPOSTO;
END;
/

ALTER TABLE SGEITMOVIMPOSTO_MVI ADD MVI_VLBASEFCP NUMBER(15,2)
/

ALTER TABLE SGEITMOVIMPOSTO_MVI ADD MVI_VLBASEFCPST NUMBER(15,2)
/

ALTER TABLE SGEITMOVIMPOSTO_MVI ADD MVI_PEFCPST NUMBER(15,2)
/

ALTER TABLE SGEITMOVIMPOSTO_MVI ADD MVI_VLFCPST NUMBER(15,2)
/

COMMENT ON COLUMN SGEITMOVIMPOSTO_MVI.MVI_VLBASEFCP IS 'VALOR DA BASE DO FCP DO ICMS'
/

COMMENT ON COLUMN SGEITMOVIMPOSTO_MVI.MVI_VLBASEFCPST IS 'VALOR DA BASE DO FCP DO ICMS-ST'
/

COMMENT ON COLUMN SGEITMOVIMPOSTO_MVI.MVI_PEFCPST IS 'PERCENTUAL DO FCP DO ICMS-ST'
/

COMMENT ON COLUMN SGEITMOVIMPOSTO_MVI.MVI_VLFCPST IS 'VALOR DO FCP DO ICMS-ST'
/

CREATE OR REPLACE PROCEDURE PRC_INSSGEITMOVIMPOSTO_MVI(PMVI_IDIMPOSTO               IN OUT NUMBER,
                                                       PMVI_SQNOTA                  IN NUMBER,
                                                       PMVI_SQITEM                  IN NUMBER,
                                                       PMVI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                       PMVI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                       PMVI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                       PMVI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                       PMVI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                       PMVI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                       PMVI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                       PMVI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                       PMVI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                       PMVI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                       PMVI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                       PMVI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                       PMVI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                       PMVI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                       PMVI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                       PMVI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                       PMVI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                       PMVI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                       PMVI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PMVI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PMVI_DTINCLUSAO              IN DATE DEFAULT SYSDATE,
                                                       PMVI_USINCLUSAO              IN CHAR DEFAULT NULL,
                                                       PMVI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PMVI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                       PMVI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                       PMVI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                       PMVI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                       PMVI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                       PMVI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                       PMVI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                       PMVI_CDNCM                   IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                       PMVI_VLSTDEVIDONAENTRADA     IN CHAR DEFAULT NULL,
                                                       PMVI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                       PMVI_VLFCPST                 IN NUMBER DEFAULT NULL) AS
BEGIN
  IF PMVI_IDIMPOSTO IS NULL THEN
    SELECT SEQ1_SGEITMOVIMPOSTO_MVI.NEXTVAL INTO PMVI_IDIMPOSTO FROM DUAL;
  END IF;
  INSERT INTO SGEITMOVIMPOSTO_MVI
    (MVI_IDIMPOSTO,
     MVI_SQNOTA,
     MVI_SQITEM,
     MVI_PEICMS,
     MVI_PEINCICMS,
     MVI_TPCONDTRIBICMS,
     MVI_CDPREFIXOCSTICMS,
     MVI_CDCSTICMS,
     MVI_CDDETBCSTICMS,
     MVI_CDDETBCICMS,
     MVI_CDCFOICMS,
     MVI_VBGERABASESUPERIORICMS,
     MVI_VBGERACUSTOICMS,
     MVI_VBGERACIAPICMS,
     MVI_CDCSTICMSST,
     MVI_CDDETBCSTICMSST,
     MVI_CDDETBCICMSST,
     MVI_TPCALCULOICMSST,
     MVI_VBACREDECREICMSST,
     MVI_VLPMCICMSST,
     MVI_PEMVAICMSST,
     MVI_PEALIQINTERNAICMSST,
     MVI_PEREDUCAOICMSST,
     MVI_PEREDUCAONORMALICMSST,
     MVI_CDCSTIPI,
     MVI_PEALIQIPI,
     MVI_TPCONDTRIBIPI,
     MVI_VBGERABASESUPIPI,
     MVI_VBBCICMSIPI,
     MVI_VBSOBREPRECOTABIPI,
     MVI_VBREDBASEICMSIPI,
     MVI_VBGERACUSTOIPI,
     MVI_VBNAOCOMPOEPISCOF,
     MVI_VBNAOCUMULATIVOPISCOF,
     MVI_CDCSTPIS,
     MVI_VBGERACUSTOPIS,
     MVI_PEALIQPIS,
     MVI_TPCONDTRIBPIS,
     MVI_PEREDBASEPIS,
     MVI_PEPAUTADOPIS,
     MVI_CDCSTCOFINS,
     MVI_VBGERACUSTOCOFINS,
     MVI_PEALIQCOFINS,
     MVI_TPCONDTRIBCOFINS,
     MVI_PEREDBASECOFINS,
     MVI_PEPAUTADOCOFINS,
     MVI_CDCSTNATBASECREDPISCOF,
     MVI_TPINDNATFRETEPISCOF,
     MVI_CDINDNATFRETEPISCOF,
     MVI_DTINCLUSAO,
     MVI_USINCLUSAO,
     MVI_PEICMSUFDEST,
     MVI_PEICMSINTERPARTILHA,
     MVI_VLDEVOLUCAOICMSST,
     MVI_PEICMSINTERESTADUAL,
     MVI_VLBASEFCP,
     MVI_PEFECP,
     MVI_VLFECP,
     MVI_VLICMSUFDEST,
     MVI_VLICMSUFREMET,
     MVI_PEDIFERIMENTO,
     MVI_VLICMSOPERACAO,
     MVI_CDNCM,
     MVI_VBCALCIMPOSTONOVOICMS,
     MVI_VBCALCIMPOSTONOVOIPI,
     MVI_VBCALCIMPOSTONOVOPIS,
     MVI_VBCALCIMPOSTONOVOCOFINS,
     MVI_VBCALCIMPOSTONOVOICMSST,
     MVI_VLSTDEVIDONAENTRADA,
     MVI_VLBASEFCPST,
     MVI_PEFCPST,
     MVI_VLFCPST)
  VALUES
    (PMVI_IDIMPOSTO,
     PMVI_SQNOTA,
     PMVI_SQITEM,
     PMVI_PEICMS,
     PMVI_PEINCICMS,
     PMVI_TPCONDTRIBICMS,
     PMVI_CDPREFIXOCSTICMS,
     PMVI_CDCSTICMS,
     PMVI_CDDETBCSTICMS,
     PMVI_CDDETBCICMS,
     PMVI_CDCFOICMS,
     PMVI_VBGERABASESUPERIORICMS,
     PMVI_VBGERACUSTOICMS,
     PMVI_VBGERACIAPICMS,
     PMVI_CDCSTICMSST,
     PMVI_CDDETBCSTICMSST,
     PMVI_CDDETBCICMSST,
     PMVI_TPCALCULOICMSST,
     PMVI_VBACREDECREICMSST,
     PMVI_VLPMCICMSST,
     PMVI_PEMVAICMSST,
     PMVI_PEALIQINTERNAICMSST,
     PMVI_PEREDUCAOICMSST,
     PMVI_PEREDUCAONORMALICMSST,
     PMVI_CDCSTIPI,
     PMVI_PEALIQIPI,
     PMVI_TPCONDTRIBIPI,
     PMVI_VBGERABASESUPIPI,
     PMVI_VBBCICMSIPI,
     PMVI_VBSOBREPRECOTABIPI,
     PMVI_VBREDBASEICMSIPI,
     PMVI_VBGERACUSTOIPI,
     PMVI_VBNAOCOMPOEPISCOF,
     PMVI_VBNAOCUMULATIVOPISCOF,
     PMVI_CDCSTPIS,
     PMVI_VBGERACUSTOPIS,
     PMVI_PEALIQPIS,
     PMVI_TPCONDTRIBPIS,
     PMVI_PEREDBASEPIS,
     PMVI_PEPAUTADOPIS,
     PMVI_CDCSTCOFINS,
     PMVI_VBGERACUSTOCOFINS,
     PMVI_PEALIQCOFINS,
     PMVI_TPCONDTRIBCOFINS,
     PMVI_PEREDBASECOFINS,
     PMVI_PEPAUTADOCOFINS,
     PMVI_CDCSTNATBASECREDPISCOF,
     PMVI_TPINDNATFRETEPISCOF,
     PMVI_CDINDNATFRETEPISCOF,
     NVL(PMVI_DTINCLUSAO, SYSDATE),
     NVL(PMVI_USINCLUSAO, GET_USER_MXM),
     PMVI_PEICMSUFDEST,
     PMVI_PEICMSINTERPARTILHA,
     PMVI_VLDEVOLUCAOICMSST,
     PMVI_PEICMSINTERESTADUAL,
     PMVI_VLBASEFCP,
     PMVI_PEFECP,
     PMVI_VLFECP,
     PMVI_VLICMSUFDEST,
     PMVI_VLICMSUFREMET,
     PMVI_PEDIFERIMENTO,
     PMVI_VLICMSOPERACAO,
     PMVI_CDNCM,
     PMVI_VBCALCIMPOSTONOVOICMS,
     PMVI_VBCALCIMPOSTONOVOIPI,
     PMVI_VBCALCIMPOSTONOVOPIS,
     PMVI_VBCALCIMPOSTONOVOCOFINS,
     PMVI_VBCALCIMPOSTONOVOICMSST,
     PMVI_VLSTDEVIDONAENTRADA,
     PMVI_VLBASEFCPST,
     PMVI_PEFCPST,
     PMVI_VLFCPST);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSGEITMOVIMPOSTO_MVI(PMVI_IDIMPOSTO               IN NUMBER,
                                                       PMVI_SQNOTA                  IN NUMBER,
                                                       PMVI_SQITEM                  IN NUMBER,
                                                       PMVI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                       PMVI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                       PMVI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                       PMVI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                       PMVI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                       PMVI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                       PMVI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                       PMVI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                       PMVI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                       PMVI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                       PMVI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                       PMVI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                       PMVI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                       PMVI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                       PMVI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                       PMVI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                       PMVI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                       PMVI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                       PMVI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                       PMVI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                       PMVI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                       PMVI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                       PMVI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                       PMVI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                       PMVI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PMVI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PMVI_DTALTERACAO             IN DATE DEFAULT SYSDATE,
                                                       PMVI_USALTERACAO             IN CHAR DEFAULT NULL,
                                                       PMVI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PMVI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                       PMVI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                       PMVI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                       PMVI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                       PMVI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                       PMVI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                       PMVI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                       PMVI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                       PMVI_CDNCM                   IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                       PMVI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                       PMVI_VLSTDEVIDONAENTRADA     IN NUMBER DEFAULT NULL,
                                                       PMVI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                       PMVI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                       PMVI_VLFCPST                 IN NUMBER DEFAULT NULL) AS
BEGIN
  UPDATE SGEITMOVIMPOSTO_MVI
     SET MVI_SQNOTA                  = PMVI_SQNOTA,
         MVI_SQITEM                  = PMVI_SQITEM,
         MVI_PEICMS                  = PMVI_PEICMS,
         MVI_PEINCICMS               = PMVI_PEINCICMS,
         MVI_TPCONDTRIBICMS          = PMVI_TPCONDTRIBICMS,
         MVI_CDPREFIXOCSTICMS        = PMVI_CDPREFIXOCSTICMS,
         MVI_CDCSTICMS               = PMVI_CDCSTICMS,
         MVI_CDDETBCSTICMS           = PMVI_CDDETBCSTICMS,
         MVI_CDDETBCICMS             = PMVI_CDDETBCICMS,
         MVI_CDCFOICMS               = PMVI_CDCFOICMS,
         MVI_VBGERABASESUPERIORICMS  = PMVI_VBGERABASESUPERIORICMS,
         MVI_VBGERACUSTOICMS         = PMVI_VBGERACUSTOICMS,
         MVI_VBGERACIAPICMS          = PMVI_VBGERACIAPICMS,
         MVI_CDCSTICMSST             = PMVI_CDCSTICMSST,
         MVI_CDDETBCSTICMSST         = PMVI_CDDETBCSTICMSST,
         MVI_CDDETBCICMSST           = PMVI_CDDETBCICMSST,
         MVI_TPCALCULOICMSST         = PMVI_TPCALCULOICMSST,
         MVI_VBACREDECREICMSST       = PMVI_VBACREDECREICMSST,
         MVI_VLPMCICMSST             = PMVI_VLPMCICMSST,
         MVI_PEMVAICMSST             = PMVI_PEMVAICMSST,
         MVI_PEALIQINTERNAICMSST     = PMVI_PEALIQINTERNAICMSST,
         MVI_PEREDUCAOICMSST         = PMVI_PEREDUCAOICMSST,
         MVI_PEREDUCAONORMALICMSST   = PMVI_PEREDUCAONORMALICMSST,
         MVI_CDCSTIPI                = PMVI_CDCSTIPI,
         MVI_PEALIQIPI               = PMVI_PEALIQIPI,
         MVI_TPCONDTRIBIPI           = PMVI_TPCONDTRIBIPI,
         MVI_VBGERABASESUPIPI        = PMVI_VBGERABASESUPIPI,
         MVI_VBBCICMSIPI             = PMVI_VBBCICMSIPI,
         MVI_VBSOBREPRECOTABIPI      = PMVI_VBSOBREPRECOTABIPI,
         MVI_VBREDBASEICMSIPI        = PMVI_VBREDBASEICMSIPI,
         MVI_VBGERACUSTOIPI          = PMVI_VBGERACUSTOIPI,
         MVI_VBNAOCOMPOEPISCOF       = PMVI_VBNAOCOMPOEPISCOF,
         MVI_VBNAOCUMULATIVOPISCOF   = PMVI_VBNAOCUMULATIVOPISCOF,
         MVI_CDCSTPIS                = PMVI_CDCSTPIS,
         MVI_VBGERACUSTOPIS          = PMVI_VBGERACUSTOPIS,
         MVI_PEALIQPIS               = PMVI_PEALIQPIS,
         MVI_TPCONDTRIBPIS           = PMVI_TPCONDTRIBPIS,
         MVI_PEREDBASEPIS            = PMVI_PEREDBASEPIS,
         MVI_PEPAUTADOPIS            = PMVI_PEPAUTADOPIS,
         MVI_CDCSTCOFINS             = PMVI_CDCSTCOFINS,
         MVI_VBGERACUSTOCOFINS       = PMVI_VBGERACUSTOCOFINS,
         MVI_PEALIQCOFINS            = PMVI_PEALIQCOFINS,
         MVI_TPCONDTRIBCOFINS        = PMVI_TPCONDTRIBCOFINS,
         MVI_PEREDBASECOFINS         = PMVI_PEREDBASECOFINS,
         MVI_PEPAUTADOCOFINS         = PMVI_PEPAUTADOCOFINS,
         MVI_CDCSTNATBASECREDPISCOF  = PMVI_CDCSTNATBASECREDPISCOF,
         MVI_TPINDNATFRETEPISCOF     = PMVI_TPINDNATFRETEPISCOF,
         MVI_CDINDNATFRETEPISCOF     = PMVI_CDINDNATFRETEPISCOF,
         MVI_DTALTERACAO             = NVL(PMVI_DTALTERACAO, SYSDATE),
         MVI_USALTERACAO             = NVL(PMVI_USALTERACAO, GET_USER_MXM),
         MVI_PEICMSUFDEST            = PMVI_PEICMSUFDEST,
         MVI_PEICMSINTERPARTILHA     = PMVI_PEICMSINTERPARTILHA,
         MVI_VLDEVOLUCAOICMSST       = PMVI_VLDEVOLUCAOICMSST,
         MVI_PEICMSINTERESTADUAL     = PMVI_PEICMSINTERESTADUAL,
         MVI_VLBASEFCP               = PMVI_VLBASEFCP,
         MVI_PEFECP                  = PMVI_PEFECP,
         MVI_VLFECP                  = PMVI_VLFECP,
         MVI_VLICMSUFDEST            = PMVI_VLICMSUFDEST,
         MVI_VLICMSUFREMET           = PMVI_VLICMSUFREMET,
         MVI_CDNCM                   = PMVI_CDNCM,
         MVI_VBCALCIMPOSTONOVOICMS   = PMVI_VBCALCIMPOSTONOVOICMS,
         MVI_VBCALCIMPOSTONOVOIPI    = PMVI_VBCALCIMPOSTONOVOIPI,
         MVI_VBCALCIMPOSTONOVOPIS    = PMVI_VBCALCIMPOSTONOVOPIS,
         MVI_VBCALCIMPOSTONOVOCOFINS = PMVI_VBCALCIMPOSTONOVOCOFINS,
         MVI_VBCALCIMPOSTONOVOICMSST = PMVI_VBCALCIMPOSTONOVOICMSST,
         MVI_VLSTDEVIDONAENTRADA     = PMVI_VLSTDEVIDONAENTRADA,
         MVI_PEDIFERIMENTO           = PMVI_PEDIFERIMENTO,
         MVI_VLICMSOPERACAO          = PMVI_VLICMSOPERACAO,
         MVI_VLBASEFCPST             = PMVI_VLBASEFCPST,
         MVI_PEFCPST                 = PMVI_PEFCPST,
         MVI_VLFCPST                 = PMVI_VLFCPST
   WHERE MVI_IDIMPOSTO = PMVI_IDIMPOSTO;
END;
/

ALTER TABLE SIPITPEDIMPOSTO_IPI ADD IPI_VLBASEFCP NUMBER(15,2)
/

ALTER TABLE SIPITPEDIMPOSTO_IPI ADD IPI_VLBASEFCPST NUMBER(15,2)
/

ALTER TABLE SIPITPEDIMPOSTO_IPI ADD IPI_PEFCPST NUMBER(15,2)
/

ALTER TABLE SIPITPEDIMPOSTO_IPI ADD IPI_VLFCPST NUMBER(15,2)
/

COMMENT ON COLUMN SIPITPEDIMPOSTO_IPI.IPI_VLBASEFCP IS 'VALOR DA BASE DO FCP DO ICMS'
/

COMMENT ON COLUMN SIPITPEDIMPOSTO_IPI.IPI_VLBASEFCPST IS 'VALOR DA BASE DO FCP DO ICMS-ST'
/

COMMENT ON COLUMN SIPITPEDIMPOSTO_IPI.IPI_PEFCPST IS 'PERCENTUAL DO FCP DO ICMS-ST'
/

COMMENT ON COLUMN SIPITPEDIMPOSTO_IPI.IPI_VLFCPST IS 'VALOR DO FCP DO ICMS-ST'
/

CREATE OR REPLACE PROCEDURE PRC_INSSIPITPEDIMPOSTO_IPI(PIPI_IDIMPOSTO               IN OUT NUMBER,
                                                       PIPI_CDEMPRESA               IN CHAR,
                                                       PIPI_CDFILIAL                IN CHAR,
                                                       PIPI_CDPEDIDO                IN NUMBER,
                                                       PIPI_SQITEM                  IN NUMBER,
                                                       PIPI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                       PIPI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                       PIPI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                       PIPI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                       PIPI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                       PIPI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                       PIPI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                       PIPI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                       PIPI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                       PIPI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                       PIPI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                       PIPI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                       PIPI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                       PIPI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                       PIPI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                       PIPI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                       PIPI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                       PIPI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                       PIPI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                       PIPI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                       PIPI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                       PIPI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                       PIPI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                       PIPI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                       PIPI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                       PIPI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                       PIPI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                       PIPI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                       PIPI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                       PIPI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                       PIPI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                       PIPI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                       PIPI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                       PIPI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                       PIPI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                       PIPI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                       PIPI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                       PIPI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIPI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIPI_DTINCLUSAO              IN DATE DEFAULT SYSDATE,
                                                       PIPI_USINCLUSAO              IN CHAR DEFAULT NULL,
                                                       PIPI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIPI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                       PIPI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                       PIPI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                       PIPI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                       PIPI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                       PIPI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                       PIPI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIPI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                       PIPI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                       PIPI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                       PIPI_CDNCM                   IN CHAR DEFAULT NULL,
                                                       PIPI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                       PIPI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                       PIPI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                       PIPI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                       PIPI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                       PIPI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                       PIPI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                       PIPI_VLFCPST                 IN NUMBER DEFAULT NULL) AS
BEGIN
  IF PIPI_IDIMPOSTO IS NULL THEN
    SELECT SEQ1_SIPITPEDIMPOSTO_IPI.NEXTVAL INTO PIPI_IDIMPOSTO FROM DUAL;
  END IF;
  INSERT INTO SIPITPEDIMPOSTO_IPI
    (IPI_IDIMPOSTO,
     IPI_CDEMPRESA,
     IPI_CDFILIAL,
     IPI_CDPEDIDO,
     IPI_SQITEM,
     IPI_PEICMS,
     IPI_PEINCICMS,
     IPI_TPCONDTRIBICMS,
     IPI_CDPREFIXOCSTICMS,
     IPI_CDCSTICMS,
     IPI_CDDETBCSTICMS,
     IPI_CDDETBCICMS,
     IPI_CDCFOICMS,
     IPI_VBGERABASESUPERIORICMS,
     IPI_VBGERACUSTOICMS,
     IPI_VBGERACIAPICMS,
     IPI_CDCSTICMSST,
     IPI_CDDETBCSTICMSST,
     IPI_CDDETBCICMSST,
     IPI_TPCALCULOICMSST,
     IPI_VBACREDECREICMSST,
     IPI_VLPMCICMSST,
     IPI_PEMVAICMSST,
     IPI_PEALIQINTERNAICMSST,
     IPI_PEREDUCAOICMSST,
     IPI_PEREDUCAONORMALICMSST,
     IPI_CDCSTIPI,
     IPI_PEALIQIPI,
     IPI_TPCONDTRIBIPI,
     IPI_VBGERABASESUPIPI,
     IPI_VBBCICMSIPI,
     IPI_VBSOBREPRECOTABIPI,
     IPI_VBREDBASEICMSIPI,
     IPI_VBGERACUSTOIPI,
     IPI_VBNAOCOMPOEPISCOF,
     IPI_VBNAOCUMULATIVOPISCOF,
     IPI_CDCSTPIS,
     IPI_VBGERACUSTOPIS,
     IPI_PEALIQPIS,
     IPI_TPCONDTRIBPIS,
     IPI_PEREDBASEPIS,
     IPI_PEPAUTADOPIS,
     IPI_CDCSTCOFINS,
     IPI_VBGERACUSTOCOFINS,
     IPI_PEALIQCOFINS,
     IPI_TPCONDTRIBCOFINS,
     IPI_PEREDBASECOFINS,
     IPI_PEPAUTADOCOFINS,
     IPI_CDCSTNATBASECREDPISCOF,
     IPI_TPINDNATFRETEPISCOF,
     IPI_CDINDNATFRETEPISCOF,
     IPI_DTINCLUSAO,
     IPI_USINCLUSAO,
     IPI_PEICMSUFDEST,
     IPI_PEICMSINTERPARTILHA,
     IPI_VLDEVOLUCAOICMSST,
     IPI_PEICMSINTERESTADUAL,
     IPI_VLBASEFCP,
     IPI_PEFECP,
     IPI_VLFECP,
     IPI_VLICMSUFDEST,
     IPI_VLICMSUFREMET,
     IPI_PEDIFERIMENTO,
     IPI_VLICMSOPERACAO,
     IPI_CDNCM,
     IPI_VBCALCIMPOSTONOVOICMS,
     IPI_VBCALCIMPOSTONOVOIPI,
     IPI_VBCALCIMPOSTONOVOPIS,
     IPI_VBCALCIMPOSTONOVOCOFINS,
     IPI_VBCALCIMPOSTONOVOICMSST,
     IPI_VLBASEFCPST,
     IPI_PEFCPST,
     IPI_VLFCPST)
  VALUES
    (PIPI_IDIMPOSTO,
     PIPI_CDEMPRESA,
     PIPI_CDFILIAL,
     PIPI_CDPEDIDO,
     PIPI_SQITEM,
     PIPI_PEICMS,
     PIPI_PEINCICMS,
     PIPI_TPCONDTRIBICMS,
     PIPI_CDPREFIXOCSTICMS,
     PIPI_CDCSTICMS,
     PIPI_CDDETBCSTICMS,
     PIPI_CDDETBCICMS,
     PIPI_CDCFOICMS,
     PIPI_VBGERABASESUPERIORICMS,
     PIPI_VBGERACUSTOICMS,
     PIPI_VBGERACIAPICMS,
     PIPI_CDCSTICMSST,
     PIPI_CDDETBCSTICMSST,
     PIPI_CDDETBCICMSST,
     PIPI_TPCALCULOICMSST,
     PIPI_VBACREDECREICMSST,
     PIPI_VLPMCICMSST,
     PIPI_PEMVAICMSST,
     PIPI_PEALIQINTERNAICMSST,
     PIPI_PEREDUCAOICMSST,
     PIPI_PEREDUCAONORMALICMSST,
     PIPI_CDCSTIPI,
     PIPI_PEALIQIPI,
     PIPI_TPCONDTRIBIPI,
     PIPI_VBGERABASESUPIPI,
     PIPI_VBBCICMSIPI,
     PIPI_VBSOBREPRECOTABIPI,
     PIPI_VBREDBASEICMSIPI,
     PIPI_VBGERACUSTOIPI,
     PIPI_VBNAOCOMPOEPISCOF,
     PIPI_VBNAOCUMULATIVOPISCOF,
     PIPI_CDCSTPIS,
     PIPI_VBGERACUSTOPIS,
     PIPI_PEALIQPIS,
     PIPI_TPCONDTRIBPIS,
     PIPI_PEREDBASEPIS,
     PIPI_PEPAUTADOPIS,
     PIPI_CDCSTCOFINS,
     PIPI_VBGERACUSTOCOFINS,
     PIPI_PEALIQCOFINS,
     PIPI_TPCONDTRIBCOFINS,
     PIPI_PEREDBASECOFINS,
     PIPI_PEPAUTADOCOFINS,
     PIPI_CDCSTNATBASECREDPISCOF,
     PIPI_TPINDNATFRETEPISCOF,
     PIPI_CDINDNATFRETEPISCOF,
     NVL(PIPI_DTINCLUSAO, SYSDATE),
     NVL(PIPI_USINCLUSAO, GET_USER_MXM),
     PIPI_PEICMSUFDEST,
     PIPI_PEICMSINTERPARTILHA,
     PIPI_VLDEVOLUCAOICMSST,
     PIPI_PEICMSINTERESTADUAL,
     PIPI_VLBASEFCP,
     PIPI_PEFECP,
     PIPI_VLFECP,
     PIPI_VLICMSUFDEST,
     PIPI_VLICMSUFREMET,
     PIPI_PEDIFERIMENTO,
     PIPI_VLICMSOPERACAO,
     PIPI_CDNCM,
     PIPI_VBCALCIMPOSTONOVOICMS,
     PIPI_VBCALCIMPOSTONOVOIPI,
     PIPI_VBCALCIMPOSTONOVOPIS,
     PIPI_VBCALCIMPOSTONOVOCOFINS,
     PIPI_VBCALCIMPOSTONOVOICMSST,
     PIPI_VLBASEFCPST,
     PIPI_PEFCPST,
     PIPI_VLFCPST);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSIPITPEDIMPOSTO_IPI(PIPI_IDIMPOSTO               IN NUMBER,
                                                       PIPI_CDEMPRESA               IN CHAR,
                                                       PIPI_CDFILIAL                IN CHAR,
                                                       PIPI_CDPEDIDO                IN NUMBER,
                                                       PIPI_SQITEM                  IN NUMBER,
                                                       PIPI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                       PIPI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                       PIPI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                       PIPI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                       PIPI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                       PIPI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                       PIPI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                       PIPI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                       PIPI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                       PIPI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                       PIPI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                       PIPI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                       PIPI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                       PIPI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                       PIPI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                       PIPI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                       PIPI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                       PIPI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                       PIPI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                       PIPI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                       PIPI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                       PIPI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                       PIPI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                       PIPI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                       PIPI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                       PIPI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                       PIPI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                       PIPI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                       PIPI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                       PIPI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                       PIPI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                       PIPI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                       PIPI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                       PIPI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                       PIPI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                       PIPI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                       PIPI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                       PIPI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                       PIPI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIPI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                       PIPI_DTALTERACAO             IN DATE DEFAULT SYSDATE,
                                                       PIPI_USALTERACAO             IN CHAR DEFAULT NULL,
                                                       PIPI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIPI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                       PIPI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                       PIPI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                       PIPI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                       PIPI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                       PIPI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                       PIPI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                       PIPI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                       PIPI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                       PIPI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                       PIPI_CDNCM                   IN CHAR DEFAULT NULL,
                                                       PIPI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                       PIPI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                       PIPI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                       PIPI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                       PIPI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                       PIPI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                       PIPI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                       PIPI_VLFCPST                 IN NUMBER DEFAULT NULL) AS
BEGIN
  UPDATE SIPITPEDIMPOSTO_IPI
     SET IPI_CDEMPRESA               = PIPI_CDEMPRESA,
         IPI_CDFILIAL                = PIPI_CDFILIAL,
         IPI_CDPEDIDO                = PIPI_CDPEDIDO,
         IPI_SQITEM                  = PIPI_SQITEM,
         IPI_PEICMS                  = PIPI_PEICMS,
         IPI_PEINCICMS               = PIPI_PEINCICMS,
         IPI_TPCONDTRIBICMS          = PIPI_TPCONDTRIBICMS,
         IPI_CDPREFIXOCSTICMS        = PIPI_CDPREFIXOCSTICMS,
         IPI_CDCSTICMS               = PIPI_CDCSTICMS,
         IPI_CDDETBCSTICMS           = PIPI_CDDETBCSTICMS,
         IPI_CDDETBCICMS             = PIPI_CDDETBCICMS,
         IPI_CDCFOICMS               = PIPI_CDCFOICMS,
         IPI_VBGERABASESUPERIORICMS  = PIPI_VBGERABASESUPERIORICMS,
         IPI_VBGERACUSTOICMS         = PIPI_VBGERACUSTOICMS,
         IPI_VBGERACIAPICMS          = PIPI_VBGERACIAPICMS,
         IPI_CDCSTICMSST             = PIPI_CDCSTICMSST,
         IPI_CDDETBCSTICMSST         = PIPI_CDDETBCSTICMSST,
         IPI_CDDETBCICMSST           = PIPI_CDDETBCICMSST,
         IPI_TPCALCULOICMSST         = PIPI_TPCALCULOICMSST,
         IPI_VBACREDECREICMSST       = PIPI_VBACREDECREICMSST,
         IPI_VLPMCICMSST             = PIPI_VLPMCICMSST,
         IPI_PEMVAICMSST             = PIPI_PEMVAICMSST,
         IPI_PEALIQINTERNAICMSST     = PIPI_PEALIQINTERNAICMSST,
         IPI_PEREDUCAOICMSST         = PIPI_PEREDUCAOICMSST,
         IPI_PEREDUCAONORMALICMSST   = PIPI_PEREDUCAONORMALICMSST,
         IPI_CDCSTIPI                = PIPI_CDCSTIPI,
         IPI_PEALIQIPI               = PIPI_PEALIQIPI,
         IPI_TPCONDTRIBIPI           = PIPI_TPCONDTRIBIPI,
         IPI_VBGERABASESUPIPI        = PIPI_VBGERABASESUPIPI,
         IPI_VBBCICMSIPI             = PIPI_VBBCICMSIPI,
         IPI_VBSOBREPRECOTABIPI      = PIPI_VBSOBREPRECOTABIPI,
         IPI_VBREDBASEICMSIPI        = PIPI_VBREDBASEICMSIPI,
         IPI_VBGERACUSTOIPI          = PIPI_VBGERACUSTOIPI,
         IPI_VBNAOCOMPOEPISCOF       = PIPI_VBNAOCOMPOEPISCOF,
         IPI_VBNAOCUMULATIVOPISCOF   = PIPI_VBNAOCUMULATIVOPISCOF,
         IPI_CDCSTPIS                = PIPI_CDCSTPIS,
         IPI_VBGERACUSTOPIS          = PIPI_VBGERACUSTOPIS,
         IPI_PEALIQPIS               = PIPI_PEALIQPIS,
         IPI_TPCONDTRIBPIS           = PIPI_TPCONDTRIBPIS,
         IPI_PEREDBASEPIS            = PIPI_PEREDBASEPIS,
         IPI_PEPAUTADOPIS            = PIPI_PEPAUTADOPIS,
         IPI_CDCSTCOFINS             = PIPI_CDCSTCOFINS,
         IPI_VBGERACUSTOCOFINS       = PIPI_VBGERACUSTOCOFINS,
         IPI_PEALIQCOFINS            = PIPI_PEALIQCOFINS,
         IPI_TPCONDTRIBCOFINS        = PIPI_TPCONDTRIBCOFINS,
         IPI_PEREDBASECOFINS         = PIPI_PEREDBASECOFINS,
         IPI_PEPAUTADOCOFINS         = PIPI_PEPAUTADOCOFINS,
         IPI_CDCSTNATBASECREDPISCOF  = PIPI_CDCSTNATBASECREDPISCOF,
         IPI_TPINDNATFRETEPISCOF     = PIPI_TPINDNATFRETEPISCOF,
         IPI_CDINDNATFRETEPISCOF     = PIPI_CDINDNATFRETEPISCOF,
         IPI_DTALTERACAO             = NVL(PIPI_DTALTERACAO, SYSDATE),
         IPI_USALTERACAO             = NVL(PIPI_USALTERACAO, GET_USER_MXM),
         IPI_PEICMSUFDEST            = PIPI_PEICMSUFDEST,
         IPI_PEICMSINTERPARTILHA     = PIPI_PEICMSINTERPARTILHA,
         IPI_VLDEVOLUCAOICMSST       = PIPI_VLDEVOLUCAOICMSST,
         IPI_PEICMSINTERESTADUAL     = PIPI_PEICMSINTERESTADUAL,
         IPI_VLBASEFCP               = PIPI_VLBASEFCP,
         IPI_PEFECP                  = PIPI_PEFECP,
         IPI_VLFECP                  = PIPI_VLFECP,
         IPI_VLICMSUFDEST            = PIPI_VLICMSUFDEST,
         IPI_VLICMSUFREMET           = PIPI_VLICMSUFREMET,
         IPI_PEDIFERIMENTO           = PIPI_PEDIFERIMENTO,
         IPI_VLICMSOPERACAO          = PIPI_VLICMSOPERACAO,
         IPI_CDNCM                   = PIPI_CDNCM,
         IPI_VBCALCIMPOSTONOVOICMS   = PIPI_VBCALCIMPOSTONOVOICMS,
         IPI_VBCALCIMPOSTONOVOIPI    = PIPI_VBCALCIMPOSTONOVOIPI,
         IPI_VBCALCIMPOSTONOVOPIS    = PIPI_VBCALCIMPOSTONOVOPIS,
         IPI_VBCALCIMPOSTONOVOCOFINS = PIPI_VBCALCIMPOSTONOVOCOFINS,
         IPI_VBCALCIMPOSTONOVOICMSST = PIPI_VBCALCIMPOSTONOVOICMSST,
         IPI_VLBASEFCPST             = PIPI_VLBASEFCPST,
         IPI_PEFCPST                 = PIPI_PEFCPST,
         IPI_VLFCPST                 = PIPI_VLFCPST
   WHERE IPI_IDIMPOSTO = PIPI_IDIMPOSTO;
END;
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_PEICMSUFDEST NUMBER(5,2)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_PEICMSINTERPARTILHA NUMBER(5,2)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_PEFECP NUMBER(5,2)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VLDEVOLUCAOICMSST NUMBER(15,2)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_PEICMSINTERESTADUAL NUMBER(5,2)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VLFECP NUMBER(15,2)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VLICMSUFDEST NUMBER(15,2)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VLICMSUFREMET NUMBER(15,2)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_PEDIFERIMENTO NUMBER(7,4)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VLICMSOPERACAO NUMBER(15,4)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_CDNCM VARCHAR2(8)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VBCALCIMPOSTONOVOICMS CHAR(1)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VBCALCIMPOSTONOVOIPI CHAR(1)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VBCALCIMPOSTONOVOPIS CHAR(1)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VBCALCIMPOSTONOVOCOFINS CHAR(1)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VBCALCIMPOSTONOVOICMSST CHAR(1)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VLBASEFCP NUMBER(15,2)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VLBASEFCPST NUMBER(15,2)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_PEFCPST NUMBER(15,2)
/

ALTER TABLE SFRCTPIMPOSTO_CTI ADD CTI_VLFCPST NUMBER(15,2)
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VLBASEFCP IS 'VALOR DA BASE DO FCP DO ICMS'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VLBASEFCPST IS 'VALOR DA BASE DO FCP DO ICMS-ST'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_PEFCPST IS 'PERCENTUAL DO FCP DO ICMS-ST'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VLFCPST IS 'VALOR DO FCP DO ICMS-ST'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_PEICMSUFDEST IS 'Percentual da Al�quota Interna de destino da opera��o'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_PEICMSINTERPARTILHA IS 'Percentual da Partilha do ICMS.'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_PEFECP IS 'Percentual do FECP (Fundo estadual de combate a pobreza)'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VLDEVOLUCAOICMSST IS 'Valor de Devolu��o do ICMS ST'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_PEICMSINTERESTADUAL IS 'Percentual do ICMS Interestadual'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VLFECP IS 'Valor do FECP'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VLICMSUFDEST IS 'Valor da Partilha do ICMS na UF de Destino'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VLICMSUFREMET IS 'Valor da Partilha do ICMS na UF de Origem'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_PEDIFERIMENTO IS 'PERCENTUAL DO DIFERIMENTO DO ICMS'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VLICMSOPERACAO IS 'VALOR DO ICMS COMO SENAO TIVESSE SIDO DIFERIDO'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_CDNCM IS 'C�DIGO DO NCM'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VBCALCIMPOSTONOVOICMS IS 'Armazena o tipo de calculo do imposto S para novo calculo do imposto e N para calculo a partir do TO'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VBCALCIMPOSTONOVOIPI IS 'Armazena o tipo de calculo do imposto S para novo calculo do imposto e N para calculo a partir do TO'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VBCALCIMPOSTONOVOPIS IS 'Armazena o tipo de calculo do imposto S para novo calculo do imposto e N para calculo a partir do TO'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VBCALCIMPOSTONOVOCOFINS IS 'Armazena o tipo de calculo do imposto S para novo calculo do imposto e N para calculo a partir do TO'
/

COMMENT ON COLUMN SFRCTPIMPOSTO_CTI.CTI_VBCALCIMPOSTONOVOICMSST IS 'Armazena o tipo de calculo do imposto S para novo calculo do imposto e N para calculo a partir do TO'
/

CREATE OR REPLACE PROCEDURE PRC_INSSFRCTPIMPOSTO_CTI(PCTI_IDIMPOSTO               IN OUT NUMBER,
                                                     PCTI_SQCONHECIMENTO          IN NUMBER,
                                                     PCTI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                     PCTI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                     PCTI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                     PCTI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                     PCTI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                     PCTI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                     PCTI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                     PCTI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                     PCTI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                     PCTI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                     PCTI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                     PCTI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                     PCTI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                     PCTI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                     PCTI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                     PCTI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                     PCTI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                     PCTI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                     PCTI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                     PCTI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                     PCTI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                     PCTI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                     PCTI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                     PCTI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                     PCTI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                     PCTI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                     PCTI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                     PCTI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                     PCTI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                     PCTI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                     PCTI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                     PCTI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                     PCTI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                     PCTI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                     PCTI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                     PCTI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                     PCTI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                     PCTI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                     PCTI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                     PCTI_DTINCLUSAO              IN DATE DEFAULT SYSDATE,
                                                     PCTI_USINCLUSAO              IN CHAR DEFAULT NULL,
                                                     PCTI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                     PCTI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                     PCTI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                     PCTI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                     PCTI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                     PCTI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                     PCTI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                     PCTI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                     PCTI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                     PCTI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                     PCTI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                     PCTI_CDNCM                   IN CHAR DEFAULT NULL,
                                                     PCTI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                     PCTI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                     PCTI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                     PCTI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                     PCTI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                     PCTI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                     PCTI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                     PCTI_VLFCPST                 IN NUMBER DEFAULT NULL) AS
BEGIN
  IF PCTI_IDIMPOSTO IS NULL THEN
    SELECT SEQ1_SFRCTPIMPOSTO_CTI.NEXTVAL INTO PCTI_IDIMPOSTO FROM DUAL;
  END IF;
  INSERT INTO SFRCTPIMPOSTO_CTI
    (CTI_IDIMPOSTO,
     CTI_SQCONHECIMENTO,
     CTI_PEICMS,
     CTI_PEINCICMS,
     CTI_TPCONDTRIBICMS,
     CTI_CDPREFIXOCSTICMS,
     CTI_CDCSTICMS,
     CTI_CDDETBCSTICMS,
     CTI_CDDETBCICMS,
     CTI_CDCFOICMS,
     CTI_VBGERABASESUPERIORICMS,
     CTI_VBGERACUSTOICMS,
     CTI_VBGERACIAPICMS,
     CTI_CDCSTICMSST,
     CTI_CDDETBCSTICMSST,
     CTI_CDDETBCICMSST,
     CTI_TPCALCULOICMSST,
     CTI_VBACREDECREICMSST,
     CTI_VLPMCICMSST,
     CTI_PEMVAICMSST,
     CTI_PEALIQINTERNAICMSST,
     CTI_PEREDUCAOICMSST,
     CTI_PEREDUCAONORMALICMSST,
     CTI_CDCSTIPI,
     CTI_PEALIQIPI,
     CTI_TPCONDTRIBIPI,
     CTI_VBGERABASESUPIPI,
     CTI_VBBCICMSIPI,
     CTI_VBSOBREPRECOTABIPI,
     CTI_VBREDBASEICMSIPI,
     CTI_VBGERACUSTOIPI,
     CTI_VBNAOCOMPOEPISCOF,
     CTI_VBNAOCUMULATIVOPISCOF,
     CTI_CDCSTPIS,
     CTI_VBGERACUSTOPIS,
     CTI_PEALIQPIS,
     CTI_TPCONDTRIBPIS,
     CTI_PEREDBASEPIS,
     CTI_PEPAUTADOPIS,
     CTI_CDCSTCOFINS,
     CTI_VBGERACUSTOCOFINS,
     CTI_PEALIQCOFINS,
     CTI_TPCONDTRIBCOFINS,
     CTI_PEREDBASECOFINS,
     CTI_PEPAUTADOCOFINS,
     CTI_CDCSTNATBASECREDPISCOF,
     CTI_TPINDNATFRETEPISCOF,
     CTI_CDINDNATFRETEPISCOF,
     CTI_DTINCLUSAO,
     CTI_USINCLUSAO,
     CTI_PEICMSUFDEST,
     CTI_PEICMSINTERPARTILHA,
     CTI_VLDEVOLUCAOICMSST,
     CTI_PEICMSINTERESTADUAL,
     CTI_VLBASEFCP,
     CTI_PEFECP,
     CTI_VLFECP,
     CTI_VLICMSUFDEST,
     CTI_VLICMSUFREMET,
     CTI_PEDIFERIMENTO,
     CTI_VLICMSOPERACAO,
     CTI_CDNCM,
     CTI_VBCALCIMPOSTONOVOICMS,
     CTI_VBCALCIMPOSTONOVOIPI,
     CTI_VBCALCIMPOSTONOVOPIS,
     CTI_VBCALCIMPOSTONOVOCOFINS,
     CTI_VBCALCIMPOSTONOVOICMSST,
     CTI_VLBASEFCPST,
     CTI_PEFCPST,
     CTI_VLFCPST)
  VALUES
    (PCTI_IDIMPOSTO,
     PCTI_SQCONHECIMENTO,
     PCTI_PEICMS,
     PCTI_PEINCICMS,
     PCTI_TPCONDTRIBICMS,
     PCTI_CDPREFIXOCSTICMS,
     PCTI_CDCSTICMS,
     PCTI_CDDETBCSTICMS,
     PCTI_CDDETBCICMS,
     PCTI_CDCFOICMS,
     PCTI_VBGERABASESUPERIORICMS,
     PCTI_VBGERACUSTOICMS,
     PCTI_VBGERACIAPICMS,
     PCTI_CDCSTICMSST,
     PCTI_CDDETBCSTICMSST,
     PCTI_CDDETBCICMSST,
     PCTI_TPCALCULOICMSST,
     PCTI_VBACREDECREICMSST,
     PCTI_VLPMCICMSST,
     PCTI_PEMVAICMSST,
     PCTI_PEALIQINTERNAICMSST,
     PCTI_PEREDUCAOICMSST,
     PCTI_PEREDUCAONORMALICMSST,
     PCTI_CDCSTIPI,
     PCTI_PEALIQIPI,
     PCTI_TPCONDTRIBIPI,
     PCTI_VBGERABASESUPIPI,
     PCTI_VBBCICMSIPI,
     PCTI_VBSOBREPRECOTABIPI,
     PCTI_VBREDBASEICMSIPI,
     PCTI_VBGERACUSTOIPI,
     PCTI_VBNAOCOMPOEPISCOF,
     PCTI_VBNAOCUMULATIVOPISCOF,
     PCTI_CDCSTPIS,
     PCTI_VBGERACUSTOPIS,
     PCTI_PEALIQPIS,
     PCTI_TPCONDTRIBPIS,
     PCTI_PEREDBASEPIS,
     PCTI_PEPAUTADOPIS,
     PCTI_CDCSTCOFINS,
     PCTI_VBGERACUSTOCOFINS,
     PCTI_PEALIQCOFINS,
     PCTI_TPCONDTRIBCOFINS,
     PCTI_PEREDBASECOFINS,
     PCTI_PEPAUTADOCOFINS,
     PCTI_CDCSTNATBASECREDPISCOF,
     PCTI_TPINDNATFRETEPISCOF,
     PCTI_CDINDNATFRETEPISCOF,
     NVL(PCTI_DTINCLUSAO, SYSDATE),
     NVL(PCTI_USINCLUSAO, GET_USER_MXM),
     PCTI_PEICMSUFDEST,
     PCTI_PEICMSINTERPARTILHA,
     PCTI_VLDEVOLUCAOICMSST,
     PCTI_PEICMSINTERESTADUAL,
     PCTI_VLBASEFCP,
     PCTI_PEFECP,
     PCTI_VLFECP,
     PCTI_VLICMSUFDEST,
     PCTI_VLICMSUFREMET,
     PCTI_PEDIFERIMENTO,
     PCTI_VLICMSOPERACAO,
     PCTI_CDNCM,
     PCTI_VBCALCIMPOSTONOVOICMS,
     PCTI_VBCALCIMPOSTONOVOIPI,
     PCTI_VBCALCIMPOSTONOVOPIS,
     PCTI_VBCALCIMPOSTONOVOCOFINS,
     PCTI_VBCALCIMPOSTONOVOICMSST,
     PCTI_VLBASEFCPST,
     PCTI_PEFCPST,
     PCTI_VLFCPST);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSFRCTPIMPOSTO_CTI(PCTI_IDIMPOSTO               IN NUMBER,
                                                     PCTI_SQCONHECIMENTO          IN NUMBER,
                                                     PCTI_PEICMS                  IN NUMBER DEFAULT NULL,
                                                     PCTI_PEINCICMS               IN NUMBER DEFAULT NULL,
                                                     PCTI_TPCONDTRIBICMS          IN CHAR DEFAULT NULL,
                                                     PCTI_CDPREFIXOCSTICMS        IN CHAR DEFAULT NULL,
                                                     PCTI_CDCSTICMS               IN CHAR DEFAULT NULL,
                                                     PCTI_CDDETBCSTICMS           IN CHAR DEFAULT NULL,
                                                     PCTI_CDDETBCICMS             IN CHAR DEFAULT NULL,
                                                     PCTI_CDCFOICMS               IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERABASESUPERIORICMS  IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERACUSTOICMS         IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERACIAPICMS          IN CHAR DEFAULT NULL,
                                                     PCTI_CDCSTICMSST             IN CHAR DEFAULT NULL,
                                                     PCTI_CDDETBCSTICMSST         IN CHAR DEFAULT NULL,
                                                     PCTI_CDDETBCICMSST           IN CHAR DEFAULT NULL,
                                                     PCTI_TPCALCULOICMSST         IN CHAR DEFAULT NULL,
                                                     PCTI_VBACREDECREICMSST       IN CHAR DEFAULT NULL,
                                                     PCTI_VLPMCICMSST             IN NUMBER DEFAULT NULL,
                                                     PCTI_PEMVAICMSST             IN NUMBER DEFAULT NULL,
                                                     PCTI_PEALIQINTERNAICMSST     IN NUMBER DEFAULT NULL,
                                                     PCTI_PEREDUCAOICMSST         IN NUMBER DEFAULT NULL,
                                                     PCTI_PEREDUCAONORMALICMSST   IN NUMBER DEFAULT NULL,
                                                     PCTI_CDCSTIPI                IN CHAR DEFAULT NULL,
                                                     PCTI_PEALIQIPI               IN NUMBER DEFAULT NULL,
                                                     PCTI_TPCONDTRIBIPI           IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERABASESUPIPI        IN CHAR DEFAULT NULL,
                                                     PCTI_VBBCICMSIPI             IN CHAR DEFAULT NULL,
                                                     PCTI_VBSOBREPRECOTABIPI      IN CHAR DEFAULT NULL,
                                                     PCTI_VBREDBASEICMSIPI        IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERACUSTOIPI          IN CHAR DEFAULT NULL,
                                                     PCTI_VBNAOCOMPOEPISCOF       IN CHAR DEFAULT NULL,
                                                     PCTI_VBNAOCUMULATIVOPISCOF   IN CHAR DEFAULT NULL,
                                                     PCTI_CDCSTPIS                IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERACUSTOPIS          IN CHAR DEFAULT NULL,
                                                     PCTI_PEALIQPIS               IN NUMBER DEFAULT NULL,
                                                     PCTI_TPCONDTRIBPIS           IN CHAR DEFAULT NULL,
                                                     PCTI_PEREDBASEPIS            IN NUMBER DEFAULT NULL,
                                                     PCTI_PEPAUTADOPIS            IN NUMBER DEFAULT NULL,
                                                     PCTI_CDCSTCOFINS             IN CHAR DEFAULT NULL,
                                                     PCTI_VBGERACUSTOCOFINS       IN CHAR DEFAULT NULL,
                                                     PCTI_PEALIQCOFINS            IN NUMBER DEFAULT NULL,
                                                     PCTI_TPCONDTRIBCOFINS        IN CHAR DEFAULT NULL,
                                                     PCTI_PEREDBASECOFINS         IN NUMBER DEFAULT NULL,
                                                     PCTI_PEPAUTADOCOFINS         IN NUMBER DEFAULT NULL,
                                                     PCTI_CDCSTNATBASECREDPISCOF  IN CHAR DEFAULT NULL,
                                                     PCTI_TPINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                     PCTI_CDINDNATFRETEPISCOF     IN CHAR DEFAULT NULL,
                                                     PCTI_DTALTERACAO             IN DATE DEFAULT SYSDATE,
                                                     PCTI_USALTERACAO             IN CHAR DEFAULT NULL,
                                                     PCTI_PEICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                     PCTI_PEICMSINTERPARTILHA     IN NUMBER DEFAULT NULL,
                                                     PCTI_VLDEVOLUCAOICMSST       IN NUMBER DEFAULT NULL,
                                                     PCTI_PEICMSINTERESTADUAL     IN NUMBER DEFAULT NULL,
                                                     PCTI_VLBASEFCP               IN NUMBER DEFAULT NULL,
                                                     PCTI_PEFECP                  IN NUMBER DEFAULT NULL,
                                                     PCTI_VLFECP                  IN NUMBER DEFAULT NULL,
                                                     PCTI_VLICMSUFDEST            IN NUMBER DEFAULT NULL,
                                                     PCTI_VLICMSUFREMET           IN NUMBER DEFAULT NULL,
                                                     PCTI_PEDIFERIMENTO           IN NUMBER DEFAULT NULL,
                                                     PCTI_VLICMSOPERACAO          IN NUMBER DEFAULT NULL,
                                                     PCTI_CDNCM                   IN CHAR DEFAULT NULL,
                                                     PCTI_VBCALCIMPOSTONOVOICMS   IN CHAR DEFAULT NULL,
                                                     PCTI_VBCALCIMPOSTONOVOIPI    IN CHAR DEFAULT NULL,
                                                     PCTI_VBCALCIMPOSTONOVOPIS    IN CHAR DEFAULT NULL,
                                                     PCTI_VBCALCIMPOSTONOVOCOFINS IN CHAR DEFAULT NULL,
                                                     PCTI_VBCALCIMPOSTONOVOICMSST IN CHAR DEFAULT NULL,
                                                     PCTI_VLBASEFCPST             IN NUMBER DEFAULT NULL,
                                                     PCTI_PEFCPST                 IN NUMBER DEFAULT NULL,
                                                     PCTI_VLFCPST                 IN NUMBER DEFAULT NULL) AS
BEGIN
  UPDATE SFRCTPIMPOSTO_CTI
     SET CTI_SQCONHECIMENTO          = PCTI_SQCONHECIMENTO,
         CTI_PEICMS                  = PCTI_PEICMS,
         CTI_PEINCICMS               = PCTI_PEINCICMS,
         CTI_TPCONDTRIBICMS          = PCTI_TPCONDTRIBICMS,
         CTI_CDPREFIXOCSTICMS        = PCTI_CDPREFIXOCSTICMS,
         CTI_CDCSTICMS               = PCTI_CDCSTICMS,
         CTI_CDDETBCSTICMS           = PCTI_CDDETBCSTICMS,
         CTI_CDDETBCICMS             = PCTI_CDDETBCICMS,
         CTI_CDCFOICMS               = PCTI_CDCFOICMS,
         CTI_VBGERABASESUPERIORICMS  = PCTI_VBGERABASESUPERIORICMS,
         CTI_VBGERACUSTOICMS         = PCTI_VBGERACUSTOICMS,
         CTI_VBGERACIAPICMS          = PCTI_VBGERACIAPICMS,
         CTI_CDCSTICMSST             = PCTI_CDCSTICMSST,
         CTI_CDDETBCSTICMSST         = PCTI_CDDETBCSTICMSST,
         CTI_CDDETBCICMSST           = PCTI_CDDETBCICMSST,
         CTI_TPCALCULOICMSST         = PCTI_TPCALCULOICMSST,
         CTI_VBACREDECREICMSST       = PCTI_VBACREDECREICMSST,
         CTI_VLPMCICMSST             = PCTI_VLPMCICMSST,
         CTI_PEMVAICMSST             = PCTI_PEMVAICMSST,
         CTI_PEALIQINTERNAICMSST     = PCTI_PEALIQINTERNAICMSST,
         CTI_PEREDUCAOICMSST         = PCTI_PEREDUCAOICMSST,
         CTI_PEREDUCAONORMALICMSST   = PCTI_PEREDUCAONORMALICMSST,
         CTI_CDCSTIPI                = PCTI_CDCSTIPI,
         CTI_PEALIQIPI               = PCTI_PEALIQIPI,
         CTI_TPCONDTRIBIPI           = PCTI_TPCONDTRIBIPI,
         CTI_VBGERABASESUPIPI        = PCTI_VBGERABASESUPIPI,
         CTI_VBBCICMSIPI             = PCTI_VBBCICMSIPI,
         CTI_VBSOBREPRECOTABIPI      = PCTI_VBSOBREPRECOTABIPI,
         CTI_VBREDBASEICMSIPI        = PCTI_VBREDBASEICMSIPI,
         CTI_VBGERACUSTOIPI          = PCTI_VBGERACUSTOIPI,
         CTI_VBNAOCOMPOEPISCOF       = PCTI_VBNAOCOMPOEPISCOF,
         CTI_VBNAOCUMULATIVOPISCOF   = PCTI_VBNAOCUMULATIVOPISCOF,
         CTI_CDCSTPIS                = PCTI_CDCSTPIS,
         CTI_VBGERACUSTOPIS          = PCTI_VBGERACUSTOPIS,
         CTI_PEALIQPIS               = PCTI_PEALIQPIS,
         CTI_TPCONDTRIBPIS           = PCTI_TPCONDTRIBPIS,
         CTI_PEREDBASEPIS            = PCTI_PEREDBASEPIS,
         CTI_PEPAUTADOPIS            = PCTI_PEPAUTADOPIS,
         CTI_CDCSTCOFINS             = PCTI_CDCSTCOFINS,
         CTI_VBGERACUSTOCOFINS       = PCTI_VBGERACUSTOCOFINS,
         CTI_PEALIQCOFINS            = PCTI_PEALIQCOFINS,
         CTI_TPCONDTRIBCOFINS        = PCTI_TPCONDTRIBCOFINS,
         CTI_PEREDBASECOFINS         = PCTI_PEREDBASECOFINS,
         CTI_PEPAUTADOCOFINS         = PCTI_PEPAUTADOCOFINS,
         CTI_CDCSTNATBASECREDPISCOF  = PCTI_CDCSTNATBASECREDPISCOF,
         CTI_TPINDNATFRETEPISCOF     = PCTI_TPINDNATFRETEPISCOF,
         CTI_CDINDNATFRETEPISCOF     = PCTI_CDINDNATFRETEPISCOF,
         CTI_DTALTERACAO             = NVL(PCTI_DTALTERACAO, SYSDATE),
         CTI_USALTERACAO             = NVL(PCTI_USALTERACAO, GET_USER_MXM),
         CTI_PEICMSUFDEST            = PCTI_PEICMSUFDEST,
         CTI_PEICMSINTERPARTILHA     = PCTI_PEICMSINTERPARTILHA,
         CTI_VLDEVOLUCAOICMSST       = PCTI_VLDEVOLUCAOICMSST,
         CTI_PEICMSINTERESTADUAL     = PCTI_PEICMSINTERESTADUAL,
         CTI_VLBASEFCP               = PCTI_VLBASEFCP,
         CTI_PEFECP                  = PCTI_PEFECP,
         CTI_VLFECP                  = PCTI_VLFECP,
         CTI_VLICMSUFDEST            = PCTI_VLICMSUFDEST,
         CTI_VLICMSUFREMET           = PCTI_VLICMSUFREMET,
         CTI_PEDIFERIMENTO           = PCTI_PEDIFERIMENTO,
         CTI_VLICMSOPERACAO          = PCTI_VLICMSOPERACAO,
         CTI_CDNCM                   = PCTI_CDNCM,
         CTI_VBCALCIMPOSTONOVOICMS   = PCTI_VBCALCIMPOSTONOVOICMS,
         CTI_VBCALCIMPOSTONOVOIPI    = PCTI_VBCALCIMPOSTONOVOIPI,
         CTI_VBCALCIMPOSTONOVOPIS    = PCTI_VBCALCIMPOSTONOVOPIS,
         CTI_VBCALCIMPOSTONOVOCOFINS = PCTI_VBCALCIMPOSTONOVOCOFINS,
         CTI_VBCALCIMPOSTONOVOICMSST = PCTI_VBCALCIMPOSTONOVOICMSST,
         CTI_VLBASEFCPST             = PCTI_VLBASEFCPST,
         CTI_PEFCPST                 = PCTI_PEFCPST,
         CTI_VLFCPST                 = PCTI_VLFCPST
   WHERE CTI_IDIMPOSTO = PCTI_IDIMPOSTO;
END;
/

INSERT INTO TIPOENUMERADO_TENU VALUES ('TPENU_TPATENDIMENTOVENFAT', '5', 'Opera��o presencial, fora do estabelecimento')
/

INSERT INTO TIPOENUMERADO_TENU VALUES ('TENUFORMAPAGAMENTONFCE', '90', 'Sem pagamento')
/

CREATE TABLE SGETPPRODANVISA_TPA
(
  TPA_IDTPPRODANVISA NUMBER(9) NOT NULL,
  TPA_CDTPPRODANVISA VARCHAR2(4) NOT NULL,
  TPA_DSTPPRODANVISA VARCHAR2(200) NOT NULL,
  TPA_VBINATIVACAO   CHAR(1) DEFAULT 'N' NOT NULL,
  TPA_DTINATIVACAO   DATE,
  TPA_USINATIVACAO   VARCHAR2(40),
  TPA_DTINCLUSAO     DATE NOT NULL,
  TPA_USINCLUSAO     VARCHAR2(40) NOT NULL,
  TPA_DTALTERACAO    DATE,
  TPA_USALTERACAO    VARCHAR2(40)
)
/

ALTER TABLE SGETPPRODANVISA_TPA
  ADD CONSTRAINT PK_SGETPPRODANVISA_TPA
  PRIMARY KEY (TPA_IDTPPRODANVISA)
/

ALTER TABLE SGETPPRODANVISA_TPA
  ADD CONSTRAINT UK1_SGETPPRODANVISA_TPA
  UNIQUE (TPA_CDTPPRODANVISA)
/

COMMENT ON TABLE SGETPPRODANVISA_TPA IS 'Tabela de tipos de produto ANVISA/MS'
/

COMMENT ON COLUMN SGETPPRODANVISA_TPA.TPA_IDTPPRODANVISA IS 'Identificador do registro de tipo de produto ANVISA/MS'
/

COMMENT ON COLUMN SGETPPRODANVISA_TPA.TPA_CDTPPRODANVISA IS 'C�digo do registro de tipo de produto ANVISA/MS'
/

COMMENT ON COLUMN SGETPPRODANVISA_TPA.TPA_DSTPPRODANVISA IS 'Descri��o do registro de tipo de produto ANVISA/MS'
/

COMMENT ON COLUMN SGETPPRODANVISA_TPA.TPA_VBINATIVACAO IS 'Flag de inativa��o do registro'
/

COMMENT ON COLUMN SGETPPRODANVISA_TPA.TPA_DTINATIVACAO IS 'Data de inativa��o do registro'
/

COMMENT ON COLUMN SGETPPRODANVISA_TPA.TPA_USINATIVACAO IS 'Usu�rio de inativa��o do registro'
/

COMMENT ON COLUMN SGETPPRODANVISA_TPA.TPA_DTINCLUSAO IS 'Data de inclus�o do registro'
/

COMMENT ON COLUMN SGETPPRODANVISA_TPA.TPA_USINCLUSAO IS 'Data de altera��o do registro'
/

COMMENT ON COLUMN SGETPPRODANVISA_TPA.TPA_DTALTERACAO IS 'Usu�rio de inclus�o do registro'
/

COMMENT ON COLUMN SGETPPRODANVISA_TPA.TPA_USALTERACAO IS 'Usu�rio de altera��o do registro'
/

CREATE SEQUENCE SEQ1_SGETPPRODANVISA_TPA
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

CREATE OR REPLACE PROCEDURE PRC_INSSGETPPRODANVISA_TPA
(
  PTPA_IDTPPRODANVISA IN OUT NUMBER,
  PTPA_CDTPPRODANVISA IN CHAR,
  PTPA_DSTPPRODANVISA IN CHAR,
  PTPA_VBINATIVACAO   IN CHAR DEFAULT NULL,
  PTPA_DTINATIVACAO   IN DATE DEFAULT NULL,
  PTPA_USINATIVACAO   IN CHAR DEFAULT NULL,
  PTPA_DTINCLUSAO     IN DATE DEFAULT NULL,
  PTPA_USINCLUSAO     IN CHAR DEFAULT NULL,
  PTPA_DTALTERACAO    IN DATE DEFAULT NULL,
  PTPA_USALTERACAO    IN CHAR DEFAULT NULL
) AS
BEGIN
  IF PTPA_IDTPPRODANVISA IS NULL THEN
    SELECT SEQ1_SGETPPRODANVISA_TPA.NEXTVAL
      INTO PTPA_IDTPPRODANVISA
      FROM DUAL;
  END IF;
  INSERT INTO SGETPPRODANVISA_TPA
    (TPA_IDTPPRODANVISA,
     TPA_CDTPPRODANVISA,
     TPA_DSTPPRODANVISA,
     TPA_VBINATIVACAO,
     TPA_DTINATIVACAO,
     TPA_USINATIVACAO,
     TPA_DTINCLUSAO,
     TPA_USINCLUSAO,
     TPA_DTALTERACAO,
     TPA_USALTERACAO)
  VALUES
    (PTPA_IDTPPRODANVISA,
     PTPA_CDTPPRODANVISA,
     PTPA_DSTPPRODANVISA,
     PTPA_VBINATIVACAO,
     PTPA_DTINATIVACAO,
     PTPA_USINATIVACAO,
     SYSDATE,
     GET_USER_MXM,
     SYSDATE,
     GET_USER_MXM);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSGETPPRODANVISA_TPA
(
  PTPA_IDTPPRODANVISA IN NUMBER,
  PTPA_CDTPPRODANVISA IN CHAR,
  PTPA_DSTPPRODANVISA IN CHAR,
  PTPA_VBINATIVACAO   IN CHAR DEFAULT NULL,
  PTPA_DTINATIVACAO   IN DATE DEFAULT NULL,
  PTPA_USINATIVACAO   IN CHAR DEFAULT NULL,
  PTPA_DTINCLUSAO     IN DATE DEFAULT NULL,
  PTPA_USINCLUSAO     IN CHAR DEFAULT NULL,
  PTPA_DTALTERACAO    IN DATE DEFAULT NULL,
  PTPA_USALTERACAO    IN CHAR DEFAULT NULL
) AS
BEGIN
  UPDATE SGETPPRODANVISA_TPA
     SET TPA_IDTPPRODANVISA = PTPA_IDTPPRODANVISA,
         TPA_CDTPPRODANVISA = PTPA_CDTPPRODANVISA,
         TPA_DSTPPRODANVISA = PTPA_DSTPPRODANVISA,
         TPA_VBINATIVACAO   = PTPA_VBINATIVACAO,
         TPA_DTINATIVACAO   = PTPA_DTINATIVACAO,
         TPA_USINATIVACAO   = PTPA_USINATIVACAO,
         TPA_DTINCLUSAO     = NVL(TPA_DTINCLUSAO, SYSDATE),
         TPA_USINCLUSAO     = NVL(TPA_USINCLUSAO, GET_USER_MXM),
         TPA_DTALTERACAO    = SYSDATE,
         TPA_USALTERACAO    = GET_USER_MXM
   WHERE TPA_IDTPPRODANVISA = PTPA_IDTPPRODANVISA;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCSGETPPRODANVISA_TPA
(
  PTPA_IDTPPRODANVISA IN NUMBER
) AS
BEGIN
  DELETE FROM SGETPPRODANVISA_TPA
   WHERE TPA_IDTPPRODANVISA = PTPA_IDTPPRODANVISA;
END;
/

CREATE TABLE SGEESTERILANVISA_CEA
(
  CEA_IDESTERILANVISA NUMBER(9) NOT NULL,
  CEA_CDESTERILANVISA VARCHAR2(4) NOT NULL,
  CEA_DSESTERILANVISA VARCHAR2(200),
  CEA_VBINATIVACAO    CHAR(1) DEFAULT 'N' NOT NULL,
  CEA_DTINATIVACAO    DATE,
  CEA_USINATIVACAO    VARCHAR2(40),
  CEA_DTINCLUSAO      DATE NOT NULL,
  CEA_USINCLUSAO      VARCHAR2(40) NOT NULL,
  CEA_DTALTERACAO     DATE,
  CEA_USALTERACAO     VARCHAR2(40)
)
/

ALTER TABLE SGEESTERILANVISA_CEA
  ADD CONSTRAINT PK_SGEESTERILANVISA_CEA
  PRIMARY KEY (CEA_IDESTERILANVISA)
/

ALTER TABLE SGEESTERILANVISA_CEA
  ADD CONSTRAINT UK1_SGEESTERILANVISA_CEA
  UNIQUE (CEA_CDESTERILANVISA)
/

COMMENT ON TABLE SGEESTERILANVISA_CEA IS 'Tabela de Esteriliza��o ANVISA/MS'
/

COMMENT ON COLUMN SGEESTERILANVISA_CEA.CEA_IDESTERILANVISA IS 'Identificador do registro de Esteriliza��o ANVISA/MS'
/

COMMENT ON COLUMN SGEESTERILANVISA_CEA.CEA_CDESTERILANVISA IS 'C�digo do registro de Esteriliza��o ANVISA/MS'
/

COMMENT ON COLUMN SGEESTERILANVISA_CEA.CEA_DSESTERILANVISA IS 'Descri��o do registro de Esteriliza��o ANVISA/MS'
/

COMMENT ON COLUMN SGEESTERILANVISA_CEA.CEA_VBINATIVACAO IS 'Flag de inativa��o do registro'
/

COMMENT ON COLUMN SGEESTERILANVISA_CEA.CEA_DTINATIVACAO IS 'Data de inativa��o do registro'
/

COMMENT ON COLUMN SGEESTERILANVISA_CEA.CEA_USINATIVACAO IS 'Usu�rio de inativa��o do registro'
/

COMMENT ON COLUMN SGEESTERILANVISA_CEA.CEA_DTINCLUSAO IS 'Data de inclus�o do registro'
/

COMMENT ON COLUMN SGEESTERILANVISA_CEA.CEA_USINCLUSAO IS 'Data de altera��o do registro'
/

COMMENT ON COLUMN SGEESTERILANVISA_CEA.CEA_DTALTERACAO IS 'Usu�rio de inclus�o do registro'
/

COMMENT ON COLUMN SGEESTERILANVISA_CEA.CEA_USALTERACAO IS 'Usu�rio de altera��o do registro'
/

CREATE SEQUENCE SEQ1_SGEESTERILANVISA_CEA
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

CREATE OR REPLACE PROCEDURE PRC_INSSGEESTERILANVISA_CEA
(
  PCEA_IDESTERILANVISA IN OUT NUMBER,
  PCEA_CDESTERILANVISA IN CHAR,
  PCEA_DSESTERILANVISA IN CHAR DEFAULT NULL,
  PCEA_VBINATIVACAO    IN CHAR DEFAULT NULL,
  PCEA_DTINATIVACAO    IN DATE DEFAULT NULL,
  PCEA_USINATIVACAO    IN CHAR DEFAULT NULL,
  PCEA_DTINCLUSAO      IN DATE DEFAULT NULL,
  PCEA_USINCLUSAO      IN CHAR DEFAULT NULL,
  PCEA_DTALTERACAO     IN DATE DEFAULT NULL,
  PCEA_USALTERACAO     IN CHAR DEFAULT NULL
) AS
BEGIN
  IF PCEA_IDESTERILANVISA IS NULL THEN
    SELECT SEQ1_SGEESTERILANVISA_CEA.NEXTVAL
      INTO PCEA_IDESTERILANVISA
      FROM DUAL;
  END IF;
  INSERT INTO SGEESTERILANVISA_CEA
    (CEA_IDESTERILANVISA,
     CEA_CDESTERILANVISA,
     CEA_DSESTERILANVISA,
     CEA_VBINATIVACAO,
     CEA_DTINATIVACAO,
     CEA_USINATIVACAO,
     CEA_DTINCLUSAO,
     CEA_USINCLUSAO,
     CEA_DTALTERACAO,
     CEA_USALTERACAO)
  VALUES
    (PCEA_IDESTERILANVISA,
     PCEA_CDESTERILANVISA,
     PCEA_DSESTERILANVISA,
     PCEA_VBINATIVACAO,
     PCEA_DTINATIVACAO,
     PCEA_USINATIVACAO,
     SYSDATE,
     GET_USER_MXM,
     SYSDATE,
     GET_USER_MXM);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSGEESTERILANVISA_CEA
(
  PCEA_IDESTERILANVISA IN NUMBER,
  PCEA_CDESTERILANVISA IN CHAR,
  PCEA_DSESTERILANVISA IN CHAR DEFAULT NULL,
  PCEA_VBINATIVACAO    IN CHAR DEFAULT NULL,
  PCEA_DTINATIVACAO    IN DATE DEFAULT NULL,
  PCEA_USINATIVACAO    IN CHAR DEFAULT NULL,
  PCEA_DTINCLUSAO      IN DATE DEFAULT NULL,
  PCEA_USINCLUSAO      IN CHAR DEFAULT NULL,
  PCEA_DTALTERACAO     IN DATE DEFAULT NULL,
  PCEA_USALTERACAO     IN CHAR DEFAULT NULL
) AS
BEGIN
  UPDATE SGEESTERILANVISA_CEA
     SET CEA_IDESTERILANVISA = PCEA_IDESTERILANVISA,
         CEA_CDESTERILANVISA = PCEA_CDESTERILANVISA,
         CEA_DSESTERILANVISA = PCEA_DSESTERILANVISA,
         CEA_VBINATIVACAO    = PCEA_VBINATIVACAO,
         CEA_DTINATIVACAO    = PCEA_DTINATIVACAO,
         CEA_USINATIVACAO    = PCEA_USINATIVACAO,
         CEA_DTINCLUSAO      = NVL(CEA_DTINCLUSAO, SYSDATE),
         CEA_USINCLUSAO      = NVL(CEA_USINCLUSAO, GET_USER_MXM),
         CEA_DTALTERACAO     = SYSDATE,
         CEA_USALTERACAO     = GET_USER_MXM
   WHERE CEA_IDESTERILANVISA = PCEA_IDESTERILANVISA;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCSGEESTERILANVISA_CEA
(
  PCEA_IDESTERILANVISA IN NUMBER
) AS
BEGIN
  DELETE FROM SGEESTERILANVISA_CEA
   WHERE CEA_IDESTERILANVISA = PCEA_IDESTERILANVISA;
END;
/

CREATE TABLE SGEREGANVISA_REA
(
  REA_IDREGANVISA      NUMBER(9) NOT NULL,
  REA_CDREGANVISA      VARCHAR2(11) NOT NULL,
  REA_DSREGANVISA      VARCHAR2(100),
  REA_CDCLASSE         VARCHAR2(2),
  REA_CDTPPRODANVISA   NUMBER(9),
  REA_CDESTERILANVISA  NUMBER(9),
  REA_DSFABRICANTE     VARCHAR2(100),
  REA_TXOBSERVACAO     VARCHAR2(100),
  REA_DTREGANVISA      DATE,
  REA_DTVALIDADE       DATE,
  REA_DTREVALIDACAO    DATE,
  REA_CDSITUACAO       VARCHAR2(5),
  REA_VBREGISTROCLASSE CHAR(1),
  REA_VBINATIVACAO     CHAR(1) DEFAULT 'N' NOT NULL,
  REA_DTINATIVACAO     DATE,
  REA_USINATIVACAO     VARCHAR2(40),
  REA_DTINCLUSAO       DATE NOT NULL,
  REA_USINCLUSAO       VARCHAR2(40) NOT NULL,
  REA_DTALTERACAO      DATE,
  REA_USALTERACAO      VARCHAR2(40)
)
/

ALTER TABLE SGEREGANVISA_REA
  ADD CONSTRAINT PK_SGEREGANVISA_REA
  PRIMARY KEY (REA_IDREGANVISA)
/

ALTER TABLE SGEREGANVISA_REA
  ADD CONSTRAINT UK1_SGEREGANVISA_REA
  UNIQUE (REA_CDREGANVISA)
/

ALTER TABLE SGEREGANVISA_REA
  ADD CONSTRAINT FK1_SGEREGANVISA_REA FOREIGN KEY (REA_CDTPPRODANVISA)
  REFERENCES SGETPPRODANVISA_TPA (TPA_IDTPPRODANVISA)
/

ALTER TABLE SGEREGANVISA_REA
  ADD CONSTRAINT FK2_SGEREGANVISA_REA FOREIGN KEY (REA_CDESTERILANVISA)
  REFERENCES SGEESTERILANVISA_CEA (CEA_IDESTERILANVISA)
/

COMMENT ON TABLE SGEREGANVISA_REA IS 'Tabela de registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_IDREGANVISA IS 'Identificador do Registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_CDREGANVISA IS 'C�digo do registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_DSREGANVISA IS 'Descri��o do registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_CDCLASSE IS 'C�digo da classe do Registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_CDTPPRODANVISA IS 'Tipo de Produto ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_CDESTERILANVISA IS 'Esteriliza��o do Registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_DSFABRICANTE IS 'Fabricante'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_TXOBSERVACAO IS 'Observa��o do Registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_DTREGANVISA IS 'Data do Registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_DTVALIDADE IS 'Data de validade do Registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_DTREVALIDACAO IS 'Data de revalida��o do Registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_CDSITUACAO IS 'Situa��o do Registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_VBREGISTROCLASSE IS 'Flag de registro de classe do Registro ANVISA/MS'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_VBINATIVACAO IS 'Flag de inativa��o do registro'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_DTINATIVACAO IS 'Data de inativa��o do registro'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_USINATIVACAO IS 'Usu�rio de inativa��o do registro'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_DTINCLUSAO IS 'Data de inclus�o do registro'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_USINCLUSAO IS 'Data de altera��o do registro'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_DTALTERACAO IS 'Usu�rio de inclus�o do registro'
/

COMMENT ON COLUMN SGEREGANVISA_REA.REA_USALTERACAO IS 'Usu�rio de altera��o do registro'
/

CREATE INDEX IN1_SGEREGANVISA_REA ON SGEREGANVISA_REA (REA_CDTPPRODANVISA)
/

CREATE INDEX IN2_SGEREGANVISA_REA ON SGEREGANVISA_REA (REA_CDESTERILANVISA)
/

CREATE SEQUENCE SEQ1_SGEREGANVISA_REA
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

CREATE OR REPLACE PROCEDURE PRC_INSSGEREGANVISA_REA
(
  PREA_IDREGANVISA      IN OUT NUMBER,
  PREA_CDREGANVISA      IN CHAR,
  PREA_DSREGANVISA      IN CHAR DEFAULT NULL,
  PREA_CDCLASSE         IN CHAR DEFAULT NULL,
  PREA_CDTPPRODANVISA   IN NUMBER DEFAULT NULL,
  PREA_CDESTERILANVISA  IN NUMBER DEFAULT NULL,
  PREA_DSFABRICANTE     IN CHAR DEFAULT NULL,
  PREA_TXOBSERVACAO     IN CHAR DEFAULT NULL,
  PREA_DTREGANVISA      IN DATE DEFAULT NULL,
  PREA_DTVALIDADE       IN DATE DEFAULT NULL,
  PREA_DTREVALIDACAO    IN DATE DEFAULT NULL,
  PREA_CDSITUACAO       IN CHAR DEFAULT NULL,
  PREA_VBREGISTROCLASSE IN CHAR DEFAULT NULL,
  PREA_VBINATIVACAO     IN CHAR DEFAULT NULL,
  PREA_DTINATIVACAO     IN DATE DEFAULT NULL,
  PREA_USINATIVACAO     IN CHAR DEFAULT NULL,
  PREA_DTINCLUSAO       IN DATE DEFAULT NULL,
  PREA_USINCLUSAO       IN CHAR DEFAULT NULL,
  PREA_DTALTERACAO      IN DATE DEFAULT NULL,
  PREA_USALTERACAO      IN CHAR DEFAULT NULL
) AS
BEGIN
  IF PREA_IDREGANVISA IS NULL THEN
    SELECT SEQ1_SGEREGANVISA_REA.NEXTVAL
      INTO PREA_IDREGANVISA
      FROM DUAL;
  END IF;
  INSERT INTO SGEREGANVISA_REA
    (REA_IDREGANVISA,
     REA_CDREGANVISA,
     REA_DSREGANVISA,
     REA_CDCLASSE,
     REA_CDTPPRODANVISA,
     REA_CDESTERILANVISA,
     REA_DSFABRICANTE,
     REA_TXOBSERVACAO,
     REA_DTREGANVISA,
     REA_DTVALIDADE,
     REA_DTREVALIDACAO,
     REA_CDSITUACAO,
     REA_VBREGISTROCLASSE,
     REA_VBINATIVACAO,
     REA_DTINATIVACAO,
     REA_USINATIVACAO,
     REA_DTINCLUSAO,
     REA_USINCLUSAO,
     REA_DTALTERACAO,
     REA_USALTERACAO)
  VALUES
    (PREA_IDREGANVISA,
     PREA_CDREGANVISA,
     PREA_DSREGANVISA,
     PREA_CDCLASSE,
     PREA_CDTPPRODANVISA,
     PREA_CDESTERILANVISA,
     PREA_DSFABRICANTE,
     PREA_TXOBSERVACAO,
     PREA_DTREGANVISA,
     PREA_DTVALIDADE,
     PREA_DTREVALIDACAO,
     PREA_CDSITUACAO,
     PREA_VBREGISTROCLASSE,
     PREA_VBINATIVACAO,
     PREA_DTINATIVACAO,
     PREA_USINATIVACAO,
     SYSDATE,
     GET_USER_MXM,
     SYSDATE,
     GET_USER_MXM);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSGEREGANVISA_REA
(
  PREA_IDREGANVISA      IN NUMBER,
  PREA_CDREGANVISA      IN CHAR,
  PREA_DSREGANVISA      IN CHAR DEFAULT NULL,
  PREA_CDCLASSE         IN CHAR DEFAULT NULL,
  PREA_CDTPPRODANVISA   IN NUMBER DEFAULT NULL,
  PREA_CDESTERILANVISA  IN NUMBER DEFAULT NULL,
  PREA_DSFABRICANTE     IN CHAR DEFAULT NULL,
  PREA_TXOBSERVACAO     IN CHAR DEFAULT NULL,
  PREA_DTREGANVISA      IN DATE DEFAULT NULL,
  PREA_DTVALIDADE       IN DATE DEFAULT NULL,
  PREA_DTREVALIDACAO    IN DATE DEFAULT NULL,
  PREA_CDSITUACAO       IN CHAR DEFAULT NULL,
  PREA_VBREGISTROCLASSE IN CHAR DEFAULT NULL,
  PREA_VBINATIVACAO     IN CHAR DEFAULT NULL,
  PREA_DTINATIVACAO     IN DATE DEFAULT NULL,
  PREA_USINATIVACAO     IN CHAR DEFAULT NULL,
  PREA_DTINCLUSAO       IN DATE DEFAULT NULL,
  PREA_USINCLUSAO       IN CHAR DEFAULT NULL,
  PREA_DTALTERACAO      IN DATE DEFAULT NULL,
  PREA_USALTERACAO      IN CHAR DEFAULT NULL
) AS
BEGIN
  UPDATE SGEREGANVISA_REA
     SET REA_IDREGANVISA      = PREA_IDREGANVISA,
         REA_CDREGANVISA      = PREA_CDREGANVISA,
         REA_DSREGANVISA      = PREA_DSREGANVISA,
         REA_CDCLASSE         = PREA_CDCLASSE,
         REA_CDTPPRODANVISA   = PREA_CDTPPRODANVISA,
         REA_CDESTERILANVISA  = PREA_CDESTERILANVISA,
         REA_DSFABRICANTE     = PREA_DSFABRICANTE,
         REA_TXOBSERVACAO     = PREA_TXOBSERVACAO,
         REA_DTREGANVISA      = PREA_DTREGANVISA,
         REA_DTVALIDADE       = PREA_DTVALIDADE,
         REA_DTREVALIDACAO    = PREA_DTREVALIDACAO,
         REA_CDSITUACAO       = PREA_CDSITUACAO,
         REA_VBREGISTROCLASSE = PREA_VBREGISTROCLASSE,
         REA_VBINATIVACAO     = PREA_VBINATIVACAO,
         REA_DTINATIVACAO     = PREA_DTINATIVACAO,
         REA_USINATIVACAO     = PREA_USINATIVACAO,
         REA_DTINCLUSAO       = NVL(REA_DTINCLUSAO, SYSDATE),
         REA_USINCLUSAO       = NVL(REA_USINCLUSAO, GET_USER_MXM),
         REA_DTALTERACAO      = SYSDATE,
         REA_USALTERACAO      = GET_USER_MXM
   WHERE REA_IDREGANVISA = PREA_IDREGANVISA;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCSGEREGANVISA_REA
(
  PREA_IDREGANVISA IN NUMBER
) AS
BEGIN
  DELETE FROM SGEREGANVISA_REA
   WHERE REA_IDREGANVISA = PREA_IDREGANVISA;
END;
/

CREATE TABLE SGEIMGREGANVISA_IRA
(
  IRA_IDIMGREGANVISA NUMBER(9) NOT NULL,
  IRA_CDREGANVISA    NUMBER(9) NOT NULL,
  IRA_DSIMGREGANVISA VARCHAR2(200) NOT NULL,
  IRA_IMREGANVISA    BLOB,
  IRA_VBINATIVACAO   CHAR(1) DEFAULT 'N' NOT NULL,
  IRA_DTINATIVACAO   DATE,
  IRA_USINATIVACAO   VARCHAR2(40),
  IRA_DTINCLUSAO     DATE NOT NULL,
  IRA_USINCLUSAO     VARCHAR2(40) NOT NULL,
  IRA_DTALTERACAO    DATE,
  IRA_USALTERACAO    VARCHAR2(40)
)
/

ALTER TABLE SGEIMGREGANVISA_IRA
  ADD CONSTRAINT PK_SGEIMGREGANVISA_IRA
  PRIMARY KEY (IRA_IDIMGREGANVISA)
/

ALTER TABLE SGEIMGREGANVISA_IRA
  ADD CONSTRAINT FK1_SGEIMGREGANVISA_IRA FOREIGN KEY (IRA_CDREGANVISA)
  REFERENCES SGEREGANVISA_REA (REA_IDREGANVISA) ON DELETE CASCADE
/

COMMENT ON TABLE SGEIMGREGANVISA_IRA IS 'Tabela de imagens do registro ANVISA/MS'
/

COMMENT ON COLUMN SGEIMGREGANVISA_IRA.IRA_IDIMGREGANVISA IS 'Identificador da imagem do registro ANVISA/MS'
/

COMMENT ON COLUMN SGEIMGREGANVISA_IRA.IRA_CDREGANVISA IS 'C�digo do registro ANVISA/MS'
/

COMMENT ON COLUMN SGEIMGREGANVISA_IRA.IRA_DSIMGREGANVISA IS 'Descri��o da imagem do registro ANVISA/MS'
/

COMMENT ON COLUMN SGEIMGREGANVISA_IRA.IRA_IMREGANVISA IS 'Imagem do registro ANVISA/MS'
/

COMMENT ON COLUMN SGEIMGREGANVISA_IRA.IRA_VBINATIVACAO IS 'Flag de inativa��o do registro'
/

COMMENT ON COLUMN SGEIMGREGANVISA_IRA.IRA_DTINATIVACAO IS 'Data de inativa��o do registro'
/

COMMENT ON COLUMN SGEIMGREGANVISA_IRA.IRA_USINATIVACAO IS 'Usu�rio de inativa��o do registro'
/

COMMENT ON COLUMN SGEIMGREGANVISA_IRA.IRA_DTINCLUSAO IS 'Data de inclus�o do registro'
/

COMMENT ON COLUMN SGEIMGREGANVISA_IRA.IRA_USINCLUSAO IS 'Data de altera��o do registro'
/

COMMENT ON COLUMN SGEIMGREGANVISA_IRA.IRA_DTALTERACAO IS 'Usu�rio de inclus�o do registro'
/

COMMENT ON COLUMN SGEIMGREGANVISA_IRA.IRA_USALTERACAO IS 'Usu�rio de altera��o do registro'
/

CREATE INDEX IN1_SGEIMGREGANVISA_IRA ON SGEIMGREGANVISA_IRA (IRA_CDREGANVISA)
/

CREATE SEQUENCE SEQ1_SGEIMGREGANVISA_IRA
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

CREATE OR REPLACE PROCEDURE PRC_INSSGEIMGREGANVISA_IRA
(
  PIRA_IDIMGREGANVISA IN OUT NUMBER,
  PIRA_CDREGANVISA    IN NUMBER,
  PIRA_DSIMGREGANVISA IN CHAR,
  PIRA_IMREGANVISA    IN BLOB DEFAULT NULL,
  PIRA_VBINATIVACAO   IN CHAR DEFAULT NULL,
  PIRA_DTINATIVACAO   IN DATE DEFAULT NULL,
  PIRA_USINATIVACAO   IN CHAR DEFAULT NULL,
  PIRA_DTINCLUSAO     IN DATE DEFAULT NULL,
  PIRA_USINCLUSAO     IN CHAR DEFAULT NULL,
  PIRA_DTALTERACAO    IN DATE DEFAULT NULL,
  PIRA_USALTERACAO    IN CHAR DEFAULT NULL
) AS
BEGIN
  IF PIRA_IDIMGREGANVISA IS NULL THEN
    SELECT SEQ1_SGEIMGREGANVISA_IRA.NEXTVAL
      INTO PIRA_IDIMGREGANVISA
      FROM DUAL;
  END IF;
  INSERT INTO SGEIMGREGANVISA_IRA
    (IRA_IDIMGREGANVISA,
     IRA_CDREGANVISA,
     IRA_DSIMGREGANVISA,
     IRA_IMREGANVISA,
     IRA_VBINATIVACAO,
     IRA_DTINATIVACAO,
     IRA_USINATIVACAO,
     IRA_DTINCLUSAO,
     IRA_USINCLUSAO,
     IRA_DTALTERACAO,
     IRA_USALTERACAO)
  VALUES
    (PIRA_IDIMGREGANVISA,
     PIRA_CDREGANVISA,
     PIRA_DSIMGREGANVISA,
     PIRA_IMREGANVISA,
     PIRA_VBINATIVACAO,
     PIRA_DTINATIVACAO,
     PIRA_USINATIVACAO,
     SYSDATE,
     GET_USER_MXM,
     SYSDATE,
     GET_USER_MXM);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSGEIMGREGANVISA_IRA
(
  PIRA_IDIMGREGANVISA IN NUMBER,
  PIRA_CDREGANVISA    IN NUMBER,
  PIRA_DSIMGREGANVISA IN CHAR,
  PIRA_IMREGANVISA    IN BLOB DEFAULT NULL,
  PIRA_VBINATIVACAO   IN CHAR DEFAULT NULL,
  PIRA_DTINATIVACAO   IN DATE DEFAULT NULL,
  PIRA_USINATIVACAO   IN CHAR DEFAULT NULL,
  PIRA_DTINCLUSAO     IN DATE DEFAULT NULL,
  PIRA_USINCLUSAO     IN CHAR DEFAULT NULL,
  PIRA_DTALTERACAO    IN DATE DEFAULT NULL,
  PIRA_USALTERACAO    IN CHAR DEFAULT NULL
) AS
BEGIN
  UPDATE SGEIMGREGANVISA_IRA
     SET IRA_IDIMGREGANVISA = PIRA_IDIMGREGANVISA,
         IRA_CDREGANVISA    = PIRA_CDREGANVISA,
         IRA_DSIMGREGANVISA = PIRA_DSIMGREGANVISA,
         IRA_IMREGANVISA    = PIRA_IMREGANVISA,
         IRA_VBINATIVACAO   = PIRA_VBINATIVACAO,
         IRA_DTINATIVACAO   = PIRA_DTINATIVACAO,
         IRA_USINATIVACAO   = PIRA_USINATIVACAO,
         IRA_DTINCLUSAO     = NVL(IRA_DTINCLUSAO, SYSDATE),
         IRA_USINCLUSAO     = NVL(IRA_USINCLUSAO, GET_USER_MXM),
         IRA_DTALTERACAO    = SYSDATE,
         IRA_USALTERACAO    = GET_USER_MXM
   WHERE IRA_IDIMGREGANVISA = PIRA_IDIMGREGANVISA;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCSGEIMGREGANVISA_IRA
(
  PIRA_IDIMGREGANVISA IN NUMBER
) AS
BEGIN
  DELETE FROM SGEIMGREGANVISA_IRA
   WHERE IRA_IDIMGREGANVISA = PIRA_IDIMGREGANVISA;
END;
/

CREATE TABLE SGERELREGANVPROD_RRP
(
  RRP_IDRELREGANVPROD NUMBER(9) NOT NULL,
  RRP_CDPRODUTO       VARCHAR2(15) NOT NULL,
  RRP_CDREGANVISA     NUMBER(9),
  RRP_CDTUSS          VARCHAR2(8),
  RRP_VBAJSINIEF1114  VARCHAR2(1),
  RRP_VBINATIVACAO    CHAR(1) DEFAULT 'N' NOT NULL,
  RRP_DTINATIVACAO    DATE,
  RRP_USINATIVACAO    VARCHAR2(40),
  RRP_DTINCLUSAO      DATE NOT NULL,
  RRP_USINCLUSAO      VARCHAR2(40) NOT NULL,
  RRP_DTALTERACAO     DATE,
  RRP_USALTERACAO     VARCHAR2(40)
)
/

ALTER TABLE SGERELREGANVPROD_RRP
  ADD CONSTRAINT PK_SGERELREGANVPROD_RRP
  PRIMARY KEY (RRP_IDRELREGANVPROD)
/

ALTER TABLE SGERELREGANVPROD_RRP
  ADD CONSTRAINT UK1_SGERELREGANVPROD_RRP
  UNIQUE (RRP_CDPRODUTO)
/

ALTER TABLE SGERELREGANVPROD_RRP
  ADD CONSTRAINT FK1_SGERELREGANVPROD_RRP FOREIGN KEY (RRP_CDPRODUTO)
  REFERENCES PRODUTO_PRD (PRD_ITEM)
/

ALTER TABLE SGERELREGANVPROD_RRP
  ADD CONSTRAINT FK2_SGERELREGANVPROD_RRP FOREIGN KEY (RRP_CDREGANVISA)
  REFERENCES SGEREGANVISA_REA (REA_IDREGANVISA)
/

COMMENT ON TABLE SGERELREGANVPROD_RRP IS 'Tabela de relacionamento entre produto e registro ANVISA/MS'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_IDRELREGANVPROD IS 'Identificador do relacionamento entre produto e registro ANVISA/MS'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_CDPRODUTO IS 'C�digo do produto'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_CDREGANVISA IS 'C�digo do Registro ANVISA/MS'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_CDTUSS IS 'C�digo TUSS'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_VBAJSINIEF1114 IS 'Flag que define se o produto participa do Ajuste SINIEF 11/14'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_VBINATIVACAO IS 'Flag de inativa��o do registro'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_DTINATIVACAO IS 'Data de inativa��o do registro'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_USINATIVACAO IS 'Usu�rio de inativa��o do registro'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_DTINCLUSAO IS 'Data de inclus�o do registro'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_USINCLUSAO IS 'Data de altera��o do registro'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_DTALTERACAO IS 'Usu�rio de inclus�o do registro'
/

COMMENT ON COLUMN SGERELREGANVPROD_RRP.RRP_USALTERACAO IS 'Usu�rio de altera��o do registro'
/

CREATE INDEX IN1_SGERELREGANVPROD_RRP ON SGERELREGANVPROD_RRP (RRP_CDREGANVISA)
/

CREATE SEQUENCE SEQ1_SGERELREGANVPROD_RRP
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

CREATE OR REPLACE PROCEDURE PRC_INSSGERELREGANVPROD_RRP
(
  PRRP_IDRELREGANVPROD IN OUT NUMBER,
  PRRP_CDPRODUTO       IN CHAR,
  PRRP_CDREGANVISA     IN NUMBER DEFAULT NULL,
  PRRP_CDTUSS          IN CHAR DEFAULT NULL,
  PRRP_VBAJSINIEF1114  IN CHAR DEFAULT NULL,
  PRRP_VBINATIVACAO    IN CHAR DEFAULT NULL,
  PRRP_DTINATIVACAO    IN DATE DEFAULT NULL,
  PRRP_USINATIVACAO    IN CHAR DEFAULT NULL,
  PRRP_DTINCLUSAO      IN DATE DEFAULT NULL,
  PRRP_USINCLUSAO      IN CHAR DEFAULT NULL,
  PRRP_DTALTERACAO     IN DATE DEFAULT NULL,
  PRRP_USALTERACAO     IN CHAR DEFAULT NULL
) AS
BEGIN
  IF PRRP_IDRELREGANVPROD IS NULL THEN
    SELECT SEQ1_SGERELREGANVPROD_RRP.NEXTVAL
      INTO PRRP_IDRELREGANVPROD
      FROM DUAL;
  END IF;
  INSERT INTO SGERELREGANVPROD_RRP
    (RRP_IDRELREGANVPROD,
     RRP_CDPRODUTO,
     RRP_CDREGANVISA,
     RRP_CDTUSS,
     RRP_VBAJSINIEF1114,
     RRP_VBINATIVACAO,
     RRP_DTINATIVACAO,
     RRP_USINATIVACAO,
     RRP_DTINCLUSAO,
     RRP_USINCLUSAO,
     RRP_DTALTERACAO,
     RRP_USALTERACAO)
  VALUES
    (PRRP_IDRELREGANVPROD,
     PRRP_CDPRODUTO,
     PRRP_CDREGANVISA,
     PRRP_CDTUSS,
     PRRP_VBAJSINIEF1114,
     PRRP_VBINATIVACAO,
     PRRP_DTINATIVACAO,
     PRRP_USINATIVACAO,
     SYSDATE,
     GET_USER_MXM,
     SYSDATE,
     GET_USER_MXM);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTSGERELREGANVPROD_RRP
(
  PRRP_IDRELREGANVPROD IN NUMBER,
  PRRP_CDPRODUTO       IN CHAR,
  PRRP_CDREGANVISA     IN NUMBER DEFAULT NULL,
  PRRP_CDTUSS          IN CHAR DEFAULT NULL,
  PRRP_VBAJSINIEF1114  IN CHAR DEFAULT NULL,
  PRRP_VBINATIVACAO    IN CHAR DEFAULT NULL,
  PRRP_DTINATIVACAO    IN DATE DEFAULT NULL,
  PRRP_USINATIVACAO    IN CHAR DEFAULT NULL,
  PRRP_DTINCLUSAO      IN DATE DEFAULT NULL,
  PRRP_USINCLUSAO      IN CHAR DEFAULT NULL,
  PRRP_DTALTERACAO     IN DATE DEFAULT NULL,
  PRRP_USALTERACAO     IN CHAR DEFAULT NULL
) AS
BEGIN
  UPDATE SGERELREGANVPROD_RRP
     SET RRP_IDRELREGANVPROD = PRRP_IDRELREGANVPROD,
         RRP_CDPRODUTO       = PRRP_CDPRODUTO,
         RRP_CDREGANVISA     = PRRP_CDREGANVISA,
         RRP_CDTUSS          = PRRP_CDTUSS,
         RRP_VBAJSINIEF1114  = PRRP_VBAJSINIEF1114,
         RRP_VBINATIVACAO    = PRRP_VBINATIVACAO,
         RRP_DTINATIVACAO    = PRRP_DTINATIVACAO,
         RRP_USINATIVACAO    = PRRP_USINATIVACAO,
         RRP_DTINCLUSAO      = NVL(RRP_DTINCLUSAO, SYSDATE),
         RRP_USINCLUSAO      = NVL(RRP_USINCLUSAO, GET_USER_MXM),
         RRP_DTALTERACAO     = SYSDATE,
         RRP_USALTERACAO     = GET_USER_MXM
   WHERE RRP_IDRELREGANVPROD = PRRP_IDRELREGANVPROD;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCSGERELREGANVPROD_RRP
(
  PRRP_IDRELREGANVPROD IN NUMBER
) AS
BEGIN
  DELETE FROM SGERELREGANVPROD_RRP
   WHERE RRP_IDRELREGANVPROD = PRRP_IDRELREGANVPROD;
END;
/

ALTER TABLE FATFORMAPAGAMENTO_FFP
  ADD FFP_VLRECEBIDO NUMBER(23,8)
/

ALTER TABLE FATFORMAPAGAMENTO_FFP
  ADD FFP_VLTROCO NUMBER(23,8)
/

COMMENT ON COLUMN FATFORMAPAGAMENTO_FFP.FFP_VLRECEBIDO IS 'Valor recebido'
/

COMMENT ON COLUMN FATFORMAPAGAMENTO_FFP.FFP_VLTROCO IS 'Valor do troco (Valor recebido - Valor pagamento)'
/

CREATE OR REPLACE PROCEDURE PRC_INSFATFORMAPAGAMENTO_FFP
(
  PFFP_IDFATFORMAPAGAMENTO  IN OUT NUMBER,
  PFFP_CDEMPRESA            IN CHAR,
  PFFP_CDFILIAL             IN CHAR,
  PFFP_CDFATURA             IN NUMBER,
  PFFP_CDCARTAOCREDITO      IN NUMBER DEFAULT NULL,
  PFFP_CDTENUFORMAPAGAMENTO IN CHAR,
  PFFP_VLPAGAMENTO          IN NUMBER,
  PFFP_VLRECEBIDO           IN NUMBER,
  PFFP_VLTROCO              IN NUMBER,
  PFFP_CDAUTORIZACAO        IN CHAR DEFAULT NULL
) AS
BEGIN
  IF PFFP_IDFATFORMAPAGAMENTO IS NULL THEN
    SELECT SQ1_FATFORMAPAGAMENTO_FFP.NEXTVAL
      INTO PFFP_IDFATFORMAPAGAMENTO
      FROM DUAL;
  END IF;
  INSERT INTO FATFORMAPAGAMENTO_FFP
    (FFP_IDFATFORMAPAGAMENTO,
     FFP_CDEMPRESA,
     FFP_CDFILIAL,
     FFP_CDFATURA,
     FFP_CDCARTAOCREDITO,
     FFP_CDTENUFORMAPAGAMENTO,
     FFP_VLPAGAMENTO,
     FFP_VLRECEBIDO,
     FFP_VLTROCO,
     FFP_CDAUTORIZACAO,
     FFP_DTINCLUSAO,
     FFP_USINCLUSAO)
  VALUES
    (PFFP_IDFATFORMAPAGAMENTO,
     PFFP_CDEMPRESA,
     PFFP_CDFILIAL,
     PFFP_CDFATURA,
     PFFP_CDCARTAOCREDITO,
     PFFP_CDTENUFORMAPAGAMENTO,
     PFFP_VLPAGAMENTO,
     PFFP_VLRECEBIDO,
     PFFP_VLTROCO,
     PFFP_CDAUTORIZACAO,
     SYSDATE,
     GET_USER_MXM);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATFORMAPAGAMENTO_FFP
(
  PFFP_IDFATFORMAPAGAMENTO  IN NUMBER,
  PFFP_CDEMPRESA            IN CHAR,
  PFFP_CDFILIAL             IN CHAR,
  PFFP_CDFATURA             IN NUMBER,
  PFFP_CDCARTAOCREDITO      IN NUMBER DEFAULT NULL,
  PFFP_CDTENUFORMAPAGAMENTO IN CHAR,
  PFFP_VLPAGAMENTO          IN NUMBER,
  PFFP_VLRECEBIDO           IN NUMBER,
  PFFP_VLTROCO              IN NUMBER,
  PFFP_CDAUTORIZACAO        IN CHAR DEFAULT NULL
) AS
BEGIN
  UPDATE FATFORMAPAGAMENTO_FFP
     SET FFP_IDFATFORMAPAGAMENTO  = PFFP_IDFATFORMAPAGAMENTO,
         FFP_CDEMPRESA            = PFFP_CDEMPRESA,
         FFP_CDFILIAL             = PFFP_CDFILIAL,
         FFP_CDFATURA             = PFFP_CDFATURA,
         FFP_CDCARTAOCREDITO      = PFFP_CDCARTAOCREDITO,
         FFP_CDTENUFORMAPAGAMENTO = PFFP_CDTENUFORMAPAGAMENTO,
         FFP_VLPAGAMENTO          = PFFP_VLPAGAMENTO,
         FFP_VLRECEBIDO           = PFFP_VLRECEBIDO,
         FFP_VLTROCO              = PFFP_VLTROCO,
         FFP_CDAUTORIZACAO        = PFFP_CDAUTORIZACAO,
         FFP_DTALTERACAO          = SYSDATE,
         FFP_USALTERACAO          = USER
   WHERE FFP_IDFATFORMAPAGAMENTO = PFFP_IDFATFORMAPAGAMENTO;
END;
/

ALTER TABLE PRDLOTESERIE_PLS ADD PLS_DTFABRICACAO DATE
/

COMMENT ON COLUMN PRDLOTESERIE_PLS.PLS_DTFABRICACAO IS 'Data de fabrica��o/produ��o do lote/s�rie'
/

CREATE OR REPLACE PROCEDURE INSPRDLOTESERIE_PLS
(
  PPLS_SQLOTESERIE             IN OUT NUMBER,
  PPLS_CDFORNECEDOR            IN CHAR,
  PPLS_CDPRODUTO               IN CHAR,
  PPLS_CDLOTESERIE             IN CHAR,
  PPLS_DTVALIDADE              IN DATE,
  PPLS_CDREGINTERNO            IN CHAR,
  PPLS_DTVALIDADEINTERNA       IN DATE,
  PPLS_FATORDENSIDADE          IN NUMBER DEFAULT 0,
  PPLS_FATORDENSIDADEANALISADO IN NUMBER DEFAULT 0,
  PPLS_DTFABRICACAO            IN DATE
) AS
BEGIN
  SELECT SEQ_PRDLOTESERIE_PLS.NEXTVAL INTO PPLS_SQLOTESERIE FROM DUAL;
  INSERT INTO PRDLOTESERIE_PLS
    (PLS_SQLOTESERIE,
     PLS_CDFORNECEDOR,
     PLS_CDPRODUTO,
     PLS_CDLOTESERIE,
     PLS_DTVALIDADE,
     PLS_CDREGINTERNO,
     PLS_DTVALIDADEINTERNA,
     PLS_FATORDENSIDADE,
     PLS_FATORDENSIDADEANALISADO,
     PLS_DTFABRICACAO)
  VALUES
    (PPLS_SQLOTESERIE,
     PPLS_CDFORNECEDOR,
     PPLS_CDPRODUTO,
     PPLS_CDLOTESERIE,
     PPLS_DTVALIDADE,
     PPLS_CDREGINTERNO,
     PPLS_DTVALIDADEINTERNA,
     NVL(PPLS_FATORDENSIDADE, 0),
     NVL(PPLS_FATORDENSIDADEANALISADO, 0),
     PPLS_DTFABRICACAO);
END;
/

CREATE OR REPLACE PROCEDURE ALTPRDLOTESERIE_PLS
(
  PPLS_SQLOTESERIE             IN NUMBER,
  PPLS_CDFORNECEDOR            IN CHAR,
  PPLS_CDPRODUTO               IN CHAR,
  PPLS_CDLOTESERIE             IN CHAR,
  PPLS_DTVALIDADE              IN DATE,
  PPLS_CDREGINTERNO            IN CHAR,
  PPLS_DTVALIDADEINTERNA       IN DATE,
  PPLS_FATORDENSIDADE          IN NUMBER DEFAULT 0,
  PPLS_FATORDENSIDADEANALISADO IN NUMBER DEFAULT 0,
  PPLS_DTFABRICACAO            IN DATE
) AS
BEGIN
  UPDATE PRDLOTESERIE_PLS
     SET PLS_DTVALIDADE              = PPLS_DTVALIDADE,
         PLS_DTVALIDADEINTERNA       = PPLS_DTVALIDADEINTERNA,
         PLS_FATORDENSIDADE          = NVL(PPLS_FATORDENSIDADE, 0),
         PLS_FATORDENSIDADEANALISADO = NVL(PPLS_FATORDENSIDADEANALISADO, 0),
         PLS_CDPRODUTO               = PPLS_CDPRODUTO,
         PLS_CDREGINTERNO            = PPLS_CDREGINTERNO,
         PLS_DTFABRICACAO            = PPLS_DTFABRICACAO
   WHERE PLS_SQLOTESERIE = PPLS_SQLOTESERIE;
END;
/

CREATE OR REPLACE VIEW PRDLOTESERIE_SALDO AS
SELECT MOV_CDEMPRESA,
       MOV_TPESTOQUE,
       MOV_DATA,
       MOV_ALMOXARIFADO,
       PLS_SQLOTESERIE,
       PLS_CDFORNECEDOR,
       PLS_CDPRODUTO,
       PLS_CDLOTESERIE,
       PLS_DTVALIDADE,
       PLS_CDREGINTERNO,
       PLS_DTVALIDADEINTERNA,
       PLS_FATORDENSIDADE,
       PLS_FATORDENSIDADEANALISADO,
       PLS_DTFABRICACAO,
       SUM(MLS_QTDCTRL * DECODE(MOV_TIPO, 'E', 1, -1)) AS SALDO
  FROM PRDLOTESERIE_PLS,
       MOVLOTESERIE_MLS,
       MOVIMENTO_MOV
 WHERE MLS_SQNOTA = MOV_SQNOTA
   AND MLS_SQMOVIMENTO = MOV_SEQUENCIA
   AND MLS_SQLOTESERIE = PLS_SQLOTESERIE
 GROUP BY MOV_CDEMPRESA,
          MOV_TPESTOQUE,
          MOV_DATA,
          MOV_ALMOXARIFADO,
          PLS_SQLOTESERIE,
          PLS_CDFORNECEDOR,
          PLS_CDPRODUTO,
          PLS_CDLOTESERIE,
          PLS_DTVALIDADE,
          PLS_CDREGINTERNO,
          PLS_DTVALIDADEINTERNA,
          PLS_FATORDENSIDADE,
          PLS_FATORDENSIDADEANALISADO,
          PLS_DTFABRICACAO
/

CREATE TABLE FATIFATGLP_IFG
(
   IFG_IDIFATGLP    NUMBER(9) NOT NULL,
   IFG_CDEMPRESA    VARCHAR2(4) NOT NULL,
   IFG_CDFILIAL     VARCHAR2(4) NOT NULL,
   IFG_CDFATURA     NUMBER(10) NOT NULL,
   IFG_NRITEM       NUMBER(5) NOT NULL,
   IFG_CDPRODUTOANP VARCHAR2(10),
   IFG_DSPRODUTOANP VARCHAR2(120),
   IFG_PEGLP        NUMBER(7,4),
   IFG_PEGNN        NUMBER(7,4),
   IFG_PEGNI        NUMBER(7,4),
   IFG_VLPARTIDA    NUMBER(27,9),
   IFG_DTINCLUSAO   DATE NOT NULL,
   IFG_USINCLUSAO   VARCHAR2(40) NOT NULL,
   IFG_DTALTERACAO  DATE,
   IFG_USALTERACAO  VARCHAR2(40)
)
/

ALTER TABLE FATIFATGLP_IFG
  ADD CONSTRAINT PK_FATIFATGLP_IFG
  PRIMARY KEY (IFG_IDIFATGLP)
/

ALTER TABLE FATIFATGLP_IFG
  ADD CONSTRAINT UK1_FATIFATGLP_IFG
  UNIQUE (IFG_CDEMPRESA, IFG_CDFILIAL, IFG_CDFATURA, IFG_NRITEM)
/

ALTER TABLE FATIFATGLP_IFG
  ADD CONSTRAINT FK1_FATIFATGLP_IFG FOREIGN KEY (IFG_CDEMPRESA, IFG_CDFILIAL, IFG_CDFATURA, IFG_NRITEM)
  REFERENCES ITFATURA_IFAT (IFAT_CDEMPRESA, IFAT_CDFILIAL, IFAT_CDFATURA, IFAT_SEQUENCIA)
/

ALTER TABLE FATIFATGLP_IFG
  ADD CONSTRAINT FK2_FATIFATGLP_IFG FOREIGN KEY (IFG_CDPRODUTOANP)
  REFERENCES SPEDCODANP_ANP (ANP_CODIGO)
/

COMMENT ON TABLE FATIFATGLP_IFG IS 'Dados do produto GLP'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_IDIFATGLP IS 'Identificador do registro'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_CDEMPRESA IS 'C�digo da Empresa'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_CDFILIAL IS 'C�digo da Filial'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_CDFATURA IS 'C�digo da Fatura'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_NRITEM IS 'N�mero do Item'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_CDPRODUTOANP IS 'C�digo de produto da ANP'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_DSPRODUTOANP IS 'Descri��o do produto conforme ANP'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_PEGLP IS 'Percentual do GLP derivado do petr�leo no produto GLP'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_PEGNN IS 'Percentual de g�s natural nacional � GLGNN para o produto GLP'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_PEGNI IS 'Percentual de g�s natural importado � GLGNI para o produto GLP'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_VLPARTIDA IS 'Valor de partida'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_DTINCLUSAO IS 'Data de inclus�o do registro'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_USINCLUSAO IS 'Usu�rio de inclus�o do registro'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_DTALTERACAO IS 'Data de altera��o do registro'
/

COMMENT ON COLUMN FATIFATGLP_IFG.IFG_USALTERACAO IS 'Usu�rio de altera��o do registro'
/

CREATE INDEX IN1_FATIFATGLP_IFG ON FATIFATGLP_IFG (IFG_CDPRODUTOANP)
/

CREATE SEQUENCE SEQ1_FATIFATGLP_IFG
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

CREATE OR REPLACE PROCEDURE PRC_INSFATIFATGLP_IFG
(
  PIFG_IDIFATGLP    IN OUT NUMBER,
  PIFG_CDEMPRESA    IN CHAR,
  PIFG_CDFILIAL     IN CHAR,
  PIFG_CDFATURA     IN NUMBER,
  PIFG_NRITEM       IN NUMBER,
  PIFG_CDPRODUTOANP IN CHAR DEFAULT NULL,
  PIFG_DSPRODUTOANP IN CHAR DEFAULT NULL,
  PIFG_PEGLP        IN NUMBER DEFAULT NULL,
  PIFG_PEGNN        IN NUMBER DEFAULT NULL,
  PIFG_PEGNI        IN NUMBER DEFAULT NULL,
  PIFG_VLPARTIDA    IN NUMBER DEFAULT NULL,
  PIFG_DTINCLUSAO   IN DATE DEFAULT NULL,
  PIFG_USINCLUSAO   IN CHAR DEFAULT NULL,
  PIFG_DTALTERACAO  IN DATE DEFAULT NULL,
  PIFG_USALTERACAO  IN CHAR DEFAULT NULL
) AS
BEGIN
  IF PIFG_IDIFATGLP IS NULL THEN
    SELECT SEQ1_FATIFATGLP_IFG.NEXTVAL INTO PIFG_IDIFATGLP FROM DUAL;
  END IF;
  INSERT INTO FATIFATGLP_IFG
    (IFG_IDIFATGLP,
     IFG_CDEMPRESA,
     IFG_CDFILIAL,
     IFG_CDFATURA,
     IFG_NRITEM,
     IFG_CDPRODUTOANP,
     IFG_DSPRODUTOANP,
     IFG_PEGLP,
     IFG_PEGNN,
     IFG_PEGNI,
     IFG_VLPARTIDA,
     IFG_DTINCLUSAO,
     IFG_USINCLUSAO,
     IFG_DTALTERACAO,
     IFG_USALTERACAO)
  VALUES
    (PIFG_IDIFATGLP,
     PIFG_CDEMPRESA,
     PIFG_CDFILIAL,
     PIFG_CDFATURA,
     PIFG_NRITEM,
     PIFG_CDPRODUTOANP,
     PIFG_DSPRODUTOANP,
     PIFG_PEGLP,
     PIFG_PEGNN,
     PIFG_PEGNI,
     PIFG_VLPARTIDA,
     NVL(PIFG_DTINCLUSAO, SYSDATE),
     NVL(PIFG_USINCLUSAO, GET_USER_MXM),
     NVL(PIFG_DTALTERACAO, SYSDATE),
     NVL(PIFG_USALTERACAO, GET_USER_MXM));
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATIFATGLP_IFG
(
  PIFG_IDIFATGLP    IN NUMBER,
  PIFG_CDEMPRESA    IN CHAR,
  PIFG_CDFILIAL     IN CHAR,
  PIFG_CDFATURA     IN NUMBER,
  PIFG_NRITEM       IN NUMBER,
  PIFG_CDPRODUTOANP IN CHAR DEFAULT NULL,
  PIFG_DSPRODUTOANP IN CHAR DEFAULT NULL,
  PIFG_PEGLP        IN NUMBER DEFAULT NULL,
  PIFG_PEGNN        IN NUMBER DEFAULT NULL,
  PIFG_PEGNI        IN NUMBER DEFAULT NULL,
  PIFG_VLPARTIDA    IN NUMBER DEFAULT NULL,
  PIFG_DTINCLUSAO   IN DATE DEFAULT NULL,
  PIFG_USINCLUSAO   IN CHAR DEFAULT NULL,
  PIFG_DTALTERACAO  IN DATE DEFAULT NULL,
  PIFG_USALTERACAO  IN CHAR DEFAULT NULL
) AS
BEGIN
  UPDATE FATIFATGLP_IFG
     SET IFG_IDIFATGLP    = PIFG_IDIFATGLP,
         IFG_CDEMPRESA    = PIFG_CDEMPRESA,
         IFG_CDFILIAL     = PIFG_CDFILIAL,
         IFG_CDFATURA     = PIFG_CDFATURA,
         IFG_NRITEM       = PIFG_NRITEM,
         IFG_CDPRODUTOANP = PIFG_CDPRODUTOANP,
         IFG_DSPRODUTOANP = PIFG_DSPRODUTOANP,
         IFG_PEGLP        = PIFG_PEGLP,
         IFG_PEGNN        = PIFG_PEGNN,
         IFG_PEGNI        = PIFG_PEGNI,
         IFG_VLPARTIDA    = PIFG_VLPARTIDA,
         IFG_DTINCLUSAO   = NVL(PIFG_DTINCLUSAO, SYSDATE),
         IFG_USINCLUSAO   = NVL(PIFG_USINCLUSAO, GET_USER_MXM),
         IFG_DTALTERACAO  = NVL(PIFG_DTALTERACAO, SYSDATE),
         IFG_USALTERACAO  = NVL(PIFG_USALTERACAO, GET_USER_MXM)
   WHERE IFG_IDIFATGLP = PIFG_IDIFATGLP;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCFATIFATGLP_IFG
(
  PIFG_IDIFATGLP IN NUMBER
)
AS
BEGIN
  DELETE FROM FATIFATGLP_IFG
   WHERE IFG_IDIFATGLP = PIFG_IDIFATGLP;
END;
/

CREATE TABLE FATRELFFPCPGTPC_CTF
(
  CTF_IDRELCPGTPCFFP      NUMBER(9) NOT NULL,
  CTF_CDEMPRESA           VARCHAR2(4) NOT NULL,
  CTF_CDFILIAL            VARCHAR2(4) NOT NULL,
  CTF_CDTPENUMFORMAPAGTO  VARCHAR2(50) NOT NULL,
  CTF_VLTPENUMFORMAPAGTO  VARCHAR2(20) NOT NULL,
  CTF_CDCONDPAGTO         VARCHAR2(2) NOT NULL,
  CTF_CDTPCOBRANCA        VARCHAR2(2) NOT NULL,
  CTF_VBINATIVACAO        CHAR(1) DEFAULT 'N' NOT NULL,
  CTF_DHINATIVACAO        DATE,
  CTF_USINATIVACAO        VARCHAR2(40),
  CTF_DTINCLUSAO          DATE NOT NULL,
  CTF_USINCLUSAO          VARCHAR2(40) NOT NULL,
  CTF_DTALTERACAO         DATE,
  CTF_USALTERACAO         VARCHAR2(40)
)
/

COMMENT ON TABLE FATRELFFPCPGTPC_CTF IS 'Tabela de Relacionamento de Forma de Pagamento com Condi��o de Pagamento/Tipo de Cobran�a'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_IDRELCPGTPCFFP IS 'Identificador do registro de relacionamento de Forma de Pagamento com Condi��o de Pagamento/Tipo de Cobran�a'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_CDEMPRESA IS 'C�digo da Empresa'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_CDFILIAL IS 'C�digo da Filial'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_CDTPENUMFORMAPAGTO IS 'Enumerado da Forma de Pagamento'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_VLTPENUMFORMAPAGTO IS 'Valor do Enumerado da Forma de Pagamento'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_CDCONDPAGTO IS 'Condi��o de Pagamento'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_CDTPCOBRANCA IS 'Tipo de Cobran�a'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_VBINATIVACAO IS 'Flag de inativa��o do registro'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_DHINATIVACAO IS 'Data de inativa��o do registro'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_USINATIVACAO IS 'Usu�rio de inativa��o do registro'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_DTINCLUSAO IS 'Data de inclus�o do registro'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_USINCLUSAO IS 'Usu�rio de inclus�o do registro'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_DTALTERACAO IS 'Data de altera��o do registro'
/

COMMENT ON COLUMN FATRELFFPCPGTPC_CTF.CTF_USALTERACAO IS 'Usu�rio de altera��o do registro'
/

ALTER TABLE FATRELFFPCPGTPC_CTF
  ADD CONSTRAINT PK_FATRELFFPCPGTPC_CTF
  PRIMARY KEY (CTF_IDRELCPGTPCFFP)
/

ALTER TABLE FATRELFFPCPGTPC_CTF
  ADD CONSTRAINT UN1_FATRELFFPCPGTPC_CTF
  UNIQUE (CTF_CDEMPRESA, CTF_CDFILIAL, CTF_CDCONDPAGTO, CTF_CDTPCOBRANCA, CTF_VBINATIVACAO, CTF_DHINATIVACAO, CTF_USINATIVACAO)
/

ALTER TABLE FATRELFFPCPGTPC_CTF
  ADD CONSTRAINT FK1_FATRELFFPCPGTPC_CTF
  FOREIGN KEY (CTF_CDEMPRESA, CTF_CDFILIAL)
  REFERENCES EMPEND_EEN (EEN_CODIGO, EEN_CDEND)
/

ALTER TABLE FATRELFFPCPGTPC_CTF
  ADD CONSTRAINT FK2_FATRELFFPCPGTPC_CTF
  FOREIGN KEY (CTF_CDTPENUMFORMAPAGTO, CTF_VLTPENUMFORMAPAGTO)
  REFERENCES TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO)
/

ALTER TABLE FATRELFFPCPGTPC_CTF
  ADD CONSTRAINT FK3_FATRELFFPCPGTPC_CTF
  FOREIGN KEY (CTF_CDCONDPAGTO)
  REFERENCES CONDPAG_CPG (CPG_CODIGO)
/

ALTER TABLE FATRELFFPCPGTPC_CTF
  ADD CONSTRAINT FK4_FATRELFFPCPGTPC_CTF
  FOREIGN KEY (CTF_CDTPCOBRANCA)
  REFERENCES TPCOBR_TCP (TCP_CDTPCOBR)
/

CREATE INDEX IN1_FATRELFFPCPGTPC_CTF ON FATRELFFPCPGTPC_CTF (CTF_CDTPENUMFORMAPAGTO, CTF_VLTPENUMFORMAPAGTO)
/

CREATE INDEX IN2_FATRELFFPCPGTPC_CTF ON FATRELFFPCPGTPC_CTF (CTF_CDCONDPAGTO)
/

CREATE INDEX IN3_FATRELFFPCPGTPC_CTF ON FATRELFFPCPGTPC_CTF (CTF_CDTPCOBRANCA)
/

CREATE SEQUENCE SEQ1_FATRELFFPCPGTPC_CTF
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

CREATE OR REPLACE PROCEDURE PRC_INSFATRELFFPCPGTPC_CTF
(
  PCTF_IDRELCPGTPCFFP      IN OUT NUMBER,
  PCTF_CDEMPRESA           IN CHAR,
  PCTF_CDFILIAL            IN CHAR,
  PCTF_CDTPENUMFORMAPAGTO  IN CHAR,
  PCTF_VLTPENUMFORMAPAGTO  IN CHAR,
  PCTF_CDCONDPAGTO         IN CHAR,
  PCTF_CDTPCOBRANCA        IN CHAR,
  PCTF_VBINATIVACAO        IN CHAR,
  PCTF_DHINATIVACAO        IN DATE DEFAULT NULL,
  PCTF_USINATIVACAO        IN CHAR DEFAULT NULL,
  PCTF_DTINCLUSAO          IN DATE,
  PCTF_USINCLUSAO          IN CHAR,
  PCTF_DTALTERACAO         IN DATE,
  PCTF_USALTERACAO         IN CHAR
) AS
BEGIN
  IF PCTF_IDRELCPGTPCFFP IS NULL THEN
    SELECT SEQ1_FATRELFFPCPGTPC_CTF.NEXTVAL
      INTO PCTF_IDRELCPGTPCFFP
      FROM DUAL;
  END IF;
  INSERT INTO FATRELFFPCPGTPC_CTF
    (CTF_IDRELCPGTPCFFP,
     CTF_CDEMPRESA,
     CTF_CDFILIAL,
     CTF_CDTPENUMFORMAPAGTO,
     CTF_VLTPENUMFORMAPAGTO,
     CTF_CDCONDPAGTO,
     CTF_CDTPCOBRANCA,
     CTF_VBINATIVACAO,
     CTF_DHINATIVACAO,
     CTF_USINATIVACAO,
     CTF_DTINCLUSAO,
     CTF_USINCLUSAO,
     CTF_DTALTERACAO,
     CTF_USALTERACAO)
  VALUES
    (PCTF_IDRELCPGTPCFFP,
     PCTF_CDEMPRESA,
     PCTF_CDFILIAL,
     PCTF_CDTPENUMFORMAPAGTO,
     PCTF_VLTPENUMFORMAPAGTO,
     PCTF_CDCONDPAGTO,
     PCTF_CDTPCOBRANCA,
     PCTF_VBINATIVACAO,
     PCTF_DHINATIVACAO,
     PCTF_USINATIVACAO,
     NVL(PCTF_DTINCLUSAO, SYSDATE),
     NVL(PCTF_USINCLUSAO, GET_USER_MXM),
     NULL,
     NULL);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATRELFFPCPGTPC_CTF
(
  PCTF_IDRELCPGTPCFFP      IN NUMBER,
  PCTF_CDEMPRESA           IN CHAR,
  PCTF_CDFILIAL            IN CHAR,
  PCTF_CDTPENUMFORMAPAGTO  IN CHAR,
  PCTF_VLTPENUMFORMAPAGTO  IN CHAR,
  PCTF_CDCONDPAGTO         IN CHAR,
  PCTF_CDTPCOBRANCA        IN CHAR,
  PCTF_VBINATIVACAO        IN CHAR,
  PCTF_DHINATIVACAO        IN DATE DEFAULT NULL,
  PCTF_USINATIVACAO        IN CHAR DEFAULT NULL,
  PCTF_DTINCLUSAO          IN DATE,
  PCTF_USINCLUSAO          IN CHAR,
  PCTF_DTALTERACAO         IN DATE,
  PCTF_USALTERACAO         IN CHAR
) AS
BEGIN
  UPDATE FATRELFFPCPGTPC_CTF
     SET CTF_CDEMPRESA           = PCTF_CDEMPRESA,
         CTF_CDFILIAL            = PCTF_CDFILIAL,
         CTF_CDTPENUMFORMAPAGTO  = PCTF_CDTPENUMFORMAPAGTO,
         CTF_VLTPENUMFORMAPAGTO  = PCTF_VLTPENUMFORMAPAGTO,
         CTF_CDCONDPAGTO         = PCTF_CDCONDPAGTO,
         CTF_CDTPCOBRANCA        = PCTF_CDTPCOBRANCA,
         CTF_VBINATIVACAO        = PCTF_VBINATIVACAO,
         CTF_DHINATIVACAO        = PCTF_DHINATIVACAO,
         CTF_USINATIVACAO        = PCTF_USINATIVACAO,
         CTF_DTINCLUSAO          = DECODE(CTF_DTINCLUSAO, NULL, NVL(PCTF_DTINCLUSAO, SYSDATE), CTF_DTINCLUSAO),
         CTF_USINCLUSAO          = DECODE(CTF_USINCLUSAO, NULL, NVL(PCTF_USINCLUSAO, GET_USER_MXM), CTF_USINCLUSAO),
         CTF_DTALTERACAO         = NVL(PCTF_DTALTERACAO, SYSDATE),
         CTF_USALTERACAO         = NVL(PCTF_USALTERACAO, GET_USER_MXM)
   WHERE CTF_IDRELCPGTPCFFP = PCTF_IDRELCPGTPCFFP;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCFATRELFFPCPGTPC_CTF
(
  PCTF_IDRELCPGTPCFFP IN NUMBER
) AS
BEGIN
  DELETE FROM FATRELFFPCPGTPC_CTF
   WHERE CTF_IDRELCPGTPCFFP = PCTF_IDRELCPGTPCFFP;
END;
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27484, 'Informa��o de Data de Fabrica��o/Produ��o de Lote/S�rie', 'Informa��o de Data de Fabrica��o/Produ��o de Lote/S�rie')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGE', 27484, 15, 2000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27484, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27484, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27484, 'EXC')
/

INSERT INTO ERROMSG_ERM VALUES('FRF0016', 'Modelo do documento referenciado inv�lido.')
/

INSERT INTO ERROMSG_ERM VALUES('FFP0010', 'Valor recebido obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES('FFP0011', 'Valor recebido tem que ser maior que zero.')
/

INSERT INTO ERROMSG_ERM VALUES('FFP0012', 'Valor do troco tem que ser maior que zero.')
/

INSERT INTO ERROMSG_ERM VALUES('IDFL0001', 'A informa��o do c�digo do produto � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES('IDFL0002', 'C�digo do produto inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES('IDFL0003', 'Sequencial de lote/s�rie inicial inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES('IDFL0004', 'Sequencial de lote/s�rie final inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES('IDFL0005', 'Informa��o de sequencial de lote/s�rie ou inv�lido.')
/

INSERT INTO ERROMSG_ERM VALUES('IDFL0006', 'A informa��o da Data de Fabrica��o/Produ��o � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES('IDFL0007', 'Lote/s�rie inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES('IDFL0008', 'Nenhum registro a ser processado.')
/

INSERT INTO ERROMSG_ERM VALUES ('IDFL0009', 'Processo conclu�do com �xito.')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0021', 'Valor de partida obrigat�rio para o c�digo ANP "210203001 � GLP"')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0022', 'N�o � permitido informar percentual do GLP para c�digo ANP diferente de �210203001 � GLP�')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0023', 'N�o � permitido informar percentual de G�s Natural Nacional para c�digo ANP diferente de �210203001 � GLP�')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0024', 'N�o � permitido informar percentual de G�s Natural Importado para c�digo ANP diferente de �210203001 � GLP�')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0025', 'C�digo de produto ANP inexistente.')
/

UPDATE ERROMSG_ERM
   SET ERM_DSERRO = 'Deve ser inforrmada uma Forma de Pagamento.'
 WHERE ERM_CDERRO = 'FAT0133'
/

INSERT INTO JANELAJUDA_JAJU (JAJU_ARQUIVO, JAJU_CODIGO, JAJU_TAMANHO, JAJU_NUMCAMPO, JAJU_COMPRIMENTO, JAJU_PROCURA, JAJU_NOMEPROCURA, JAJU_TODOS, JAJU_DSFROM, JAJU_DSWHERE, JAJU_DSGROUPBY, JAJU_DSORDERBY)
VALUES ('SGETPPRODANVISA_TPA', 'TP2', 535, 'TPA_CDTPPRODANVISA', 300, 'TPA_DSTPPRODANVISA', 'Descri��o', 'S', '', '', '', '')
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('TP2', '001', 'TPA_CDTPPRODANVISA', 'C�digo', '', '')
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('TP2', '002', 'TPA_DSTPPRODANVISA', 'Descri��o', '', '')
/

INSERT INTO JANELAJUDA_JAJU (JAJU_ARQUIVO, JAJU_CODIGO, JAJU_TAMANHO, JAJU_NUMCAMPO, JAJU_COMPRIMENTO, JAJU_PROCURA, JAJU_NOMEPROCURA, JAJU_TODOS, JAJU_DSFROM, JAJU_DSWHERE, JAJU_DSGROUPBY, JAJU_DSORDERBY)
VALUES ('SGEESTERILANVISA_CEA', 'CE2', 535, 'CEA_CDESTERILANVISA', 300, 'CEA_DSESTERILANVISA', 'Descri��o', 'S', '', '', '', '')
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('CE2', '001', 'CEA_CDESTERILANVISA', 'C�digo', '', '')
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('CE2', '002', 'CEA_DSESTERILANVISA', 'Descri��o', '', '')
/

INSERT INTO JANELAJUDA_JAJU (JAJU_ARQUIVO, JAJU_CODIGO, JAJU_TAMANHO, JAJU_NUMCAMPO, JAJU_COMPRIMENTO, JAJU_PROCURA, JAJU_NOMEPROCURA, JAJU_TODOS, JAJU_DSFROM, JAJU_DSWHERE, JAJU_DSGROUPBY, JAJU_DSORDERBY)
VALUES ('SGEREGANVISA_REA', 'RE2', 535, 'REA_CDREGANVISA', 300, 'REA_DSREGANVISA', 'Descri��o', 'S', '', '', '', '')
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('RE2', '001', 'REA_CDREGANVISA', 'C�digo', '', '')
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('RE2', '002', 'REA_DSREGANVISA', 'Descri��o', '', '')
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (11818, 'Tipo de Produto ANVISA/MS', 'Tipo de Produto ANVISA/MS')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGE', 11818, 1, 11531)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11818, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11818, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11818, 'EXC')
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (11819, 'Esteriliza��o ANVISA/MS', 'Esteriliza��o ANVISA/MS')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGE', 11819, 2, 11531)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11819, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11819, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11819, 'EXC')
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (11820, 'Registro Anvisa/MS', 'Registro Anvisa/MS')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGE', 11820, 3, 11531)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11820, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11820, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11820, 'EXC')
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (11821, 'Relacionamento entre Registro ANVISA/MS e Produto', 'Relacionamento entre Registro ANVISA/MS e Produto')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGE', 11821, 4, 11531)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11821, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11821, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11821, 'EXC')
/

ALTER TABLE ITFATLOTESERIE_IFLS ADD IFLS_DTFABRICACAO DATE
/

COMMENT ON COLUMN ITFATLOTESERIE_IFLS.IFLS_DTFABRICACAO IS 'Data de fabrica��o/produ��o do lote/s�rie'
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27491, 'Informa��o de data de fabrica��o/produ��o de lote/s�rie', 'Informa��o de data de fabrica��o/produ��o de lote/s�rie')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGE', 27491, 29, 2000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27491, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27491, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27491, 'EXC')
/

INSERT INTO JANELAJUDA_JAJU (JAJU_ARQUIVO, JAJU_CODIGO, JAJU_TAMANHO, JAJU_NUMCAMPO, JAJU_COMPRIMENTO, JAJU_PROCURA, JAJU_NOMEPROCURA, JAJU_TODOS, JAJU_DSFROM, JAJU_DSWHERE, JAJU_DSGROUPBY, JAJU_DSORDERBY)
VALUES ('FATRELFFPCPGTPC_CTF', 'CTF', 535, 'CTF_IDRELCPGTPCFFP', 250, 'TENU_DESCRICAO', 'Desc. Forma Pagto', 'S', null, null, null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('CTF', '000', 'CTF_IDRELCPGTPCFFP', 'Identificador', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('CTF', '001', 'CTF_CDEMPRESA', 'Empresa', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('CTF', '002', 'CTF_CDFILIAL', 'Filial', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('CTF', '003', 'CTF_VLTPENUMFORMAPAGTO', 'Forma Pagamento', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('CTF', '004', 'TENU_DESCRICAO', 'Desc. Forma Pagto', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('CTF', '005', 'CTF_CDCONDPAGTO', 'Condi��o Pagamento', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('CTF', '006', 'CTF_CDTPCOBRANCA', 'Tipo Cobran�a', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('CTF', '007', 'CTF_VBINATIVACAO', 'Inativo', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('CTF', '008', 'CTF_DHINATIVACAO', 'Data Inativo', null, null)
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (11827, 'Relacionamento entre Forma de Pagamento, Condi��o de Pagamento e Tipo de Cobran�a', 'Relacionamento entre Forma de Pagamento, Condi��o de Pagamento e Tipo de Cobran�a')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SF', 11827, 11, 10793)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11827, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11827, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11827, 'EXC')
/

ALTER TABLE COLNOTAFISCAL_CNF MODIFY CNF_DSCAMPO VARCHAR2(300)
/

DECLARE
 VCNF_SQCAMPO NUMBER;
 PRIMEIRO     NUMBER;
 ULTIMO       NUMBER;
BEGIN
  VCNF_SQCAMPO := 200000;
  PRIMEIRO     := VCNF_SQCAMPO;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Id - Identificador da TAG a ser assinada  <infNFe><id>', 0, 'infNFe_id', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B02 - C�digo da UF do emitente do Documento Fiscal  <infNFe><ide><cUF>', 0, 'infNFe_ide_cUF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B03 - C�digo Num�rico que comp�e a Chave de Acesso  <infNFe><ide><cNF>', 0, 'infNFe_ide_cNF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B04 - Descri��o da Natureza da Opera��o  <infNFe><ide><natOp>', 0, 'infNFe_ide_natOp', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B05 - Indicador da forma de pagamento  <infNFe><ide><indPag>', 0, 'infNFe_ide_indPag', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B06 - C�digo do Modelo do Documento Fiscal  <infNFe><ide><mod>', 0, 'infNFe_ide_mod', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B07 - S�rie do Documento Fiscal  <infNFe><ide><serie>', 0, 'infNFe_ide_serie', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B08 - N�mero do Documento Fiscal  <infNFe><ide><nNF>', 0, 'infNFe_ide_nNF', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B09 - Data de emiss�o do Documento Fiscal  <infNFe><ide><dEmi>', 0, 'infNFe_ide_dEmi', 2, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B10 - Data de Sa�da ou da Entrada da MercadoriaProduto  <infNFe><ide><dSaiEnt>', 0, 'infNFe_ide_dSaiEnt', 2, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B10a - Hora de Sa�da ou da Entrada da MercadoriaProduto  <infNFe><ide><hSaiEnt>', 0, 'infNFe_ide_hSaiEnt', 2, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B11 - Tipo de Opera��o  <infNFe><ide><tpNF>', 0, 'infNFe_ide_tpNF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B12 - C�digo do Munic�pio de Ocorr�ncia do Fato Gerador  <infNFe><ide><cMunFG>', 0, 'infNFe_ide_cMunFG', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B12a - Grupo de informa��o das NF/NFe referenciadas - NFref <infNFe><ide><NFref>', 0, 'infNFe_ide_NFref', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B21 - Formato de Impress�o do DANFE  <infNFe><ide><tpImp>', 0, 'infNFe_ide_tpImp', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B22 - Tipo de Emiss�o da NF-e  <infNFe><ide><tpEmis>', 0, 'infNFe_ide_tpEmis', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B23 - D�gito Verificador da Chave de Acesso da NF-e  <infNFe><ide><cDV>', 0, 'infNFe_ide_cDV', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B24 - Identifica��o do Ambiente  <infNFe><ide><tpAmb>', 0, 'infNFe_ide_tpAmb', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B25 - Identifica��o do Ambiente  <infNFe><ide><finNFe>', 0, 'infNFe_ide_finNFe', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B26 - Processo de emiss�o da NF-e  <infNFe><ide><procEmi>', 0, 'infNFe_ide_procEmi', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B27 - Vers�o do Processo de emiss�o da NF-e  <infNFe><ide><verProc>', 0, 'infNFe_ide_verProc', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B28 - Data e Hora da entrada em conting�ncia  <infNFe><ide><dhCont>', 0, 'infNFe_ide_dhCont', 2, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'B29 - Justificativa da entrada em conting�ncia  <infNFe><ide><xJust>', 0, 'infNFe_ide_xJust', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C02 - CNPJ do emitente  <infNFe><emit><CNPJ>', 0, 'infNFe_emit_CNPJ', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C02a - CPF do remetente  <infNFe><emit><CPF>', 0, 'infNFe_emit_CPF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C03 - Raz�o Social ou Nome do emitente  <infNFe><emit><xNome>', 0, 'infNFe_emit_xNome', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C04 - Nome fantasia  <infNFe><emit><xFant>', 0, 'infNFe_emit_xFant', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C06 - Logradouro  <infNFe><emit><enderEmit><xLgr>', 0, 'infNFe_emit_enderEmit_xLgr', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C07 - N�mero  <infNFe><emit><enderEmit><nro>', 0, 'infNFe_emit_enderEmit_nro', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C08 - Complemento  <infNFe><emit><enderEmit><xCpl>', 0, 'infNFe_emit_enderEmit_xCpl', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C09 - Bairro  <infNFe><emit><enderEmit><xBairro>', 0, 'infNFe_emit_enderEmit_xBairro', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C10 - C�digo do munic�pio  <infNFe><emit><enderEmit><cMun>', 0, 'infNFe_emit_enderEmit_cMun', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C11 - Nome do munic�pio  <infNFe><emit><enderEmit><xMun>', 0, 'infNFe_emit_enderEmit_xMun', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C12 - Sigla da UF  <infNFe><emit><enderEmit><UF>', 0, 'infNFe_emit_enderEmit_UF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C13 - C�digo do CEP  <infNFe><emit><enderEmit><CEP>', 0, 'infNFe_emit_enderEmit_CEP', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C14 - C�digo do Pa�s  <infNFe><emit><enderEmit><cPais>', 0, 'infNFe_emit_enderEmit_cPais', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C15 - Nome do Pa�s  <infNFe><emit><enderEmit><xPais>', 0, 'infNFe_emit_enderEmit_xPais', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C16 - Telefone  <infNFe><emit><enderEmit><fone>', 0, 'infNFe_emit_enderEmit_fone', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C17 - IE  <infNFe><emit><IE>', 0, 'infNFe_emit_IE', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C18 - IE do Substituto Tribut�rio  <infNFe><emit><IEST>', 0, 'infNFe_emit_IEST', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C19 - Inscri��o Municipal  <infNFe><emit><IM>', 0, 'infNFe_emit_IM', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C20 - CNAE fiscal  <infNFe><emit><CNAE>', 0, 'infNFe_emit_CNAE', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'C21 - C�digo de Regime Tribut�rio  <infNFe><emit><CRT>', 0, 'infNFe_emit_CRT', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'D02 - CNPJ do �rg�o emitente  <infNFe><avulsa><CNPJ>', 0, 'infNFe_avulsa_CNPJ', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'D03 - �rg�o emitente  <infNFe><avulsa><xOrgao>', 0, 'infNFe_avulsa_xOrgao', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'D04 - Matr�cula do agente  <infNFe><avulsa><matr>', 0, 'infNFe_avulsa_matr', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'D05 - Nome do agente  <infNFe><avulsa><xAgente>', 0, 'infNFe_avulsa_xAgente', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'D06 - Telefone  <infNFe><avulsa><fone>', 0, 'infNFe_avulsa_fone', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'D07 - Sigla da UF  <infNFe><avulsa><UF>', 0, 'infNFe_avulsa_UF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'D08 - N�mero do Documento de Arrecada��o de Receita  <infNFe><avulsa><nDAR>', 0, 'infNFe_avulsa_nDAR', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'D09 - Data de emiss�o do Documento de Arrecada��o  <infNFe><avulsa><dEmi>', 0, 'infNFe_avulsa_dEmi', 2, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'D10 - Valor Total constante no Documento de arrecada��o de Receita  <infNFe><avulsa><vDAR>', 0, 'infNFe_avulsa_vDAR', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'D11 - Reparti��o Fiscal emitente  <infNFe><avulsa><repEmi>', 0, 'infNFe_avulsa_repEmi', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'D12 - Data de pagamento do Documento de Arrecada��o  <infNFe><avulsa><dPag>', 0, 'infNFe_avulsa_dPag', 2, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E02 - CNPJ do destinat�rio  <infNFe><dest><CNPJ>', 0, 'infNFe_dest_CNPJ', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E03 - CPF do destinat�rio  <infNFe><dest><CPF>', 0, 'infNFe_dest_CPF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E04 - Raz�o Social ou nome do destinat�rio  <infNFe><dest><xNome>', 0, 'infNFe_dest_xNome', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E06 - Logradouro  <infNFe><dest><EnderDest><xLgr>', 0, 'infNFe_dest_EnderDest_xLgr', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E07 - N�mero  <infNFe><dest><EnderDest><nro>', 0, 'infNFe_dest_EnderDest_nro', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E08 - Complemento  <infNFe><dest><EnderDest><xCpl>', 0, 'infNFe_dest_EnderDest_xCpl', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E09 - Bairro  <infNFe><dest><EnderDest><xBairro>', 0, 'infNFe_dest_EnderDest_xBairro', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E10 - C�digo do munic�pio  <infNFe><dest><EnderDest><cMun>', 0, 'infNFe_dest_EnderDest_cMun', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E11 - Nome do munic�pio  <infNFe><dest><EnderDest><xMun>', 0, 'infNFe_dest_EnderDest_xMun', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E12 - Sigla da UF  <infNFe><dest><EnderDest><UF>', 0, 'infNFe_dest_EnderDest_UF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E13 - C�digo do CEP  <infNFe><dest><EnderDest><CEP>', 0, 'infNFe_dest_EnderDest_CEP', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E14 - C�digo do Pa�s  <infNFe><dest><EnderDest><cPais>', 0, 'infNFe_dest_EnderDest_cPais', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E15 - Nome do Pa�s  <infNFe><dest><EnderDest><xPais>', 0, 'infNFe_dest_EnderDest_xPais', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E16 - Telefone  <infNFe><dest><EnderDest><fone>', 0, 'infNFe_dest_EnderDest_fone', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E17 - IE  <infNFe><dest><IE>', 0, 'infNFe_dest_IE', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E18 - Inscri��o na SUFRAMA  <infNFe><dest><ISUF>', 0, 'infNFe_dest_ISUF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'E19 - email  <infNFe><dest><email>', 0, 'infNFe_dest_email', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'F01 - Grupo de identifica��o do Local de retirada', 0, 'infNFe_retirada', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'F02 - CNPJ  <infNFe><retirada><CNPJ>', 0, 'infNFe_retirada_CNPJ', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'F02a - CPF  <infNFe><retirada><CPF>', 0, 'infNFe_retirada_CPF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'F03 - Logradouro  <infNFe><retirada><xLgr>', 0, 'infNFe_retirada_xLgr', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'F04 - N�mero  <infNFe><retirada><nro>', 0, 'infNFe_retirada_nro', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'F05 - Complemento  <infNFe><retirada><xCpl>', 0, 'infNFe_retirada_xCpl', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'F06 - Bairro  <infNFe><retirada><xBairro>', 0, 'infNFe_retirada_xBairro', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'F07 - C�digo do munic�pio  <infNFe><retirada><cMun>', 0, 'infNFe_retirada_cMun', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'F08 - Nome do munic�pio  <infNFe><retirada><xMun>', 0, 'infNFe_retirada_xMun', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'F09 - Sigla da UF  <infNFe><retirada><UF>', 0, 'infNFe_retirada_UF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'G01 - Grupo de identifica��o do Local de entrega <infNFe><entrega>', 0, 'infNFe_entrega', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'G02 - CNPJ  <infNFe><entrega><CNPJ>', 0, 'infNFe_entrega_CNPJ', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'G02a - CPF  <infNFe><entrega><CPF>', 0, 'infNFe_entrega_CPF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'G03 - Logradouro  <infNFe><entrega><xLgr>', 0, 'infNFe_entrega_xLgr', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'G04 - N�mero  <infNFe><entrega><nro>', 0, 'infNFe_entrega_nro', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'G05 - Complemento  <infNFe><entrega><xCpl>', 0, 'infNFe_entrega_xCpl', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'G06 - Bairro  <infNFe><entrega><xBairro>', 0, 'infNFe_entrega_xBairro', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'G07 - C�digo do munic�pio   <infNFe><entrega><cMun>', 0, 'infNFe_entrega_cMun', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'G08 - Nome do munic�pio  <infNFe><entrega><xMun>', 0, 'infNFe_entrega_xMun', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'G09 - Sigla da UF  <infNFe><entrega><UF>', 0, 'infNFe_entrega_UF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'H02 - N�mero do item   <infNFe><det><nItem>', 1, 'infNFe_det_nItem', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I02 - C�digo do produto ou servi�o  <infNFe><det><prod><cProd>', 1, 'infNFe_det_prod_cProd', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I03 - GTIN  <infNFe><det><prod><cEAN>', 1, 'infNFe_det_prod_cEAN', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I04 - Descri��o do produto ou servi�o <infNFe><det><prod><xProd>', 1, 'infNFe_det_prod_xProd', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I05 - C�digo NCM com 8 d�gitos ou 2 d�gitos <infNFe><det><prod><NCM>', 1, 'infNFe_det_prod_NCM', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I05d Indicador de Escala Relevante <infNFe><det><prod><indEscala>', 1, 'infNFe_det_prod_indEscala', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I05e Indicador de Escala Relevante <infNFe><det><prod><CNPJFab>', 1, 'infNFe_det_prod_CNPJFab', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I05f C�digo de Benef�cio Fiscal na UF aplicado ao item <infNFe><det><prod><cBenef>', 1, 'infNFe_det_prod_cBenef', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I06 - EX_TIPI  <infNFe><det><prod><EXTIPI>', 1, 'infNFe_det_prod_EXTIPI', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I08 - C�digo Fiscal de Opera��es e Presta��es  <infNFe><det><prod><CFOP>', 1, 'infNFe_det_prod_CFOP', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I09 - Unidade Comercial  <infNFe><det><prod><uCom>', 1, 'infNFe_det_prod_uCom', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I10 - Quantidade Comercial  <infNFe><det><prod><qCom>', 1, 'infNFe_det_prod_qCom', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I10a - Valor Unit�rio de Comercializa��o  <infNFe><det><prod><vUnCom>', 1, 'infNFe_det_prod_vUnCom', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I11 - Valor Total Bruto dos Produtos ou Servi�os  <infNFe><det><prod><vProd>', 1, 'infNFe_det_prod_vProd', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I12 - GTIN  da unid. tribut., antigo c�d. EAN ou c�d. de barras  <infNFe><det><prod><cEANTrib>', 1, 'infNFe_det_prod_cEANTrib', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I13 - Unidade Tribut�vel  <infNFe><det><prod><uTrib>', 1, 'infNFe_det_prod_uTrib', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I14 - Quantidade Tribut�vel  <infNFe><det><prod><qTrib>', 1, 'infNFe_det_prod_qTrib', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I14a - Valor Unit�rio de tributa��o  <infNFe><det><prod><vUnTrib>', 1, 'infNFe_det_prod_vUnTrib', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I15 - Valor Total do Frete   <infNFe><det><prod><vFrete>', 1, 'infNFe_det_prod_vFrete', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I16 - Valor Total do Seguro  <infNFe><det><prod><vSeg>', 1, 'infNFe_det_prod_vSeg', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I17 - Valor do Desconto  <infNFe><det><prod><vDesc>', 1, 'infNFe_det_prod_vDesc', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I17a - Outras despesas acess�rias  <infNFe><det><prod><vOutro>', 1, 'infNFe_det_prod_vOutro', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I17b - Indica val. do Item (vProd) entra no val. total da NF-e(vProd)  <infNFe><det><prod><indTot>', 1, 'infNFe_det_prod_indTot', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I18 - Declara��o de Importa��o <infNFe><det><prod><DI>', 1, 'infNFe_det_prod_DI', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I30 - N�mero do Pedido de Compra  <infNFe><det><prod><xPed>', 1, 'infNFe_det_prod_xPed', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I31 - Item do Pedido de Compra  <infNFe><det><prod><nItemPed>', 1, 'infNFe_det_prod_nItemPed', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'I80 - Rastreabilidade de produto <infNFe><det><prod><rastro>', 1, 'infNFe_det_prod_rastro', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J02 - Tipo da opera��o  <infNFe><det><prod><veicProd><tpOp>', 1, 'infNFe_det_prod_veicProd_tpOp', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J03 - Chassi do ve�culo  <infNFe><det><prod><veicProd><chassi>', 1, 'infNFe_det_prod_veicProd_chassi', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J04 - Cor  <infNFe><det><prod><veicProd><cCor>', 1, 'infNFe_det_prod_veicProd_cCor', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J05 - Descri��o da Cor  <infNFe><det><prod><veicProd><xCor>', 1, 'infNFe_det_prod_veicProd_xCor', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J06 - Pot�ncia Motor (CV)  <infNFe><det><prod><veicProd><pot>', 1, 'infNFe_det_prod_veicProd_pot', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J07 - Cilindradas  <infNFe><det><prod><veicProd><cilin>', 1, 'infNFe_det_prod_veicProd_cilin', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J08 - Peso L�quido  <infNFe><det><prod><veicProd><pesoL>', 1, 'infNFe_det_prod_veicProd_pesoL', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J09 - Peso Bruto  <infNFe><det><prod><veicProd><pesoB>', 1, 'infNFe_det_prod_veicProd_pesoB', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J10 - Serial (s�rie)  <infNFe><det><prod><veicProd><nSerie>', 1, 'infNFe_det_prod_veicProd_nSerie', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J11 - Tipo de combust�vel  <infNFe><det><prod><veicProd><tpComb>', 1, 'infNFe_det_prod_veicProd_tpComb', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J12 - N�mero de Motor  <infNFe><det><prod><veicProd><nMotor>', 1, 'infNFe_det_prod_veicProd_nMotor', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J13 - Capacidade M�xima de Tra��o  <infNFe><det><prod><veicProd><CMT>', 1, 'infNFe_det_prod_veicProd_CMT', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J14 - Dist�ncia entre eixos  <infNFe><det><prod><veicProd><dist>', 1, 'infNFe_det_prod_veicProd_dist', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J16 - Ano Modelo de Fabrica��o  <infNFe><det><prod><veicProd><anoMod>', 1, 'infNFe_det_prod_veicProd_anoMod', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J17 - Ano de Fabrica��o   <infNFe><det><prod><veicProd><anoFab>', 1, 'infNFe_det_prod_veicProd_anoFab', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J18 - Tipo de Pintura  <infNFe><det><prod><veicProd><tpPint>', 1, 'infNFe_det_prod_veicProd_tpPint', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J19 - Tipo de Ve�culo   <infNFe><det><prod><veicProd><tpVeic>', 1, 'infNFe_det_prod_veicProd_tpVeic', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J20 - Esp�cie de Ve�culo  <infNFe><det><prod><veicProd><espVeic>', 1, 'infNFe_det_prod_veicProd_espVeic', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J21 - Condi��o do VIN  <infNFe><det><prod><veicProd><VIN>', 1, 'infNFe_det_prod_veicProd_VIN', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J22 - Condi��o do Ve�culo  <infNFe><det><prod><veicProd><condVeic>', 1, 'infNFe_det_prod_veicProd_condVeic', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J23 - C�digo Marca Modelo  <infNFe><det><prod><veicProd><cMod>', 1, 'infNFe_det_prod_veicProd_cMod', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J24 - C�digo da Cor  <infNFe><det><prod><veicProd><cCorDENATRAN>', 1, 'infNFe_det_prod_veicProd_cCorDENATRAN', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J25 - Capacidade m�xima de lota��o  <infNFe><det><prod><veicProd><lota>', 1, 'infNFe_det_prod_veicProd_lota', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'J26 - Restri��o  <infNFe><det><prod><veicProd><tpRest>', 1, 'infNFe_det_prod_veicProd_tpRest', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'K01 - Grupo do detal. de Medicamentos e de mat�riasprimas farmac�uticas <infNFe><det><prod><med>', 1, 'infNFe_det_prod_med', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'L01 - Grupo do detalhamento de Armamento <infNFe><det><prod><arma>', 1, 'infNFe_det_prod_arma', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA02 - C�digo de produto da ANP <infNFe><det><prod><comb><cProdANP>', 1, 'infNFe_det_prod_comb_cProdANP', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA03 - Descri��o do produto conforme ANP <infNFe><det><prod><comb><descANP>', 1, 'infNFe_det_prod_comb_descANP', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA03a - Percentual do GLP derivado do petr�leo no produto GLP <infNFe><det><prod><comb><pGLP>', 1, 'infNFe_det_prod_comb_pGLP', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA03b - Percentual de G�s Natural Nacional � GLGNn para o produto GLP <infNFe><det><prod><comb><pGNn>', 1, 'infNFe_det_prod_comb_pGNn', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA03c - Percentual de G�s Natural Importado � GLGNi para o produto GLP <infNFe><det><prod><comb><pGNi>', 1, 'infNFe_det_prod_comb_pGNi', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA03d - Valor de partida <infNFe><det><prod><comb><vPart>', 1, 'infNFe_det_prod_comb_vPart', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA04 - C�digo de autoriza��o  registro do CODIF  <infNFe><det><prod><comb><CODIF>', 1, 'infNFe_det_prod_comb_CODIF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA05 - Quantidade de combust�vel faturada � temperatura ambiente.  <infNFe><det><prod><comb><qTemp>', 1, 'infNFe_det_prod_comb_qTemp', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA06 - Sigla da UF de consumo  <infNFe><det><prod><comb><UFCons>', 1, 'infNFe_det_prod_comb_UFCons', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA08 - BC da CIDE  <infNFe><det><prod><comb><CIDE><qBCProd>', 1, 'infNFe_det_prod_comb_CIDE_qBCProd', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA09 - Valor da al�quota da CIDE  <infNFe><det><prod><comb><CIDE><vAliqProd>', 1, 'infNFe_det_prod_comb_CIDE_vAliqProd', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'LA10 - Valor da CIDE  <infNFe><det><prod><comb><CIDE><vCIDE>', 1, 'infNFe_det_prod_comb_CIDE_vCIDE', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'NA03 - Valor da BC do ICMS na UF de destino <infNFe><det><imposto><ICMSUFDest><vBCUFDest>', 0, 'infNFe_det_imposto_ICMSUFDest_vBCUFDest', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'NA04 - Valor da BC FCP na UF de destino <infNFe><det><imposto><ICMSUFDest><vBCFCPUFDest>', 0, 'infNFe_det_imposto_ICMSUFDest_vBCFCPUFDest', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'NA05 - Percentual do ICMS relativo ao Fundo de Combate � Pobreza (FCP) na UF de destino <infNFe><det><imposto><ICMSUFDest><pFCPUFDest>', 1, 'infNFe_det_imposto_ICMSUFDest_pFCPUFDest', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'NA07 - Al�quota interna da UF de destino <infNFe><det><imposto><ICMSUFDest><pICMSUFDest>', 1, 'infNFe_det_imposto_ICMSUFDest_pICMSUFDest', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'NA09 - Al�quota interestadual das UF envolvidas <infNFe><det><imposto><ICMSUFDest><pICMSInter>', 1, 'infNFe_det_imposto_ICMSUFDest_pICMSInter', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'NA11 - Percentual provis�rio de partilha do ICMS Interestadual <infNFe><det><imposto><ICMSUFDest><pICMSInterPart>', 1, 'infNFe_det_imposto_ICMSUFDest_pICMSInterPart', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'NA13 - Valor do ICMS relativo ao Fundo de Combate � Pobreza (FCP) da UF de destino <infNFe><det><imposto><ICMSUFDest><vFCPUFDest>', 1, 'infNFe_det_imposto_ICMSUFDest_vFCPUFDest', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'NA15 - Valor do ICMS Interestadual para a UF de destino <infNFe><det><imposto><ICMSUFDest><vICMSUFDest>', 1, 'infNFe_det_imposto_ICMSUFDest_vICMSUFDest', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'NA17 - Valor do ICMS Interestadual para a UF de destino <infNFe><det><imposto><ICMSUFDest><vICMSUFRemet>', 1, 'infNFe_det_imposto_ICMSUFDest_vICMSUFRemet', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N11 - orig Origem da mercadoria <infNFe><det><imposto><ICMS><orig>', 1, 'infNFe_det_imposto_ICMS_orig', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N12 - Tributa��o do ICMS  <infNFe><det><imposto><ICMS><CST>', 1, 'infNFe_det_imposto_ICMS_CST', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N12a - C�digo de Situa��o da Opera��o � Simples Nacional <infNFe><det><imposto><ICMS><CSOSN>', 1, 'infNFe_det_imposto_ICMS_CSOSN', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N13 - Modalidade de determina��o da BC do ICMS <infNFe><det><imposto><ICMS><modBC>', 1, 'infNFe_det_imposto_ICMS_modBC', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N14 - Percentual da Redu��o de BC <infNFe><det><imposto><ICMS><pRedBC>', 1, 'infNFe_det_imposto_ICMS_pRedBC', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N15 - Valor da BC do ICMS  <infNFe><det><imposto><ICMS><vBC>', 1, 'infNFe_det_imposto_ICMS_vBC', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N16 - Al�quota do imposto <infNFe><det><imposto><ICMS><pICMS>', 1, 'infNFe_det_imposto_ICMS_pICMS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N17 - Valor do ICMS <infNFe><det><imposto><ICMS><vICMS>', 1, 'infNFe_det_imposto_ICMS_vICMS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N17a - Valor da Base de C�lculo <infNFe><det><imposto><ICMS><vBCFCP>', 1, 'infNFe_det_imposto_ICMS_vBCFCP', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N17b - Percentual do Fundo de Combate � Pobreza (FCP) <infNFe><det><imposto><ICMS><pFCP>', 1, 'infNFe_det_imposto_ICMS_pFCP', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N17c - Valor do Fundo de Combate � Pobreza (FCP) <infNFe><det><imposto><ICMS><vFCP>', 1, 'infNFe_det_imposto_ICMS_vFCP', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N18 - Modalidade de determina��o da BC do ICMS ST <infNFe><det><imposto><ICMS><modBCST>', 1, 'infNFe_det_imposto_ICMS_modBCST', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N19 - Percentual da margem de valor Adicionado do ICMS ST <infNFe><det><imposto><ICMS><pMVAST>', 1, 'infNFe_det_imposto_ICMS_pMVAST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N20 - Percentual da Redu��o de BC do ICMS ST <infNFe><det><imposto><ICMS><pRedBCST>', 1, 'infNFe_det_imposto_ICMS_pRedBCST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N21 - Valor da BC do ICMS ST <infNFe><det><imposto><ICMS><vBCST>', 1, 'infNFe_det_imposto_ICMS_vBCST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N22 - Al�quota do imposto do ICMS ST <infNFe><det><imposto><ICMS><pICMSST>', 1, 'infNFe_det_imposto_ICMS_pICMSST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N23 - Valor do ICMS ST <infNFe><det><imposto><ICMS><vICMSST>', 1, 'infNFe_det_imposto_ICMS_vICMSST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N23a - Valor da Base de C�lculo do FCP retido por Substitui��o Tribut�ria <infNFe><det><imposto><ICMS><vBCFCPST>', 1, 'infNFe_det_imposto_ICMS_vBCFCPST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N23b - Percentual do FCP retido por Substitui��o Tribut�ria <infNFe><det><imposto><ICMS><pFCPST>', 1, 'infNFe_det_imposto_ICMS_pFCPST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N23d - Valor do FCP retido por Substitui��o Tribut�ria <infNFe><det><imposto><ICMS><vFCPST>', 1, 'infNFe_det_imposto_ICMS_vFCPST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N24 - UF para qual � devido o ICMS ST <infNFe><det><imposto><ICMS><UFST>', 1, 'infNFe_det_imposto_ICMS_UFST', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N25 - Percentual da BC opera��o pr�pria <infNFe><det><imposto><ICMS><pBCOp>', 1, 'infNFe_det_imposto_ICMS_pBCOp', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N26 - Valor do BC do ICMS ST retido na UF remetente <infNFe><det><imposto><ICMS><vBCSTRet>', 1, 'infNFe_det_imposto_ICMS_vBCSTRet', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N26a - Al�quota suportada pelo Consumidor Final <infNFe><det><imposto><ICMS><pST>', 1, 'infNFe_det_imposto_ICMS_pST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N27 - Valor do ICMS ST retido na UF remetente <infNFe><det><imposto><ICMS><vICMSSTRet>', 1, 'infNFe_det_imposto_ICMS_vICMSSTRet', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N27a - Valor do ICMS ST retido na UF remetente <infNFe><det><imposto><ICMS><vBCFCPSTRet>', 1, 'infNFe_det_imposto_ICMS_vBCFCPSTRet', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N27b - Valor do ICMS ST retido na UF remetente <infNFe><det><imposto><ICMS><pFCPSTRet>', 1, 'infNFe_det_imposto_ICMS_pFCPSTRet', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N27d - Valor do ICMS ST retido na UF remetente <infNFe><det><imposto><ICMS><vFCPSTRet>', 1, 'infNFe_det_imposto_ICMS_vFCPSTRet', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N28 - Motivo da desonera��o do ICMS <infNFe><det><imposto><ICMS><motDesICMS>', 1, 'infNFe_det_imposto_ICMS_motDesICMS', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N29 - Al�q. Aplic. de c�lc. do cr�dito (Simples Nacional) <infNFe><det><imposto><ICMS><pCredSN>', 1, 'infNFe_det_imposto_ICMS_pCredSN', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N30 - Val. cr�d. ICMS pode aprov. term. art. 23 da LC 123 <infNFe><det><imposto><ICMS><vCredICMSSN>', 1, 'infNFe_det_imposto_ICMS_vCredICMSSN', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N31 - Valor da BC do ICMS ST da UF destino <infNFe><det><imposto><ICMS><vBCSTDest>', 1, 'infNFe_det_imposto_ICMS_vBCSTDest', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'N32 - Valor do ICMS ST da UF destino <infNFe><det><imposto><ICMS><vICMSSTDest>', 1, 'infNFe_det_imposto_ICMS_vICMSSTDest', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'O02 - Classe de enquadramento do IPI para Cigarros e Bebidas  <infNFe><det><imposto><IPI><clEnq>', 1, 'infNFe_det_imposto_IPI_clEnq', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'O03 - CNPJ do produtor da mercadoria  <infNFe><det><imposto><IPI><CNPJProd>', 1, 'infNFe_det_imposto_IPI_CNPJProd', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'O04 - C�digo do selo de controle IPI  <infNFe><det><imposto><IPI><cSelo>', 1, 'infNFe_det_imposto_IPI_cSelo', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'O05 - Quantidade de selo de controle  <infNFe><det><imposto><IPI><qSelo>', 1, 'infNFe_det_imposto_IPI_qSelo', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'O06 - C�digo de Enquadramento Legal do IPI  <infNFe><det><imposto><IPI><cEnq>', 1, 'infNFe_det_imposto_IPI_cEnq', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'O09 - C�digo da situa��o tribut�ria do IPI IPITrib  <infNFe><det><imposto><IPI><CST>', 1, 'infNFe_det_imposto_IPI_CST', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'O10 - Valor da BC do IPI   <infNFe><det><imposto><IPI><vBC>', 1, 'infNFe_det_imposto_IPI_vBC', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'O11 - Quantidade total na unidade padr�o para tributa��o  <infNFe><det><imposto><IPI><qUnid>', 1, 'infNFe_det_imposto_IPI_qUnid', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'O12 - Valor por Unidade Tribut�vel   <infNFe><det><imposto><IPI><vUnid>', 1, 'infNFe_det_imposto_IPI_vUnid', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'O13 - Al�quota do IPI   <infNFe><det><imposto><IPI><pIPI>', 1, 'infNFe_det_imposto_IPI_pIPI', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'O14 - Valor do IPI   <infNFe><det><imposto><IPI><vIPI>', 1, 'infNFe_det_imposto_IPI_vIPI', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Q06 - C�digo de Situa��o Tribut�ria do PIS  <infNFe><det><imposto><PIS><CST>', 1, 'infNFe_det_imposto_PIS_CST', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Q07 - Valor da Base de C�lculo do PIS  <infNFe><det><imposto><PIS><vBC>', 1, 'infNFe_det_imposto_PIS_vBC', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Q08 - Al�quota do PIS (em percentual)   <infNFe><det><imposto><PIS><pPIS>', 1, 'infNFe_det_imposto_PIS_pPIS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Q09 - Valor do PIS   <infNFe><det><imposto><PIS><vPIS>', 1, 'infNFe_det_imposto_PIS_vPIS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Q10 - Quantidade Vendida PISQtde  <infNFe><det><imposto><PIS><qBCProd>', 1, 'infNFe_det_imposto_PIS_qBCProd', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Q11 - Al�quota do PIS (em reais) PISOutr  <infNFe><det><imposto><PIS><vAliqProd>', 1, 'infNFe_det_imposto_PIS_vAliqProd', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'R02 - Valor da Base de C�lculo do PIS   <infNFe><det><imposto><PISST><vBC>', 1, 'infNFe_det_imposto_PISST_vBC', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'R03 - Al�quota do PIS (em percentual)  <infNFe><det><imposto><PISST><pPIS>', 1, 'infNFe_det_imposto_PISST_pPIS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'R04 - Quantidade Vendida   <infNFe><det><imposto><PISST><qBCProd>', 1, 'infNFe_det_imposto_PISST_qBCProd', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'R05 - Al�quota do PIS (em reais)  <infNFe><det><imposto><PISST><vAliqProd>', 1, 'infNFe_det_imposto_PISST_vAliqProd', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'R06 - Valor do PIS  <infNFe><det><imposto><PISST><vPIS>', 1, 'infNFe_det_imposto_PISST_vPIS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'S06 - C�digo de Situa��o Tribut�ria da COFINS COFINSAliq  <infNFe><det><imposto><COFINS><CST>', 1, 'infNFe_det_imposto_COFINS_CST', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'S07 - Valor da Base de C�lculo da COFINS COFINSAliq  <infNFe><det><imposto><COFINS><vBC>', 1, 'infNFe_det_imposto_COFINS_vBC', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'S08 - Al�quota da COFINS (em percentual) COFINSAliq  <infNFe><det><imposto><COFINS><pCOFINS>', 1, 'infNFe_det_imposto_COFINS_pCOFINS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'S09 - Quantidade Vendida COFINSQtde  <infNFe><det><imposto><COFINS><qBCProd>', 1, 'infNFe_det_imposto_COFINS_qBCProd', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'S10 - Al�quota da COFINS (em reais) COFINSQtde  <infNFe><det><imposto><COFINS><vAliqProd>', 1, 'infNFe_det_imposto_COFINS_vAliqProd', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'S11 - Valor da COFINS COFINSAliq  <infNFe><det><imposto><COFINS><vCOFINS>', 1, 'infNFe_det_imposto_COFINS_vCOFINS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'T02 - Valor da Base de C�lculo da COFINSST  <infNFe><det><imposto><COFINSST><vBC>', 1, 'infNFe_det_imposto_COFINSST_vBC', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'T03 - Al�quota da COFINS (em percentual)  <infNFe><det><imposto><COFINSST><pCOFINS>', 1, 'infNFe_det_imposto_COFINSST_pCOFINS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'T04 - Quantidade Vendida  <infNFe><det><imposto><COFINSST><qBCProd>', 1, 'infNFe_det_imposto_COFINSST_qBCProd', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'T05 - Al�quota da COFINS (em reais)  <infNFe><det><imposto><COFINSST><vAliqProd>', 1, 'infNFe_det_imposto_COFINSST_vAliqProd', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'T06 - Valor da COFINS  <infNFe><det><imposto><COFINSST><vCOFINS>', 1, 'infNFe_det_imposto_COFINSST_vCOFINS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'U02 - Valor da Base de C�lculo do ISSQN  <infNFe><det><imposto><ISSQN><vBC>', 1, 'infNFe_det_imposto_ISSQN_Vbc', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'U03 - Al�quota do ISSQN   <infNFe><det><imposto><ISSQN><vAliq>', 1, 'infNFe_det_imposto_ISSQN_vAliq', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'U04 - Valor do ISSQN  <infNFe><det><imposto><ISSQN><vISSQN>', 1, 'infNFe_det_imposto_ISSQN_vISSQN', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'U05 - C�d. do mun. de ocorr�ncia do fato gerador do ISSQN  <infNFe><det><imposto><ISSQN><cMunFG>', 1, 'infNFe_det_imposto_ISSQN_cMunFG', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'U06 - Item da Lista de Servi�os  <infNFe><det><imposto><ISSQN><cListServ>', 1, 'infNFe_det_imposto_ISSQN_cListServ', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'U07 - C�digo de Tributa��o do ISSQN  <infNFe><det><imposto><ISSQN><cSitTrib>', 1, 'infNFe_det_imposto_ISSQN_cSitTrib', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'V01 - Informa��es Adicionais do Produto  <infNFe><det><infAdProd>', 1, 'infNFe_det_infAdProd', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W03 - Base de C�lculo do ICMS  <infNFe><total><ICMSTot><vBC>', 0, 'infNFe_total_ICMSTot_vBC', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W04 - Valor Total do ICMS  <infNFe><total><ICMSTot><vICMS>', 0, 'infNFe_total_ICMSTot_vICMS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W04b - Valor Total do FCP (Fundo de Combate � Pobreza) <infNFe><total><ICMSTot><vFCP>', 0, 'infNFe_total_ICMSTot_vFCP', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W04c - Valor total do ICMS relativo Fundo de Combate � Pobreza (FCP) da UF de destino <infNFe><total><ICMSTot><vFCPUFDest>', 0, 'infNFe_total_ICMSTot_vFCPUFDest', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W04e - Valor total do ICMS Interestadual para a UF de destino  <infNFe><total><ICMSTot><vICMSUFDest>', 0, 'infNFe_total_ICMSTot_vICMSUFDest', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W04g - Valor total do ICMS Interestadual para a UF do remetente  <infNFe><total><ICMSTot><vICMSUFRemet>', 0, 'infNFe_total_ICMSTot_vICMSUFRemet', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W05 - Base de C�lculo do ICMS ST  <infNFe><total><ICMSTot><vBCST>', 0, 'infNFe_total_ICMSTot_vBCST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W06 - Valor Total do ICMS ST  <infNFe><total><ICMSTot><vST>', 0, 'infNFe_total_ICMSTot_vST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W06a - Valor Total do FCP (Fundo de Combate � Pobreza) retido por substitui��o tribut�ria <infNFe><total><ICMSTot><vFCPST>', 0, 'infNFe_total_ICMSTot_vFCPST', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W06b - Valor Total do FCP retido anteriormente por Substitui��o Tribut�ria <infNFe><total><ICMSTot><vFCPSTRet>', 0, 'infNFe_total_ICMSTot_vFCPSTRet', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W07 - Valor Total dos produtos e servi�os  <infNFe><total><ICMSTot><vProd>', 0, 'infNFe_total_ICMSTot_vProd', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W08 - Valor Total do Frete  <infNFe><total><ICMSTot><vFrete>', 0, 'infNFe_total_ICMSTot_vFrete', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W09 - Valor Total do Seguro  <infNFe><total><ICMSTot><vSeg>', 0, 'infNFe_total_ICMSTot_vSeg', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W10 - Valor Total do Desconto  <infNFe><total><ICMSTot><vDesc>', 0, 'infNFe_total_ICMSTot_vDesc', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W11 - Valor Total do II  <infNFe><total><ICMSTot><vII>', 0, 'infNFe_total_ICMSTot_vII', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W12 - Valor Total do IPI  <infNFe><total><ICMSTot><vIPI>', 0, 'infNFe_total_ICMSTot_vIPI', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W12a - Valor Total da NF-e  <infNFe><total><ICMSTot><vIPIDevol>', 0, 'infNFe_total_ICMSTot_vIPIDevol', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W13 - Valor do PIS  <infNFe><total><ICMSTot><vPIS>', 0, 'infNFe_total_ICMSTot_vPIS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W14 - Valor do COFINS  <infNFe><total><ICMSTot><vCOFINS>', 0, 'infNFe_total_ICMSTot_vCOFINS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W15 - Outras Despesas acess�rias  <infNFe><total><ICMSTot><vOutro>', 0, 'infNFe_total_ICMSTot_vOutro', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W16 - Valor Total da NF-e  <infNFe><total><ICMSTot><vNF>', 0, 'infNFe_total_ICMSTot_vNF', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W18 - Val. Tot. Servi�os sob n�o-incid. ou n�o tribut. pelo ICMS  <infNFe><total><ISSQNtot><vServ>', 0, 'infNFe_total_ISSQNtot_vServ', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W19 - Base de C�lculo do ISS  <infNFe><total><ISSQNtot><vBC>', 0, 'infNFe_total_ISSQNtot_vBC', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W20 - Valor Total do ISS  <infNFe><total><ISSQNtot><vISS>', 0, 'infNFe_total_ISSQNtot_vISS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W21 - Valor do PIS sobre servi�os  <infNFe><total><ISSQNtot><vPIS>', 0, 'infNFe_total_ISSQNtot_vPIS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W22 - Valor do COFINS sobre servi�os  <infNFe><total><ISSQNtot><vCOFINS>', 0, 'infNFe_total_ISSQNtot_vCOFINS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W24 - Valor Retido de PIS  <infNFe><total><retTrib><vRetPIS>', 0, 'infNFe_total_retTrib_vRetPIS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W25 - Valor Retido de COFINS  <infNFe><total><retTrib><vRetCOFINS>', 0, 'infNFe_total_retTrib_vRetCOFINS', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W26 - Valor Retido de CSLL  <infNFe><total><retTrib><vRetCSLL>', 0, 'infNFe_total_retTrib_vRetCSLL', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W27 - Base de C�lculo do IRRF  <infNFe><total><retTrib><vBCIRRF>', 0, 'infNFe_total_retTrib_vBCIRRF', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W28 - Valor Retido do IRRF   <infNFe><total><retTrib><vIRRF>', 0, 'infNFe_total_retTrib_vIRRF', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W29 - Base de C�lculo da Reten��o da Previd�ncia Socia  <infNFe><total><retTrib><vBCRetPrev>', 0, 'infNFe_total_retTrib_vBCRetPrev', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'W30 - Valor da Reten��o da Previd�ncia Social  <infNFe><total><retTrib><vRetPrev>', 0, 'infNFe_total_retTrib_vRetPrev', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X02 - Modalidade do frete  <infNFe><transp><modFrete>', 0, 'infNFe_transp_modFrete', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X04 - CNPJ  <infNFe><transp><transporta><CNPJ>', 0, 'infNFe_transp_transporta_CNPJ', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X05 - CPF  <infNFe><transp><transporta><CPF>', 0, 'infNFe_transp_transporta_CPF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X06 - xNome  <infNFe><transp><transporta><xNome>', 0, 'infNFe_transp_transporta_xNome', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X07 - IE  <infNFe><transp><transporta><IE>', 0, 'infNFe_transp_transporta_IE', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X08 - Endere�o Completo  <infNFe><transp><transporta><xEnder>', 0, 'infNFe_transp_transporta_xEnder', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X09 - Nome do munic�pio  <infNFe><transp><transporta><xMun>', 0, 'infNFe_transp_transporta_xMun', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X10 - Sigla da UF  <infNFe><transp><transporta><UF>', 0, 'infNFe_transp_transporta_UF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X12 - Valor do Servi�o  <infNFe><transp><retTransp><vServ>', 0, 'infNFe_transp_retTransp_vServ', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X13 - BC da Reten��o do ICMS  <infNFe><transp><retTransp><vBCRet>', 0, 'infNFe_transp_retTransp_vBCRet', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X14 - Al�quota da Reten��o  <infNFe><transp><retTransp><pICMSRet>', 0, 'infNFe_transp_retTransp_pICMSRet', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X15 - Valor do ICMS Retido  <infNFe><transp><retTransp><vICMSRet>', 0, 'infNFe_transp_retTransp_vICMSRet', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X16 - CFOP  <infNFe><transp><retTransp><CFOP>', 0, 'infNFe_transp_retTransp_CFOP', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X17 - C�d. do mun. de ocorr�ncia do fato ger. do ICMS do transp. <infNFe><transp><retTransp><cMunFG>', 0, 'infNFe_transp_retTransp_cMunFG', 1, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X19 - Placa do Ve�culo  <infNFe><transp><veicTransp><placa>', 0, 'infNFe_transp_veicTransp_placa', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X20 - Sigla da UF   <infNFe><transp><veicTransp><UF>', 0, 'infNFe_transp_veicTransp_UF', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X21 - Registro Nacional de Transportador de Carga (ANTT)  <infNFe><transp><veicTransp><RNTC>', 0, 'infNFe_transp_veicTransp_RNTC', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X22 - Grupo Reboque <infNFe><transp><reboque>', 0, 'infNFe_transp_reboque', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X25a - Identifica��o do vag�o  <infNFe><transp><vagao>', 0, 'infNFe_transp_vagao', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X25b - Identifica��o da balsa   <infNFe><transp><balsa>', 0, 'infNFe_transp_balsa', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X26 - Grupo Volumes <infNFe><transp><vol>', 0, 'infNFe_transp_vol', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X27 - Quantidade de volumes transportados  <infNFe><transp><vol><qVol>', 0, 'infNFe_transp_vol_qVol', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X28 - Esp�cie dos volumes transportados  <infNFe><transp><vol><esp>', 0, 'infNFe_transp_vol_esp', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X29 - Marca dos volumes transportados <infNFe><transp><vol><marca>', 0, 'infNFe_transp_vol_marca', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X30 - Numera��o dos volumes transportados <infNFe><transp><vol><nVol>', 0, 'infNFe_transp_vol_nVol', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X31 - Peso L�quido (em kg) <infNFe><transp><vol><pesoL>', 0, 'infNFe_transp_vol_pesoL', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'X32 - Peso Bruto (em kg)  <infNFe><transp><vol><pesoB>', 0, 'infNFe_transp_vol_pesoB', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Y03 - N�mero da Fatura  <infNFe><cobr><fat><nFat>', 0, 'infNFe_cobr_fat_nFat', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Y04 - Valor Original da Fatura  <infNFe><cobr><fat><vOrig>', 0, 'infNFe_cobr_fat_vOrig', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Y05 - Valor do desconto  <infNFe><cobr><fat><vDesc>', 0, 'infNFe_cobr_fat_vDesc', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Y06 - Valor L�quido da Fatura  <infNFe><cobr><fat><vLiq>', 0, 'infNFe_cobr_fat_vLiq', 3, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Y07 - Grupo da Duplicata <infNFe><cobr><dup>', 0, 'infNFe_cobr_dup', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'YA01 - Modalidade do frete  <infNFe><pag>', 0, 'infNFe_pag', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZA02 - Sigla da UF onde ocorrer� o Embarque dos produtos  <infNFe><exporta><UFEmbarq>', 0, 'infNFe_exporta_UFEmbarq', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZA03 - Local onde ocorrer� o Embarque dos produtos  <infNFe><exporta><xLocEmbarq>', 0, 'infNFe_exporta_xLocEmbarq', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZB02 - Nota de Empenho  <infNFe><compra><xNEmp>', 0, 'infNFe_compra_xNEmp', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZB03 - Pedido  <infNFe><compra><xPed>', 0, 'infNFe_compra_xPed', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZB04 - Contrato  <infNFe><compra><xCont>', 0, 'infNFe_compra_xCont', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZC02 - Identifica��o da safra  <infNFe><cana><safra>', 0, 'infNFe_cana_safra', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZC03 - M�s e ano de refer�ncia  <infNFe><cana><ref>', 0, 'infNFe_cana_ref', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZC04 - Grupo de Fornecimento di�rio de cana <infNFe><cana><forDia>', 0, 'infNFe_cana_forDia', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZC07 - Quantidade Total do M�s  <infNFe><cana><qTotMes>', 0, 'infNFe_cana_qTotMes', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZC08 - Quantidade Total Anterior  <infNFe><cana><qTotAnt>', 0, 'infNFe_cana_qTotAnt', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZC09 - Quantidade Total Geral   <infNFe><cana><qTotGer>', 0, 'infNFe_cana_qTotGer', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZC10 - Grupo de Dedu��es � Taxas e Contribui��es <infNFe><cana><deduc>', 0, 'infNFe_cana_deduc', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZC13 - Valor dos Fornecimentos  <infNFe><cana><vFor>', 0, 'infNFe_cana_vFor', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZC14 - Valor Total da Dedu��o  <infNFe><cana><vTotDed>', 0, 'infNFe_cana_vTotDed', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'ZC15 - Valor L�quido dos Fornecimentos  <infNFe><cana><vLiqFor>', 0, 'infNFe_cana_vLiqFor', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Z02 - Informa��es Adicionais de Interesse do Fisco  <infNFe><infAdic><infAdFisco>', 0, 'infNFe_infAdic_infAdFisco', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Z03 - Informa��es Complementares de interesse do Contribuinte  <infNFe><infAdic><infCpl>', 0, 'infNFe_infAdic_infCpl', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Z04 - Grupo de campo de uso livre do contribuinte <infNFe><infAdic><obsCont>', 0, 'infNFe_infAdic_obsCont', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Z07 - Grupo do campo de uso livre do Fisco <infNFe><infAdic><obsFisco>', 0, 'infNFe_infAdic_obsFisco', 0, null, GET_USER_MXM, SYSDATE);
  VCNF_SQCAMPO := VCNF_SQCAMPO + 1;
  ULTIMO       := VCNF_SQCAMPO;
  INSERT INTO COLNOTAFISCAL_CNF (CNF_SQCAMPO, CNF_DSCAMPO, CNF_TPCAMPO, CNF_TEFORMULA, CNF_TPDADO, CNF_CDGRUPO, CNF_USUARIO, CNF_DTALTER)
  VALUES (VCNF_SQCAMPO, 'Z10 - Grupo do processo referenciado <infNFe><infAdic><procRef>', 0, 'infNFe_infAdic_procRef', 0, null, GET_USER_MXM, SYSDATE);
  INSERT INTO FATCOLNFXML_CNX
  SELECT SEQ1_FATCOLNFXML_CNX.NEXTVAL,
         CNF_SQCAMPO,
         CNF_TEFORMULA,
         'NFE_4.00',
         SYSDATE,
         SYSDATE,
         GET_USER_MXM,
         GET_USER_MXM,
         'N'
    FROM COLNOTAFISCAL_CNF
   WHERE CNF_SQCAMPO BETWEEN PRIMEIRO AND ULTIMO;
END;
/

INSERT INTO PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
VALUES ('PARDATALIMITENFE3.10', '02/04/2018', USER, SYSDATE, NULL, NULL, NULL, NULL, NULL, NULL)
/

INSERT INTO ERROMSG_ERM VALUES ('GERINT0036', 'A data de emiss�o da NF-e n�o pode ser maior que a data limite da vers�o utilizada.')
/

INSERT INTO ERROMSG_ERM VALUES ('GERINT0037', 'A data limite para emiss�o de NF-e nesta vers�o est� pr�xima.')
/

INSERT INTO ERROMSG_ERM VALUES ('GERINT0038', 'Data de emiss�o da NF-e na data limite para a vers�o.')
/

INSERT INTO ERROMSG_ERM VALUES ('FFP0013', 'N�o deve ser informado o Valor Recebido quando a Forma de Pagamento for "Sem Pagamento"')
/

INSERT INTO ERROMSG_ERM VALUES ('FFP0014', 'N�o deve ser informado o Valor do Troco quando a Forma de Pagamento for "Sem Pagamento"')
/

INSERT INTO ERROMSG_ERM VALUES ('FFP0015', 'N�o deve ser informado o Valor de Pagamento quando a Forma de Pagamento for "Sem Pagamento"')
/

ALTER TABLE FATMDFE_FMD MODIFY FMD_CDTRANSPORTADORA NULL
/

CREATE TABLE FATREGRAPREENCANP_RPA
(
  RPA_IDREGRAPREENCANP NUMBER(7) NOT NULL,
  RPA_CDPRODUTOANP     VARCHAR2(30) NOT NULL,
  RPA_TPVLPARTIDA      NUMBER(1) NOT NULL,
  RPA_TPPERCGLP        NUMBER(1) NOT NULL,
  RPA_TPPERCGNN        NUMBER(1) NOT NULL,
  RPA_TPPERCGNI        NUMBER(1) NOT NULL,
  RPA_VBINATIVACAO     CHAR(1) DEFAULT 'N' NOT NULL ,
  RPA_USINATIVACAO     VARCHAR2(40),
  RPA_DTINATIVACAO     DATE,
  RPA_USINCLUSAO       VARCHAR2(40) NOT NULL,
  RPA_DTINCLUSAO       DATE NOT NULL,
  RPA_USALTERACAO      VARCHAR2(40),
  RPA_DTALTERACAO      DATE
)
/

CREATE INDEX IN1_FATREGRAPREENCANP_RPA ON FATREGRAPREENCANP_RPA (RPA_CDPRODUTOANP)
/

COMMENT ON TABLE FATREGRAPREENCANP_RPA IS 'Regras de preenchimento do c�digo ANP'
/

COMMENT ON COLUMN FATREGRAPREENCANP_RPA.RPA_CDPRODUTOANP IS 'Codigo ANP'
/

COMMENT ON COLUMN FATREGRAPREENCANP_RPA.RPA_TPVLPARTIDA IS '0 - Obrigat�rio / 1 - Opcional / 2 - N�o preencher'
/

COMMENT ON COLUMN FATREGRAPREENCANP_RPA.RPA_TPPERCGLP IS '0 - Obrigat�rio / 1 - Opcional / 2 - N�o preencher'
/

COMMENT ON COLUMN FATREGRAPREENCANP_RPA.RPA_TPPERCGNN IS '0 - Obrigat�rio / 1 - Opcional / 2 - N�o preencher'
/

COMMENT ON COLUMN FATREGRAPREENCANP_RPA.RPA_TPPERCGNI IS '0 - Obrigat�rio / 1 - Opcional / 2 - N�o preencher'
/

CREATE SEQUENCE SEQ1_FATREGRAPREENCANP_RPA
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

ALTER TABLE FATREGRAPREENCANP_RPA ADD (CONSTRAINT PK_FATREGRAPREENCANP_RPA PRIMARY KEY (RPA_IDREGRAPREENCANP))
/

ALTER TABLE FATREGRAPREENCANP_RPA ADD (CONSTRAINT UK1_FATREGRAPREENCANP_RPA UNIQUE (RPA_CDPRODUTOANP, RPA_VBINATIVACAO, RPA_USINATIVACAO, RPA_DTINATIVACAO))
/

ALTER TABLE FATREGRAPREENCANP_RPA
  ADD CONSTRAINT FK1_FATREGRAPREENCANP_RPA FOREIGN KEY (RPA_CDPRODUTOANP)
  REFERENCES SPEDCODANP_ANP (ANP_CODIGO)
/

CREATE OR REPLACE PROCEDURE PRC_INSFATREGRAPREENCANP_RPA
(
  PRPA_IDREGRAPREENCANP IN OUT NUMBER,
  PRPA_CDPRODUTOANP     IN CHAR,
  PRPA_TPVLPARTIDA      IN NUMBER,
  PRPA_TPPERCGLP        IN NUMBER,
  PRPA_TPPERCGNN        IN NUMBER,
  PRPA_TPPERCGNI        IN NUMBER,
  PRPA_VBINATIVACAO     IN CHAR,
  PRPA_USINATIVACAO     IN CHAR DEFAULT NULL,
  PRPA_DTINATIVACAO     IN DATE DEFAULT NULL,
  PRPA_USINCLUSAO       IN CHAR,
  PRPA_DTINCLUSAO       IN DATE,
  PRPA_USALTERACAO      IN CHAR DEFAULT NULL,
  PRPA_DTALTERACAO      IN DATE DEFAULT NULL
) AS
BEGIN
  IF PRPA_IDREGRAPREENCANP IS NULL THEN
    SELECT SEQ1_FATREGRAPREENCANP_RPA.NEXTVAL
      INTO PRPA_IDREGRAPREENCANP
      FROM DUAL;
  END IF;
  INSERT INTO FATREGRAPREENCANP_RPA
    (RPA_IDREGRAPREENCANP,
     RPA_CDPRODUTOANP,
     RPA_TPVLPARTIDA,
     RPA_TPPERCGLP,
     RPA_TPPERCGNN,
     RPA_TPPERCGNI,
     RPA_VBINATIVACAO,
     RPA_USINATIVACAO,
     RPA_DTINATIVACAO,
     RPA_USINCLUSAO,
     RPA_DTINCLUSAO,
     RPA_USALTERACAO,
     RPA_DTALTERACAO)
  VALUES
    (PRPA_IDREGRAPREENCANP,
     PRPA_CDPRODUTOANP,
     PRPA_TPVLPARTIDA,
     PRPA_TPPERCGLP,
     PRPA_TPPERCGNN,
     PRPA_TPPERCGNI,
     NVL(PRPA_VBINATIVACAO,'N'),
     PRPA_USINATIVACAO,
     PRPA_DTINATIVACAO,
     NVL(PRPA_USINCLUSAO, GET_USER_MXM),
     NVL(PRPA_DTINCLUSAO, SYSDATE),
     PRPA_USALTERACAO,
     PRPA_DTALTERACAO);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATREGRAPREENCANP_RPA
(
  PRPA_IDREGRAPREENCANP IN NUMBER,
  PRPA_CDPRODUTOANP     IN CHAR,
  PRPA_TPVLPARTIDA      IN NUMBER,
  PRPA_TPPERCGLP        IN NUMBER,
  PRPA_TPPERCGNN        IN NUMBER,
  PRPA_TPPERCGNI        IN NUMBER,
  PRPA_VBINATIVACAO     IN CHAR,
  PRPA_USINATIVACAO     IN CHAR DEFAULT NULL,
  PRPA_DTINATIVACAO     IN DATE DEFAULT NULL,
  PRPA_USINCLUSAO       IN CHAR,
  PRPA_DTINCLUSAO       IN DATE,
  PRPA_USALTERACAO      IN CHAR DEFAULT NULL,
  PRPA_DTALTERACAO      IN DATE DEFAULT NULL
) AS
BEGIN
  UPDATE FATREGRAPREENCANP_RPA
     SET RPA_IDREGRAPREENCANP = PRPA_IDREGRAPREENCANP,
         RPA_CDPRODUTOANP     = PRPA_CDPRODUTOANP,
         RPA_TPVLPARTIDA      = PRPA_TPVLPARTIDA,
         RPA_TPPERCGLP        = PRPA_TPPERCGLP,
         RPA_TPPERCGNN        = PRPA_TPPERCGNN,
         RPA_TPPERCGNI        = PRPA_TPPERCGNI,
         RPA_VBINATIVACAO     = PRPA_VBINATIVACAO,
         RPA_USINATIVACAO     = PRPA_USINATIVACAO,
         RPA_DTINATIVACAO     = PRPA_DTINATIVACAO,
         RPA_USINCLUSAO       = PRPA_USINCLUSAO,
         RPA_DTINCLUSAO       = PRPA_DTINCLUSAO,
         RPA_USALTERACAO      = NVL(PRPA_USALTERACAO, GET_USER_MXM),
         RPA_DTALTERACAO      = NVL(PRPA_DTALTERACAO, SYSDATE)
   WHERE RPA_IDREGRAPREENCANP = PRPA_IDREGRAPREENCANP;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCFATREGRAPREENCANP_RPA
(
  PRPA_IDREGRAPREENCANP IN NUMBER
) AS
BEGIN
  DELETE FROM FATREGRAPREENCANP_RPA
   WHERE RPA_IDREGRAPREENCANP = PRPA_IDREGRAPREENCANP;
END;
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0012', 'Registro de relacionamento j� existente.')
/

UPDATE CAMPOAJUDA_CAJU
   SET CAJU_SEQUENCIA = '009'
 WHERE CAJU_CODIGO    = 'X12'
   AND CAJU_SEQUENCIA = '008'
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('X12', '008', 'PLS_DTFABRICACAO', 'Dt.Fabrica��o', NULL, NULL)
/

INSERT INTO TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
VALUES ('TENUFORMAPAGAMENTONFCE', '14', 'Duplicata Mercantil')
/

INSERT INTO TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
VALUES ('TENUFORMAPAGAMENTONFCE', '15', 'Boleto Banc�rio')
/

UPDATE ERROMSG_ERM
   SET ERM_DSERRO = 'Fatura de NF-e e NFC-e tem que ser inforrmado forma de pagamento.'
 WHERE ERM_CDERRO = 'FAT0133'
/

UPDATE ERROMSG_ERM
   SET ERM_DSERRO = 'Valor de partida obrigat�rio para o c�digo ANP "210203001 � GLP".'
 WHERE ERM_CDERRO = 'IFG0021'
/

UPDATE ERROMSG_ERM
   SET ERM_DSERRO = 'N�o � permitido informar percentual do GLP para o c�digo ANP igual a �210203001 � GLP�.'
 WHERE ERM_CDERRO = 'IFG0022'
/

UPDATE ERROMSG_ERM
   SET ERM_DSERRO = 'N�o � permitido informar percentual de G�s Natural Nacional para o c�digo ANP igual a �210203001 � GLP�.'
 WHERE ERM_CDERRO = 'IFG0023'
/

UPDATE ERROMSG_ERM
   SET ERM_DSERRO = 'N�o � permitido informar percentual de G�s Natural Importado para o c�digo ANP igual a �210203001 � GLP�.'
 WHERE ERM_CDERRO = 'IFG0024'
/

DECLARE
 IDENT NUMBER;
BEGIN
  IDENT := NULL;
  PRC_INSFATREGRAPREENCANP_RPA(IDENT,'210203001', 0, 2, 2, 2, 'N', NULL, NULL, GET_USER_MXM, SYSDATE, NULL, NULL);
END;
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'TPAE0001'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'TPAE0002'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CEAE0001'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CEAE0002'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CRAE0001'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CRAE0002'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CRAE0003'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CRAE0004'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CRAE0005'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CRAE0006'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0001'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0002'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0003'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0004'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0005'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0006'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0007'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0008'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0009'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0010'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0011'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CDAE0012'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IRAE0001'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IRAE0002'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IRAE0003'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IRAE0004'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IRAE0005'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0001'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0002'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0003'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0004'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0005'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0006'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0007'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0008'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0009'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0010'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0011'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'CTF0012'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FAT0133'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FAT0147'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FAT9050'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0021'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0022'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0023'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0024'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0025'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0026'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0027'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0028'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0029'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FFP0010'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FFP0011'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FFP0012'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FFP0013'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FFP0014'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FFP0015'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FFP0016'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FATD8010'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'GERINT0036'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'GERINT0037'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'GERINT0038'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FMD0041'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FRF0016'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'NCE0006'
/

INSERT INTO ERROMSG_ERM VALUES ('TPAE0001', 'Esteriliza��o obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('TPAE0002', 'Descri��o do tipo de produto obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CEAE0001', 'Esteriliza��o obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CEAE0002', 'Descri��o da Esteriliza��o obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CRAE0001', 'Produto obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CRAE0002', 'Produto inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('CRAE0003', 'Registro ANVISA/MS obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CRAE0004', 'Registro ANVISA/MS inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('CRAE0005', 'Um produto n�o pode ser informado mais de uma vez.')
/

INSERT INTO ERROMSG_ERM VALUES ('CRAE0006', 'O Produto est� relacionado a outro Registro ANVISA.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0001', 'Registro Anvisa obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0002', 'Classe obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0003', 'Data do Registro obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0004', 'Data de Validade obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0005', 'Descri��o obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0006', 'Produto ANVISA obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0007', 'Esteriliza��o inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0008', 'Fabricante obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0009', 'Data de Revalida��o obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0010', 'Tipo de Produto ANVISA inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0011', 'Data da Validade menor ou igual a do Registro.')
/

INSERT INTO ERROMSG_ERM VALUES ('CDAE0012', 'Data da Revalida��o menor ou igual a do Registro.')
/

INSERT INTO ERROMSG_ERM VALUES ('IRAE0001', 'Registro ANVISA obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('IRAE0002', 'Registro ANVISA inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('IRAE0003', 'Descri��o da imagem obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('IRAE0004', 'A Imagem obrigat�rio.')
/

INSERT INTO ERROMSG_ERM VALUES ('IRAE0005', 'A imagem selecionada dever� estar no formato JPG.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0001', 'Identificador do Relacionamento entre Forma de Pagamento, Condi��o de Pagamento e Tipo de cobran�a inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0002', 'A informa��o do c�digo da Empresa � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0003', 'Empresa inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0004', 'A informa��o do c�digo da Filial � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0005', 'Filial inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0006', 'A informa��o do c�digo da Forma de Pagamento � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0007', 'Forma de Pagamento inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0008', 'A informa��o do c�digo da Condi��o de Pagamento � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0009', 'Condi��o de Pagamento inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0010', 'A informa��o do c�digo do Tipo de Cobran�a � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0011', 'Tipo de Cobran�a inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('CTF0012', 'Registro de relacionamento j� existente.')
/

INSERT INTO ERROMSG_ERM VALUES ('FAT0133', ' Deve ser inforrmada uma Forma de Pagamento.')
/

INSERT INTO ERROMSG_ERM VALUES ('FAT0147', 'Percentual n�o permitido para o FECP.')
/

INSERT INTO ERROMSG_ERM VALUES ('FAT9050', 'Deve ser informado o documento referenciado quando selecionada a forma de atendimento "Opera��o presencial, fora do estabelecimento".')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0021', 'Valor de partida obrigat�rio para o c�digo ANP "210203001 � GLP"')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0022', 'N�o � permitido informar percentual do GLP para c�digo ANP diferente de �210203001 � GLP�')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0023', 'N�o � permitido informar percentual de G�s Natural Nacional para c�digo ANP diferente de �210203001 � GLP�')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0024', 'N�o � permitido informar percentual de G�s Natural Importado para c�digo ANP diferente de �210203001 � GLP�')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0025', 'C�digo de produto ANP inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0026', 'N�o � permitido informar o Valor de partida para o c�digo ANP "210203001 � GLP".')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0027', '� obrigat�rio o preenchimento do percentual do GLP para o c�digo ANP igual de �210203001 � GLP�.')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0028', '� obrigat�rio o preenchimento do percentual de G�s Natural Nacional para o c�digo ANP igual a �210203001 � GLP�.')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0029', '� obrigat�rio o preenchimento do percentual de G�s Natural Importado para o c�digo ANP igual a �210203001 � GLP�.')
/

INSERT INTO ERROMSG_ERM VALUES ('FFP0010', 'Valor recebido obrigat�rio')
/

INSERT INTO ERROMSG_ERM VALUES ('FFP0011', 'Valor recebido tem que ser maior que zero')
/

INSERT INTO ERROMSG_ERM VALUES ('FFP0012', 'Valor do troco tem que ser maior que zero')
/

INSERT INTO ERROMSG_ERM VALUES ('FFP0013', 'N�o deve ser informado o Valor Recebido quando a Forma de Pagamento for "Sem Pagamento"')
/

INSERT INTO ERROMSG_ERM VALUES ('FFP0014', 'N�o deve ser informado o Valor do Troco quando a Forma de Pagamento for "Sem Pagamento"')
/

INSERT INTO ERROMSG_ERM VALUES ('FFP0015', 'N�o deve ser informado o Valor de Pagamento quando a Forma de Pagamento for "Sem Pagamento"')
/

INSERT INTO ERROMSG_ERM VALUES ('FFP0016', 'A Forma de Pagamento "Sem Pagamento" somente deve ser utilizadas em notas de Devolu��o ou Ajuste.')
/

INSERT INTO ERROMSG_ERM VALUES ('FATD8010', 'N�o � permitida a informa��o de Formas de Pagamento diferentes de 90 (Sem pagamentos) em notas de Ajuste ou Devolu��o.')
/

INSERT INTO ERROMSG_ERM VALUES ('GERINT0036', 'A data de emiss�o da NF-e n�o pode ser maior que a data limite da vers�o utilizada.')
/

INSERT INTO ERROMSG_ERM VALUES ('GERINT0037', 'A data limite para emiss�o de NF-e nesta vers�o est� pr�xima.')
/

INSERT INTO ERROMSG_ERM VALUES ('GERINT0038', 'Data de emiss�o da NF-e na data limite para a vers�o.')
/

INSERT INTO ERROMSG_ERM VALUES ('FMD0041', 'MDF-e tem que possuir pelo menos 1 NFe ou CTe vinculado')
/

INSERT INTO ERROMSG_ERM VALUES ('FRF0016', 'Modelo do documento referenciado inv�lido')
/

INSERT INTO ERROMSG_ERM VALUES ('NCE0006', 'N�o � permitida a informa��o da forma de pagamento Duplicata Mercantil.')
/

UPDATE ERROMSG_ERM SET ERM_DSERRO = 'Classe � obrigat�rio.' WHERE ERM_CDERRO = 'CDAE0002'
/

UPDATE ERROMSG_ERM SET ERM_DSERRO = 'Data do Registro � obrigat�ria.' WHERE ERM_CDERRO = 'CDAE0003'
/

UPDATE ERROMSG_ERM SET ERM_DSERRO = 'Data de Validade � obrigat�ria.' WHERE ERM_CDERRO = 'CDAE0004'
/

UPDATE ERROMSG_ERM SET ERM_DSERRO = 'Data de Revalida��o � obrigat�ria.' WHERE ERM_CDERRO = 'CDAE0009'
/

UPDATE ERROMSG_ERM SET ERM_DSERRO = 'Descri��o da imagem � obrigat�ria.' WHERE ERM_CDERRO = 'IRAE0003'
/

UPDATE ERROMSG_ERM SET ERM_DSERRO = 'A Imagem � obrigat�ria.' WHERE ERM_CDERRO = 'IRAE0004'
/

CREATE TABLE FATREGRAFCP_RGF
(
  RGF_IDREGRAFCP   NUMBER(9) NOT NULL,
  RGF_NRUF         VARCHAR2(2) NOT NULL,
  RGF_VBINATIVACAO CHAR(1) DEFAULT 'N' NOT NULL,
  RGF_DHINATIVACAO DATE,
  RGF_USINATIVACAO VARCHAR2(40),
  RGF_DTINCLUSAO   DATE NOT NULL,
  RGF_USINCLUSAO   VARCHAR2(40) NOT NULL,
  RGF_DTALTERACAO  DATE,
  RGF_USALTERACAO  VARCHAR2(40)
) 
/

COMMENT ON TABLE FATREGRAFCP_RGF IS 'Tabela de Regra de valida��o de FCP'
/

COMMENT ON COLUMN FATREGRAFCP_RGF.RGF_IDREGRAFCP IS 'Identificador do registro de Regra de valida��o de FCP'
/

COMMENT ON COLUMN FATREGRAFCP_RGF.RGF_NRUF IS 'Sequencia da UF'
/

COMMENT ON COLUMN FATREGRAFCP_RGF.RGF_VBINATIVACAO IS 'Flag de inativa��o do registro'
/

COMMENT ON COLUMN FATREGRAFCP_RGF.RGF_DHINATIVACAO IS 'Data de inativa��o do registro'
/

COMMENT ON COLUMN FATREGRAFCP_RGF.RGF_USINATIVACAO IS 'Usu�rio de inativa��o do registro'
/

COMMENT ON COLUMN FATREGRAFCP_RGF.RGF_DTINCLUSAO IS 'Data de inclus�o do registro'
/

COMMENT ON COLUMN FATREGRAFCP_RGF.RGF_USINCLUSAO IS 'Usu�rio de inclus�o do registro'
/

COMMENT ON COLUMN FATREGRAFCP_RGF.RGF_DTALTERACAO IS 'Data de altera��o do registro'
/

COMMENT ON COLUMN FATREGRAFCP_RGF.RGF_USALTERACAO IS 'Usu�rio de altera��o do registro'
/

ALTER TABLE FATREGRAFCP_RGF
  ADD CONSTRAINT PK_FATREGRAFCP_RGF PRIMARY KEY (RGF_IDREGRAFCP)
/

ALTER TABLE FATREGRAFCP_RGF
  ADD CONSTRAINT UN1_FATREGRAFCP_RGF UNIQUE (RGF_NRUF, RGF_VBINATIVACAO, RGF_DHINATIVACAO, RGF_USINATIVACAO)
/

ALTER TABLE FATREGRAFCP_RGF
  ADD CONSTRAINT FK1_FATREGRAFCP_RGF FOREIGN KEY (RGF_NRUF)
  REFERENCES SPEDTABUF_TUF (TUF_CODIGO)
/

CREATE INDEX IN1_FATREGRAFCP_RGF ON FATREGRAFCP_RGF (RGF_NRUF)
/

CREATE TABLE FATITREGRAFCP_IRF
(
  IRF_IDITREGRAFCP NUMBER(9) NOT NULL,
  IRF_NRREGRAFCP   NUMBER(9) NOT NULL,
  IRF_TPOPCAOFCP   NUMBER(1) NOT NULL,
  IRF_PEREGRAFCP   NUMBER(9,5) NOT NULL,
  IRF_DTINCLUSAO   DATE NOT NULL,
  IRF_USINCLUSAO   VARCHAR2(40) NOT NULL,
  IRF_DTALTERACAO  DATE,
  IRF_USALTERACAO  VARCHAR2(40)
)
/

COMMENT ON TABLE FATITREGRAFCP_IRF IS 'Tabela de Op��es e Percentuais da Regra de valida��o de FCP'
/

COMMENT ON COLUMN FATITREGRAFCP_IRF.IRF_IDITREGRAFCP IS 'Identificador do registro de Op��es e Percentuais da Regra de valida��o de FCP'
/

COMMENT ON COLUMN FATITREGRAFCP_IRF.IRF_NRREGRAFCP IS 'Sequencial do registro de Regra de valida��o de FCP'
/

COMMENT ON COLUMN FATITREGRAFCP_IRF.IRF_TPOPCAOFCP IS 'Op��o de valida��o do FCP'
/

COMMENT ON COLUMN FATITREGRAFCP_IRF.IRF_PEREGRAFCP IS 'Percentual da regra de valida��o do FCP'
/

COMMENT ON COLUMN FATITREGRAFCP_IRF.IRF_DTINCLUSAO IS 'Data de inclus�o do registro'
/

COMMENT ON COLUMN FATITREGRAFCP_IRF.IRF_USINCLUSAO IS 'Usu�rio de inclus�o do registro'
/

COMMENT ON COLUMN FATITREGRAFCP_IRF.IRF_DTALTERACAO IS 'Data de altera��o do registro'
/

COMMENT ON COLUMN FATITREGRAFCP_IRF.IRF_USALTERACAO IS 'Usu�rio de altera��o do registro'
/

ALTER TABLE FATITREGRAFCP_IRF
  ADD CONSTRAINT PK_FATITREGRAFCP_IRF PRIMARY KEY (IRF_IDITREGRAFCP)
/

ALTER TABLE FATITREGRAFCP_IRF
  ADD CONSTRAINT FK1_FATITREGRAFCP_IRF FOREIGN KEY (IRF_NRREGRAFCP)
  REFERENCES FATREGRAFCP_RGF (RGF_IDREGRAFCP)
/

CREATE INDEX IN1_FATITREGRAFCP_IRF ON FATITREGRAFCP_IRF (IRF_NRREGRAFCP)
/

CREATE SEQUENCE SEQ1_FATREGRAFCP_RGF
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

CREATE OR REPLACE PROCEDURE PRC_INSFATREGRAFCP_RGF
(
  PRGF_IDREGRAFCP   IN OUT NUMBER,
  PRGF_NRUF         IN CHAR,
  PRGF_VBINATIVACAO IN CHAR,
  PRGF_DHINATIVACAO IN DATE DEFAULT NULL,
  PRGF_USINATIVACAO IN CHAR DEFAULT NULL,
  PRGF_DTINCLUSAO   IN DATE,
  PRGF_USINCLUSAO   IN CHAR,
  PRGF_DTALTERACAO  IN DATE DEFAULT NULL,
  PRGF_USALTERACAO  IN CHAR DEFAULT NULL
) AS
BEGIN
  IF PRGF_IDREGRAFCP IS NULL THEN
    SELECT SEQ1_FATREGRAFCP_RGF.NEXTVAL INTO PRGF_IDREGRAFCP FROM DUAL;
  END IF;
  INSERT INTO FATREGRAFCP_RGF
    (RGF_IDREGRAFCP,
     RGF_NRUF,
     RGF_VBINATIVACAO,
     RGF_DHINATIVACAO,
     RGF_USINATIVACAO,
     RGF_DTINCLUSAO,
     RGF_USINCLUSAO,
     RGF_DTALTERACAO,
     RGF_USALTERACAO)
  VALUES
    (PRGF_IDREGRAFCP,
     PRGF_NRUF,
     PRGF_VBINATIVACAO,
     PRGF_DHINATIVACAO,
     PRGF_USINATIVACAO,
     PRGF_DTINCLUSAO,
     PRGF_USINCLUSAO,
     PRGF_DTALTERACAO,
     PRGF_USALTERACAO);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATREGRAFCP_RGF
(
  PRGF_IDREGRAFCP   IN NUMBER,
  PRGF_NRUF         IN CHAR,
  PRGF_VBINATIVACAO IN CHAR,
  PRGF_DHINATIVACAO IN DATE DEFAULT NULL,
  PRGF_USINATIVACAO IN CHAR DEFAULT NULL,
  PRGF_DTINCLUSAO   IN DATE,
  PRGF_USINCLUSAO   IN CHAR,
  PRGF_DTALTERACAO  IN DATE DEFAULT NULL,
  PRGF_USALTERACAO  IN CHAR DEFAULT NULL
) AS
BEGIN
  UPDATE FATREGRAFCP_RGF
     SET RGF_IDREGRAFCP   = PRGF_IDREGRAFCP,
         RGF_NRUF         = PRGF_NRUF,
         RGF_VBINATIVACAO = PRGF_VBINATIVACAO,
         RGF_DHINATIVACAO = PRGF_DHINATIVACAO,
         RGF_USINATIVACAO = PRGF_USINATIVACAO,
         RGF_DTINCLUSAO   = PRGF_DTINCLUSAO,
         RGF_USINCLUSAO   = PRGF_USINCLUSAO,
         RGF_DTALTERACAO  = PRGF_DTALTERACAO,
         RGF_USALTERACAO  = PRGF_USALTERACAO
   WHERE RGF_IDREGRAFCP = PRGF_IDREGRAFCP;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCFATREGRAFCP_RGF
(
  PRGF_IDREGRAFCP IN NUMBER
) AS
BEGIN
  DELETE FROM FATREGRAFCP_RGF
   WHERE RGF_IDREGRAFCP = PRGF_IDREGRAFCP;
END;
/

CREATE SEQUENCE SEQ1_FATITREGRAFCP_IRF
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

CREATE OR REPLACE PROCEDURE PRC_INSFATITREGRAFCP_IRF
(
  PIRF_IDITREGRAFCP IN OUT NUMBER,
  PIRF_NRREGRAFCP   IN NUMBER,
  PIRF_TPOPCAOFCP   IN NUMBER,
  PIRF_PEREGRAFCP   IN NUMBER,
  PIRF_DTINCLUSAO   IN DATE,
  PIRF_USINCLUSAO   IN CHAR,
  PIRF_DTALTERACAO  IN DATE DEFAULT NULL,
  PIRF_USALTERACAO  IN CHAR DEFAULT NULL
) AS
BEGIN
  IF PIRF_IDITREGRAFCP IS NULL THEN
    SELECT SEQ1_FATITREGRAFCP_IRF.NEXTVAL INTO PIRF_IDITREGRAFCP FROM DUAL;
  END IF;
  INSERT INTO FATITREGRAFCP_IRF
    (IRF_IDITREGRAFCP,
     IRF_NRREGRAFCP,
     IRF_TPOPCAOFCP,
     IRF_PEREGRAFCP,
     IRF_DTINCLUSAO,
     IRF_USINCLUSAO,
     IRF_DTALTERACAO,
     IRF_USALTERACAO)
  VALUES
    (PIRF_IDITREGRAFCP,
     PIRF_NRREGRAFCP,
     PIRF_TPOPCAOFCP,
     PIRF_PEREGRAFCP,
     PIRF_DTINCLUSAO,
     PIRF_USINCLUSAO,
     PIRF_DTALTERACAO,
     PIRF_USALTERACAO);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATITREGRAFCP_IRF
(
  PIRF_IDITREGRAFCP IN NUMBER,
  PIRF_NRREGRAFCP   IN NUMBER,
  PIRF_TPOPCAOFCP   IN NUMBER,
  PIRF_PEREGRAFCP   IN NUMBER,
  PIRF_DTINCLUSAO   IN DATE,
  PIRF_USINCLUSAO   IN CHAR,
  PIRF_DTALTERACAO  IN DATE DEFAULT NULL,
  PIRF_USALTERACAO  IN CHAR DEFAULT NULL
) AS
BEGIN
  UPDATE FATITREGRAFCP_IRF
     SET IRF_IDITREGRAFCP = PIRF_IDITREGRAFCP,
         IRF_NRREGRAFCP   = PIRF_NRREGRAFCP,
         IRF_TPOPCAOFCP   = PIRF_TPOPCAOFCP,
         IRF_PEREGRAFCP   = PIRF_PEREGRAFCP,
         IRF_DTINCLUSAO   = PIRF_DTINCLUSAO,
         IRF_USINCLUSAO   = PIRF_USINCLUSAO,
         IRF_DTALTERACAO  = PIRF_DTALTERACAO,
         IRF_USALTERACAO  = PIRF_USALTERACAO
   WHERE IRF_IDITREGRAFCP = PIRF_IDITREGRAFCP;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCFATITREGRAFCP_IRF
(
  PIRF_IDITREGRAFCP IN NUMBER
) AS
BEGIN
  DELETE FROM FATITREGRAFCP_IRF
   WHERE IRF_IDITREGRAFCP = PIRF_IDITREGRAFCP;
END;
/

INSERT INTO JANELAJUDA_JAJU (JAJU_ARQUIVO, JAJU_CODIGO, JAJU_TAMANHO, JAJU_NUMCAMPO, JAJU_COMPRIMENTO, JAJU_PROCURA, JAJU_NOMEPROCURA, JAJU_TODOS, JAJU_DSFROM, JAJU_DSWHERE, JAJU_DSGROUPBY, JAJU_DSORDERBY)
VALUES ('FATREGRAFCP_RGF', 'RGF', 535, 'RGF_IDREGRAFCP', 250, 'RGF_NRUF', 'Identificador', 'S', null, null, null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('RGF', '001', 'RGF_IDREGRAFCP', 'Identificador', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('RGF', '002', 'RGF_NRUF', 'UF', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('RGF', '003', 'RGF_VBINATIVACAO', 'Inativo', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('RGF', '004', 'RGF_DHINATIVACAO', 'Data Inativo', null, null)
/

INSERT INTO ERROMSG_ERM VALUES('RGF0001', 'A informa��o da UF � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES('RGF0002', 'UF inexistente.')
/

INSERT INTO ERROMSG_ERM VALUES('RGF0003', 'A informa��o da op��o da regra de valida��o � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES('RGF0004', 'Op��o da regra de valida��o inv�lida.')
/

INSERT INTO ERROMSG_ERM VALUES('RGF0005', 'A informa��o do percentual da regra de valida��o � obrigat�ria.')
/

INSERT INTO ERROMSG_ERM VALUES('RGF0006', 'Percentual da regra de valida��o inv�lido.')
/

INSERT INTO ERROMSG_ERM VALUES('RGF0007', 'A regra de valida��o foi informada em duplicidade.')
/

INSERT INTO ERROMSG_ERM VALUES('RGF0008', 'J� existe uma regra de valida��o do FECP ativa.')
/

UPDATE ERROMSG_ERM
   SET ERM_DSERRO = 'Deve ser informada uma Forma de Pagamento.'
 WHERE ERM_CDERRO = 'FAT0133'
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
VALUES ('X12', '008', 'PLS_DTFABRICACAO', 'DATA FABRICA��O', NULL, NULL)
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0022'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0023'
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'IFG0024'
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0022', 'N�o � permitido informar percentual do GLP para o c�digo ANP �210203001 � GLP�')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0023', 'N�o � permitido informar percentual de GNN para o c�digo ANP �210203001 � GLP�')
/

INSERT INTO ERROMSG_ERM VALUES ('IFG0024', 'N�o � permitido informar percentual de GNI para o c�digo ANP �210203001 � GLP�')
/

INSERT INTO ERROMSG_ERM VALUES ('RGF0009', 'Identificador de regra de valida��o do FECP inexistente.')
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (40523, 'Regra de valida��o do FECP', 'Regra de valida��o do FECP')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SF', 40523, 20, 4000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40523, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40523, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40523, 'EXC')
/

DELETE FROM CAMPOAJUDA_CAJU WHERE CAJU_CODIGO = 'X12'
/

INSERT INTO CAMPOAJUDA_CAJU VALUES('X12', '001', 'PLS_SQLOTESERIE', 'SEQU�NCIA', NULL, NULL)
/

INSERT INTO CAMPOAJUDA_CAJU VALUES('X12', '002', 'PLS_CDLOTESERIE', 'LOTE/S�RIE', NULL, NULL)
/

INSERT INTO CAMPOAJUDA_CAJU VALUES('X12', '003', 'PLS_DTVALIDADE', 'VALIDADE', NULL, NULL)
/

INSERT INTO CAMPOAJUDA_CAJU VALUES('X12', '004', 'PLS_CDREGINTERNO', 'REGISTRO INTERNO', NULL, NULL)
/

INSERT INTO CAMPOAJUDA_CAJU VALUES('X12', '005', 'PLS_DTVALIDADEINTERNA', 'VALIDADE INTERNA', NULL, NULL)
/

INSERT INTO CAMPOAJUDA_CAJU VALUES('X12', '006', 'PLS_DTFABRICACAO', 'DT.FABRICA��O', NULL, NULL)
/

INSERT INTO CAMPOAJUDA_CAJU VALUES('X12', '007', 'SUM(SALDO)', 'SALDO', NULL, NULL)
/

INSERT INTO ERROMSG_ERM VALUES('TPAE0003', 'Tipo de Produto ANVISA/MS j� utilizado em um Registro ANVISA/MS.')
/

INSERT INTO ERROMSG_ERM VALUES('CEAE0003', 'Esteriliza��o ANVISA/MS j� utilizada em um Registro ANVISA/MS.')
/

INSERT INTO ERROMSG_ERM VALUES('CDAE0013', 'Existem produtos relacionados a este Registro ANVISA.')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 270085
PROMPT ======================================================================