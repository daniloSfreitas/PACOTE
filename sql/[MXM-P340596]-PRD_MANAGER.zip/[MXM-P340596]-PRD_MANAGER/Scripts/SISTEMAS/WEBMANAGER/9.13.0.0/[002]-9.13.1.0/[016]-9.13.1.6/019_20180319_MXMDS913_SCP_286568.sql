PROMPT ======================================================================
PROMPT == DEMANDA......: 286568
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: WALTER FERREIRA NETO
PROMPT == DATA.........: 08/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
VALUES (
   (SELECT MAX(cdr_idcampo)+1 FROM GRECAMPOS_CDR),
   (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'FGPAGIR_FGI'),
   '(SELECT GRPAG_GPA.GPA_DSGRUPO FROM GRPAG_GPA WHERE GRPAG_GPA.GPA_CDGRUPO = FGI_CODGRPAG)',
   'Grp. Pag - Descri��o',
   0,
   'Grp.Pag - Descri��o')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 286568
PROMPT ======================================================================