PROMPT ======================================================================
PROMPT == DEMANDA......: 285386
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: RODRIGO MASSAYOSHI TOMA
PROMPT == DATA.........: 01/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGE360(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGE360         VARCHAR2(4) := 'E360';
   VR_ICMSSTSAIDA_E360 CHAR(1);
   CURSOR CS_REGE360 IS
      SELECT SEQ1_EFDLEDFREGISTROE360_E17.NEXTVAL AS IDLEDFREGISTROE360
           , PT_IDMODESCRITURACAO AS NRLME
           , CT_REGE360 AS REGE360
           , VL_01
           , VL_02
           , VL_03
           , VL_04
           , VL_05
           , VL_06
           , VL_07
           , VL_08
           , VL_09
           , VL_10
           , VL_11
           , VL_12
           , VL_13
           , DECODE(VL_12 - VL_13, ABS(VL_12 - VL_13), VL_12 - VL_13, 0) AS VL_14
           , VL_15
           , DECODE(VR_ICMSSTSAIDA_E360, 'S', VL_16, 0)
           , NVL(VL_17, 0) AS VL_17
           , VL_18
           , VL_19
           , DECODE( SIGN(VL_12 - VL_13), 1, (VL_12 - VL_13) + NVL(VL_17, 0) + VL_18 + VL_19 + VL_20, 0) AS VL_20
           , VL_99
        FROM (SELECT SUM(VL_01) AS VL_01
                   , SUM(VL_02) AS VL_02
                   , SUM(VL_03) AS VL_03
                   , SUM(VL_01 + VL_02 + VL_03) AS VL_04
                   , SUM(VL_05) AS VL_05
                   , SUM(VL_06) AS VL_06
                   , SUM(VL_07) AS VL_07
                   , SUM(VL_05 + VL_06 + VL_07) AS VL_08
                   , SUM(VL_09) AS VL_09
                   , SUM(VL_05 + VL_06 + VL_07 + VL_09) AS VL_10
                   , DECODE(
                        SUM((VL_05 + VL_06 + VL_07 + VL_09) - (VL_01 + VL_02 + VL_03))
                      , ABS(SUM((VL_05 + VL_06 + VL_07 + VL_09) - (VL_01 + VL_02 + VL_03))), SUM(
                                                                                                (VL_05 + VL_06 + VL_07 + VL_09) -
                                                                                                (VL_01 + VL_02 + VL_03))
                      , 0)
                        AS VL_11
                   , DECODE(
                        SUM((VL_01 + VL_02 + VL_03) - (VL_05 + VL_06 + VL_07 + VL_09))
                      , ABS(SUM((VL_01 + VL_02 + VL_03) - (VL_05 + VL_06 + VL_07 + VL_09))), SUM(
                                                                                                (VL_01 + VL_02 + VL_03) -
                                                                                                (VL_05 + VL_06 + VL_07 + VL_09))
                      , 0)
                        AS VL_12
                   , SUM(VL_13) AS VL_13
                   , SUM(VL_15) AS VL_15
                   , SUM(VL_16) AS VL_16
                   , SUM(VL_17) AS VL_17
                   , SUM(VL_18) AS VL_18
                   , SUM(VL_19) AS VL_19
                   , SUM(VL_20) AS VL_20
                   , SUM(VL_15 + VL_16) AS VL_99
                FROM (SELECT VL_01
                           , VL_02
                           , VL_03
                           , VL_05
                           , VL_06
                           , VL_07
                           , VL_09
                           , VL_13
                           , (E350_VL_OR + VL_15) AS VL_15
               , CASE WHEN (E330_VL_ST > E350_VL_OR) THEN (E330_VL_ST - E350_VL_OR) WHEN (E330_VL_ST = E350_VL_OR) THEN 0 ELSE E330_VL_ST END AS VL_16
                           , VL_17
                           , VL_18
                           , VL_19
                           , VL_20
                        FROM (SELECT NVL(SUM(DECODE(E02_TPINDOPER, 1, E02_VLICMS, 0)), 0) AS VL_01
                                   , 0 AS VL_02
                                   , 0 AS VL_03
                                   , NVL(SUM(DECODE(E02_TPINDOPER, 0, E02_VLICMS, 0)), 0) AS VL_05
                                   , 0 AS VL_06
                                   , 0 AS VL_07
                                   , 0 AS VL_09
                                   , 0 AS VL_13
                                   , NVL(SUM(DECODE(E02_TPINDOPER, 0, E02_VLST, 0)), 0) AS VL_15
                                   , NVL(SUM(DECODE(E02_TPINDOPER, 1, E02_VLST, 0)), 0) AS VL_16
                                   , 0 AS VL_17
                                   , 0 AS VL_18
                                   , 0 AS VL_19
                                   , 0 AS VL_20
                                FROM EFDLEDFREGISTROE020_E02
                               WHERE E02_NRLME = PT_IDMODESCRITURACAO)
                           , (SELECT SUM(E14_VLST) AS E330_VL_ST
                                FROM EFDLEDFREGISTROE330_E14
                               WHERE E14_TPINDTOT IN (4, 8)
                                 AND E14_NRLME = PT_IDMODESCRITURACAO)
                           , (SELECT SUM(E16_VLOR) AS E350_VL_OR
                                FROM EFDLEDFREGISTROE350_E16
                               WHERE E16_CDOR IN ('020', '030', '001')
                                 AND E16_NRLME = PT_IDMODESCRITURACAO)
                      UNION ALL
                      SELECT NVL(SUM(DECODE(E10_TPINDOPER, 1, E10_VLICMS, 0)), 0) AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , NVL(SUM(DECODE(E10_TPINDOPER, 0, E10_VLICMS, 0)), 0) AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
               , 0 AS VL_20
                        FROM EFDLEDFREGISTROE120_E10
                       WHERE E10_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT NVL(SUM(E07_VLICMSP), 0) AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , 0 AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
               , 0 AS VL_20
                        FROM EFDLEDFREGISTROE085_E07
                       WHERE E07_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT NVL(SUM(DECODE(E08_TPINDOPER, 1, E08_VLICMS, 0)), 0) AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , NVL(SUM(DECODE(E08_TPINDOPER, 0, E08_VLICMS, 0)), 0) AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
                           , 0 AS VL_20
                        FROM EFDLEDFREGISTROE100_E08
                       WHERE E08_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT 0 AS VL_01
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '1', E15_VLAJ, 0)), 0) AS VL_02
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '2', E15_VLAJ, 0)), 0) AS VL_03
                           , 0 AS VL_05
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '4', E15_VLAJ, 0)), 0) AS VL_06
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '5', E15_VLAJ, 0)), 0) AS VL_07
                           , 0 AS VL_09
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '6', E15_VLAJ, 0)), 0) AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
                           , 0 AS VL_20
                        FROM EFDLEDFREGISTROE340_E15
                       WHERE E15_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT 0 AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , 0 AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , CRA.CRA_VLSALDO AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
                           , 0 AS VL_20
                        FROM SPEDSALCREDANT_CRA CRA, EFDLEDFMODELOESCRIT_LME LME
                       WHERE CRA.CRA_TPIMPOSTO = '0'
                         AND CRA.CRA_CDEMPRESA = LME.LME_CDEMPRESA
                         AND CRA.CRA_CDFILIAL = LME.LME_CDFILIAL
                         AND CRA.CRA_PERIODO + 1 = LME.LME_DTINI
                         AND LME.LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT C14_VLICMS AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , 0 AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
                           , 0 AS VL_20
                        FROM EFDLEDFREGISTROC550_C14
                       WHERE C14_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT 0 AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , 0 AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , SUM(DECODE(OIR_CDOBRIGACAO, '020', OIR_VLOBRIGACAO, 0)) AS VL_17
                           , SUM(DECODE(OIR_CDOBRIGACAO, '004', OIR_VLOBRIGACAO, 0)) AS VL_18
               , SUM(DECODE(OIR_CDOBRIGACAO, '005', OIR_VLOBRIGACAO, 0)) AS VL_19
               , SUM(DECODE(OIR_CDOBRIGACAO, '999', OIR_VLOBRIGACAO, 0)) AS VL_20
                        FROM (SELECT DECODE(SAI_ICMSTPOPERACAO, 3, DECODE(SAI_UF, 'DF', '020', '999'), OIR_CDOBRIGACAO) AS OIR_CDOBRIGACAO
                                   , OIR_VLOBRIGACAO
                                FROM SPEDAPUICMS_SAI, SPEDOBICMSREC_OIR, EFDLEDFMODELOESCRIT_LME
                               WHERE SAI_SQAPUICMS = OIR_SQAPUICMS
                                 AND SAI_CDEMPRESA = LME_CDEMPRESA
                                 AND SAI_CDFILIAL = LME_CDFILIAL
                                 AND SAI_DATAINI >= LME_DTINI
                                 AND SAI_DATAFIM <= LME_DTFIN
                                 AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO)));
   TYPE TP_CS_REGE360 IS TABLE OF CS_REGE360%ROWTYPE
                            INDEX BY PLS_INTEGER;
   TB_CS_REGE360      TP_CS_REGE360;
BEGIN
    VR_ICMSSTSAIDA_E360 := 'S';
    FOR REC_PARAMS_PAR IN
       (SELECT PAR.PAR_VLPARAM FROM PARAMS_PAR PAR, EFDLEDFMODELOESCRIT_LME LME WHERE
               PAR.PAR_CDEMP = LME.LME_CDEMPRESA
           AND PAR.PAR_CDFILIAL = LME.LME_CDFILIAL
           AND PAR.PAR_CDPARAM = 'wPAR_LevarICMSSTSaidasLEDF'
           AND LME.LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO) LOOP
    VR_ICMSSTSAIDA_E360 := NVL(REC_PARAMS_PAR.PAR_VLPARAM,'S');
    END LOOP;
   OPEN CS_REGE360;
   LOOP
      FETCH CS_REGE360
        BULK COLLECT INTO TB_CS_REGE360
      LIMIT 100;
      EXIT WHEN TB_CS_REGE360.COUNT = 0;
      FORALL I IN TB_CS_REGE360.FIRST .. TB_CS_REGE360.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROE360_E17
         VALUES TB_CS_REGE360(I);
   END LOOP;
   CLOSE CS_REGE360;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGE360%ISOPEN
         THEN
            CLOSE CS_REGE360;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

UPDATE PARAMS_PAR
   SET PAR_VLPARAM = '02/07/2018'
 WHERE PAR_CDPARAM = 'PARDATALIMITENFE3.10'
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGB020(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGB020         VARCHAR2(4) := 'B020';
   CURSOR CS_REGB020 IS
      SELECT SEQ1_EFDLEDFREGISTROB020_B02.NEXTVAL AS IDLEDFREGISTROB020
           , PT_IDMODESCRITURACAO
           , SDFS_SQDOCFISSERV AS SQDOCFISSERV
           , CT_REGB020
           , DECODE(TPO_TIPO, 'E', '0', '1') AS IND_OPER
           , DECODE(SDFS_EMITENTE, 'P', '0', '1') AS IND_EMIT
           , DECODE(SDFS_SITDOC, '02', '', SDFS_CLIFOR) AS CLIFOR
           , DECODE(SDFS_SITDOC, '02', '', TRIM(SDFS_CDCLIFOR)) AS COD_PART
		   , NVL(DECODE(UPPER(TIP_DOCFISCAL), 'X1', '55', TIP_DOCFISCAL), '03') AS COD_MOD
           , NVL(SDFS_SITDOC, '00') AS COD_SIT
           , SDFS_SERIE AS SER
           , SDFS_SUBSERIE AS SUB
           , REPLACE(REPLACE(SDFS_DOCUMENTO, '-'), '/') AS NUM_DOC
           , TO_CHAR(SDFS_DATA, 'DDMMYYYY') AS DT_DOC
           , IRT_CDCFPS AS CFPS
           , 0 AS NUM_LCTO
           , DECODE(UF, 'EX', '', PPA_CODMUNIC) AS COD_MUN_SERV
           , SDFS_VLTOTAL - SDFS_VLTOTDESC AS VL_CONT
           , 0 AS VL_MAT_TERC
           , 0 AS VL_SUB
           , SDFS_VLBIISS AS VL_ISNT_ISS
           , 0 AS VL_DED_BC
           , CASE
                WHEN (NVL(TPO_GBTRBISS, 'N') = 'S')
                 AND (NVL(TPO_ISSDESTACADO, 'N') = 'S')
                THEN
                   SDFS_VLBCISS
                ELSE
                   0
             END
                AS VL_BC_ISS
           , CASE
                WHEN (NVL(TPO_GBISSRETIDO, 'N') = 'S')
                THEN
                   SDFS_VLBCISS
                ELSE
                   0
             END
                AS VL_BC_ISS_RT
           , CASE
                WHEN (NVL(TPO_GBISSRETIDO, 'N') = 'S')
                THEN
                   SDFS_VLISS
                ELSE
                   0
             END
                AS VL_ISS_RT
           , CASE
                WHEN (NVL(TPO_GBTRBISS, 'N') = 'S')
                 AND (NVL(TPO_ISSDESTACADO, 'N') = 'S')
                THEN
                   SDFS_VLISS
                ELSE
                   0
             END
                AS VL_ISS
           , '' AS COD_INF_OBS
           , TPO_CODIGO
        FROM SPEDDOCFISSERV_SDFS
             INNER JOIN TPOPER_TPO
                ON SDFS_TPOP = TPO_CODIGO
             LEFT JOIN TIPULO_TIP
                ON TPO_CDTIPTIT = TIP_CDTIPULO
             INNER JOIN SPEDPARPART_PPA
                ON SDFS_CDCLIFOR = PPA_CODIGOPART
               AND SDFS_CLIFOR = PPA_CLIFOR
             INNER JOIN EFDLEDFMODELOESCRIT_LME
                ON SDFS_CDEMPRESA = LME_CDEMPRESA
               AND SDFS_CDFILIAL = LME_CDFILIAL
               AND SDFS_DATAESCR >= LME_DTINI
               AND SDFS_DATAESCR <= LME_DTFIN
               AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
             LEFT JOIN EFDLEDFCABRELTOCFPS_TPS
                ON SDFS_CDEMPRESA = TPS_CDEMPRESA
               AND SDFS_CDFILIAL = TPS_CDFILIAL
             LEFT JOIN EFDLEDFITRELTOCFPS_IRT
                ON TPS_IDCABRELTOCFPS = IRT_NRTPS
               AND TPO_CODIGO = IRT_CDTPO
             INNER JOIN CLIENTEFORNEC
                ON SDFS_CLIFOR = TIPO
               AND SDFS_CDCLIFOR = CODIGO
       WHERE SDFS_SITDOC <> '02';
   TYPE TP_CS_REGB020 IS TABLE OF CS_REGB020%ROWTYPE
                            INDEX BY PLS_INTEGER;
   TB_CS_REGB020      TP_CS_REGB020;
BEGIN
   OPEN CS_REGB020;
   LOOP
      FETCH CS_REGB020
        BULK COLLECT INTO TB_CS_REGB020
      LIMIT 1000;
      EXIT WHEN TB_CS_REGB020.COUNT = 0;
      FORALL I IN TB_CS_REGB020.FIRST .. TB_CS_REGB020.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROB020_B02
         VALUES TB_CS_REGB020(I);
   END LOOP;
   CLOSE CS_REGB020;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGB020%ISOPEN
         THEN
            CLOSE CS_REGB020;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

CREATE OR REPLACE PACKAGE PKG_CALCULOCUSTOESTOQUE
IS
   PROCEDURE CALCULOCUSTOESTOQUE (
      ACDEMPRESA      IN   CHAR,
      ATPESTOQUE      IN   CHAR,
      AALMOXARIFADO   IN   CHAR,
      AITEM           IN   CHAR,
      ADATA           IN   DATE,
      ACRITICA        IN   CHAR
   );
   PROCEDURE ATUALIZAMOVTEMP;
   FUNCTION EXISTS_ERROR_SALDO (
      ACDEMPRESA      IN   CHAR,
      ATPESTOQUE      IN   CHAR,
      AALMOXARIFADO   IN   CHAR,
      AITEM           IN   CHAR
   ) RETURN BOOLEAN;
END PKG_CALCULOCUSTOESTOQUE;
/

CREATE OR REPLACE PACKAGE BODY PKG_CALCULOCUSTOESTOQUE IS
  FUNCTION BOOLEAN_VALUE(ASTRING IN CHAR) RETURN BOOLEAN AS
  BEGIN
    IF ASTRING = 'S' THEN
      RETURN(TRUE);
    ELSE
      RETURN(FALSE);
    END IF;
  END;
  FUNCTION GET_BOOLEAN_STR_VALUE(ABOOLEAN IN BOOLEAN) RETURN CHAR AS
  BEGIN
    IF ABOOLEAN THEN
      RETURN('S');
    ELSE
      RETURN('N');
    END IF;
  END;
  FUNCTION GET_FILIAL_ESTOQUE
  (
    CODEMPRESA  IN CHAR,
    ACODESTOQUE IN CHAR
  ) RETURN CHAR AS
    VCODFILIAL RELFILEST_RFE.RFE_FILIAL%TYPE;
    CURSOR FILIAL IS
      SELECT RFE_FILIAL
        FROM RELFILEST_RFE
       WHERE RFE_EMPRESA   = CODEMPRESA
         AND RFE_TPESTOQUE = ACODESTOQUE;
  BEGIN
    -----------------------------------------------------------------
    -- Recupera a filial relacionada ao Estoque
    -----------------------------------------------------------------
    OPEN FILIAL;
    FETCH FILIAL INTO VCODFILIAL;
    CLOSE FILIAL;
    RETURN(VCODFILIAL);
  END;
  FUNCTION VALIDA_SEG_MOEDA
  (
    ATPESTOQUE IN CHAR
  ) RETURN CHAR AS
    VSEGMOEDA ESTOQUES_EST.EST_SEGMOEDA%TYPE;
    CURSOR SEGMOEDA IS
      SELECT EST_SEGMOEDA
        FROM ESTOQUES_EST
       WHERE EST_CODIGO = ATPESTOQUE;
  BEGIN
    VSEGMOEDA := NULL;
    OPEN SEGMOEDA;
    FETCH SEGMOEDA INTO VSEGMOEDA;
    CLOSE SEGMOEDA;
    IF VSEGMOEDA IS NOT NULL THEN
      RETURN('S');
    ELSE
      RETURN('N');
    END IF;
  END;
  PROCEDURE SETUPVARIAVEISCALCULOCUSTO
  (
    ACDEMPRESA                IN CHAR,
    ATPESTOQUE                IN CHAR,
    AESTDECIMAL               IN OUT NUMBER,
    ADEVCUSTOMEDIO            IN OUT BOOLEAN,
    ACUSTOESPECIF             IN OUT BOOLEAN,
    AVALORIZA_TRANS_ALMX      IN OUT BOOLEAN,
    ACUSTONORMALTRANSEMPRESAS IN OUT BOOLEAN,
    ACUSTONORMALTRANSFILIAL   IN OUT BOOLEAN
  ) AS
    VDEVCUSMEDIO              PARAMSGE_PSGE.PSGE_DEVCUSMEDIO%TYPE;
    VCUSTOESPECIF             PARAMSGE_PSGE.PSGE_CUSTOESPECIF%TYPE;
    VVALORIZA_TRANS_ALMX      PARAMSGE_PSGE.PSGE_VALORIZATRANSFALMOX%TYPE;
    VCUSTONORMALTRANSEMPRESAS PARAMS_PAR.PAR_CDPARAM%TYPE;
    VCUSTONORMALTRANSFILIAL   PARAMS_PAR.PAR_CDPARAM%TYPE;
    CURSOR ESTOQUES IS
      SELECT EST_DECIMAL
        FROM ESTOQUES_EST
       WHERE EST_CODIGO = ATPESTOQUE;
    CURSOR PARAMSGE IS
      SELECT DECODE(PSGE_DEVCUSMEDIO, 'N', 'S', 'N'),
             PSGE_CUSTOESPECIF,
             PSGE_VALORIZATRANSFALMOX
        FROM PARAMSGE_PSGE
       WHERE PSGE_CDEMPRESA = ACDEMPRESA;
    CURSOR PARAMS_TRANSFERENCIAEMP IS
      SELECT PAR_VLPARAM
        FROM PARAMS_PAR
       WHERE PAR_CDPARAM = 'wSGE_CustoNormalTransEmpresas';
    CURSOR PARAMS_TRANSFERENCIAFIL IS
      SELECT PAR_VLPARAM
        FROM PARAMS_PAR
       WHERE PAR_CDPARAM = 'wSGE_CustoNormalTransFiliais';
  BEGIN
    ------------------------------------------------------------------------------
    -- Procedure que busca os parametros do sistema que tem influ�ncia sobre o calculo
    ------------------------------------------------------------------------------
    OPEN ESTOQUES;
    FETCH ESTOQUES INTO AESTDECIMAL;
    CLOSE ESTOQUES;
    OPEN PARAMSGE;
    FETCH PARAMSGE INTO VDEVCUSMEDIO, VCUSTOESPECIF, VVALORIZA_TRANS_ALMX;
    CLOSE PARAMSGE;
    OPEN PARAMS_TRANSFERENCIAEMP;
    FETCH PARAMS_TRANSFERENCIAEMP INTO VCUSTONORMALTRANSEMPRESAS;
    CLOSE PARAMS_TRANSFERENCIAEMP;
    OPEN PARAMS_TRANSFERENCIAFIL;
    FETCH PARAMS_TRANSFERENCIAFIL INTO VCUSTONORMALTRANSFILIAL;
    CLOSE PARAMS_TRANSFERENCIAFIL;
    IF VDEVCUSMEDIO IS NULL THEN
      VDEVCUSMEDIO := 'N';
    END IF;
    IF VCUSTOESPECIF IS NULL THEN
      VCUSTOESPECIF := 'N';
    END IF;
    IF VVALORIZA_TRANS_ALMX IS NULL THEN
      VVALORIZA_TRANS_ALMX := 'N';
    END IF;
    IF VCUSTONORMALTRANSEMPRESAS IS NULL THEN
      VCUSTONORMALTRANSEMPRESAS := 'N';
    END IF;
    IF VCUSTONORMALTRANSFILIAL IS NULL THEN
      VCUSTONORMALTRANSFILIAL := 'N';
    END IF;
    ADEVCUSTOMEDIO            := BOOLEAN_VALUE(VDEVCUSMEDIO);
    ACUSTOESPECIF             := BOOLEAN_VALUE(VCUSTOESPECIF);
    AVALORIZA_TRANS_ALMX      := BOOLEAN_VALUE(VVALORIZA_TRANS_ALMX);
    ACUSTONORMALTRANSEMPRESAS := BOOLEAN_VALUE(VCUSTONORMALTRANSEMPRESAS);
    ACUSTONORMALTRANSFILIAL   := BOOLEAN_VALUE(VCUSTONORMALTRANSFILIAL);
  END;
  FUNCTION VALIDA_LOADMOVIMENTACAO
  (
    ACDEMPRESA    IN CHAR,
    ATPESTOQUE    IN CHAR,
    AALMOXARIFADO IN CHAR,
    AITEM         IN CHAR
  ) RETURN BOOLEAN AS
    ASQNOTA MOVCALCCUSTO_MCC.MCC_SQNOTA%TYPE;
    CURSOR MOVCALCCUSTO IS
      SELECT MCC_SQNOTA
        FROM MOVCALCCUSTO_MCC
       WHERE MCC_CDEMPRESA = ACDEMPRESA
         AND MCC_TPESTOQUE = ATPESTOQUE
         AND MCC_ITEM = AITEM;
  BEGIN
    ------------------------------------------------------------------------------
    -- fun��o para verificar se os saldos daquele estoque j� foram adicionados
    -- a tabela tempor�ria
    ------------------------------------------------------------------------------
    OPEN MOVCALCCUSTO;
    FETCH MOVCALCCUSTO INTO ASQNOTA;
    IF MOVCALCCUSTO%FOUND THEN
      RETURN(FALSE);
    ELSE
      RETURN(TRUE);
    END IF;
    CLOSE MOVCALCCUSTO;
  END;
  PROCEDURE LOADMOVIMENTACAO_CALCULOCUSTO
  (
    ACDEMPRESA    IN CHAR,
    ATPESTOQUE    IN CHAR,
    AALMOXARIFADO IN CHAR,
    AITEM         IN CHAR,
    ADATA         IN DATE
  ) AS
  BEGIN
    ------------------------------------------------------------------------------
    -- Procedure que adiciona as movimentacoes de estoque a tabela tempor�ria
    -- Obs.: Os saldos anteriores s�o adicionados com o Sqnota = 0
    ------------------------------------------------------------------------------
    IF VALIDA_LOADMOVIMENTACAO(ACDEMPRESA, ATPESTOQUE, AALMOXARIFADO, AITEM) THEN
      --
      INSERT INTO MOVCALCCUSTO_MCC
        (MCC_SQNOTA,
         MCC_SEQUENCIA,
         MCC_TIPO,
         MCC_CDEMPRESA,
         MCC_TPESTOQUE,
         MCC_ALMOXARIFADO,
         MCC_ITEM,
         MCC_DATA,
         MCC_CUSTOINFORMADO,
         MCC_SQLOTESERIE,
         MCC_QTDMOV,
         MCC_QTDLOTESERIE,
         MCC_VALORMOV,
         MCC_VALORLOTESERIE,
         MCC_VALORMOVM,
         MCC_VALORLOTESERIEM,
         MCC_SQNOTARELTRANSF,
         MCC_DEVOLUCAO,
         MCC_REVISADO,
         MCC_DTCONTABILIZADO)
        (SELECT MCC_SQNOTA,
                ROWNUM MCC_SEQUENCIA,
                MCC_TIPO,
                MCC_CDEMPRESA,
                MCC_TPESTOQUE,
                MCC_ALMOXARIFADO,
                MCC_ITEM,
                MCC_DATA,
                MCC_CUSTOINFORMADO,
                MCC_SQLOTESERIE,
                MCC_QTDMOV,
                MCC_QTDLOTESERIE,
                MCC_VALORMOV,
                MCC_VALORLOTESERIE,
                MCC_VALORMOVM,
                MCC_VALORLOTESERIEM,
                MCC_SQNOTARELTRANSF,
                MCC_DEVOLUCAO,
                MCC_REVISADO,
                MCC_DTCONTABILIZADO
           FROM (SELECT 0 MCC_SQNOTA,
                        0 MCC_SEQUENCIA,
                        'E' MCC_TIPO,
                        MOV_CDEMPRESA MCC_CDEMPRESA,
                        MOV_TPESTOQUE MCC_TPESTOQUE,
                        MOV_ALMOXARIFADO MCC_ALMOXARIFADO,
                        MOV_ITEM MCC_ITEM,
                        ADATA - 1 MCC_DATA,
                        'S' MCC_CUSTOINFORMADO,
                        NVL(MLS_SQLOTESERIE, 0) MCC_SQLOTESERIE,
                        SUM(MOV_QTDAQ * DECODE(MOV_TIPO, 'S', -1, 1)) MCC_QTDMOV,
                        SUM(NVL(MLS_QTDCTRL * DECODE(MOV_TIPO, 'S', -1, 1), 0)) MCC_QTDLOTESERIE,
                        SUM(MOV_VALOR * DECODE(MOV_TIPO, 'S', -1, 1)) MCC_VALORMOV,
                        SUM(NVL(MLS_VLINFORMADO * DECODE(MOV_TIPO, 'S', -1, 1), 0)) MCC_VALORLOTESERIE,
                        SUM(MOV_VALORM * DECODE(MOV_TIPO, 'S', -1, 1)) MCC_VALORMOVM,
                        SUM(NVL(MLS_VLINFORMADOM * DECODE(MOV_TIPO, 'S', -1, 1), 0)) MCC_VALORLOTESERIEM,
                        0 MCC_SQNOTARELTRANSF,
                        'N' MCC_DEVOLUCAO,
                        'S' MCC_REVISADO,
                        NULL MCC_DTCONTABILIZADO
                   FROM MOVIMENTO_MOV,
                        MOVLOTESERIE_MLS
                  WHERE MOV_SQNOTA    = MLS_SQNOTA(+)
                    AND MOV_SEQUENCIA = MLS_SQMOVIMENTO(+)
                    AND MOV_CDEMPRESA = ACDEMPRESA
                    AND MOV_TPESTOQUE = ATPESTOQUE
                    AND MOV_DATA      < ADATA
                    AND MOV_ITEM      = AITEM
                  GROUP BY MOV_CDEMPRESA,
                           MOV_TPESTOQUE,
                           MOV_ALMOXARIFADO,
                           MLS_SQLOTESERIE,
                           MOV_ITEM)
         UNION ALL
         SELECT MOV_SQNOTA,
                MOV_SEQUENCIA,
                MOV_TIPO,
                MOV_CDEMPRESA,
                MOV_TPESTOQUE,
                MOV_ALMOXARIFADO,
                MOV_ITEM,
                MOV_DATA,
                DECODE(MOV_CUSTOINFORMADO, '', 'N', MOV_CUSTOINFORMADO),
                NVL(MLS_SQLOTESERIE, 0),
                MOV_QTDAQ,
                NVL(MLS_QTDCTRL, 0),
                MOV_VALOR,
                NVL(MLS_VLINFORMADO, 0),
                MOV_VALORM,
                NVL(MLS_VLINFORMADOM, 0),
                MOV_SQNOTARELTRANSF,
                MOV_DEVOLUCAO,
                'N',
                MOV_DTCONTABILIZADO MCC_DTCONTABILIZADO
           FROM MOVIMENTO_MOV,
                MOVLOTESERIE_MLS
          WHERE MOV_CDEMPRESA = ACDEMPRESA
            AND MOV_TPESTOQUE = ATPESTOQUE
            AND MOV_DATA     >= ADATA
            AND MOV_ITEM      = AITEM
            AND MOV_SQNOTA    = MLS_SQNOTA(+)
            AND MOV_SEQUENCIA = MLS_SQMOVIMENTO(+));
    END IF;
  END;
  PROCEDURE GETULTIMOCUSTO
  (
    ACDEMPRESA         IN CHAR,
    ATPESTOQUE         IN CHAR,
    AITEM              IN CHAR,
    ASQLOTESERIE       IN NUMBER,
    ADATA              IN DATE,
    ACUSTOESPECIF      IN BOOLEAN,
    AESTDECIMAL        IN NUMBER,
    ASALDO_FISICO      OUT NUMBER,
    ASALDO_FINANCEIRO  OUT NUMBER,
    ASALDO_FINANCEIROM OUT NUMBER
  ) AS
    ------------------------------------------------------------------------------
    -- Caso seja efetuada uma movimentacao a custo m�dio para um item sem saldo
    -- f�sico, o sistema deve considerar o �ltimo m�dio
    ------------------------------------------------------------------------------
    VCUSTOESPECIF PARAMSGE_PSGE.PSGE_CUSTOESPECIF%TYPE;
    -- ver se acha a ultima movimentacao na tabela temporaria
    CURSOR ULTIMOCUSTO_BUFFER IS
      SELECT DECODE(MCC_QTDMOV, 0, 1, MCC_QTDMOV),
             MCC_VALORMOV,
             MCC_VALORMOVM
        FROM MOVCALCCUSTO_MCC
       WHERE MCC_CDEMPRESA      = ACDEMPRESA
         AND MCC_TPESTOQUE      = ATPESTOQUE
         AND MCC_ITEM           = AITEM
         AND MCC_DATA          <= ADATA
         AND MCC_QTDMOV        <> 0
         AND MCC_CUSTOINFORMADO = 'N'
         AND MCC_REVISADO       = 'S'
         AND MCC_VALORMOV      <> 0
         AND (  (MCC_SQLOTESERIE = DECODE(VCUSTOESPECIF, 'S', ASQLOTESERIE, MCC_SQLOTESERIE))
              OR(MCC_SQLOTESERIE IS NULL)
             )
       ORDER BY MCC_DATA DESC;
    CURSOR ULTIMOCUSTO_MLS IS
    -- se nao achar procura na movimento_mov
      SELECT SUM(MLS.MLS_QTDCTRL),
             SUM(MLS.MLS_VLINFORMADO),
             SUM(MLS.MLS_VLINFORMADOM)
        FROM MOVIMENTO_MOV    MOV,
             MOVLOTESERIE_MLS MLS
       WHERE MOV.MOV_SQNOTA        = MLS.MLS_SQNOTA(+)
         AND MOV.MOV_SEQUENCIA     = MLS.MLS_SQMOVIMENTO(+)
         AND MOV.MOV_CDEMPRESA     = ACDEMPRESA
         AND MOV.MOV_TPESTOQUE     = ATPESTOQUE
         AND MOV.MOV_ITEM          = AITEM
         AND MOV_DATA              < ADATA
         AND MOV_CUSTOINFORMADO    = 'N'
         AND MOV.MOV_DOCUMENTODEV IS NULL
         AND MOV.MOV_VALOR        <> 0
         AND MLS.MLS_SQLOTESERIE   = ASQLOTESERIE
         AND MLS.MLS_QTDCTRL      <> 0
       ORDER BY MOV.MOV_DATA DESC;
    -- se nao achar procura na movimento_mov
    CURSOR ULTIMOCUSTOMEDIO IS
      SELECT MOV.MOV_QTDAQ,
             MOV.MOV_VALOR,
             MOV.MOV_VALORM
        FROM MOVIMENTO_MOV MOV
       WHERE MOV.MOV_CDEMPRESA      = ACDEMPRESA
         AND MOV.MOV_TPESTOQUE      = ATPESTOQUE
         AND MOV.MOV_ITEM           = AITEM
         AND MOV.MOV_DATA           < ADATA
         AND MOV.MOV_CUSTOINFORMADO = 'N'
         AND MOV.MOV_DOCUMENTODEV  IS NULL
         AND MOV.MOV_VALOR         <> 0
         AND MOV.MOV_QTDAQ         <> 0
       ORDER BY MOV.MOV_DATA DESC;
    CURSOR ULTIMOCUSTO IS
      SELECT MOV.MOV_QTDAQ,
             MOV.MOV_VALOR,
             MOV.MOV_VALORM
        FROM MOVIMENTO_MOV MOV
       WHERE MOV.MOV_CDEMPRESA     = ACDEMPRESA
         AND MOV.MOV_TPESTOQUE     = ATPESTOQUE
         AND MOV.MOV_ITEM          = AITEM
         AND MOV.MOV_DATA          < ADATA
         AND MOV.MOV_DOCUMENTODEV IS NULL
         AND MOV.MOV_VALOR        <> 0
         AND MOV.MOV_QTDAQ        <> 0
       ORDER BY MOV.MOV_DATA DESC;
  BEGIN
    ASALDO_FISICO      := NULL;
    ASALDO_FINANCEIRO  := NULL;
    ASALDO_FINANCEIROM := NULL;
    VCUSTOESPECIF      := GET_BOOLEAN_STR_VALUE((ACUSTOESPECIF) AND (ASQLOTESERIE > 0));
    OPEN ULTIMOCUSTO_BUFFER;
    FETCH ULTIMOCUSTO_BUFFER INTO ASALDO_FISICO, ASALDO_FINANCEIRO, ASALDO_FINANCEIROM;
    CLOSE ULTIMOCUSTO_BUFFER;
    IF ASALDO_FINANCEIRO IS NULL THEN
      IF (ACUSTOESPECIF AND ASQLOTESERIE IS NOT NULL) OR (ASQLOTESERIE IS NOT NULL AND ASQLOTESERIE > 0) THEN
        OPEN ULTIMOCUSTO_MLS;
        FETCH ULTIMOCUSTO_MLS INTO ASALDO_FISICO, ASALDO_FINANCEIRO, ASALDO_FINANCEIROM;
        CLOSE ULTIMOCUSTO_MLS;
      ELSE
        OPEN ULTIMOCUSTOMEDIO;
        FETCH ULTIMOCUSTOMEDIO INTO ASALDO_FISICO, ASALDO_FINANCEIRO, ASALDO_FINANCEIROM;
        CLOSE ULTIMOCUSTOMEDIO;
        IF ASALDO_FINANCEIRO IS NULL THEN
          OPEN ULTIMOCUSTO;
          FETCH ULTIMOCUSTO INTO ASALDO_FISICO, ASALDO_FINANCEIRO, ASALDO_FINANCEIROM;
          CLOSE ULTIMOCUSTO;
        END IF;
      END IF;
      ASALDO_FISICO      := NVL(ASALDO_FISICO, 0);
      ASALDO_FINANCEIRO  := NVL(ASALDO_FINANCEIRO, 0);
      ASALDO_FINANCEIROM := NVL(ASALDO_FINANCEIROM, 0);
    END IF;
  END;
  PROCEDURE GET_CUSTO_ITEM
  (
    ASQNOTA            IN NUMBER,
    ASEQUENCIA         IN NUMBER,
    ATIPO              IN CHAR,
    ASQLOTE            IN NUMBER,
    AQTDMOV            IN NUMBER,
    AQTDLOTE           IN NUMBER,
    ASALDO_FISICO      IN NUMBER,
    ASALDO_FINANCEIRO  IN NUMBER,
    ASALDO_FINANCEIROM IN NUMBER,
    AISORDEMPRODUCAO   IN BOOLEAN,
    AUSACUSTOORIGEM    IN BOOLEAN,
    ACUSTOESPECIF      IN BOOLEAN,
    ACDEMP_TRANS       IN CHAR,
    ATPEST_TRANS       IN CHAR,
    AALMOX_TRANS       IN CHAR,
    ADATA_TRANS        IN DATE,
    AITEM_TRANS        IN CHAR,
    AESTDECIMAL        IN NUMBER,
    AVALOR             OUT NUMBER,
    AVALORM            OUT NUMBER,
    AVALORLOTE         OUT NUMBER,
    AVALORLOTEM        OUT NUMBER
  ) AS
    VCUSTO_UNITARIO          NUMBER(28, 8);
    VCUSTO_UNITARIOM         NUMBER(28, 8);
    VSALDO_FINANCEIRO_TRANS  NUMBER(28, 8);
    VSALDO_FINANCEIROM_TRANS NUMBER(28, 8);
    VSALDO_FISICO_TRANS      NUMBER(28, 8);
    CURSOR CUSTO_ORIGEM IS
      SELECT SUM(DECODE(MOV_TIPO, 'E', 1, -1) * MOV_VALOR) AS SALDO_FINANCEIRO_TRANS,
             SUM(DECODE(MOV_TIPO, 'E', 1, -1) * MOV_VALORM) AS SALDO_FINANCEIROM_TRANS,
             SUM(DECODE(MOV_TIPO, 'E', 1, -1) * MOV_QTDAQ) AS SALDO_FISICO_TRANS
        FROM MOVIMENTO_MOV
       WHERE MOV_CDEMPRESA = ACDEMP_TRANS
         AND MOV_TPESTOQUE = ATPEST_TRANS
         AND MOV_ITEM      = AITEM_TRANS
         AND MOV_DATA     <= ADATA_TRANS;
    CURSOR CUSTO_ORIGEM_LOTE IS
      SELECT SUM(DECODE(MOV_TIPO, 'E', 1, -1) * MLS_VLINFORMADO) AS SALDO_FINANCEIRO_TRANS,
             SUM(DECODE(MOV_TIPO, 'E', 1, -1) * MLS_VLINFORMADOM) AS SALDO_FINANCEIROM_TRANS,
             SUM(DECODE(MOV_TIPO, 'E', 1, -1) * M.MLS_QTDCTRL) AS SALDO_FISICO_TRANS
        FROM MOVIMENTO_MOV,
             MOVLOTESERIE_MLS M
       WHERE MOV_CDEMPRESA   = ACDEMP_TRANS
         AND MOV_TPESTOQUE   = ATPEST_TRANS
         AND MOV_ITEM        = AITEM_TRANS
         AND MOV_DATA       <= ADATA_TRANS
         AND MLS_SQLOTESERIE = ASQLOTE
         AND MLS_SQNOTA      = MOV_SQNOTA
         AND MLS_SQMOVIMENTO = MOV_SEQUENCIA;
  BEGIN
    IF (NOT AUSACUSTOORIGEM) OR (AUSACUSTOORIGEM AND ATIPO = 'S') THEN
      -- Se for uma ordem de produ��o acata o custo calculado anteriormente.
      IF NOT AISORDEMPRODUCAO THEN
        IF ASALDO_FISICO > 0 THEN
          VCUSTO_UNITARIO  := ASALDO_FINANCEIRO / ASALDO_FISICO;
          VCUSTO_UNITARIOM := ASALDO_FINANCEIROM / ASALDO_FISICO;
        ELSE
          VCUSTO_UNITARIO  := 0;
          VCUSTO_UNITARIOM := 0;
        END IF;
      END IF;
      IF AQTDMOV = ASALDO_FISICO THEN
        AVALOR  := ROUND(ASALDO_FINANCEIRO, AESTDECIMAL);
        AVALORM := ROUND(ASALDO_FINANCEIROM, AESTDECIMAL);
      ELSE
        AVALOR  := ROUND(AQTDMOV * VCUSTO_UNITARIO, AESTDECIMAL);
        AVALORM := ROUND(AQTDMOV * VCUSTO_UNITARIOM, AESTDECIMAL);
      END IF;
      IF AQTDLOTE = ASALDO_FISICO THEN
        AVALORLOTE  := ROUND(ASALDO_FINANCEIRO, AESTDECIMAL);
        AVALORLOTEM := ROUND(ASALDO_FINANCEIROM, AESTDECIMAL);
      ELSE
        AVALORLOTE  := ROUND(AQTDLOTE * VCUSTO_UNITARIO, AESTDECIMAL);
        AVALORLOTEM := ROUND(AQTDLOTE * VCUSTO_UNITARIOM, AESTDECIMAL);
      END IF;
    ELSE
      IF ASQLOTE > 0 THEN
        OPEN CUSTO_ORIGEM_LOTE;
        FETCH CUSTO_ORIGEM_LOTE INTO VSALDO_FINANCEIRO_TRANS, VSALDO_FINANCEIROM_TRANS, VSALDO_FISICO_TRANS;
        CLOSE CUSTO_ORIGEM_LOTE;
      ELSE
        OPEN CUSTO_ORIGEM;
        FETCH CUSTO_ORIGEM INTO VSALDO_FINANCEIRO_TRANS, VSALDO_FINANCEIROM_TRANS, VSALDO_FISICO_TRANS;
        CLOSE CUSTO_ORIGEM;
      END IF;
      IF VSALDO_FISICO_TRANS = 0 THEN
        GETULTIMOCUSTO(ACDEMP_TRANS,
                       ATPEST_TRANS,
                       AITEM_TRANS,
                       ASQLOTE,
                       ADATA_TRANS,
                       ACUSTOESPECIF,
                       AESTDECIMAL,
                       VSALDO_FISICO_TRANS,
                       VSALDO_FINANCEIRO_TRANS,
                       VSALDO_FINANCEIROM_TRANS);
      END IF;
      IF VSALDO_FISICO_TRANS > 0 THEN
        VCUSTO_UNITARIO  := VSALDO_FINANCEIRO_TRANS / VSALDO_FISICO_TRANS;
        VCUSTO_UNITARIOM := VSALDO_FINANCEIROM_TRANS / VSALDO_FISICO_TRANS;
      ELSE
        VCUSTO_UNITARIO  := VSALDO_FINANCEIRO_TRANS;
        VCUSTO_UNITARIOM := VSALDO_FINANCEIROM_TRANS;
      END IF;
      IF AQTDMOV = 0 THEN
        AVALOR  := ROUND(VCUSTO_UNITARIO, AESTDECIMAL);
        AVALORM := ROUND(VCUSTO_UNITARIO, AESTDECIMAL);
      ELSE
        AVALOR  := ROUND(AQTDMOV * VCUSTO_UNITARIO, AESTDECIMAL);
        AVALORM := ROUND(AQTDMOV * VCUSTO_UNITARIOM, AESTDECIMAL);
      END IF;
      IF AQTDLOTE = 0 THEN
        AVALORLOTE  := ROUND(VCUSTO_UNITARIO, AESTDECIMAL);
        AVALORLOTEM := ROUND(VCUSTO_UNITARIOM, AESTDECIMAL);
      ELSE
        AVALORLOTE  := ROUND(AQTDLOTE * VCUSTO_UNITARIO, AESTDECIMAL);
        AVALORLOTEM := ROUND(AQTDLOTE * VCUSTO_UNITARIOM, AESTDECIMAL);
      END IF;
    END IF;
  END;
  PROCEDURE GET_SALDOS_ESTOQUE
  (
    ACDEMPRESA         IN CHAR,
    ATPESTOQUE         IN CHAR,
    AALMOXARIFADO      IN CHAR,
    AITEM              IN CHAR,
    ADATA              IN DATE,
    ASQLOTESERIE       IN CHAR,
    ACUSTOESPECIF      IN BOOLEAN,
    AESTDECIMAL        IN NUMBER,
    ASALDO_FISICO      OUT NUMBER,
    ASALDO_FINANCEIRO  OUT NUMBER,
    ASALDO_FINANCEIROM OUT NUMBER
  ) AS
    VSALDO_FISICO      NUMBER(28, 8);
    VSALDO_FINANCEIRO  NUMBER(28, 8);
    VSALDO_FINANCEIROM NUMBER(28, 8);
    CURSOR CUSTOMEDIO IS
      SELECT SUM(DECODE(ASQLOTESERIE, 0, MCC_QTDMOV, MCC_QTDLOTESERIE) * DECODE(MCC_TIPO, 'S', -1, 1)) AS SALDO_FISICO,
             SUM(DECODE(ASQLOTESERIE, 0, MCC_VALORMOV, MCC_VALORLOTESERIE) * DECODE(MCC_TIPO, 'S', -1, 1)) AS SALDO_FINANCEIRO,
             SUM(DECODE(ASQLOTESERIE, 0, MCC_VALORMOVM, MCC_VALORLOTESERIEM) * DECODE(MCC_TIPO, 'S', -1, 1)) AS SALDO_FINANCEIROM
        FROM MOVCALCCUSTO_MCC
       WHERE MCC_CDEMPRESA = ACDEMPRESA
         AND MCC_TPESTOQUE = ATPESTOQUE
         AND MCC_ITEM      = AITEM
         AND (  (MCC_DATA < ADATA)
              OR(   (MCC_DATA = ADATA)
                 AND(  (MCC_CUSTOINFORMADO = 'S')
                     OR(MCC_REVISADO = 'S')
                    )
                )
             );
    -- Se for custo espec�fico pega o custo do lote em todos os estoques.
    CURSOR CUSTOMEDIO_LOTE IS
      SELECT SUM(MCC_QTDLOTESERIE * DECODE(MCC_TIPO, 'S', -1, 1)) AS SALDO_FISICO,
             SUM(MCC_VALORLOTESERIE * DECODE(MCC_TIPO, 'S', -1, 1)) AS SALDO_FINANCEIRO,
             SUM(MCC_VALORLOTESERIEM * DECODE(MCC_TIPO, 'S', -1, 1)) AS SALDO_FINANCEIROM
        FROM MOVCALCCUSTO_MCC
       WHERE MCC_CDEMPRESA   = ACDEMPRESA
         AND MCC_ITEM        = AITEM
         AND MCC_SQLOTESERIE = ASQLOTESERIE
         AND (  (MCC_DATA < ADATA)
              OR(   (MCC_DATA = ADATA)
                 AND(  (MCC_CUSTOINFORMADO = 'S')
                     OR(MCC_REVISADO = 'S')
                    )
                )
             );
  BEGIN
    ------------------------------------------------------------------------------
    -- Busca os saldos atuais f�sicos e financeiros com base nas altera��es efetuadas
    -- durante o procedimento de c�lculo
    ------------------------------------------------------------------------------
    IF (ACUSTOESPECIF) AND (ASQLOTESERIE > 0) THEN
      OPEN CUSTOMEDIO_LOTE;
      FETCH CUSTOMEDIO_LOTE INTO VSALDO_FISICO, VSALDO_FINANCEIRO, VSALDO_FINANCEIROM;
      CLOSE CUSTOMEDIO_LOTE;
    ELSE
      OPEN CUSTOMEDIO;
      FETCH CUSTOMEDIO INTO VSALDO_FISICO, VSALDO_FINANCEIRO, VSALDO_FINANCEIROM;
      CLOSE CUSTOMEDIO;
    END IF;
    IF VSALDO_FISICO > 0 THEN
      ASALDO_FISICO      := VSALDO_FISICO;
      ASALDO_FINANCEIRO  := VSALDO_FINANCEIRO;
      ASALDO_FINANCEIROM := VSALDO_FINANCEIROM;
    ELSE
      GETULTIMOCUSTO(ACDEMPRESA,
                     ATPESTOQUE,
                     AITEM,
                     ASQLOTESERIE,
                     ADATA,
                     ACUSTOESPECIF,
                     AESTDECIMAL,
                     VSALDO_FISICO,
                     VSALDO_FINANCEIRO,
                     VSALDO_FINANCEIROM);
      ASALDO_FISICO      := VSALDO_FISICO;
      ASALDO_FINANCEIRO  := VSALDO_FINANCEIRO;
      ASALDO_FINANCEIROM := VSALDO_FINANCEIROM;
    END IF;
  END;
  PROCEDURE GET_SALDOS_DEVOLUCAO
  (
    ASQNOTA            IN CHAR,
    ASEQUENCIA         IN CHAR,
    ASQLOTESERIE       IN CHAR,
    ACUSTOESPECIF      IN BOOLEAN,
    ASALDO_FISICO      OUT NUMBER,
    ASALDO_FINANCEIRO  OUT NUMBER,
    ASALDO_FINANCEIROM OUT NUMBER
  ) AS
    VSALDO_FISICO      NUMBER(28, 8);
    VSALDO_FINANCEIRO  NUMBER(28, 8);
    VSALDO_FINANCEIROM NUMBER(28, 8);
    CURSOR CUSTODEV IS
      SELECT NVL(MCC_QTDMOV, A.MOV_QTDAQ),
             NVL(MCC_VALORMOV, A.MOV_VALOR),
             NVL(MCC_VALORMOVM, A.MOV_VALORM)
        FROM MOVIMENTO_MOV    A,
             MOVIMENTO_MOV    B,
             MOVDEVMOV_MDM,
             MOVCALCCUSTO_MCC
       WHERE MDM_SQNOTA       = A.MOV_SQNOTA
         AND MDM_SEQUENCIA    = A.MOV_SEQUENCIA
         AND MDM_SQNOTADEV    = B.MOV_SQNOTA
         AND MDM_SEQUENCIADEV = B.MOV_SEQUENCIA
         AND A.MOV_SQNOTA     = MCC_SQNOTA(+)
         AND A.MOV_SEQUENCIA  = MCC_SEQUENCIA(+)
         AND B.MOV_SQNOTA     = ASQNOTA
         AND B.MOV_SEQUENCIA  = ASEQUENCIA;
    -- Se for custo espec�fico pega o custo do lote em todos os estoques.
    CURSOR CUSTODEV_LOTE IS
      SELECT MLS_QTDCTRL,
             MLS_VLINFORMADO,
             MLS_VLINFORMADOM
        FROM MOVIMENTO_MOV    A,
             MOVIMENTO_MOV    B,
             MOVDEVMOV_MDM,
             MOVLOTESERIE_MLS
       WHERE MDM_SQNOTA       = A.MOV_SQNOTA
         AND MDM_SEQUENCIA    = A.MOV_SEQUENCIA
         AND MDM_SQNOTADEV    = B.MOV_SQNOTA
         AND MDM_SEQUENCIADEV = B.MOV_SEQUENCIA
         AND A.MOV_SQNOTA     = MLS_SQNOTA
         AND A.MOV_SEQUENCIA  = MLS_SQMOVIMENTO
         AND B.MOV_SQNOTA     = ASQNOTA
         AND B.MOV_SEQUENCIA  = ASEQUENCIA
         AND MLS_SQLOTESERIE  = ASQLOTESERIE;
  BEGIN
    ------------------------------------------------------------------------------
    -- Verifica se existe NF de origem para a devolu��o, caso possua, utiliza
    -- o mesmo custo
    ------------------------------------------------------------------------------
    IF (ACUSTOESPECIF) AND (ASQLOTESERIE > 0) THEN
      OPEN CUSTODEV_LOTE;
      FETCH CUSTODEV_LOTE INTO VSALDO_FISICO, VSALDO_FINANCEIRO, VSALDO_FINANCEIROM;
      CLOSE CUSTODEV_LOTE;
    ELSE
      OPEN CUSTODEV;
      FETCH CUSTODEV INTO VSALDO_FISICO, VSALDO_FINANCEIRO, VSALDO_FINANCEIROM;
      CLOSE CUSTODEV;
    END IF;
    IF VSALDO_FISICO > 0 THEN
      ASALDO_FISICO      := VSALDO_FISICO;
      ASALDO_FINANCEIRO  := VSALDO_FINANCEIRO;
      ASALDO_FINANCEIROM := VSALDO_FINANCEIROM;
    ELSE
      ASALDO_FISICO      := 0;
      ASALDO_FINANCEIRO  := 0;
      ASALDO_FINANCEIROM := 0;
    END IF;
  END;
  PROCEDURE CALCULACUSTOORDPRODUCAO
  (
    ASQNOTA          IN NUMBER,
    ASQMOVIMENTO     IN NUMBER,
    ISPRODUCAO       OUT BOOLEAN,
    ACUSTOUNITARIOOP OUT NUMBER
  ) AS
    VCDORDEM  MOVATENDORDENS_MAO.MAO_CDORDPROD%TYPE;
    VCDMODELO MOVATENDORDENS_MAO.MAO_CDMODELO%TYPE;
    CURSOR ORDEMPRODUCAO IS
      SELECT MAO_CDORDPROD,
             MAO_CDMODELO
        FROM MOVATENDORDENS_MAO
       WHERE MAO_SQNOTA      = ASQNOTA
         AND MAO_SQMOVIMENTO = ASQMOVIMENTO;
  BEGIN
    ISPRODUCAO := FALSE;
    -- nao calcula custo do pcp em segunda moeda
    OPEN ORDEMPRODUCAO;
    FETCH ORDEMPRODUCAO INTO VCDORDEM, VCDMODELO;
    CLOSE ORDEMPRODUCAO;
    IF (VCDORDEM IS NOT NULL) THEN
      ISPRODUCAO       := TRUE;
      ACUSTOUNITARIOOP := GET_CUSTO_ORDPRODUCAO(VCDORDEM, VCDMODELO);
    END IF;
  END;
  PROCEDURE ATUALIZAMOV_BUFFER
  (
    ASQNOTA      IN NUMBER,
    ASEQUENCIA   IN NUMBER,
    ASQLOTE      IN NUMBER,
    AVALOR       IN NUMBER,
    AVALORLOTE   IN NUMBER,
    AVALORM      IN NUMBER,
    AVALORLOTEM  IN NUMBER,
    ACUSTOINFORM IN CHAR,
    AREVISADO    IN CHAR
  ) AS
  BEGIN
    ------------------------------------------------------------------------------
    -- Atualiza a tabela tempor�ria com os valores calculados
    ------------------------------------------------------------------------------
    UPDATE MOVCALCCUSTO_MCC
       SET MCC_VALORMOV        = AVALOR,
           MCC_VALORLOTESERIE  = AVALORLOTE,
           MCC_VALORMOVM       = AVALORM,
           MCC_VALORLOTESERIEM = AVALORLOTEM,
           MCC_CUSTOINFORMADO  = ACUSTOINFORM,
           MCC_REVISADO        = AREVISADO
     WHERE MCC_SQNOTA      = ASQNOTA
       AND MCC_SEQUENCIA   = ASEQUENCIA
       AND MCC_SQLOTESERIE = ASQLOTE;
  END;
  PROCEDURE INSERROCALCULOCUSTO_ECC
  (
    PECC_CODERRO      IN CHAR,
    PECC_CDEMPRESA    IN CHAR,
    PECC_TPESTOQUE    IN CHAR,
    PECC_ALMOXARIFADO IN CHAR,
    PECC_SQLOTESERIE  IN NUMBER,
    PECC_ITEM         IN CHAR,
    PECC_DATA         IN DATE,
    PECC_SALDOVALOR   IN NUMBER,
    PECC_SALDOVALORM  IN NUMBER,
    PECC_SALDO        IN NUMBER
  ) AS
    VCOUNT NUMBER;
  BEGIN
    SELECT COUNT(1)
      INTO VCOUNT
      FROM ERROCALCULOCUSTO_ECC
     WHERE ECC_CODERRO   = PECC_CODERRO
       AND ECC_CDEMPRESA = PECC_CDEMPRESA
       AND ECC_TPESTOQUE = PECC_TPESTOQUE
       AND ECC_ITEM = PECC_ITEM
       AND (  (ECC_ALMOXARIFADO = PECC_ALMOXARIFADO)
            OR(ECC_ALMOXARIFADO IS NULL)
           )
       AND (  (ECC_SQLOTESERIE = PECC_SQLOTESERIE)
            OR(ECC_SQLOTESERIE IS NULL)
           );
    -- nao deixar duplicar os erros na tabela de erro
    IF VCOUNT = 0 THEN
      INSERT INTO ERROCALCULOCUSTO_ECC
        (ECC_IDERROCALCULOCUSTO,
         ECC_CODERRO,
         ECC_CDEMPRESA,
         ECC_TPESTOQUE,
         ECC_ALMOXARIFADO,
         ECC_SQLOTESERIE,
         ECC_ITEM,
         ECC_DATA,
         ECC_SALDOVALOR,
         ECC_SALDOVALORM,
         ECC_SALDO)
      VALUES
        (SEQ1_ERROCALCULOCUSTO_ECC.NEXTVAL,
         PECC_CODERRO,
         PECC_CDEMPRESA,
         PECC_TPESTOQUE,
         PECC_ALMOXARIFADO,
         PECC_SQLOTESERIE,
         PECC_ITEM,
         PECC_DATA,
         PECC_SALDOVALOR,
         PECC_SALDOVALORM,
         PECC_SALDO);
    END IF;
  END;
  PROCEDURE VALIDAPERIODOCONTABILIZADO
  (
    ACDEMPRESA        IN CHAR,
    ATPESTOQUE        IN CHAR,
    AALMOXARIFADO     IN CHAR,
    AITEM             IN CHAR,
    ASQLOTESERIE      IN NUMBER,
    ADATA             IN DATE,
    AQTDMOV           IN NUMBER,
    AVALOR            IN NUMBER,
    AVALORM           IN NUMBER,
    AVALORATUALIZADO  IN NUMBER,
    AVALORATUALIZADOM IN NUMBER,
    AERROSALDO        IN OUT BOOLEAN
  ) IS
    VCODERROCTB VARCHAR2(10);
  BEGIN
    VCODERROCTB := 'CTBSGE_001';
    ----------------------------------------------------------------------------
    -- Caso per�odo esteja contabilizado e a movimentacao esteja sofrendo
    -- altera��es devido a revisao dos custos, bloqueia a opera��o
    ----------------------------------------------------------------------------
    IF (AVALOR <> AVALORATUALIZADO) OR (AVALORM <> AVALORATUALIZADOM) THEN
      AERROSALDO := FALSE;
      INSERT INTO ERROPROCESSO_EPC
      VALUES
        ('CALCCUSTO001',
         1,
         'O procedimento est� alterando o custo de movimenta��es j� contabilizadas.' ||
         '  Empresa => "' || ACDEMPRESA || '" Estoque => "' || ATPESTOQUE ||
         '" Data => "' || TO_CHAR(ADATA) || '".');
    END IF;
  END;
  PROCEDURE VALIDASALDOSESTOQUE
  (
    ACDEMPRESA    IN CHAR,
    ATPESTOQUE    IN CHAR,
    AALMOXARIFADO IN CHAR,
    AITEM         IN CHAR,
    ASQLOTESERIE  IN NUMBER,
    ACUSTOESPECIF IN BOOLEAN,
    AESTDECIMAL   IN NUMBER,
    ADATA         IN DATE,
    AERROSALDO    IN OUT BOOLEAN
  ) IS
    VCUSTOESPECIF     PARAMSGE_PSGE.PSGE_CUSTOESPECIF%TYPE;
    VCODERROSALDOQTD  VARCHAR2(10);
    VCODERROSALDOVLR  VARCHAR2(10);
    VCODERROSALDOVLRM VARCHAR2(10);
    VSALDOFINANCEIRO  NUMBER(28, 8);
    VSALDOFINANCEIROM NUMBER(28, 8);
    VSALDOFISICO      NUMBER(28, 8);
    CURSOR SALDO_FINANCEIRO IS
      SELECT SUM(DECODE(ASQLOTESERIE, 0, MCC_VALORMOV, MCC_VALORLOTESERIE) * DECODE(MCC_TIPO, 'S', -1, 1)) AS SALDO,
             SUM(DECODE(ASQLOTESERIE, 0, MCC_VALORMOVM, MCC_VALORLOTESERIEM) * DECODE(MCC_TIPO, 'S', -1, 1)) AS SALDOM
        FROM MOVCALCCUSTO_MCC
       WHERE MCC_CDEMPRESA   = ACDEMPRESA
         AND MCC_TPESTOQUE   = DECODE(VCUSTOESPECIF, 'S', MCC_TPESTOQUE, ATPESTOQUE)
         AND MCC_ITEM        = AITEM
            --somente filtra lote ser o custo for espec�fico
         AND MCC_SQLOTESERIE = DECODE(VCUSTOESPECIF, 'S', ASQLOTESERIE, MCC_SQLOTESERIE)
         AND (  (MCC_DATA < ADATA)
              OR(   (MCC_DATA = ADATA)
                 AND(  (MCC_CUSTOINFORMADO = 'S')
                     OR(MCC_REVISADO = 'S')
                    )
                )
             );
    CURSOR SALDO_FISICO IS
      SELECT SUM(DECODE(ASQLOTESERIE, 0, MCC_QTDMOV, MCC_QTDLOTESERIE) *
                 DECODE(MCC_TIPO, 'S', -1, 1)) AS SALDO
        FROM MOVCALCCUSTO_MCC
       WHERE MCC_CDEMPRESA    = ACDEMPRESA
         AND MCC_TPESTOQUE    = DECODE(VCUSTOESPECIF, 'S', MCC_TPESTOQUE, ATPESTOQUE)
         AND MCC_ALMOXARIFADO = AALMOXARIFADO
         AND MCC_ITEM         = AITEM
            --somente filtra lote ser o custo for espec�fico
         AND MCC_SQLOTESERIE  = ASQLOTESERIE
         AND (  (MCC_DATA < ADATA)
              OR(   (MCC_DATA = ADATA)
                 AND(  (MCC_CUSTOINFORMADO = 'S')
                     OR(MCC_REVISADO = 'S')
                    )
                )
             );
  BEGIN
    VCUSTOESPECIF := GET_BOOLEAN_STR_VALUE((ACUSTOESPECIF) AND (ASQLOTESERIE > 0));
    --C�digos de erros sao traduzidos atrav�s dos objetos de neg�cio do sistema
    VCODERROSALDOQTD  := 'SLDCC_001';
    VCODERROSALDOVLR  := 'SLDCC_002';
    VCODERROSALDOVLRM := 'SLDCC_003';
    OPEN SALDO_FISICO;
    FETCH SALDO_FISICO INTO VSALDOFISICO;
    CLOSE SALDO_FISICO;
    OPEN SALDO_FINANCEIRO;
    FETCH SALDO_FINANCEIRO INTO VSALDOFINANCEIRO, VSALDOFINANCEIROM;
    CLOSE SALDO_FINANCEIRO;
    IF VSALDOFISICO < 0 THEN
      AERROSALDO := TRUE;
      INSERROCALCULOCUSTO_ECC(VCODERROSALDOQTD,
                              ACDEMPRESA,
                              ATPESTOQUE,
                              AALMOXARIFADO,
                              ASQLOTESERIE,
                              AITEM,
                              ADATA,
                              ROUND(VSALDOFINANCEIRO, AESTDECIMAL),
                              ROUND(VSALDOFINANCEIROM, AESTDECIMAL),
                              VSALDOFISICO);
    END IF;
    IF ROUND(VSALDOFINANCEIRO, AESTDECIMAL) < 0 THEN
      AERROSALDO := TRUE;
      INSERROCALCULOCUSTO_ECC(VCODERROSALDOVLR,
                              ACDEMPRESA,
                              ATPESTOQUE,
                              AALMOXARIFADO,
                              ASQLOTESERIE,
                              AITEM,
                              ADATA,
                              ROUND(VSALDOFINANCEIRO, AESTDECIMAL),
                              ROUND(VSALDOFINANCEIROM, AESTDECIMAL),
                              VSALDOFISICO);
    END IF;
    IF (ROUND(VSALDOFINANCEIROM, AESTDECIMAL) < 0) AND (VALIDA_SEG_MOEDA(ATPESTOQUE) = 'S') THEN
      AERROSALDO := TRUE;
      INSERROCALCULOCUSTO_ECC(VCODERROSALDOVLRM,
                              ACDEMPRESA,
                              ATPESTOQUE,
                              AALMOXARIFADO,
                              ASQLOTESERIE,
                              AITEM,
                              ADATA,
                              ROUND(VSALDOFINANCEIRO, AESTDECIMAL),
                              ROUND(VSALDOFINANCEIROM, AESTDECIMAL),
                              VSALDOFISICO);
    END IF;
  END;
  PROCEDURE PROCESSOCALCULOCUSTO
  (
    ACDEMPRESA                IN CHAR,
    ATPESTOQUE                IN CHAR,
    AALMOXARIFADO             IN CHAR,
    AITEM                     IN CHAR,
    ADATA                     IN DATE,
    AESTDECIMAL               IN NUMBER,
    ACUSTOESPECIF             IN BOOLEAN,
    ACUSTONORMALTRANSEMPRESAS IN BOOLEAN,
    ACUSTONORMALTRANSFILIAL   IN BOOLEAN,
    ACRITICA                  IN CHAR,
    AERROSALDO                IN OUT BOOLEAN
  ) AS
    VSQNOTA              MOVCALCCUSTO_MCC.MCC_SQNOTA%TYPE;
    VSEQUENCIA           MOVCALCCUSTO_MCC.MCC_SEQUENCIA%TYPE;
    VTIPO                MOVCALCCUSTO_MCC.MCC_TIPO%TYPE;
    VCDEMPRESA           MOVCALCCUSTO_MCC.MCC_CDEMPRESA%TYPE;
    VTPESTOQUE           MOVCALCCUSTO_MCC.MCC_TPESTOQUE%TYPE;
    VALMOXARIFADO        MOVCALCCUSTO_MCC.MCC_ALMOXARIFADO%TYPE;
    VITEM                MOVCALCCUSTO_MCC.MCC_ITEM%TYPE;
    VDATA                MOVCALCCUSTO_MCC.MCC_DATA%TYPE;
    VCUSTOINFORM         MOVCALCCUSTO_MCC.MCC_CUSTOINFORMADO%TYPE;
    VSQLOTE              MOVCALCCUSTO_MCC.MCC_SQLOTESERIE%TYPE;
    VQTDMOV              MOVCALCCUSTO_MCC.MCC_QTDMOV%TYPE;
    VQTDLOTE             MOVCALCCUSTO_MCC.MCC_QTDLOTESERIE%TYPE;
    VVALORMOV            MOVCALCCUSTO_MCC.MCC_VALORMOV%TYPE;
    VVALORLOTESERIE      MOVCALCCUSTO_MCC.MCC_VALORLOTESERIE%TYPE;
    VVALORMOVM           MOVCALCCUSTO_MCC.MCC_VALORMOVM%TYPE;
    VVALORLOTESERIEM     MOVCALCCUSTO_MCC.MCC_VALORLOTESERIEM%TYPE;
    VSQNOTATRANS         MOVCALCCUSTO_MCC.MCC_SQNOTARELTRANSF%TYPE;
    VDEVOLUCAO           MOVCALCCUSTO_MCC.MCC_DEVOLUCAO%TYPE;
    VDTCONTABILIZADO     MOVCALCCUSTO_MCC.MCC_DTCONTABILIZADO%TYPE;
    VREVISADO            MOVCALCCUSTO_MCC.MCC_REVISADO%TYPE;
    VCDEMP_TRANS         MOVCALCCUSTO_MCC.MCC_CDEMPRESA%TYPE;
    VTPEST_TRANS         MOVCALCCUSTO_MCC.MCC_TPESTOQUE%TYPE;
    VALMOX_TRANS         MOVCALCCUSTO_MCC.MCC_ALMOXARIFADO%TYPE;
    VDATA_TRANS          MOVCALCCUSTO_MCC.MCC_DATA%TYPE;
    VITEM_TRANS          MOVCALCCUSTO_MCC.MCC_ITEM%TYPE;
    BREAK_PROCESS        BOOLEAN;
    ISORDEMPRODUCAO      BOOLEAN;
    CALCULATRANSFERENCIA BOOLEAN;
    USACUSTOORIGEM       BOOLEAN;
    VCUSTO_UNITARIO      NUMBER(28, 8);
    VCUSTO_UNITARIOM     NUMBER(28, 8);
    VVALOR               NUMBER(28, 8);
    VVALORM              NUMBER(28, 8);
    VVALORLOTE           NUMBER(28, 8);
    VVALORLOTEM          NUMBER(28, 8);
    VSALDO_FISICO        NUMBER(28, 8);
    VSALDO_FINANCEIRO    NUMBER(28, 8);
    VSALDO_FINANCEIROM   NUMBER(28, 8);
    -- Saldos remanescentes antes de zerar
    VSALDO_FISICO_REM      NUMBER(28, 8);
    VSALDO_FINANCEIRO_REM  NUMBER(28, 8);
    VSALDO_FINANCEIROM_REM NUMBER(28, 8);
    CURSOR MOVCUSTOMEDIO IS
      SELECT MCC_SQNOTA,
             MCC_SEQUENCIA,
             MCC_TIPO,
             MCC_CDEMPRESA,
             MCC_TPESTOQUE,
             MCC_ALMOXARIFADO,
             MCC_ITEM,
             MCC_DATA,
             MCC_CUSTOINFORMADO,
             MCC_SQLOTESERIE,
             MCC_QTDMOV,
             MCC_QTDLOTESERIE,
             MCC_VALORMOV,
             MCC_VALORLOTESERIE,
             MCC_VALORMOVM,
             MCC_VALORLOTESERIEM,
             MCC_SQNOTARELTRANSF,
             MCC_DEVOLUCAO,
             MCC_REVISADO,
             MCC_DTCONTABILIZADO
        FROM MOVCALCCUSTO_MCC
       WHERE MCC_REVISADO = 'N'
       ORDER BY MCC_DATA,
                MCC_DEVOLUCAO DESC,
                DECODE(MCC_TIPO, 'E', DECODE(MCC_CUSTOINFORMADO, 'N', 0, 1), 1),
                MCC_TIPO,
                MCC_SQNOTA,
                DECODE(NVL(MCC_SQNOTARELTRANSF, 0), 0, '0', MCC_TIPO) DESC;
    CURSOR MOVTRANSFERENCIA IS
      SELECT MOV_CDEMPRESA,
             MOV_TPESTOQUE,
             MOV_ALMOXARIFADO,
             MOV_DATA,
             MOV_ITEM
        FROM MOVIMENTO_MOV
       WHERE MOV_SQNOTA    = VSQNOTATRANS
         AND MOV_SEQUENCIA = VSEQUENCIA;
  BEGIN
    ------------------------------------------------------------------------------
    -- Inicia processo de c�lculo dos custos nas modalidades m�dio ou hist�rico (espec�fico)
    ------------------------------------------------------------------------------
    BREAK_PROCESS := FALSE;
    OPEN MOVCUSTOMEDIO;
    FETCH MOVCUSTOMEDIO
      INTO VSQNOTA,
           VSEQUENCIA,
           VTIPO,
           VCDEMPRESA,
           VTPESTOQUE,
           VALMOXARIFADO,
           VITEM,
           VDATA,
           VCUSTOINFORM,
           VSQLOTE,
           VQTDMOV,
           VQTDLOTE,
           VVALORMOV,
           VVALORLOTESERIE,
           VVALORMOVM,
           VVALORLOTESERIEM,
           VSQNOTATRANS,
           VDEVOLUCAO,
           VREVISADO,
           VDTCONTABILIZADO;
    WHILE (MOVCUSTOMEDIO%FOUND) AND (NOT BREAK_PROCESS) LOOP
      ISORDEMPRODUCAO      := FALSE;
      CALCULATRANSFERENCIA := FALSE;
      -- Zer� vari�veis que ser�o utilizadas no calculo.
      VCUSTO_UNITARIO  := 0;
      VCUSTO_UNITARIOM := 0;
      VCUSTO_UNITARIO  := 0;
      VCUSTO_UNITARIOM := 0;
      USACUSTOORIGEM   := FALSE;
      IF VSQNOTATRANS > 0 THEN
        OPEN MOVTRANSFERENCIA;
        FETCH MOVTRANSFERENCIA INTO VCDEMP_TRANS, VTPEST_TRANS, VALMOX_TRANS, VDATA_TRANS, VITEM_TRANS;
        USACUSTOORIGEM :=   (MOVTRANSFERENCIA%FOUND)
                         AND (   (  (NOT ACUSTONORMALTRANSEMPRESAS)
                                  OR(VCDEMP_TRANS = VCDEMPRESA)
                                 )
                              AND(  (NOT ACUSTONORMALTRANSFILIAL)
                                  OR(GET_FILIAL_ESTOQUE(VCDEMPRESA, VTPESTOQUE) = GET_FILIAL_ESTOQUE(VCDEMP_TRANS, VTPEST_TRANS))
                                 )
                             );
        CLOSE MOVTRANSFERENCIA;
      END IF;
      -- Se for uma movimenta��o a custo m�dio entra no bloco abaixo para calcular o custo m�dio.
      IF ((NOT BOOLEAN_VALUE(VCUSTOINFORM)) OR (USACUSTOORIGEM AND (VTIPO = 'E'))) AND (NOT VDTCONTABILIZADO IS NOT NULL) THEN
        -- Se for entrada por devolu��o tenta buscar o custo da NF de origem
        IF (BOOLEAN_VALUE(VDEVOLUCAO)) AND (VTIPO = 'E') THEN
          GET_SALDOS_DEVOLUCAO(VSQNOTA,
                               VSEQUENCIA,
                               VSQLOTE,
                               ACUSTOESPECIF,
                               VSALDO_FISICO,
                               VSALDO_FINANCEIRO,
                               VSALDO_FINANCEIROM);
        ELSE
          CALCULACUSTOORDPRODUCAO(VSQNOTA,
                                  VSEQUENCIA,
                                  ISORDEMPRODUCAO,
                                  VCUSTO_UNITARIO);
        END IF;
        -- Se n�o for uma entrada por devolu��o, se n�o for uma ordem de produ��o
        -- Pega o m�dio do dia.
        IF ((NOT ((BOOLEAN_VALUE(VDEVOLUCAO)) AND (VTIPO = 'E'))) OR (VSALDO_FISICO = 0)) AND (NOT ISORDEMPRODUCAO) THEN
          GET_SALDOS_ESTOQUE(VCDEMPRESA,
                             VTPESTOQUE,
                             VALMOXARIFADO,
                             VITEM,
                             VDATA,
                             VSQLOTE,
                             ACUSTOESPECIF,
                             AESTDECIMAL,
                             VSALDO_FISICO,
                             VSALDO_FINANCEIRO,
                             VSALDO_FINANCEIROM);
        END IF;
        GET_CUSTO_ITEM(VSQNOTA,
                       VSEQUENCIA,
                       VTIPO,
                       VSQLOTE,
                       VQTDMOV,
                       VQTDLOTE,
                       VSALDO_FISICO,
                       VSALDO_FINANCEIRO,
                       VSALDO_FINANCEIROM,
                       ISORDEMPRODUCAO,
                       USACUSTOORIGEM,
                       ACUSTOESPECIF,
                       VCDEMP_TRANS,
                       VTPEST_TRANS,
                       VALMOX_TRANS,
                       VDATA_TRANS,
                       VITEM_TRANS,
                       AESTDECIMAL,
                       VVALOR,
                       VVALORM,
                       VVALORLOTE,
                       VVALORLOTEM);
      ELSE
        -- Mant�m os valores intactos caso seja uma movimentacao a custo informado.
        VVALOR      := VVALORMOV;
        VVALORM     := VVALORMOVM;
        VVALORLOTE  := VVALORLOTESERIE;
        VVALORLOTEM := VVALORLOTESERIEM;
      END IF;
      -- Se o per�odo estiver contabilizado, verifica o impacto da opera��o nos custos
      IF VDTCONTABILIZADO IS NOT NULL THEN
        VALIDAPERIODOCONTABILIZADO(VCDEMPRESA,
                                   VTPESTOQUE,
                                   VALMOXARIFADO,
                                   VITEM,
                                   VSQLOTE,
                                   VDATA,
                                   VQTDMOV,
                                   VVALORMOV,
                                   VVALORMOVM,
                                   VVALOR,
                                   VVALORM,
                                   AERROSALDO);
      END IF;
      -- Somente executa este passo se for sa�da ou entrada n�o transf�ncia
      IF (VSQNOTATRANS = 0) OR (VSQNOTATRANS IS NULL) OR (VTIPO = 'S') THEN
        ATUALIZAMOV_BUFFER(VSQNOTA,
                           VSEQUENCIA,
                           VSQLOTE,
                           VVALOR,
                           VVALORLOTE,
                           VVALORM,
                           VVALORLOTEM,
                           VCUSTOINFORM,
                           'S');
      ELSE
        IF (VSQNOTATRANS > 0) AND (VTIPO = 'E') THEN
          ATUALIZAMOV_BUFFER(VSQNOTA,
                             VSEQUENCIA,
                             VSQLOTE,
                             VVALOR,
                             VVALORLOTE,
                             VVALORM,
                             VVALORLOTEM,
                             VCUSTOINFORM,
                             'S');
        END IF;
      END IF;
      IF VSQNOTATRANS > 0 THEN
        IF USACUSTOORIGEM THEN
          CALCULATRANSFERENCIA := TRUE;
          LOADMOVIMENTACAO_CALCULOCUSTO(VCDEMP_TRANS,
                                        VTPEST_TRANS,
                                        VALMOX_TRANS,
                                        VITEM_TRANS,
                                        VDATA);
          BREAK_PROCESS := TRUE;
        END IF;
        IF (CALCULATRANSFERENCIA) THEN
          IF (VTIPO = 'S') THEN
            ATUALIZAMOV_BUFFER(VSQNOTATRANS,
                               VSEQUENCIA,
                               VSQLOTE,
                               VVALOR,
                               VVALORLOTE,
                               VVALORM,
                               VVALORLOTEM,
                               'S',
                               'S');
          ELSE
            ATUALIZAMOV_BUFFER(VSQNOTATRANS,
                               VSEQUENCIA,
                               VSQLOTE,
                               VVALOR,
                               VVALORLOTE,
                               VVALORM,
                               VVALORLOTEM,
                               'N',
                               'N');
          END IF;
        END IF;
      END IF;
      IF BOOLEAN_VALUE(ACRITICA) THEN
        VALIDASALDOSESTOQUE(VCDEMPRESA,
                            VTPESTOQUE,
                            VALMOXARIFADO,
                            VITEM,
                            VSQLOTE,
                            ACUSTOESPECIF,
                            AESTDECIMAL,
                            VDATA,
                            AERROSALDO);
      ELSE
        AERROSALDO := FALSE;
      END IF;
      FETCH MOVCUSTOMEDIO
        INTO VSQNOTA,
             VSEQUENCIA,
             VTIPO,
             VCDEMPRESA,
             VTPESTOQUE,
             VALMOXARIFADO,
             VITEM,
             VDATA,
             VCUSTOINFORM,
             VSQLOTE,
             VQTDMOV,
             VQTDLOTE,
             VVALORMOV,
             VVALORLOTESERIE,
             VVALORMOVM,
             VVALORLOTESERIEM,
             VSQNOTATRANS,
             VDEVOLUCAO,
             VREVISADO,
             VDTCONTABILIZADO;
    END LOOP;
  END;
  PROCEDURE CALCULOCUSTOESTOQUE
  (
    ACDEMPRESA    IN CHAR,
    ATPESTOQUE    IN CHAR,
    AALMOXARIFADO IN CHAR,
    AITEM         IN CHAR,
    ADATA         IN DATE,
    ACRITICA      IN CHAR
  ) AS
    VESTDECIMAL               NUMBER;
    VDEVCUSTOMEDIO            BOOLEAN;
    VCUSTOESPECIF             BOOLEAN;
    VVALORIZA_TRANS_ALMX      BOOLEAN;
    VQTDPENDENTE              NUMBER;
    VENCERRADO                BOOLEAN;
    VERROSALDO                BOOLEAN;
    VCUSTONORMALTRANSEMPRESAS BOOLEAN;
    VCUSTONORMALTRANSFILIAL   BOOLEAN;
    CURSOR MOVPENDENTE IS
      SELECT COUNT(1)
        FROM MOVCALCCUSTO_MCC
       WHERE MCC_REVISADO = 'N';
  BEGIN
    ------------------------------------------------------------------------------
    -- Procedure de controle das chamadas dos demais m�todos
    -- Ordem:
    -- 1 - Pega as vari�veis
    -- 2 - Adiciona as movimentacoes a tabela tempor�ria
    -- 3 - Verifica se h� algo a ser revisado
    -- 4 - Inicia processo de calculo dos custos
    -- 5 - Durante o processo de calculo, movimentacoes podem ter sido adicionadas,
    -- sendo assim, ao t�rmino do passo 4, caso ainda restem movimentacoes pendentes
    -- retorna ao processo de calculo at� que todas as movimentacoes sejam revisadas
    -- 6 - Nenhuma movimentacao e�calculada mais de uma vez.
    ------------------------------------------------------------------------------
    SETUPVARIAVEISCALCULOCUSTO(ACDEMPRESA,
                               ATPESTOQUE,
                               VESTDECIMAL,
                               VDEVCUSTOMEDIO,
                               VCUSTOESPECIF,
                               VVALORIZA_TRANS_ALMX,
                               VCUSTONORMALTRANSEMPRESAS,
                               VCUSTONORMALTRANSFILIAL);
    LOADMOVIMENTACAO_CALCULOCUSTO(ACDEMPRESA,
                                  ATPESTOQUE,
                                  AALMOXARIFADO,
                                  AITEM,
                                  ADATA);
    VENCERRADO := FALSE;
    VERROSALDO := FALSE;
    --Executa pelo menos uma vez para validar os saldos
    WHILE NOT VENCERRADO LOOP
      PROCESSOCALCULOCUSTO(ACDEMPRESA,
                           ATPESTOQUE,
                           AALMOXARIFADO,
                           AITEM,
                           ADATA,
                           VESTDECIMAL,
                           VCUSTOESPECIF,
                           VCUSTONORMALTRANSEMPRESAS,
                           VCUSTONORMALTRANSFILIAL,
                           ACRITICA,
                           VERROSALDO);
      OPEN MOVPENDENTE;
      FETCH MOVPENDENTE INTO VQTDPENDENTE;
      CLOSE MOVPENDENTE;
      VENCERRADO := VQTDPENDENTE = 0 OR VERROSALDO;
    END LOOP;
  END;
  PROCEDURE ATUALIZAMOVTEMP AS
    ASQNOTA          MOVCALCCUSTO_MCC.MCC_SQNOTA%TYPE;
    ASEQUENCIA       MOVCALCCUSTO_MCC.MCC_SEQUENCIA%TYPE;
    ASQLOTESERIE     MOVCALCCUSTO_MCC.MCC_SQLOTESERIE%TYPE;
    AVALORMOV        MOVCALCCUSTO_MCC.MCC_VALORMOV%TYPE;
    AVALORLOTESERIE  MOVCALCCUSTO_MCC.MCC_VALORLOTESERIE%TYPE;
    AVALORMOVM       MOVCALCCUSTO_MCC.MCC_VALORMOVM%TYPE;
    AVALORLOTESERIEM MOVCALCCUSTO_MCC.MCC_VALORLOTESERIEM%TYPE;
    ACUSTOINFORMADO  MOVCALCCUSTO_MCC.MCC_CUSTOINFORMADO%TYPE;
    AVALORMOV_TOTAL  MOVCALCCUSTO_MCC.MCC_VALORMOV%TYPE;
    AVALORMOVM_TOTAL MOVCALCCUSTO_MCC.MCC_VALORMOVM%TYPE;
    ATPESTOQUE       MOVCALCCUSTO_MCC.MCC_TPESTOQUE%TYPE;
    CURSOR MOVCALCCUSTO IS
      SELECT MCC_SQNOTA,
             MCC_SEQUENCIA,
             MCC_SQLOTESERIE,
             MCC_VALORMOV,
             MCC_VALORLOTESERIE,
             MCC_VALORMOVM,
             MCC_VALORLOTESERIEM,
             MCC_CUSTOINFORMADO,
             MCC_TPESTOQUE
        FROM MOVCALCCUSTO_MCC
       WHERE MCC_REVISADO = 'S'
         AND MCC_SQNOTA   > 0;
    CURSOR MLS_TOTAL IS
      SELECT SUM(MLS_VLINFORMADO),
             SUM(MLS_VLINFORMADOM)
        FROM MOVLOTESERIE_MLS
       WHERE MLS_SQNOTA      = ASQNOTA
         AND MLS_SQMOVIMENTO = ASEQUENCIA;
    AESTDECIMAL NUMBER;
  BEGIN
    ------------------------------------------------------------------------
    -- M�todo que atualiza as tabelas do Estoque com os valores calculados
    ------------------------------------------------------------------------
    OPEN MOVCALCCUSTO;
    FETCH MOVCALCCUSTO INTO ASQNOTA, ASEQUENCIA, ASQLOTESERIE, AVALORMOV, AVALORLOTESERIE, AVALORMOVM, AVALORLOTESERIEM, ACUSTOINFORMADO, ATPESTOQUE;
    WHILE MOVCALCCUSTO%FOUND LOOP
      SELECT EST_DECIMAL
        INTO AESTDECIMAL
        FROM ESTOQUES_EST
       WHERE EST_CODIGO = ATPESTOQUE;
      IF ASQLOTESERIE > 0 THEN
        UPDATE MOVLOTESERIE_MLS
           SET MLS_VLINFORMADO  = AVALORLOTESERIE,
               MLS_VLINFORMADOM = AVALORLOTESERIEM
         WHERE MLS_SQNOTA      = ASQNOTA
           AND MLS_SQMOVIMENTO = ASEQUENCIA
           AND MLS_SQLOTESERIE = ASQLOTESERIE;
        -- Para evitar erros de arredondamento entre a MLS e a MOV
        OPEN MLS_TOTAL;
        FETCH MLS_TOTAL INTO AVALORMOV_TOTAL, AVALORMOVM_TOTAL;
        CLOSE MLS_TOTAL;
        UPDATE MOVIMENTO_MOV
           SET MOV_VALOR          = ROUND(AVALORMOV_TOTAL, AESTDECIMAL),
               MOV_VALORM         = ROUND(AVALORMOVM_TOTAL, AESTDECIMAL),
               MOV_VALORB         = DECODE(MOV_CLIFOR, 'N', AVALORMOV / DECODE(MOV_QTDAQ, 0, 1, MOV_QTDAQ),
                                           DECODE(MOV_VALORB, 0, AVALORMOV / DECODE(MOV_QTDAQ, 0, 1, MOV_QTDAQ), MOV_VALORB)),
               MOV_CUSTOINFORMADO = ACUSTOINFORMADO
         WHERE MOV_SQNOTA    = ASQNOTA
           AND MOV_SEQUENCIA = ASEQUENCIA;
      ELSE
        -- Atualiza��o de produtos n�o controlados por lote, s�rie ou registro interno
        UPDATE MOVIMENTO_MOV
           SET MOV_VALOR          = ROUND(AVALORMOV, AESTDECIMAL),
               MOV_VALORM         = ROUND(AVALORMOVM, AESTDECIMAL),
               MOV_VALORB         = DECODE(MOV_CLIFOR, 'N', AVALORMOV / DECODE(MOV_QTDAQ, 0, 1, MOV_QTDAQ),
                                           DECODE(MOV_VALORB, 0, AVALORMOV / DECODE(MOV_QTDAQ, 0, 1, MOV_QTDAQ), MOV_VALORB)),
               MOV_CUSTOINFORMADO = ACUSTOINFORMADO
         WHERE MOV_SQNOTA    = ASQNOTA
           AND MOV_SEQUENCIA = ASEQUENCIA;
      END IF;
      FETCH MOVCALCCUSTO INTO ASQNOTA, ASEQUENCIA, ASQLOTESERIE, AVALORMOV, AVALORLOTESERIE, AVALORMOVM, AVALORLOTESERIEM, ACUSTOINFORMADO, ATPESTOQUE;
    END LOOP;
  END;
  FUNCTION EXISTS_ERROR_SALDO
  (
    ACDEMPRESA    IN CHAR,
    ATPESTOQUE    IN CHAR,
    AALMOXARIFADO IN CHAR,
    AITEM         IN CHAR
  ) RETURN BOOLEAN AS
    VCOUNT NUMBER;
    CURSOR ERROR_COUNT IS
      SELECT COUNT(1)
        FROM ERROCALCULOCUSTO_ECC
       WHERE ECC_CDEMPRESA    = NVL(ACDEMPRESA, ECC_CDEMPRESA)
         AND ECC_TPESTOQUE    = NVL(ATPESTOQUE, ECC_TPESTOQUE)
         AND ECC_ALMOXARIFADO = NVL(AALMOXARIFADO, ECC_ALMOXARIFADO)
         AND ECC_ITEM         = NVL(AITEM, ECC_ITEM);
  BEGIN
    OPEN ERROR_COUNT;
    FETCH ERROR_COUNT INTO VCOUNT;
    CLOSE ERROR_COUNT;
    RETURN(VCOUNT > 0);
  END;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 285386
PROMPT ======================================================================
/*
===============================================================================================
     Data: 29/06/2018  11:40
	 Solicitante:  Filipe
	 Motivo: Conforme informado pelo Igor e Alan o script ser� disponibilizado pelo SAU, script inclu�do por precau��o
===============================================================================================     
*/

PROMPT ======================================================================
PROMPT == DEMANDA......: 294919
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: JOSE BARBOSA DA SILVA JUNIOR
PROMPT == DATA.........: 21/06/2018
PROMPT == BASE.........: MXMDS9132
PROMPT == OWNER DESTINO: MXMDS9132
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE PARAMS_PAR
   SET PAR_VLPARAM = '02/08/2018'
 WHERE PAR_CDPARAM = 'PARDATALIMITENFE3.10'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 294919
PROMPT ======================================================================