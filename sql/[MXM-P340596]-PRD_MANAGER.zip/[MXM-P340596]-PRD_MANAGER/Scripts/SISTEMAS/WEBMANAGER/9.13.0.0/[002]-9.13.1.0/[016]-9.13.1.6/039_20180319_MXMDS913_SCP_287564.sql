PROMPT ======================================================================
PROMPT == DEMANDA......: 287564
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: GABRIEL MAGALHAES OLIVEIRA
PROMPT == DATA.........: 19/03/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27627, 'Gera��o de arquivo para DIRF', 'Gera��o de arquivo para DIRF')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SCP', 27627, 34, 2000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27627, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27627, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27627, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 287564
PROMPT ======================================================================