PROMPT ======================================================================
PROMPT == DEMANDA......: 280872
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: Julian Alves
PROMPT == DATA.........: 01/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE PRC_EFDPROCESSA_R0205 (
 PSMECODIGO       IN CHAR
,PCDITEM          IN CHAR
) AS
vIDREG0205           NUMBER(9);
ERR_MSG VARCHAR2(500);
-- VARI�VEIS MODELO DE ESCRITURA��O
  vSME_CDEMPRESA VARCHAR2(4);
  vSME_CDFILIAL VARCHAR2(4);
  vSME_DTINICIO DATE;
  vSME_DTFIM DATE;
CURSOR CS_INFO_MODESCRITURACAO IS
  SELECT SME.SME_CDEMPRESA,
         SME.SME_CDFILIAL,
         SME.SME_DTINICIO,
         SME.SME_DTFIM
    FROM SPEDMODELOESCRT_SME SME
   WHERE SME_CODIGO = PSMECODIGO;
CURSOR CS_R0205_CUR IS
  SELECT  REG
        , MIN(DESCR_ANT_ITEM) AS DESCR_ANT_ITEM
        , DT_INI
        , DT_FIM
        , COD_ANT_ITEM
        , COD_ITEM
 FROM (
       SELECT DISTINCT '0205' AS REG
              ,  SPED_RETIRA_CHARS(SAIT_DESCR_ANT_ITEM)  AS DESCR_ANT_ITEM
              ,  TO_CHAR(SAIT_DT_INI,'DDMMYYYY')     AS DT_INI
              ,  TO_CHAR(SAIT_DT_FIM,'DDMMYYYY')     AS DT_FIM
              ,  SAIT_COD_ANT_ITEM                     AS COD_ANT_ITEM
              ,  SAIT_ITEM                             AS COD_ITEM
        FROM SPEDALTITEM_SAIT
        WHERE SAIT_ITEM  = PCDITEM
        AND SAIT_DT_FIM IS NOT NULL
        AND SAIT_DT_FIM  >= vSME_DTINICIO
        AND SAIT_DT_FIM  < vSME_DTFIM
        AND SAIT_DT_FIM = (  SELECT MAX(SAIT_DT_FIM)
                             FROM SPEDALTITEM_SAIT
                             WHERE SAIT_ITEM  = PCDITEM
                               AND SAIT_DT_FIM IS NOT NULL
                               AND SAIT_DT_FIM  >= vSME_DTINICIO
                               AND SAIT_DT_FIM  < vSME_DTFIM)
 UNION ALL
       SELECT DISTINCT '0205' AS REG
              ,  SPED_RETIRA_CHARS(SAIP_DESCRANTERIOR) AS DESCR_ANT_ITEM
              ,  TO_CHAR(SAIP_DTINICIO,'DDMMYYYY')     AS DT_INI
              ,  TO_CHAR(SAIP_DTFIM,'DDMMYYYY')     AS DT_FIM
              ,  SAIP_CDITPATRIM||'-'||SAIP_CDANEXOPATRIM AS COD_ANT_ITEM
              ,  SAIP_CDITPATRIM||'-'||SAIP_CDANEXOPATRIM AS COD_ITEM
        FROM SPEDALTITEMPATRIM_SAIP
        WHERE SAIP_CDITPATRIM||'-'||SAIP_CDANEXOPATRIM  = PCDITEM
        AND SAIP_DTFIM IS NOT NULL
        AND SAIP_DTFIM  >= vSME_DTINICIO
        AND SAIP_DTFIM  < vSME_DTFIM
        AND SAIP_DTFIM = (  SELECT MAX(SAIP_DTFIM)
                             FROM SPEDALTITEMPATRIM_SAIP
                             WHERE SAIP_CDITPATRIM||'-'||SAIP_CDANEXOPATRIM  = PCDITEM
                               AND SAIP_DTFIM IS NOT NULL
                               AND SAIP_DTFIM  >= vSME_DTINICIO
                               AND SAIP_DTFIM  < vSME_DTFIM))
        GROUP BY REG, DT_INI,DT_FIM,COD_ANT_ITEM,COD_ITEM;
  TYPE TP_CS_R0205 IS TABLE OF CS_R0205_CUR%ROWTYPE INDEX BY PLS_INTEGER;
  TBL_CS_R0205 TP_CS_R0205;
BEGIN
  -- RECUPERA INFORMA��ES DO MODELO DE ESCRITURA��O
  OPEN CS_INFO_MODESCRITURACAO;
  FETCH CS_INFO_MODESCRITURACAO INTO vSME_CDEMPRESA, vSME_CDFILIAL, vSME_DTINICIO, vSME_DTFIM;
  CLOSE CS_INFO_MODESCRITURACAO;
  -- ABRE CURSOR REGISTRO 0205
  OPEN CS_R0205_CUR;
  LOOP
    FETCH CS_R0205_CUR BULK COLLECT INTO TBL_CS_R0205 LIMIT 2000;
      EXIT WHEN TBL_CS_R0205.COUNT=0;
      FOR IDXR0205 IN 1..TBL_CS_R0205.COUNT
       LOOP
        BEGIN
        vIDREG0205 := NULL;
        INSSPEDEFDALTITEM_R0205( PSMECODIGO
                                ,TBL_CS_R0205(IDXR0205).DT_INI
                                ,TBL_CS_R0205(IDXR0205).COD_ITEM
                                ,TBL_CS_R0205(IDXR0205).REG
                                ,TBL_CS_R0205(IDXR0205).DESCR_ANT_ITEM
                                ,TBL_CS_R0205(IDXR0205).DT_FIM
                                ,'');
        END;
       END LOOP;
  END LOOP;
  CLOSE CS_R0205_CUR;
EXCEPTION
  WHEN OTHERS
   THEN BEGIN
    ERR_MSG := SUBSTR('Mensagem do Sistema: "' || SQLERRM,1,499) || '"';
    IF CS_R0205_CUR%ISOPEN
     THEN CLOSE CS_R0205_CUR; END IF;
    RAISE_APPLICATION_ERROR(-20000,ERR_MSG);
   END;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280872
PROMPT ======================================================================