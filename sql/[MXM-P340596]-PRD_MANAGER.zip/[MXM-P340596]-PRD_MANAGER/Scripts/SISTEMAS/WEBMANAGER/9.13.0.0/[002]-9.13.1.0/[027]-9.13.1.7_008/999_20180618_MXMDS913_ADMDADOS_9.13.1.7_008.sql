/*
======================================================================================
       Ajuste criado para script de corre��o da ultima atualiza��o
======================================================================================

========================================================================================
     Data: 29/06/2018  11:10
	 Solicitante:  Filipe
	 Motivo: Conforme informado pelo Igor o script ser� disponibilizado pelo SAU, script incluido por precau��o
=========================================================================================     
*/

 PROMPT ======================================================================
PROMPT == DEMANDA......: 294919
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: JOSE BARBOSA DA SILVA JUNIOR
PROMPT == DATA.........: 21/06/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE PARAMS_PAR
   SET PAR_VLPARAM = '02/08/2018'
 WHERE PAR_CDPARAM = 'PARDATALIMITENFE3.10'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 294919
PROMPT ======================================================================

/*
========================================================================================
     Data: 27/08/2018 15:30
     Solicitante:  Gustavo
     Motivo: Identificado erro em atualiza��o devido ao nexval na sequence
=========================================================================================     
*/


--Ajuste demanda 278867
CREATE OR REPLACE PROCEDURE PRC_ECDPROCESSAREGK100K110K115(PT_SME_CODIGO         IN VARCHAR2,
                                                           PT_TOTALREGISTRO_K100 OUT NUMBER,
                                                           PT_TOTALREGISTRO_K110 OUT NUMBER,
                                                           PT_TOTALREGISTRO_K115 OUT NUMBER) AS
  VR_RK2_IDRK2     ECDREGISTROK100_RK2.RK2_IDRK2%TYPE;
  VR_EK5_CDEMPCONS ECDCABEVENTSOC_EK5.EK5_CDEMPCONS%TYPE;
  VR_RK3_IDRK3     ECDREGISTROK110_RK3.RK3_IDRK3%TYPE;
  VR_EK7_NREK6     ECDEMPPARTEVENTSOC_EK7.EK7_NREK6%TYPE;
  VR_RK4_IDRK4     ECDREGISTROK115_RK4.RK4_IDRK4%TYPE;
  CURSOR CS_DADOS_REGISTRO_K100 IS
    SELECT 'K100' AS REG,
           PEMP_CODPAIS AS COD_PAIS,
           EK2_NMIDENTEMPRESA AS EMP_COD,
           DECODE(PEMP_CODPAIS, '01058', SUBSTR(EMP_CGC, 1, 8), NULL) AS CNPJ,
           PEMP_NOMEFANTASIA AS NOME,
           EK2_PEPARTICIPACAO AS PER_PART,
           EK2_VBEVENTOSOCIETARIO AS EVENTO,
           EK2_PECONSOLIDACAO AS PER_CONS,
           TO_CHAR(EK2_DTINICONSOLIDACAO, 'DDMMRRRR') AS DATA_INI_EMP,
           TO_CHAR(EK2_DTFIMCONSOLIDACAO, 'DDMMRRRR') AS DATA_FIN_EMP,
           PEMP_CDEMPRESA AS CHAVE
      FROM ECDCABRELEMPCONS_EK1,
           ECDDETRELEMPCONS_EK2,
           SPEDPAREMPRESA_PEMP,
           EMPGERAL_EMP
     WHERE EK2_NREK1 = EK1_IDECDCABRELEMPCONS
       AND EK2_CDEMPRESA = PEMP_CDEMPRESA(+)
       AND PEMP_CDFILIAL IS NULL
       AND EK2_CDEMPRESA = EMP_CODIGO
       AND EK1_CDMODESCR = PT_SME_CODIGO;
  CURSOR CS_DADOS_REGISTRO_K110 IS
    SELECT 'K110' AS REG,
           EK6_TPEVENTO AS TP_EVENTO,
           TO_CHAR(EK6_DTEVENTO, 'DDMMRRRR') AS DT_EVENTO,
           EK6_IDECDDETEVENTSOC AS CHAVE
      FROM ECDCABEVENTSOC_EK5, ECDDETEVENTSOC_EK6
     WHERE EK6_NREK5 = EK5_IDECDCABEVENTSOC
       AND EK5_CDMODESCR = PT_SME_CODIGO
       AND EK5_CDEMPCONS = VR_EK5_CDEMPCONS;
  CURSOR CS_DADOS_REGISTRO_K115 IS
    SELECT 'K115' AS REG,
           (SELECT EK2_NMIDENTEMPRESA
              FROM ECDCABRELEMPCONS_EK1, ECDDETRELEMPCONS_EK2
             WHERE EK2_NREK1 = EK1_IDECDCABRELEMPCONS
               AND EK2_CDEMPRESA = EK7_CDEMPPART
               AND EK1_CDMODESCR = PT_SME_CODIGO) AS EMP_COD_PART,
           EK7_TPCONDEMPPART AS COND_PART,
           EK7_PEEMPPART AS PER_EVT
      FROM ECDEMPPARTEVENTSOC_EK7
     WHERE EK7_NREK6 = VR_EK7_NREK6;
BEGIN
  PT_TOTALREGISTRO_K100 := 0;
  PT_TOTALREGISTRO_K110 := 0;
  PT_TOTALREGISTRO_K115 := 0;
  --K100
  FOR REC_DADOS_REGISTRO_K100 IN CS_DADOS_REGISTRO_K100 LOOP
    BEGIN
      SELECT 
		SEQ1_ECDREGISTROK100_RK2.NEXTVAL 
		INTO  VR_RK2_IDRK2 
	  FROM DUAL;
      VR_EK5_CDEMPCONS      := REC_DADOS_REGISTRO_K100.CHAVE;
      PT_TOTALREGISTRO_K100 := PT_TOTALREGISTRO_K100 + 1;
      INSERT INTO ECDREGISTROK100_RK2
        (RK2_IDRK2,
         RK2_CDMODESCR,
         RK2_CDREG,
         RK2_CDPAIS,
         RK2_CDEMPRESA,
         RK2_CDCNPJ,
         RK2_TXNOME,
         RK2_PEPARTICIPACAO,
         RK2_VBEVENTO,
         RK2_PECONSOLIDACAO,
         RK2_DTINICONSOLIDACAO,
         RK2_DTFIMCONSOLIDACAO,
         RK2_USINCLUSAO,
         RK2_DTINCLUSAO)
      VALUES
        (VR_RK2_IDRK2,
         PT_SME_CODIGO,
         REC_DADOS_REGISTRO_K100.REG,
         REC_DADOS_REGISTRO_K100.COD_PAIS,
         REC_DADOS_REGISTRO_K100.EMP_COD,
         REC_DADOS_REGISTRO_K100.CNPJ,
         REC_DADOS_REGISTRO_K100.NOME,
         REC_DADOS_REGISTRO_K100.PER_PART,
         REC_DADOS_REGISTRO_K100.EVENTO,
         REC_DADOS_REGISTRO_K100.PER_CONS,
         REC_DADOS_REGISTRO_K100.DATA_INI_EMP,
         REC_DADOS_REGISTRO_K100.DATA_FIN_EMP,
         GET_USER_MXM,
         SYSDATE);
      --K110
      FOR REC_DADOS_REGISTRO_K110 IN CS_DADOS_REGISTRO_K110 LOOP
        BEGIN
		  SELECT 
			SEQ1_ECDREGISTROK110_RK3.NEXTVAL 
			INTO  VR_RK3_IDRK3 
		  FROM DUAL;
          VR_EK7_NREK6          := REC_DADOS_REGISTRO_K110.CHAVE;
          PT_TOTALREGISTRO_K110 := PT_TOTALREGISTRO_K110 + 1;
          INSERT INTO ECDREGISTROK110_RK3
            (RK3_IDRK3,
             RK3_NRRK2,
             RK3_CDMODESCR,
             RK3_CDREG,
             RK3_TPEVENTO,
             RK3_DTEVENTO,
             RK3_USINCLUSAO,
             RK3_DTINCLUSAO)
          VALUES
            (VR_RK3_IDRK3,
             VR_RK2_IDRK2,
             PT_SME_CODIGO,
             REC_DADOS_REGISTRO_K110.REG,
             REC_DADOS_REGISTRO_K110.TP_EVENTO,
             REC_DADOS_REGISTRO_K110.DT_EVENTO,
             GET_USER_MXM,
             SYSDATE);
        END;
        --K115
        FOR REC_DADOS_REGISTRO_K115 IN CS_DADOS_REGISTRO_K115 LOOP
          BEGIN
		    SELECT 
			  SEQ1_ECDREGISTROK115_RK4.NEXTVAL
			  INTO  VR_RK4_IDRK4 
		    FROM DUAL;
            PT_TOTALREGISTRO_K115 := PT_TOTALREGISTRO_K115 + 1;
            INSERT INTO ECDREGISTROK115_RK4
              (RK4_IDRK4,
               RK4_NRRK3,
               RK4_CDMODESCR,
               RK4_CDREG,
               RK4_CDEMPPART,
               RK4_TPCONDPART,
               RK4_PEEVENTO,
               RK4_USINCLUSAO,
               RK4_DTINCLUSAO)
            VALUES
              (VR_RK4_IDRK4,
               VR_RK3_IDRK3,
               PT_SME_CODIGO,
               REC_DADOS_REGISTRO_K115.REG,
               REC_DADOS_REGISTRO_K115.EMP_COD_PART,
               REC_DADOS_REGISTRO_K115.COND_PART,
               REC_DADOS_REGISTRO_K115.PER_EVT,
               GET_USER_MXM,
               SYSDATE);
          END;
        END LOOP;
      END LOOP;
    END;
  END LOOP;
END PRC_ECDPROCESSAREGK100K110K115;
/


--Ajuste demanda 286725

CREATE OR REPLACE PROCEDURE PRC_ECFPROCESSA_V010(PT_IDMODESCRITURACAO IN NUMBER,
                                                 PT_TOV010            OUT NUMBER,
                                                 PT_TOV020            OUT NUMBER) AS
  vINSTITUICAODEREX NUMBER(7);
  
  vSEQ1_ECFREGISTROV010_V10 NUMBER;
  vSEQ1_ECFREGISTROV020_V20 NUMBER;
  vSEQ1_ECFREGISTROV030_V30 NUMBER;
		
		
  CURSOR CS_INST_DEREX IS
    SELECT RRD_RFDX1
      FROM ECFLANCTABDINAMICA_TD2,
           ECFMODESCRITURACAO_EME,
           ECFRELREFISPAESTD2_RRD
     WHERE EME_IDMODESCRITURACAO = PT_IDMODESCRITURACAO
       AND TD2_NRPA2 = EME_NRPA2
       AND RRD_NRTD2 = TD2_IDTD2
     GROUP BY RRD_RFDX1;
BEGIN
  PT_TOV010 := 0;
  PT_TOV020 := 0;
  FOR LOOP_DEREX IN CS_INST_DEREX LOOP
    vINSTITUICAODEREX := LOOP_DEREX.RRD_RFDX1;
    -- PROCESSA V010
    FOR LOOP_INSTITUICAO_V010 IN (SELECT DX1_NMINSTITUICAO NOME,
                                         PSS_CDPAISISO     PAIS,
                                         EBC_CDMOEDAISO    MOEDA,
                                         DX1_IDDX1         ID_INSTITUICAO
                                    FROM ECFDEREXINSTIT_DX1,
                                         PAIS_PAS,
                                         ECFINTPAISISO_PSS,
                                         MOEDA_MOE,
                                         ECFINTCODMOEDABC_EBC
                                   WHERE DX1_IDDX1 = vINSTITUICAODEREX
                                     AND DX1_RFPAIS = PAS_CDPAIS
                                     AND PSS_CDPAIS = PAS_CDPAIS
                                     AND MOE_NREBC = EBC_IDEBC
                                     AND MOE_CODIGO = DX1_RFMOEDA) LOOP
	  SELECT 
	    SEQ1_ECFREGISTROV010_V10.NEXTVAL
		INTO vSEQ1_ECFREGISTROV010_V10
	  FROM DUAL;
      INSERT INTO ECFREGISTROV010_V10
        (V10_IDREGISTROV010,
         V10_RFMODESCRITURACAO,
         V10_NMINSTITUICAO,
         V10_CDPAIS,
         V10_CDMOEDA)
      VALUES
        (vSEQ1_ECFREGISTROV010_V10,
         PT_IDMODESCRITURACAO,
         LOOP_INSTITUICAO_V010.NOME,
         LOOP_INSTITUICAO_V010.PAIS,
         LOOP_INSTITUICAO_V010.MOEDA);
      PT_TOV010 := PT_TOV010 + 1;
      --PROCESSA V020
      FOR LOOP_RESPONSAVEL_V020 IN (SELECT DX2_NMRESPONSAVEL   NOME,
                                           DX2_DSENDERECO      ENDERECO,
                                           DX2_TPDOCUMENTO     TPDOCUMENTO,
                                           DX2_CDIDENTIFICACAO NUMEROIDENTIFICACAO,
                                           DX2_CDIDENTCONTAS   IDENTIFICACAOCONTA
                                      FROM ECFDEREXRESPONS_DX2
                                     WHERE DX2_RFDX1 = LOOP_INSTITUICAO_V010.ID_INSTITUICAO) LOOP
									 
		   SELECT 
			SEQ1_ECFREGISTROV020_V20.NEXTVAL
			INTO vSEQ1_ECFREGISTROV020_V20
		  FROM DUAL;							 
        INSERT INTO ECFREGISTROV020_V20
          (V20_IDREGISTROV020,
           V20_RFMODESCRITURACAO,
           V20_RFV010,
           V20_NMRESPONSAVEL,
           V20_DSENDERECO,
           V20_TPDOCUMENTO,
           V20_CDDOCUMENTO,
           V20_CDIDENTCONTAS)
        VALUES
          (vSEQ1_ECFREGISTROV020_V20,
           PT_IDMODESCRITURACAO,
           vSEQ1_ECFREGISTROV010_V10,
           LOOP_RESPONSAVEL_V020.NOME,
           LOOP_RESPONSAVEL_V020.ENDERECO,
           LOOP_RESPONSAVEL_V020.TPDOCUMENTO,
           LOOP_RESPONSAVEL_V020.NUMEROIDENTIFICACAO,
           LOOP_RESPONSAVEL_V020.IDENTIFICACAOCONTA);
        PT_TOV020 := PT_TOV020 + 1;
      END LOOP; -- LOOP_RESPONSAVEL_V020
      --PROCESSA V030
      FOR LOOP_MES_V030 IN (SELECT RRD_NRMES, TD2_IDTD2
                              FROM ECFLANCTABDINAMICA_TD2,
                                   ECFRELREFISPAESTD2_RRD,
                                   ECFMODESCRITURACAO_EME
                             WHERE EME_IDMODESCRITURACAO = PT_IDMODESCRITURACAO
                               AND EME_NRPA2 = TD2_NRPA2
                               AND RRD_NRTD2 = TD2_IDTD2
                               AND TD2_NRIDENTREGISTRO = (SELECT ER1_IDIDENTREGISTRO FROM ECFINTIDENTREGISTRO_ER1 WHERE ECFINTIDENTREGISTRO_ER1.ER1_CDREGISTRO = 'V100')
                               AND RRD_RFDX1 = LOOP_INSTITUICAO_V010.ID_INSTITUICAO) LOOP
		SELECT 
			SEQ1_ECFREGISTROV030_V30.NEXTVAL
			INTO vSEQ1_ECFREGISTROV030_V30
		FROM DUAL;
        INSERT INTO ECFREGISTROV030_V30
          (V30_IDREGISTROV030,
           V30_RFMODESCRITURACAO,
           V30_RFV010,
           V30_CDMES)
        VALUES
          (vSEQ1_ECFREGISTROV030_V30,
           PT_IDMODESCRITURACAO,
           vSEQ1_ECFREGISTROV010_V10,
           LPAD(TO_CHAR(LOOP_MES_V030.RRD_NRMES), 2, '0'));
         --PROCESSA V100
         PRC_ECFPROCESSA_V100(PT_IDMODESCRITURACAO, vSEQ1_ECFREGISTROV030_V30, LOOP_MES_V030.TD2_IDTD2, LOOP_MES_V030.RRD_NRMES);
      END LOOP; -- LOOP_MES_V030
    END LOOP; -- LOOP_INSTITUICAO_V010
  END LOOP; -- CS_INST_DEREX
END;
/
