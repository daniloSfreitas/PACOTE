PROMPT ======================================================================
PROMPT == DEMANDA......: 278867
PROMPT == SISTEMA......: Escritura��o Cont�bil Digital
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 06/02/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27603, 'Conglomerado Econ�mico', 'Conglomerado Econ�mico')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('ECD', 27603, 11, 2000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27603, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27603, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27603, 'EXC')
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27604, 'Empresas Consolidadas', 'Empresas Consolidadas')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('ECD', 27604, 1, 27603)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27604, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27604, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27604, 'EXC')
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27605, 'Eventos Societ�rios', 'Eventos Societ�rios')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('ECD', 27605, 2, 27603)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27605, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27605, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27605, 'EXC')
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27606, 'Saldos das Contas Consolidadas', 'Saldos das Contas Consolidadas')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('ECD', 27606, 3, 27603)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27606, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27606, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27606, 'EXC')
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27607, 'Lan�amento das Parcelas do Valor Eliminado das Contas Consolidadas', 'Lan�amento das Parcelas do Valor Eliminado das Contas Consolidadas')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('ECD', 27607, 4, 27603)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27607, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27607, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27607, 'EXC')
/

create table ECDCABRELEMPCONS_EK1
(
  ek1_idecdcabrelempcons NUMBER(9) not null,
  ek1_cdmodescr          VARCHAR2(15) not null,
  ek1_usinclusao         VARCHAR2(40) not null,
  ek1_dtinclusao         DATE not null,
  ek1_usalteracao        VARCHAR2(40),
  ek1_dtalteracao        DATE
)
/

comment on table ECDCABRELEMPCONS_EK1
  is 'Tabela pai de rela��o das empresas consolidadas (Conglomerados Econ�micos)'
/

comment on column ECDCABRELEMPCONS_EK1.ek1_idecdcabrelempcons
  is 'Chave prim�ria da tabela ECDCABRELEMPCONS_EK1'
/

comment on column ECDCABRELEMPCONS_EK1.ek1_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDCABRELEMPCONS_EK1.ek1_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDCABRELEMPCONS_EK1.ek1_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDCABRELEMPCONS_EK1.ek1_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDCABRELEMPCONS_EK1.ek1_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDCABRELEMPCONS_EK1
  add constraint PK_ECDCABRELEMPCONS_EK1 primary key (EK1_IDECDCABRELEMPCONS)
/

alter table ECDCABRELEMPCONS_EK1
  add constraint UK1_ECDCABRELEMPCONS_EK1 unique (EK1_CDMODESCR)
/

create table ECDDETRELEMPCONS_EK2
(
  ek2_idecddetrelempcons NUMBER(9) not null,
  ek2_nrek1              NUMBER(9) not null,
  ek2_cdempresa          VARCHAR2(4) not null,
  ek2_nmidentempresa     NUMBER(4),
  ek2_peparticipacao     NUMBER(7,4) not null,
  ek2_vbeventosocietario VARCHAR2(1) not null,
  ek2_peconsolidacao     NUMBER(7,4) not null,
  ek2_dtiniconsolidacao  DATE not null,
  ek2_dtfimconsolidacao  DATE not null,
  ek2_usinclusao         VARCHAR2(40) not null,
  ek2_dtinclusao         DATE not null,
  ek2_usalteracao        VARCHAR2(40),
  ek2_dtalteracao        DATE
)
/

comment on table ECDDETRELEMPCONS_EK2
  is 'Tabela filha de rela��o das empresas consolidadas (Conglomerados Econ�micos)'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_idecddetrelempcons
  is 'Chave prim�ria da tabela ECDDETRELEMPCONS_EK2'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_nrek1
  is 'Chave estrangeira da tabela ECDCABRELEMPCONS_EK1'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_cdempresa
  is 'C�digo da empresa consolidada'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_nmidentempresa
  is 'N�mero identificador da empresa envolvida na opera��o.'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_peparticipacao
  is 'Percentual de participa��o'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_vbeventosocietario
  is 'Flag indicador de ocorr�ncia de evento societ�rio'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_peconsolidacao
  is 'Percentual de consolida��o'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_dtiniconsolidacao
  is 'Data inicial do per�odo da escritura��o cont�bil da empresa que foi consolidada.'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_dtfimconsolidacao
  is 'Data final do per�odo da escritura��o cont�bil da empresa que foi consolidada.'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDDETRELEMPCONS_EK2.ek2_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDDETRELEMPCONS_EK2
  add constraint PK_ECDDETRELEMPCONS_EK2 primary key (EK2_IDECDDETRELEMPCONS)
/

alter table ECDDETRELEMPCONS_EK2
  add constraint UK1_ECDDETRELEMPCONS_EK2 unique (EK2_NREK1, EK2_NMIDENTEMPRESA)
/

alter table ECDDETRELEMPCONS_EK2
  add constraint FK1_ECDDETRELEMPCONS_EK2 foreign key (EK2_NREK1)
  references ECDCABRELEMPCONS_EK1 (EK1_IDECDCABRELEMPCONS)
/

create table ECDCABSLDCTBCONS_EK3
(
  ek3_idecdcabsldctbcons NUMBER(9) not null,
  ek3_cdmodescr          VARCHAR2(15) not null,
  ek3_usinclusao         VARCHAR2(40) not null,
  ek3_dtinclusao         DATE not null,
  ek3_usalteracao        VARCHAR2(40),
  ek3_dtalteracao        DATE
)
/

comment on table ECDCABSLDCTBCONS_EK3
  is 'Tabela pai de saldos das contas consolidadas (Conglomerados Econ�micos)'
/

comment on column ECDCABSLDCTBCONS_EK3.ek3_idecdcabsldctbcons
  is 'Chave prim�ria da tabela ECDCABSLDCTBCONS_EK3'
/

comment on column ECDCABSLDCTBCONS_EK3.ek3_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDCABSLDCTBCONS_EK3.ek3_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDCABSLDCTBCONS_EK3.ek3_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDCABSLDCTBCONS_EK3.ek3_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDCABSLDCTBCONS_EK3.ek3_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDCABSLDCTBCONS_EK3
  add constraint PK_ECDCABSLDCTBCONS_EK3 primary key (EK3_IDECDCABSLDCTBCONS)
/

alter table ECDCABSLDCTBCONS_EK3
  add constraint UK1_ECDCABSLDCTBCONS_EK3 unique (EK3_CDMODESCR)
/

create table ECDDETSLDCTBCONS_EK4
(
  ek4_idecddetsldctbcons NUMBER(9) not null,
  ek4_nrek3              NUMBER(9) not null,
  ek4_cdctbconsolidadora VARCHAR2(15) not null,
  ek4_vlaglutinado       NUMBER(15,2) not null,
  ek4_tpindvlaglutinado  VARCHAR2(1) not null,
  ek4_vleliminado        NUMBER(15,2) not null,
  ek4_tpindvleliminado   VARCHAR2(1) not null,
  ek4_vlconsolidado      NUMBER(15,2) not null,
  ek4_tpindvlconsolidado VARCHAR2(1) not null,
  ek4_usinclusao         VARCHAR2(40) not null,
  ek4_dtinclusao         DATE not null,
  ek4_usalteracao        VARCHAR2(40),
  ek4_dtalteracao        DATE
)
/

comment on table ECDDETSLDCTBCONS_EK4
  is 'Tabela filha de saldo das contas consolidadas (Conglomerados Econ�micos)'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_idecddetsldctbcons
  is 'Chave prim�ria da tabela ECDDETSLDCTBCONS_EK4'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_nrek3
  is 'Chave estrangeira da tabela ECDCABSLDCTBCONS_EK3'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_cdctbconsolidadora
  is 'C�digo da conta consolidada'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_vlaglutinado
  is 'Valor absoluto aglutinado'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_tpindvlaglutinado
  is 'Indicador da situa��o do valor aglutinado: D � Devedor C � Credor'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_vleliminado
  is 'Valor absoluto das elimina��es'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_tpindvleliminado
  is 'Indicador da situa��o do valor eliminado: D � Devedor C � Credor'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_vlconsolidado
  is 'Valor absoluto consolidado'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_tpindvlconsolidado
  is 'Indicador da situa��o do valor consolidado: D � Devedor C � Credor'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDDETSLDCTBCONS_EK4.ek4_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDDETSLDCTBCONS_EK4
  add constraint PK_ECDDETSLDCTBCONS_EK4 primary key (EK4_IDECDDETSLDCTBCONS)
/

alter table ECDDETSLDCTBCONS_EK4
  add constraint UK1_ECDDETSLDCTBCONS_EK4 unique (EK4_CDCTBCONSOLIDADORA)
/

alter table ECDDETSLDCTBCONS_EK4
  add constraint FK1_ECDDETSLDCTBCONS_EK4 foreign key (EK4_NREK3)
  references ECDCABSLDCTBCONS_EK3 (EK3_IDECDCABSLDCTBCONS)
/

create table ECDCABEVENTSOC_EK5
(
  ek5_idecdcabeventsoc NUMBER(9) not null,
  ek5_cdmodescr        VARCHAR2(15) not null,
  ek5_cdempcons        VARCHAR2(4) not null,
  ek5_usinclusao       VARCHAR2(40) not null,
  ek5_dtinclusao       DATE not null,
  ek5_usalteracao      VARCHAR2(40),
  ek5_dtalteracao      DATE
)
/

comment on table ECDCABEVENTSOC_EK5
  is 'Tabela pai de rela��o dos eventos societ�rios (Conglomerados Econ�micos)'
/

comment on column ECDCABEVENTSOC_EK5.ek5_idecdcabeventsoc
  is 'Chave prim�ria da tabela ECDCABEVENTSOC_EK5'
/

comment on column ECDCABEVENTSOC_EK5.ek5_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDCABEVENTSOC_EK5.ek5_cdempcons
  is 'C�digo da empresa consolidada'
/

comment on column ECDCABEVENTSOC_EK5.ek5_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDCABEVENTSOC_EK5.ek5_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDCABEVENTSOC_EK5.ek5_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDCABEVENTSOC_EK5.ek5_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDCABEVENTSOC_EK5
  add constraint PK_ECDCABEVENTSOC_EK5 primary key (EK5_IDECDCABEVENTSOC)
/

alter table ECDCABEVENTSOC_EK5
  add constraint UK1_ECDCABEVENTSOC_EK5 unique (EK5_CDMODESCR, EK5_CDEMPCONS)
/

create table ECDDETEVENTSOC_EK6
(
  ek6_idecddeteventsoc NUMBER(9) not null,
  ek6_nrek5            NUMBER(9) not null,
  ek6_tpevento         VARCHAR2(1) not null,
  ek6_dtevento         DATE not null,
  ek6_usinclusao       VARCHAR2(40) not null,
  ek6_dtinclusao       DATE not null,
  ek6_usalteracao      VARCHAR2(40),
  ek6_dtalteracao      DATE
)
/

comment on table ECDDETEVENTSOC_EK6
  is 'Tabela filha de rela��o dos eventos societ�rios (Conglomerados Econ�micos)'
/

comment on column ECDDETEVENTSOC_EK6.ek6_idecddeteventsoc
  is 'Chave prim�ria da tabela ECDDETEVENTSOC_EK6'
/

comment on column ECDDETEVENTSOC_EK6.ek6_nrek5
  is 'Chave estrangeira da tabela ECDCABEVENTSOC_EK5'
/

comment on column ECDDETEVENTSOC_EK6.ek6_tpevento
  is 'Evento societ�rio ocorrido no per�odo'
/

comment on column ECDDETEVENTSOC_EK6.ek6_dtevento
  is 'Data do evento societ�rio'
/

comment on column ECDDETEVENTSOC_EK6.ek6_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDDETEVENTSOC_EK6.ek6_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDDETEVENTSOC_EK6.ek6_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDDETEVENTSOC_EK6.ek6_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDDETEVENTSOC_EK6
  add constraint PK_ECDDETEVENTSOC_EK6 primary key (EK6_IDECDDETEVENTSOC)
/

alter table ECDDETEVENTSOC_EK6
  add constraint FK1_ECDDETEVENTSOC_EK6 foreign key (EK6_NREK5)
  references ECDCABEVENTSOC_EK5 (EK5_IDECDCABEVENTSOC)
/

create table ECDEMPPARTEVENTSOC_EK7
(
  ek7_idecdempparteventsoc NUMBER(9) not null,
  ek7_nrek6                NUMBER(9) not null,
  ek7_cdemppart            VARCHAR2(4) not null,
  ek7_tpcondemppart        VARCHAR2(1) not null,
  ek7_peemppart            NUMBER(7,4) not null,
  ek7_usinclusao           VARCHAR2(40) not null,
  ek7_dtinclusao           DATE not null,
  ek7_usalteracao          VARCHAR2(40),
  ek7_dtalteracao          DATE
)
/

comment on table ECDEMPPARTEVENTSOC_EK7
  is 'Tabela filha de rela��o das empresas participantes do evento societ�rio (Conglomerados Econ�mico)'
/

comment on column ECDEMPPARTEVENTSOC_EK7.ek7_idecdempparteventsoc
  is 'Chave prim�ria da tabela ECDEMPPARTEVENTSOC_EK7'
/

comment on column ECDEMPPARTEVENTSOC_EK7.ek7_nrek6
  is 'Chave estrangeira da tabela ECDDETEVENTSOC_EK6'
/

comment on column ECDEMPPARTEVENTSOC_EK7.ek7_cdemppart
  is 'C�digo da empresa envolvida na opera��o'
/

comment on column ECDEMPPARTEVENTSOC_EK7.ek7_tpcondemppart
  is 'Condi��o da empresa relacionada � opera��o 1 � Sucessora; 2 � Adquirente; 3 � Alienante.'
/

comment on column ECDEMPPARTEVENTSOC_EK7.ek7_peemppart
  is 'Percentual da empresa participante envolvida na opera��o'
/

comment on column ECDEMPPARTEVENTSOC_EK7.ek7_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDEMPPARTEVENTSOC_EK7.ek7_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDEMPPARTEVENTSOC_EK7.ek7_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDEMPPARTEVENTSOC_EK7.ek7_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDEMPPARTEVENTSOC_EK7
  add constraint PK_ECDEMPPARTEVENTSOC_EK7 primary key (EK7_IDECDEMPPARTEVENTSOC)
/

alter table ECDEMPPARTEVENTSOC_EK7
  add constraint FK1_ECDEMPPARTEVENTSOC_EK7 foreign key (EK7_NREK6)
  references ECDDETEVENTSOC_EK6 (EK6_IDECDDETEVENTSOC)
/

create table ECDCABLANCVLELI_EK8
(
  ek8_idecdcablancvleli NUMBER(9) not null,
  ek8_cdmodescr         VARCHAR2(15) not null,
  ek8_cdcontacontabil   VARCHAR2(15) not null,
  ek8_vltotaleliminado  NUMBER(15,2) not null,
  ek8_tpindvleliminado  VARCHAR2(1) not null,
  ek8_usinclusao        VARCHAR2(40) not null,
  ek8_dtinclusao        DATE not null,
  ek8_usalteracao       VARCHAR2(40),
  ek8_dtalteracao       DATE
)
/

comment on table ECDCABLANCVLELI_EK8
  is 'Tabela pai de empresas detentoras das parcelas do valor eliminado (Conglomerados Econ�micos)'
/

comment on column ECDCABLANCVLELI_EK8.ek8_idecdcablancvleli
  is 'Chave prim�ria da tabela ECDCABLANCVLELI_EK8'
/

comment on column ECDCABLANCVLELI_EK8.ek8_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDCABLANCVLELI_EK8.ek8_cdcontacontabil
  is 'C�digo da conta cont�bil consolidadora'
/

comment on column ECDCABLANCVLELI_EK8.ek8_vltotaleliminado
  is 'Valor total eliminado'
/

comment on column ECDCABLANCVLELI_EK8.ek8_tpindvleliminado
  is 'Indicador da situa��o do valor total eliminado: D � Devedor C � Credor'
/

comment on column ECDCABLANCVLELI_EK8.ek8_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDCABLANCVLELI_EK8.ek8_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDCABLANCVLELI_EK8.ek8_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDCABLANCVLELI_EK8.ek8_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDCABLANCVLELI_EK8
  add constraint PK_ECDCABLANCVLELI_EK8 primary key (EK8_IDECDCABLANCVLELI)
/

alter table ECDCABLANCVLELI_EK8
  add constraint UK1_ECDCABLANCVLELI_EK8 unique (EK8_CDMODESCR, EK8_CDCONTACONTABIL)
/

create table ECDDETLANCVLELI_EK9
(
  ek9_idecddetlancvleli NUMBER(9) not null,
  ek9_nrek8             NUMBER(9) not null,
  ek9_cdempdetparc      VARCHAR2(4) not null,
  ek9_vlparceli         NUMBER(15,2) not null,
  ek9_tpindvlparceli    VARCHAR2(1) not null,
  ek9_usinclusao        VARCHAR2(40) not null,
  ek9_dtinclusao        DATE not null,
  ek9_usalteracao       VARCHAR2(40),
  ek9_dtalteracao       DATE
)
/

comment on table ECDDETLANCVLELI_EK9
  is 'Tabela filha de empresas detentoras das parcelas do valor eliminado (Conglomerados Econ�micos)'
/

comment on column ECDDETLANCVLELI_EK9.ek9_idecddetlancvleli
  is 'Chave prim�ria da tabela ECDDETLANCVLELI_EK9'
/

comment on column ECDDETLANCVLELI_EK9.ek9_nrek8
  is 'Chave estrangeira da tabela ECDCABLANCVLELI_EK8'
/

comment on column ECDDETLANCVLELI_EK9.ek9_cdempdetparc
  is 'C�digo da empresa detentora do valor aglutinado que foi eliminado'
/

comment on column ECDDETLANCVLELI_EK9.ek9_vlparceli
  is 'Parcela do valor eliminado total'
/

comment on column ECDDETLANCVLELI_EK9.ek9_tpindvlparceli
  is 'Indicador da situa��o do valor eliminado: D � Devedor C � Credor'
/

comment on column ECDDETLANCVLELI_EK9.ek9_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDDETLANCVLELI_EK9.ek9_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDDETLANCVLELI_EK9.ek9_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDDETLANCVLELI_EK9.ek9_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDDETLANCVLELI_EK9
  add constraint PK_ECDDETLANCVLELI_EK9 primary key (EK9_IDECDDETLANCVLELI)
/

alter table ECDDETLANCVLELI_EK9
  add constraint UK1_ECDDETLANCVLELI_EK9 unique (EK9_CDEMPDETPARC, EK9_NREK8)
/

alter table ECDDETLANCVLELI_EK9
  add constraint FK1_ECDDETLANCVLELI_EK9 foreign key (EK9_NREK8)
  references ECDCABLANCVLELI_EK8 (EK8_IDECDCABLANCVLELI)
/

create table ECDEMPCONTRAVLELI_EK0
(
  ek0_idecdempcontravleli NUMBER(9) not null,
  ek0_nrek9               NUMBER(9) not null,
  ek0_cdempcontra         VARCHAR2(4) not null,
  ek0_cdcontacontra       VARCHAR2(15) not null,
  ek0_vlcontra            NUMBER(15,2) not null,
  ek0_tpindvlcontra       VARCHAR2(1) not null,
  ek0_usinclusao          VARCHAR2(40) not null,
  ek0_dtinclusao          DATE not null,
  ek0_usalteracao         VARCHAR2(40),
  ek0_dtalteracao         DATE
)
/

comment on table ECDEMPCONTRAVLELI_EK0
  is 'Tabela de detalhamento das empresas contrapartes das parcelas do valor eliminado total (Conglomerados Econ�micos)'
/

comment on column ECDEMPCONTRAVLELI_EK0.ek0_idecdempcontravleli
  is 'Chave prim�ria da tabela ECDEMPCONTRAVLELI_EK0'
/

comment on column ECDEMPCONTRAVLELI_EK0.ek0_nrek9
  is 'Chave estrangeira da tabela ECDDETLANCVLELI_EK9'
/

comment on column ECDEMPCONTRAVLELI_EK0.ek0_cdempcontra
  is 'C�digo da empresa da contrapartida'
/

comment on column ECDEMPCONTRAVLELI_EK0.ek0_cdcontacontra
  is 'C�digo da conta consolidada da contrapartida'
/

comment on column ECDEMPCONTRAVLELI_EK0.ek0_vlcontra
  is 'Parcela da contrapartida do valor eliminado total'
/

comment on column ECDEMPCONTRAVLELI_EK0.ek0_tpindvlcontra
  is 'Indicador da situa��o do valor eliminado: D � Devedor C � Credor'
/

comment on column ECDEMPCONTRAVLELI_EK0.ek0_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDEMPCONTRAVLELI_EK0.ek0_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDEMPCONTRAVLELI_EK0.ek0_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDEMPCONTRAVLELI_EK0.ek0_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDEMPCONTRAVLELI_EK0
  add constraint PK_ECDEMPCONTRAVLELI_EK0 primary key (EK0_IDECDEMPCONTRAVLELI)
/

alter table ECDEMPCONTRAVLELI_EK0
  add constraint UK1_ECDEMPCONTRAVLELI_EK0 unique (EK0_CDEMPCONTRA, EK0_CDCONTACONTRA, EK0_NREK9)
/

alter table ECDEMPCONTRAVLELI_EK0
  add constraint FK1_ECDEMPCONTRAVLELI_EK0 foreign key (EK0_NREK9)
  references ECDDETLANCVLELI_EK9 (EK9_IDECDDETLANCVLELI)
/

CREATE SEQUENCE SEQ1_ECDCABRELEMPCONS_EK1
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDDETRELEMPCONS_EK2
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDCABSLDCTBCONS_EK3
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDDETSLDCTBCONS_EK4
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDCABEVENTSOC_EK5
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDDETEVENTSOC_EK6
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDEMPPARTEVENTSOC_EK7
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDCABLANCVLELI_EK8
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDDETLANCVLELI_EK9
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDEMPCONTRAVLELI_EK0
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE OR REPLACE PROCEDURE PRC_INSECDCABRELEMPCONS_EK1(
 PEK1_IDECDCABRELEMPCONS IN OUT NUMBER
,PEK1_CDMODESCR IN CHAR
)
AS
BEGIN
  IF PEK1_IDECDCABRELEMPCONS IS NULL THEN
   SELECT SEQ1_ECDCABRELEMPCONS_EK1.NEXTVAL INTO PEK1_IDECDCABRELEMPCONS FROM DUAL;
  END IF;
  INSERT INTO ECDCABRELEMPCONS_EK1(
    EK1_IDECDCABRELEMPCONS
   ,EK1_CDMODESCR
   ,EK1_USINCLUSAO
   ,EK1_DTINCLUSAO
) VALUES (
    PEK1_IDECDCABRELEMPCONS
   ,PEK1_CDMODESCR
   ,GET_USER_MXM
   ,SYSDATE
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_INSECDDETRELEMPCONS_EK2(
 PEK2_IDECDDETRELEMPCONS IN OUT NUMBER
,PEK2_NREK1 IN NUMBER
,PEK2_CDEMPRESA IN CHAR
,PEK2_NMIDENTEMPRESA IN NUMBER
,PEK2_PEPARTICIPACAO IN NUMBER
,PEK2_VBEVENTOSOCIETARIO IN CHAR
,PEK2_PECONSOLIDACAO IN NUMBER
,PEK2_DTINICONSOLIDACAO IN DATE
,PEK2_DTFIMCONSOLIDACAO IN DATE
)
AS
BEGIN
  IF PEK2_IDECDDETRELEMPCONS IS NULL THEN
   SELECT SEQ1_ECDDETRELEMPCONS_EK2.NEXTVAL INTO PEK2_IDECDDETRELEMPCONS FROM DUAL;
  END IF;
  INSERT INTO ECDDETRELEMPCONS_EK2(
    EK2_IDECDDETRELEMPCONS
   ,EK2_NREK1
   ,EK2_CDEMPRESA
   ,EK2_NMIDENTEMPRESA
   ,EK2_PEPARTICIPACAO
   ,EK2_VBEVENTOSOCIETARIO
   ,EK2_PECONSOLIDACAO
   ,EK2_DTINICONSOLIDACAO
   ,EK2_DTFIMCONSOLIDACAO
   ,EK2_USINCLUSAO
   ,EK2_DTINCLUSAO
) VALUES (
    PEK2_IDECDDETRELEMPCONS
   ,PEK2_NREK1
   ,PEK2_CDEMPRESA
   ,PEK2_NMIDENTEMPRESA
   ,PEK2_PEPARTICIPACAO
   ,PEK2_VBEVENTOSOCIETARIO
   ,PEK2_PECONSOLIDACAO
   ,PEK2_DTINICONSOLIDACAO
   ,PEK2_DTFIMCONSOLIDACAO
   ,GET_USER_MXM
   ,SYSDATE
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_INSECDCABSLDCTBCONS_EK3(
 PEK3_IDECDCABSLDCTBCONS IN OUT NUMBER
,PEK3_CDMODESCR IN CHAR
)
AS
BEGIN
  IF PEK3_IDECDCABSLDCTBCONS IS NULL THEN
   SELECT SEQ1_ECDCABSLDCTBCONS_EK3.NEXTVAL INTO PEK3_IDECDCABSLDCTBCONS FROM DUAL;
  END IF;
  INSERT INTO ECDCABSLDCTBCONS_EK3(
    EK3_IDECDCABSLDCTBCONS
   ,EK3_CDMODESCR
   ,EK3_USINCLUSAO
   ,EK3_DTINCLUSAO
) VALUES (
    PEK3_IDECDCABSLDCTBCONS
   ,PEK3_CDMODESCR
   ,GET_USER_MXM
   ,SYSDATE
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_INSECDDETSLDCTBCONS_EK4(
 PEK4_IDECDDETSLDCTBCONS IN OUT NUMBER
,PEK4_NREK3 IN NUMBER
,PEK4_CDCTBCONSOLIDADORA IN CHAR
,PEK4_VLAGLUTINADO IN NUMBER
,PEK4_TPINDVLAGLUTINADO IN CHAR
,PEK4_VLELIMINADO IN NUMBER
,PEK4_TPINDVLELIMINADO IN CHAR
,PEK4_VLCONSOLIDADO IN NUMBER
,PEK4_TPINDVLCONSOLIDADO IN CHAR
)
AS
BEGIN
  IF PEK4_IDECDDETSLDCTBCONS IS NULL THEN
   SELECT SEQ1_ECDDETSLDCTBCONS_EK4.NEXTVAL INTO PEK4_IDECDDETSLDCTBCONS FROM DUAL;
  END IF;
  INSERT INTO ECDDETSLDCTBCONS_EK4(
    EK4_IDECDDETSLDCTBCONS
   ,EK4_NREK3
   ,EK4_CDCTBCONSOLIDADORA
   ,EK4_VLAGLUTINADO
   ,EK4_TPINDVLAGLUTINADO
   ,EK4_VLELIMINADO
   ,EK4_TPINDVLELIMINADO
   ,EK4_VLCONSOLIDADO
   ,EK4_TPINDVLCONSOLIDADO
   ,EK4_USINCLUSAO
   ,EK4_DTINCLUSAO
) VALUES (
    PEK4_IDECDDETSLDCTBCONS
   ,PEK4_NREK3
   ,PEK4_CDCTBCONSOLIDADORA
   ,PEK4_VLAGLUTINADO
   ,PEK4_TPINDVLAGLUTINADO
   ,PEK4_VLELIMINADO
   ,PEK4_TPINDVLELIMINADO
   ,PEK4_VLCONSOLIDADO
   ,PEK4_TPINDVLCONSOLIDADO
   ,GET_USER_MXM
   ,SYSDATE
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_INSECDCABEVENTSOC_EK5(
 PEK5_IDECDCABEVENTSOC IN OUT NUMBER
,PEK5_CDMODESCR IN CHAR
,PEK5_CDEMPCONS IN CHAR
)
AS
BEGIN
  IF PEK5_IDECDCABEVENTSOC IS NULL THEN
   SELECT SEQ1_ECDCABEVENTSOC_EK5.NEXTVAL INTO PEK5_IDECDCABEVENTSOC FROM DUAL;
  END IF;
  INSERT INTO ECDCABEVENTSOC_EK5(
    EK5_IDECDCABEVENTSOC
   ,EK5_CDMODESCR
   ,EK5_CDEMPCONS
   ,EK5_USINCLUSAO
   ,EK5_DTINCLUSAO
) VALUES (
    PEK5_IDECDCABEVENTSOC
   ,PEK5_CDMODESCR
   ,PEK5_CDEMPCONS
   ,GET_USER_MXM
   ,SYSDATE
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_INSECDDETEVENTSOC_EK6(
 PEK6_IDECDDETEVENTSOC IN OUT NUMBER
,PEK6_NREK5 IN NUMBER
,PEK6_TPEVENTO IN CHAR
,PEK6_DTEVENTO IN DATE
)
AS
BEGIN
  IF PEK6_IDECDDETEVENTSOC IS NULL THEN
   SELECT SEQ1_ECDDETEVENTSOC_EK6.NEXTVAL INTO PEK6_IDECDDETEVENTSOC FROM DUAL;
  END IF;
  INSERT INTO ECDDETEVENTSOC_EK6(
    EK6_IDECDDETEVENTSOC
   ,EK6_NREK5
   ,EK6_TPEVENTO
   ,EK6_DTEVENTO
   ,EK6_USINCLUSAO
   ,EK6_DTINCLUSAO
) VALUES (
    PEK6_IDECDDETEVENTSOC
   ,PEK6_NREK5
   ,PEK6_TPEVENTO
   ,PEK6_DTEVENTO
   ,GET_USER_MXM
   ,SYSDATE
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_INSECDEMPPARTEVENTSOC_EK7(
 PEK7_IDECDEMPPARTEVENTSOC IN OUT NUMBER
,PEK7_NREK6 IN NUMBER
,PEK7_CDEMPPART IN CHAR
,PEK7_TPCONDEMPPART IN CHAR
,PEK7_PEEMPPART IN NUMBER
)
AS
BEGIN
  IF PEK7_IDECDEMPPARTEVENTSOC IS NULL THEN
   SELECT SEQ1_ECDEMPPARTEVENTSOC_EK7.NEXTVAL INTO PEK7_IDECDEMPPARTEVENTSOC FROM DUAL;
  END IF;
  INSERT INTO ECDEMPPARTEVENTSOC_EK7(
    EK7_IDECDEMPPARTEVENTSOC
   ,EK7_NREK6
   ,EK7_CDEMPPART
   ,EK7_TPCONDEMPPART
   ,EK7_PEEMPPART
   ,EK7_USINCLUSAO
   ,EK7_DTINCLUSAO
) VALUES (
    PEK7_IDECDEMPPARTEVENTSOC
   ,PEK7_NREK6
   ,PEK7_CDEMPPART
   ,PEK7_TPCONDEMPPART
   ,PEK7_PEEMPPART
   ,GET_USER_MXM
   ,SYSDATE
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_INSECDCABLANCVLELI_EK8(
 PEK8_IDECDCABLANCVLELI IN OUT NUMBER
,PEK8_CDMODESCR IN CHAR
,PEK8_CDCONTACONTABIL IN CHAR
,PEK8_VLTOTALELIMINADO IN NUMBER
,PEK8_TPINDVLELIMINADO IN CHAR
)
AS
BEGIN
  IF PEK8_IDECDCABLANCVLELI IS NULL THEN
   SELECT SEQ1_ECDCABLANCVLELI_EK8.NEXTVAL INTO PEK8_IDECDCABLANCVLELI FROM DUAL;
  END IF;
  INSERT INTO ECDCABLANCVLELI_EK8(
    EK8_IDECDCABLANCVLELI
   ,EK8_CDMODESCR
   ,EK8_CDCONTACONTABIL
   ,EK8_VLTOTALELIMINADO
   ,EK8_TPINDVLELIMINADO
   ,EK8_USINCLUSAO
   ,EK8_DTINCLUSAO
) VALUES (
    PEK8_IDECDCABLANCVLELI
   ,PEK8_CDMODESCR
   ,PEK8_CDCONTACONTABIL
   ,PEK8_VLTOTALELIMINADO
   ,PEK8_TPINDVLELIMINADO
   ,GET_USER_MXM
   ,SYSDATE
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_INSECDDETLANCVLELI_EK9(
 PEK9_IDECDDETLANCVLELI IN OUT NUMBER
,PEK9_NREK8 IN NUMBER
,PEK9_CDEMPDETPARC IN CHAR
,PEK9_VLPARCELI IN NUMBER
,PEK9_TPINDVLPARCELI IN CHAR
)
AS
BEGIN
  IF PEK9_IDECDDETLANCVLELI IS NULL THEN
   SELECT SEQ1_ECDDETLANCVLELI_EK9.NEXTVAL INTO PEK9_IDECDDETLANCVLELI FROM DUAL;
  END IF;
  INSERT INTO ECDDETLANCVLELI_EK9(
    EK9_IDECDDETLANCVLELI
   ,EK9_NREK8
   ,EK9_CDEMPDETPARC
   ,EK9_VLPARCELI
   ,EK9_TPINDVLPARCELI
   ,EK9_USINCLUSAO
   ,EK9_DTINCLUSAO
) VALUES (
    PEK9_IDECDDETLANCVLELI
   ,PEK9_NREK8
   ,PEK9_CDEMPDETPARC
   ,PEK9_VLPARCELI
   ,PEK9_TPINDVLPARCELI
   ,GET_USER_MXM
   ,SYSDATE
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_INSECDEMPCONTRAVLELI_EK0(
 PEK0_IDECDEMPCONTRAVLELI IN OUT NUMBER
,PEK0_NREK9 IN NUMBER
,PEK0_CDEMPCONTRA IN CHAR
,PEK0_CDCONTACONTRA IN CHAR
,PEK0_VLCONTRA IN NUMBER
,PEK0_TPINDVLCONTRA IN CHAR
)
AS
BEGIN
  IF PEK0_IDECDEMPCONTRAVLELI IS NULL THEN
   SELECT SEQ1_ECDEMPCONTRAVLELI_EK0.NEXTVAL INTO PEK0_IDECDEMPCONTRAVLELI FROM DUAL;
  END IF;
  INSERT INTO ECDEMPCONTRAVLELI_EK0(
    EK0_IDECDEMPCONTRAVLELI
   ,EK0_NREK9
   ,EK0_CDEMPCONTRA
   ,EK0_CDCONTACONTRA
   ,EK0_VLCONTRA
   ,EK0_TPINDVLCONTRA
   ,EK0_USINCLUSAO
   ,EK0_DTINCLUSAO
) VALUES (
    PEK0_IDECDEMPCONTRAVLELI
   ,PEK0_NREK9
   ,PEK0_CDEMPCONTRA
   ,PEK0_CDCONTACONTRA
   ,PEK0_VLCONTRA
   ,PEK0_TPINDVLCONTRA
   ,GET_USER_MXM
   ,SYSDATE
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTECDCABRELEMPCONS_EK1(
 PEK1_IDECDCABRELEMPCONS IN NUMBER,
 PEK1_CDMODESCR IN CHAR
)
AS
BEGIN
  UPDATE ECDCABRELEMPCONS_EK1
     SET EK1_CDMODESCR = PEK1_CDMODESCR
        ,EK1_USALTERACAO = GET_USER_MXM
        ,EK1_DTALTERACAO = SYSDATE
   WHERE EK1_IDECDCABRELEMPCONS = PEK1_IDECDCABRELEMPCONS;
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTECDDETRELEMPCONS_EK2(
 PEK2_IDECDDETRELEMPCONS IN NUMBER
,PEK2_NREK1 IN NUMBER
,PEK2_CDEMPRESA IN CHAR
,PEK2_NMIDENTEMPRESA IN NUMBER
,PEK2_PEPARTICIPACAO IN NUMBER
,PEK2_VBEVENTOSOCIETARIO IN CHAR
,PEK2_PECONSOLIDACAO IN NUMBER
,PEK2_DTINICONSOLIDACAO IN DATE
,PEK2_DTFIMCONSOLIDACAO IN DATE
)
AS
BEGIN
  UPDATE ECDDETRELEMPCONS_EK2
     SET EK2_NREK1 = PEK2_NREK1
        ,EK2_CDEMPRESA = PEK2_CDEMPRESA
        ,EK2_NMIDENTEMPRESA = PEK2_NMIDENTEMPRESA
        ,EK2_PEPARTICIPACAO = PEK2_PEPARTICIPACAO
        ,EK2_VBEVENTOSOCIETARIO = PEK2_VBEVENTOSOCIETARIO
        ,EK2_PECONSOLIDACAO = PEK2_PECONSOLIDACAO
        ,EK2_DTINICONSOLIDACAO = PEK2_DTINICONSOLIDACAO
        ,EK2_DTFIMCONSOLIDACAO = PEK2_DTFIMCONSOLIDACAO
        ,EK2_USALTERACAO = GET_USER_MXM
        ,EK2_DTALTERACAO = SYSDATE
   WHERE EK2_IDECDDETRELEMPCONS = PEK2_IDECDDETRELEMPCONS;
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTECDCABSLDCTBCONS_EK3(
 PEK3_IDECDCABSLDCTBCONS IN NUMBER
,PEK3_CDMODESCR IN CHAR
)
AS
BEGIN
  UPDATE ECDCABSLDCTBCONS_EK3
     SET EK3_CDMODESCR = PEK3_CDMODESCR
        ,EK3_USALTERACAO = GET_USER_MXM
        ,EK3_DTALTERACAO = SYSDATE
   WHERE EK3_IDECDCABSLDCTBCONS = PEK3_IDECDCABSLDCTBCONS;
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTECDDETSLDCTBCONS_EK4(
 PEK4_IDECDDETSLDCTBCONS IN NUMBER
,PEK4_NREK3 IN NUMBER
,PEK4_CDCTBCONSOLIDADORA IN CHAR
,PEK4_VLAGLUTINADO IN NUMBER
,PEK4_TPINDVLAGLUTINADO IN CHAR
,PEK4_VLELIMINADO IN NUMBER
,PEK4_TPINDVLELIMINADO IN CHAR
,PEK4_VLCONSOLIDADO IN NUMBER
,PEK4_TPINDVLCONSOLIDADO IN CHAR
)
AS
BEGIN
  UPDATE ECDDETSLDCTBCONS_EK4
     SET EK4_NREK3 = PEK4_NREK3
        ,EK4_CDCTBCONSOLIDADORA = PEK4_CDCTBCONSOLIDADORA
        ,EK4_VLAGLUTINADO = PEK4_VLAGLUTINADO
        ,EK4_TPINDVLAGLUTINADO = PEK4_TPINDVLAGLUTINADO
        ,EK4_VLELIMINADO = PEK4_VLELIMINADO
        ,EK4_TPINDVLELIMINADO = PEK4_TPINDVLELIMINADO
        ,EK4_VLCONSOLIDADO = PEK4_VLCONSOLIDADO
        ,EK4_TPINDVLCONSOLIDADO = PEK4_TPINDVLCONSOLIDADO
        ,EK4_USALTERACAO = GET_USER_MXM
        ,EK4_DTALTERACAO = SYSDATE
   WHERE EK4_IDECDDETSLDCTBCONS = PEK4_IDECDDETSLDCTBCONS;
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTECDCABEVENTSOC_EK5(
 PEK5_IDECDCABEVENTSOC IN NUMBER
,PEK5_CDMODESCR IN CHAR
,PEK5_CDEMPCONS IN CHAR
)
AS
BEGIN
  UPDATE ECDCABEVENTSOC_EK5
     SET EK5_CDMODESCR = PEK5_CDMODESCR
        ,EK5_CDEMPCONS = PEK5_CDEMPCONS
        ,EK5_USALTERACAO = GET_USER_MXM
        ,EK5_DTALTERACAO = SYSDATE
   WHERE EK5_IDECDCABEVENTSOC = PEK5_IDECDCABEVENTSOC;
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTECDDETEVENTSOC_EK6(
 PEK6_IDECDDETEVENTSOC IN NUMBER
,PEK6_NREK5 IN NUMBER
,PEK6_TPEVENTO IN CHAR
,PEK6_DTEVENTO IN DATE
)
AS
BEGIN
  UPDATE ECDDETEVENTSOC_EK6
     SET EK6_NREK5 = PEK6_NREK5
        ,EK6_TPEVENTO = PEK6_TPEVENTO
        ,EK6_DTEVENTO = PEK6_DTEVENTO
        ,EK6_USALTERACAO = GET_USER_MXM
        ,EK6_DTALTERACAO = SYSDATE
   WHERE EK6_IDECDDETEVENTSOC = PEK6_IDECDDETEVENTSOC;
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTECDEMPPARTEVENTSOC_EK7(
 PEK7_IDECDEMPPARTEVENTSOC IN NUMBER
,PEK7_NREK6 IN NUMBER
,PEK7_CDEMPPART IN CHAR
,PEK7_TPCONDEMPPART IN CHAR
,PEK7_PEEMPPART IN NUMBER
)
AS
BEGIN
  UPDATE ECDEMPPARTEVENTSOC_EK7
     SET EK7_NREK6 = PEK7_NREK6
        ,EK7_CDEMPPART = PEK7_CDEMPPART
        ,EK7_TPCONDEMPPART = PEK7_TPCONDEMPPART
        ,EK7_PEEMPPART = PEK7_PEEMPPART
        ,EK7_USALTERACAO = GET_USER_MXM
        ,EK7_DTALTERACAO = SYSDATE
   WHERE EK7_IDECDEMPPARTEVENTSOC = PEK7_IDECDEMPPARTEVENTSOC;
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTECDCABLANCVLELI_EK8(
 PEK8_IDECDCABLANCVLELI IN NUMBER
,PEK8_CDMODESCR IN CHAR
,PEK8_CDCONTACONTABIL IN CHAR
,PEK8_VLTOTALELIMINADO IN NUMBER
,PEK8_TPINDVLELIMINADO IN CHAR
)
AS
BEGIN
  UPDATE ECDCABLANCVLELI_EK8
     SET EK8_CDMODESCR = PEK8_CDMODESCR
        ,EK8_CDCONTACONTABIL = PEK8_CDCONTACONTABIL
        ,EK8_VLTOTALELIMINADO = PEK8_VLTOTALELIMINADO
        ,EK8_TPINDVLELIMINADO = PEK8_TPINDVLELIMINADO
        ,EK8_USALTERACAO = GET_USER_MXM
        ,EK8_DTALTERACAO = SYSDATE
   WHERE EK8_IDECDCABLANCVLELI = PEK8_IDECDCABLANCVLELI;
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTECDDETLANCVLELI_EK9(
 PEK9_IDECDDETLANCVLELI IN NUMBER
,PEK9_NREK8 IN NUMBER
,PEK9_CDEMPDETPARC IN CHAR
,PEK9_VLPARCELI IN NUMBER
,PEK9_TPINDVLPARCELI IN CHAR
,PEK9_USINCLUSAO IN CHAR
,PEK9_DTINCLUSAO IN DATE
)
AS
BEGIN
  UPDATE ECDDETLANCVLELI_EK9
     SET EK9_NREK8 = PEK9_NREK8
        ,EK9_CDEMPDETPARC = PEK9_CDEMPDETPARC
        ,EK9_VLPARCELI = PEK9_VLPARCELI
        ,EK9_TPINDVLPARCELI = PEK9_TPINDVLPARCELI
        ,EK9_USALTERACAO = GET_USER_MXM
        ,EK9_DTALTERACAO = SYSDATE
   WHERE EK9_IDECDDETLANCVLELI = PEK9_IDECDDETLANCVLELI;
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTECDEMPCONTRAVLELI_EK0(
 PEK0_IDECDEMPCONTRAVLELI IN NUMBER
,PEK0_NREK9 IN NUMBER
,PEK0_CDEMPCONTRA IN CHAR
,PEK0_CDCONTACONTRA IN CHAR
,PEK0_VLCONTRA IN NUMBER
,PEK0_TPINDVLCONTRA IN CHAR
)
AS
BEGIN
  UPDATE ECDEMPCONTRAVLELI_EK0
     SET EK0_NREK9 = PEK0_NREK9
        ,EK0_CDEMPCONTRA = PEK0_CDEMPCONTRA
        ,EK0_CDCONTACONTRA = PEK0_CDCONTACONTRA
        ,EK0_VLCONTRA = PEK0_VLCONTRA
        ,EK0_TPINDVLCONTRA = PEK0_TPINDVLCONTRA
        ,EK0_USALTERACAO = GET_USER_MXM
        ,EK0_DTALTERACAO = SYSDATE
   WHERE EK0_IDECDEMPCONTRAVLELI = PEK0_IDECDEMPCONTRAVLELI;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCECDCABRELEMPCONS_EK1(
 PEK1_IDECDCABRELEMPCONS IN NUMBER
)
AS
BEGIN
  DELETE FROM ECDCABRELEMPCONS_EK1
   WHERE EK1_IDECDCABRELEMPCONS = PEK1_IDECDCABRELEMPCONS;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCECDDETRELEMPCONS_EK2(
 PEK2_IDECDDETRELEMPCONS IN NUMBER
)
AS
BEGIN
  DELETE FROM ECDDETRELEMPCONS_EK2
   WHERE EK2_IDECDDETRELEMPCONS = PEK2_IDECDDETRELEMPCONS;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCECDCABSLDCTBCONS_EK3(
 PEK3_IDECDCABSLDCTBCONS IN NUMBER
)
AS
BEGIN
  DELETE FROM ECDCABSLDCTBCONS_EK3
   WHERE EK3_IDECDCABSLDCTBCONS = PEK3_IDECDCABSLDCTBCONS;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCECDDETSLDCTBCONS_EK4(
 PEK4_IDECDDETSLDCTBCONS IN NUMBER
)
AS
BEGIN
  DELETE FROM ECDDETSLDCTBCONS_EK4
   WHERE EK4_IDECDDETSLDCTBCONS = PEK4_IDECDDETSLDCTBCONS;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCECDCABEVENTSOC_EK5(
 PEK5_IDECDCABEVENTSOC IN NUMBER
)
AS
BEGIN
  DELETE FROM ECDCABEVENTSOC_EK5
   WHERE EK5_IDECDCABEVENTSOC = PEK5_IDECDCABEVENTSOC;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCECDDETEVENTSOC_EK6(
 PEK6_IDECDDETEVENTSOC IN NUMBER
)
AS
BEGIN
  DELETE FROM ECDDETEVENTSOC_EK6
   WHERE EK6_IDECDDETEVENTSOC = PEK6_IDECDDETEVENTSOC;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCECDEMPPARTEVENTSOC_EK7(
 PEK7_IDECDEMPPARTEVENTSOC IN NUMBER
)
AS
BEGIN
  DELETE FROM ECDEMPPARTEVENTSOC_EK7
   WHERE EK7_IDECDEMPPARTEVENTSOC = PEK7_IDECDEMPPARTEVENTSOC;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCECDCABLANCVLELI_EK8(
 PEK8_IDECDCABLANCVLELI IN NUMBER
)
AS
BEGIN
  DELETE FROM ECDCABLANCVLELI_EK8
   WHERE EK8_IDECDCABLANCVLELI = PEK8_IDECDCABLANCVLELI;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCECDDETLANCVLELI_EK9(
 PEK9_IDECDDETLANCVLELI IN NUMBER
)
AS
BEGIN
  DELETE FROM ECDDETLANCVLELI_EK9
   WHERE EK9_IDECDDETLANCVLELI = PEK9_IDECDDETLANCVLELI;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCECDEMPCONTRAVLELI_EK0(
 PEK0_IDECDEMPCONTRAVLELI IN NUMBER
)
AS
BEGIN
  DELETE FROM ECDEMPCONTRAVLELI_EK0
   WHERE EK0_IDECDEMPCONTRAVLELI = PEK0_IDECDEMPCONTRAVLELI;
END;
/

create table ECDREGISTROK001_RKA
(
  rka_idrka       NUMBER(9) not null,
  rka_cdmodescr   VARCHAR2(15) not null,
  rka_cdreg       VARCHAR2(4) not null,
  rka_tpindmov    VARCHAR2(1) not null,
  rka_usinclusao  VARCHAR2(40) not null,
  rka_dtinclusao  DATE not null,
  rka_usalteracao VARCHAR2(40),
  rka_dtalteracao DATE
)
/

comment on table ECDREGISTROK001_RKA
  is 'Tabela processada do registro K001'
/

comment on column ECDREGISTROK001_RKA.rka_idrka
  is 'Chave prim�ria da tabela ECDREGISTROK001_RKA'
/

comment on column ECDREGISTROK001_RKA.rka_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDREGISTROK001_RKA.rka_cdreg
  is 'C�digo do registro'
/

comment on column ECDREGISTROK001_RKA.rka_tpindmov
  is 'Indicador de movimento: 0- Bloco com dados informados; 1- Bloco sem dados informados.'
/

comment on column ECDREGISTROK001_RKA.rka_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDREGISTROK001_RKA.rka_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDREGISTROK001_RKA.rka_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDREGISTROK001_RKA.rka_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDREGISTROK001_RKA
  add constraint PK_ECDREGISTROK001_RKA primary key (RKA_IDRKA)
/

create table ECDREGISTROK030_RK1
(
  rk1_idrk1       NUMBER(9) not null,
  rk1_cdmodescr   VARCHAR2(15) not null,
  rk1_cdreg       VARCHAR2(4) not null,
  rk1_dtinicio    VARCHAR2(8) not null,
  rk1_dtfinal     VARCHAR2(8) not null,
  rk1_usinclusao  VARCHAR2(40) not null,
  rk1_dtinclusao  DATE not null,
  rk1_usalteracao VARCHAR2(40),
  rk1_dtalteracao DATE
)
/

comment on table ECDREGISTROK030_RK1
  is 'Tabela processada do registro K030'
/

comment on column ECDREGISTROK030_RK1.rk1_idrk1
  is 'Chave prim�ria da tabela ECDREGISTROK030_RK1'
/

comment on column ECDREGISTROK030_RK1.rk1_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDREGISTROK030_RK1.rk1_cdreg
  is 'C�digo do registro'
/

comment on column ECDREGISTROK030_RK1.rk1_dtinicio
  is 'Data inicial do per�odo consolidado'
/

comment on column ECDREGISTROK030_RK1.rk1_dtfinal
  is 'Data final do per�odo consolidado'
/

comment on column ECDREGISTROK030_RK1.rk1_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDREGISTROK030_RK1.rk1_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDREGISTROK030_RK1.rk1_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDREGISTROK030_RK1.rk1_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDREGISTROK030_RK1
  add constraint PK_ECDREGISTROK030_RK1 primary key (RK1_IDRK1)
/

create table ECDREGISTROK100_RK2
(
  rk2_idrk2             NUMBER(9) not null,
  rk2_cdmodescr         VARCHAR2(15) not null,
  rk2_cdreg             VARCHAR2(4) not null,
  rk2_cdpais            VARCHAR2(5),
  rk2_cdempresa         VARCHAR2(4),
  rk2_cdcnpj            VARCHAR2(8),
  rk2_txnome            VARCHAR2(255),
  rk2_peparticipacao    VARCHAR2(8),
  rk2_vbevento          VARCHAR2(1),
  rk2_peconsolidacao    VARCHAR2(8),
  rk2_dtiniconsolidacao VARCHAR2(8),
  rk2_dtfimconsolidacao VARCHAR2(8),
  rk2_usinclusao        VARCHAR2(40) not null,
  rk2_dtinclusao        DATE not null,
  rk2_usalteracao       VARCHAR2(40),
  rk2_dtalteracao       DATE
)
/

comment on table ECDREGISTROK100_RK2
  is 'Tabela processada do registro K100'
/

comment on column ECDREGISTROK100_RK2.rk2_idrk2
  is 'Chave prim�ria da tabela ECDREGISTROK100_RK2'
/

comment on column ECDREGISTROK100_RK2.rk2_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDREGISTROK100_RK2.rk2_cdreg
  is 'C�digo do registro'
/

comment on column ECDREGISTROK100_RK2.rk2_cdpais
  is 'C�digo do pa�s da empresa, conforme tabela do Banco Central do Brasil.'
/

comment on column ECDREGISTROK100_RK2.rk2_cdempresa
  is 'C�digo de identifica��o da empresa participante.'
/

comment on column ECDREGISTROK100_RK2.rk2_cdcnpj
  is 'CNPJ (somente os 8 primeiros d�gitos).'
/

comment on column ECDREGISTROK100_RK2.rk2_txnome
  is 'Nome empresarial.'
/

comment on column ECDREGISTROK100_RK2.rk2_peparticipacao
  is 'Percentual de participa��o total do conglomerado na empresa no final do per�odo consolidado: Informar a participa��o acion�ria.'
/

comment on column ECDREGISTROK100_RK2.rk2_vbevento
  is 'Evento societ�rio ocorrido no per�odo: S - Sim N � N�o'
/

comment on column ECDREGISTROK100_RK2.rk2_peconsolidacao
  is 'Percentual de consolida��o da empresa no final do per�odo consolidado: Informar o percentual do resultado da empresa que foi para a consolida��o.'
/

comment on column ECDREGISTROK100_RK2.rk2_dtiniconsolidacao
  is 'Data inicial do per�odo da escritura��o cont�bil da empresa que foi consolidada.'
/

comment on column ECDREGISTROK100_RK2.rk2_dtfimconsolidacao
  is 'Data final do per�odo da escritura��o cont�bil da empresa que foi consolidada'
/

comment on column ECDREGISTROK100_RK2.rk2_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDREGISTROK100_RK2.rk2_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDREGISTROK100_RK2.rk2_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDREGISTROK100_RK2.rk2_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDREGISTROK100_RK2
  add constraint PK_ECDREGISTROK100_RK2 primary key (RK2_IDRK2)
/

create table ECDREGISTROK110_RK3
(
  rk3_idrk3       NUMBER(9) not null,
  rk3_nrrk2       NUMBER(9) not null,
  rk3_cdmodescr   VARCHAR2(15) not null,
  rk3_cdreg       VARCHAR2(4) not null,
  rk3_tpevento    VARCHAR2(1),
  rk3_dtevento    VARCHAR2(8),
  rk3_usinclusao  VARCHAR2(40) not null,
  rk3_dtinclusao  DATE not null,
  rk3_usalteracao VARCHAR2(40),
  rk3_dtalteracao DATE
)
/

comment on table ECDREGISTROK110_RK3
  is 'Tabela processada do registro K110'
/

comment on column ECDREGISTROK110_RK3.rk3_idrk3
  is 'Chave prim�ria da tabela ECDREGISTROK110_RK3'
/

comment on column ECDREGISTROK110_RK3.rk3_nrrk2
  is 'Chave estrangeira da tabela ECDREGISTROK100_RK2'
/

comment on column ECDREGISTROK110_RK3.rk3_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDREGISTROK110_RK3.rk3_cdreg
  is 'C�digo do registro'
/

comment on column ECDREGISTROK110_RK3.rk3_tpevento
  is 'Evento societ�rio ocorrido no per�odo: 1 � Aquisi��o 2 � Aliena��o 3 � Fus�o 4 � Cis�o Parcial 5 � Cis�o Total 6 � Incorpora��o 7 � Extin��o 8 � Constitui��o'
/

comment on column ECDREGISTROK110_RK3.rk3_dtevento
  is 'Data do evento societ�rio.'
/

comment on column ECDREGISTROK110_RK3.rk3_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDREGISTROK110_RK3.rk3_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDREGISTROK110_RK3.rk3_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDREGISTROK110_RK3.rk3_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDREGISTROK110_RK3
  add constraint PK_ECDREGISTROK110_RK3 primary key (RK3_IDRK3)
/

alter table ECDREGISTROK110_RK3
  add constraint FK1_ECDREGISTROK110_RK3 foreign key (RK3_NRRK2)
  references ECDREGISTROK100_RK2 (RK2_IDRK2)
/

create table ECDREGISTROK115_RK4
(
  rk4_idrk4       NUMBER(9) not null,
  rk4_nrrk3       NUMBER(9) not null,
  rk4_cdmodescr   VARCHAR2(15) not null,
  rk4_cdreg       VARCHAR2(4) not null,
  rk4_cdemppart   VARCHAR2(4),
  rk4_tpcondpart  VARCHAR2(1),
  rk4_peevento    VARCHAR2(8),
  rk4_usinclusao  VARCHAR2(40) not null,
  rk4_dtinclusao  DATE not null,
  rk4_usalteracao VARCHAR2(40),
  rk4_dtalteracao DATE
)
/

comment on table ECDREGISTROK115_RK4
  is 'Tabela processada do registro K115'
/

comment on column ECDREGISTROK115_RK4.rk4_idrk4
  is 'Chave prim�ria da tabela ECDREGISTROK115_RK4'
/

comment on column ECDREGISTROK115_RK4.rk4_nrrk3
  is 'Chave estrangeira da tabela ECDREGISTROK110_RK3'
/

comment on column ECDREGISTROK115_RK4.rk4_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDREGISTROK115_RK4.rk4_cdreg
  is 'C�digo do registro'
/

comment on column ECDREGISTROK115_RK4.rk4_cdemppart
  is 'C�digo da empresa envolvida na opera��o'
/

comment on column ECDREGISTROK115_RK4.rk4_tpcondpart
  is 'Condi��o da empresa relacionada � opera��o: 1 � Sucessora; 2 � Adquirente; 3 � Alienante.'
/

comment on column ECDREGISTROK115_RK4.rk4_peevento
  is 'Percentual da empresa participante envolvida na opera��o'
/

comment on column ECDREGISTROK115_RK4.rk4_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDREGISTROK115_RK4.rk4_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDREGISTROK115_RK4.rk4_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDREGISTROK115_RK4.rk4_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDREGISTROK115_RK4
  add constraint PK_ECDREGISTROK115_RK4 primary key (RK4_IDRK4)
/

alter table ECDREGISTROK115_RK4
  add constraint FK1_ECDREGISTROK115_RK4 foreign key (RK4_NRRK3)
  references ECDREGISTROK110_RK3 (RK3_IDRK3)
/

create table ECDREGISTROK200_RK5
(
  rk5_idrk5       NUMBER(9) not null,
  rk5_cdmodescr   VARCHAR2(15) not null,
  rk5_cdreg       VARCHAR2(4) not null,
  rk5_cdnatconta  VARCHAR2(2),
  rk5_tpindconta  VARCHAR2(1),
  rk5_nrnivel     VARCHAR2(3),
  rk5_cdconta     VARCHAR2(30),
  rk5_cdcontasup  VARCHAR2(30),
  rk5_nmconta     VARCHAR2(250),
  rk5_usinclusao  VARCHAR2(40) not null,
  rk5_dtinclusao  DATE not null,
  rk5_usalteracao VARCHAR2(40),
  rk5_dtalteracao DATE
)
/

comment on table ECDREGISTROK200_RK5
  is 'Tabela processada do registro K200'
/

comment on column ECDREGISTROK200_RK5.rk5_idrk5
  is 'Chave prim�ria da tabela ECDREGISTROK200_RK5'
/

comment on column ECDREGISTROK200_RK5.rk5_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDREGISTROK200_RK5.rk5_cdreg
  is 'C�digo do registro'
/

comment on column ECDREGISTROK200_RK5.rk5_cdnatconta
  is 'C�digo da natureza da conta/grupo de contas, conforme tabela publicada pelo Sped.'
/

comment on column ECDREGISTROK200_RK5.rk5_tpindconta
  is 'Indicador do tipo de conta: S - Sint�tica (grupo de contas); A - Anal�tica (conta).'
/

comment on column ECDREGISTROK200_RK5.rk5_nrnivel
  is 'N�vel da conta'
/

comment on column ECDREGISTROK200_RK5.rk5_cdconta
  is 'C�digo da conta'
/

comment on column ECDREGISTROK200_RK5.rk5_cdcontasup
  is 'C�digo da conta superior'
/

comment on column ECDREGISTROK200_RK5.rk5_nmconta
  is 'Nome da conta'
/

comment on column ECDREGISTROK200_RK5.rk5_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDREGISTROK200_RK5.rk5_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDREGISTROK200_RK5.rk5_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDREGISTROK200_RK5.rk5_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDREGISTROK200_RK5
  add constraint PK_ECDREGISTROK200_RK5 primary key (RK5_IDRK5)
/

create table ECDREGISTROK210_RK6
(
  rk6_idrk6       NUMBER(9) not null,
  rk6_nrrk5       NUMBER(9) not null,
  rk6_cdmodescr   VARCHAR2(15) not null,
  rk6_cdreg       VARCHAR2(4) not null,
  rk6_cdempresa   VARCHAR2(4),
  rk6_cdcontaemp  VARCHAR2(30),
  rk6_usinclusao  VARCHAR2(40) not null,
  rk6_dtinclusao  DATE not null,
  rk6_usalteracao VARCHAR2(40),
  rk6_dtalteracao DATE
)
/

comment on table ECDREGISTROK210_RK6
  is 'Tabela processada do registro K210'
/

comment on column ECDREGISTROK210_RK6.rk6_idrk6
  is 'Chave prim�ria da tabela ECDREGISTROK210_RK6'
/

comment on column ECDREGISTROK210_RK6.rk6_nrrk5
  is 'Chave estrangeira da tabela ECDREGISTROK200_RK5'
/

comment on column ECDREGISTROK210_RK6.rk6_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDREGISTROK210_RK6.rk6_cdreg
  is 'C�digo do registro'
/

comment on column ECDREGISTROK210_RK6.rk6_cdempresa
  is 'C�digo de identifica��o da empresa participante'
/

comment on column ECDREGISTROK210_RK6.rk6_cdcontaemp
  is 'C�digo da conta da empresa participante'
/

comment on column ECDREGISTROK210_RK6.rk6_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDREGISTROK210_RK6.rk6_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDREGISTROK210_RK6.rk6_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDREGISTROK210_RK6.rk6_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDREGISTROK210_RK6
  add constraint PK_ECDREGISTROK210_RK6 primary key (RK6_IDRK6)
/

alter table ECDREGISTROK210_RK6
  add constraint FK1_ECDREGISTROK210_RK6 foreign key (RK6_NRRK5)
  references ECDREGISTROK200_RK5 (RK5_IDRK5)
/

create table ECDREGISTROK300_RK7
(
  rk7_idrk7              NUMBER(9) not null,
  rk7_cdmodescr          VARCHAR2(15) not null,
  rk7_cdreg              VARCHAR2(4) not null,
  rk7_cdconta            VARCHAR2(30),
  rk7_vlaglutinado       VARCHAR2(19),
  rk7_tpindvlaglutinado  VARCHAR2(1),
  rk7_vleliminado        VARCHAR2(19),
  rk7_tpindvleliminado   VARCHAR2(1),
  rk7_vlconsolidado      VARCHAR2(19),
  rk7_tpindvlconsolidado VARCHAR2(1),
  rk7_usinclusao         VARCHAR2(40) not null,
  rk7_dtinclusao         DATE not null,
  rk7_usalteracao        VARCHAR2(40),
  rk7_dtalteracao        DATE
)
/

comment on table ECDREGISTROK300_RK7
  is 'Tabela processada do registro K300'
/

comment on column ECDREGISTROK300_RK7.rk7_idrk7
  is 'Chave prim�ria da tabela ECDREGISTROK300_RK7'
/

comment on column ECDREGISTROK300_RK7.rk7_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDREGISTROK300_RK7.rk7_cdreg
  is 'C�digo do registro'
/

comment on column ECDREGISTROK300_RK7.rk7_cdconta
  is 'C�digo da conta consolidada'
/

comment on column ECDREGISTROK300_RK7.rk7_vlaglutinado
  is 'Valor absoluto aglutinado'
/

comment on column ECDREGISTROK300_RK7.rk7_tpindvlaglutinado
  is 'Indicador da situa��o do valor aglutinado: D � Devedor C � Credor'
/

comment on column ECDREGISTROK300_RK7.rk7_vleliminado
  is 'Valor absoluto das elimina��es'
/

comment on column ECDREGISTROK300_RK7.rk7_tpindvleliminado
  is 'Indicador da situa��o do valor eliminado: D � Devedor C � Credor'
/

comment on column ECDREGISTROK300_RK7.rk7_vlconsolidado
  is 'Valor absoluto consolidado'
/

comment on column ECDREGISTROK300_RK7.rk7_tpindvlconsolidado
  is 'Indicador da situa��o do valor consolidado: D � Devedor C � Credor'
/

comment on column ECDREGISTROK300_RK7.rk7_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDREGISTROK300_RK7.rk7_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDREGISTROK300_RK7.rk7_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDREGISTROK300_RK7.rk7_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDREGISTROK300_RK7
  add constraint PK_ECDREGISTROK300_RK7 primary key (RK7_IDRK7)
/

create table ECDREGISTROK310_RK8
(
  rk8_idrk8            NUMBER(9) not null,
  rk8_nrrk7            NUMBER(9) not null,
  rk8_cdmodescr        VARCHAR2(15) not null,
  rk8_cdreg            VARCHAR2(4) not null,
  rk8_cdemppart        VARCHAR2(4),
  rk8_vleliminado      VARCHAR2(19),
  rk8_tpindvleliminado VARCHAR2(1),
  rk8_usinclusao       VARCHAR2(40) not null,
  rk8_dtinclusao       DATE not null,
  rk8_usalteracao      VARCHAR2(40),
  rk8_dtalteracao      DATE
)
/

comment on table ECDREGISTROK310_RK8
  is 'Tabela processada do registro K310'
/

comment on column ECDREGISTROK310_RK8.rk8_idrk8
  is 'Chave prim�ria da tabela ECDREGISTROK310_RK8'
/

comment on column ECDREGISTROK310_RK8.rk8_nrrk7
  is 'Chave estrangeira da tabela ECDREGISTROK300_RK7'
/

comment on column ECDREGISTROK310_RK8.rk8_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDREGISTROK310_RK8.rk8_cdreg
  is 'C�digo do registro'
/

comment on column ECDREGISTROK310_RK8.rk8_cdemppart
  is 'C�digo da empresa detentora do valor aglutinado que foi eliminado'
/

comment on column ECDREGISTROK310_RK8.rk8_vleliminado
  is 'Parcela do valor eliminado total'
/

comment on column ECDREGISTROK310_RK8.rk8_tpindvleliminado
  is 'Indicador da situa��o do valor eliminado: D � Devedor C � Credor'
/

comment on column ECDREGISTROK310_RK8.rk8_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDREGISTROK310_RK8.rk8_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDREGISTROK310_RK8.rk8_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDREGISTROK310_RK8.rk8_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDREGISTROK310_RK8
  add constraint PK_ECDREGISTROK310_RK8 primary key (RK8_IDRK8)
/

alter table ECDREGISTROK310_RK8
  add constraint FK1_ECDREGISTROK310_RK8 foreign key (RK8_NRRK7)
  references ECDREGISTROK300_RK7 (RK7_IDRK7)
/

create table ECDREGISTROK315_RK9
(
  rk9_idrk9            NUMBER(9) not null,
  rk9_nrrk8            NUMBER(9) not null,
  rk9_cdmodescr        VARCHAR2(15) not null,
  rk9_cdreg            VARCHAR2(4) not null,
  rk9_cdempcontra      VARCHAR2(4),
  rk9_cdcontacontra    VARCHAR2(30),
  rk9_vleliminado      VARCHAR2(19),
  rk9_tpindvleliminado VARCHAR2(1),
  rk9_usinclusao       VARCHAR2(40) not null,
  rk9_dtinclusao       DATE not null,
  rk9_usalteracao      VARCHAR2(40),
  rk9_dtalteracao      DATE
)
/

comment on table ECDREGISTROK315_RK9
  is 'Tabela processada do registro K315'
/

comment on column ECDREGISTROK315_RK9.rk9_idrk9
  is 'Chave prim�ria da tabela ECDREGISTROK315_RK9'
/

comment on column ECDREGISTROK315_RK9.rk9_nrrk8
  is 'Chave estrangeira da tabela ECDREGISTROK310_RK8'
/

comment on column ECDREGISTROK315_RK9.rk9_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDREGISTROK315_RK9.rk9_cdreg
  is 'C�digo do registro'
/

comment on column ECDREGISTROK315_RK9.rk9_cdempcontra
  is 'C�digo da empresa da contrapartida'
/

comment on column ECDREGISTROK315_RK9.rk9_cdcontacontra
  is 'C�digo da conta consolidada da contrapartida'
/

comment on column ECDREGISTROK315_RK9.rk9_vleliminado
  is 'Parcela da contrapartida do valor eliminado total'
/

comment on column ECDREGISTROK315_RK9.rk9_tpindvleliminado
  is 'Indicador da situa��o do valor eliminado: D � Devedor C � Credor'
/

comment on column ECDREGISTROK315_RK9.rk9_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDREGISTROK315_RK9.rk9_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDREGISTROK315_RK9.rk9_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDREGISTROK315_RK9.rk9_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDREGISTROK315_RK9
  add constraint PK_ECDREGISTROK315_RK9 primary key (RK9_IDRK9)
/

alter table ECDREGISTROK315_RK9
  add constraint FK1_ECDREGISTROK315_RK9 foreign key (RK9_NRRK8)
  references ECDREGISTROK310_RK8 (RK8_IDRK8)
/

create table ECDREGISTROK990_RKE
(
  rke_idrke         NUMBER(9) not null,
  rke_cdmodescr     VARCHAR2(15) not null,
  rke_cdreg         VARCHAR2(4) not null,
  rke_qtlinhasbloco VARCHAR2(15) not null,
  rke_usinclusao    VARCHAR2(40) not null,
  rke_dtinclusao    DATE not null,
  rke_usalteracao   VARCHAR2(40),
  rke_dtalteracao   DATE
)
/

comment on table ECDREGISTROK990_RKE
  is 'Tabela processada do registro K990'
/

comment on column ECDREGISTROK990_RKE.rke_idrke
  is 'Chave prim�ria da tabela ECDREGISTROK990_RKE'
/

comment on column ECDREGISTROK990_RKE.rke_cdmodescr
  is 'C�digo do modelo de escritura��o da ECD'
/

comment on column ECDREGISTROK990_RKE.rke_cdreg
  is 'C�digo do registro'
/

comment on column ECDREGISTROK990_RKE.rke_qtlinhasbloco
  is 'Quantidade total de linhas do Bloco K.'
/

comment on column ECDREGISTROK990_RKE.rke_usinclusao
  is 'Usu�rio de Inclus�o'
/

comment on column ECDREGISTROK990_RKE.rke_dtinclusao
  is 'Data de Inclus�o'
/

comment on column ECDREGISTROK990_RKE.rke_usalteracao
  is 'Usu�rio de Altera��o'
/

comment on column ECDREGISTROK990_RKE.rke_dtalteracao
  is 'Data de Altera��o'
/

alter table ECDREGISTROK990_RKE
  add constraint PK_ECDREGISTROK990_RKE primary key (RKE_IDRKE)
/

CREATE SEQUENCE SEQ1_ECDREGISTROK001_RKA
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDREGISTROK030_RK1
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDREGISTROK100_RK2
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDREGISTROK110_RK3
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDREGISTROK115_RK4
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDREGISTROK200_RK5
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDREGISTROK210_RK6
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDREGISTROK300_RK7
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDREGISTROK310_RK8
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDREGISTROK315_RK9
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE SEQUENCE SEQ1_ECDREGISTROK990_RKE
MINVALUE 1
MAXVALUE 999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE OR REPLACE PROCEDURE PRC_EXCECDPROCESSAMENTO(PT_CDMODESCRITURACAO IN CHAR
                                                   ,PT_VBBLOCO0          IN CHAR
                                                   ,PT_VBBLOCOI          IN CHAR
                                                   ,PT_VBBLOCOJ          IN CHAR
                                                   ,PT_VBBLOCOK          IN CHAR
                                                   ,PT_VBBLOCO9          IN CHAR) AS
BEGIN
  IF PT_VBBLOCO0 = 'S'
    THEN BEGIN
      DELETE FROM SPEDECDABERTURABLCV10_R0001 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDABERTURAV10_R0000 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDOUTINSCRV10_R0007 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDESCRDESCV10_R0020 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDRELPARTV10_R0180 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDPARTV10_R0150 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDENCERRABLCV10_R0990 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM ECDIDENTSCP_R35 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
    END;
  END IF;
  IF PT_VBBLOCOI = 'S'
    THEN BEGIN
      DELETE FROM SPEDECDABERTURABLCV10_RI001 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDIDESCRV10_RI010 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM ECDCAMPOSADICIONAIS_I02 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDCODAGLUV10_RI052 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDPLREFERV10_RI051 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDPLCONTASV10_RI050 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM ECDSUBCONTACORR_I05 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDTERMABRTV10_RI030 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDCCUSTOV10_RI100 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDPARTLANV10_RI256 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDPARTLANCV10_RI250 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDLANCCTBV10_RI200 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM ECDSALDOPLCTBANT_I57 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDTOTDCV10_RI156 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDDETSALDOSV10_RI155 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDSALDOSV10_RI150 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDDETBALV10_RI310 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDBALDIARIOV10_RI300 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDSLDFINV10_RI356 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDDETSLDARSV10_RI355 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDSALDOANTRESV10_RI350 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDTABHISTV10_RI075 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDENCERRABLCV10_RI990 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
    END;
  END IF;
  IF PT_VBBLOCOJ = 'S'
    THEN BEGIN
      DELETE FROM SPEDECDABERTURABLCV10_RJ001 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDDEMCONTABILV10_RJ005 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDBALPATRIMV10_RJ100 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDDEMRESULTV10_RJ150 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM ECDHISTFATCTB_J20 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM ECDDLPADMPL_J21 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM ECDFATCTBDLPADMPL_J22 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDOUTRASINFV10_RJ800 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM ECDTERMOFINSSUBST_J80 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDTERMENCERRAV10_RJ900 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDSIGNATARIOSV10_RJ930 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM ECDAUDITORINDEP_J93 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDENCERRABLCV10_RJ990 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
    END;
  END IF;
  IF PT_VBBLOCOK = 'S'
    THEN BEGIN
      DELETE FROM ECDREGISTROK315_RK9 WHERE RK9_CDMODESCR = PT_CDMODESCRITURACAO;
      DELETE FROM ECDREGISTROK310_RK8 WHERE RK8_CDMODESCR = PT_CDMODESCRITURACAO;
      DELETE FROM ECDREGISTROK300_RK7 WHERE RK7_CDMODESCR = PT_CDMODESCRITURACAO;
      DELETE FROM ECDREGISTROK990_RKE WHERE RKE_CDMODESCR = PT_CDMODESCRITURACAO;
      DELETE FROM ECDREGISTROK210_RK6 WHERE RK6_CDMODESCR = PT_CDMODESCRITURACAO;
      DELETE FROM ECDREGISTROK200_RK5 WHERE RK5_CDMODESCR = PT_CDMODESCRITURACAO;
      DELETE FROM ECDREGISTROK115_RK4 WHERE RK4_CDMODESCR = PT_CDMODESCRITURACAO;
      DELETE FROM ECDREGISTROK110_RK3 WHERE RK3_CDMODESCR = PT_CDMODESCRITURACAO;
      DELETE FROM ECDREGISTROK100_RK2 WHERE RK2_CDMODESCR = PT_CDMODESCRITURACAO;
      DELETE FROM ECDREGISTROK030_RK1 WHERE RK1_CDMODESCR = PT_CDMODESCRITURACAO;
      DELETE FROM ECDREGISTROK001_RKA WHERE RKA_CDMODESCR = PT_CDMODESCRITURACAO;
    END;
  END IF;
  IF PT_VBBLOCO9 = 'S'
    THEN BEGIN
      DELETE FROM SPEDECDABERTURABLCV10_R9001 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDREGISTROSV10_R9900 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDENCERRABLCV10_R9990 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
      DELETE FROM SPEDECDENCERRABLCV10_R9999 WHERE SMECODIGO = PT_CDMODESCRITURACAO;
    END;
  END IF;
END;
/

CREATE OR REPLACE PROCEDURE PRC_ECDPROCESSAREGISTROK001(PT_SME_CODIGO         IN VARCHAR2,
                                                        PT_TOTALREGISTRO_K    IN NUMBER,
                                                        PT_TOTALREGISTRO_K001 OUT NUMBER) AS
  VR_RKA_TPINDMOV ECDREGISTROK001_RKA.RKA_TPINDMOV%TYPE;
BEGIN
  PT_TOTALREGISTRO_K001 := 1;
  IF PT_TOTALREGISTRO_K > 0 THEN
    VR_RKA_TPINDMOV := 0;
  ELSE
    VR_RKA_TPINDMOV := 1;
  END IF;
  INSERT INTO ECDREGISTROK001_RKA
    (RKA_IDRKA,
     RKA_CDMODESCR,
     RKA_CDREG,
     RKA_TPINDMOV,
     RKA_USINCLUSAO,
     RKA_DTINCLUSAO)
  VALUES
    (SEQ1_ECDREGISTROK001_RKA.NEXTVAL,
     PT_SME_CODIGO,
     'K001',
     VR_RKA_TPINDMOV,
     get_user_mxm,
     SYSDATE);
END PRC_ECDPROCESSAREGISTROK001;
/

CREATE OR REPLACE PROCEDURE PRC_ECDPROCESSAREGISTROK030(PT_SME_CODIGO         IN VARCHAR2,
                                                        PT_TOTALREGISTRO_K030 OUT NUMBER) AS
  CURSOR CS_DADOS_REGISTRO_K030 IS
    SELECT 'K030' AS REG,
           CASE
             WHEN MIN(EK2_DTINICONSOLIDACAO) = SME_DTINICIO THEN
              TO_CHAR(MIN(EK2_DTINICONSOLIDACAO), 'DDMMRRRR')
             ELSE
              TO_CHAR(SME_DTINICIO, 'DDMMRRRR')
           END AS DT_INI,
           TO_CHAR(SME_DTFIM, 'DDMMRRRR') AS DT_FIM
      FROM ECDCABRELEMPCONS_EK1, ECDDETRELEMPCONS_EK2, SPEDMODELOESCRT_SME
     WHERE EK2_NREK1 = EK1_IDECDCABRELEMPCONS
       AND SME_CODIGO = EK1_CDMODESCR
       AND SME_SYSTEMID = 'ECD'
       AND SME_CODIGO = PT_SME_CODIGO
     GROUP BY SME_DTINICIO, SME_DTFIM;
BEGIN
  PT_TOTALREGISTRO_K030 := 1;
  FOR REC_DADOS_REGISTRO_K030 IN CS_DADOS_REGISTRO_K030 LOOP
    BEGIN
      INSERT INTO ECDREGISTROK030_RK1
        (RK1_IDRK1,
         RK1_CDMODESCR,
         RK1_CDREG,
         RK1_DTINICIO,
         RK1_DTFINAL,
         RK1_USINCLUSAO,
         RK1_DTINCLUSAO)
      VALUES
        (SEQ1_ECDREGISTROK030_RK1.NEXTVAL,
         PT_SME_CODIGO,
         REC_DADOS_REGISTRO_K030.REG,
         REC_DADOS_REGISTRO_K030.DT_INI,
         REC_DADOS_REGISTRO_K030.DT_FIM,
         GET_USER_MXM,
         SYSDATE);
    END;
  END LOOP;
END PRC_ECDPROCESSAREGISTROK030;
/

CREATE OR REPLACE PROCEDURE PRC_ECDPROCESSAREGK100K110K115(PT_SME_CODIGO         IN VARCHAR2,
                                                           PT_TOTALREGISTRO_K100 OUT NUMBER,
                                                           PT_TOTALREGISTRO_K110 OUT NUMBER,
                                                           PT_TOTALREGISTRO_K115 OUT NUMBER) AS
  VR_RK2_IDRK2     ECDREGISTROK100_RK2.RK2_IDRK2%TYPE;
  VR_EK5_CDEMPCONS ECDCABEVENTSOC_EK5.EK5_CDEMPCONS%TYPE;
  VR_RK3_IDRK3     ECDREGISTROK110_RK3.RK3_IDRK3%TYPE;
  VR_EK7_NREK6     ECDEMPPARTEVENTSOC_EK7.EK7_NREK6%TYPE;
  VR_RK4_IDRK4     ECDREGISTROK115_RK4.RK4_IDRK4%TYPE;
  CURSOR CS_DADOS_REGISTRO_K100 IS
    SELECT 'K100' AS REG,
           PEMP_CODPAIS AS COD_PAIS,
           EK2_NMIDENTEMPRESA AS EMP_COD,
           DECODE(PEMP_CODPAIS, '01058', SUBSTR(EMP_CGC, 1, 8), NULL) AS CNPJ,
           PEMP_NOMEFANTASIA AS NOME,
           EK2_PEPARTICIPACAO AS PER_PART,
           EK2_VBEVENTOSOCIETARIO AS EVENTO,
           EK2_PECONSOLIDACAO AS PER_CONS,
           TO_CHAR(EK2_DTINICONSOLIDACAO, 'DDMMRRRR') AS DATA_INI_EMP,
           TO_CHAR(EK2_DTFIMCONSOLIDACAO, 'DDMMRRRR') AS DATA_FIN_EMP,
           PEMP_CDEMPRESA AS CHAVE
      FROM ECDCABRELEMPCONS_EK1,
           ECDDETRELEMPCONS_EK2,
           SPEDPAREMPRESA_PEMP,
           EMPGERAL_EMP
     WHERE EK2_NREK1 = EK1_IDECDCABRELEMPCONS
       AND EK2_CDEMPRESA = PEMP_CDEMPRESA(+)
       AND PEMP_CDFILIAL IS NULL
       AND EK2_CDEMPRESA = EMP_CODIGO
       AND EK1_CDMODESCR = PT_SME_CODIGO;
  CURSOR CS_DADOS_REGISTRO_K110 IS
    SELECT 'K110' AS REG,
           EK6_TPEVENTO AS TP_EVENTO,
           TO_CHAR(EK6_DTEVENTO, 'DDMMRRRR') AS DT_EVENTO,
           EK6_IDECDDETEVENTSOC AS CHAVE
      FROM ECDCABEVENTSOC_EK5, ECDDETEVENTSOC_EK6
     WHERE EK6_NREK5 = EK5_IDECDCABEVENTSOC
       AND EK5_CDMODESCR = PT_SME_CODIGO
       AND EK5_CDEMPCONS = VR_EK5_CDEMPCONS;
  CURSOR CS_DADOS_REGISTRO_K115 IS
    SELECT 'K115' AS REG,
           (SELECT EK2_NMIDENTEMPRESA
              FROM ECDCABRELEMPCONS_EK1, ECDDETRELEMPCONS_EK2
             WHERE EK2_NREK1 = EK1_IDECDCABRELEMPCONS
               AND EK2_CDEMPRESA = EK7_CDEMPPART
               AND EK1_CDMODESCR = PT_SME_CODIGO) AS EMP_COD_PART,
           EK7_TPCONDEMPPART AS COND_PART,
           EK7_PEEMPPART AS PER_EVT
      FROM ECDEMPPARTEVENTSOC_EK7
     WHERE EK7_NREK6 = VR_EK7_NREK6;
BEGIN
  PT_TOTALREGISTRO_K100 := 0;
  PT_TOTALREGISTRO_K110 := 0;
  PT_TOTALREGISTRO_K115 := 0;
  --K100
  FOR REC_DADOS_REGISTRO_K100 IN CS_DADOS_REGISTRO_K100 LOOP
    BEGIN
      VR_RK2_IDRK2          := SEQ1_ECDREGISTROK100_RK2.NEXTVAL;
      VR_EK5_CDEMPCONS      := REC_DADOS_REGISTRO_K100.CHAVE;
      PT_TOTALREGISTRO_K100 := PT_TOTALREGISTRO_K100 + 1;
      INSERT INTO ECDREGISTROK100_RK2
        (RK2_IDRK2,
         RK2_CDMODESCR,
         RK2_CDREG,
         RK2_CDPAIS,
         RK2_CDEMPRESA,
         RK2_CDCNPJ,
         RK2_TXNOME,
         RK2_PEPARTICIPACAO,
         RK2_VBEVENTO,
         RK2_PECONSOLIDACAO,
         RK2_DTINICONSOLIDACAO,
         RK2_DTFIMCONSOLIDACAO,
         RK2_USINCLUSAO,
         RK2_DTINCLUSAO)
      VALUES
        (VR_RK2_IDRK2,
         PT_SME_CODIGO,
         REC_DADOS_REGISTRO_K100.REG,
         REC_DADOS_REGISTRO_K100.COD_PAIS,
         REC_DADOS_REGISTRO_K100.EMP_COD,
         REC_DADOS_REGISTRO_K100.CNPJ,
         REC_DADOS_REGISTRO_K100.NOME,
         REC_DADOS_REGISTRO_K100.PER_PART,
         REC_DADOS_REGISTRO_K100.EVENTO,
         REC_DADOS_REGISTRO_K100.PER_CONS,
         REC_DADOS_REGISTRO_K100.DATA_INI_EMP,
         REC_DADOS_REGISTRO_K100.DATA_FIN_EMP,
         GET_USER_MXM,
         SYSDATE);
      --K110
      FOR REC_DADOS_REGISTRO_K110 IN CS_DADOS_REGISTRO_K110 LOOP
        BEGIN
          VR_RK3_IDRK3          := SEQ1_ECDREGISTROK110_RK3.NEXTVAL;
          VR_EK7_NREK6          := REC_DADOS_REGISTRO_K110.CHAVE;
          PT_TOTALREGISTRO_K110 := PT_TOTALREGISTRO_K110 + 1;
          INSERT INTO ECDREGISTROK110_RK3
            (RK3_IDRK3,
             RK3_NRRK2,
             RK3_CDMODESCR,
             RK3_CDREG,
             RK3_TPEVENTO,
             RK3_DTEVENTO,
             RK3_USINCLUSAO,
             RK3_DTINCLUSAO)
          VALUES
            (VR_RK3_IDRK3,
             VR_RK2_IDRK2,
             PT_SME_CODIGO,
             REC_DADOS_REGISTRO_K110.REG,
             REC_DADOS_REGISTRO_K110.TP_EVENTO,
             REC_DADOS_REGISTRO_K110.DT_EVENTO,
             GET_USER_MXM,
             SYSDATE);
        END;
        --K115
        FOR REC_DADOS_REGISTRO_K115 IN CS_DADOS_REGISTRO_K115 LOOP
          BEGIN
            VR_RK4_IDRK4          := SEQ1_ECDREGISTROK115_RK4.NEXTVAL;
            PT_TOTALREGISTRO_K115 := PT_TOTALREGISTRO_K115 + 1;
            INSERT INTO ECDREGISTROK115_RK4
              (RK4_IDRK4,
               RK4_NRRK3,
               RK4_CDMODESCR,
               RK4_CDREG,
               RK4_CDEMPPART,
               RK4_TPCONDPART,
               RK4_PEEVENTO,
               RK4_USINCLUSAO,
               RK4_DTINCLUSAO)
            VALUES
              (VR_RK4_IDRK4,
               VR_RK3_IDRK3,
               PT_SME_CODIGO,
               REC_DADOS_REGISTRO_K115.REG,
               REC_DADOS_REGISTRO_K115.EMP_COD_PART,
               REC_DADOS_REGISTRO_K115.COND_PART,
               REC_DADOS_REGISTRO_K115.PER_EVT,
               GET_USER_MXM,
               SYSDATE);
          END;
        END LOOP;
      END LOOP;
    END;
  END LOOP;
END PRC_ECDPROCESSAREGK100K110K115;
/

CREATE OR REPLACE PROCEDURE PRC_ECDPROCESSAREGK200K210(PT_SME_CODIGO         IN VARCHAR2,
                                                       PT_TOTALREGISTRO_K200 OUT NUMBER,
                                                       PT_TOTALREGISTRO_K210 OUT NUMBER) AS
  TYPE TB_RK5_CDREG IS TABLE OF ECDREGISTROK200_RK5.RK5_CDREG%TYPE;
  TYPE TB_RK5_CDNATCONTA IS TABLE OF ECDREGISTROK200_RK5.RK5_CDNATCONTA%TYPE;
  TYPE TB_RK5_TPINDCONTA IS TABLE OF ECDREGISTROK200_RK5.RK5_NRNIVEL%TYPE;
  TYPE TB_RK5_NRNIVEL IS TABLE OF ECDREGISTROK200_RK5.RK5_IDRK5%TYPE;
  TYPE TB_RK5_CDCONTA IS TABLE OF ECDREGISTROK200_RK5.RK5_CDCONTA%TYPE;
  TYPE TB_RK5_CDCONTASUP IS TABLE OF ECDREGISTROK200_RK5.RK5_CDCONTASUP%TYPE;
  TYPE TB_RK5_NMCONTA IS TABLE OF ECDREGISTROK200_RK5.RK5_NMCONTA%TYPE;
  VR_RK5_IDRK5      ECDREGISTROK200_RK5.RK5_IDRK5%TYPE;
  VR_RK5_CDREG      TB_RK5_CDREG;
  VR_RK5_CDNATCONTA TB_RK5_CDNATCONTA;
  VR_RK5_TPINDCONTA TB_RK5_TPINDCONTA;
  VR_RK5_NRNIVEL    TB_RK5_NRNIVEL;
  VR_RK5_CDCONTA    TB_RK5_CDCONTA;
  VR_RK5_CDCONTASUP TB_RK5_CDCONTASUP;
  VR_RK5_NMCONTA    TB_RK5_NMCONTA;
  TYPE TB_RK6_CDREG IS TABLE OF ECDREGISTROK210_RK6.RK6_CDREG%TYPE;
  TYPE TB_RK6_CDEMPRESA IS TABLE OF ECDREGISTROK210_RK6.RK6_CDEMPRESA%TYPE;
  TYPE TB_RK6_CDCONTAEMP IS TABLE OF ECDREGISTROK210_RK6.RK6_CDCONTAEMP%TYPE;
  VR_RK6_IDRK6      ECDREGISTROK210_RK6.RK6_IDRK6%TYPE;
  VR_RK6_CDREG      TB_RK6_CDREG;
  VR_RK6_CDEMPRESA  TB_RK6_CDEMPRESA;
  VR_RK6_CDCONTAEMP TB_RK6_CDCONTAEMP;
  VR_CDCONTA ECDREGISTROK200_RK5.RK5_CDCONTA%TYPE;
  CURSOR CS_DADOS_REGISTRO_K200 IS
    SELECT DISTINCT 'K200' AS REG,
                    COD_NAT,
                    PLC_SA AS IND_CTA,
                    PLC_GRAU AS NIVEL,
                    MONTAMASCARA(PLC_NOCONTAB, CPLC_MASCARA) AS COD_CTA,
                    DECODE(PLC_GRAU,
                           1,
                           NULL,
                           MONTAMASCARA(PLC_NOSUP, CPLC_MASCARA)) AS COD_CTA_SUP,
                    PLC_DSCONTAB AS CTA,
                    DECODE(PLC_SA, 'A', 'K210') AS REG,
                    DECODE(PLC_SA, 'A', EMP_K210) AS COD_EMP,
                    DECODE(PLC_SA, 'A', COD_CTA_EMP) AS COD_CTA_EMP
      FROM PLANOCTA_PLC A,
           CDPLANO_CPLC,
           (SELECT SPCC_CODNAT AS COD_NAT,
                   MONTAMASCARA(CMP_NOCONTABORI, CPLC_MASCARA) AS COD_CTA_EMP,
                   CMP_CDPLANODES,
                   CMP_NOCONTABDES,
                   EK2_NMIDENTEMPRESA AS EMP_K210
              FROM CONVMOEDAPLC_CMP,
                   SPEDMODELOESCRT_SME,
                   EMPGERAL_EMP         A,
                   SPEDPARCCONTAB_SPCC,
                   CDPLANO_CPLC,
                   EMPGERAL_EMP         B,
                   ECDCABRELEMPCONS_EK1,
                   ECDDETRELEMPCONS_EK2
             WHERE SME_CDEMPRESA = A.EMP_CODIGO
               AND SME_CDFILIAL IS NULL
               AND SME_SYSTEMID = 'ECD'
               AND CMP_CDPLANODES = A.EMP_CODPLCONTA
               AND SPCC_PLCONTAB = A.EMP_CODPLCONTA
               AND SPCC_PLCONTAB = CMP_CDPLANODES
               AND SPCC_NOCONTAB = CMP_NOCONTABDES
               AND CPLC_CODIGO = CMP_CDPLANOORI
               AND CMP_CDPLANODES IS NOT NULL
               AND EK2_NREK1 = EK1_IDECDCABRELEMPCONS
               AND B.EMP_CODIGO = EK2_CDEMPRESA
               AND EK1_CDMODESCR = SME_CODIGO
               AND B.EMP_CODPLCONTA = CMP_CDPLANOORI
               AND SME_CODIGO = PT_SME_CODIGO) B
     WHERE A.PLC_CODPLANO = B.CMP_CDPLANODES
       AND CPLC_CODIGO = A.PLC_CODPLANO
       AND CPLC_CODIGO = B.CMP_CDPLANODES
       AND A.PLC_NOCONTAB =
           SUBSTR(B.CMP_NOCONTABDES, 1, LENGTH(A.PLC_NOCONTAB))
     ORDER BY COD_CTA, COD_CTA_EMP;
BEGIN
  PT_TOTALREGISTRO_K200 := 0;
  PT_TOTALREGISTRO_K210 := 0;
  VR_CDCONTA            := 'CONTA_VAZIA';
  OPEN CS_DADOS_REGISTRO_K200;
  LOOP
    FETCH CS_DADOS_REGISTRO_K200 BULK COLLECT
      INTO VR_RK5_CDREG,
           VR_RK5_CDNATCONTA,
           VR_RK5_TPINDCONTA,
           VR_RK5_NRNIVEL,
           VR_RK5_CDCONTA,
           VR_RK5_CDCONTASUP,
           VR_RK5_NMCONTA,
           VR_RK6_CDREG,
           VR_RK6_CDEMPRESA,
           VR_RK6_CDCONTAEMP LIMIT 500;
    EXIT WHEN VR_RK5_CDREG.COUNT = 0;
    IF VR_RK5_CDREG.EXISTS(1) THEN
      BEGIN
        FOR I IN VR_RK5_CDREG.FIRST .. VR_RK5_CDREG.LAST LOOP
          BEGIN
            IF (VR_RK5_CDCONTA(I) <> VR_CDCONTA) THEN
              BEGIN
                VR_CDCONTA   := VR_RK5_CDCONTA(I);
                VR_RK5_IDRK5 := SEQ1_ECDREGISTROK200_RK5.NEXTVAL;
                INSERT INTO ECDREGISTROK200_RK5
                  (RK5_IDRK5,
                   RK5_CDMODESCR,
                   RK5_CDREG,
                   RK5_CDNATCONTA,
                   RK5_TPINDCONTA,
                   RK5_NRNIVEL,
                   RK5_CDCONTA,
                   RK5_CDCONTASUP,
                   RK5_NMCONTA,
                   RK5_USINCLUSAO,
                   RK5_DTINCLUSAO)
                VALUES
                  (VR_RK5_IDRK5,
                   PT_SME_CODIGO,
                   VR_RK5_CDREG(I),
                   VR_RK5_CDNATCONTA(I),
                   VR_RK5_TPINDCONTA(I),
                   VR_RK5_NRNIVEL(I),
                   VR_RK5_CDCONTA(I),
                   VR_RK5_CDCONTASUP(I),
                   VR_RK5_NMCONTA(I),
                   GET_USER_MXM,
                   SYSDATE);
                PT_TOTALREGISTRO_K200 := PT_TOTALREGISTRO_K200 + 1;
              END;
            END IF;
            IF VR_RK5_TPINDCONTA(I) = 'A' THEN
              BEGIN
                VR_RK6_IDRK6 := SEQ1_ECDREGISTROK210_RK6.NEXTVAL;
                INSERT INTO ECDREGISTROK210_RK6
                  (RK6_IDRK6,
                   RK6_NRRK5,
                   RK6_CDMODESCR,
                   RK6_CDREG,
                   RK6_CDEMPRESA,
                   RK6_CDCONTAEMP,
                   RK6_USINCLUSAO,
                   RK6_DTINCLUSAO)
                VALUES
                  (VR_RK6_IDRK6,
                   VR_RK5_IDRK5,
                   PT_SME_CODIGO,
                   VR_RK6_CDREG(I),
                   VR_RK6_CDEMPRESA(I),
                   VR_RK6_CDCONTAEMP(I),
                   GET_USER_MXM,
                   SYSDATE);
                PT_TOTALREGISTRO_K210 := PT_TOTALREGISTRO_K210 + 1;
              END;
            END IF;
          END;
        END LOOP;
      END;
    END IF;
  END LOOP;
  CLOSE CS_DADOS_REGISTRO_K200;
END PRC_ECDPROCESSAREGK200K210;
/

CREATE OR REPLACE PROCEDURE PRC_ECDPROCESSAREGK300K310K315(PT_SME_CODIGO         IN VARCHAR2,
                                                           PT_TOTALREGISTRO_K300 OUT NUMBER,
                                                           PT_TOTALREGISTRO_K310 OUT NUMBER,
                                                           PT_TOTALREGISTRO_K315 OUT NUMBER) AS
  VR_EK8_CDCONTACONTABIL ECDCABLANCVLELI_EK8.EK8_CDCONTACONTABIL%TYPE;
  VR_EK0_NREK9           ECDEMPCONTRAVLELI_EK0.EK0_NREK9%TYPE;
  VR_CPLC_MASCARA        CDPLANO_CPLC.CPLC_MASCARA%TYPE;
  VR_RK7_IDRK7           ECDREGISTROK300_RK7.RK7_IDRK7%TYPE;
  VR_RK8_IDRK8           ECDREGISTROK310_RK8.RK8_IDRK8%TYPE;
  VR_RK9_IDRK9           ECDREGISTROK315_RK9.RK9_IDRK9%TYPE;
  CURSOR CS_DADOS_REGISTRO_K300 IS
    SELECT 'K300' AS REG,
           MONTAMASCARA(EK4_CDCTBCONSOLIDADORA, CPLC_MASCARA) AS COD_CTA,
           TO_CHAR(EK4_VLAGLUTINADO, 'FM9999999999990D00') AS VAL_AG,
           EK4_TPINDVLAGLUTINADO AS IND_VAL_AG,
           TO_CHAR(EK4_VLELIMINADO, 'FM9999999999990D00') AS VAL_EL,
           EK4_TPINDVLELIMINADO AS IND_VAL_EL,
           TO_CHAR(EK4_VLCONSOLIDADO, 'FM9999999999990D00') AS VAL_CS,
           EK4_TPINDVLCONSOLIDADO AS IND_VAL_CS,
           EK4_CDCTBCONSOLIDADORA AS CONTA,
           CPLC_MASCARA AS MASCARA
      FROM ECDCABSLDCTBCONS_EK3,
           ECDDETSLDCTBCONS_EK4,
           SPEDMODELOESCRT_SME,
           EMPGERAL_EMP,
           CDPLANO_CPLC
     WHERE EK4_NREK3 = EK3_IDECDCABSLDCTBCONS
       AND EK3_CDMODESCR = SME_CODIGO
       AND SME_CDEMPRESA = EMP_CODIGO
       AND SME_CDFILIAL IS NULL
       AND SME_SYSTEMID = 'ECD'
       AND CPLC_CODIGO = EMP_CODPLCONTA
       AND EK3_CDMODESCR = PT_SME_CODIGO
     ORDER BY EK4_CDCTBCONSOLIDADORA;
  CURSOR CS_DADOS_REGISTRO_K310 IS
    SELECT 'K310' AS REG,
           EK2_NMIDENTEMPRESA AS EMP_COD_PARTE,
           TO_CHAR(EK9_VLPARCELI, 'FM9999999999990D00') AS VALOR,
           EK9_TPINDVLPARCELI AS IND_VALOR,
           EK9_IDECDDETLANCVLELI AS CHAVE
      FROM ECDCABLANCVLELI_EK8,
           ECDDETLANCVLELI_EK9,
           SPEDMODELOESCRT_SME,
           ECDCABRELEMPCONS_EK1,
           ECDDETRELEMPCONS_EK2
     WHERE EK9_NREK8 = EK8_IDECDCABLANCVLELI
       AND ek2_nrek1 = EK1_IDECDCABRELEMPCONS
       AND EK1_CDMODESCR = SME_CODIGO
       AND EK8_CDMODESCR = SME_CODIGO
       AND EK1_CDMODESCR = EK8_CDMODESCR
       AND SME_CODIGO = EK8_CDMODESCR
       AND EK9_CDEMPDETPARC = EK2_CDEMPRESA
       AND EK8_CDCONTACONTABIL = VR_EK8_CDCONTACONTABIL;
  CURSOR CS_DADOS_REGISTRO_K315 IS
    SELECT 'K315' AS REG,
           (SELECT EK2_NMIDENTEMPRESA
              FROM ECDCABRELEMPCONS_EK1, ECDDETRELEMPCONS_EK2
             WHERE EK2_NREK1 = EK1_IDECDCABRELEMPCONS
               AND EK2_CDEMPRESA = EK0_CDEMPCONTRA
               AND EK1_CDMODESCR = PT_SME_CODIGO) AS EMP_COD_CONTRA,
           MONTAMASCARA(EK0_CDCONTACONTRA, '9.99.9.99') AS COD_CONTRA,
           TO_CHAR(EK0_VLCONTRA, 'FM9999999999990D00') AS VALOR,
           EK0_TPINDVLCONTRA AS IND_VALOR
      FROM ECDEMPCONTRAVLELI_EK0
     WHERE EK0_NREK9 = VR_EK0_NREK9;
BEGIN
  PT_TOTALREGISTRO_K300 := 0;
  PT_TOTALREGISTRO_K310 := 0;
  PT_TOTALREGISTRO_K315 := 0;
  --K300
  FOR REC_DADOS_REGISTRO_K300 IN CS_DADOS_REGISTRO_K300 LOOP
    BEGIN
      VR_RK7_IDRK7          := SEQ1_ECDREGISTROK300_RK7.NEXTVAL;
      PT_TOTALREGISTRO_K300 := PT_TOTALREGISTRO_K300 + 1;
      VR_EK8_CDCONTACONTABIL := REC_DADOS_REGISTRO_K300.CONTA;
      VR_CPLC_MASCARA        := REC_DADOS_REGISTRO_K300.MASCARA;
      INSERT INTO ECDREGISTROK300_RK7
        (RK7_IDRK7,
         RK7_CDMODESCR,
         RK7_CDREG,
         RK7_CDCONTA,
         RK7_VLAGLUTINADO,
         RK7_TPINDVLAGLUTINADO,
         RK7_VLELIMINADO,
         RK7_TPINDVLELIMINADO,
         RK7_VLCONSOLIDADO,
         RK7_TPINDVLCONSOLIDADO,
         RK7_USINCLUSAO,
         RK7_DTINCLUSAO)
      VALUES
        (VR_RK7_IDRK7,
         PT_SME_CODIGO,
         REC_DADOS_REGISTRO_K300.REG,
         REC_DADOS_REGISTRO_K300.COD_CTA,
         REC_DADOS_REGISTRO_K300.VAL_AG,
         REC_DADOS_REGISTRO_K300.IND_VAL_AG,
         REC_DADOS_REGISTRO_K300.VAL_EL,
         REC_DADOS_REGISTRO_K300.IND_VAL_EL,
         REC_DADOS_REGISTRO_K300.VAL_CS,
         REC_DADOS_REGISTRO_K300.IND_VAL_CS,
         GET_USER_MXM,
         SYSDATE);
      --K310
      FOR REC_DADOS_REGISTRO_K310 IN CS_DADOS_REGISTRO_K310 LOOP
        BEGIN
          VR_RK8_IDRK8          := SEQ1_ECDREGISTROK310_RK8.NEXTVAL;
          PT_TOTALREGISTRO_K310 := PT_TOTALREGISTRO_K310 + 1;
          VR_EK0_NREK9 := REC_DADOS_REGISTRO_K310.CHAVE;
          INSERT INTO ECDREGISTROK310_RK8
            (RK8_IDRK8,
             RK8_NRRK7,
             RK8_CDMODESCR,
             RK8_CDREG,
             RK8_CDEMPPART,
             RK8_VLELIMINADO,
             RK8_TPINDVLELIMINADO,
             RK8_USINCLUSAO,
             RK8_DTINCLUSAO)
          VALUES
            (VR_RK8_IDRK8,
             VR_RK7_IDRK7,
             PT_SME_CODIGO,
             REC_DADOS_REGISTRO_K310.REG,
             REC_DADOS_REGISTRO_K310.EMP_COD_PARTE,
             REC_DADOS_REGISTRO_K310.VALOR,
             REC_DADOS_REGISTRO_K310.IND_VALOR,
             GET_USER_MXM,
             SYSDATE);
          --K315
          FOR REC_DADOS_REGISTRO_K315 IN CS_DADOS_REGISTRO_K315 LOOP
            BEGIN
              VR_RK9_IDRK9          := SEQ1_ECDREGISTROK315_RK9.NEXTVAL;
              PT_TOTALREGISTRO_K315 := PT_TOTALREGISTRO_K315 + 1;
              INSERT INTO ECDREGISTROK315_RK9
                (RK9_IDRK9,
                 RK9_NRRK8,
                 RK9_CDMODESCR,
                 RK9_CDREG,
                 RK9_CDEMPCONTRA,
                 RK9_CDCONTACONTRA,
                 RK9_VLELIMINADO,
                 RK9_TPINDVLELIMINADO,
                 RK9_USINCLUSAO,
                 RK9_DTINCLUSAO)
              VALUES
                (VR_RK9_IDRK9,
                 VR_RK8_IDRK8,
                 PT_SME_CODIGO,
                 REC_DADOS_REGISTRO_K315.REG,
                 REC_DADOS_REGISTRO_K315.EMP_COD_CONTRA,
                 REC_DADOS_REGISTRO_K315.COD_CONTRA,
                 REC_DADOS_REGISTRO_K315.VALOR,
                 REC_DADOS_REGISTRO_K315.IND_VALOR,
                 GET_USER_MXM,
                 SYSDATE);
            END;
          END LOOP;
        END;
      END LOOP;
    END;
  END LOOP;
END PRC_ECDPROCESSAREGK300K310K315;
/

CREATE OR REPLACE PROCEDURE PRC_ECDPROCESSAREGISTROK990(PT_SME_CODIGO         IN VARCHAR2,
                                                        PT_TOTALREGISTRO_K    IN NUMBER,
                                                        PT_TOTALREGISTRO_K990 OUT NUMBER) AS
BEGIN
  PT_TOTALREGISTRO_K990 := 1;
  INSERT INTO ECDREGISTROK990_RKE
    (RKE_IDRKE,
     RKE_CDMODESCR,
     RKE_CDREG,
     RKE_QTLINHASBLOCO,
     RKE_USINCLUSAO,
     RKE_DTINCLUSAO)
  VALUES
    (SEQ1_ECDREGISTROK990_RKE.NEXTVAL,
     PT_SME_CODIGO,
     'K990',
     (PT_TOTALREGISTRO_K + PT_TOTALREGISTRO_K990),
     GET_USER_MXM,
     SYSDATE);
END PRC_ECDPROCESSAREGISTROK990;
/

DELETE FROM TIPOENUMERADO_TENU WHERE TENU_CDTPENUMERADO IN ('TPENU_CONDEMPRELACOPERACAOECD','TPENU_EVENTOSSOCIETARIOSECD')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_CONDEMPRELACOPERACAOECD', '1', 'Sucessora')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_CONDEMPRELACOPERACAOECD', '2', 'Adquirente')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_CONDEMPRELACOPERACAOECD', '3', 'Alienante')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_EVENTOSSOCIETARIOSECD', '1', 'Aquisi��o')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_EVENTOSSOCIETARIOSECD', '2', 'Aliena��o')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_EVENTOSSOCIETARIOSECD', '3', 'Fus�o')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_EVENTOSSOCIETARIOSECD', '4', 'Cis�o Parcial')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_EVENTOSSOCIETARIOSECD', '5', 'Cis�o Total')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_EVENTOSSOCIETARIOSECD', '6', 'Incorpora��o')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_EVENTOSSOCIETARIOSECD', '7', 'Extin��o')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_EVENTOSSOCIETARIOSECD', '8', 'Constitui��o')
/

DELETE FROM ERROMSG_ERM
 WHERE ERM_CDERRO IN ('EK00001',
                      'EK00002',
                      'EK00003',
                      'EK00004',
                      'EK00005',
                      'EK00006',
                      'EK00007',
                      'EK00008',
                      'EK00009',
                      'EK00010',
                      'EK00013',
                      'EK00014',
                      'EK10001',
                      'EK10002',
                      'EK10003',
                      'EK10004',
                      'EK10005',
                      'EK20001',
                      'EK20002',
                      'EK20003',
                      'EK20004',
                      'EK20005',
                      'EK20006',
                      'EK20007',
                      'EK20008',
                      'EK20009',
                      'EK20010',
                      'EK20011',
                      'EK20012',
                      'EK20013',
                      'EK30001',
                      'EK30002',
                      'EK30003',
                      'EK30004',
                      'EK40001',
                      'EK40002',
                      'EK40003',
                      'EK50001',
                      'EK50002',
                      'EK50003',
                      'EK50004',
                      'EK50005',
                      'EK50006',
                      'EK50007',
                      'EK50008',
                      'EK60001',
                      'EK60002',
                      'EK60003',
                      'EK60004',
                      'EK60005',
                      'EK60006',
                      'EK70001',
                      'EK70002',
                      'EK70003',
                      'EK70004',
                      'EK70005',
                      'EK70006',
                      'EK70007',
                      'EK70008',
                      'EK70009',
                      'EK70010',
                      'EK70011',
                      'EK70012',
                      'EK70013',
                      'EK80001',
                      'EK80002',
                      'EK80003',
                      'EK80004',
                      'EK80005',
                      'EK80006',
                      'EK80007',
                      'EK90001',
                      'EK90002',
                      'EK90003',
                      'EK90004',
                      'EK90005',
                      'EK90006',
                      'EK90007',
                      'EK90008',
                      'EK90009',
                      'EK90011',
                      'EK90012')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00001', 'Empresa contraparte da parcela do valor eliminado total obrigat�ria.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00002', 'Empresa contraparte da parcela do valor eliminado total inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00003', 'Empresa contraparte da parcela do valor eliminado total n�o relacionanda a rotina de Empresas Consolidadas.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00004', 'Empresa contraparte da parcela do valor eliminado total deve ser diferente da empresa detentora da parcela do valor eliminado.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00005', 'Conta cont�bil da empresa contraparte obrigat�ria.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00006', 'Conta cont�bil da empresa contraparte inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00007', 'Conta cont�bil da empresa contraparte deve ser diferente da conta da empresa detentora da parcela do valor eliminado.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00008', 'Valor eliminado obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00009', 'Informa��o D/C obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00010', 'Informa��o D/C inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00013', 'Conta cont�bil da empresa contraparte deve existir em Saldos das Contas Consolidadas.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK00014', 'Informa��es das empresas contrapartes das parcelas do valor eliminado total s�o de preenchimento obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK10001', 'Informa��o Modelo de escritura��o Obrigat�rio')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK10002', 'Informa��o Modelo de escritura��o Inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK10003', 'Empresa relacionada ao modelo de escritura��o informado n�o � consolidadora.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK10004', 'Empresa relacionada ao modelo de escritura��o n�o est� parametrizada como conglomerado econ�mico nos Par�metros do Sistema.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK10005', 'Empresa declarante do arquivo deve estar relacionada na lista de empresas consolidadas.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20001', 'Informa��o percentual de participa��o obrigat�rio')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20002', 'Informa��o percentual consolida��o obrigat�rio')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20003', 'Informa��o data inicial obrigat�rio')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20004', 'Informa��o data final obrigat�rio')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20005', 'Percentual de participa��o dever� ser maior que 0.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20006', 'Percentual de participa��o dever� ser menor igual a 100.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20007', 'Percentual de consolida��o dever� ser maior que 0.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20008', 'Percentual de consolida��o dever� ser menor igual a 100.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20009', 'Data inicial dever� estar dentro do per�odo do modelo de escritura��o informado.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20010', 'Data final dever� estar dentro do per�odo do modelo de escritura��o informado.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20011', 'Data final dever� ser maior que a data inicial.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20012', 'C�digo Identificador obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK20013', 'Duplicidade de C�digo Identificador informada.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK30001', 'Informa��o Modelo de escritura��o Obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK30002', 'Informa��o Modelo de escritura��o Inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK30003', 'Empresa relacionada ao modelo de escritura��o informado n�o � consolidadora.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK30004', 'Empresa relacionada ao modelo de escritura��o n�o est� parametrizada como coglomerado econ�mico nos Par�metros do Sistema.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK40001', 'Informa��o D/C Obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK40002', 'Informa��o D/C Inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK40003', 'Informa��o Valor eliminado Obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK50001', 'Informa��o Modelo de Escritura��o Obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK50002', 'Informa��o Modelo de escritura��o Inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK50003', 'Empresa relacionada ao modelo de escritura��o informado n�o � consolidadora.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK50004', 'Empresa relacionada ao modelo de escritura��o n�o est� parametrizada como conglomerado econ�mico nos Par�metros do Sistema.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK50005', 'Informa��o Empresa Consolidada Obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK50006', 'Informa��o Empresa Consolidada inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK50007', 'Empresa Consolidada n�o relacionanda a rotina de Empresas Consolidadas.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK50008', 'Empresa Consolidada n�o possui situa��o de evento societ�rio na rotina de Empresas Consolidadas.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK60001', 'Informa��o Evento societ�rio Obrigat�rio')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK60002', 'Informa��o Evento societ�rio Inexistente')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK60003', 'Informa��o Data do evento Obrigat�rio')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK60004', 'Data do evento dever� estar dentro do per�odo do modelo de escritura��o informado.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK60005', 'Existe duplicidade na lista de Eventos societ�rios.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK60006', 'Informa��es de eventos societ�rios s�o de preenchimento obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70001', 'Empresa participante do evento societ�rio obrigat�ria.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70002', 'Empresa participante do evento societ�rio inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70003', 'Empresa participante do evento societ�rio n�o relacionanda a rotina de Empresas Consolidadas.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70004', 'Empresa participante do evento societ�rio deve ser diferente da informada no campo empresa consolidada.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70005', 'Condi��o da empresa relacionada ao evento societ�rio obrigat�ria.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70006', 'Condi��o da empresa relacionada ao evento societ�rio inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70007', 'Percetual da empresa envolvida na opera��o obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70008', 'Percetual da empresa envolvida na opera��o obrigat�rio dever� ser menor ou igual a 100%.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70009', 'Condi��o da empresa relacionada ao evento societ�rio incompat�vel com o evento societ�rio informado.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70010', 'Existe duplicidade na lista de empresas participantes do evento societ�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70011', 'A soma dos percentuais das empresas envolvidas no evento societ�rio dever� ser menor ou igual a 100%.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70012', 'N�o devem ser informadas empresas participantes do evento societ�rio quando o evento for igual a 7 - Extin��o ou 8 - Constitui��o.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK70013', 'Informa��es das empresas participantes do evento societ�rio s�o de preenchimento obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK80001', 'Informa��o Modelo de escritura��o Obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK80002', 'Informa��o Modelo de escritura��o Inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK80003', 'Empresa relacionada ao modelo de escritura��o informado n�o � consolidadora.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK80004', 'Empresa relacionada ao modelo de escritura��o n�o est� parametrizada como conglomerado econ�mico nos Par�metros do Sistema.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK80005', 'Informa��o Conta cont�bil Obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK80006', 'Informa��o Conta cont�bil Inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK80007', 'Conta cont�bil n�o possui detalhamento de valor eliminado na rotina de Saldos das Contas Consolidadas.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK90001', 'Empresa detentora da parcela do valor eliminado obrigat�ria.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK90002', 'Empresa detentora da parcela do valor eliminado inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK90003', 'Empresa detentora da parcela do valor eliminado n�o relacionanda a rotina de Empresas Consolidadas.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK90004', 'Informa��o Valor eliminado obrigat�rio')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK90005', 'Informa��o D/C obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK90006', 'Informa��o D/C inexistente.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK90007', 'Existe duplicidade na lista de Empresas detentoras das parcelas do valor eliminado.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK90008', 'O somat�rio das parcelas do valor eliminado deve coincidir com o valor eliminado total.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK90009', 'Informa��es das empresas detentoras das parcelas do valor eliminado s�o de preenchimento obrigat�rio.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK90011', 'Existe duplicidade na lista de Empresas contrapartes das parcelas do valor eliminado total.')
/

insert into erromsg_erm (ERM_CDERRO, ERM_DSERRO)
values ('EK90012', 'O somat�rio das parcelas da contrapartida do valor eliminado deve coincidir com o valor da parcela do valor eliminado, com o indicador de situa��o invertido.')
/

CREATE INDEX IN1_ECDDETRELEMPCONS_EK2   ON ECDDETRELEMPCONS_EK2   (EK2_NREK1)
/

CREATE INDEX IN1_ECDDETSLDCTBCONS_EK4   ON ECDDETSLDCTBCONS_EK4   (EK4_NREK3)
/

CREATE INDEX IN1_ECDDETEVENTSOC_EK6     ON ECDDETEVENTSOC_EK6     (EK6_NREK5)
/

CREATE INDEX IN1_ECDEMPPARTEVENTSOC_EK7 ON ECDEMPPARTEVENTSOC_EK7 (EK7_NREK6)
/

CREATE INDEX IN1_ECDDETLANCVLELI_EK9    ON ECDDETLANCVLELI_EK9    (EK9_NREK8)
/

CREATE INDEX IN1_ECDEMPCONTRAVLELI_EK0  ON ECDEMPCONTRAVLELI_EK0  (EK0_NREK9)
/

CREATE INDEX IN1_ECDREGISTROK110_RK3    ON ECDREGISTROK110_RK3    (RK3_NRRK2)
/

CREATE INDEX IN1_ECDREGISTROK115_RK4    ON ECDREGISTROK115_RK4    (RK4_NRRK3)
/

CREATE INDEX IN1_ECDREGISTROK210_RK6    ON ECDREGISTROK210_RK6    (RK6_NRRK5)
/

CREATE INDEX IN1_ECDREGISTROK310_RK8    ON ECDREGISTROK310_RK8    (RK8_NRRK7)
/

CREATE INDEX IN1_ECDREGISTROK315_RK9    ON ECDREGISTROK315_RK9    (RK9_NRRK8)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 278867
PROMPT ======================================================================