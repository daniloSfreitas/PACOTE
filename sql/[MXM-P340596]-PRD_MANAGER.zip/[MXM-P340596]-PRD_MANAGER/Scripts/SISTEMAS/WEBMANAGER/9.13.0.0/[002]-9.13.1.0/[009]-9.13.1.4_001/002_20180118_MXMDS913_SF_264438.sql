PROMPT ======================================================================
PROMPT == DEMANDA......: 264438
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: Eduardo Lopes de Oliveira
PROMPT == DATA.........: 18/01/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES('FFP0017','Somat�rio do total das formas de pagamento diferente do total da NF')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 264438
PROMPT ======================================================================