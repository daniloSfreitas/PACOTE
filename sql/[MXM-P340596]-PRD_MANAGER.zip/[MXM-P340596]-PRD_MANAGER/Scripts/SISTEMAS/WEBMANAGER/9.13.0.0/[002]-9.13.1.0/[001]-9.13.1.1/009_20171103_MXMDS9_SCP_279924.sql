PROMPT ======================================================================
PROMPT == DEMANDA......: 279924
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: MARCOS FELIPE DE CARVALHO FIGUEIRED
PROMPT == DATA.........: 31/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE ITMODRATCCFIN_IMRCCF
ADD (IMRCCF_CDPROJETO VARCHAR2(20))
/

COMMENT ON COLUMN ITMODRATCCFIN_IMRCCF.IMRCCF_CDPROJETO IS 'C�digo do projeto'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279924
PROMPT ======================================================================