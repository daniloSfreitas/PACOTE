PROMPT ======================================================================
PROMPT == DEMANDA......: 282276
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: Sistema MANTIS - PAT 263852
PROMPT == DATA.........: 24/11/2017
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM MXRPT_SISTEMARELATORIO_MSIR WHERE MSIR_CDSISTEMA = 'SCP' AND MSIR_CDRELATORIO = 'MXM3717'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282276
PROMPT ======================================================================