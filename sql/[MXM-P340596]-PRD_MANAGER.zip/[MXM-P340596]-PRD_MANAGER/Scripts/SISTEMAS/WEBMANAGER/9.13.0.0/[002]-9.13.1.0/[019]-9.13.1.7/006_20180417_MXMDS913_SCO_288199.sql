PROMPT ======================================================================
PROMPT == DEMANDA......: 288199
PROMPT == SISTEMA......: Compras
PROMPT == RESPONSAVEL..: TAINA DE OLIVEIRA EVANGELISTA
PROMPT == DATA.........: 06/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

DECLARE
PRAGMA AUTONOMOUS_TRANSACTION;
CURSOR C_RESTRICOES IS
               SELECT CONSTRAINT_NAME         FROM
                 USER_CONSTRAINTS             WHERE
                 TABLE_NAME = 'USUEQUIV_UEQ'
                 AND CONSTRAINT_TYPE = 'P'  ORDER BY
                 CONSTRAINT_NAME;
RESTRICAO     VARCHAR2(30);
COMANDO      VARCHAR2(200);
BEGIN
    OPEN  C_RESTRICOES;
    FETCH C_RESTRICOES INTO  RESTRICAO;
    WHILE C_RESTRICOES%FOUND LOOP
        COMANDO := 'ALTER TABLE USUEQUIV_UEQ DROP CONSTRAINT ' || RESTRICAO;
        DBMS_OUTPUT.PUT_LINE (COMANDO);
        BEGIN
          EXECUTE IMMEDIATE COMANDO;
          DBMS_OUTPUT.PUT_LINE ('*');
          DBMS_OUTPUT.PUT_LINE ('A CONSTRANINT ' || RESTRICAO || ' FOI ELIMINADA.');
          DBMS_OUTPUT.PUT_LINE ('*');
          EXCEPTION WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE (SQLERRM);
        END;
        FETCH C_RESTRICOES INTO  RESTRICAO;
    END LOOP;
CLOSE  C_RESTRICOES;
END;
/

ALTER TABLE USUEQUIV_UEQ ADD (CONSTRAINT PK_USUEQUIV_UEQ  PRIMARY KEY (UEQ_CODIGO, UEQ_CODUSU, UEQ_CDSISTEMA))
 
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 288199
PROMPT ======================================================================