PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.6_002 gerados em 06/04/2018 
PROMPT ============================================================= 

@@001_20180406_MXMDS913_MXMRECRUIT_286063.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.6_002');

COMMIT;
