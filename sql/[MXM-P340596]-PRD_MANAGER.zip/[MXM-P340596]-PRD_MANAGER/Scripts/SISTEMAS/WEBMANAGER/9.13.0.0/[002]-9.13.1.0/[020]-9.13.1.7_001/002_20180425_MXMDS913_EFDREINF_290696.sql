PROMPT ======================================================================
PROMPT == DEMANDA......: 290696
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: KAROLLYNE MENDES DA SILVA
PROMPT == DATA.........: 25/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE VIEW VW_RNF2010
(tcp_cdempori, tcp_cdfilial, tcp_cdfor, for_codigo, for_nome, tcp_notitulo, tcp_dtentrada, rpc_nrfatcadobra, ief_cdstatus, ief_cdrecibo, ief_nrevento, for_cgc, rpc_nrserie, rpc_nrdocumento, tcp_dtemissao, rpc_vltitulo, tcp_obs, rpc_tpservico, rpc_cdatividade, rpi_dedm, rpi_dedt, rpi_deda, rpi_base, rpi_inss, rpi_sret, rpi_nret, rpi_baseadc2, rpi_adc2, rpi_baseadc3, rpi_adc3, rpi_baseadc4, rpi_adc4, rpi_adct, tcp_totinss, rpi_nretadc, rpi_nrprocref, trt_nrmoo, drf_perc, fco_cdobra)
AS
SELECT tcp.tcp_cdempori,
       tcp.tcp_cdfilial,
       tcp.tcp_cdfor,
       forn.for_codigo,
       forn.for_nome,
       tcp.tcp_notitulo,
       tcp.tcp_dtentrada,
       rpc.rpc_nrfatcadobra,
       CASE
         WHEN (ief.ief_cdstatus IS NULL AND trt.trt_idtrt IS NULL) THEN
          -1
         WHEN (ief.ief_cdstatus IS NULL) THEN
          0
         ELSE
          ief.ief_cdstatus
       END AS ief_cdstatus,
       ief.ief_cdrecibo,
       ief.ief_nrevento,
       forn.for_cgc,
       rpc.rpc_nrserie,
       rpc.rpc_nrdocumento,
       tcp.tcp_dtemissao,
       NVL(rpc.rpc_vltitulo, 0),
       tcp.tcp_obs,
       rts.rts_cdtpservico AS rpc_tpservico,
       cas.cas_cdatividade AS rpc_cdatividade,
       rpi.rpi_dedm,
       rpi.rpi_dedt,
       rpi.rpi_deda,
       rpi.rpi_base,
       rpi.rpi_vlimp as rpi_inss,
       NVL(rpi.rpi_sret, 0),
       NVL(rpi.rpi_nret, 0),
       NVL(rpi.rpi_baseadc2, 0),
       NVL(rpi.rpi_adc2, 0),
       NVL(rpi.rpi_baseadc3, 0),
       NVL(rpi.rpi_adc3, 0),
       NVL(rpi.rpi_baseadc4, 0),
       NVL(rpi.rpi_adc4, 0),
       (NVL(rpi.rpi_adc2, 0) + NVL(rpi.rpi_adc3, 0) + NVL(rpi.rpi_adc4, 0)) AS rpi_adct,
       tcp.tcp_inss AS tcp_totinss,
       0 AS rpi_nretadc,
       rpi.rpi_nrprocref,
       trt_nrmoo,
       drf_perc,
       fco.fco_cdobra
  FROM titcp_tcp tcp
  JOIN emp emp ON emp.emp_codigo = tcp.tcp_cdempori
  JOIN darf_drf drf ON drf.drf_codplconta = emp.emp_codplconta
                   AND drf.drf_codigo = tcp.tcp_cdinss
  JOIN fornec_for forn ON forn.for_codigo = tcp.tcp_cdfor
                      AND forn.for_cgc IS NOT NULL
                      AND forn.for_tipessoa = 'J'
  JOIN rnftcpcomp_rpc rpc ON rpc.rpc_cdfor = tcp.tcp_cdfor
                         AND rpc.rpc_notitulo = tcp.tcp_notitulo
                         AND rpc.rpc_tprepasse IS NULL
  JOIN rnfinttpservico_rts rts ON rts.rts_idrts = rpc.rpc_nrrts
  LEFT JOIN efdspedcodativscp_cas cas ON cas.cas_idatividade =
                                         rpc.rpc_nrcas
  LEFT JOIN (SELECT rpi_nrrpc,
                    SUM(rpi_vlimp) AS rpi_vlimp,
                    SUM(rpi_base) AS rpi_base,
                    SUM(rpi_dedm) AS rpi_dedm,
                    SUM(rpi_dedt) AS rpi_dedt,
                    SUM(rpi_deda) AS rpi_deda,
                    SUM(rpi_baseadc2) AS rpi_baseadc2,
                    SUM(rpi_adc2) AS rpi_adc2,
                    SUM(rpi_baseadc3) AS rpi_baseadc3,
                    SUM(rpi_adc3) AS rpi_adc3,
                    SUM(rpi_baseadc4) AS rpi_baseadc4,
                    SUM(rpi_adc4) AS rpi_adc4,
                    SUM(rpi_sret) AS rpi_sret,
                    SUM(rpi_nret) AS rpi_nret,
                    MAX(rpi_nrprocref) AS rpi_nrprocref
               FROM (SELECT rpi_nrrpc,
                            rta_tpitemcalc AS rpi_tpcompimp,
                            DECODE(rta_tpitemcalc, 'B', rpi_vlimp, NULL) rpi_vlimp,
                            DECODE(rta_tpitemcalc, 'B', rpi_vlbaseimp, NULL) rpi_base,
                            DECODE(rta_tpitemcalc, 'M', rpi_vlbaseimp, NULL) rpi_dedm,
                            DECODE(rta_tpitemcalc, 'T', rpi_vlbaseimp, NULL) rpi_dedt,
                            DECODE(rta_tpitemcalc, 'A', rpi_vlbaseimp, NULL) rpi_deda,
                            DECODE(rta_tpitemcalc, '2', rpi_vlbaseimp, NULL) rpi_baseadc2,
                            DECODE(rta_tpitemcalc, '2', rpi_vlimp, NULL) rpi_adc2,
                            DECODE(rta_tpitemcalc, '3', rpi_vlbaseimp, NULL) rpi_baseadc3,
                            DECODE(rta_tpitemcalc, '3', rpi_vlimp, NULL) rpi_adc3,
                            DECODE(rta_tpitemcalc, '4', rpi_vlbaseimp, NULL) rpi_baseadc4,
                            DECODE(rta_tpitemcalc, '4', rpi_vlimp, NULL) rpi_adc4,
                            DECODE(rta_tpitemcalc, 'S', rpi_vlimp, NULL) rpi_sret,
                            DECODE(rta_tpitemcalc, 'N', rpi_vlimp, NULL) rpi_nret,
                            rpi_nrprocref
                       FROM rnftcpcompimp_rpi
                       JOIN rnfinttpcalcadic_rta ON rta_idrta = rpi_nrrta)
              GROUP BY rpi_nrrpc) rpi ON rpi.rpi_nrrpc = rpc.rpc_idrpc
  LEFT JOIN rnftitcpreinf_trt trt ON trt.trt_nrrpc = rpc.rpc_idrpc
  LEFT JOIN rnfinfenviosreinf_ief ief ON trt_nrief = ief.ief_idief
  LEFT JOIN fatcadobra_fco fco ON fco_idfatcadobra = rpc_nrfatcadobra
 WHERE tcp_cdinss IS NOT NULL
/

CREATE OR REPLACE VIEW VW_RNF2020
(tcr_cdempori, tcr_cdfilial, tcr_cdcliente, cli_codigo, cli_nome, tcr_notitulo, rrc_nrfatcadobra, ief_cdstatus, ief_cdrecibo, ief_nrevento, cli_cgc, rrc_nrserie, rrc_nrdocumento, tcr_dtemissao, rrc_vltitulo, tcr_obs, rrc_tpservico, rrc_cdatividade, rri_dedm, rri_dedt, rri_deda, rri_base, rri_inss, rri_sret, rri_nret, rri_baseadc2, rri_adc2, rri_baseadc3, rri_adc3, rri_baseadc4, rri_adc4, rri_adct, tcr_totinss, rri_nretadc, rri_nrprocref, tru_nrmoo, drf_perc, fco_cdobra)
AS
SELECT tcr.tcr_cdempori,
       tcr.tcr_cdfilial,
       tcr.tcr_cdcliente,
       cli.cli_codigo,
       cli.cli_nome,
       tcr.tcr_notitulo,
       rrc.rrc_nrfatcadobra,
       CASE
         WHEN (ief.ief_cdstatus IS NULL AND tru.tru_idtru IS NULL) THEN
          -1
         WHEN (ief.ief_cdstatus IS NULL) THEN
          0
         ELSE
          ief.ief_cdstatus
       END AS ief_cdstatus,
       ief.ief_cdrecibo,
       ief.ief_nrevento,
       cli.cli_cgc,
       rrc.rrc_nrserie,
       rrc.rrc_nrdocumento,
       tcr.tcr_dtemissao,
       NVL(rrc.rrc_vltitulo, 0),
       tcr.tcr_obs,
       rts.rts_cdtpservico AS rrc_tpservico,
       cas.cas_cdatividade AS rrc_cdatividade,
       rri.rri_dedm,
       rri.rri_dedt,
       rri.rri_deda,
       rri.rri_base,
       rri.rri_vlimp as rri_inss,
       NVL(rri.rri_sret, 0),
       NVL(rri.rri_nret, 0),
       NVL(rri.rri_baseadc2, 0),
       NVL(rri.rri_adc2, 0),
       NVL(rri.rri_baseadc3, 0),
       NVL(rri.rri_adc3, 0),
       NVL(rri.rri_baseadc4, 0),
       NVL(rri.rri_adc4, 0),
       (NVL(rri.rri_adc2, 0) + NVL(rri.rri_adc3, 0) + NVL(rri.rri_adc4, 0)) AS rri_adct,
       tcr.tcr_inss AS tcr_totinss,
       0 AS rri_nretadc,
       rri.rri_nrprocref,
       tru_nrmoo,
       drf_perc,
       fco.fco_cdobra
  FROM titcr_tcr tcr
  JOIN emp emp ON emp.emp_codigo = tcr.tcr_cdempori
  JOIN darf_drf drf ON drf.drf_codplconta = emp.emp_codplconta
                   AND drf.drf_codigo = tcr.tcr_cdinss
  JOIN cliente_cli cli ON cli.cli_codigo = tcr.tcr_cdcliente
                      AND cli.cli_cgc IS NOT NULL
  JOIN rnftcrcomp_rrc rrc ON rrc.rrc_cdcliente = tcr.tcr_cdcliente
                         AND rrc.rrc_notitulo = tcr.tcr_notitulo
                         AND rrc.rrc_tprepasse IS NULL
  JOIN rnfinttpservico_rts rts ON rts.rts_idrts = rrc.rrc_nrrts
  LEFT JOIN efdspedcodativscp_cas cas ON cas.cas_idatividade =
                                         rrc.rrc_nrcas
  LEFT JOIN (SELECT rri_nrrrc,
                    SUM(rri_vlimp) AS rri_vlimp,
                    SUM(rri_base) AS rri_base,
                    SUM(rri_dedm) AS rri_dedm,
                    SUM(rri_dedt) AS rri_dedt,
                    SUM(rri_deda) AS rri_deda,
                    SUM(rri_baseadc2) AS rri_baseadc2,
                    SUM(rri_adc2) AS rri_adc2,
                    SUM(rri_baseadc3) AS rri_baseadc3,
                    SUM(rri_adc3) AS rri_adc3,
                    SUM(rri_baseadc4) AS rri_baseadc4,
                    SUM(rri_adc4) AS rri_adc4,
                    SUM(rri_sret) AS rri_sret,
                    SUM(rri_nret) AS rri_nret,
                    MAX(rri_nrprocref) AS rri_nrprocref
               FROM (SELECT rri_nrrrc,
                            rta_tpitemcalc AS rri_tpcompimp,
                            DECODE(rta_tpitemcalc, 'B', rri_vlimp, NULL) rri_vlimp,
                            DECODE(rta_tpitemcalc, 'B', rri_vlbaseimp, NULL) rri_base,
                            DECODE(rta_tpitemcalc, 'M', rri_vlbaseimp, NULL) rri_dedm,
                            DECODE(rta_tpitemcalc, 'T', rri_vlbaseimp, NULL) rri_dedt,
                            DECODE(rta_tpitemcalc, 'A', rri_vlbaseimp, NULL) rri_deda,
                            DECODE(rta_tpitemcalc, '2', rri_vlbaseimp, NULL) rri_baseadc2,
                            DECODE(rta_tpitemcalc, '2', rri_vlimp, NULL) rri_adc2,
                            DECODE(rta_tpitemcalc, '3', rri_vlbaseimp, NULL) rri_baseadc3,
                            DECODE(rta_tpitemcalc, '3', rri_vlimp, NULL) rri_adc3,
                            DECODE(rta_tpitemcalc, '4', rri_vlbaseimp, NULL) rri_baseadc4,
                            DECODE(rta_tpitemcalc, '4', rri_vlimp, NULL) rri_adc4,
                            DECODE(rta_tpitemcalc, 'S', rri_vlimp, NULL) rri_sret,
                            DECODE(rta_tpitemcalc, 'N', rri_vlimp, NULL) rri_nret,
                            rri_nrprocref
                       FROM rnftcrcompimp_rri
                       JOIN rnfinttpcalcadic_rta ON rta_idrta = rri_nrrta)
              GROUP BY rri_nrrrc) rri ON rri.rri_nrrrc = rrc.rrc_idrrc
  LEFT JOIN rnftitcrreinf_tru tru ON tru.tru_nrrrc = rrc.rrc_idrrc
  LEFT JOIN rnfinfenviosreinf_ief ief ON tru.tru_nrief = ief.ief_idief
  LEFT JOIN fatcadobra_fco fco ON fco_idfatcadobra = rrc.rrc_nrfatcadobra
 WHERE tcr_cdinss IS NOT NULL
/

DELETE FROM PARAMS_PAR WHERE PAR_CDPARAM = 'PAREFDREINF_URLRECEPCAOEVENTOSHOMOLOGACAO'
/

INSERT INTO PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO,PAR_DTCADASTRADO)
VALUES ('PAREFDREINF_URLRECEPCAOEVENTOSHOMOLOGACAO', 'https://preprodefdreinf.receita.fazenda.gov.br/WsREINF/RecepcaoLoteReinf.svc', GET_USER_MXM, SYSDATE)
/

DELETE FROM PARAMS_PAR WHERE PAR_CDPARAM = 'PAREFDREINF_URLCONSULTAINFORMACOESCONSOLIDHOMOLOGACAO'
/

INSERT INTO PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO,PAR_DTCADASTRADO)
VALUES ('PAREFDREINF_URLCONSULTAINFORMACOESCONSOLIDHOMOLOGACAO', 'https://preprodefdreinf.receita.fazenda.gov.br/WsREINF/ConsultasReinf.svc', GET_USER_MXM, SYSDATE)
/

UPDATE RNFINTVERSAOEVENTO_VRR SET VRR_DSVERSAO = 'v1_03_02', VRR_DSVERSAONUMERO = '1.03.00'
WHERE VRR_DSVERSAO = 'v1_03_00'
AND VRR_DSVERSAONUMERO = '1.03.00'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 290696
PROMPT ======================================================================