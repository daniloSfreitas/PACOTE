PROMPT ============================================================= 
PROMPT Chamador dos scripts da vers�o 9.13.1.7_001 gerados em 25/04/2018 
PROMPT ============================================================= 

@@001_20180425_MXMDS913_EFDREINF_290689.sql
@@002_20180425_MXMDS913_EFDREINF_290696.sql
@@003_20180503_MXMDS913_SPED_Ajuste.sql

INSERT INTO VERSAO_VER
VALUES(SYSDATE,'9.13.1.7_001');

COMMIT;
