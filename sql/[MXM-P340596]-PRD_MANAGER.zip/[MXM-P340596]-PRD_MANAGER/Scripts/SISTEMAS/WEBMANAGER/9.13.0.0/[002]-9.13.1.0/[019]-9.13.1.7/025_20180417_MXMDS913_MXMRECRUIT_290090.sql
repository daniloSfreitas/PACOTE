PROMPT ======================================================================
PROMPT == DEMANDA......: 290090
PROMPT == SISTEMA......: MXM-RECRUITMENT
PROMPT == RESPONSAVEL..: PALOMA CASSIA CAMPELO DE OLIVEIRA
PROMPT == DATA.........: 17/04/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE RECPERGUNTA_PER
ADD (PER_VBPERGUNTAINATIVA NUMBER(1))
/

UPDATE RECCANDIDATO_CAN
SET CAN_VBPORTADORDEFICIENCIA = '0'
WHERE CAN_VBPORTADORDEFICIENCIA IS NULL
/

INSERT INTO GRETABDICDADOS_TDR
(TDR_IDTABELA, TDR_NMTABELA, TDR_DSTABELA, TDR_NRFORCARJOIN)
VALUES ((SELECT MAX(TDR_IDTABELA)+1 FROM GRETABDICDADOS_TDR),
'CNTUSUARIO_USU',
'Usu�rio',
0)
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'CNTUSUARIO_USU'),
'CNTUSUARIO_USU.USU_NMNOME',
'Nome',
0,
'Nome')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
(SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'CNTUSUARIO_USU'),
'CNTUSUARIO_USU.USU_DSEMAILSECUNDARIO',
'Email secund�rio',
0,
'Email secund�rio')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'DECODE(CNTUSUARIO_USU.USU_IDUSUARIO, NULL, NULL, CNTUSUARIO_USU.USU_IDUSUARIO || '' - '' || CNTUSUARIO_USU.USU_NMNOME)',
'C�digo + Nome',
0,
'C�digo + Nome')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'CNTUSUARIO_USU.USU_DSEMAIL',
'Email',
0,
'Email')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'CNTUSUARIO_USU.USU_DTINCLUSAO',
'Cadastramento',
1,
'Cadastramento')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'CNTUSUARIO_USU.USU_MNAPELIDO',
'Apelido',
0,
'Apelido')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'CNTUSUARIO_USU.USU_DTALTERACAO',
'Altera��o',
1,
'Altera��o')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'((SELECT USUARIO.USU_NMNOME FROM CNTUSUARIO_USU USUARIO WHERE USUARIO.USU_IDUSUARIO = CNTUSUARIO_USU.USU_USINCLUSAO)
)',
'Criado por',
0,
'Criado por')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'(SELECT USUARIO.USU_NMNOME FROM CNTUSUARIO_USU USUARIO WHERE USUARIO.USU_IDUSUARIO = CNTUSUARIO_USU.USU_USALTERACAO)',
'Alterado por',
0,
'Alterado por')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'DECODE(CNTUSUARIO_USU.USU_SGATIVO, ''S'', ''Sim'', ''N�o'')',
'Usu�rio ativo',
2,
'Usu�rio ativo')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'DECODE(CNTUSUARIO_USU.USU_SGATIVADOEMAIL, ''S'', ''Sim'', ''N�o'')',
'Email ativado',
2,
'Email ativado')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'DECODE(USU_CDIDIOMA, ''PTB'', ''Portugu�s'', ''USA'', ''Ingl�s'', ''Espanhol'')',
'Idioma',
0,
'Idioma')
/

INSERT INTO GREVISAOTAB_VDR (VDR_IDVISAO,VDR_NRTABELA,VDR_CDSISTEMA,VRD_DSVISAO,VRD_NRFUNCAO)
VALUES
((SELECT MAX(VDR_IDVISAO) +1 FROM GREVISAOTAB_VDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'CNTADM',
'Usu�rio',
'110001')
/

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'(SELECT USU_NMNOME FROM CNTUSUARIO_USU WHERE USU_IDUSUARIO = CNTUSUARIO_USU.USU_USINCLUSAO)',
'Criado por',
0,
'Criado por')
/

INSERT INTO GRETABELARELVISAL_TRV
(TRV_IDTABELARELVISAO, TRV_NRVISAO, TRV_NRTABELA, TRV_NMLISTATABREL, TRV_NMCONDICAOTABREL)
VALUES (
(SELECT MAX(TRV_IDTABELARELVISAO) +1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
NULL,
NULL)
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'Nome',
			 0,
			 0,
             '',
			 '',
			 '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'CNTUSUARIO_USU'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'CNTUSUARIO_USU.USU_NMNOME', 'Nome'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'Usu�rio ativo',
			 1,
			 0,
             '',
			 '',
			 '',
            'DECODE(CNTUSUARIO_USU.USU_SGATIVO,  ''S'', ''S'', ''N'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'CNTUSUARIO_USU'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'CNTUSUARIO_USU.USU_USUARIOATIVO', 'Usu�rio ativo'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'Usu�rio inativo',
			 1,
			 0,
             '',
			 '',
			 '',
             'DECODE(CNTUSUARIO_USU.USU_SGATIVO,  ''N'', ''S'', ''N'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'CNTUSUARIO_USU'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'CNTUSUARIO_USU.USU_USUARIOINATIVO', 'Usu�rio inativo'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'Cadastrado por',
			 0,
			 2,
             'CNTUSUARIO_USU',
			 '',
			 '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'CNTUSUARIO_USU'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'CNTUSUARIO_USU.USU_USINCLUSAO', 'Cadastrado por'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'Alterado por',
             0,
             2,
             'CNTUSUARIO_USU',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'CNTUSUARIO_USU'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'CNTUSUARIO_USU.USU_USALTERACAO', 'Alterado por'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'Email ativado',
             1,
             0,
             '',
             '',
             '',
            'DECODE(CNTUSUARIO_USU.USU_SGATIVADOEMAIL,  ''S'', ''S'', ''N'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'CNTUSUARIO_USU'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'CNTUSUARIO_USU.USU_SGATIVADOEMAIL', 'Email ativado'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'Email n�o ativado',
             1,
             0,
             '',
             '',
             '',
            'DECODE(CNTUSUARIO_USU.USU_SGATIVADOEMAIL,  ''N'', ''S'', ''N'')',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'CNTUSUARIO_USU'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'CNTUSUARIO_USU.USU_EMAILNAOATIVADO', 'Email n�o ativado'
            )
/

INSERT INTO GREVISAOTAB_VDR (VDR_IDVISAO,VDR_NRTABELA,VDR_CDSISTEMA,VRD_DSVISAO,VRD_NRFUNCAO)
VALUES
((SELECT MAX(VDR_IDVISAO) +1 FROM GREVISAOTAB_VDR),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='MXS_PERFILACESSO_MXPA'),
'CNTADM',
'Comunidade',
'110002')
/

INSERT INTO GRETABELARELVISAL_TRV
(TRV_IDTABELARELVISAO, TRV_NRVISAO, TRV_NRTABELA, TRV_NMLISTATABREL, TRV_NMCONDICAOTABREL)
VALUES (
(SELECT MAX(TRV_IDTABELARELVISAO) +1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='MXS_PERFILACESSO_MXPA')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='MXS_PERFILACESSO_MXPA'),
NULL,
NULL)
/

INSERT INTO GRETABELARELVISAL_TRV
(TRV_IDTABELARELVISAO, TRV_NRVISAO, TRV_NRTABELA, TRV_NMLISTATABREL, TRV_NMCONDICAOTABREL)
VALUES (
(SELECT MAX(TRV_IDTABELARELVISAO) +1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='MXS_PERFILACESSO_MXPA')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CNTUSUARIO_USU'),
'CNTCOMUNIDADEUSUARIO_RCU',
'CNTCOMUNIDADEUSUARIO_RCU.RCU_CDUSUARIO(+) = CNTUSUARIO_USU.USU_IDUSUARIO AND
CNTCOMUNIDADEUSUARIO_RCU.RCU_CDCOMUNIDADE = MXS_PERFILACESSO_MXPA.MXPA_PERFILACESSO(+)')
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'MXS_PERFILACESSO_MXPA')),
             'Cadastrado por',
             0,
             2,
             'CNTUSUARIO_USU',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'MXS_PERFILACESSO_MXPA'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'MXS_PERFILACESSO_MXPA')),
             'MXS_PERFILACESSO_MXPA.MXPA_CRIADOPOR', 'Cadastrado por'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'MXS_PERFILACESSO_MXPA')),
             'Alterado por',
             0,
             2,
             'CNTUSUARIO_USU',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'MXS_PERFILACESSO_MXPA'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'MXS_PERFILACESSO_MXPA')),
             'MXS_PERFILACESSO_MXPA.MXPA_ALTERADOPOR', 'Alterado por'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'MXS_PERFILACESSO_MXPA')),
             'Nome',
             0,
             0,
             '',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'MXS_PERFILACESSO_MXPA'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'MXS_PERFILACESSO_MXPA')),
             'MXS_PERFILACESSO_MXPA.MXPA_DESCRICAO', 'Nome'
            )
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'MXS_PERFILACESSO_MXPA')),
             'Usu�rio',
             0,
             2,
             'CNTUSUARIO_USU',
             '',
             '',
             null,
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'MXS_PERFILACESSO_MXPA'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'CNTUSUARIO_USU')),
             'CNTUSUARIO_USU.USU_IDUSUARIO', 'Usu�rio'
            )
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 290090
PROMPT ======================================================================