PROMPT ======================================================================
PROMPT == DEMANDA......: 280383
PROMPT == SISTEMA......: Contratos de Vendas
PROMPT == RESPONSAVEL..: RODRIGO DA PAZ DO NASCIMENTO
PROMPT == DATA.........: 08/01/2018
PROMPT == BASE.........: MXMDS913
PROMPT == OWNER DESTINO: MXMDS913
PROMPT ======================================================================

SET DEFINE OFF;

alter table TPCONTRATO_TPC add TPC_CDSISTEMA VARCHAR2(5)
/

comment on column TPCONTRATO_TPC.TPC_CDSISTEMA
  is 'C�digo do sistema'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280383
PROMPT ======================================================================