PROMPT ======================================================================
PROMPT == DEMANDA......: 283053
PROMPT == SISTEMA......: MXM-RECRUITMENT
PROMPT == RESPONSAVEL..: PALOMA CASSIA CAMPELO DE OLIVEIRA
PROMPT == DATA.........: 18/12/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'Sexo',
             0,
             0,
             '',
             '',
             '',
             '',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
             'RECCANDIDATO_CAN.CAN_CDSEXO', 'Sexo (F/M)'
            )
/

ALTER TABLE RECPROCRECRUTAMENTO_PRC
ADD (PRC_STATUSCONTRATACAO2 VARCHAR2(1))
/

UPDATE RECPROCRECRUTAMENTO_PRC
SET PRC_STATUSCONTRATACAO2 = 'A'
WHERE PRC_STATUSCONTRATACAO = '0'
/

UPDATE RECPROCRECRUTAMENTO_PRC
SET PRC_STATUSCONTRATACAO2 = 'C'
WHERE PRC_STATUSCONTRATACAO = '1'
/

UPDATE RECPROCRECRUTAMENTO_PRC
SET PRC_STATUSCONTRATACAO2 = 'S'
WHERE PRC_STATUSCONTRATACAO = '2'
/

ALTER TABLE RECPROCRECRUTAMENTO_PRC
DROP COLUMN PRC_STATUSCONTRATACAO
/

ALTER TABLE RECPROCRECRUTAMENTO_PRC
RENAME COLUMN PRC_STATUSCONTRATACAO2 TO PRC_STATUSCONTRATACAO
/

INSERT INTO grefiltrocampotab_fct
            (fct_idfiltrocampo,
             fct_nrvisao,
             fct_dsfiltro, fct_tpfiltro, fct_tpcampofiltro,
             fct_nmarquivoajuda, fct_nmlistatabela, fct_nmlistacondicaoajuda,
             fct_nmcondcampochb,
             fct_tabelarelvisao,
             fct_nmcampo, fct_dsfiltrocabecalho
            )
     VALUES ((SELECT MAX (fct_idfiltrocampo) + 1
                FROM grefiltrocampotab_fct),
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'Status do processo',
             0,
             0,
             '',
             '',
             '',
             '',
             (SELECT trv_idtabelarelvisao
                FROM gretabelarelvisal_trv
               WHERE trv_nrvisao =
                        (SELECT vdr_idvisao
                           FROM grevisaotab_vdr
                          WHERE vdr_nrtabela =
                                           (SELECT tdr_idtabela
                                              FROM gretabdicdados_tdr
                                             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
                 AND trv_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC')),
             'RECPROC.PRC_STATUSCONTRATACAO', 'Status do Processo ( A - Aberto / C - Com Contrata��o / S - Sem Contrata��o )'
            )
/

UPDATE grefiltrocampotab_fct
               SET FCT_NMCONDCAMPOCHB = 'DECODE(PRC_STATUSCONTRATACAO,  ''C'', ''S'', ''N'')',
                     FCT_NMCAMPO = 'RECPROC.PRC_STATUSCONTRATACAO1'            
 WHERE FCT_NMCAMPO = 'RECPROC.PRC_STATUSCONTRATACAO'
               AND FCT_TPFILTRO = '1'
               AND FCT_NRVISAO =(SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                       FROM gretabdicdados_tdr
                                      WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC RECPROC'))
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPOTABELA = 'DECODE(RECPROC.PRC_STATUSCONTRATACAO, ''A'', ''Aberto'', ''C'', ''Finalizado com contrata��es'', ''Finalizado sem contrata��es'')',
CDR_DSCAMPOTABELACABECALHO = 'Status do processo',
CDR_DSCAMPO = 'Status do processo'
WHERE CDR_DSCAMPOTABELA =  'DECODE(RECPROC.PRC_STATUSCONTRATACAO, 0, ''Em andamento'', 1, ''Finalizado com contrata��es'', ''Finalizado sem contrata��es'')'
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPOTABELA = 'DECODE(RECPROC.PRC_STATUSCONTRATACAO, ''C'', ''Sim'', ''N�o'')'
where CDR_DSCAMPOTABELA = 'DECODE(RECPROC.PRC_STATUSCONTRATACAO, 0, ''Sim'', ''N�o'')'
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPOTABELACABECALHO = 'C�digo entrevista',
CDR_DSCAMPO = 'C�digo'
WHERE CDR_DSCAMPOTABELA =  'RECENTREVISTA_ENT.ENT_IDENTREVISTA'
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPO = 'Nome',
CDR_DSCAMPOTABELACABECALHO = 'Nome do cargo'
where CDR_DSCAMPOTABELA = 'VW_RECCARGO_CAR.CAR_NMCARGO'
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPO = 'Nome',
CDR_DSCAMPOTABELACABECALHO = 'Nome entrevistador'
where CDR_DSCAMPOTABELA = 'USUARIOENTREVISTADOR.USU_NMNOME'
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPOTABELACABECALHO = 'C�d. entrevistador',
CDR_DSCAMPO = 'C�digo'
WHERE CDR_DSCAMPOTABELA =  'USUARIOENTREVISTADOR.USU_IDUSUARIO'
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPOTABELA = 'DECODE(RECPROCRECRUTAMENTO_PRC.PRC_STATUSCONTRATACAO, ''A'', ''Aberto'', ''C'', ''Finalizado com contrata��es'', ''Finalizado sem contrata��es'')',
CDR_DSCAMPOTABELACABECALHO = 'Status do processo',
CDR_DSCAMPO = 'Status do processo'
WHERE CDR_DSCAMPOTABELA =  'DECODE(RECPROCRECRUTAMENTO_PRC.PRC_STATUSCONTRATACAO, 0, ''Em andamento'', 1, ''Finalizado com contrata��es'', ''Finalizado sem contrata��es'')'
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPOTABELA = 'DECODE(RECPROCRECRUTAMENTO_PRC.PRC_STATUSCONTRATACAO, ''C'', ''Sim'', ''N�o'')'
WHERE CDR_DSCAMPOTABELA =  'DECODE(RECPROCRECRUTAMENTO_PRC.PRC_STATUSCONTRATACAO, 0, ''Sim'', ''N�o'')'
/

UPDATE GRECAMPOS_CDR
SET CDR_DSCAMPO = 'Nome',
CDR_DSCAMPOTABELACABECALHO = 'Nome do candidato'
where CDR_DSCAMPOTABELA = 'RECCANDIDATO_CAN.CAN_NMCANDIDATO'
/

ALTER TABLE RECCANDIDATO_CAN
MODIFY (CAN_DSCEP VARCHAR2(20))
/

ALTER TABLE RECCANDIDATO_CAN
MODIFY (CAN_TXIDENTIFICACAO VARCHAR2(40))
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283053
PROMPT ======================================================================