PROMPT ======================================================================
PROMPT == DEMANDA......: 281527
PROMPT == SISTEMA......: Estoque
PROMPT == RESPONSAVEL..: RODRIGO DA PAZ DO NASCIMENTO
PROMPT == DATA.........: 17/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_PERIODOCONTABILBLOQUEADO(
  pEMPRESA IN CHAR,
  pDATA    IN DATE)
RETURN BOOLEAN IS
  VCOUNT NUMBER;
  CURSOR CS_PERIODOLIBERADO IS
    SELECT COUNT(1)
      FROM LIBERACAO_LIB
     WHERE LIB_CDEMPRESA = pEMPRESA
       AND TO_DATE(LIB_DATA, 'DD/MM/RR') = TO_DATE(pDATA, 'DD/MM/RR')
       AND LIB_CDSISTEMA = 'SCB';
  CURSOR CS_PERIODOLIBERADOPORPERFIL IS
    SELECT COUNT(1)
      FROM LIBPERGRUPO_LPG
     WHERE LPG_EMPRESA = pEMPRESA
       AND EXISTS (SELECT NULL
                     FROM MXS_PERFILUSUARIO_MXPU
                    WHERE MXPU_USUARIO      = GET_USER_MXM
                      AND MXPU_PERFILACESSO = LPG_PERFILACESSO )
       AND TO_DATE(LPG_DATA, 'DD/MM/RR') = TO_DATE(pDATA,'DD/MM/RR')
       AND LPG_CDSISTEMA = 'SCB'
       AND LPG_GRPTRB    = -1;
BEGIN
  OPEN CS_PERIODOLIBERADO;
  FETCH CS_PERIODOLIBERADO INTO VCOUNT;
  CLOSE CS_PERIODOLIBERADO;
  IF (VCOUNT = 0) THEN
    OPEN CS_PERIODOLIBERADOPORPERFIL;
    FETCH CS_PERIODOLIBERADOPORPERFIL INTO VCOUNT;
    CLOSE CS_PERIODOLIBERADOPORPERFIL;
    RETURN(VCOUNT = 0);
  ELSE
    RETURN(VCOUNT = 0);
  END IF;
END;
/

CREATE OR REPLACE PROCEDURE GERA_MOVIMENTO_CONTABIL
(
  pEMPRESA      IN CHAR,
  pESTOQUE      IN CHAR,
  pDATA         IN DATE,
  PINDDOCUMENTO IN CHAR,
  pINDGRPPRD    IN CHAR,
  pAGRUPA       IN CHAR DEFAULT NULL
) AS
  ---
  vULTCONTAB    DATE;
  vTIPO         CHAR(1);
  vDOCUMENTO    MOVIMENTO_MOV.MOV_DOCUMENTO%TYPE;
  --vOBSMOV       MOVIMENTO_MOV.MOV_OBS%TYPE;
  vULTDOCUMENTO MOVIMENTO_MOV.MOV_DOCUMENTO%TYPE;
  vSEQLANCCTB   NUMBER(6);
  vLANCCTB      VARCHAR2(6);
  vSEQUENCIA    NUMBER(6);
  vCONTAB1      LANCCTB_LCT.LCT_NOCONTAB%TYPE;
  vCONTAB2      LANCCTB_LCT.LCT_NOCONTAB%TYPE;
  vNOCCUSTO1    LANCCTB_LCT.LCT_NOCCUSTO%TYPE;
  vNOCCUSTO2    LANCCTB_LCT.LCT_NOCCUSTO%TYPE;
  vDC           LANCCTB_LCT.LCT_DC%TYPE;
  vHISTORICO    LANCCTB_LCT.LCT_HISTORICO%TYPE;
  vVALORCTB     LANCCTB_LCT.LCT_VALOR%TYPE;
  vVALORCTBM    LANCCTB_LCT.LCT_VALORM%TYPE;
  vSEGMOEDA     LANCCTB_LCT.LCT_TPLANC%TYPE;
  vCODPLANO     LANCCTB_LCT.LCT_PLCONTAB%TYPE;
  vCONTA        LANCCTB_LCT.LCT_NOCONTAB%TYPE;
  vCCUSTO       CHAR(1);
  --Thiago
  vSEQANT NUMBER(6);
  ---
  vERROR                     BOOLEAN;
  vERRORMSG                  BOOLEAN;
  vEXISTE_PARAM_ULTIMA_DATA  BOOLEAN;
  vALMOX                     MOVIMENTO_MOV.MOV_ALMOXARIFADO%TYPE;
  vITEM                      MOVIMENTO_MOV.MOV_ITEM%TYPE;
  vSALDOQTD                  MOVIMENTO_MOV.MOV_QTD%TYPE;
  vSALDOVALOR                MOVIMENTO_MOV.MOV_VALOR%TYPE;
  vSALDOVALORM               MOVIMENTO_MOV.MOV_VALORM%TYPE;
  vMENSAGEMERRO              VARCHAR2(500);
  VCDPROJETO                 MOVIMENTO_MOV.MOV_CDPROJETO%TYPE;
  VBCustoNormalTransEmpresas PARAMS_PAR.PAR_VLPARAM%TYPE;
  vPERIODOBLOQUEADO          BOOLEAN;
  ---
  vCONTABCOMP NUMBER(1);
  ---
  SGECONT001 EXCEPTION;
  SGECONT002 EXCEPTION;
  SGECONT003 EXCEPTION;
  SGECONT004 EXCEPTION;
  SGECONT005 EXCEPTION;
  SGECONT006 EXCEPTION;
  SGECONT007 EXCEPTION;
  SGECONT008 EXCEPTION;
  SGECONT009 EXCEPTION;
  SGECONT010 EXCEPTION;
  SGECONT011 EXCEPTION;
  SGECONT015 EXCEPTION;
  CURSOR MOV IS
    SELECT RTRIM(TIPO),
           RTRIM(MOV_TIPO),
           RTRIM(CP),
           RTRIM(UP),
           RTRIM(CR),
           RTRIM(UR),
           RTRIM(HP),
           SUM(MOV_VALOR),
           SUM(MOV_VALORM),
           MOV_CDPROJETO
      FROM (SELECT DECODE(PINDDOCUMENTO,
                          'S',
                          A.MOV_DOCUMENTO,
                          NULL) AS TIPO,
                   A.MOV_TIPO,
                   Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                            A.MOV_TPESTOQUE,
                                            A.MOV_ITEM,
                                            A.MOV_OPERACAO,
                                            A.MOV_DOCUMENTO,
                                            A.MOV_OBS,
                                            A.MOV_DESTINACAO,
                                            'CP',
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            A.MOV_SQNOTA) AS CP,
                   --Se for Conta Patrimonial uso Centro de Custo do Parametro. Se for Resultado Posso Usar ccusto do Estoque
                   NVL(Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                                A.MOV_TPESTOQUE,
                                                A.MOV_ITEM,
                                                A.MOV_OPERACAO,
                                                A.MOV_DOCUMENTO,
                                                A.MOV_OBS,
                                                A.MOV_DESTINACAO,
                                                'UP',
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                A.MOV_SQNOTA),
                       A.MOV_NOCCUSTO) AS UP,
                   Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                            A.MOV_TPESTOQUE,
                                            A.MOV_ITEM,
                                            A.MOV_OPERACAO,
                                            A.MOV_DOCUMENTO,
                                            A.MOV_OBS,
                                            A.MOV_DESTINACAO,
                                            'CR',
                                            NULL,
                                            NULL,
                                            NULL,
                                            NULL,
                                            A.MOV_SQNOTA) AS CR,
           NVL(NVL(A.MOV_NOCCUSTO, Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                                A.MOV_TPESTOQUE,
                                                A.MOV_ITEM,
                                                A.MOV_OPERACAO,
                                                A.MOV_DOCUMENTO,
                                                A.MOV_OBS,
                                                A.MOV_DESTINACAO,
                                                'UR',
                                                NULL,
                                                NULL,
                                                NULL,
                                                NULL,
                                                            A.MOV_SQNOTA)),
                   B.MOV_NOCCUSTO) AS UR,
                   Nocontabparamestoque_Npe(A.MOV_CDEMPRESA,
                                            A.MOV_TPESTOQUE,
                                            A.MOV_ITEM,
                                            A.MOV_OPERACAO,
                                            A.MOV_DOCUMENTO,
                                            A.MOV_OBS,
                                            A.MOV_DESTINACAO,
                                            'HP',
                                            PINDDOCUMENTO,
                                            'S',
                                            pINDGRPPRD,
                                            pAGRUPA,
                                            A.MOV_SQNOTA) AS HP,
                   A.MOV_VALOR,
                   A.MOV_VALORM,
                   A.MOV_CDPROJETO
              FROM MOVIMENTO_MOV A,
                   MOVIMENTO_MOV B,
                   TPOPER_TPO,
                   NOTA_NT
             WHERE A.MOV_SQNOTARELTRANSF = B.MOV_SQNOTA(+)
               AND A.MOV_SEQUENCIA = B.MOV_SEQUENCIA(+)
               AND A.MOV_SQNOTA = NT_SQNOTA
               AND A.MOV_CDEMPRESA = pEMPRESA
               AND A.MOV_TPESTOQUE = pESTOQUE
               AND TPO_CODIGO = A.MOV_OPERACAO
               AND TPO_GECONT = 'S'
               AND ((TPO_DEVOLUCAO <> 'N' OR TPO_NOTAFISCAL <> 'S' OR
                   TPO_TIPO <> 'E') OR
                   (TPO_TIPO = 'E' AND TPO_ENTRADATRANSF = 'S' AND
                   NVL(VBCustoNormalTransEmpresas,
                         'N') = 'N') OR (NT_TPNOTA = 13))
               AND A.MOV_DTCONTABILIZADO IS NULL
               AND DECODE(A.MOV_TIPO,
                          'S',
                          DECODE(TPO_NOTAFISCAL,
                                 'S',
                                 DECODE(TPO_DEVOLUCAO,
                                        'S',
                                        'N',
                                        'S'),
                                 'S'),
                          'S') = 'S'
               AND A.MOV_DATA <= pDATA)
     GROUP BY TIPO,
              MOV_TIPO,
              CP,
              UP,
              CR,
              UR,
              HP,
              MOV_CDPROJETO;
  CURSOR CCUSTO IS
    SELECT PLC_CCUSTO
      FROM PLANOCTA_PLC
     WHERE PLC_CODPLANO = VCODPLANO
       AND PLC_NOCONTAB = VCONTA;
  CURSOR CUSTONORMALTRANSEMPRESAS IS
    SELECT PAR_VLPARAM
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = 'wSGE_CustoNormalTransEmpresas';
  FUNCTION EXISTE_PARAM_ULTIMA_DATA
  RETURN BOOLEAN
  AS
    VCOUNT NUMBER;
    CURSOR PARAM_ULTIMA_DATA IS
      SELECT COUNT(1)
        FROM PARAMS_PAR
       WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE;
  BEGIN
    OPEN PARAM_ULTIMA_DATA;
    FETCH PARAM_ULTIMA_DATA INTO VCOUNT;
    CLOSE PARAM_ULTIMA_DATA;
    RETURN(VCOUNT > 0);
  END;
  FUNCTION EXISTE_MENSAGEM_DE_ERRO
  RETURN BOOLEAN
  AS
    VCOUNT NUMBER;
    CURSOR ERROR_COUNT IS
      SELECT COUNT(1)
        FROM ERROPROCESSO_EPC;
  BEGIN
    OPEN ERROR_COUNT;
    FETCH ERROR_COUNT INTO VCOUNT;
    CLOSE ERROR_COUNT;
    RETURN(VCOUNT > 0);
  END;
BEGIN
  vPERIODOBLOQUEADO := GET_PERIODOCONTABILBLOQUEADO(pEMPRESA, pDATA);
  IF vPERIODOBLOQUEADO THEN
    vMENSAGEMERRO := 'Lan�amentos em per�odo cont�bil bloqueado. Data: ' || pDATA;
    RAISE SGECONT015;
  END IF;
  ---
  SELECT MIN(MOV_DTCONTABILIZADO)
    INTO vULTCONTAB
    FROM MOVIMENTO_MOV
   WHERE MOV_CDEMPRESA        = pEMPRESA
     AND MOV_TPESTOQUE        = pESTOQUE
     AND MOV_DTCONTABILIZADO IS NOT NULL
     AND MOV_DATA            <= pDATA;
  IF vULTCONTAB >= pDATA THEN
    -- Erro para periodo ja contabilizado -- A descricao consta na tabela de erros para ocodigo abaixo
    RAISE SGECONT001;
  END IF;
  ---
  OPEN CUSTONORMALTRANSEMPRESAS;
  FETCH CUSTONORMALTRANSEMPRESAS INTO VBCustoNormalTransEmpresas;
  CLOSE CUSTONORMALTRANSEMPRESAS;
  OPEN MOV;
  FETCH MOV INTO vDOCUMENTO, vTIPO, vCONTAB1, vNOCCUSTO1, vCONTAB2, vNOCCUSTO2, vHISTORICO, vVALORCTB, vVALORCTBM, VCDPROJETO;
  IF NOT MOV%FOUND THEN
    -- N�o h� movimento a contabilizar -- A descricao consta na tabela de erros para ocodigo abaixo
    RAISE SGECONT002;
  END IF;
  -- VERIFICA SE POSSUI ERRO
  vERROR := PKG_CALCULOCUSTOESTOQUE.EXISTS_ERROR_SALDO(pEMPRESA,
                                                       pESTOQUE,
                                                       NULL,
                                                       NULL);
  -- VERIFICA SE FORMAM INCLUIDAS MENSAGENS DE ERRO
  vERRORMSG := EXISTE_MENSAGEM_DE_ERRO;
  -- SE OUVER ERRO NAO FAZ A CONTABILIZACAO
  IF ((NOT vERROR) AND (NOT vERRORMSG)) THEN
    COMMIT;
    ---
    SELECT EST_SEGMOEDA
      INTO vSEGMOEDA
      FROM ESTOQUES_EST
     WHERE EST_CODIGO = pESTOQUE;
    ---
    vSEQLANCCTB   := 0;
    vULTDOCUMENTO := NULL;
    vLANCCTB      := pESTOQUE;
    vSEQUENCIA    := 0;
    WHILE MOV%FOUND LOOP
      vSEQANT := 0;
      ---
      IF RTRIM(vCONTAB1) IS NULL THEN
        RAISE SGECONT003;
      END IF;
      IF RTRIM(vCONTAB2) IS NULL THEN
        RAISE SGECONT004;
      END IF;
      ---
      IF vNOCCUSTO1 IS NULL THEN
        vNOCCUSTO1 := '               ';
      END IF;
      IF vNOCCUSTO2 IS NULL THEN
        vNOCCUSTO2 := '               ';
      END IF;
      ---
      IF vTIPO = 'S' THEN
        vDC := 'C';
      ELSE
        vDC := 'D';
      END IF;
      ---
      IF vVALORCTB <> 0 OR vVALORCTBM <> 0 OR RTRIM(vCONTAB1) <> RTRIM(vCONTAB2) THEN
        IF (pINDDOCUMENTO = 'S') AND (vULTDOCUMENTO IS NULL OR vULTDOCUMENTO <> vDOCUMENTO) THEN
          vULTDOCUMENTO := vDOCUMENTO;
          vSEQLANCCTB   := vSEQLANCCTB + 1;
          vSEQUENCIA    := 0;
          vLANCCTB      := pESTOQUE || Padr(vSEQLANCCTB, 4, '0');
        END IF;
        ---
        SELECT EMP_CODPLCONTA
          INTO vCODPLANO
          FROM EMP
         WHERE EMP_CODIGO = pEMPRESA;
        ---
        vCONTA := vCONTAB1;
        OPEN CCUSTO;
        FETCH CCUSTO INTO vCCUSTO;
        CLOSE CCUSTO;
        IF vCCUSTO = 'N' THEN
          vNOCCUSTO1 := '               ';
        END IF;
        IF vCCUSTO = 'O' AND TRIM(vNOCCUSTO1) = '' THEN
          RAISE SGECONT005;
        END IF;
        IF vCCUSTO = 'E' THEN
          BEGIN
            SELECT RCC_NOCCUSTO
              INTO vNOCCUSTO1
              FROM RELCTACC_RCC
             WHERE RCC_CDEMPRESA = pEMPRESA
               AND RCC_NOCONTAB  = vCONTAB1
               AND RCC_NOCCUSTO  = vNOCCUSTO1;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              RAISE SGECONT006;
          END;
        END IF;
        ---
        vSEQUENCIA := vSEQUENCIA + 1;
        ---
        SELECT DECODE(COUNT(PLC_NOCONTAB), 0, 0, 1)
          INTO vCONTABCOMP
          FROM PLANOCTA_PLC
         WHERE PLC_NOCONTAB = vCONTAB1
           AND PLC_SA       = 'A';
        IF vCONTABCOMP = 0 THEN
          -- Conta de estoque inexistente -- A descricao consta na tabela de erros para ocodigo abaixo
          RAISE SGECONT007;
        END IF;
        ---
        INSLANCCTB_LCT(pEMPRESA,
                       'SGE_CC',
                       pDATA,
                       vLANCCTB,
                       vSEQUENCIA,
                       vCONTAB1,
                       vNOCCUSTO1,
                       vHISTORICO,
                       vDC,
                       vVALORCTB,
                       vVALORCTBM,
                       '',
                       vSEGMOEDA,
                       null,
                       null,
                       VCDPROJETO);
        ---
        IF vTIPO = 'S' THEN
          vDC := 'D';
        ELSE
          vDC := 'C';
        END IF;
        ---
        vCONTA := vCONTAB2;
        OPEN CCUSTO;
        FETCH CCUSTO INTO vCCUSTO;
        CLOSE CCUSTO;
        IF vCCUSTO = 'N' THEN
          vNOCCUSTO2 := '               ';
        END IF;
        IF vCCUSTO = 'O' AND vNOCCUSTO2 = '               ' THEN
          RAISE SGECONT008;
        END IF;
        IF vCCUSTO = 'E' THEN
          BEGIN
            SELECT RCC_NOCCUSTO
              INTO vNOCCUSTO2
              FROM RELCTACC_RCC
             WHERE RCC_CDEMPRESA = pEMPRESA
               AND RCC_NOCONTAB  = vCONTAB2
               AND RCC_NOCCUSTO  = vNOCCUSTO2;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              RAISE SGECONT009;
          END;
        END IF;
        --
        IF pAGRUPA = 'S' THEN
          BEGIN
            SELECT MAX(LCT_SEQ)
              INTO vSEQANT
              FROM LANCCTB_LCT
             WHERE LCT_CDEMPRESA = pEMPRESA
               AND LCT_DATA      = pDATA
               AND LCT_LOTE      = 'SGE_CC'
               AND LCT_LANCCTB   = vLANCCTB
               AND LCT_NOCONTAB  = vCONTAB2
               AND LCT_DC        = vDC
               AND LCT_NOCCUSTO  = vNOCCUSTO2;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              vSEQANT := -1;
          END;
          IF vSEQANT IS NULL THEN
            vSEQANT := -1;
          END IF;
        END IF;
        IF vSEQANT <= 0 THEN
          vSEQUENCIA := vSEQUENCIA + 1;
          INSLANCCTB_LCT(pEMPRESA,
                         'SGE_CC',
                         pDATA,
                         vLANCCTB,
                         vSEQUENCIA,
                         vCONTAB2,
                         vNOCCUSTO2,
                         vHISTORICO,
                         vDC,
                         vVALORCTB,
                         vVALORCTBM,
                         '',
                         vSEGMOEDA,
                         null,
                         null,
                         VCDPROJETO);
        ELSE
          UPDATE LANCCTB_LCT
             SET LCT_VALOR  = LCT_VALOR + vVALORCTB,
                 LCT_VALORM = LCT_VALORM + vVALORCTBM
           WHERE LCT_CDEMPRESA = pEMPRESA
             AND LCT_DATA      = pDATA
             AND LCT_LOTE      = 'SGE_CC'
             AND LCT_LANCCTB   = vLANCCTB
             AND LCT_SEQ       = vSEQANT;
        END IF;
      END IF;
      ---
      FETCH MOV INTO vDOCUMENTO,
                     vTIPO,
                     vCONTAB1,
                     vNOCCUSTO1,
                     vCONTAB2,
                     vNOCCUSTO2,
                     vHISTORICO,
                     vVALORCTB,
                     vVALORCTBM,
                     VCDPROJETO;
      ---
    END LOOP;
    ---
    CLOSE MOV;
    ---
    /*
       Ira verificar a existencia de erros gerados pelo processo e que foram
       armazenados na tabela ERROPROCESSO_EPC.
       Caso existam erros, o processo de contabilizacao n�o sera comitado, e ser� feito um rollback do processo
    */
    vERRORMSG := EXISTE_MENSAGEM_DE_ERRO;
    IF NOT vERRORMSG THEN
      BEGIN
        COMMIT;
        ---
        UPDATE MOVIMENTO_MOV
           SET MOV_DTCONTABILIZADO = pDATA
         WHERE MOV_CDEMPRESA        = pEMPRESA
           AND MOV_TPESTOQUE        = pESTOQUE
           AND MOV_DATA            <= pDATA
           AND MOV_DTCONTABILIZADO IS NULL;
        vEXISTE_PARAM_ULTIMA_DATA := EXISTE_PARAM_ULTIMA_DATA;
        IF NOT vEXISTE_PARAM_ULTIMA_DATA THEN
          INSERT INTO PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
          VALUES ('SGE_DTCONTABILIZAESTOQUE' ||pEMPRESA || pESTOQUE, TO_CHAR(pDATA,'DD/MM/YYYY'), USER, SYSDATE, null, null, null, null, null, null);
        ELSE
          UPDATE PARAMS_PAR
             SET PAR_VLPARAM = TO_CHAR(pDATA,'DD/MM/YYYY')
           WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE'||pEMPRESA || pESTOQUE;
        END IF;
        RAISE SGECONT011;
      END;
    ELSE
      BEGIN
        ROLLBACK;
      END;
    END IF;
    ---
    -- FIM VARIAVEL ERRO
  ELSE
    -- PEGAR O PRIMEIRO ERRO GERADO E JOGAR NA TELA, ALTERAR POSTARIORMENTE A TELA PARA BUSCAR TODOS OS ERROS GERADOS NA TABELA DE ERRO
    BEGIN
      SELECT ERROCALCULOCUSTO_ECC.ECC_ALMOXARIFADO,
             ERROCALCULOCUSTO_ECC.ECC_ITEM,
             ERROCALCULOCUSTO_ECC.ECC_SALDO,
             ERROCALCULOCUSTO_ECC.ECC_SALDOVALOR,
             ERROCALCULOCUSTO_ECC.ECC_SALDOVALORM
        INTO vALMOX,
             vITEM,
             vSALDOQTD,
             vSALDOVALOR,
             vSALDOVALORM
        FROM ERROCALCULOCUSTO_ECC
       WHERE ECC_CDEMPRESA = pEMPRESA
         AND ECC_TPESTOQUE = pESTOQUE
         AND ROWNUM        = 1;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        vALMOX       := NULL;
        vITEM        := NULL;
        vSALDOQTD    := NULL;
        vSALDOVALOR  := NULL;
        vSALDOVALORM := NULL;
    END;
    ---
    IF (vSALDOQTD IS NOT NULL) OR (vSALDOVALOR IS NOT NULL) OR (vSALDOVALORM IS NOT NULL) THEN
      vMENSAGEMERRO := 'Item: ' || vITEM;
      IF vALMOX IS NOT NULL THEN
        vMENSAGEMERRO := vMENSAGEMERRO || ', Almoxarifado: ' || vALMOX;
      END IF;
      vMENSAGEMERRO := vMENSAGEMERRO || ' saldo de quantidade: ' || vSALDOQTD;
      vMENSAGEMERRO := vMENSAGEMERRO || ' saldo de valor:      ' || vSALDOVALOR;
      IF vSALDOVALORM <> 0 THEN
        vMENSAGEMERRO := vMENSAGEMERRO || ' saldo de valor na segunda moeda:      ' || vSALDOVALORM;
      END IF;
      RAISE SGECONT010;
    END IF;
  END IF;
EXCEPTION
  WHEN SGECONT001 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT001', 1, 'Periodo j� contabilizado');
    END;
  WHEN SGECONT002 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT002', 1, 'N�o h� movimento a contabilizar');
    END;
  WHEN SGECONT003 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT003', 1, 'Conta de estoque n�o parametrizada para o seguinte lan�amento: ' || RTRIM(vHISTORICO));
    END;
  WHEN SGECONT004 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT004', 1, 'Conta de destina��o ou contra-partida n�o parametrizada para o seguinte lan�amento: ' || RTRIM(vHISTORICO));
    END;
  WHEN SGECONT005 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT005', 1, 'Conta Cont�bil ' || vCONTAB1 || ' com centro de custo obrigat�rio.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT006 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT006', 1, 'Conta Cont�bil ' || vCONTAB1 || ' n�o aceita o centro de custo ' || vNOCCUSTO1 || '.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT007 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT007', 1, 'Conta de estoque inexistente');
    END;
  WHEN SGECONT008 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT008', 1, 'Conta Cont�bil ' || vCONTAB2 || ' com centro de custo obrigat�rio.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT009 THEN
    BEGIN
      ROLLBACK;
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT009', 1, 'Conta Cont�bil ' || vCONTAB2 || ' n�o aceita o centro de custo ' || vNOCCUSTO2 || '.' || DECODE(vDOCUMENTO, NULL, '', ' Documento: ' || vDOCUMENTO));
    END;
  WHEN SGECONT010 THEN
    BEGIN
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT010', 1, vMENSAGEMERRO);
    END;
  WHEN SGECONT011 THEN
    BEGIN
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT011', 0, 'Gera��o do custo e contabiliza��o conclu�dos.');
    END;
  WHEN SGECONT015 THEN
    BEGIN
      INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT015', 1, vMENSAGEMERRO);
    END;
END;
/

CREATE OR REPLACE PROCEDURE DESFAZ_MOVIMENTO_CONTABIL
(
  pEMPRESA IN CHAR,
  pESTOQUE IN CHAR,
  pDATA    IN DATE
)
AS
  vDATA                     DATE;
  vLANCCTB                  VARCHAR2(6);
  vEXISTE_PARAM_ULTIMA_DATA BOOLEAN;
  vULTCONTAB                MOVIMENTO_MOV.MOV_DTCONTABILIZADO%TYPE;
  vPERIODOBLOQUEADO         BOOLEAN;
  vMENSAGEMERRO             VARCHAR2(500);
  SGECONT015     EXCEPTION;
  ---
  CURSOR ULTIMA_CONTABILIZACAO_MOV IS
    SELECT MAX(MOV_DTCONTABILIZADO)
      FROM MOVIMENTO_MOV
     WHERE MOV_CDEMPRESA        = pEMPRESA
       AND MOV_TPESTOQUE        = pESTOQUE
       AND MOV_DTCONTABILIZADO IS NOT NULL
       AND MOV_DATA            <= pDATA;
  ---
  CURSOR DOCS IS
    SELECT DISTINCT LCT_DATA, LCT_LANCCTB
      FROM LANCCTB_LCT
     WHERE LCT_CDEMPRESA = pEMPRESA
       AND LCT_LOTE      = 'SGE_CC'
       AND LCT_DATA     >= pDATA
       AND (LCT_LANCCTB = pESTOQUE OR LCT_LANCCTB LIKE pESTOQUE || '____');
  FUNCTION EXISTE_PARAM_ULTIMA_DATA RETURN BOOLEAN AS
    VCOUNT NUMBER;
    CURSOR PARAM_ULTIMA_DATA IS
      SELECT COUNT(1)
        FROM PARAMS_PAR
       WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE;
  BEGIN
    OPEN PARAM_ULTIMA_DATA;
    FETCH PARAM_ULTIMA_DATA INTO VCOUNT;
    CLOSE PARAM_ULTIMA_DATA;
    RETURN(VCOUNT > 0);
  END;
BEGIN
  vPERIODOBLOQUEADO := GET_PERIODOCONTABILBLOQUEADO(pEMPRESA, pDATA);
  IF vPERIODOBLOQUEADO THEN
      vMENSAGEMERRO := 'Lan�amentos em per�odo cont�bil bloqueado. Data: ' || pDATA;
      RAISE SGECONT015;
  END IF;
  UPDATE MOVIMENTO_MOV
     SET MOV_DTCONTABILIZADO = NULL
   WHERE MOV_TPESTOQUE        = pESTOQUE
     AND MOV_CDEMPRESA        = pEMPRESA
     AND MOV_DTCONTABILIZADO >= pDATA;
  ---
  OPEN DOCS;
  FETCH DOCS INTO vDATA, vLANCCTB;
  WHILE DOCS%FOUND LOOP
    EXCLANCCTB_LCT(pEMPRESA, 'SGE_CC', vDATA, vLANCCTB);
    FETCH DOCS INTO vDATA, vLANCCTB;
  END LOOP;
  CLOSE DOCS;
  ----------------------------------------------------------------------
  --- SO PARA DESFAZER O DOCUMENTO DA VERSAO ANTERIOR ------------------
  EXCLANCCTB_LCT(pEMPRESA, 'CCE' || pESTOQUE, LAST_DAY(pDATA), 'CCE' || pESTOQUE); ---
  ----------------------------------------------------------------------
  ---
  OPEN ULTIMA_CONTABILIZACAO_MOV;
  FETCH ULTIMA_CONTABILIZACAO_MOV INTO vULTCONTAB;
  CLOSE ULTIMA_CONTABILIZACAO_MOV;
  vEXISTE_PARAM_ULTIMA_DATA := EXISTE_PARAM_ULTIMA_DATA;
  IF NOT vEXISTE_PARAM_ULTIMA_DATA THEN
    INSERT INTO PARAMS_PAR
      (PAR_CDPARAM,
       PAR_VLPARAM,
       PAR_CADASTRADO,
       PAR_DTCADASTRADO,
       PAR_HOMOLOGADO,
       PAR_DTHOMOLOGADO,
       PAR_CDEMP,
       PAR_CDFILIAL,
       PAR_CODOBS,
       PAR_SEPARADOROBS)
    VALUES
      ('SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE,
       TO_CHAR(vULTCONTAB, 'DD/MM/YYYY'),
       USER,
       SYSDATE,
       null,
       null,
       null,
       null,
       null,
       null);
  ELSE
    UPDATE PARAMS_PAR
       SET PAR_VLPARAM = TO_CHAR(vULTCONTAB, 'DD/MM/YYYY')
     WHERE PAR_CDPARAM = 'SGE_DTCONTABILIZAESTOQUE' || pEMPRESA || pESTOQUE;
  END IF;
EXCEPTION
  WHEN SGECONT015 THEN
    BEGIN
      RAISE_APPLICATION_ERROR(-20000, vMENSAGEMERRO);
      --INSERT INTO ERROPROCESSO_EPC VALUES ('SGECONT015', 1, vMENSAGEMERRO);
    END;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 281527
PROMPT ======================================================================