PROMPT ======================================================================
PROMPT == DEMANDA......: 281776
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: VANDERSON LOPES GUIDI
PROMPT == DATA.........: 16/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE RNFTITCRREINF_TRU
  DROP CONSTRAINT FK2_RNFTITCRREINF_TRU
/

ALTER TABLE RNFTITCRREINF_TRU
  ADD CONSTRAINT FK2_RNFTITCRREINF_TRU FOREIGN KEY (TRU_NRRRC)
  REFERENCES RNFTCRCOMP_RRC (RRC_IDRRC) ON DELETE CASCADE
/

ALTER TABLE RNFTITCPREINF_TRT
  DROP CONSTRAINT FK2_RNFTITCPREINF_TRT
/

ALTER TABLE RNFTITCPREINF_TRT
  ADD CONSTRAINT FK2_RNFTITCPREINF_TRT FOREIGN KEY (TRT_NRRPC)
  REFERENCES RNFTCPCOMP_RPC (RPC_IDRPC) ON DELETE CASCADE
/

CREATE OR REPLACE VIEW VW_RNF2010
/* CONSULTA DE T�TULOS A PAGAR REINF R-2010 
   CL�USULAS: 1) SOMENTE COM RETEN��O DE INSS 
              2) SOMENTE PARA FORNECEDORES PESSOA JURIDICA
              3) QUE POSSUAM INFORMA��ES FISCAIS COMPLEMENTARES PREENCHIDAS
              4) QUE POSSUAM AL�QUOTAS BASE DE 11% OU 3,5% (CPRB)
              5) QUE N�O POSSUAM INFORMA��O DE REPASSE PARA CLUBES DE FUTEBOL
*/
--CAMPOS DE CONTROLE------------------------------------------------------------
( TCP_CDEMPORI  
, TCP_CDFILIAL  
, TCP_CDFOR     
, TCP_NOTITULO  
, TCP_DTENTRADA 
, RPC_NRFATCADOBRA
, IEF_CDSTATUS
, IEF_CDRECIBO 
, IEF_NREVENTO
--CAMPOS DO LAYOUT--------------------------------------------------------------
, FOR_CGC          /*20 cnpjPrestador               */
, RPC_NRSERIE      /*29 nfs_serie                   */
, RPC_NRDOCUMENTO  /*30 nfs_numDocto                */
, TCP_DTEMISSAO    /*31 nfs_dtEmissaoNF             */
, TCP_VLRTITULO    /*32 nfs_vlrBruto                */
, TCP_OBS          /*33 nfs_obs                     */
, RPC_TPSERVICO    /*35 infoTpServ_tpServico        */
, RPC_CDATIVIDADE  
, RPI_DEDM         
, RPI_DEDT         
, RPI_DEDA         
, TCP_BASECALCINSS /*36 infoTpServ_vlrBaseRet       */
, TCP_INSS         /*37 infoTpServ_vlrRetencao      */
, RPI_SRET         /*38 infoTpServ_vlrRetSub        */
, RPI_NRET         /*39 infoTpServ_vlrNRetPrinc     */
, RPI_ADC2         /*40 infoTpServ_vlrServicos15    */
, RPI_ADC3         /*41 infoTpServ_vlrServicos20    */
, RPI_ADC4         /*42 infoTpServ_vlrServicos25    */
, RPI_ADCT         /*43 infoTpServ_vlrAdicional     */
, RPI_NRETADC      /*44 infoTpServ_vlrNRetAdic      */
, RPI_NRPROCREF    /*48 infoProcRetPr_nrProcRetPrinc*/
--------------------------------------------------------------------------------
)
AS 
SELECT TCP.TCP_CDEMPORI
     , TCP.TCP_CDFILIAL
     , TCP.TCP_CDFOR
     , TCP.TCP_NOTITULO     
     , TCP.TCP_DTENTRADA
     , RPC.RPC_NRFATCADOBRA
     , NVL(IEF.IEF_CDSTATUS, -1)
     , IEF.IEF_CDRECIBO	 
	 , IEF.IEF_NREVENTO
     , FORN.FOR_CGC        
     , RPC.RPC_NRSERIE
     , RPC.RPC_NRDOCUMENTO
     , TCP.TCP_DTEMISSAO     
     , TCP.TCP_VLRTITULO     
     , TCP.TCP_OBS
     , RTS.RTS_CDTPSERVICO AS RPC_TPSERVICO
     , CAS.CAS_CDATIVIDADE AS RPC_CDATIVIDADE
     , RPI.RPI_DEDM
     , RPI.RPI_DEDT
     , RPI.RPI_DEDA
     , TCP.TCP_BASECALCINSS
     , (TCP.TCP_INSS + NVL(RPI.RPI_SRET,0) + NVL(RPI.RPI_NRET,0)) - (NVL(RPI.RPI_ADC2,0) + NVL(RPI.RPI_ADC3,0) + NVL(RPI.RPI_ADC4,0)) AS TCP_INSS
     , NVL(RPI.RPI_SRET,0)
     , NVL(RPI.RPI_NRET,0)
     , NVL(RPI.RPI_ADC2,0)
     , NVL(RPI.RPI_ADC3,0)
     , NVL(RPI.RPI_ADC4,0)
     , (NVL(RPI.RPI_ADC2,0) + NVL(RPI.RPI_ADC3,0) + NVL(RPI.RPI_ADC4,0)) AS RPI_ADCT  
     , 0 AS RPI_NRETADC     
     , RPI.RPI_NRPROCREF	 
  FROM TITCP_TCP TCP
  JOIN EMP EMP                   ON EMP.EMP_CODIGO = TCP.TCP_CDEMPORI
  JOIN DARF_DRF DRF              ON DRF.DRF_CODPLCONTA = EMP.EMP_CODPLCONTA AND DRF.DRF_CODIGO = TCP.TCP_CDINSS 
  JOIN FORNEC_FOR FORN           ON FORN.FOR_CODIGO = TCP.TCP_CDFOR AND FORN.FOR_CGC IS NOT NULL AND FORN.FOR_TIPESSOA = 'J'
  JOIN RNFTCPCOMP_RPC RPC        ON RPC.RPC_CDFOR = TCP.TCP_CDFOR AND RPC.RPC_NOTITULO = TCP.TCP_NOTITULO AND RPC.RPC_TPREPASSE IS NULL            
  JOIN RNFINTTPSERVICO_RTS RTS   ON RTS.RTS_IDRTS = RPC.RPC_NRRTS
  LEFT 
  JOIN EFDSPEDCODATIVSCP_CAS CAS ON CAS.CAS_IDATIVIDADE = RPC.RPC_NRCAS
  LEFT
  JOIN (SELECT RPI_NRRPC 
             , SUM(DECODE(RPI_TPCOMPIMP, 'B', RPI_VALOR, NULL)) RPI_BASE
             , SUM(DECODE(RPI_TPCOMPIMP, 'M', RPI_VALOR, NULL)) RPI_DEDM
             , SUM(DECODE(RPI_TPCOMPIMP, 'T', RPI_VALOR, NULL)) RPI_DEDT
             , SUM(DECODE(RPI_TPCOMPIMP, 'A', RPI_VALOR, NULL)) RPI_DEDA
             , SUM(DECODE(RPI_TPCOMPIMP, '2', RPI_VALOR, NULL)) RPI_ADC2
             , SUM(DECODE(RPI_TPCOMPIMP, '3', RPI_VALOR, NULL)) RPI_ADC3
             , SUM(DECODE(RPI_TPCOMPIMP, '4', RPI_VALOR, NULL)) RPI_ADC4
             , SUM(DECODE(RPI_TPCOMPIMP, 'S', RPI_VALOR, NULL)) RPI_SRET
             , SUM(DECODE(RPI_TPCOMPIMP, 'N', RPI_VALOR, NULL)) RPI_NRET
             , MAX (RPI_NRPROCREF) AS RPI_NRPROCREF
          FROM (SELECT RPI_NRRPC,
                       RTA_TPITEMCALC AS RPI_TPCOMPIMP,
                       CASE WHEN RTA_TPITEMCALC IN ('B','M','T','A') THEN RPI_VLBASEIMP
                            ELSE RPI_VLIMP
                        END AS RPI_VALOR,
                       RPI_NRPROCREF
                  FROM RNFTCPCOMPIMP_RPI
                  JOIN RNFINTTPCALCADIC_RTA ON RTA_IDRTA = RPI_NRRTA)
                 GROUP BY RPI_NRRPC) RPI ON RPI.RPI_NRRPC = RPC.RPC_IDRPC  
  LEFT 
  JOIN RNFTITCPREINF_TRT TRT ON TRT.TRT_NRRPC = RPC.RPC_IDRPC
  LEFT
  JOIN RNFINFENVIOSREINF_IEF IEF ON TRT_NRIEF = IEF.IEF_IDIEF
 WHERE TCP_CDINSS IS NOT NULL

/

CREATE OR REPLACE VIEW VW_RNF2020
/* CONSULTA DE T�TULOS A RECEBER REINF R-2020 
   CL�USULAS: 1) SOMENTE COM RETEN��O DE INSS 
              2) QUE POSSUAM INFORMA��ES FISCAIS COMPLEMENTARES PREENCHIDAS
              3) QUE POSSUAM AL�QUOTAS BASE DE 11% OU 3,5% (CPRB)
              4) QUE N�O POSSUAM INFORMA��O DE RECURSOS RECEBIDOS POR CLUBES DE FUTEBOL
*/
--CAMPOS DE CONTROLE------------------------------------------------------------
( TCR_CDEMPORI  
, TCR_CDFILIAL  
, TCR_CDCLIENTE     
, TCR_NOTITULO  
, RRC_NRFATCADOBRA 
, IEF_CDSTATUS
, IEF_CDRECIBO
, IEF_NREVENTO
--CAMPOS DO LAYOUT--------------------------------------------------------------
, CLI_CGC          /*20 nrInscTomador               */
, RRC_NRSERIE      /*29 nfs_serie                   */
, RRC_NRDOCUMENTO  /*30 nfs_numDocto                */
, TCR_DTEMISSAO    /*31 nfs_dtEmissaoNF             */
, TCR_VLRTITULO    /*32 nfs_vlrBruto                */
, TCR_OBS          /*33 nfs_obs                     */
, RRC_TPSERVICO    /*35 infoTpServ_tpServico        */
, RRC_CDATIVIDADE  
, RRI_DEDM         
, RRI_DEDT         
, RRI_DEDA         
, TCR_BASECALCINSS /*36 infoTpServ_vlrBaseRet       */
, TCR_INSS         /*37 infoTpServ_vlrRetencao      */
, RRI_SRET         /*38 infoTpServ_vlrRetSub        */
, RRI_NRET         /*39 infoTpServ_vlrNRetPrinc     */
, RRI_ADC2         /*40 infoTpServ_vlrServicos15    */
, RRI_ADC3         /*41 infoTpServ_vlrServicos20    */
, RRI_ADC4         /*42 infoTpServ_vlrServicos25    */
, RRI_ADCT         /*43 infoTpServ_vlrAdicional     */
, RRI_NRETADC      /*44 infoTpServ_vlrNRetAdic      */
, RRI_NRPROCREF    /*48 infoProcRetPr_nrProcRetPrinc*/
--------------------------------------------------------------------------------
)
AS 
SELECT TCR.TCR_CDEMPORI
     , TCR.TCR_CDFILIAL
     , TCR.TCR_CDCLIENTE
     , TCR.TCR_NOTITULO     
     , RRC.RRC_NRFATCADOBRA
     , NVL(IEF.IEF_CDSTATUS, -1)
     , IEF.IEF_CDRECIBO	 
	 , IEF.IEF_NREVENTO
     , CLI.CLI_CGC        
     , RRC.RRC_NRSERIE
     , RRC.RRC_NRDOCUMENTO
     , TCR.TCR_DTEMISSAO     
     , TCR.TCR_VLRTITULO     
     , TCR.TCR_OBS
     , RTS.RTS_CDTPSERVICO AS RRC_TPSERVICO
     , CAS.CAS_CDATIVIDADE AS RRC_CDATIVIDADE
     , RRI.RRI_DEDM
     , RRI.RRI_DEDT
     , RRI.RRI_DEDA
     , TCR.TCR_BASECALCINSS
     , (TCR.TCR_INSS + NVL(RRI.RRI_SRET,0) + NVL(RRI.RRI_NRET,0)) - (NVL(RRI.RRI_ADC2,0) + NVL(RRI.RRI_ADC3,0) + NVL(RRI.RRI_ADC4,0)) AS TCR_INSS
     , NVL(RRI.RRI_SRET,0)
     , NVL(RRI.RRI_NRET,0)
     , NVL(RRI.RRI_ADC2,0)
     , NVL(RRI.RRI_ADC3,0)
     , NVL(RRI.RRI_ADC4,0)
     , (NVL(RRI.RRI_ADC2,0) + NVL(RRI.RRI_ADC3,0) + NVL(RRI.RRI_ADC4,0)) AS RRI_ADCT  
     , 0 AS RRI_NRETADC     
     , RRI.RRI_NRPROCREF
  FROM TITCR_TCR TCR
  JOIN EMP EMP                   ON EMP.EMP_CODIGO = TCR.TCR_CDEMPORI
  JOIN DARF_DRF DRF              ON DRF.DRF_CODPLCONTA = EMP.EMP_CODPLCONTA AND DRF.DRF_CODIGO = TCR.TCR_CDINSS 
  JOIN CLIENTE_CLI CLI           ON CLI.CLI_CODIGO = TCR.TCR_CDCLIENTE AND CLI.CLI_CGC IS NOT NULL
  JOIN RNFTCRCOMP_RRC RRC        ON RRC.RRC_CDCLIENTE = TCR.TCR_CDCLIENTE AND RRC.RRC_NOTITULO = TCR.TCR_NOTITULO AND RRC.RRC_TPREPASSE IS NULL            
  JOIN RNFINTTPSERVICO_RTS RTS   ON RTS.RTS_IDRTS = RRC.RRC_NRRTS
  LEFT 
  JOIN EFDSPEDCODATIVSCP_CAS CAS ON CAS.CAS_IDATIVIDADE = RRC.RRC_NRCAS
  LEFT
  JOIN (SELECT RRI_NRRRC 
             , SUM(DECODE(RRI_TPCOMPIMP, 'B', RRI_VALOR, NULL)) RRI_BASE
             , SUM(DECODE(RRI_TPCOMPIMP, 'M', RRI_VALOR, NULL)) RRI_DEDM
             , SUM(DECODE(RRI_TPCOMPIMP, 'T', RRI_VALOR, NULL)) RRI_DEDT
             , SUM(DECODE(RRI_TPCOMPIMP, 'A', RRI_VALOR, NULL)) RRI_DEDA
             , SUM(DECODE(RRI_TPCOMPIMP, '2', RRI_VALOR, NULL)) RRI_ADC2
             , SUM(DECODE(RRI_TPCOMPIMP, '3', RRI_VALOR, NULL)) RRI_ADC3
             , SUM(DECODE(RRI_TPCOMPIMP, '4', RRI_VALOR, NULL)) RRI_ADC4
             , SUM(DECODE(RRI_TPCOMPIMP, 'S', RRI_VALOR, NULL)) RRI_SRET
             , SUM(DECODE(RRI_TPCOMPIMP, 'N', RRI_VALOR, NULL)) RRI_NRET
             , MAX (RRI_NRPROCREF) AS RRI_NRPROCREF
          FROM (SELECT RRI_NRRRC,
                       RTA_TPITEMCALC AS RRI_TPCOMPIMP,
                       CASE WHEN RTA_TPITEMCALC IN ('B','M','T','A') THEN RRI_VLBASEIMP
                            ELSE RRI_VLIMP
                        END AS RRI_VALOR,
                       RRI_NRPROCREF
                  FROM RNFTCRCOMPIMP_RRI
                  JOIN RNFINTTPCALCADIC_RTA ON RTA_IDRTA = RRI_NRRTA)
                 GROUP BY RRI_NRRRC) RRI ON RRI.RRI_NRRRC = RRC.RRC_IDRRC  
  LEFT 
  JOIN RNFTITCRREINF_TRU TRU ON TRU.TRU_NRRRC = RRC.RRC_IDRRC
  LEFT
  JOIN RNFINFENVIOSREINF_IEF IEF ON TRU.TRU_NRIEF = IEF.IEF_IDIEF
 WHERE TCR_CDINSS IS NOT NULL

/

CREATE OR REPLACE VIEW VW_RNF2030
/* CONSULTA DE T�TULOS A RECEBER REINF R-2030 
   CL�USULAS: 1) SOMENTE COM RETEN��O DE INSS 
              2) QUE POSSUAM INFORMA��ES FISCAIS COMPLEMENTARES PREENCHIDAS
              3) QUE POSSUAM INFORMA��O DE REPASSE RECEBIDO POR CLUBES DE FUTEBOL
*/
--CAMPOS DE CONTROLE------------------------------------------------------------
( TCR_CDEMPORI  
, TCR_CDFILIAL  
, TCR_CDCLIENTE     
, TCR_NOTITULO  
, TCR_DTEMISSAO
, TCR_OBS
, IEF_CDSTATUS
, IEF_CDRECIBO
, IEF_NREVENTO
--CAMPOS DO LAYOUT--------------------------------------------------------------
, CLI_CGC          /*18 recursosRec_cnpjOrigRecurso */
, RRC_TPREPASSE    /*23 infoRecurso_tpRepasse       */
, RRC_DSREPASSE    /*24 infoRecurso_descRecurso     */
, TCR_VLRTITULO    /*25 infoRecurso_vlrBruto        */
, TCR_INSS         /*26 infoRecurso_vlrRetApur      */
, RRI_NRPROCREF    /*29 infoProc_nrProc             */
, RRI_NRET         /*29 infoProc_vlrNRet            */
--------------------------------------------------------------------------------
)
AS 
SELECT TCR.TCR_CDEMPORI
     , TCR.TCR_CDFILIAL
     , TCR.TCR_CDCLIENTE
     , TCR.TCR_NOTITULO     
     , TCR.TCR_DTEMISSAO     
     , TCR.TCR_OBS
     , NVL(IEF.IEF_CDSTATUS, -1)
     , IEF.IEF_CDRECIBO	 
	 , IEF.IEF_NREVENTO
     , CLI.CLI_CGC        
     , RRC.RRC_TPREPASSE
     , RRC.RRC_DSREPASSE
     , TCR.TCR_VLRTITULO     
     , TCR.TCR_INSS
     , RRI.RRI_NRPROCREF
     , RRI.RRI_NRET
  FROM TITCR_TCR TCR
  JOIN EMP EMP                   ON EMP.EMP_CODIGO = TCR.TCR_CDEMPORI
  JOIN DARF_DRF DRF              ON DRF.DRF_CODPLCONTA = EMP.EMP_CODPLCONTA AND DRF.DRF_CODIGO = TCR.TCR_CDINSS
  JOIN CLIENTE_CLI CLI           ON CLI.CLI_CODIGO = TCR.TCR_CDCLIENTE AND CLI.CLI_CGC IS NOT NULL
  JOIN RNFTCRCOMP_RRC RRC        ON RRC.RRC_CDCLIENTE = TCR.TCR_CDCLIENTE AND RRC.RRC_NOTITULO = TCR.TCR_NOTITULO AND RRC.RRC_TPREPASSE IS NOT NULL            
  LEFT
  JOIN (SELECT RRI_NRRRC 
             , SUM(DECODE(RRI_TPCOMPIMP, 'B', RRI_VALOR, NULL)) RRI_BASE
             , SUM(DECODE(RRI_TPCOMPIMP, 'M', RRI_VALOR, NULL)) RRI_DEDM
             , SUM(DECODE(RRI_TPCOMPIMP, 'T', RRI_VALOR, NULL)) RRI_DEDT
             , SUM(DECODE(RRI_TPCOMPIMP, 'A', RRI_VALOR, NULL)) RRI_DEDA
             , SUM(DECODE(RRI_TPCOMPIMP, '2', RRI_VALOR, NULL)) RRI_ADC2
             , SUM(DECODE(RRI_TPCOMPIMP, '3', RRI_VALOR, NULL)) RRI_ADC3
             , SUM(DECODE(RRI_TPCOMPIMP, '4', RRI_VALOR, NULL)) RRI_ADC4
             , SUM(DECODE(RRI_TPCOMPIMP, 'S', RRI_VALOR, NULL)) RRI_SRET
             , SUM(DECODE(RRI_TPCOMPIMP, 'N', RRI_VALOR, NULL)) RRI_NRET
             , MAX (RRI_NRPROCREF) AS RRI_NRPROCREF
          FROM (SELECT RRI_NRRRC,
                       RTA_TPITEMCALC AS RRI_TPCOMPIMP,
                       CASE WHEN RTA_TPITEMCALC IN ('B','M','T','A') THEN RRI_VLBASEIMP
                            ELSE RRI_VLIMP
                        END AS RRI_VALOR,
                       RRI_NRPROCREF
                  FROM RNFTCRCOMPIMP_RRI
                  JOIN RNFINTTPCALCADIC_RTA ON RTA_IDRTA = RRI_NRRTA)
                 GROUP BY RRI_NRRRC) RRI ON RRI.RRI_NRRRC = RRC.RRC_IDRRC  
  LEFT 
  JOIN RNFTITCRREINF_TRU TRU ON TRU.TRU_NRRRC = RRC.RRC_IDRRC
  LEFT
  JOIN RNFINFENVIOSREINF_IEF IEF ON TRU.TRU_NRIEF = IEF.IEF_IDIEF
 WHERE TCR_CDINSS IS NOT NULL

/

CREATE OR REPLACE VIEW VW_RNF2040
/* CONSULTA DE T�TULOS A PAGAR REINF R-2040 
   CL�USULAS: 1) SOMENTE COM RETEN��O DE INSS 
              2) SOMENTE PARA FORNECEDORES PESSOA JURIDICA
              3) QUE POSSUAM INFORMA��ES FISCAIS COMPLEMENTARES PREENCHIDAS
              4) QUE POSSUAM INFORMA��O DE REPASSE PARA CLUBES DE FUTEBOL
*/
--CAMPOS DE CONTROLE------------------------------------------------------------
( TCP_CDEMPORI  
, TCP_CDFILIAL  
, TCP_CDFOR     
, TCP_NOTITULO  
, TCP_DTENTRADA 
, TCP_OBS
, IEF_CDSTATUS
, IEF_CDRECIBO
, IEF_NREVENTO
--CAMPOS DO LAYOUT--------------------------------------------------------------
, FOR_CGC          /*18 recursosRep_cnpjAssocDesp */
, RPC_TPREPASSE    /*23 infoRecurso_tpRepasse     */
, RPC_DSREPASSE    /*24 infoRecurso_descRecurso   */
, TCP_VLRTITULO    /*25 infoRecurso_vlrBruto      */
, TCP_INSS         /*26 infoRecurso_vlrRetApur    */
, RPI_NRPROCREF    /*29 infoProc_nrProc           */
, RPI_NRET         /*29 infoProc_vlrNRet          */
--------------------------------------------------------------------------------
)
AS 
SELECT TCP.TCP_CDEMPORI
     , TCP.TCP_CDFILIAL
     , TCP.TCP_CDFOR
     , TCP.TCP_NOTITULO     
     , TCP.TCP_DTENTRADA
     , TCP.TCP_OBS
     , NVL(IEF.IEF_CDSTATUS, -1)
     , IEF.IEF_CDRECIBO
	 , IEF_NREVENTO
     , FORN.FOR_CGC        
     , RPC.RPC_TPREPASSE
     , RPC.RPC_DSREPASSE
     , TCP.TCP_VLRTITULO
     , TCP.TCP_INSS     
     , RPI.RPI_NRPROCREF
     , RPI.RPI_NRET     
  FROM TITCP_TCP TCP
  JOIN EMP EMP                   ON EMP.EMP_CODIGO = TCP.TCP_CDEMPORI
  JOIN DARF_DRF DRF              ON DRF.DRF_CODPLCONTA = EMP.EMP_CODPLCONTA AND DRF.DRF_CODIGO = TCP.TCP_CDINSS
  JOIN FORNEC_FOR FORN           ON FORN.FOR_CODIGO = TCP.TCP_CDFOR AND FORN.FOR_CGC IS NOT NULL AND FORN.FOR_TIPESSOA = 'J'
  JOIN RNFTCPCOMP_RPC RPC        ON RPC.RPC_CDFOR = TCP.TCP_CDFOR AND RPC.RPC_NOTITULO = TCP.TCP_NOTITULO AND RPC.RPC_TPREPASSE IS NOT NULL            
  LEFT
  JOIN (SELECT RPI_NRRPC 
             , SUM(DECODE(RPI_TPCOMPIMP, 'B', RPI_VALOR, NULL)) RPI_BASE
             , SUM(DECODE(RPI_TPCOMPIMP, 'M', RPI_VALOR, NULL)) RPI_DEDM
             , SUM(DECODE(RPI_TPCOMPIMP, 'T', RPI_VALOR, NULL)) RPI_DEDT
             , SUM(DECODE(RPI_TPCOMPIMP, 'A', RPI_VALOR, NULL)) RPI_DEDA
             , SUM(DECODE(RPI_TPCOMPIMP, '2', RPI_VALOR, NULL)) RPI_ADC2
             , SUM(DECODE(RPI_TPCOMPIMP, '3', RPI_VALOR, NULL)) RPI_ADC3
             , SUM(DECODE(RPI_TPCOMPIMP, '4', RPI_VALOR, NULL)) RPI_ADC4
             , SUM(DECODE(RPI_TPCOMPIMP, 'S', RPI_VALOR, NULL)) RPI_SRET
             , SUM(DECODE(RPI_TPCOMPIMP, 'N', RPI_VALOR, NULL)) RPI_NRET
             , MAX (RPI_NRPROCREF) AS RPI_NRPROCREF
          FROM (SELECT RPI_NRRPC,
                       RTA_TPITEMCALC AS RPI_TPCOMPIMP,
                       CASE WHEN RTA_TPITEMCALC IN ('B','M','T','A') THEN RPI_VLBASEIMP
                            ELSE RPI_VLIMP
                        END AS RPI_VALOR,
                       RPI_NRPROCREF
                  FROM RNFTCPCOMPIMP_RPI
                  JOIN RNFINTTPCALCADIC_RTA ON RTA_IDRTA = RPI_NRRTA)
                 GROUP BY RPI_NRRPC) RPI ON RPI.RPI_NRRPC = RPC.RPC_IDRPC  
	LEFT
	JOIN RNFTITCPREINF_TRT TRT ON TRT.TRT_NRRPC = RPC.RPC_IDRPC
	LEFT
	JOIN RNFINFENVIOSREINF_IEF IEF ON TRT.TRT_NRIEF = IEF.IEF_IDIEF
 WHERE TCP_CDINSS IS NOT NULL

/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 281776
PROMPT ======================================================================