PROMPT ======================================================================
PROMPT == DEMANDA......: 276986
PROMPT == SISTEMA......: Orcamento
PROMPT == RESPONSAVEL..: Camilla Batista de Lima
PROMPT == DATA.........: 05/12/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FORCE VIEW ORCAMESREV_ORR (ORR_COMPFCAIXA,
                                             ORR_CDEMPRESA,
                                             ORR_CDORCAM,
                                             ORR_CDREVIS,
                                             ORR_ESTFUNC,
                                             ORR_VERSAO,
                                             ORR_NOCCUSTO,
                                             ORR_ANOMES,
                                             ORR_NOCONTA,
                                             ORR_REALVIRT,
                                             ORR_TPLANC,
                                             ORR_CDPLORCA,
                                             ORR_CDPROJETO,
                                             ORR_VALOR
                                                    )
AS
SELECT   LCO_COMPFCAIXA AS ORR_COMPFCAIXA, ORC_CDEMPRESA AS ORR_CDEMPRESA, ORC_CDORCAM AS ORR_CDORCAM,
         ORC_CDREVIS AS ORR_CDREVIS, LCO_ESTFUNC AS ORR_ESTFUNC, LCO_VERSAO AS ORR_VERSAO, LCO_NOCCUSTO AS ORR_NOCCUSTO,
         LCO_ANOMES AS ORR_ANOMES, LCO_NOCONTA AS ORR_NOCONTA, 'F' AS ORR_REALVIRT, LCO_TPLANC AS ORR_TPLANC,
         LCO_CDPLORCA AS ORR_CDPLORCA, LCO_CDPROJETO AS ORR_CDPROJETO,
         SUM (DECODE (LCO_DC, 'D', LCO_VALOR, -LCO_VALOR)) AS ORR_VALOR
    FROM ORCAMENTO_ORC A, LANCORCA_LCO B
   WHERE A.ORC_CDEMPRESA = B.LCO_CDEMPRESA AND A.ORC_CDORCAM = B.LCO_CDORCAM AND B.LCO_CDREVIS = A.ORC_CDREVIS
GROUP BY LCO_COMPFCAIXA,
         LCO_DC,
         ORC_CDEMPRESA,
         ORC_CDORCAM,
         ORC_CDREVIS,
         LCO_ESTFUNC,
         LCO_VERSAO,
         LCO_NOCCUSTO,
         LCO_ANOMES,
         LCO_NOCONTA,
         LCO_TPLANC,
         LCO_CDPLORCA,
         LCO_CDPROJETO
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276986
PROMPT ======================================================================