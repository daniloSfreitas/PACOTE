PROMPT ======================================================================
PROMPT == DEMANDA......: 281574
PROMPT == SISTEMA......: Compras
PROMPT == RESPONSAVEL..: ERICA LIMA BOTELHO
PROMPT == DATA.........: 10/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE IREQCOMPRA_IRC DROP CONSTRAINT IREQCOMPRA_IRC_FK2
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 281574
PROMPT ======================================================================