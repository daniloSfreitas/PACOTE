PROMPT ======================================================================
PROMPT == DEMANDA......: 282558
PROMPT == SISTEMA......: SISTEMA GERADOR DE RELATORIOS
PROMPT == RESPONSAVEL..: ANDERSON EIJI NOGUTI
PROMPT == DATA.........: 04/12/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE TRIGGER TRG1_MXRPT_RELATORIO_MREL BEFORE INSERT OR UPDATE ON MXRPT_RELATORIO_MREL
FOR EACH ROW
BEGIN
  IF :NEW.MREL_TPRELATORIO = 3 THEN
   RAISE_APPLICATION_ERROR('ORA-20999','N�o � poss�vel salvar este relat�rio com o Tipo Cadastro');
  END IF;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282558
PROMPT ======================================================================