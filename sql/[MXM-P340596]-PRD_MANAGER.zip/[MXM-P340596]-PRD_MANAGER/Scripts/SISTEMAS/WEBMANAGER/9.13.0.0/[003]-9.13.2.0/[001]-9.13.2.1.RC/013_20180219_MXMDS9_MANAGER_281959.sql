PROMPT ======================================================================
PROMPT == DEMANDA......: 281959
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: FABIANO FIGUEIREDO ABREU
PROMPT == DATA.........: 24/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (11887, 'Cadastro de motivo de solicita��o de material', 'Cadastro de motivo de solicita��o de material')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGS', 11887, 8, 1000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11887, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11887, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11887, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 281959
PROMPT ======================================================================