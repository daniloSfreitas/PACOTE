PROMPT ======================================================================
PROMPT == DEMANDA......: 282944
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: FABIANO FIGUEIREDO ABREU
PROMPT == DATA.........: 06/12/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (11893, 'Estoque e Almoxarifado sem nota de transferencia', 'Estoque e Almoxarifado sem nota de transferencia')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGS', 11893, 10, 1000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11893, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11893, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (11893, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282944
PROMPT ======================================================================