PROMPT ======================================================================
PROMPT == DEMANDA......: 282304
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: LUANA MARIA DE SOUZA
PROMPT == DATA.........: 05/12/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GREVISAOTAB_VDR
      SET VRD_DSVISAO = 'Par�metro Cont�bil do Financeiro'
 WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA
                                             FROM GRETABDICDADOS_TDR
                                           WHERE TDR_NMTABELA = 'PARAMCTBSCPACRDEC_PCAD')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282304
PROMPT ======================================================================