PROMPT ======================================================================
PROMPT == DEMANDA......: 282687
PROMPT == SISTEMA......: Vendas
PROMPT == RESPONSAVEL..: RODRIGO DA PAZ DO NASCIMENTO
PROMPT == DATA.........: 08/12/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CALL ATUALIZA_SEQUENCE('SIPRELITPEDCOMP_ISPC','ISPC_IDRELACAO','SQ1_SIPRELITPEDCOMPRA_ISPC_E')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282687
PROMPT ======================================================================