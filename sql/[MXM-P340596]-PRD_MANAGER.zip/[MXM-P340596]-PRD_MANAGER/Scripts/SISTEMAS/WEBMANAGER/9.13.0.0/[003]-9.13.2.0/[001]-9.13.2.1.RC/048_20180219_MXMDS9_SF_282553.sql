PROMPT ======================================================================
PROMPT == DEMANDA......: 282553
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: Eduardo Lopes de Oliveira
PROMPT == DATA.........: 18/12/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE FATCADOBRA_FCO ADD FCO_NRMART VARCHAR2(100) NULL
/

COMMENT ON COLUMN FATCADOBRA_FCO.FCO_NRMART  IS 'Anota��o de Responsabilidade T�cnica'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282553
PROMPT ======================================================================