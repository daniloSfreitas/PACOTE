PROMPT ======================================================================
PROMPT == DEMANDA......: 283040
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: RODRIGO DA PAZ DO NASCIMENTO
PROMPT == DATA.........: 18/12/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

alter table FATACRDEC_FAD drop column FAT_CDFATURA
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 283040
PROMPT ======================================================================