PROMPT ======================================================================
PROMPT == DEMANDA......: 282300
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: SAMUEL MACHADO PINA DE MACEDO
PROMPT == DATA.........: 29/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE MXS_AMBIENTE_MXA
MODIFY MXS_CDAMBIENTE VARCHAR2(20)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 282300
PROMPT ======================================================================