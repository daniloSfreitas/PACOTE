PROMPT ======================================================================
PROMPT == DEMANDA......: 280662
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: CAIXA FATURAMENTO
PROMPT == DATA.........: 17/11/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE JANELAJUDA_JAJU
   SET JAJU_CODIGO = 'Y24'
 WHERE JAJU_ARQUIVO = 'ITFATURA_IFAT_SEQ'
/

UPDATE CAMPOAJUDA_CAJU
  SET CAJU_CODIGO = 'Y24'
WHERE CAJU_CODIGO = '926'
  AND CAJU_SEQUENCIA IN ('1','2')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280662
PROMPT ======================================================================