PROMPT ======================================================================
PROMPT == DEMANDA......: 278956
PROMPT == SISTEMA......: Integra��o Padr�o
PROMPT == RESPONSAVEL..: WESLEY RAPOSO
PROMPT == DATA.........: 27/09/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM LAYOUTCOD_LYC WHERE LYC_MODELO = 'PEDIDO DE VENDAS' AND   LYC_INDEX = 2
/

DELETE FROM LAYOUTMOD_LYM WHERE LYM_MODELO = 'PEDIDO DE VENDAS' AND   LYM_INDEX = 2
/

DELETE FROM LAYOUT_LAY WHERE LAY_MODELO = 'PEDIDO DE VENDAS' AND   LAY_INDEX = 2
/

UPDATE LAYOUTCOD_LYC SET LYC_FORMATO = 'DDMMAAAA' WHERE LYC_MODELO = 'PEDIDO DE VENDAS' AND   LYC_INDEX = 0 AND  (LYC_CAMPO = 'PDV_DATA' OR LYC_CAMPO = 'PDV_PENTREGA')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 278956
PROMPT ======================================================================