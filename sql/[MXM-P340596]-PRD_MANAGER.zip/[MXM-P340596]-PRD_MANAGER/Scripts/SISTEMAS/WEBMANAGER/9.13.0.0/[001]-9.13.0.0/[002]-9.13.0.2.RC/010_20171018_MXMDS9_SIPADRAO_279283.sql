PROMPT ======================================================================
PROMPT == DEMANDA......: 279283
PROMPT == SISTEMA......: Integra��o Padr�o
PROMPT == RESPONSAVEL..: THIAGO FERREIRA BARBOSA
PROMPT == DATA.........: 03/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE LAYOUTCOD_LYC
  SET LYC_COLUNA    = 'AU'
WHERE LYC_CODLAYOUT = 'XL'
  AND LYC_MODELO    = 'FATURAMENTO'
  AND LYC_CAMPO     = 'FAT_DTCOMPETENCIA'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279283
PROMPT ======================================================================