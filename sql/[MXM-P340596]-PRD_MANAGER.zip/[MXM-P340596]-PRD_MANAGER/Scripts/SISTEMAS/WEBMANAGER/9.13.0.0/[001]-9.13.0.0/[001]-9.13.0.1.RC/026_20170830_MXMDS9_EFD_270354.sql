PROMPT ======================================================================
PROMPT == DEMANDA......: 270354
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: Julian Alves
PROMPT == DATA.........: 17/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE SPEDTPUTILCRED_STUC MODIFY STUC_DESCRICAO VARCHAR2(2000)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 270354
PROMPT ======================================================================