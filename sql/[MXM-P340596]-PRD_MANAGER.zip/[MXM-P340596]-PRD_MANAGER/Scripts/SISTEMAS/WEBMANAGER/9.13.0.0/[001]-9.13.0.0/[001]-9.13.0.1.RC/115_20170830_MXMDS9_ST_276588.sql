PROMPT ======================================================================
PROMPT == DEMANDA......: 276588
PROMPT == SISTEMA......: Tesouraria
PROMPT == RESPONSAVEL..: MARCOS FELIPE DE CARVALHO FIGUEIRED
PROMPT == DATA.........: 30/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE PARCONAUTO_PCA
ADD (PCA_CDPROJETO VARCHAR2(20))
/

COMMENT ON COLUMN PARCONAUTO_PCA.PCA_CDPROJETO IS 'C�digo do projeto'
/



/*

     Retirando o  script conforme informado pelo Marcos.
	 
	 
De: Marcos Figueiredo 
Enviada em: quinta-feira, 31 de agosto de 2017 18:24
Para: Leonel Hora <leonel.hora@mxm.com.br>; Filipe Santos <filipe.santos@mxm.com.br>
Cc: Daniel Costa <daniel@mxm.com.br>
Assunto: Demanda 276588
Prioridade: Alta

Senhores boa tarde,

Preciso que retirem o script abaixo do pacote tanto da MXMDS9 como a MXMDS912.

O script subiu na demanda 276588.

O script foi inserido no SAU somente para aplicar na base da qualidade para que  o sistema conseguisse ler o arquivo enviado para o cliente, mas esqueci de retirar, cada agencia do banco utiliza e envia um arquivo com uma vers�o de layout, cada cliente tem sua agencia, ent�o o layout � adaptado conforme a necessidade do cliente, se o script ficar no pacote ir� atualizar o layout erradamente.



DELETE FROM PARAMS_PAR WHERE SUBSTR(PAR_CDPARAM,1,12) = 'wST_CA001COL'
/

insert into PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
values ('wST_CA001COL001', '@01CTACORRENTE @02Conta Corrente @0359 @0471 @0513 @06C @07 @08', USER, SYSDATE, '', null, '', '', '', '')
/

insert into PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
values ('wST_CA001COL002', '@01CDLANC @02Cod Lanc @03170 @04172 @053 @06C @07 @08', USER, SYSDATE, '', null, '', '', '', '')
/

insert into PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
values ('wST_CA001COL003', '@01HISTORICO @02Historico @03177 @04201 @0525 @06C @07 @08', USER, SYSDATE, '', null, '', '', '', '')
/

insert into PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
values ('wST_CA001COL004', '@01NODOC @02Documento @03202 @04207 @056 @06C @07 @08', USER, SYSDATE, '', null, '', '', '', '')
/

insert into PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
values ('wST_CA001COL005', '@01DTCON @02Data @03143 @04150 @058 @06D @07DDMMAAAA @08', USER, SYSDATE, '', null, '', '', '', '')
/

insert into PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
values ('wST_CA001COL006', '@01VALOR @02Valor @03151 @04168 @0518 @06N @079999999999999999.99 @08', USER, SYSDATE, '', null, '', '', '', '')
/

insert into PARAMS_PAR (PAR_CDPARAM, PAR_VLPARAM, PAR_CADASTRADO, PAR_DTCADASTRADO, PAR_HOMOLOGADO, PAR_DTHOMOLOGADO, PAR_CDEMP, PAR_CDFILIAL, PAR_CODOBS, PAR_SEPARADOROBS)
values ('wST_CA001COL007', '@01RP @02D/C @03169 @04169 @051 @06C @07 @08', USER, SYSDATE, '', null, '', '', '', '')
/

*/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276588
PROMPT ======================================================================