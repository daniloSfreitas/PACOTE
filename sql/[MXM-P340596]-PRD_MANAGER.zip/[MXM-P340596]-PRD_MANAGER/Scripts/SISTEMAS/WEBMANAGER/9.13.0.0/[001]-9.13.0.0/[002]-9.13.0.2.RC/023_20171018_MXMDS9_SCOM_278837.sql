PROMPT ======================================================================
PROMPT == DEMANDA......: 278837
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: LUANA MARIA DE SOUZA
PROMPT == DATA.........: 17/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FORCE VIEW vw_movist_mst (mst_cdclifor,
                                                    mst_nolanc,
                                                    mst_cdconta,
                                                    mst_lancctb,
                                                    cli_codigo
                                                   )
AS
   SELECT mst_cdclifor, mst_nolanc, mst_cdconta, mst_lancctb, cli_codigo
     FROM movist_mst, cliente_cli
    WHERE mst_cdclifor = cli_codigo
/

INSERT INTO GRETABDICDADOS_TDR (TDR_IDTABELA, TDR_NMTABELA, TDR_DSTABELA, TDR_NRFORCARJOIN)
VALUES (
(SELECT MAX(TDR_IDTABELA)+1 FROM GRETABDICDADOS_TDR),
'VW_MOVIST_MST',
'Movimenta��o Tesouraria - Cliente',
0
)
/

INSERT INTO GRETABELARELVISAL_TRV (TRV_IDTABELARELVISAO,TRV_NRVISAO,TRV_NRTABELA,TRV_NMLISTATABREL,TRV_NMCONDICAOTABREL)
VALUES (
(SELECT MAX(TRV_IDTABELARELVISAO)+1 FROM GRETABELARELVISAL_TRV),
(SELECT VDR_IDVISAO FROM GREVISAOTAB_VDR WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='MOVIST_MST')),
(SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='VW_MOVIST_MST'),
'CLIENTE_CLI',
'MOVIST_MST.MST_NOLANC = VW_MOVIST_MST.MST_NOLANC AND MOVIST_MST.MST_LANCCTB = VW_MOVIST_MST.MST_LANCCTB AND MOVIST_MST.MST_CDCLIFOR = VW_MOVIST_MST.MST_CDCLIFOR AND VW_MOVIST_MST.MST_CDCLIFOR = CLIENTE_CLI.CLI_CODIGO'
)
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (FCT_IDFILTROCAMPO,
   FCT_NRVISAO,
   FCT_DSFILTRO,
   FCT_TPFILTRO,
   FCT_TPCAMPOFILTRO,
   FCT_NMARQUIVOAJUDA,
   FCT_NMLISTATABELA,
   FCT_NMLISTACONDICAOAJUDA,
   FCT_NMCONDCAMPOCHB,
   FCT_TABELARELVISAO,
   FCT_NMCAMPO,
   FCT_DSFILTROCABECALHO)
VALUES
  ((SELECT MAX(FCT_IDFILTROCAMPO) + 1 FROM GREFILTROCAMPOTAB_FCT),
   (SELECT VDR_IDVISAO
      FROM GREVISAOTAB_VDR
     WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA
                             FROM GRETABDICDADOS_TDR
                            WHERE TDR_NMTABELA = 'MOVIST_MST')),
   'Cliente',
   0,
   0,
   'CLIENTE_CLI',
   null,
   null,
   null,
   (SELECT TRV_IDTABELARELVISAO
      FROM GRETABELARELVISAL_TRV
     WHERE TRV_NRVISAO =
           (SELECT VDR_IDVISAO
              FROM GREVISAOTAB_VDR
             WHERE VDR_NRTABELA =
                   (SELECT TDR_IDTABELA
                      FROM GRETABDICDADOS_TDR
                     WHERE TDR_NMTABELA = 'MOVIST_MST'))
       AND TRV_NRTABELA =
           (SELECT TDR_IDTABELA
              FROM GRETABDICDADOS_TDR
             WHERE TDR_NMTABELA = 'VW_MOVIST_MST')),
   'VW_MOVIST_MST.MST_CDCLIFOR',
   'Cliente')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 278837
PROMPT ======================================================================