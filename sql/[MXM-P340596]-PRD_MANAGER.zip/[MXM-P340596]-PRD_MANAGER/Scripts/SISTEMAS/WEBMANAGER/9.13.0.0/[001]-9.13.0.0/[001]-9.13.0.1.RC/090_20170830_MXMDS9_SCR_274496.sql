PROMPT ======================================================================
PROMPT == DEMANDA......: 274496
PROMPT == SISTEMA......: Contas a Receber
PROMPT == RESPONSAVEL..: NIKOLAS DE AGUIAR PONTES
PROMPT == DATA.........: 27/07/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION CALCIRRF(
  pcCdPessoa      IN VARCHAR2, -- codigo da pessoa na tabela cliente ou fornec.
  pcTpPessoa      IN CHAR, -- tipo   F=fisica ou J=juridica ou E=estrangeira ou G=governamental
  pcTbPessoa      IN CHAR, -- tabela C=cliente ou F=fornecedor
  pcCdPlCtb       IN VARCHAR2, -- codigo do plano de conta contabil (novo parametro 05/05/03)
  pcCdImp         IN VARCHAR2, -- codigo do imposto titulo
  pdDtBase        IN DATE, -- data da base para calculo atual
  pcNoTitulo      IN VARCHAR2, -- numero titulo no calculo atual
  pnVlrTitulo     IN NUMBER, -- valor titulo no calculo atual
  pnDedINSSI      IN NUMBER, -- valor deducao do inssi (novo parametro 05/05/03)
  pcCdEmp         IN VARCHAR2 DEFAULT '', -- codigo da empresa
  pcCGC           IN VARCHAR2 DEFAULT '', -- CGC da empresa
  pcTbCalc        IN CHAR DEFAULT 'T', -- tabela de calculo T=titulos SCP ou SCR, D=titulos SiDirf
  pcBaseCalcINSSI IN CHAR DEFAULT 'P', -- P=provisao ou B=baixa
  pnDtBaseINSSI   IN DATE DEFAULT NULL,-- data base deducao do inssi (novo parametro 05/05/03)
  pConsideraDTPagamentoIMP IN CHAR DEFAULT 'N')
  RETURN NUMBER
IS
  cCGC                  EMPGERAL_EMP.EMP_CGC%TYPE;
  cTpPessoa             VARCHAR2(1);
  cNoTitulo             VARCHAR2(20);
  cCdParam              VARCHAR2(20);
  nVlrTitulo            NUMBER;
  nVlrPago              NUMBER;
  nIrrf                 NUMBER;
  nInssi                NUMBER;
  nPerc                 NUMBER;
  nTTit                 NUMBER;
  nTIrrf                NUMBER;
  nTInssi               NUMBER; -- total de inssi do fornecedor na data base
  nCalcIrrf             NUMBER;
  nNDep                 NUMBER; -- numero de dependentes
  nVlrBase              NUMBER;
  nAliquota             NUMBER;
  nDeducao              NUMBER;
  nDedCarneINSS         NUMBER;
  nNumTit               NUMBER; --Variavel que verifica se existe mais de 1 titulo no mesmo mes
  cClasseINSS           VARCHAR2(2);
  cPV                   CHAR; -- ponto ou virgula para uso oracle instalado em portugues ou ingles
  nDedDependente        NUMBER; -- deducao por dependente
  wPAR_IRMIN            NUMBER; -- ir minimo para retencao
  cCdPlCtb              VARCHAR2(4); -- codigo do plano de conta contabil
  nCursor               INTEGER;
  nRows                 INTEGER;
  cSql                  VARCHAR2(1000);
  nDRF_DEDBASECALC      NUMBER;
  nDRF_VLRDEDBASECALC   NUMBER;
  nCountVigencia        NUMBER;
  wSCP_IMPSOCRETEMCDSRF PARAMS_PAR.PAR_VLPARAM%TYPE;
  PT_IMPIRRFRETENCDSRF  PARAMS_PAR.PAR_VLPARAM%TYPE DEFAULT ''; -- Parametro do imposto IRRF que possui os codigos SRF de retencao para acumulo individual
  PT_IMPIRRFCDSRFSEMAC  PARAMS_PAR.PAR_VLPARAM%TYPE DEFAULT ''; -- Parametro do imposto IRRF que possui os codigos SRF de retencao que n�o devem possuir acumulo
  PT_EXISTRETENESPCDSRF CHAR DEFAULT 'F'; -- Parametro existe codigo SRF de retencao para acumulo especifico (V = verdadeiro / F = falso)
  PT_EXISTRETENCDSRFIND CHAR DEFAULT 'F'; -- Parametro existe codigo SRF de retencao para acumulo individual(sem acumulo)
  PT_CDSRF              VARCHAR2(10) DEFAULT '';  -- Parametro que contem o codigo SRF de retencao referente ao codigo do imposto IRRF
  CURSOR TITDIRF IS
    SELECT  TRF_NOTITULO,TRF_VLRTITULO, NVL(TRF_IRRF,0),NVL(TRF_INSSI,0)
    FROM    TITDIRF_TRF A, EMP B, DARF_DRF
    WHERE   TRF_CDFOR = pcCdPessoa
            AND TRF_CDRET = DRF_CODIGO
            AND TRF_CDRET IS NOT NULL
            AND TO_CHAR(DECODE(DRF_BASECALC,'P',TRF_DTENTRADA,DECODE(TRF_DTPAGAME,'',TRF_DTPROG,TRF_DTPAGAME)),'MMYYYY') = TO_CHAR
(pdDtBase,'MMYYYY')
            AND TRF_CDEMPORI = EMP_CODIGO
            AND DRF_CODPLCONTA = B.EMP_CODPLCONTA
            AND (EMP_CGC = cCGC OR NVL(cCGC,' ') = ' ')
            AND ((PT_EXISTRETENESPCDSRF = 'V' AND DRF_CDRET = PT_CDSRF) OR (PT_EXISTRETENESPCDSRF = 'F' AND NOT (','||replace(PT_IMPIRRFRETENCDSRF,' ','')||',' LIKE '%,'|| DRF_CDRET || ',%') ))
            AND (PT_EXISTRETENCDSRFIND = 'F' AND NOT (','||replace(PT_IMPIRRFCDSRFSEMAC,' ','')||',' LIKE '%,'|| DRF_CDRET || ',%'))
    ORDER   BY TRF_DTENTRADA,A.ROWID;
  CURSOR TITCR IS
    SELECT  TCR_NOTITULO,DECODE(NVL(TCR_BASECALCIRRF,0),0,TCR_VLRTITULO,TCR_BASECALCIRRF),
            NVL(TCR_VLRPAGO,0),NVL(TCR_IRRF,0)
    FROM    TITCR_TCR A, EMP B, DARF_DRF
    WHERE   TCR_CDCLIENTE = pcCdPessoa
            AND TCR_CDIRRF = DRF_CODIGO
            AND TCR_CDIRRF IS NOT NULL
            AND TCR_DOCFATURA IS NULL
            AND (    (DECODE(NVL(pConsideraDTPagamentoIMP, 'N'),'S',TO_CHAR(DECODE(DRF_BASECALC, 'P', TCR_DTEMISSAO,TCR_DTPAGAME),'MMYYYY')) = TO_CHAR(pdDtBase,'MMYYYY'))
                  OR (DECODE(NVL(pConsideraDTPagamentoIMP, 'N'),'N',TO_CHAR(DECODE(DRF_BASECALC, 'P', TCR_DTEMISSAO,DECODE(TCR_DTPAGAME,NULL,TCR_DTPROG,TCR_DTPAGAME)),'MMYYYY')) = TO_CHAR(pdDtBase,'MMYYYY'))
                )
            AND TCR_CDEMPORI = EMP_CODIGO
            AND DRF_CODPLCONTA = B.EMP_CODPLCONTA
            AND NVL(TCR_STATUS, 'A') <> 'C'
            AND (EMP_CGC = cCGC OR NVL(cCGC,' ') = ' ')
            AND EMP_CODPLCONTA = DRF_CODPLCONTA
            AND ((PT_EXISTRETENESPCDSRF = 'V' AND DRF_CDRET = PT_CDSRF) OR (PT_EXISTRETENESPCDSRF = 'F' AND NOT (','||replace(PT_IMPIRRFRETENCDSRF,' ','')||',' LIKE '%,'|| DRF_CDRET || ',%') ))
            AND (PT_EXISTRETENCDSRFIND = 'F' AND NOT (','||replace(PT_IMPIRRFCDSRFSEMAC,' ','')||',' LIKE '%,'|| DRF_CDRET || ',%'))
    ORDER   BY TCR_DTEMISSAO,A.ROWID;
  CURSOR TITCP IS
    SELECT  TCP_NOTITULO,DECODE(NVL(TCP_BASECALCIRRF,0),0,TCP_VLRTITULO,TCP_BASECALCIRRF),
            NVL(TCP_VLRPAGO,0),NVL(TCP_IRRF,0)
    FROM    TITCP_TCP A, EMP B, DARF_DRF
    WHERE   TCP_CDFOR = pcCdPessoa
            AND TCP_CDRET = DRF_CODIGO
            AND TCP_CDRET IS NOT NULL
            AND TCP_DOCFATURA IS NULL
            AND NVL(TCP_STATUS, 'A') <> 'C'
            AND (    (DECODE(NVL(pConsideraDTPagamentoIMP, 'N'),'S',TO_CHAR(DECODE(DRF_BASECALC, 'P', TCP_DTENTRADA,TCP_DTPAGAME),'MMYYYY')) = TO_CHAR(pdDtBase,'MMYYYY'))
                  OR (DECODE(NVL(pConsideraDTPagamentoIMP, 'N'),'N',TO_CHAR(DECODE(DRF_BASECALC, 'P', TCP_DTENTRADA,DECODE(TCP_DTPAGAME,NULL,TCP_DTPROG,TCP_DTPAGAME)),'MMYYYY')) = TO_CHAR(pdDtBase,'MMYYYY'))
                )
            AND TCP_CDEMPORI = EMP_CODIGO
            AND DRF_CODPLCONTA = B.EMP_CODPLCONTA
            AND (EMP_CGC = cCGC OR NVL(cCGC,' ') = ' ')
            AND EMP_CODPLCONTA = DRF_CODPLCONTA
            AND ((PT_EXISTRETENESPCDSRF = 'V' AND DRF_CDRET = PT_CDSRF) OR (PT_EXISTRETENESPCDSRF = 'F' AND NOT (','||replace(PT_IMPIRRFRETENCDSRF,' ','')||',' LIKE '%,'|| DRF_CDRET || ',%') ))
            AND (PT_EXISTRETENCDSRFIND = 'F' AND NOT (','||replace(PT_IMPIRRFCDSRFSEMAC,' ','')||',' LIKE '%,'|| DRF_CDRET || ',%'))
    ORDER   BY TCP_DTENTRADA,A.ROWID;
  CURSOR PARAMS IS
    SELECT  TO_NUMBER(REPLACE(REPLACE(PAR_VLPARAM,'.',''),cPV,'.'))
    FROM    PARAMS_PAR
    WHERE   PAR_CDPARAM = cCdParam;
  CURSOR DEDCARNEINSS IS
    SELECT  CCI_SALBASE * CCI_ALIQSOBBASE / 100
    FROM    CLASSCONTINSS_CCI
    WHERE   TO_CHAR(CCI_COMPETENCIA,'MMYYYY') = TO_CHAR(pdDtBase,'MMYYYY')
            AND CCI_CLASSE = cClasseINSS
    ORDER   BY CCI_COMPETENCIA DESC;
  /*Para buscar o valor do INSSI � necess�rio utilizar a data base do IR e nao do INSSI, no momento de baixar um titulo
   so pode ser utilizado como base de calculo o INSSI do mes em questao.*/
  CURSOR TITCP_INSSI IS
    SELECT  TCP_NOTITULO,NVL(TCP_INSSI,0)+NVL(TCP_INSSIDEDIRRF,0)
    FROM    TITCP_TCP A, EMP B, DARF_DRF
    WHERE   TCP_CDFOR = pcCdPessoa
            AND TCP_CDRET = DRF_CODIGO
            AND DRF_CODPLCONTA = B.EMP_CODPLCONTA
            AND TCP_CDINSSI IS NOT NULL
            AND TCP_DOCFATURA IS NULL
            AND NVL(TCP_STATUS, 'A') <> 'C'
            AND (    (DECODE(NVL(pConsideraDTPagamentoIMP, 'N'),'S',TO_CHAR(DECODE(DRF_BASECALC, 'P', TCP_DTENTRADA,TCP_DTPAGAME),'MMYYYY')) = TO_CHAR(pdDtBase,'MMYYYY'))
                  OR (DECODE(NVL(pConsideraDTPagamentoIMP, 'N'),'N',TO_CHAR(DECODE(DRF_BASECALC, 'P', TCP_DTENTRADA,DECODE(TCP_DTPAGAME,NULL,TCP_DTPROG,TCP_DTPAGAME)),'MMYYYY')) = TO_CHAR(pdDtBase,'MMYYYY'))
                )
            AND TCP_CDEMPORI = EMP_CODIGO
            AND (EMP_CGC = cCGC OR NVL(cCGC,' ') = ' ')
            AND ((PT_EXISTRETENESPCDSRF = 'V' AND DRF_CDRET = PT_CDSRF) OR (PT_EXISTRETENESPCDSRF = 'F' AND NOT (','||replace(PT_IMPIRRFRETENCDSRF,' ','')||',' LIKE '%,'|| DRF_CDRET || ',%') ))
            AND (PT_EXISTRETENCDSRFIND = 'F' AND NOT (','||replace(PT_IMPIRRFCDSRFSEMAC,' ','')||',' LIKE '%,'|| DRF_CDRET || ',%'))
    ORDER   BY TCP_DTENTRADA,A.ROWID;
  CURSOR DARF IS
    SELECT  TO_NUMBER(REPLACE(REPLACE(DRF_PERC,'.',''),cPV,'.')),
            NVL(DRF_DEDBASECALC,0),
            NVL(DRF_VLRDEDBASECALC,0),
            DRF_CDRET
    FROM    DARF_DRF
    WHERE   DRF_CODPLCONTA = pcCdPlCtb
            AND DRF_CODIGO = pcCdImp;
BEGIN
  IF TRIM(pcCGC) IS NOT NULL THEN
    cCGC := pcCGC;
  ELSE
    IF pcCdEmp IS NULL THEN
      cCGC := '';
    ELSE
      SELECT EMP_CGC INTO cCGC FROM EMPGERAL_EMP WHERE EMP_CODIGO = pcCdEmp;
    END IF;
  END IF;
  BEGIN
    SELECT TO_NUMBER('1.5') INTO nPerc FROM DUAL;
    cPV := ',';
  EXCEPTION WHEN OTHERS THEN
    cPV := '.';
  END;
  BEGIN
    SELECT  PAR_VLPARAM
          INTO PT_IMPIRRFRETENCDSRF
    FROM    PARAMS_PAR
    WHERE   PAR_CDPARAM='wSCPSCRSIDIRF_IMPIRRFRETENCDSRF';
  EXCEPTION WHEN OTHERS THEN
      PT_IMPIRRFRETENCDSRF := '';
  END;
  BEGIN
    SELECT  PAR_VLPARAM
          INTO PT_IMPIRRFCDSRFSEMAC
    FROM    PARAMS_PAR
    WHERE   PAR_CDPARAM='wSCPSCRSIDIRF_IMPIRRFCDSRFSEMAC';
  EXCEPTION WHEN OTHERS THEN
      PT_IMPIRRFCDSRFSEMAC := '';
  END;
  cTpPessoa := pcTpPessoa;
  IF cTpPessoa IS NULL THEN
    IF pcTbPessoa = 'C' THEN
      SELECT  CLI_TIPESSOA
              INTO cTpPessoa
      FROM    CLIENTE_CLI
      WHERE   CLI_CODIGO = pcCdPessoa;
    ELSE
      SELECT  FOR_TIPESSOA
              INTO cTpPessoa
      FROM    FORNEC_FOR
      WHERE   FOR_CODIGO = pcCdPessoa;
    END IF;
  END IF;
  OPEN  DARF;
  FETCH DARF INTO nPerc, nDRF_DEDBASECALC, nDRF_VLRDEDBASECALC, PT_CDSRF;
  CLOSE DARF;
  IF nPerc IS NULL THEN
    nPerc := 0;
  END IF;
  IF  (','||replace(PT_IMPIRRFRETENCDSRF,' ','')||',' LIKE '%,'|| PT_CDSRF || ',%') AND (NOT PT_IMPIRRFRETENCDSRF IS NULL) AND (NOT PT_CDSRF IS NULL) THEN
   PT_EXISTRETENESPCDSRF := 'V';
  END IF;
  IF  (','||replace(PT_IMPIRRFCDSRFSEMAC,' ','')||',' LIKE '%,'|| PT_CDSRF || ',%') AND (NOT PT_IMPIRRFCDSRFSEMAC IS NULL) AND (NOT PT_CDSRF IS NULL) THEN
   PT_EXISTRETENCDSRFIND := 'V';
  END IF;
  IF (cTpPessoa = 'J') OR (cTpPessoa = 'E') OR (cTpPessoa = 'G') THEN
    nVlrTitulo := pnVlrTitulo;
    IF nVlrTitulo = 0 THEN
      BEGIN
        IF pcTbPessoa = 'C' THEN
          SELECT  DECODE(NVL(TCR_BASECALCIRRF,0),0,TCR_VLRTITULO,TCR_BASECALCIRRF)
                  INTO nVlrTitulo
          FROM    TITCR_TCR
          WHERE   TCR_CDCLIENTE = pcCdPessoa AND TCR_NOTITULO = pcNoTitulo;
        ELSE
          SELECT  DECODE(NVL(TCP_BASECALCIRRF,0),0,TCP_VLRTITULO,TCP_BASECALCIRRF)
                  INTO nVlrTitulo
          FROM    TITCP_TCP
          WHERE   TCP_CDFOR = pcCdPessoa AND TCP_NOTITULO = pcNoTitulo;
        END IF;
      EXCEPTION WHEN OTHERS THEN
        nVlrTitulo := 0;
      END;
    END IF;
    nVlrTitulo  := nVlrTitulo - (nVlrTitulo * nDRF_DEDBASECALC / 100); -- deducao percentual
    nVlrTitulo  := nVlrTitulo - nDRF_VLRDEDBASECALC; -- deducao valor
    nCalcIrrf   := (nVlrTitulo*nPerc/100);
    IF pcTbPessoa = 'C' THEN
       cCdParam    := 'wPARSCR_IRMIN';
    ELSE
       cCdParam    := 'wPAR_IRMIN';
    END IF;
    OPEN  PARAMS;
    FETCH PARAMS INTO wPAR_IRMIN;
    IF (PARAMS%NOTFOUND) OR (wPAR_IRMIN IS NULL) THEN
      wPAR_IRMIN := 10;
    END IF;
    CLOSE PARAMS;
    IF nCalcIrrf > wPAR_IRMIN THEN
      IF nVlrTitulo < nCalcIrrf THEN
        nCalcIrrf := nVlrTitulo;
      END IF;
    ELSE
      nCalcIrrf := 0;
    END IF;
  ELSE
    IF (cTpPessoa = 'F') OR (cTpPessoa = 'j') OR (cTpPessoa = 'J') THEN
      BEGIN
        SELECT  PAR_VLPARAM
              INTO wSCP_IMPSOCRETEMCDSRF
        FROM    PARAMS_PAR
        WHERE   PAR_CDPARAM='wSCP_IMPSOCRETEMCDSRF';
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          wSCP_IMPSOCRETEMCDSRF := '?';
        WHEN OTHERS THEN
          RAISE;
      END;
      BEGIN
        IF pcTbPessoa = 'C' THEN
          cCdParam    := 'wPARSCR_IRMIN';
        ELSE
          cCdParam    := 'wPAR_IRMIN';
        END IF;
        OPEN  PARAMS;
        FETCH PARAMS INTO wPAR_IRMIN;
        IF PARAMS%NOTFOUND THEN
          wPAR_IRMIN := 10;
        END IF;
      EXCEPTION WHEN OTHERS THEN
        wPAR_IRMIN := 10;
      END;
      CLOSE PARAMS;
      SELECT COUNT(*)
             INTO nCountVigencia
      FROM   CALCIRRF_CIR
             JOIN BASECALCIR_BCI ON (BCI_SEQ = CIR_SEQ)
      WHERE  BCI_VLRBASE >= pnVlrTitulo
             AND CIR_DATAINICIO <= pdDtBase
             AND CIR_DATAFIM >= pdDtBase;
      IF nCountVigencia = 0 THEN
        RETURN(0);
      END IF;
      nTTit := NVL(pnVlrTitulo,0);
      nIrrf         := 0;
      nTIrrf        := 0;
      nTInssi       := 0;
      nCalcIrrf     := 0;
      nNDep         := 0;
      nDedCarneINSS := NVL(pnDedINSSI,0);
      IF (pcTbPessoa = 'F') OR (pcTbPessoa = 'f') THEN
        SELECT  FOR_QTDDEP, FOR_CLASSEINSS
                INTO nNDep, cClasseINSS
        FROM    FORNEC_FOR
        WHERE   FOR_CODIGO = pcCdPessoa;
        IF nNDep IS NULL THEN
          nNDep := 0;
        END IF;
        IF nDedCarneINSS = 0 AND cClasseINSS IS NOT NULL THEN
          BEGIN
            OPEN  DEDCARNEINSS;
            FETCH DEDCARNEINSS INTO nDedCarneINSS;
            CLOSE DEDCARNEINSS;
          EXCEPTION WHEN OTHERS THEN
            nDedCarneINSS := 0;
          END;
        END IF;
      END IF;
      IF pcTbPessoa = 'C' THEN
        OPEN  TITCR;
        FETCH TITCR INTO cNoTitulo,nVlrTitulo,nVlrPago,nIrrf;
        nNumTit := TITCR%ROWCOUNT; --Atribui a quantidade de titulos que existem na data
        WHILE TITCR%FOUND LOOP
          -- se pcNoTitulo = '' ou nulo entao grava e retorna o imposto calculado
          -- se nao sY retorna o imposto calculado
          IF NVL(pcNoTitulo,' ') <> cNoTitulo THEN
            nTTit := nTTit + nVlrTitulo;
            IF nIrrf > 0 THEN
              nTIrrf := nTIrrf + nIrrf;
            END IF;
          END IF;
          FETCH TITCR INTO cNoTitulo,nVlrTitulo,nVlrPago,nIrrf;
        END LOOP;
        CLOSE TITCR;
        SELECT  COALESCE(MIN(CIR_DEDDEPENDENTE),0)
                INTO nDedDependente
        FROM    CALCIRRF_CIR
        WHERE   pdDtBase >= CIR_DATAINICIO AND pdDtBase <= CIR_DATAFIM;
        nTTit := nTTit - (nTTit * nDRF_DEDBASECALC / 100); -- deducao percentual
        nTTit := nTTit - nDRF_VLRDEDBASECALC; -- deducao valor
        nTTit := nTTit - (nNDep * nDedDependente) - nDedCarneINSS;
        SELECT  COALESCE(MIN(BCI_VLRBASE),0), COALESCE(MIN(BCI_ALIQUOTA),0), COALESCE(MIN(BCI_DEDUCAO),0)
                INTO nVlrBase, nAliquota, nDeducao
        FROM    BASECALCIR_BCI, CALCIRRF_CIR
        WHERE   BCI_VLRBASE >= nTTit
                AND pdDtBase >= CIR_DATAINICIO
                AND pdDtBase <= CIR_DATAFIM
                AND CIR_SEQ = BCI_SEQ;
        IF nAliquota > 0 THEN
          nCalcIrrf := nTTit * (nAliquota/100) - nDeducao;
          nCalcIrrf := nCalcIrrf - nTIrrf;
          IF nCalcIrrf < wPAR_IRMIN THEN
            nCalcIrrf := 0;
          END IF;
        END IF;
      ELSE
        IF pcTbCalc = 'D' THEN
          OPEN TITDIRF;
          FETCH TITDIRF INTO cNoTitulo, nVlrTitulo, nIrrf, nInssi;
          nNumTit := TITDIRF%ROWCOUNT;
          WHILE TITDIRF%FOUND LOOP
            IF NVL(pcNoTitulo,' ') <> cNoTitulo THEN
              nTTit := nTTit + nVlrTitulo;
              nTIrrf := nTIrrf + nIrrf;
              nTInssi := nTInssi + nInssi;
            END IF;
            FETCH TITDIRF INTO cNoTitulo, nVlrTitulo, nIrrf, nInssi;
          END LOOP;
          CLOSE TITDIRF;
        ELSE
          OPEN  TITCP;
          FETCH TITCP INTO cNoTitulo,nVlrTitulo,nVlrPago,nIrrf;
          nNumTit := TITCP%ROWCOUNT;
          WHILE TITCP%FOUND LOOP
            -- se pcNoTitulo = '' ou nulo entao grava e retorna o imposto calculado
            -- se nao sY retorna o imposto calculado
            IF NVL(pcNoTitulo,' ') <> cNoTitulo THEN
              nTTit := nTTit + nVlrTitulo;
              nTIrrf := nTIrrf + nIrrf;
            END IF;
            FETCH TITCP INTO cNoTitulo,nVlrTitulo,nVlrPago,nIrrf;
          END LOOP;
          CLOSE TITCP;
          OPEN  TITCP_INSSI;
          FETCH TITCP_INSSI INTO cNoTitulo,nInssi;
          nNumTit := TITCP_INSSI%ROWCOUNT;
          WHILE TITCP_INSSI%FOUND LOOP
            IF NVL(pcNoTitulo,' ') <> cNoTitulo THEN
              nTInssi := nTInssi + nInssi;
            END IF;
            FETCH TITCP_INSSI INTO cNoTitulo,nInssi;
          END LOOP;
          CLOSE TITCP_INSSI;
        END IF;
        SELECT  COALESCE(MIN(CIR_DEDDEPENDENTE),0)
                INTO nDedDependente
        FROM    CALCIRRF_CIR
        WHERE   pdDtBase >= CIR_DATAINICIO AND pdDtBase <= CIR_DATAFIM;
        nTTit := nTTit - (nTTit * nDRF_DEDBASECALC / 100); -- deducao percentual
        nTTit := nTTit - nDRF_VLRDEDBASECALC; -- deducao valor
        nTTit := nTTit - (nNDep * nDedDependente) - (nDedCarneINSS + nTInssi);
        SELECT  COALESCE(MIN(BCI_VLRBASE),0), COALESCE(MIN(BCI_ALIQUOTA),0), COALESCE(MIN(BCI_DEDUCAO),0)
                INTO nVlrBase, nAliquota, nDeducao
        FROM    BASECALCIR_BCI, CALCIRRF_CIR
        WHERE   BCI_VLRBASE >= nTTit
                AND pdDtBase >= CIR_DATAINICIO
                AND pdDtBase <= CIR_DATAFIM
                AND CIR_SEQ = BCI_SEQ;
        IF nAliquota > 0 THEN
          nCalcIrrf := nTTit * (nAliquota/100) - nDeducao;
          IF nCalcIrrf < wPAR_IRMIN THEN
            nCalcIrrf := 0;
          ELSE
            nCalcIrrf := nCalcIrrf - nTIrrf;
          END IF;
        END IF;
      END IF;
    END IF;
  END IF;
  /*
    Corre��o necess�ria para n�o permitir reten��o de imposto com valor negativo para IR. Mesma regra existente na CALCIMP para os demais impostos.
    OBS: Esta corre��o j� havia sido criada na vers�o 821C002 e foi sobrescrita por outra demanda. N�o remover.
  */
  IF nCalcIrrf < 0
   THEN nCalcIrrf:= 0;
  END IF;
  RETURN(nCalcIrrf);
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 274496
PROMPT ======================================================================