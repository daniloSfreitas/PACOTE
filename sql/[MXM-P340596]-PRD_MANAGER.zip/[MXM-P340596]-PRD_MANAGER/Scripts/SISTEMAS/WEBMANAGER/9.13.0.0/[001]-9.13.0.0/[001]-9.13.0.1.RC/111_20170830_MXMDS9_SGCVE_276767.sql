PROMPT ======================================================================
PROMPT == DEMANDA......: 276767
PROMPT == SISTEMA......: Contratos de Vendas
PROMPT == RESPONSAVEL..: DIOGO_RODRIGUES
PROMPT == DATA.........: 28/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

create sequence SEQ1_LANCSERVPREST_LST
minvalue 1
maxvalue 9999999999
start with 1
increment by 1
nocache
nocycle
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276767
PROMPT ======================================================================