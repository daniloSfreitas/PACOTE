PROMPT ======================================================================
PROMPT == DEMANDA......: 271946
PROMPT == SISTEMA......: Escritura��o Cont�bil Digital
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 12/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE ECD_PROCESSA_RI050 (PSME_CODIGO IN VARCHAR2, PTOTALREGISTRO_I050 OUT NUMBER, PTOTALREGISTRO_I051 OUT NUMBER, PTOTALREGISTRO_I052 OUT NUMBER) AS
   CURSOR BUSCACONTAREFERENCIAL   -- BUSCA SE A MANUTEN��O DO PLANO DE CONTAS � FEITO PELO BC OU SRF NO PAR�METRO DO EMPRES�RIO OU SOCIEDADE EMPRESARIAL
   IS
      SELECT PEPC_MANPLCONTA
        FROM SPEDPAREMPPLCONTAS_PEPC,SPEDPAREMPRESA_PEMP,SPEDMODELOESCRT_SME
       WHERE PEMP_IDPEMP = PEPC_IDPEMP
         AND SME_CDEMPRESA = PEMP_CDEMPRESA
         AND PEMP_CDFILIAL IS NULL
         AND SME_SYSTEMID = 'ECD'
         AND SME_CODIGO = PSME_CODIGO;
   CURSOR BUSCADATAESCRITURACAO
   IS
      SELECT TO_CHAR(SME_DTINICIO, 'RRRRMM'), TO_CHAR(SME_DTFIM, 'RRRRMM'), SME_CDEMPRESA,SME_IDLEIAUTE
        FROM SPEDMODELOESCRT_SME
       WHERE SME_CODIGO = PSME_CODIGO
         AND SME_SYSTEMID = 'ECD';
   CURSOR BUSCAVERSAOLAYOUT  -- Busca o ID da Vers�o Layout para verificar se o modelo de escritura��o � o layout 2
   IS SELECT SVL_IDVERSAOLAYOUT FROM SPEDVERSOESLAYOUT_SVL WHERE SVL_TPLEIAUTE = '0' AND SVL_CDLAYOUT = 'ECD2';
   CURSOR BUSCAVERSAOLAYOUT5
   IS SELECT SVL_IDVERSAOLAYOUT FROM SPEDVERSOESLAYOUT_SVL WHERE SVL_TPLEIAUTE = '0' AND SVL_CDLAYOUT = 'ECD5';
--TIPOS RI050 --
  TYPE TP_RI050_REG         IS TABLE OF SPEDECDPLCONTASV10_RI050.REG%TYPE;
  TYPE TP_RI050_COD_NAT     IS TABLE OF SPEDECDPLCONTASV10_RI050.COD_NAT%TYPE;
  TYPE TP_RI050_IND_CTA     IS TABLE OF SPEDECDPLCONTASV10_RI050.IND_CTA%TYPE;
  TYPE TP_RI050_NIVEL       IS TABLE OF SPEDECDPLCONTASV10_RI050.NIVEL%TYPE;
  TYPE TP_RI050_COD_CTA_SUP IS TABLE OF SPEDECDPLCONTASV10_RI050.COD_CTA_SUP%TYPE;
  TYPE TP_RI050_CTA         IS TABLE OF SPEDECDPLCONTASV10_RI050.CTA%TYPE;
  TYPE TP_RI050_PLC_ATIVO   IS TABLE OF SPEDECDPLCONTASV10_RI050.CTA%TYPE;
--VARIAVEIS RI050
   LST_RI050_REG            TP_RI050_REG;
   LST_RI050_COD_NAT        TP_RI050_COD_NAT;
   LST_RI050_IND_CTA        TP_RI050_IND_CTA;
   LST_RI050_NIVEL          TP_RI050_NIVEL;
   LST_RI050_COD_CTA_SUP    TP_RI050_COD_CTA_SUP;
   LST_RI050_CTA            TP_RI050_CTA;
   LST_RI050_PLC_ATIVO      TP_RI050_PLC_ATIVO;
--TIPOS RI051 --
  TYPE TP_RI051_REG         IS TABLE OF SPEDECDPLREFERV10_RI051.REG%TYPE;
  TYPE TP_RI051_COD_CTA_REF IS TABLE OF SPEDECDPLREFERV10_RI051.COD_CTA_REF%TYPE;
  TYPE TP_RI051_COD_ENT_REF IS TABLE OF SPEDECDPLREFERV10_RI051.COD_ENT_REF%TYPE;
--VARIAVEIS RI051
   LST_RI051_REG            TP_RI051_REG;
   LST_RI051_COD_CTA_REF    TP_RI051_COD_CTA_REF;
   LST_RI051_COD_ENT_REF    TP_RI051_COD_ENT_REF;
--TIPOS RI052 --
  TYPE TP_RI052_REG         IS TABLE OF SPEDECDCODAGLUV10_RI052.Reg%TYPE;
  TYPE TP_RI052_COD_AGL     IS TABLE OF SPEDECDCODAGLUV10_RI052.COD_AGL%TYPE;
--VARIAVEIS RI052
   LST_RI052_REG            TP_RI052_REG;
   LST_RI052_COD_AGL        TP_RI052_COD_AGL;
--TIPOS UNIVERSAIS
  TYPE TP_SMECODIGO         IS TABLE OF SPEDECDPLCONTASV10_RI050.Smecodigo%TYPE;
  TYPE TP_DT_ALT            IS TABLE OF SPEDECDPLCONTASV10_RI050.DT_ALT%TYPE;
  TYPE TP_COD_CTA           IS TABLE OF SPEDECDPLCONTASV10_RI050.COD_CTA%TYPE;
  TYPE TP_COD_CCUS          IS TABLE OF SPEDECDPLREFERV10_RI051.COD_CCUS%TYPE;
--VARIAVEIS UNIVERSAIS
   LST_SMECODIGO            TP_SMECODIGO;
   LST_DT_ALT               TP_DT_ALT;
   LST_COD_CTA              TP_COD_CTA;
   LST_COD_CCUS             TP_COD_CCUS;
   LST_COD_CCUS051          TP_COD_CCUS;
   QRY                      LONG;
   VPEPC_MANPLCONTA         VARCHAR2(3);
   SMEDTINICIO              VARCHAR2(6);
   SMEDTFIM                 VARCHAR2(6);
   SMECDEMPRESA             VARCHAR2(4);
   SME_IDLEIAUTE            NUMBER(10);
   SVL_IDVERSAOLAYOUT       NUMBER(10);
   SVL_IDVERSAOLAYOUT5      NUMBER(10);
   ZERA                     NUMBER;
   CONTAANTERIOR            VARCHAR2(30);
   ISUTILIZACCUSTO          VARCHAR2(1);
  CURSOR GET_PAR_ECD_UTILIZACCUSTO_ECD IS
     SELECT PAR_VLPARAM
       FROM PARAMS_PAR
      WHERE PAR_CDPARAM = 'wECD_UTILIZAR_CENTRO_CUSTO_NO_ECD'||SMECDEMPRESA;
BEGIN
  DELETE FROM SPEDECDCODAGLUV10_RI052  WHERE SMECODIGO = PSME_CODIGO;
  DELETE FROM SPEDECDPLREFERV10_RI051  WHERE SMECODIGO = PSME_CODIGO;
  DELETE FROM SPEDECDPLCONTASV10_RI050 WHERE SMECODIGO = PSME_CODIGO;
  OPEN BUSCACONTAREFERENCIAL;
  FETCH BUSCACONTAREFERENCIAL INTO VPEPC_MANPLCONTA;
  CLOSE BUSCACONTAREFERENCIAL;
  OPEN BUSCADATAESCRITURACAO;
  FETCH BUSCADATAESCRITURACAO INTO SMEDTINICIO, SMEDTFIM, SMECDEMPRESA,SME_IDLEIAUTE;
  CLOSE BUSCADATAESCRITURACAO;
  OPEN BUSCAVERSAOLAYOUT;
  FETCH BUSCAVERSAOLAYOUT INTO SVL_IDVERSAOLAYOUT;
  CLOSE BUSCAVERSAOLAYOUT;
  OPEN BUSCAVERSAOLAYOUT5;
  FETCH BUSCAVERSAOLAYOUT5 INTO SVL_IDVERSAOLAYOUT5;
  CLOSE BUSCAVERSAOLAYOUT5;
  OPEN  GET_PAR_ECD_UTILIZACCUSTO_ECD;
  FETCH GET_PAR_ECD_UTILIZACCUSTO_ECD INTO ISUTILIZACCUSTO;
  CLOSE GET_PAR_ECD_UTILIZACCUSTO_ECD;
  QRY := '';
  QRY := QRY || '  SELECT SMECODIGO                                                                                                    ';
  QRY := QRY || '     , DT_ALT                                                                                                         ';
  QRY := QRY || '     , COD_CTA                                                                                                        ';
  QRY := QRY || '     , REG                                                                                                            ';
  QRY := QRY || '     , COD_NAT                                                                                                        ';
  QRY := QRY || '     , IND_CTA                                                                                                        ';
  QRY := QRY || '     , NIVEL                                                                                                          ';
  QRY := QRY || '     , COD_CTA_SUP                                                                                                    ';
  QRY := QRY || '     , CTA                                                                                                            ';
  IF SVL_IDVERSAOLAYOUT = SME_IDLEIAUTE
   THEN BEGIN
     QRY := QRY || '     ,'''' AS REGI051                                                                                              ';
     QRY := QRY || '     ,'''' AS COD_ENT_REF                                                                                          ';
     QRY := QRY || '     ,'''' AS COD_CCUS                                                                                             ';
     QRY := QRY || '     ,'''' AS COD_CTA_REF                                                                                          ';
   END;
   ELSE BEGIN
     QRY := QRY || '     , REGI051                                                                                                     ';
     QRY := QRY || '     , COD_ENT_REF                                                                                                 ';
    IF ISUTILIZACCUSTO = 'S'
      THEN QRY := QRY || ' , ''               '' AS COD_CCUS                                                                           ';
      ELSE QRY := QRY || ' , COD_CCUS                                                                                                  ';
    END IF;
     QRY := QRY || '     , COD_CTA_REF                                                                                                 ';
   END;
  END IF;
  QRY := QRY || '     , REGI052                                                                                                        ';
  QRY := QRY || '     , COD_CCUS_AGLU                                                                                                  ';
  QRY := QRY || '     , COD_AGL                                                                                                        ';
  QRY := QRY || '     , PLC_ATIVO                                                                                                      ';
  QRY := QRY || ' FROM (                                                                                                               ';
  QRY := QRY || 'SELECT SMECODIGO                                                                                                      ';
  QRY := QRY || '     , TO_CHAR(SME_DTINICIO,''DDMMYYYY'')                                   AS DT_ALT                                 ';
  QRY := QRY || '     , MONTAMASCARA(PLC_NOCONTAB,CPLC_MASCARA)                              AS COD_CTA                                ';
  QRY := QRY || '     , ''I050''                                                             AS REG                                    ';
  QRY := QRY || '     , SPCC_CODNAT                                                          AS COD_NAT                                ';
  QRY := QRY || '     , PLC_SA                                                               AS IND_CTA                                ';
  QRY := QRY || '     , PLC_GRAU                                                             AS NIVEL                                  ';
  QRY := QRY || '     , DECODE(NVL(PLC_GRAU,1),1,'''',MONTAMASCARA(PLC_NOSUP,CPLC_MASCARA))  AS COD_CTA_SUP                            ';
  QRY := QRY || '     , PLC_DSCONTAB                                                         AS CTA                                    ';
  QRY := QRY || '     , DECODE(PLC_SA,''A'',''I051'','''')                                   AS REGI051                                ';
  IF SVL_IDVERSAOLAYOUT5 = SME_IDLEIAUTE
   THEN BEGIN
     QRY := QRY || '     , REPLACE(MANPLCONTA, ''#'', '''')  AS COD_ENT_REF';
   END;
   ELSE BEGIN
     QRY := QRY || '     , DECODE(PLC_SA,''A'',DECODE(MANPLCONTA,''0'',''20'',''1'',''10'',''#1'',''1'',''#2'',''2'',''#3'',''3'',''#4'',''4'',''#5'',''5'',''#6'',''6'',''#7'',''7'',''#8'',''8'',''#9'',''9'',''''),'''')         AS COD_ENT_REF';
   END;
  END IF;
  QRY := QRY || '     , DECODE(PLC_SA,''A'',COD_CCUS,'''')                                   AS COD_CCUS                                ';
  --  CASO A MANUTEN��O DO PLANO DE CONTAS FOR IGUAL A 0(BANCO CENTRAL) OU #3 ECF LR FINANCEIRA(#E02) ELE BUSCA O CODIGO CONTA REDUZIDO/ALTERNATIVO
  --  PARA QUALQUER OUTRO CASO UTILIZA O CODIGO DA CONTA CADASTRADA
  IF VPEPC_MANPLCONTA ='0'
   THEN QRY := QRY || ' , DECODE(PLC_SA,''A'',REPLACE(REPLACE(CONTA_COSI,''.'',''''),''-'',''''),'''')  AS COD_CTA_REF       ';
   ELSE IF VPEPC_MANPLCONTA ='#3'
         THEN QRY := QRY || ' , DECODE(PLC_SA,''A'',CONTA_COSI)                                     AS COD_CTA_REF                 ';
         ELSE QRY := QRY || ' , DECODE(PLC_SA,''A'',MONTAMASCARA(CMP_NOCONTABDES,MASCARAREF),'''')  AS COD_CTA_REF                 ';
        END IF;
  END IF;
  QRY := QRY || '     , DECODE(PLC_SA,''A'',''I052'','''')                                   AS REGI052                                ';
  QRY := QRY || '     , '' ''                                                                AS COD_CCUS_AGLU                          ';
  QRY := QRY || '     , DECODE(PLC_CONTRESUL,''N'',DECODE(PLC_SA,''A'',DECODE(CODMODAGL,'''',SUBSTR(PLC_NOCONTAB,1,4),SPCC_CODIGOAGLU),''''),''D''||SPCC_CODIGOAGLU) AS COD_AGL ';
  QRY := QRY || '     , PLC_ATIVO                                                                                                      ';
  QRY := QRY || '  FROM PLANOCTA_PLC                                                                                                   ';
  QRY := QRY || '     , (SELECT DISTINCT SME_CODIGO AS SMECODIGO                                                                       ';
  QRY := QRY || '             , PLC_CODPLANO        AS CODPLANO                                                                        ';
  QRY := QRY || '             , PEPC_PLCONTAREF     AS PLCONTAREF                                                                      ';
  QRY := QRY || '             , PEPC_CODMODAGL      AS CODMODAGL                                                                       ';
  QRY := QRY || '             , PEPC_MANPLCONTA     AS MANPLCONTA                                                                      ';
  QRY := QRY || '             , CPLC_MASCARA        AS MASCARAREF                                                                      ';
  QRY := QRY || '             , SME_DTINICIO        AS SME_DTINICIO                                                                    ';
  QRY := QRY || '             , SME_DTFIM           AS SME_DTFIM                                                                       ';
  QRY := QRY || '          FROM SPEDMODELOESCRT_SME                                                                                    ';
  QRY := QRY || '             , EMPGERAL_EMP                                                                                           ';
  QRY := QRY || '             , SPEDPAREMPRESA_PEMP                                                                                    ';
  QRY := QRY || '             , PLANOCTA_PLC                                                                                           ';
  QRY := QRY || '             , SPEDPAREMPPLCONTAS_PEPC                                                                                ';
  QRY := QRY || '             , CDPLANO_CPLC                                                                                           ';
  QRY := QRY || '         WHERE SME_CDEMPRESA   = EMP_CODIGO                                                                           ';
  QRY := QRY || '           AND SME_CDEMPRESA   = PEMP_CDEMPRESA                                                                       ';
  QRY := QRY || '           AND PEMP_CDFILIAL  IS NULL                                                                                 ';
  QRY := QRY || '           AND EMP_CODPLCONTA  = PLC_CODPLANO                                                                         ';
  QRY := QRY || '           AND PEMP_IDPEMP     = PEPC_IDPEMP                                                                          ';
  QRY := QRY || '           AND PEPC_PLCONTAREF = CPLC_CODIGO                                                                          ';
  QRY := QRY || '           AND SME_CODIGO      = ''' || PSME_CODIGO || '''                                                            ';
  QRY := QRY || '           AND SME_SYSTEMID    = ''ECD''                                                                              ';
  QRY := QRY || '        )                                                                                                             ';
  QRY := QRY || '     , (SELECT A.COD_CCUS AS COD_CCUS, CMP_NOCONTABORI, CMP_NOCONTABDES, PLC_NOREDUZ AS CONTA_COSI, CMP_CDPLANOORI    ';
  QRY := QRY || '          FROM CONVMOEDAPLC_CMP, PLANOCTA_PLC                                                                         ';
  QRY := QRY || '             ,(SELECT DISTINCT EMP_CODPLCONTA AS CODPLANO                                                             ';
  QRY := QRY || '                    , PEPC_PLCONTAREF       AS PLCONTAREF                                                             ';
  QRY := QRY || '                    , PEPC_CODMODAGL        AS CODMODAGL                                                              ';
  QRY := QRY || '                 FROM SPEDMODELOESCRT_SME                                                                             ';
  QRY := QRY || '                    , EMPGERAL_EMP                                                                                    ';
  QRY := QRY || '                    , SPEDPAREMPRESA_PEMP                                                                             ';
  QRY := QRY || '                    , SPEDPAREMPPLCONTAS_PEPC                                                                         ';
  QRY := QRY || '                WHERE SME_CDEMPRESA  = EMP_CODIGO                                                                     ';
  QRY := QRY || '                  AND SME_CDEMPRESA  = PEMP_CDEMPRESA                                                                 ';
  QRY := QRY || '                  AND PEMP_CDFILIAL IS NULL                                                                           ';
  QRY := QRY || '                  AND SME_CODIGO      = ''' || PSME_CODIGO || '''                                                     ';
  QRY := QRY || '                  AND SME_SYSTEMID = ''ECD''                                                                          ';
  QRY := QRY || '                  AND PEMP_IDPEMP    = PEPC_IDPEMP)                                                                   ';
  QRY := QRY || '             ,(SELECT DISTINCT REPLACE(COD_CTA, ''.'') AS COD_CTA, COD_CCUS                                           ';
  QRY := QRY || '                 FROM SPEDECDDETSALDOSV10_RI155                                                                       ';
  QRY := QRY || '                WHERE SMECODIGO = ''' || PSME_CODIGO || '''                                                           ';
  QRY := QRY || '              ) A                                                                                                     ';
  QRY := QRY || '         WHERE CMP_CDPLANOORI = CODPLANO                                                                              ';
  QRY := QRY || '           AND CMP_CDPLANODES = PLCONTAREF                                                                            ';
  QRY := QRY || '           AND PLC_CODPLANO = PLCONTAREF                                                                              ';
  QRY := QRY || '           AND PLC_NOCONTAB = CMP_NOCONTABDES                                                                         ';
  QRY := QRY || '           AND CMP_NOCONTABORI = COD_CTA                                                                              ';
  QRY := QRY || '       )                                                                                                              ';
  QRY := QRY || '     , CDPLANO_CPLC                                                                                                   ';
  QRY := QRY || '     , SPEDPARCCONTAB_SPCC                                                                                            ';
  QRY := QRY || ' WHERE PLC_CODPLANO = CODPLANO                                                                                        ';
  QRY := QRY || '   AND PLC_CODPLANO = CPLC_CODIGO                                                                                     ';
  QRY := QRY || '   AND PLC_CODPLANO = SPCC_PLCONTAB   (+)                                                                             ';
  QRY := QRY || '   AND PLC_NOCONTAB = SPCC_NOCONTAB   (+)                                                                             ';
  QRY := QRY || '   AND PLC_NOCONTAB = SUBSTR(CMP_NOCONTABORI,1,LENGTH(PLC_NOCONTAB))                                                  ';
  QRY := QRY || '   AND PLC_CODPLANO = CMP_CDPLANOORI                                                                                  ';
  QRY := QRY || '   AND SMECODIGO    = ''' || PSME_CODIGO || '''                                                                       ';
  QRY := QRY || ')                                                                                                                     ';
  QRY := QRY || 'GROUP BY SMECODIGO                                                                                                    ';
  QRY := QRY || '     , DT_ALT                                                                                                         ';
  QRY := QRY || '     , COD_CTA                                                                                                        ';
  QRY := QRY || '     , REG                                                                                                            ';
  QRY := QRY || '     , COD_NAT                                                                                                        ';
  QRY := QRY || '     , IND_CTA                                                                                                        ';
  QRY := QRY || '     , NIVEL                                                                                                          ';
  QRY := QRY || '     , COD_CTA_SUP                                                                                                    ';
  QRY := QRY || '     , CTA                                                                                                            ';
  QRY := QRY || '     , REGI051                                                                                                        ';
  QRY := QRY || '     , COD_ENT_REF                                                                                                    ';
  QRY := QRY || '     , COD_CCUS                                                                                                       ';
  QRY := QRY || '     , COD_CTA_REF                                                                                                    ';
  QRY := QRY || '     , REGI052                                                                                                        ';
  QRY := QRY || '     , COD_CCUS_AGLU                                                                                                  ';
  QRY := QRY || '     , COD_AGL                                                                                                        ';
  QRY := QRY || '     , PLC_ATIVO                                                                                                      ';
  QRY := QRY || 'ORDER BY COD_CTA, COD_CCUS                                                                                            ';
  EXECUTE IMMEDIATE QRY BULK COLLECT INTO LST_SMECODIGO
                                         , LST_DT_ALT
                                         , LST_COD_CTA
                                         , LST_RI050_REG
                                         , LST_RI050_COD_NAT
                                         , LST_RI050_IND_CTA
                                         , LST_RI050_NIVEL
                                         , LST_RI050_COD_CTA_SUP
                                         , LST_RI050_CTA
                                         , LST_RI051_REG
                                         , LST_RI051_COD_ENT_REF
                                         , LST_COD_CCUS051
                                         , LST_RI051_COD_CTA_REF
                                         , LST_RI052_REG
                                         , LST_COD_CCUS
                                         , LST_RI052_COD_AGL
                                         , LST_RI050_PLC_ATIVO;
  PTOTALREGISTRO_I050 := 0;
  PTOTALREGISTRO_I051 := 0;
  PTOTALREGISTRO_I052 := 0;
--  Processa o Registro I050
      FOR IDX_I050 IN LST_RI050_REG.FIRST..LST_RI050_REG.LAST LOOP
        BEGIN
          IF LST_RI050_REG.EXISTS(1) THEN
           BEGIN
            IF (
                   LST_RI050_IND_CTA(IDX_I050) = 'A' --ANALITICO
                   AND LST_RI050_NIVEL(IDX_I050) = '3' --GRAU 3
                   AND LST_RI050_PLC_ATIVO(IDX_I050) = 'N' -- INATIVA
                )
            THEN
              ZERA := 0;
            ELSE
              IF IDX_I050 > 1
              THEN CONTAANTERIOR := LST_COD_CTA(IDX_I050 - 1);
              END IF;
              IF (CONTAANTERIOR <>  LST_COD_CTA(IDX_I050)) OR (CONTAANTERIOR IS NULL)
              THEN
               INSERT INTO SPEDECDPLCONTASV10_RI050(SMECODIGO
                                                  , DT_ALT
                                                  , COD_CTA
                                                  , REG
                                                  , COD_NAT
                                                  , IND_CTA
                                                  , NIVEL
                                                  , COD_CTA_SUP
                                                  , CTA )
               VALUES(LST_SMECODIGO(IDX_I050)
                    , LST_DT_ALT(IDX_I050)
                    , LST_COD_CTA(IDX_I050)
                    , LST_RI050_REG(IDX_I050)
                    , LST_RI050_COD_NAT(IDX_I050)
                    , LST_RI050_IND_CTA(IDX_I050)
                    , LST_RI050_NIVEL(IDX_I050)
                    , LST_RI050_COD_CTA_SUP(IDX_I050)
                    , LST_RI050_CTA(IDX_I050)
                     );
               PTOTALREGISTRO_I050 := PTOTALREGISTRO_I050 + 1;
              END IF;
            END IF;
           END;
          END IF;
        END;
      END LOOP;
--  Processa o Registro I051
      IF LST_RI051_REG.EXISTS(1) AND LST_RI051_COD_CTA_REF.EXISTS(1) THEN
       BEGIN
         FOR IDX_I051 IN LST_RI051_REG.FIRST..LST_RI051_REG.LAST LOOP
          BEGIN
            IF LST_RI051_REG.EXISTS(IDX_I051) AND LST_RI051_REG(IDX_I051) IS NOT NULL AND LST_RI051_COD_CTA_REF(IDX_I051) IS NOT NULL AND TRIM(REPLACE(REPLACE(LST_RI051_COD_CTA_REF(IDX_I051),'.',''),' ','')) IS NOT NULL
            THEN
             IF (
                    LST_RI050_IND_CTA(IDX_I051) = 'A' --ANALITICO \ SINTETICO
                    AND LST_RI050_NIVEL(IDX_I051) = '3' --GRAU 3
                    AND LST_RI050_PLC_ATIVO(IDX_I051) = 'N' -- INATIVA
                 )
             THEN
              ZERA := 0;
             ELSE
              IF IDX_I051 > 1
              THEN CONTAANTERIOR  := LST_COD_CTA(IDX_I051 - 1);
              END IF;
              --IF (CONTAANTERIOR = LST_COD_CTA(IDX_I051) )
              --THEN
               INSERT INTO SPEDECDPLREFERV10_RI051(SMECODIGO,
                                                   DT_ALT,
                                                   COD_CTA,
                                                   COD_CTA_REF,
                                                   REG,
                                                   COD_ENT_REF,
                                                   COD_CCUS)
               VALUES(LST_SMECODIGO(IDX_I051),
                      LST_DT_ALT(IDX_I051),
                      LST_COD_CTA(IDX_I051),
                      LST_RI051_COD_CTA_REF(IDX_I051),
                      LST_RI051_REG(IDX_I051),
                      LST_RI051_COD_ENT_REF(IDX_I051),
                      TRIM(LST_COD_CCUS051(IDX_I051)));
               PTOTALREGISTRO_I051 := PTOTALREGISTRO_I051 + 1;
              END IF;
             END IF;
            --END IF;
          END;
         END LOOP;
       END;
      END IF;
--  Processa o Registro I052
    IF LST_RI052_REG.EXISTS(1) THEN
     BEGIN
       FOR IDX_I052 IN LST_RI052_REG.FIRST..LST_RI052_REG.LAST LOOP
         BEGIN
           IF LST_RI052_REG.EXISTS(IDX_I052) AND LST_RI052_REG(IDX_I052) IS NOT NULL AND LST_RI052_COD_AGL(IDX_I052) IS NOT NULL
           THEN
            IF(
                   LST_RI050_IND_CTA(IDX_I052) = 'A' --ANALITICO \ SINTETICO
                   AND LST_RI050_NIVEL(IDX_I052) = '3' --GRAU 3
                   AND LST_RI050_PLC_ATIVO(IDX_I052) = 'N' -- INATIVA
                )
            THEN
               ZERA := 0;
            ELSE
             IF IDX_I052 > 1
              THEN CONTAANTERIOR := LST_COD_CTA(IDX_I052 - 1);
              END IF;
              IF (CONTAANTERIOR <>  LST_COD_CTA(IDX_I052)) OR (CONTAANTERIOR IS NULL)
              THEN
              INSERT INTO SPEDECDCODAGLUV10_RI052(SMECODIGO,
                                                  DT_ALT,
                                                  COD_CTA,
                                                  COD_AGL,
                                                  REG,
                                                  COD_CCUS)
              VALUES(LST_SMECODIGO(IDX_I052),
                     LST_DT_ALT(IDX_I052),
                     LST_COD_CTA(IDX_I052),
                     LST_RI052_COD_AGL(IDX_I052),
                     LST_RI052_REG(IDX_I052),
                     LST_COD_CCUS(IDX_I052));
              PTOTALREGISTRO_I052 := PTOTALREGISTRO_I052 + 1;
              END IF;
            END IF;
           END IF;
         END;
       END LOOP;
     END;
    END IF;
END;
/

alter table SPEDSIGNATARIO_SSIG modify ssig_telefone VARCHAR2(14)
/

alter table SPEDECDSIGNATARIOSV10_RJ930 modify fone VARCHAR2(14)
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  1 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I155' as I20_CDREGORIGEM,
  '10' as I20_NRSEQCAMPOADICIONAL,
  'VL_SLD_INI_MF' as I20_NMCAMPOADICIONAL,
  'Valor do saldo inicial do per�odo em moeda funcional, convertida para reais.' as I20_DSCAMPOADICIONAL,
  'N' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  2 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I155' as I20_CDREGORIGEM,
  '11' as I20_NRSEQCAMPOADICIONAL,
  'IND_DC_INI_MF' as I20_NMCAMPOADICIONAL,
  'Indicador da situa��o do saldo inicial em moeda funcional: D - Devedor; C - Credor.' as I20_DSCAMPOADICIONAL,
  'C' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  3 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I155' as I20_CDREGORIGEM,
  '12' as I20_NRSEQCAMPOADICIONAL,
  'VL_DEB_MF' as I20_NMCAMPOADICIONAL,
  'Valor total dos d�bitos do per�odo em moeda funcional, convertida para reais.' as I20_DSCAMPOADICIONAL,
  'N' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  4 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I155' as I20_CDREGORIGEM,
  '13' as I20_NRSEQCAMPOADICIONAL,
  'VL_CRED_MF' as I20_NMCAMPOADICIONAL,
  'Valor total dos cr�ditos do per�odo em moeda funcional, convertida para reais.' as I20_DSCAMPOADICIONAL,
  'N' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  5 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I155' as I20_CDREGORIGEM,
  '14' as I20_NRSEQCAMPOADICIONAL,
  'VL_SLD_FIN_MF' as I20_NMCAMPOADICIONAL,
  'Valor do saldo final do per�odo em moeda funcional, convertida para reais.' as I20_DSCAMPOADICIONAL,
  'N' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  6 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I155' as I20_CDREGORIGEM,
  '15' as I20_NRSEQCAMPOADICIONAL,
  'IND_DC_FIN_MF' as I20_NMCAMPOADICIONAL,
  'Indicador da situa��o do saldo final em moeda funcional: D - Devedor; C - Credor' as I20_DSCAMPOADICIONAL,
  'C' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  7 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I200' as I20_CDREGORIGEM,
  '06' as I20_NRSEQCAMPOADICIONAL,
  'VL_LCTO_MF' as I20_NMCAMPOADICIONAL,
  'Valor do lan�amento em moeda funcional, convertida para reais.' as I20_DSCAMPOADICIONAL,
  'N' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  8 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I250' as I20_CDREGORIGEM,
  '10' as I20_NRSEQCAMPOADICIONAL,
  'VL_DC_MF' as I20_NMCAMPOADICIONAL,
  'Valor da partida em moeda funcional, convertida para reais.' as I20_DSCAMPOADICIONAL,
  'N' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  9 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I250' as I20_CDREGORIGEM,
  '11' as I20_NRSEQCAMPOADICIONAL,
  'IND_DC_MF' as I20_NMCAMPOADICIONAL,
  'Indicador da natureza da partida em moeda funcional: D - D�bito; C - Cr�dito' as I20_DSCAMPOADICIONAL,
  'C' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  10 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I355' as I20_CDREGORIGEM,
  '06' as I20_NRSEQCAMPOADICIONAL,
  'VL_CTA_MF' as I20_NMCAMPOADICIONAL,
  'Valor do saldo final antes do lan�amento de encerramento em moeda funcional, convertida para reais.' as I20_DSCAMPOADICIONAL,
  'N' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  11 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I355' as I20_CDREGORIGEM,
  '07' as I20_NRSEQCAMPOADICIONAL,
  'IND_DC_MF' as I20_NMCAMPOADICIONAL,
  'Indicador da situa��o do saldo final em moeda funcional: D - Devedor; C - Credor' as I20_DSCAMPOADICIONAL,
  'C' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  23 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I157' as I20_CDREGORIGEM,
  '06' as I20_NRSEQCAMPOADICIONAL,
  'VL_SLD_INI_MF' as I20_NMCAMPOADICIONAL,
  'Valor do saldo inicial do per�odo em moeda funcional, convertida para reais.' as I20_DSCAMPOADICIONAL,
  'N' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

MERGE INTO ECDCADCAMPOSADICION_I20 A USING
 (SELECT
  24 as I20_IDI20,
  'MOEDAFUNCIONAL' as I20_CDMOTIVO,
  'I157' as I20_CDREGORIGEM,
  '07' as I20_NRSEQCAMPOADICIONAL,
  'IND_DC_INI_MF' as I20_NMCAMPOADICIONAL,
  'Indicador da situa��o do saldo inicial em moeda funcional: D - Devedor; C - Credor.' as I20_DSCAMPOADICIONAL,
  'C' as I20_TPCAMPOADICIONAL,
  SYSDATE as I20_DTINCLUSAO,
  GET_USER_MXM as I20_USINCLUSAO,
  NULL as I20_DTALTERACAO,
  NULL as I20_USALTERACAO,
  'ECD4' as I20_CDVERSAOLAYOUT
  FROM DUAL) B
ON (A.I20_IDI20 = B.I20_IDI20)
WHEN NOT MATCHED THEN
INSERT (
  I20_IDI20, I20_CDMOTIVO, I20_CDREGORIGEM, I20_NRSEQCAMPOADICIONAL, I20_NMCAMPOADICIONAL,
  I20_DSCAMPOADICIONAL, I20_TPCAMPOADICIONAL, I20_DTINCLUSAO, I20_USINCLUSAO, I20_DTALTERACAO,
  I20_USALTERACAO, I20_CDVERSAOLAYOUT)
VALUES (
  B.I20_IDI20, B.I20_CDMOTIVO, B.I20_CDREGORIGEM, B.I20_NRSEQCAMPOADICIONAL, B.I20_NMCAMPOADICIONAL,
  B.I20_DSCAMPOADICIONAL, B.I20_TPCAMPOADICIONAL, B.I20_DTINCLUSAO, B.I20_USINCLUSAO, B.I20_DTALTERACAO,
  B.I20_USALTERACAO, B.I20_CDVERSAOLAYOUT)
WHEN MATCHED THEN
UPDATE SET
  A.I20_CDMOTIVO = B.I20_CDMOTIVO,
  A.I20_CDREGORIGEM = B.I20_CDREGORIGEM,
  A.I20_NRSEQCAMPOADICIONAL = B.I20_NRSEQCAMPOADICIONAL,
  A.I20_NMCAMPOADICIONAL = B.I20_NMCAMPOADICIONAL,
  A.I20_DSCAMPOADICIONAL = B.I20_DSCAMPOADICIONAL,
  A.I20_TPCAMPOADICIONAL = B.I20_TPCAMPOADICIONAL,
  A.I20_DTINCLUSAO = B.I20_DTINCLUSAO,
  A.I20_USINCLUSAO = B.I20_USINCLUSAO,
  A.I20_DTALTERACAO = B.I20_DTALTERACAO,
  A.I20_USALTERACAO = B.I20_USALTERACAO,
  A.I20_CDVERSAOLAYOUT = B.I20_CDVERSAOLAYOUT
/

UPDATE PARAMS_PAR
   SET PAR_CDPARAM = REPLACE(PAR_CDPARAM,
                             'wECD_GERARREGISTROSREFADEMODERESULTADO',
                             'wECD_GERARBLOCOJSITUACAOESPECIAL_ECD')
 WHERE PAR_CDPARAM LIKE 'wECD_GERARREGISTROSREFADEMODERESULTADO%'
/

alter table ECDTRANSSALPLCTBANT_TSA modify tsa_cdplanocta null
/

alter table ECDTRANSSALPLCTBANT_TSA modify tsa_cdccusto null
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 271946
PROMPT ======================================================================