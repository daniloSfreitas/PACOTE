PROMPT ======================================================================
PROMPT == DEMANDA......: 266471
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: JONATHAS DUARTE PEREIRA
PROMPT == DATA.........: 23/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (27445, 'Acompanhamento de envio de nota fiscal de servi�o', 'Acompanhamento de envio de nota fiscal de servi�o')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SF', 27445, 48, 2000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27445, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27445, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (27445, 'EXC')
/

ALTER TABLE fatloterps_flp ADD FLP_DSXMLENVIO BLOB
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 266471
PROMPT ======================================================================