PROMPT ======================================================================
PROMPT == DEMANDA......: 273071
PROMPT == SISTEMA......: Integra��o Padr�o
PROMPT == RESPONSAVEL..: GABRIEL SPINOLA TRINDADE MARINHO
PROMPT == DATA.........: 07/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

update TI_ARQFORGRPAG_TAFG TAFG
   SET TAFG.TAFG_REG = 0
 WHERE TAFG.TAFG_REG IS NULL
/

alter table TI_ARQFORGRPAG_TAFG
  DROP PRIMARY KEY CASCADE DROP INDEX
/

alter table TI_ARQFORGRPAG_TAFG
  add constraint PK_TI_ARQFORGRPAG_TAFG primary key (TAFG_SQPROCESSO, TAFG_SQREGISTRO, TAFG_SEQ, TAFG_REG)
/

create or replace procedure ALTTi_ARQFORGRPAG_TAFG
( pTAFG_SQPROCESSO	in NUMBER,
  pTAFG_SQREGISTRO	in NUMBER,
  PTAFG_REG         in NUMBER,
  pTAFG_CODFOR	    in CHAR,
  pTAFG_CODEMP	    in CHAR,
  pTAFG_CODFILIAL	  in CHAR,
  pTAFG_CODMOEDA	  in CHAR,
  pTAFG_CODGRPAG	  in CHAR,
  pTAFG_RETIR	      in CHAR,
  pTAFG_INSS	      in CHAR,
  pTAFG_ISS	        in CHAR,
  pTAFG_PIS	        in CHAR,
  pTAFG_COFINS	    in CHAR,
  pTAFG_CSOCIAL	    in CHAR,
  pTAFG_INSSI	      in CHAR,
  pTAFG_SEST	      in CHAR)
as begin
  update Ti_ARQFORGRPAG_TAFG set
    TAFG_CODFOR     = pTAFG_CODFOR,
    TAFG_CODEMP     = pTAFG_CODEMP,
    TAFG_CODFILIAL  = pTAFG_CODFILIAL,
    TAFG_CODMOEDA   = pTAFG_CODMOEDA,
    TAFG_CODGRPAG   = pTAFG_CODGRPAG,
    TAFG_RETIR      = pTAFG_RETIR,
    TAFG_INSS       = pTAFG_INSS,
    TAFG_ISS        = pTAFG_ISS,
    TAFG_PIS        = pTAFG_PIS,
    TAFG_COFINS     = pTAFG_COFINS,
    TAFG_CSOCIAL    = pTAFG_CSOCIAL,
    TAFG_INSSI      = pTAFG_INSSI,
    TAFG_SEST       = pTAFG_SEST
  where
    TAFG_SQPROCESSO = pTAFG_SQPROCESSO and
    TAFG_SQREGISTRO = pTAFG_SQREGISTRO AND
    TAFG_REG        = PTAFG_REG;
end;
/

create or replace procedure EXCTi_ARQFORGRPAG_TAFG
(pTAFG_SQPROCESSO	in NUMBER,
 pTAFG_SQREGISTRO	in NUMBER,
 PTAFG_REG                        in NUMBER)
as begin
  delete from Ti_ARQFORGRPAG_TAFG
  where
    TAFG_SQPROCESSO = pTAFG_SQPROCESSO and
    TAFG_SQREGISTRO = pTAFG_SQREGISTRO AND
    TAFG_REG        = PTAFG_REG;
end;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 273071
PROMPT ======================================================================