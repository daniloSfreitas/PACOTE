PROMPT ======================================================================
PROMPT == DEMANDA......: 275807
PROMPT == SISTEMA......: FRAMEWORK WEB
PROMPT == RESPONSAVEL..: SAMUEL MACHADO PINA DE MACEDO
PROMPT == DATA.........: 14/09/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (40503, 'Instalar chave do sistema', 'Instalar chave do sistema')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 275807
PROMPT ======================================================================