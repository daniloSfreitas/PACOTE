PROMPT ======================================================================
PROMPT == DEMANDA......: 279763
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: MAXUEL RIBEIRO SANTANA
PROMPT == DATA.........: 09/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'SPRR0015'
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO)
VALUES ('SPRR0015', 'Este registro s� pode ser manipulado pelo modulo EFD Reinf.')
/

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO = 'FCO00003'
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO)
VALUES ('FCO00003', 'Este registro s� pode ser manipulado pelo modulo EFD Reinf.')
/

UPDATE EFDAPURCONTRIBPREV_APB SET APB_CDSISTEMA='EFD' WHERE APB_CDSISTEMA IS NULL
/

ALTER TABLE EFDAPURCONTRIBPREV_APB MODIFY APB_CDSISTEMA NOT NULL
/

DROP PROCEDURE INSSPEDPROCREFERENCIADO_SPRR
/

DROP PROCEDURE ALTSPEDPROCREFERENCIADO_SPRR
/

DROP PROCEDURE EXCSPEDPROCREFERENCIADO_SPRR
/

DROP PROCEDURE EFD_PROCIMPORTAREFERENCIADO
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279763
PROMPT ======================================================================