PROMPT ======================================================================
PROMPT == DEMANDA......: 270815
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: PALOMA CASSIA CAMPELO DE OLIVEIRA
PROMPT == DATA.........: 15/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
VALUES (
   (SELECT MAX(cdr_idcampo)+1 FROM GRECAMPOS_CDR),
   (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'PLANOCTA_PLC'),
   'PLANOCTA_PLC.PLC_NOSUP',
   'Conta Cont�bil Superior',
   0,
   'Conta Superior')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 270815
PROMPT ======================================================================