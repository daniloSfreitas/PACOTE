PROMPT ======================================================================
PROMPT == DEMANDA......: 279291
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: LUANA MARIA DE SOUZA
PROMPT == DATA.........: 17/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE function GET_FORMATACODIGOFLUXOCAIXA
( pCodigo_Fluxo  IN CHAR )
return Varchar2 is
 varCodigo_Fluxo varchar2(30);
  numTam      number;
begin
  if pCodigo_Fluxo is not null then
    varCodigo_Fluxo := Translate(pCodigo_Fluxo, '.', '.');
    varCodigo_Fluxo := Replace(varCodigo_Fluxo, '.', '');
    numTam            := Length(varCodigo_Fluxo);
    varCodigo_Fluxo := MontaMascara(varCodigo_Fluxo, '9.99.999');
  else
     varCodigo_Fluxo := null;
  end if;
  return(varCodigo_Fluxo);
end GET_FORMATACODIGOFLUXOCAIXA;
/

INSERT INTO GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
VALUES (
   (SELECT MAX(cdr_idcampo)+1 FROM GRECAMPOS_CDR),
   (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'FORNEC_FOR'),
   'GET_CPF_CNPJ_FORMATADO(FORNEC_FOR.FOR_CGC)',
   'CNPJ/CPF Formatado',
   0,
   'CNPJ/CPF Formatado')
/

INSERT INTO GRECAMPOS_CDR
   (CDR_IDCAMPO, CDR_NRTABELA, CDR_DSCAMPOTABELA, CDR_DSCAMPO, CDR_TPCAMPO, CDR_DSCAMPOTABELACABECALHO)
VALUES (
   (SELECT MAX(cdr_idcampo)+1 FROM GRECAMPOS_CDR),
   (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'FLUXOCX_FCX'),
   'GET_FORMATA_CODIGO_FLUXO_CAIXA(FORNEC_FOR.FOR_CGC)',
   'C�digo Formatado',
   0,
   'C�digo Formatado')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279291
PROMPT ======================================================================