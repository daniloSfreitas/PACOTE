PROMPT ======================================================================
PROMPT == DEMANDA......: 276746
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: CAIXA SAU
PROMPT == DATA.........: 11/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

               INSERT INTO GRECAMPOS_CDR
     VALUES ((SELECT MAX (CDR_IDCAMPO) + 1
                FROM GRECAMPOS_CDR), (SELECT TDR_IDTABELA
                                        FROM GRETABDICDADOS_TDR
                                       WHERE TDR_NMTABELA = 'IREQCOMPRA_IRC'),
             'IREQCOMPRA_IRC.IRC_GRUPOCOTA', 'Grupo de Cota��o', 0,
             'Grupo de Cota��o')
/

INSERT INTO GREFILTROCAMPOTAB_FCT
     VALUES ((SELECT MAX (FCT_IDFILTROCAMPO) + 1
                FROM GREFILTROCAMPOTAB_FCT),
             (SELECT VDR_IDVISAO
                FROM GREVISAOTAB_VDR
               WHERE VDR_CDSISTEMA = 'SCOM' AND VRD_DSVISAO = 'Requisi��o'),
             'Grupo de Cota��o', 0, 0, 'GRCOTAC_GCT', NULL, NULL, NULL, NULL,
             'IREQCOMPRA_IRC.IRC_GRUPOCOTA', 'Grupo de Cota��o')
/

DELETE FROM GRECADCAMPO_CCG
      WHERE CCG_IDCAMPOREL =
                   (SELECT CDR_IDCAMPO
                      FROM GRECAMPOS_CDR
                     WHERE CDR_DSCAMPOTABELA = 'REQCOMPRA_RCO.RCO_STATUSAPRV')
/

DELETE FROM GRECAMPOS_CDR
      WHERE CDR_DSCAMPOTABELA = 'REQCOMPRA_RCO.RCO_STATUSAPRV'
/

UPDATE GRECAMPOS_CDR  SET CDR_DSCAMPOTABELA  = 'ROUND(' || CDR_DSCAMPOTABELA  || ',2)' WHERE CDR_DSCAMPOTABELA LIKE 'MOEDACONV%'
/

INSERT INTO GRECAMPOS_CDR
     VALUES ((SELECT MAX (CDR_IDCAMPO) + 1
                FROM GRECAMPOS_CDR),
                (SELECT TDR_IDTABELA
                                        FROM GRETABDICDADOS_TDR
                                       WHERE TDR_NMTABELA = 'TITCP_TCP'),
             'ROUND(MOEDACONV(TITCP_TCP.TCP_ANTECIP, :PARAM_TCP_MOEDA, TITCP_TCP.TCP_MOEDA, TRUNC(SYSDATE), TITCP_TCP.TCP_VLRCOTACAOPR, EMP.EMP_MOEDACOR),2)', 'Valor Convertido Antecipa��o', 3,
             'Vl. Conv. Antecip')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276746
PROMPT ======================================================================