PROMPT ======================================================================
PROMPT == DEMANDA......: 274398
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: LUCIANO VARGAS DE MATTOS
PROMPT == DATA.........: 04/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRECAMPOS_CDR
  (cdr_idcampo,
   cdr_nrtabela,
   cdr_dscampotabela,
   cdr_dscampo,
   cdr_tpcampo,
   cdr_dscampotabelacabecalho)
VALUES
  ((SELECT MAX(CDR_IDCAMPO) + 1 FROM GRECAMPOS_CDR),
   (SELECT TDR_IDTABELA
      FROM GRETABDICDADOS_TDR
     WHERE TDR_NMTABELA = 'FATURAS_FAT'),
   '(SELECT DECODE(FAT2.FAT_NF, 0, NULL, FAT2.FAT_NF)
  FROM FATNFSUBST_FNS FNS, FATURAS_FAT FAT2
 WHERE FNS.FNS_CDEMPRESA = FATURAS_FAT.FAT_CDEMPRESA
   AND FNS.FNS_CDFILIAL = FATURAS_FAT.FAT_CDFILIAL
   AND FNS.FNS_CDFATURA = FATURAS_FAT.FAT_CDFATURA
   AND FAT2.FAT_CDEMPRESA = FNS.FNS_CDEMPRESA
   AND FAT2.FAT_CDFILIAL = FNS.FNS_CDFILIAL
   AND FAT2.FAT_CDFATURA = FNS.FNS_CDFATURAORI
   AND FNS.FNS_CDFATURAORI = FAT2.FAT_CDFATURA)',
   'Nota substitu�da',
   0,
   'Nota substitu�da')
/

INSERT INTO grefiltrocampotab_fct
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'FATURAS_FAT')),
   'Somente nota substituta',
   1,
   0,
   '',
   '',
   '',
   '(CASE WHEN(EXISTS (SELECT fns_cdfatura
      FROM FATNFSUBST_FNS
     WHERE FATNFSUBST_FNS.fns_cdempresa = FATURAS_FAT.FAT_CDEMPRESA
       AND FATNFSUBST_FNS.fns_cdfilial = FATURAS_FAT.FAT_CDFILIAL
       AND FATNFSUBST_FNS.FNS_CDFATURA = FATURAS_FAT.FAT_CDFATURA))
     THEN ''S'' ELSE ''N'' END)',
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'FATURAS_FAT'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'FATURAS_FAT')),
   'FATURAS_FAT.NOTA_SUBSTITUTA',
   'Somente nota substitu�da')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 274398
PROMPT ======================================================================