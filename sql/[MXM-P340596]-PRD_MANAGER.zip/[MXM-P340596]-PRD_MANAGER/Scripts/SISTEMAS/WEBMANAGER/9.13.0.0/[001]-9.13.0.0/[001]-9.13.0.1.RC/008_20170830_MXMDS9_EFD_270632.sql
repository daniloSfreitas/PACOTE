PROMPT ======================================================================
PROMPT == DEMANDA......: 270632
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: ANDRE LUIZ PEREIRA FONTES
PROMPT == DATA.........: 02/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGB025(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGB025         VARCHAR2(4) := 'B025';
   CURSOR CS_REGB025 IS
      SELECT SEQ1_EFDLEDFREGISTROB025_B03.NEXTVAL AS IDLEDFREGISTROB025
           , B02_IDLEDFREGISTROB020 AS NRB02
           , CT_REGB025 AS B03_NMREG
           , B02_VLCONT AS VL_CONT_P
           , B02_VLBCISS AS VL_BC_ISS_P
           , SDFS_ALIQISS AS ALIQ_ISS
           , B02_VLISS AS VL_ISS_P
           , B02_VLISNTISS AS VL_ISNT_ISS_P
        FROM SPEDDOCFISSERV_SDFS, EFDLEDFMODELOESCRIT_LME, EFDLEDFREGISTROB020_B02
       WHERE SDFS_SQDOCFISSERV = B02_NRDOCFISSERV
         AND SDFS_CDEMPRESA = LME_CDEMPRESA
         AND SDFS_CDFILIAL = LME_CDFILIAL
         AND SDFS_DATAESCR >= LME_DTINI
         AND SDFS_DATAESCR <= LME_DTFIN
         AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO;
   TYPE TP_CS_REGB025 IS TABLE OF CS_REGB025%ROWTYPE
                            INDEX BY PLS_INTEGER;
   TB_CS_REGB025      TP_CS_REGB025;
BEGIN
   OPEN CS_REGB025;
   LOOP
      FETCH CS_REGB025
        BULK COLLECT INTO TB_CS_REGB025
      LIMIT 1000;
      EXIT WHEN TB_CS_REGB025.COUNT = 0;
      FORALL I IN TB_CS_REGB025.FIRST .. TB_CS_REGB025.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROB025_B03
         VALUES TB_CS_REGB025(I);
   END LOOP;
   CLOSE CS_REGB025;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGB025%ISOPEN
         THEN
            CLOSE CS_REGB025;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGB420(PT_IDMODESCRITURACAO IN NUMBER) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGB420         VARCHAR2(4) := 'B420';
   CURSOR CS_REGB420 IS
      SELECT SEQ1_EFDLEDFREGISTROB420_B06.NEXTVAL AS IDLEDFREGISTROB420
           , PT_IDMODESCRITURACAO
           , CT_REGB420
           , VL_CONT
           , VL_BC_ISS
           , ALIQ_ISS
           , VL_BC_ISS_RT
           , VL_RT
           , VL_ISNT_ISS
           , VL_ISS
        FROM (SELECT SUM(DECODE(B02_TPINDOPER, 1, B02_VLCONT, 0)) AS VL_CONT
                   , SUM(DECODE(B02_TPINDOPER, 1, B02_VLBCISS, 0)) AS VL_BC_ISS
                   , DECODE(B02_TPINDOPER, 1, B03_PEALIQISS, 0) AS ALIQ_ISS
                   , SUM(DECODE(B02_TPINDOPER, 1, B02_VLBCISSRT, 0)) AS VL_BC_ISS_RT
                   , SUM(DECODE(B02_TPINDOPER, 1, B02_VLISSRT, 0)) AS VL_RT
                   , SUM(DECODE(B02_TPINDOPER, 1, B02_VLISNTISS, 0)) AS VL_ISNT_ISS
                   , SUM(DECODE(B02_TPINDOPER, 1, B02_VLISS, 0)) AS VL_ISS
                FROM EFDLEDFREGISTROB020_B02, EFDLEDFREGISTROB025_B03
               WHERE B02_IDLEDFREGISTROB020 = B03_NRB02
                 AND B02_NRLME = PT_IDMODESCRITURACAO
              GROUP BY DECODE(B02_TPINDOPER, 1, B03_PEALIQISS, 0));
   TYPE TP_CS_REGB420 IS TABLE OF CS_REGB420%ROWTYPE
                            INDEX BY PLS_INTEGER;
   TB_CS_REGB420      TP_CS_REGB420;
BEGIN
   OPEN CS_REGB420;
   LOOP
      FETCH CS_REGB420
        BULK COLLECT INTO TB_CS_REGB420
      LIMIT 1000;
      EXIT WHEN TB_CS_REGB420.COUNT = 0;
      FORALL I IN TB_CS_REGB420.FIRST .. TB_CS_REGB420.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROB420_B06
         VALUES TB_CS_REGB420(I);
   END LOOP;
   CLOSE CS_REGB420;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGB420%ISOPEN
         THEN
            CLOSE CS_REGB420;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGB470(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGB470         VARCHAR2(4) := 'B470';
   CURSOR CS_REGB470 IS
      SELECT SEQ1_EFDLEDFREGISTROB470_B10.NEXTVAL AS IDLEDFREGISTROB470
           , PT_IDMODESCRITURACAO AS NRLME
           , CT_REGB470 AS REGB470
           , VL_CONT
           , VL_MAT_TERC
           , VL_MAT_PROP
           , VL_SUB
           , VL_ISNT
           , VL_DED_BC
           , VL_BC_ISS
           , VL_BC_ISS_RT
           , VL_ISS
           , VL_ISS_RT
           , VL_DED
           , VL_ISS_REC
           , VL_ISS_ST
           , VL_ISS_FIL
           , VL_ISS_RT_REC
        FROM (SELECT VL_CONT
                   , VL_MAT_TERC
                   , VL_MAT_PROP
                   , VL_SUB
                   , VL_ISNT
                   , VL_DED_BC
                   , VL_BC_ISS
                   , VL_BC_ISS_RT
                   , VL_ISS
                   , VL_ISS_RT
                   , VL_DED
                   , CASE WHEN ((VL_ISS - VL_ISS_RT - VL_DED) > 0) THEN (VL_ISS - VL_ISS_RT - VL_DED) ELSE 0 END AS VL_ISS_REC
                   , VL_ISS_ST
                   , VL_ISS_FIL
                   , VL_ISS_RT_REC
                FROM (SELECT NVL(SUM(DECODE(B02_TPINDOPER, 1, B02_VLCONT, 0)), 0) AS VL_CONT
                           , NVL(SUM(DECODE(B02_TPINDOPER, 1, B02_VLMATTERC, 0)), 0) AS VL_MAT_TERC
                           , 0 AS VL_MAT_PROP
                           , NVL(SUM(DECODE(B02_TPINDOPER, 1, B02_VLSUB, 0)), 0) AS VL_SUB
                           , NVL(SUM(DECODE(B02_TPINDOPER, 1, B02_VLISNTISS, 0)), 0) AS VL_ISNT
                           , NVL(SUM(DECODE(B02_TPINDOPER, 1, B02_VLMATTERC + B02_VLSUB + B02_VLISNTISS, 0)), 0) AS VL_DED_BC
                           , NVL(SUM(DECODE(B02_TPINDOPER, 1, B02_VLCONT - (B02_VLMATTERC + B02_VLSUB + B02_VLISNTISS), 0)), 0) AS VL_BC_ISS
                           , NVL(SUM(DECODE(B02_TPINDOPER, 1, B02_VLBCISSRT, 0)), 0) AS VL_BC_ISS_RT
                           , NVL(SUM(DECODE(B02_TPINDOPER, 1, B02_VLISS, 0)), 0) AS VL_ISS
                           , NVL(SUM(DECODE(B02_TPINDOPER, 1, B02_VLISSRT, 0)), 0) AS VL_ISS_RT
                           , NVL(SUM(DECODE(B02_TPINDOPER, 1, B02_VLDEDBC, 0)), 0) AS VL_DED
                           , NVL(SUM(DECODE(B02_TPINDOPER, 0, B02_VLISSRT, 0)), 0) AS VL_ISS_ST
                           , 0 AS VL_ISS_FIL
                           , 0 AS VL_ISS_RT_REC
                        FROM EFDLEDFREGISTROB020_B02, EFDLEDFREGISTROB025_B03
                       WHERE B02_IDLEDFREGISTROB020 = B03_NRB02
                         AND B02_NRLME = PT_IDMODESCRITURACAO));
   TYPE TP_CS_REGB470 IS TABLE OF CS_REGB470%ROWTYPE
                            INDEX BY PLS_INTEGER;
   TB_CS_REGB470      TP_CS_REGB470;
BEGIN
   OPEN CS_REGB470;
   LOOP
      FETCH CS_REGB470
        BULK COLLECT INTO TB_CS_REGB470
      LIMIT 1000;
      EXIT WHEN TB_CS_REGB470.COUNT = 0;
      FORALL I IN TB_CS_REGB470.FIRST .. TB_CS_REGB470.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROB470_B10
         VALUES TB_CS_REGB470(I);
   END LOOP;
   CLOSE CS_REGB470;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGB470%ISOPEN
         THEN
            CLOSE CS_REGB470;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCREGC020DIFAL(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGC020         VARCHAR2(4) := 'C020';
   CURSOR CS_REGC020 IS
      SELECT SEQ1_EFDLEDFREGISTROC020_C03.NEXTVAL AS IDLEDFREGISTROC020
           , PT_IDMODESCRITURACAO AS NRLME
           , CT_REGC020 AS REG020
           , IND_OPER
           , IND_EMIT
           , CLIFOR
           , COD_PART
           , COD_MOD
           , COD_SIT
           , SER
           , NUM_DOC
           , DT_DOC
           , DT_E_S
           , COD_NAT
           , VL_DOC
           , IND_PGTO
           , VL_DESC
           , VL_MERC
           , IND_FRT
           , VL_FRT
           , VL_SEG
           , VL_OUT_DA
           , VL_BC_ICMS
           , VL_ICMS
           , VL_BC_ST
           , VL_ST
           , VL_IPI
           , COD_INF_OBS
        FROM (SELECT DECODE(TPO_TIPO, 'E', '0', '1') AS IND_OPER
                   , DECODE(SDF_EMITENTE, 'P', '0', '1') AS IND_EMIT
                   , DECODE(SDF_SITDOC, '02', '', SDF_CLIFOR) AS CLIFOR
                   , DECODE(SDF_SITDOC, '02', '', TRIM(SDF_CDCLIFOR)) AS COD_PART
                   , SDF_MODELO AS COD_MOD
                   , NVL(SDF_SITDOC, '00') AS COD_SIT
                   , SDF_SERIE AS SER
                   , SDF_DOCUMENTO AS NUM_DOC
                   , TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY') AS DT_DOC
                   , DECODE(TPO_TIPO, 'E', TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'), TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')) AS DT_E_S
                   , MAX(SDF_TPOP) AS COD_NAT
                   , SUM(ROUND(SDF_VLTOTAL, 2)) AS VL_DOC
                   , DECODE(SDF_INDPAG, 2, 1, SDF_INDPAG) AS IND_PGTO
                   , SUM(ROUND(SDF_VLTOTDESC, 2)) AS VL_DESC
                   , SUM(ROUND(SDF_VLESPEC, 2)) AS VL_MERC
                   , DECODE(SDF_INDTPFRETE,  2, 1,  9, 0,  SDF_INDTPFRETE) AS IND_FRT
                   , SUM(ROUND(SDF_VLFRETE, 2)) AS VL_FRT
                   , SUM(ROUND(SDF_VLSEGUROS, 2)) AS VL_SEG
                   , SUM(ROUND(SDF_DESPESASAC, 2)) AS VL_OUT_DA
                   , SUM(ROUND(SDF_VLBCICMS, 2)) AS VL_BC_ICMS
                   , SUM(ROUND(SDF_VLICMS, 2)) AS VL_ICMS
                   , SUM(ROUND(SDF_VLBCICMSST, 2)) AS VL_BC_ST
                   , DECODE(TPO_TIPO, 'S', SUM(ROUND(IDF.IDF_VLICMSUFREMETENTE, 2)), SUM(ROUND(IDF.IDF_VLICMSUFDESTINO, 2))) AS VL_ST
                   , SUM(ROUND(SDF_VLIPI, 2)) AS VL_IPI
                   , 'DIFALEC87DF' AS COD_INF_OBS
                FROM SPEDDOCFIS_SDF
                   , TPOPER_TPO
                   , (SELECT SDF_SQDOCFIS AS SQDOCFIS
                           , SUM(IDF_VLICMSUFREMETENTE) AS IDF_VLICMSUFREMETENTE
                           , SUM(IDF_VLICMSUFDESTINO) AS IDF_VLICMSUFDESTINO
                        FROM SPEDDOCFIS_SDF, SPEDITDOCFIS_IDF, EFDLEDFMODELOESCRIT_LME
                       WHERE IDF_SQDOCFIS = SDF_SQDOCFIS
                         AND SDF_CDEMPRESA = LME_CDEMPRESA
                         AND SDF_CDFILIAL = LME_CDFILIAL
                         AND SDF_DATAESCR >= LME_DTINI
                         AND SDF_DATAESCR <= LME_DTFIN
                         AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                         AND SDF_MODELO IN ('01', '04', '55')
                         AND ((NVL(IDF_VLICMSUFDESTINO, 0) + NVL(IDF_VLICMSUFREMETENTE, 0)) > 0)
                         AND SDF_SITDOC <> '02'
                      GROUP BY SDF_SQDOCFIS) IDF
               WHERE SDF_TPOP = TPO_CODIGO
                 AND SDF_SQDOCFIS = IDF.SQDOCFIS
                 AND SDF_SQDOCFIS IN (SELECT DISTINCT SDF_SQDOCFIS
                                        FROM SPEDDOCFIS_SDF, SPEDITDOCFIS_IDF, EFDLEDFMODELOESCRIT_LME
                                       WHERE IDF_SQDOCFIS = SDF_SQDOCFIS
                                         AND SDF_CDEMPRESA = LME_CDEMPRESA
                                         AND SDF_CDFILIAL = LME_CDFILIAL
                                         AND SDF_DATAESCR >= LME_DTINI
                                         AND SDF_DATAESCR <= LME_DTFIN
                                         AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                                         AND SDF_MODELO IN ('01', '04', '55')
                                         AND ((NVL(IDF_VLICMSUFDESTINO, 0) + NVL(IDF_VLICMSUFREMETENTE, 0)) > 0)
                                         AND SDF_SITDOC <> '02')
              GROUP BY DECODE(TPO_TIPO, 'E', '0', '1')
                     , DECODE(SDF_EMITENTE, 'P', '0', '1')
                     , SDF_CLIFOR
                     , TRIM(SDF_CDCLIFOR)
                     , SDF_MODELO
                     , SDF_SITDOC
                     , SDF_SERIE
                     , SDF_DOCUMENTO
                     , TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')
                     , DECODE(TPO_TIPO, 'E', TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'), TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY'))
                     , DECODE(SDF_INDPAG, 2, 1, SDF_INDPAG)
                     , DECODE(SDF_INDTPFRETE,  2, 1,  9, 0,  SDF_INDTPFRETE)
                     , TPO_TIPO);
   TYPE TP_CS_REGC020 IS TABLE OF CS_REGC020%ROWTYPE
                            INDEX BY PLS_INTEGER;
   TB_CS_REGC020      TP_CS_REGC020;
BEGIN
   OPEN CS_REGC020;
   LOOP
      FETCH CS_REGC020
        BULK COLLECT INTO TB_CS_REGC020
      LIMIT 1000;
      EXIT WHEN TB_CS_REGC020.COUNT = 0;
      FORALL I IN TB_CS_REGC020.FIRST .. TB_CS_REGC020.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROC020_C03
         VALUES TB_CS_REGC020(I);
   END LOOP;
   CLOSE CS_REGC020;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGC020%ISOPEN
         THEN
            CLOSE CS_REGC020;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGE340(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGE340         VARCHAR2(4) := 'E340';
   CURSOR CS_REGE340 IS
      SELECT SEQ1_EFDLEDFREGISTROE340_E15.NEXTVAL AS IDLEDFREGISTROE340
           , PT_IDMODESCRITURACAO AS NRLME
           , CT_REGE340 AS REGE340
           , COD_AJ
           , VL_AJ
           , NUM_DA
           , NUM_PROC
           , IND_PROC
           , PROC
           , COD_INF_OBS
        FROM (SELECT CASE
                        WHEN SUI_UTILIZACAO = '0' THEN '199'
                        WHEN SUI_UTILIZACAO = '1' THEN '299'
                        WHEN SUI_UTILIZACAO = '2' THEN '499'
                        WHEN SUI_UTILIZACAO = '3' THEN '599'
                        WHEN SUI_UTILIZACAO = '4' THEN '699'
                        WHEN SUI_UTILIZACAO = '5' THEN '000'
                        ELSE TO_CHAR(SUI_UTILIZACAO)
                     END
                        AS COD_AJ
                   , SUM(SUI_VLAJUSTE) AS VL_AJ
                   , AAI_NRDOCARRECEST AS NUM_DA
                   , AAI_NRPROCAJUSTE AS NUM_PROC
                   , NVL(AAI_TPINDORIGPROCESSO, 9) AS IND_PROC
                   , AAI_DSPROCEMBLANC AS PROC
                   , COD_INF_OBS
                FROM (SELECT NVL(AAI_CDAJUSTAPUICMS, SUI_UTILIZACAO) AS SUI_UTILIZACAO
                           , NVL(AAI_VLAJUSTAPUICMS, SUI_VLAJUSTE) AS SUI_VLAJUSTE
                           , AAI_NRDOCARRECEST
                           , AAI_NRPROCAJUSTE
                           , AAI_TPINDORIGPROCESSO
                           , AAI_DSPROCEMBLANC
                           , SUI_UTILIZACAO AS COD_INF_OBS
                        FROM SPEDAPUICMS_SAI
                           , SPEDAJAPUICMS_SUI
                           , EFDLEDFMODELOESCRIT_LME
                           , EFDLEDFAJUSTAPUICMS_AAI
                       WHERE SAI_SQAPUICMS = SUI_SQAPUICMS
                         AND SAI_CDEMPRESA = LME_CDEMPRESA
                         AND SAI_CDFILIAL = LME_CDFILIAL
                         AND SAI_DATAINI >= LME_DTINI
                         AND SAI_DATAFIM <= LME_DTFIN
                         AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                         AND SUI_SQAJAPUICMS = AAI_NRSUI(+))
              GROUP BY SUI_UTILIZACAO
                     , AAI_NRDOCARRECEST
                     , AAI_NRPROCAJUSTE
                     , AAI_TPINDORIGPROCESSO
                     , AAI_DSPROCEMBLANC
                     , COD_INF_OBS
              ORDER BY 1);
   TYPE TP_CS_REGE340 IS TABLE OF CS_REGE340%ROWTYPE INDEX BY PLS_INTEGER;
   TB_CS_REGE340      TP_CS_REGE340;
BEGIN
   OPEN CS_REGE340;
   LOOP
      FETCH CS_REGE340
        BULK COLLECT INTO TB_CS_REGE340 LIMIT 1000;
      EXIT WHEN TB_CS_REGE340.COUNT = 0;
      FORALL I IN TB_CS_REGE340.FIRST .. TB_CS_REGE340.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROE340_E15 VALUES TB_CS_REGE340(I);
   END LOOP;
   CLOSE CS_REGE340;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGE340%ISOPEN
         THEN
            CLOSE CS_REGE340;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGE360(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGE360         VARCHAR2(4) := 'E360';
   CURSOR CS_REGE360 IS
      SELECT SEQ1_EFDLEDFREGISTROE360_E17.NEXTVAL AS IDLEDFREGISTROE360
           , PT_IDMODESCRITURACAO AS NRLME
           , CT_REGE360 AS REGE360
           , VL_01
           , VL_02
           , VL_03
           , VL_04
           , VL_05
           , VL_06
           , VL_07
           , VL_08
           , VL_09
           , VL_10
           , VL_11
           , VL_12
           , VL_13
           , DECODE(VL_12 - VL_13, ABS(VL_12 - VL_13), VL_12 - VL_13, 0) AS VL_14
           , VL_15
           , VL_16
           , NVL(VL_17, 0) AS VL_17
           , VL_18
           , VL_19
           , DECODE(VL_12 - VL_13, ABS(VL_12 - VL_13), VL_12 - VL_13, 0) + NVL(VL_17, 0) + VL_18 + VL_19 + VL_20 AS VL_20
           , VL_99
        FROM (SELECT SUM(VL_01) AS VL_01
                   , SUM(VL_02) AS VL_02
                   , SUM(VL_03) AS VL_03
                   , SUM(VL_01 + VL_02 + VL_03) AS VL_04
                   , SUM(VL_05) AS VL_05
                   , SUM(VL_06) AS VL_06
                   , SUM(VL_07) AS VL_07
                   , SUM(VL_05 + VL_06 + VL_07) AS VL_08
                   , SUM(VL_09) AS VL_09
                   , SUM(VL_05 + VL_06 + VL_07 + VL_09) AS VL_10
                   , DECODE(
                        SUM((VL_05 + VL_06 + VL_07 + VL_09) - (VL_01 + VL_02 + VL_03))
                      , ABS(SUM((VL_05 + VL_06 + VL_07 + VL_09) - (VL_01 + VL_02 + VL_03))), SUM(
                                                                                                (VL_05 + VL_06 + VL_07 + VL_09) -
                                                                                                (VL_01 + VL_02 + VL_03))
                      , 0)
                        AS VL_11
                   , DECODE(
                        SUM((VL_01 + VL_02 + VL_03) - (VL_05 + VL_06 + VL_07 + VL_09))
                      , ABS(SUM((VL_01 + VL_02 + VL_03) - (VL_05 + VL_06 + VL_07 + VL_09))), SUM(
                                                                                                (VL_01 + VL_02 + VL_03) -
                                                                                                (VL_05 + VL_06 + VL_07 + VL_09))
                      , 0)
                        AS VL_12
                   , SUM(VL_13) AS VL_13
                   , SUM(VL_15) AS VL_15
                   , SUM(VL_16) AS VL_16
                   , SUM(VL_17) AS VL_17
                   , SUM(VL_18) AS VL_18
                   , SUM(VL_19) AS VL_19
				   , SUM(VL_20) AS VL_20
                   , SUM(VL_15 + VL_16) AS VL_99
                FROM (SELECT VL_01
                           , VL_02
                           , VL_03
                           , VL_05
                           , VL_06
                           , VL_07
                           , VL_09
                           , VL_13
                           , VL_15
						   , CASE WHEN (E330_VL_ST > E350_VL_OR) THEN (E330_VL_ST - E350_VL_OR) WHEN (E330_VL_ST = E350_VL_OR) THEN 0 ELSE 0 END AS VL_16
                           , VL_17
                           , VL_18
                           , VL_19
						   , VL_20
                        FROM (SELECT NVL(SUM(DECODE(E02_TPINDOPER, 1, E02_VLICMS, 0)), 0) AS VL_01
                                   , 0 AS VL_02
                                   , 0 AS VL_03
                                   , NVL(SUM(DECODE(E02_TPINDOPER, 0, E02_VLICMS, 0)), 0) AS VL_05
                                   , 0 AS VL_06
                                   , 0 AS VL_07
                                   , 0 AS VL_09
                                   , 0 AS VL_13
                                   , NVL(SUM(DECODE(E02_TPINDOPER, 0, E02_VLST, 0)), 0) AS VL_15
                                   , NVL(SUM(DECODE(E02_TPINDOPER, 1, E02_VLST, 0)), 0) AS VL_16
                                   , 0 AS VL_17
                                   , 0 AS VL_18
                                   , 0 AS VL_19
								   , 0 AS VL_20
                                FROM EFDLEDFREGISTROE020_E02
                               WHERE E02_NRLME = PT_IDMODESCRITURACAO)
                           , (SELECT SUM(E14_VLST) AS E330_VL_ST
                                FROM EFDLEDFREGISTROE330_E14
                               WHERE E14_TPINDTOT IN (4, 8)
                                 AND E14_NRLME = PT_IDMODESCRITURACAO)
                           , (SELECT SUM(E16_VLOR) AS E350_VL_OR
                                FROM EFDLEDFREGISTROE350_E16
                               WHERE E16_CDOR = '020'
                                 AND E16_NRLME = PT_IDMODESCRITURACAO)
                      UNION ALL
                      SELECT NVL(SUM(DECODE(E10_TPINDOPER, 1, E10_VLICMS, 0)), 0) AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , NVL(SUM(DECODE(E10_TPINDOPER, 0, E10_VLICMS, 0)), 0) AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
						   , 0 AS VL_20
                        FROM EFDLEDFREGISTROE120_E10
                       WHERE E10_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT NVL(SUM(E07_VLICMSP), 0) AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , 0 AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
						   , 0 AS VL_20
                        FROM EFDLEDFREGISTROE085_E07
                       WHERE E07_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT NVL(SUM(DECODE(E08_TPINDOPER, 1, E08_VLICMS, 0)), 0) AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , NVL(SUM(DECODE(E08_TPINDOPER, 0, E08_VLICMS, 0)), 0) AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
						   , 0 AS VL_20
                        FROM EFDLEDFREGISTROE100_E08
                       WHERE E08_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT 0 AS VL_01
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '1', E15_VLAJ, 0)), 0) AS VL_02
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '2', E15_VLAJ, 0)), 0) AS VL_03
                           , 0 AS VL_05
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '4', E15_VLAJ, 0)), 0) AS VL_06
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '5', E15_VLAJ, 0)), 0) AS VL_07
                           , 0 AS VL_09
                           , NVL(SUM(DECODE(SUBSTR(E15_CDAJ, 1, 1), '6', E15_VLAJ, 0)), 0) AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
						   , 0 AS VL_20
                        FROM EFDLEDFREGISTROE340_E15
                       WHERE E15_NRLME = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT 0 AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , 0 AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , CRA.CRA_VLSALDO AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , 0 AS VL_17
                           , 0 AS VL_18
                           , 0 AS VL_19
						   , 0 AS VL_20
                        FROM SPEDSALCREDANT_CRA CRA, EFDLEDFMODELOESCRIT_LME LME
                       WHERE CRA.CRA_TPIMPOSTO = '0'
                         AND CRA.CRA_CDEMPRESA = LME.LME_CDEMPRESA
                         AND CRA.CRA_CDFILIAL = LME.LME_CDFILIAL
                         AND CRA.CRA_PERIODO + 1 = LME.LME_DTINI
                         AND LME.LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
                      UNION ALL
                      SELECT 0 AS VL_01
                           , 0 AS VL_02
                           , 0 AS VL_03
                           , 0 AS VL_05
                           , 0 AS VL_06
                           , 0 AS VL_07
                           , 0 AS VL_09
                           , 0 AS VL_13
                           , 0 AS VL_15
                           , 0 AS VL_16
                           , SUM(DECODE(OIR_CDOBRIGACAO, '020', OIR_VLOBRIGACAO, 0)) AS VL_17
                           , SUM(DECODE(OIR_CDOBRIGACAO, '004', OIR_VLOBRIGACAO, 0)) AS VL_18
						   , SUM(DECODE(OIR_CDOBRIGACAO, '005', OIR_VLOBRIGACAO, 0)) AS VL_19
						   , SUM(DECODE(OIR_CDOBRIGACAO, '999', OIR_VLOBRIGACAO, 0)) AS VL_20
                        FROM (SELECT DECODE(SAI_ICMSTPOPERACAO, 3, DECODE(SAI_UF, 'DF', '020', '999'), OIR_CDOBRIGACAO) AS OIR_CDOBRIGACAO
                                   , OIR_VLOBRIGACAO
                                FROM SPEDAPUICMS_SAI, SPEDOBICMSREC_OIR, EFDLEDFMODELOESCRIT_LME
                               WHERE SAI_SQAPUICMS = OIR_SQAPUICMS
                                 AND SAI_CDEMPRESA = LME_CDEMPRESA
                                 AND SAI_CDFILIAL = LME_CDFILIAL
                                 AND SAI_DATAINI >= LME_DTINI
                                 AND SAI_DATAFIM <= LME_DTFIN
                                 AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO)));
   TYPE TP_CS_REGE360 IS TABLE OF CS_REGE360%ROWTYPE
                            INDEX BY PLS_INTEGER;
   TB_CS_REGE360      TP_CS_REGE360;
BEGIN
   OPEN CS_REGE360;
   LOOP
      FETCH CS_REGE360
        BULK COLLECT INTO TB_CS_REGE360
      LIMIT 100;
      EXIT WHEN TB_CS_REGE360.COUNT = 0;
      FORALL I IN TB_CS_REGE360.FIRST .. TB_CS_REGE360.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROE360_E17
         VALUES TB_CS_REGE360(I);
   END LOOP;
   CLOSE CS_REGE360;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGE360%ISOPEN
         THEN
            CLOSE CS_REGE360;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 270632
PROMPT ======================================================================