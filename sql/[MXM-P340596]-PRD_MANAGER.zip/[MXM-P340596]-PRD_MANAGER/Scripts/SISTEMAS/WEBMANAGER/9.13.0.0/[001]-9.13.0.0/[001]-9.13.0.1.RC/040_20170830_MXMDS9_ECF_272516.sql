PROMPT ======================================================================
PROMPT == DEMANDA......: 272516
PROMPT == SISTEMA......: Escrituracao Contabil Fiscal
PROMPT == RESPONSAVEL..: DEBORAH EVELYN MOREIRA DA ROCHA
PROMPT == DATA.........: 31/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM SPEDVERSOESLAYOUT_SVL WHERE SVL_CDLEIAUTE = 'ECF_003' AND SVL_TPLEIAUTE = '6' AND SVL_CDSISTEMA = 'ECF'
/

INSERT INTO SPEDVERSOESLAYOUT_SVL
  (SVL_IDVERSAOLAYOUT,
   SVL_CDLEIAUTE,
   SVL_LEIAUTE,
   SVL_TPLEIAUTE,
   SVL_CDSISTEMA,
   SVL_DTINICIO,
   SVL_DTCADASTRO,
   SVL_USUARIO,
   SVL_CDLAYOUT,
   SVL_CDVERSAO,
   SVL_DTFIM)
VALUES
  (SEQ_SPEDLEIAUTE_SVL.NEXTVAL,
   'ECF_003',
   'ECF VERS�O 003',
   '6',
   'ECF',
   TO_DATE('01/01/2016', 'DD/MM/RRRR'),
   SYSDATE,
   GET_USER_MXM,
   'ECF3',
   '0003',
   NULL)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 272516
PROMPT ======================================================================