PROMPT ======================================================================
PROMPT == DEMANDA......: 278336
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: RODRIGO FERRAZ DE MEDEIROS
PROMPT == DATA.........: 09/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE ACRDEC_ACD ADD ACD_NRRTA NUMBER
/

COMMENT ON COLUMN ACRDEC_ACD.ACD_NRRTA
  IS 'REFERENCIA DA TIPAGEM DE CALCULO ADICIONAL'
/

CREATE INDEX IN1_ACRDEC_ACD ON ACRDEC_ACD (ACD_NRRTA)
/

ALTER TABLE ACRDEC_ACD ADD CONSTRAINT FK1_ACRDEC_ACD FOREIGN KEY (ACD_NRRTA) REFERENCES RNFINTTPCALCADIC_RTA (RTA_IDRTA)
/

CREATE OR REPLACE PROCEDURE INSACRDEC_ACD
  (
   ACC_CODIGO           IN CHAR,
   ACC_DESCRICAO        IN CHAR,
   ACC_ACRDEC           IN CHAR,
   ACC_PORFORA          IN CHAR,
   ACC_GERACUSTO        IN CHAR,
   ACC_IICM             IN CHAR,
   ACC_IIPI             IN CHAR,
   ACC_IISS             IN CHAR,
   ACC_BICM             IN CHAR,
   ACC_BIPI             IN CHAR,
   ACC_BISS             IN CHAR,
   ACC_BCONFINS         IN CHAR,
   ACC_BIIMPORT         IN CHAR,
   ACC_BFTI             IN CHAR,
   ACC_BPIS             IN CHAR,
   ACC_SUFRAMA          IN CHAR,
   ACC_CUSTOENTRADA     IN CHAR,
   ACC_BCOMISS          IN CHAR,
   ACC_TPRATITEM        IN CHAR,
   ACC_TIPO             IN CHAR,
   ACC_INCIDEFINANC     IN CHAR,
   ACC_BIRRF            IN CHAR DEFAULT NULL,
   ACC_BINSS            IN CHAR DEFAULT NULL,
   ACC_BINSSI           IN CHAR DEFAULT NULL,
   ACC_BSEST            IN CHAR DEFAULT NULL,
   ACC_BCSOCIAL         IN CHAR DEFAULT NULL,
   ACC_DISCRIMINAFINANC IN CHAR DEFAULT NULL,
   ACC_SUBTRIB          IN CHAR DEFAULT NULL,
   ACC_DESPADU          IN CHAR,
   ACC_NRRTA            NUMBER
   )
AS
BEGIN
   INSERT INTO ACRDEC_ACD
    (
     ACD_CODIGO,
     ACD_DESCRICAO,
     ACD_ACRDEC,
     ACD_PORFORA,
     ACD_GERACUSTO,
     ACD_IICM,
     ACD_IIPI,
     ACD_IISS,
     ACD_BICM,
     ACD_BIPI,
     ACD_BISS,
     ACD_BCONFINS,
     ACD_BIIMPORT,
     ACD_BFTI,
     ACD_BPIS,
     ACD_SUFRAMA,
     ACD_CUSTOENTRADA,
     ACD_BCOMISS,
     ACD_TPRATITEM,
     ACD_TIPO,
     ACD_INCIDEFINANC,
     ACD_BIRRF,
     ACD_BINSS,
     ACD_BINSSI,
     ACD_BSEST,
     ACD_BCSOCIAL,
     ACD_DISCRIMINAFINANC,
     ACD_SUBTRIB,
     ACD_DESPADU,
     ACD_NRRTA
    )
   VALUES
    (
     ACC_CODIGO,
     ACC_DESCRICAO,
     ACC_ACRDEC,
     ACC_PORFORA,
     ACC_GERACUSTO,
     ACC_IICM,
     ACC_IIPI,
     ACC_IISS,
     ACC_BICM,
     ACC_BIPI,
     ACC_BISS,
     ACC_BCONFINS,
     ACC_BIIMPORT,
     ACC_BFTI,
     ACC_BPIS,
     ACC_SUFRAMA,
     ACC_CUSTOENTRADA,
     ACC_BCOMISS,
     ACC_TPRATITEM,
     ACC_TIPO,
     ACC_INCIDEFINANC,
     ACC_BIRRF,
     ACC_BINSS,
     ACC_BINSSI,
     ACC_BSEST,
     ACC_BCSOCIAL,
     ACC_DISCRIMINAFINANC,
     ACC_SUBTRIB,
     ACC_DESPADU,
     ACC_NRRTA
    );
END;
/

CREATE OR REPLACE PROCEDURE ALTACRDEC_ACD
  (
   PACD_CODIGO           IN CHAR,
   PACD_DESCRICAO        IN CHAR,
   PACD_ACRDEC           IN CHAR,
   PACD_PORFORA          IN CHAR,
   PACD_IICM             IN CHAR,
   PACD_IIPI             IN CHAR,
   PACD_IISS             IN CHAR,
   PACD_BICM             IN CHAR,
   PACD_BIPI             IN CHAR,
   PACD_BISS             IN CHAR,
   PACD_BCONFINS         IN CHAR,
   PACD_BIIMPORT         IN CHAR,
   PACD_BFTI             IN CHAR,
   PACD_BPIS             IN CHAR,
   PACD_GERACUSTO        IN CHAR,
   PACD_SUFRAMA          IN CHAR,
   PACD_EXP              IN CHAR,
   PACD_CUSTOENTRADA     IN CHAR,
   PACD_BCOMISS          IN CHAR,
   PACD_TPRATITEM        IN CHAR,
   PACD_TIPO             IN CHAR,
   PACD_INCIDEFINANC     IN CHAR,
   PACD_BIRRF            IN CHAR DEFAULT NULL,
   PACD_BINSS            IN CHAR DEFAULT NULL,
   PACD_BINSSI           IN CHAR DEFAULT NULL,
   PACD_BSEST            IN CHAR DEFAULT NULL,
   PACD_BCSOCIAL         IN CHAR DEFAULT NULL,
   PACD_DISCRIMINAFINANC IN CHAR DEFAULT NULL,
   PACD_SUBTRIB          IN CHAR DEFAULT NULL,
   PACD_DESPADU          IN CHAR,
   PACD_NRRTA            IN NUMBER
  )
AS
BEGIN
  UPDATE ACRDEC_ACD
   SET ACD_DESCRICAO        = PACD_DESCRICAO,
       ACD_ACRDEC           = PACD_ACRDEC,
       ACD_PORFORA          = PACD_PORFORA,
       ACD_IICM             = PACD_IICM ,
       ACD_IIPI             = PACD_IIPI,
       ACD_IISS             = PACD_IISS,
       ACD_BICM             = PACD_BICM,
       ACD_BIPI             = PACD_BIPI,
       ACD_BISS             = PACD_BISS,
       ACD_BCONFINS         = PACD_BCONFINS,
       ACD_BIIMPORT         = PACD_BIIMPORT,
       ACD_BFTI             = PACD_BFTI,
       ACD_BPIS             = PACD_BPIS,
       ACD_GERACUSTO        = PACD_GERACUSTO,
       ACD_SUFRAMA          = PACD_SUFRAMA,
       ACD_EXP              = NULL,
       ACD_CUSTOENTRADA     = PACD_CUSTOENTRADA,
       ACD_BCOMISS          = PACD_BCOMISS,
       ACD_TPRATITEM        = PACD_TPRATITEM,
       ACD_TIPO             = PACD_TIPO,
       ACD_INCIDEFINANC     = PACD_INCIDEFINANC,
       ACD_BIRRF            = PACD_BIRRF,
       ACD_BINSS            = PACD_BINSS,
       ACD_BINSSI           = PACD_BINSSI,
       ACD_BSEST            = PACD_BSEST,
       ACD_BCSOCIAL         = PACD_BCSOCIAL,
       ACD_DISCRIMINAFINANC = PACD_DISCRIMINAFINANC,
       ACD_SUBTRIB          = PACD_SUBTRIB,
       ACD_DESPADU          = PACD_DESPADU,
       ACD_NRRTA            = PACD_NRRTA
  WHERE ACD_CODIGO = PACD_CODIGO;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 278336
PROMPT ======================================================================