PROMPT ======================================================================
PROMPT == DEMANDA......: 274819
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: RODRIGO DA PAZ DO NASCIMENTO
PROMPT == DATA.........: 13/07/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRETABELARELVISAL_TRV
   SET TRV_NMCONDICAOTABREL = 'TPOPER_TPO.TPO_DETALHAMENTO = GRTPOP_GTO.GTO_CODIGO(+)'
 WHERE TRV_NRVISAO = (SELECT VDR_IDVISAO
                        FROM GREVISAOTAB_VDR
                       WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA
                                                FROM GRETABDICDADOS_TDR
                                               WHERE TDR_NMTABELA = 'TPOPER_TPO'))
  AND TRV_NRTABELA = (SELECT TDR_IDTABELA
                          FROM GRETABDICDADOS_TDR
                         WHERE TDR_NMTABELA = 'GRTPOP_GTO')
  AND TRV_NMCONDICAOTABREL = 'TPOPER_TPO.TPO_DETALHAMENTO = GRTPOP_GTO.GTO_CODIGO'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 274819
PROMPT ======================================================================