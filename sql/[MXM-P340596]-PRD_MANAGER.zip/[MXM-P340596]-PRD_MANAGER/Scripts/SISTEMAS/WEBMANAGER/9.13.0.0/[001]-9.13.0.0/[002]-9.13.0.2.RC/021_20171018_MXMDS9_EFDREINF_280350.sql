PROMPT ======================================================================
PROMPT == DEMANDA......: 280350
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: VANDERSON LOPES GUIDI
PROMPT == DATA.........: 17/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (35314, 'Apura��o da contribui��o previd�nci�ria sobre a receita bruta', 'Apura��o da contribui��o previd�nci�ria sobre a receita bruta')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('EFDREINF', 35314, 1, 3000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35314, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35314, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35314, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280350
PROMPT ======================================================================