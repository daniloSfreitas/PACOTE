PROMPT ======================================================================
PROMPT == DEMANDA......: 275798
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: WALTER FERREIRA NETO
PROMPT == DATA.........: 28/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GREFILTROCAMPOTAB_FCT
   SET FCT_NMLISTACONDICAOAJUDA = 'USUEMP('''', EEN_CODIGO, EEN_CDEND) = ''S'''
 WHERE UPPER (FCT_DSFILTRO) = 'FILIAL'
   AND FCT_TABELARELVISAO IN (
          SELECT TRV_IDTABELARELVISAO
            FROM GRETABELARELVISAL_TRV
           WHERE TRV_NRVISAO IN (
                    SELECT VDR_IDVISAO
                      FROM GREVISAOTAB_VDR
                     WHERE VDR_NRTABELA IN (
                              SELECT TDR_IDTABELA
                                FROM GRETABDICDADOS_TDR
                               WHERE TDR_NMTABELA IN
                                        ('TITCP_TCP', 'ANTECCP_ACP',
                                         'TITCR_TCR', 'ANTECIP_ANT',
                                         'MOVIST_MST', 'CONTRATOCO_CONC')))
             AND TRV_NRTABELA = (SELECT TDR_IDTABELA
                                   FROM GRETABDICDADOS_TDR
                                  WHERE UPPER (TDR_NMTABELA) = 'EMPEND'))
/

UPDATE GREFILTROCAMPOTAB_FCT
   SET FCT_NMLISTACONDICAOAJUDA =
                                 'USUEMP('''', EEN_CODIGO, EEN_CDEND) = ''S'''
 WHERE UPPER (FCT_DSFILTRO) = 'FILIAL'
   AND FCT_TABELARELVISAO IN (
          SELECT TRV_IDTABELARELVISAO
            FROM GRETABELARELVISAL_TRV
           WHERE TRV_NRVISAO IN (
                    SELECT VDR_IDVISAO
                      FROM GREVISAOTAB_VDR
                     WHERE VDR_NRTABELA IN (
                                       SELECT TDR_IDTABELA
                                         FROM GRETABDICDADOS_TDR
                                        WHERE TDR_NMTABELA IN
                                                            ('PEDCOMPRA_PEC')))
             AND TRV_NRTABELA = (SELECT TDR_IDTABELA
                                   FROM GRETABDICDADOS_TDR
                                  WHERE UPPER (TDR_NMTABELA) = 'EMPEND_EEN'))
/

UPDATE GREFILTROCAMPOTAB_FCT
   SET FCT_NMARQUIVOAJUDA = 'EMPEND_EEN'
 WHERE UPPER (FCT_DSFILTRO) = 'FILIAL'
   AND FCT_TABELARELVISAO IN (
          SELECT TRV_IDTABELARELVISAO
            FROM GRETABELARELVISAL_TRV
           WHERE TRV_NRVISAO IN (
                    SELECT VDR_IDVISAO
                      FROM GREVISAOTAB_VDR
                     WHERE VDR_NRTABELA IN (
                                     SELECT TDR_IDTABELA
                                       FROM GRETABDICDADOS_TDR
                                      WHERE TDR_NMTABELA IN
                                                          ('CONTRATOCO_CONC')))
             AND TRV_NRTABELA = (SELECT TDR_IDTABELA
                                   FROM GRETABDICDADOS_TDR
                                  WHERE UPPER (TDR_NMTABELA) = 'EMPEND'))
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 275798
PROMPT ======================================================================