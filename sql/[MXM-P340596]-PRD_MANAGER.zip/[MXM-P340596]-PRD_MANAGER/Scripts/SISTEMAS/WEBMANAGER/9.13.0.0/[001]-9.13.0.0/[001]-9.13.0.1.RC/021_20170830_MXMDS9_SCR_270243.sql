PROMPT ======================================================================
PROMPT == DEMANDA......: 270243
PROMPT == SISTEMA......: Contas a Receber
PROMPT == RESPONSAVEL..: GABRIEL SPINOLA TRINDADE MARINHO
PROMPT == DATA.........: 16/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

alter table TI_ARQPEDVENDA_TAPV add TAPV_DTBASEVENCIM varchar2(8)
/

comment on column TI_ARQPEDVENDA_TAPV.TAPV_DTBASEVENCIM
  is 'Data Base do Vencimento'
/

ALTER TABLE PEDVENDA_PDV ADD PDV_DTBASEVENCIMENTO DATE
/

COMMENT ON COLUMN PEDVENDA_PDV.PDV_DTBASEVENCIMENTO IS 'Data base do vencimento'
/

CREATE OR REPLACE PROCEDURE INSPEDVENDA_PDV(PPDV_CDEMPRESA IN CHAR,
                                            PPDV_CDFILIAL IN CHAR,
                                            PPDV_PEDIDO IN OUT NUMBER,
                                            PPDV_ORDCOMPRA IN CHAR,
                                            PPDV_DATA IN DATE,
                                            PPDV_PENTREGA IN DATE,
                                            PPDV_CDCLIENTE IN CHAR,
                                            PPDV_CDENDFAT IN CHAR,
                                            PPDV_CDENDENTR IN CHAR,
                                            PPDV_CDENDCOBR IN CHAR,
                                            PPDV_VENDEDOR1 IN CHAR,
                                            PPDV_VENDEDOR2 IN CHAR,
                                            PPDV_CONDPAGTO IN CHAR,
                                            PPDV_TPCOBRANCA IN CHAR,
                                            PPDV_GERACREC IN CHAR,
                                            PPDV_PESOBRUTO IN NUMBER,
                                            PPDV_PESOLIQUI IN NUMBER,
                                            PPDV_TPOPER IN CHAR,
                                            PPDV_TIPOVENDA IN CHAR,
                                            PPDV_OBS IN CHAR,
                                            PPDV_DTLIBFIN IN DATE,
                                            PPDV_USULIBFIN IN CHAR,
                                            PPDV_DATADIG IN DATE,
                                            PPDV_USUARIO IN CHAR,
                                            PPDV_NOTITULO IN CHAR,
                                            PPDV_MOEDA IN CHAR,
                                            PPDV_QTPROD IN NUMBER,
                                            PPDV_TOTPROD IN NUMBER,
                                            PPDV_PDESCONTO IN NUMBER,
                                            PPDV_DESCONTO IN NUMBER,
                                            PPDV_FRETE IN NUMBER,
                                            PPDV_SEGURO IN NUMBER,
                                            PPDV_ACRES IN NUMBER,
                                            PPDV_IPI IN NUMBER,
                                            PPDV_ISSNINCL IN NUMBER,
                                            PPDV_TOTPED IN NUMBER,
                                            PPDV_ICMS IN NUMBER,
                                            PPDV_PISCOFINS IN NUMBER,
                                            PPDV_IR IN NUMBER,
                                            PPDV_ISSINCL IN NUMBER,
                                            PPDV_ADMOPER IN NUMBER,
                                            PPDV_COMISSAO IN NUMBER,
                                            PPDV_OUTROS IN NUMBER,
                                            PPDV_TOTLIQ IN NUMBER,
                                            PPDV_PERDESCENC IN NUMBER,
                                            PPDV_VLRDESCENC IN NUMBER,
                                            PPDV_TPFAT IN CHAR,
                                            PPDV_TPESTOQUE IN CHAR,
                                            PPDV_TPENTR IN CHAR,
                                            PPDV_TRANSPORTADORA IN CHAR,
                                            PPDV_ADIANTAMENTO IN NUMBER,
                                            PPDV_CDNATSERV IN CHAR,
                                            PPDV_DESCNATSERV IN CHAR,
                                            PPDV_SYSTEM IN CHAR,
                                            PPDV_VIA IN NUMBER,
                                            PPDV_MENSFAT IN CHAR,
                                            PPDV_MENSFAT2 IN CHAR,
                                            PPDV_MENSFAT3 IN CHAR,
                                            PPDV_NATUREZA IN CHAR,
                                            PPDV_PLACAVEIC IN CHAR,
                                            PPDV_UFTRANSP IN CHAR,
                                            PPDV_MARCA IN CHAR,
                                            PPDV_NUMERO IN CHAR,
                                            PPDV_QUANTIDADE IN NUMBER,
                                            PPDV_ESPECIE IN CHAR,
                                            PPDV_REDESP1 IN CHAR,
                                            PPDV_REDESP2 IN CHAR,
                                            PPDV_CANALDEVENDA IN CHAR,
                                            PPDV_OBSPED IN CHAR,
                                            PPDV_DESCRSERV IN CHAR,
                                            PPDV_TOTVOLUME IN NUMBER,
                                            PPDV_EXP IN CHAR,
                                            PPDV_UNIDNEG IN CHAR,
                                            PPDV_REFEMPRESA IN CHAR,
                                            PPDV_REFCLIENTE IN CHAR,
                                            PPDV_INSTALACAO IN CHAR,
                                            PPDV_CDPROMOCAO IN CHAR,
                                            PPDV_QTDPROMOCAO IN NUMBER,
                                            PPDV_VRSUFRAMA IN NUMBER,
                                            PPDV_CUSTOFRETE IN NUMBER,
                                            PPDV_PESOINFCALC IN CHAR,
                                            PPDV_CDALMOX IN CHAR,
                                            PPDV_MUNICIPIOTRANSP IN CHAR,
                                            PPDV_NATUREZACARGA IN CHAR,
                                            PPDV_FATURAR IN CHAR DEFAULT NULL,
                                            PPDV_GERAMINUTA IN CHAR DEFAULT 'N', -- NOVO CAMPO DEMANDA 15021
                                            PPDV_VBUTILADIANT IN NUMBER,
                                            PPDV_CDCATALOGO IN CHAR,
                                            PPDV_VLBONIFICADO IN NUMBER,
                                            PPDV_VLRSUFRAMA IN NUMBER,
                                            PPDV_VLRSUBST IN NUMBER,
                                            PPDV_VLRPMC IN NUMBER,
                                            PPDV_CLIFINAL IN CHAR DEFAULT NULL,
                                            PPDV_CONTRATO IN CHAR DEFAULT NULL,
                                            PPDV_CDORCAMENTO IN NUMBER,
                                            PPDV_DTBASEVENCIMENTO IN DATE) AS
  REPEAT BOOLEAN;
  DUMMY CHAR;
BEGIN
  IF PPDV_PEDIDO = 0 OR PPDV_PEDIDO IS NULL THEN
    REPEAT := TRUE;
    WHILE REPEAT LOOP
      --
      SELECT PDV_SEQUENCIA.NEXTVAL INTO PPDV_PEDIDO FROM DUAL;
      --
      BEGIN
        SELECT 'X'
          INTO DUMMY
          FROM PEDVENDA_PDV
         WHERE PDV_CDEMPRESA = PPDV_CDEMPRESA
           AND PDV_CDFILIAL = PPDV_CDFILIAL
           AND PDV_PEDIDO = PPDV_PEDIDO;
        REPEAT := TRUE;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          REPEAT := FALSE;
        WHEN OTHERS THEN
          RAISE;
      END;
    --
    END LOOP;
  END IF;
  INSERT INTO PEDVENDA_PDV
    (PDV_CDEMPRESA,
     PDV_CDFILIAL,
     PDV_PEDIDO,
     PDV_ORDCOMPRA,
     PDV_DATA,
     PDV_PENTREGA,
     PDV_CDCLIENTE,
     PDV_CDENDFAT,
     PDV_CDENDENTR,
     PDV_CDENDCOBR,
     PDV_VENDEDOR1,
     PDV_VENDEDOR2,
     PDV_CONDPAGTO,
     PDV_TPCOBRANCA,
     PDV_GERACREC,
     PDV_PESOBRUTO,
     PDV_PESOLIQUI,
     PDV_TPOPER,
     PDV_TIPOVENDA,
     PDV_OBS,
     PDV_DTLIBFIN,
     PDV_USULIBFIN,
     PDV_DTINC,
     PDV_USERINC,
     PDV_DATADIG,
     PDV_USUARIO,
     PDV_NOTITULO,
     PDV_MOEDA,
     PDV_QTPROD,
     PDV_TOTPROD,
     PDV_PDESCONTO,
     PDV_DESCONTO,
     PDV_FRETE,
     PDV_SEGURO,
     PDV_ACRES,
     PDV_IPI,
     PDV_ISSNINCL,
     PDV_TOTPED,
     PDV_ICMS,
     PDV_PISCOFINS,
     PDV_IR,
     PDV_ISSINCL,
     PDV_ADMOPER,
     PDV_COMISSAO,
     PDV_OUTROS,
     PDV_TOTLIQ,
     PDV_PERDESCENC,
     PDV_VLRDESCENC,
     PDV_TPFAT,
     PDV_TPENTR,
     PDV_TRANSPORTADORA,
     PDV_ADIANTAMENTO,
     PDV_TPESTOQUE,
     PDV_CDNATSERV,
     PDV_DESCNATSERV,
     PDV_VIA,
     PDV_MENSFAT,
     PDV_MENSFAT2,
     PDV_MENSFAT3,
     PDV_NATUREZA,
     PDV_PLACAVEIC,
     PDV_UFTRANSP,
     PDV_MARCA,
     PDV_NUMERO,
     PDV_QUANTIDADE,
     PDV_ESPECIE,
     PDV_REDESP1,
     PDV_REDESP2,
     PDV_CANALDEVENDA,
     PDV_SYSTEM,
     PDV_OBSPED,
     PDV_DESCRSERV,
     PDV_TOTVOLUME,
     PDV_EXP,
     PDV_UNIDNEG,
     PDV_REFEMPRESA,
     PDV_REFCLIENTE,
     PDV_INSTALACAO,
     PDV_CDPROMOCAO,
     PDV_QTDPROMOCAO,
     PDV_VRSUFRAMA,
     PDV_CUSTOFRETE,
     PDV_PESOINFCALC,
     PDV_CDALMOX,
     PDV_MUNICIPIOTRANSP,
     PDV_NATUREZACARGA,
     PDV_FATURAR,
     PDV_GERAMINUTA, -- NOVO CAMPO DEMANDA 15021
     PDV_VBUTILADIANT,
     PDV_CDCATALOGO,
     PDV_VLBONIFICADO,
     PDV_VLRSUFRAMA,
     PDV_VLRSUBST,
     PDV_VLRPMC,
     PDV_CLIFINAL,
     PDV_CONTRATO,
     PDV_CDORCAMENTO,
     PDV_DTBASEVENCIMENTO)
  VALUES
    (PPDV_CDEMPRESA,
     PPDV_CDFILIAL,
     PPDV_PEDIDO,
     PPDV_ORDCOMPRA,
     PPDV_DATA,
     PPDV_PENTREGA,
     PPDV_CDCLIENTE,
     PPDV_CDENDFAT,
     PPDV_CDENDENTR,
     PPDV_CDENDCOBR,
     PPDV_VENDEDOR1,
     PPDV_VENDEDOR2,
     PPDV_CONDPAGTO,
     PPDV_TPCOBRANCA,
     PPDV_GERACREC,
     PPDV_PESOBRUTO,
     PPDV_PESOLIQUI,
     PPDV_TPOPER,
     PPDV_TIPOVENDA,
     PPDV_OBS,
     PPDV_DTLIBFIN,
     PPDV_USULIBFIN,
     SYSDATE,
     GET_USER_MXM,
     SYSDATE,
     GET_USER_MXM,
     PPDV_NOTITULO,
     PPDV_MOEDA,
     PPDV_QTPROD,
     PPDV_TOTPROD,
     PPDV_PDESCONTO,
     PPDV_DESCONTO,
     PPDV_FRETE,
     PPDV_SEGURO,
     PPDV_ACRES,
     PPDV_IPI,
     PPDV_ISSNINCL,
     PPDV_TOTPED,
     PPDV_ICMS,
     PPDV_PISCOFINS,
     PPDV_IR,
     PPDV_ISSINCL,
     PPDV_ADMOPER,
     PPDV_COMISSAO,
     PPDV_OUTROS,
     PPDV_TOTLIQ,
     PPDV_PERDESCENC,
     PPDV_VLRDESCENC,
     PPDV_TPFAT,
     PPDV_TPENTR,
     PPDV_TRANSPORTADORA,
     PPDV_ADIANTAMENTO,
     PPDV_TPESTOQUE,
     PPDV_CDNATSERV,
     PPDV_DESCNATSERV,
     PPDV_VIA,
     PPDV_MENSFAT,
     PPDV_MENSFAT2,
     PPDV_MENSFAT3,
     PPDV_NATUREZA,
     PPDV_PLACAVEIC,
     PPDV_UFTRANSP,
     PPDV_MARCA,
     PPDV_NUMERO,
     PPDV_QUANTIDADE,
     PPDV_ESPECIE,
     PPDV_REDESP1,
     PPDV_REDESP2,
     PPDV_CANALDEVENDA,
     PPDV_SYSTEM,
     PPDV_OBSPED,
     PPDV_DESCRSERV,
     PPDV_TOTVOLUME,
     PPDV_EXP,
     PPDV_UNIDNEG,
     PPDV_REFEMPRESA,
     PPDV_REFCLIENTE,
     PPDV_INSTALACAO,
     PPDV_CDPROMOCAO,
     PPDV_QTDPROMOCAO,
     PPDV_VRSUFRAMA,
     PPDV_CUSTOFRETE,
     PPDV_PESOINFCALC,
     PPDV_CDALMOX,
     PPDV_MUNICIPIOTRANSP,
     PPDV_NATUREZACARGA,
     PPDV_FATURAR,
     PPDV_GERAMINUTA, -- NOVO CAMPO DEMANDA 15021
     PPDV_VBUTILADIANT,
     PPDV_CDCATALOGO,
     PPDV_VLBONIFICADO,
     PPDV_VLRSUFRAMA,
     PPDV_VLRSUBST,
     PPDV_VLRPMC,
     PPDV_CLIFINAL,
     PPDV_CONTRATO,
     PPDV_CDORCAMENTO,
     PPDV_DTBASEVENCIMENTO);
END;
/

CREATE OR REPLACE PROCEDURE ALTPEDVENDA_PDV(PPDV_CDEMPRESA IN CHAR,
                                            PPDV_CDFILIAL IN CHAR,
                                            PPDV_PEDIDO IN NUMBER,
                                            PPDV_ORDCOMPRA IN CHAR,
                                            PPDV_DATA IN DATE,
                                            PPDV_PENTREGA IN DATE,
                                            PPDV_CDCLIENTE IN CHAR,
                                            PPDV_CDENDFAT IN CHAR,
                                            PPDV_CDENDENTR IN CHAR,
                                            PPDV_CDENDCOBR IN CHAR,
                                            PPDV_VENDEDOR1 IN CHAR,
                                            PPDV_VENDEDOR2 IN CHAR,
                                            PPDV_CONDPAGTO IN CHAR,
                                            PPDV_TPCOBRANCA IN CHAR,
                                            PPDV_GERACREC IN CHAR,
                                            PPDV_PESOBRUTO IN NUMBER,
                                            PPDV_PESOLIQUI IN NUMBER,
                                            PPDV_TPOPER IN CHAR,
                                            PPDV_TIPOVENDA IN CHAR,
                                            PPDV_OBS IN CHAR,
                                            PPDV_DTLIBFIN IN DATE,
                                            PPDV_USULIBFIN IN CHAR,
                                            PPDV_DATADIG IN DATE,
                                            PPDV_USUARIO IN CHAR,
                                            PPDV_NOTITULO IN CHAR,
                                            PPDV_MOEDA IN CHAR,
                                            PPDV_QTPROD IN NUMBER,
                                            PPDV_TOTPROD IN NUMBER,
                                            PPDV_PDESCONTO IN NUMBER,
                                            PPDV_DESCONTO IN NUMBER,
                                            PPDV_FRETE IN NUMBER,
                                            PPDV_SEGURO IN NUMBER,
                                            PPDV_ACRES IN NUMBER,
                                            PPDV_IPI IN NUMBER,
                                            PPDV_ISSNINCL IN NUMBER,
                                            PPDV_TOTPED IN NUMBER,
                                            PPDV_ICMS IN NUMBER,
                                            PPDV_PISCOFINS IN NUMBER,
                                            PPDV_IR IN NUMBER,
                                            PPDV_ISSINCL IN NUMBER,
                                            PPDV_ADMOPER IN NUMBER,
                                            PPDV_COMISSAO IN NUMBER,
                                            PPDV_OUTROS IN NUMBER,
                                            PPDV_TOTLIQ IN NUMBER,
                                            PPDV_PERDESCENC IN NUMBER,
                                            PPDV_VLRDESCENC IN NUMBER,
                                            PPDV_TPFAT IN CHAR,
                                            PPDV_TPENTR IN CHAR,
                                            PPDV_MENSFAT IN CHAR,
                                            PPDV_MENSFAT2 IN CHAR,
                                            PPDV_MENSFAT3 IN CHAR,
                                            PPDV_TRANSPORTADORA IN CHAR,
                                            PPDV_ADIANTAMENTO IN NUMBER,
                                            PPDV_TPESTOQUE IN CHAR,
                                            PPDV_CDNATSERV IN CHAR,
                                            PPDV_DESCNATSERV IN CHAR,
                                            PPDV_VIA IN NUMBER,
                                            PPDV_NATUREZA IN CHAR,
                                            PPDV_PLACAVEIC IN CHAR,
                                            PPDV_UFTRANSP IN CHAR,
                                            PPDV_MARCA IN CHAR,
                                            PPDV_NUMERO IN CHAR,
                                            PPDV_QUANTIDADE IN NUMBER,
                                            PPDV_ESPECIE IN CHAR,
                                            PPDV_REDESP1 IN CHAR,
                                            PPDV_REDESP2 IN CHAR,
                                            PPDV_SYSTEM IN CHAR,
                                            PPDV_CANALDEVENDA IN CHAR,
                                            PPDV_OBSPED IN CHAR,
                                            PPDV_DESCRSERV IN CHAR,
                                            PPDV_TOTVOLUME IN NUMBER,
                                            PPDV_UNIDNEG IN CHAR,
                                            PPDV_REFEMPRESA IN CHAR,
                                            PPDV_REFCLIENTE IN CHAR,
                                            PPDV_INSTALACAO IN CHAR,
                                            PPDV_CDPROMOCAO IN CHAR,
                                            PPDV_QTDPROMOCAO IN NUMBER,
                                            PPDV_VRSUFRAMA IN NUMBER,
                                            PPDV_CUSTOFRETE IN NUMBER,
                                            PPDV_PESOINFCALC IN CHAR,
                                            PPDV_CDALMOX IN CHAR,
                                            PPDV_MUNICIPIOTRANSP IN CHAR,
                                            PPDV_NATUREZACARGA IN CHAR,
                                            PPDV_FATURAR IN CHAR DEFAULT NULL,
                                            PPDV_GERAMINUTA IN CHAR DEFAULT 'N', -- NOVO CAMPO DEMANDA 15021
                                            PPDV_DTALT IN DATE DEFAULT SYSDATE,
                                            PPDV_USRALT IN CHAR DEFAULT GET_USER_MXM,
                                            PPDV_VBUTILADIANT IN NUMBER,
                                            PPDV_CDCATALOGO IN CHAR,
                                            PPDV_VLBONIFICADO IN NUMBER,
                                            PPDV_VLRSUFRAMA IN NUMBER,
                                            PPDV_VLRSUBST IN NUMBER,
                                            PPDV_VLRPMC IN NUMBER,
                                            PPDV_CLIFINAL IN CHAR DEFAULT NULL,
                                            PPDV_CDORCAMENTO IN NUMBER,
                                            PPDV_VB_OBJ_BD IN CHAR DEFAULT 'B',
                                            PPDV_DTBASEVENCIMENTO IN DATE) AS
  vSTATUS FATURAS_FAT.FAT_STATUS%TYPE;
BEGIN
  BEGIN
    SELECT 'F'
      INTO vSTATUS
      FROM FATURAS_FAT
     WHERE FAT_CDFILIAL = PPDV_CDFILIAL
       AND FAT_CDEMPRESA = PPDV_CDEMPRESA
       AND FAT_PEDIDO = PPDV_PEDIDO
       AND FAT_STATUS <> 'C'
       AND ROWNUM = 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      vSTATUS := NULL;
    WHEN OTHERS THEN
      RAISE;
  END;
  ---
  IF vSTATUS = 'F' THEN
    RAISE_APPLICATION_ERROR(-20001, 'Pedido faturado.');
  END IF;
  ---
  --OPEN FATURA;
  --FETCH FATURA INTO vFATURA;
  --IF FATURA%FOUND THEN
  --   RAISE_APPLICATION_ERROR(-20001,'Pedido faturado.');
  --END IF;
  UPDATE PEDVENDA_PDV
     SET PDV_ORDCOMPRA = PPDV_ORDCOMPRA,
         PDV_DATA = PPDV_DATA,
         PDV_PENTREGA = PPDV_PENTREGA,
         PDV_CDCLIENTE = PPDV_CDCLIENTE,
         PDV_CDENDFAT = PPDV_CDENDFAT,
         PDV_CDENDENTR = PPDV_CDENDENTR,
         PDV_CDENDCOBR = PPDV_CDENDCOBR,
         PDV_VENDEDOR1 = PPDV_VENDEDOR1,
         PDV_VENDEDOR2 = PPDV_VENDEDOR2,
         PDV_CONDPAGTO = PPDV_CONDPAGTO,
         PDV_TPCOBRANCA = PPDV_TPCOBRANCA,
         PDV_GERACREC = PPDV_GERACREC,
         PDV_PESOBRUTO = PPDV_PESOBRUTO,
         PDV_PESOLIQUI = PPDV_PESOLIQUI,
         PDV_TPOPER = PPDV_TPOPER,
         PDV_TIPOVENDA = PPDV_TIPOVENDA,
         PDV_OBS = PPDV_OBS,
         PDV_DTLIBFIN = PPDV_DTLIBFIN,
         PDV_USULIBFIN = PPDV_USULIBFIN,
         PDV_DATADIG = SYSDATE,
         PDV_USUARIO = GET_USER_MXM,
         PDV_NOTITULO = PPDV_NOTITULO,
         PDV_MOEDA = PPDV_MOEDA,
         PDV_QTPROD = PPDV_QTPROD,
         PDV_TOTPROD = PPDV_TOTPROD,
         PDV_PDESCONTO = PPDV_PDESCONTO,
         PDV_DESCONTO = PPDV_DESCONTO,
         PDV_FRETE = PPDV_FRETE,
         PDV_SEGURO = PPDV_SEGURO,
         PDV_ACRES = PPDV_ACRES,
         PDV_IPI = PPDV_IPI,
         PDV_ISSNINCL = PPDV_ISSNINCL,
         PDV_TOTPED = PPDV_TOTPED,
         PDV_ICMS = PPDV_ICMS,
         PDV_PISCOFINS = PPDV_PISCOFINS,
         PDV_IR = PPDV_IR,
         PDV_ISSINCL = PPDV_ISSINCL,
         PDV_ADMOPER = PPDV_ADMOPER,
         PDV_COMISSAO = PPDV_COMISSAO,
         PDV_OUTROS = PPDV_OUTROS,
         PDV_TOTLIQ = PPDV_TOTLIQ,
         PDV_PERDESCENC = PPDV_PERDESCENC,
         PDV_VLRDESCENC = PPDV_VLRDESCENC,
         PDV_TPFAT = PPDV_TPFAT,
         PDV_TPENTR = PPDV_TPENTR,
         PDV_MENSFAT = PPDV_MENSFAT,
         PDV_MENSFAT2 = PPDV_MENSFAT2,
         PDV_MENSFAT3 = PPDV_MENSFAT3,
         PDV_VIA = PPDV_VIA,
         PDV_TRANSPORTADORA = PPDV_TRANSPORTADORA,
         PDV_TPESTOQUE = PPDV_TPESTOQUE,
         PDV_ADIANTAMENTO = PPDV_ADIANTAMENTO,
         PDV_CDNATSERV = PPDV_CDNATSERV,
         PDV_DESCNATSERV = PPDV_DESCNATSERV,
         PDV_NATUREZA = PPDV_NATUREZA,
         PDV_PLACAVEIC = PPDV_PLACAVEIC,
         PDV_UFTRANSP = PPDV_UFTRANSP,
         PDV_MARCA = PPDV_MARCA,
         PDV_NUMERO = PPDV_NUMERO,
         PDV_QUANTIDADE = PPDV_QUANTIDADE,
         PDV_ESPECIE = PPDV_ESPECIE,
         PDV_REDESP1 = PPDV_REDESP1,
         PDV_REDESP2 = PPDV_REDESP2,
         PDV_SYSTEM = PPDV_SYSTEM,
         PDV_CANALDEVENDA = PPDV_CANALDEVENDA,
         PDV_OBSPED = PPDV_OBSPED,
         PDV_DESCRSERV = PPDV_DESCRSERV,
         PDV_TOTVOLUME = PPDV_TOTVOLUME,
         PDV_UNIDNEG = PPDV_UNIDNEG,
         PDV_REFEMPRESA = PPDV_REFEMPRESA,
         PDV_REFCLIENTE = PPDV_REFCLIENTE,
         PDV_INSTALACAO = PPDV_INSTALACAO,
         PDV_CDPROMOCAO = PPDV_CDPROMOCAO,
         PDV_QTDPROMOCAO = PPDV_QTDPROMOCAO,
         PDV_VRSUFRAMA = PPDV_VRSUFRAMA,
         PDV_CUSTOFRETE = PPDV_CUSTOFRETE,
         PDV_PESOINFCALC = PPDV_PESOINFCALC,
         PDV_CDALMOX = PPDV_CDALMOX,
         PDV_MUNICIPIOTRANSP = PPDV_MUNICIPIOTRANSP,
         PDV_NATUREZACARGA = PPDV_NATUREZACARGA,
         PDV_FATURAR = PPDV_FATURAR,
         PDV_GERAMINUTA = PPDV_GERAMINUTA, -- NOVO CAMPO DEMANDA 15021
         PDV_DTALT = SYSDATE,
         PDV_USRALT = GET_USER_MXM,
         PDV_VBUTILADIANT = PPDV_VBUTILADIANT,
         PDV_CDCATALOGO = PPDV_CDCATALOGO,
         PDV_VLBONIFICADO = PPDV_VLBONIFICADO,
         PDV_VLRSUFRAMA = PPDV_VLRSUFRAMA,
         PDV_VLRSUBST = PPDV_VLRSUBST,
         PDV_VLRPMC = PPDV_VLRPMC,
         PDV_CLIFINAL = PPDV_CLIFINAL,
         PDV_CDORCAMENTO = PPDV_CDORCAMENTO,
         PDV_DTBASEVENCIMENTO = PPDV_DTBASEVENCIMENTO
   WHERE PDV_CDEMPRESA = PPDV_CDEMPRESA
     AND PDV_CDFILIAL = PPDV_CDFILIAL
     AND PDV_PEDIDO = PPDV_PEDIDO;
  --
  IF NVL(PPDV_VB_OBJ_BD, 'B') = 'B' THEN
    EXCITPEDVENDA_ITPV(PPDV_CDEMPRESA, PPDV_CDFILIAL, PPDV_PEDIDO);
    EXCPEDACRDEC_PAD(PPDV_CDEMPRESA, PPDV_CDFILIAL, PPDV_PEDIDO);
  END IF;
  --
END;
/

CREATE OR REPLACE PROCEDURE INSTI_ARQPEDVENDA_TAPV
( PTAPV_SQPROCESSO         IN NUMBER
 ,PTAPV_SQREGISTRO         IN NUMBER
 ,PTAPV_CDEMPRESA          IN CHAR
 ,PTAPV_CDFILIAL           IN CHAR
 ,PTAPV_PEDIDO             IN CHAR
 ,PTAPV_ORDCOMPRA          IN CHAR
 ,PTAPV_DATA               IN CHAR
 ,PTAPV_PENTREGA           IN CHAR
 ,PTAPV_CDCLIENTE          IN CHAR
 ,PTAPV_CDENDFAT           IN CHAR
 ,PTAPV_CDENDENTR          IN CHAR
 ,PTAPV_CDENDCOBR          IN CHAR
 ,PTAPV_UNIDNEG            IN CHAR
 ,PTAPV_CONDPAGTO          IN CHAR
 ,PTAPV_TPCOBRANCA         IN CHAR
 ,PTAPV_PESOBRUTO          IN CHAR
 ,PTAPV_PESOLIQUI          IN CHAR
 ,PTAPV_TPOPER             IN CHAR
 ,PTAPV_VIA                IN CHAR
 ,PTAPV_TIPOVENDA          IN CHAR
 ,PTAPV_OBS                IN CHAR
 ,PTAPV_MOEDA              IN CHAR
 ,PTAPV_DESCONTO           IN CHAR
 ,PTAPV_FRETE              IN CHAR
 ,PTAPV_SEGURO             IN CHAR
 ,PTAPV_ACRES              IN CHAR
 ,PTAPV_IPI                IN CHAR
 ,PTAPV_TOTPED             IN CHAR
 ,PTAPV_TPFAT              IN CHAR
 ,PTAPV_TPESTOQUE          IN CHAR
 ,PTAPV_TPENTR             IN CHAR
 ,PTAPV_CANAL              IN CHAR
 ,PTAPV_DESCRSERV          IN CHAR
 ,PTAPV_QTPROD             IN CHAR
 ,PTAPV_STOPERACAO         IN NUMBER
 ,PTAPV_CDALMOX            IN CHAR
 ,PTAPV_PERDESCENC         IN CHAR
 ,PTAPV_VLRDESCENC         IN CHAR
 ,PTAPV_VBUTILADIANT       IN CHAR
 ,PTAPV_ADIANTAMENTO       IN CHAR
 ,PTAPV_NOTITULO           IN CHAR
 ,PTAPV_CDCATALOGO         IN CHAR
 ,PTAPV_GERAMINUTA         IN CHAR
 ,PTAPV_CUSTOFRETE         IN CHAR
 ,PTAPV_TRANSPORTADORA     IN CHAR
 ,PTAPV_CDNATSERV          IN CHAR
 ,PTAPV_DESCNATSERV        IN CHAR
 ,PTAPV_MENSFAT            IN CHAR
 ,PTAPV_MENSFAT2           IN CHAR
 ,PTAPV_MENSFAT3           IN CHAR
 ,PTAPV_NATUREZA           IN CHAR
 ,PTAPV_PLACAVEIC          IN CHAR
 ,PTAPV_UFTRANSP           IN CHAR
 ,PTAPV_MARCA              IN CHAR
 ,PTAPV_QUANTIDADE         IN CHAR
 ,PTAPV_ESPECIE            IN CHAR
 ,PTAPV_REDESP1            IN CHAR
 ,PTAPV_REDESP2            IN CHAR
 ,PTAPV_EXPEDIDO           IN CHAR
 ,PTAPV_MUNICIPIOTRANSP    IN CHAR
 ,PTAPV_NATUREZACARGA      IN CHAR
 ,PTAPV_REFEMPRESA         IN CHAR
 ,PTAPV_REFCLIENTE         IN CHAR
 ,PTAPV_INSTALACAO         IN CHAR
 ,PTAPV_CLIFINAL           IN CHAR
 ,PTAPV_PESOINFCALC        IN CHAR
 ,PTAPV_TOTVOLUME          IN CHAR
 ,PTAPV_TOTPROD            IN CHAR
 ,PTAPV_VLBONIFICADO       IN CHAR
 ,PTAPV_TOTLIQ             IN CHAR
 ,PTAPV_ISSNINCL           IN CHAR
 ,PTAPV_ISSINCL            IN CHAR
 ,PTAPV_ICMS               IN CHAR
 ,PTAPV_PISCOFINS          IN CHAR
 ,PTAPV_IR                 IN CHAR
 ,PTAPV_VLRSUFRAMA         IN CHAR
 ,PTAPV_VLRSUBST           IN CHAR
 ,PTAPV_VLRPMC             IN CHAR
 ,PTAPV_PDESCONTO          IN CHAR
 ,PTAPV_ADMOPER            IN CHAR
 ,PTAPV_COMISSAO           IN CHAR
 ,PTAPV_OUTROS             IN CHAR
 ,PTAPV_SYSTEM             IN CHAR
 ,PTAPV_DTINC              IN CHAR
 ,PTAPV_USERINC            IN CHAR
 ,PTAPV_DATADIG            IN CHAR
 ,PTAPV_USUARIO            IN CHAR
 ,PTAPV_CDPROMOCAO         IN CHAR
 ,PTAPV_QTDPROMOCAO        IN CHAR
 ,PTAPV_CDORCAMENTO        IN CHAR
 ,PTAPV_DTCOTACAO          IN CHAR
 ,PTAPV_DTLIBFIN           IN CHAR
 ,PTAPV_USULIBFIN          IN CHAR
 ,PTAPV_FATURAR            IN CHAR
 ,PTAPV_VENDEDOR1          IN CHAR
 ,PTAPV_VENDEDOR2          IN CHAR
 ,PTAPV_ARQUIVO            IN CHAR
 ,PTAPV_IMPITEMEXPICAO     IN CHAR
 ,PTAPV_CDLIGACAO          IN CHAR
 ,PTAPV_IMPRECENTREGA      IN CHAR
 ,PTAPV_TPFORMAATENDIMENTO IN CHAR
 ,PTAPV_DTVENCIMENTO       IN CHAR DEFAULT NULL
 ,PTAPV_OBSPED             IN CHAR DEFAULT NULL
 ,PTAPV_DTBASEVENCIM       IN CHAR DEFAULT NULL)
AS
BEGIN
  INSERT INTO TI_ARQPEDVENDA_TAPV
  ( TAPV_SQPROCESSO
   ,TAPV_SQREGISTRO
   ,TAPV_CDEMPRESA
   ,TAPV_CDFILIAL
   ,TAPV_PEDIDO
   ,TAPV_ORDCOMPRA
   ,TAPV_DATA
   ,TAPV_PENTREGA
   ,TAPV_CDCLIENTE
   ,TAPV_CDENDFAT
   ,TAPV_CDENDENTR
   ,TAPV_CDENDCOBR
   ,TAPV_UNIDNEG
   ,TAPV_CONDPAGTO
   ,TAPV_TPCOBRANCA
   ,TAPV_PESOBRUTO
   ,TAPV_PESOLIQUI
   ,TAPV_TPOPER
   ,TAPV_VIA
   ,TAPV_TIPOVENDA
   ,TAPV_OBS
   ,TAPV_MOEDA
   ,TAPV_DESCONTO
   ,TAPV_FRETE
   ,TAPV_SEGURO
   ,TAPV_ACRES
   ,TAPV_IPI
   ,TAPV_TOTPED
   ,TAPV_TPFAT
   ,TAPV_TPESTOQUE
   ,TAPV_TPENTR
   ,TAPV_CANAL
   ,TAPV_DESCRSERV
   ,TAPV_QTPROD
   ,TAPV_STOPERACAO
   ,TAPV_CDALMOX
   ,TAPV_PERDESCENC
   ,TAPV_VLRDESCENC
   ,TAPV_VBUTILADIANT
   ,TAPV_ADIANTAMENTO
   ,TAPV_NOTITULO
   ,TAPV_CDCATALOGO
   ,TAPV_GERAMINUTA
   ,TAPV_CUSTOFRETE
   ,TAPV_TRANSPORTADORA
   ,TAPV_CDNATSERV
   ,TAPV_DESCNATSERV
   ,TAPV_MENSFAT
   ,TAPV_MENSFAT2
   ,TAPV_MENSFAT3
   ,TAPV_NATUREZA
   ,TAPV_PLACAVEIC
   ,TAPV_UFTRANSP
   ,TAPV_MARCA
   ,TAPV_QUANTIDADE
   ,TAPV_ESPECIE
   ,TAPV_REDESP1
   ,TAPV_REDESP2
   ,TAPV_EXPEDIDO
   ,TAPV_MUNICIPIOTRANSP
   ,TAPV_NATUREZACARGA
   ,TAPV_REFEMPRESA
   ,TAPV_REFCLIENTE
   ,TAPV_INSTALACAO
   ,TAPV_CLIFINAL
   ,TAPV_PESOINFCALC
   ,TAPV_TOTVOLUME
   ,TAPV_TOTPROD
   ,TAPV_VLBONIFICADO
   ,TAPV_TOTLIQ
   ,TAPV_ISSNINCL
   ,TAPV_ISSINCL
   ,TAPV_ICMS
   ,TAPV_PISCOFINS
   ,TAPV_IR
   ,TAPV_VLRSUFRAMA
   ,TAPV_VLRSUBST
   ,TAPV_VLRPMC
   ,TAPV_PDESCONTO
   ,TAPV_ADMOPER
   ,TAPV_COMISSAO
   ,TAPV_OUTROS
   ,TAPV_SYSTEM
   ,TAPV_DTINC
   ,TAPV_USERINC
   ,TAPV_DATADIG
   ,TAPV_USUARIO
   ,TAPV_CDPROMOCAO
   ,TAPV_QTDPROMOCAO
   ,TAPV_CDORCAMENTO
   ,TAPV_DTCOTACAO
   ,TAPV_DTLIBFIN
   ,TAPV_USULIBFIN
   ,TAPV_FATURAR
   ,TAPV_VENDEDOR1
   ,TAPV_VENDEDOR2
   ,TAPV_ARQUIVO
   ,TAPV_IMPITEMEXPICAO
   ,TAPV_CDLIGACAO
   ,TAPV_IMPRECENTREGA
   ,TAPV_TPFORMAATENDIMENTO
   ,TAPV_DTVENCIMENTO
   ,TAPV_OBSPED
   ,TAPV_DTBASEVENCIM)
  VALUES
  ( PTAPV_SQPROCESSO
   ,PTAPV_SQREGISTRO
   ,PTAPV_CDEMPRESA
   ,PTAPV_CDFILIAL
   ,PTAPV_PEDIDO
   ,PTAPV_ORDCOMPRA
   ,PTAPV_DATA
   ,PTAPV_PENTREGA
   ,PTAPV_CDCLIENTE
   ,PTAPV_CDENDFAT
   ,PTAPV_CDENDENTR
   ,PTAPV_CDENDCOBR
   ,PTAPV_UNIDNEG
   ,PTAPV_CONDPAGTO
   ,PTAPV_TPCOBRANCA
   ,PTAPV_PESOBRUTO
   ,PTAPV_PESOLIQUI
   ,PTAPV_TPOPER
   ,PTAPV_VIA
   ,PTAPV_TIPOVENDA
   ,PTAPV_OBS
   ,PTAPV_MOEDA
   ,PTAPV_DESCONTO
   ,PTAPV_FRETE
   ,PTAPV_SEGURO
   ,PTAPV_ACRES
   ,PTAPV_IPI
   ,PTAPV_TOTPED
   ,PTAPV_TPFAT
   ,PTAPV_TPESTOQUE
   ,PTAPV_TPENTR
   ,PTAPV_CANAL
   ,PTAPV_DESCRSERV
   ,PTAPV_QTPROD
   ,PTAPV_STOPERACAO
   ,PTAPV_CDALMOX
   ,PTAPV_PERDESCENC
   ,PTAPV_VLRDESCENC
   ,PTAPV_VBUTILADIANT
   ,PTAPV_ADIANTAMENTO
   ,PTAPV_NOTITULO
   ,PTAPV_CDCATALOGO
   ,PTAPV_GERAMINUTA
   ,PTAPV_CUSTOFRETE
   ,PTAPV_TRANSPORTADORA
   ,PTAPV_CDNATSERV
   ,PTAPV_DESCNATSERV
   ,PTAPV_MENSFAT
   ,PTAPV_MENSFAT2
   ,PTAPV_MENSFAT3
   ,PTAPV_NATUREZA
   ,PTAPV_PLACAVEIC
   ,PTAPV_UFTRANSP
   ,PTAPV_MARCA
   ,PTAPV_QUANTIDADE
   ,PTAPV_ESPECIE
   ,PTAPV_REDESP1
   ,PTAPV_REDESP2
   ,PTAPV_EXPEDIDO
   ,PTAPV_MUNICIPIOTRANSP
   ,PTAPV_NATUREZACARGA
   ,PTAPV_REFEMPRESA
   ,PTAPV_REFCLIENTE
   ,PTAPV_INSTALACAO
   ,PTAPV_CLIFINAL
   ,PTAPV_PESOINFCALC
   ,PTAPV_TOTVOLUME
   ,PTAPV_TOTPROD
   ,PTAPV_VLBONIFICADO
   ,PTAPV_TOTLIQ
   ,PTAPV_ISSNINCL
   ,PTAPV_ISSINCL
   ,PTAPV_ICMS
   ,PTAPV_PISCOFINS
   ,PTAPV_IR
   ,PTAPV_VLRSUFRAMA
   ,PTAPV_VLRSUBST
   ,PTAPV_VLRPMC
   ,PTAPV_PDESCONTO
   ,PTAPV_ADMOPER
   ,PTAPV_COMISSAO
   ,PTAPV_OUTROS
   ,PTAPV_SYSTEM
   ,PTAPV_DTINC
   ,PTAPV_USERINC
   ,PTAPV_DATADIG
   ,PTAPV_USUARIO
   ,PTAPV_CDPROMOCAO
   ,PTAPV_QTDPROMOCAO
   ,PTAPV_CDORCAMENTO
   ,PTAPV_DTCOTACAO
   ,PTAPV_DTLIBFIN
   ,PTAPV_USULIBFIN
   ,PTAPV_FATURAR
   ,PTAPV_VENDEDOR1
   ,PTAPV_VENDEDOR2
   ,PTAPV_ARQUIVO
   ,PTAPV_IMPITEMEXPICAO
   ,PTAPV_CDLIGACAO
   ,PTAPV_IMPRECENTREGA
   ,PTAPV_TPFORMAATENDIMENTO
   ,PTAPV_DTVENCIMENTO
   ,PTAPV_OBSPED
   ,PTAPV_DTBASEVENCIM
   );
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 270243
PROMPT ======================================================================