PROMPT ======================================================================
PROMPT == DEMANDA......: 273416
PROMPT == SISTEMA......: Patrimonio
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 14/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE INSACRDCR(CDEMPRESA      IN CHAR,
                                      CODIGO         IN CHAR,
                                      ANEXO          IN CHAR,
                                      DATA           IN DATE,
                                      TIPO           IN CHAR,
                                      VALMOED1       IN NUMBER,
                                      VALMOED2       IN NUMBER,
                                      VALDEP1        IN NUMBER,
                                      VALDEP2        IN NUMBER,
                                      QUANTIDADE     IN NUMBER,
                                      CONTRPART      IN CHAR,
                                      CODPLAN        IN CHAR,
                                      HISTORICO      IN CHAR,
                                      COTACAO        IN NUMBER,
                                      CONTABIL       IN CHAR,
                                      IDMOVIMENTACAO IN NUMBER) AS
  CCUSTO           VARCHAR2(15);
  LOCAL            VARCHAR2(10);
  RESPONS          VARCHAR2(30);
  CONTABEM         VARCHAR2(15);
  CONTARES         VARCHAR2(15);
  GRPAT            VARCHAR2(06);
  LANCTO           VARCHAR2(06);
  LOTE             VARCHAR2(06);
  VMOEDA           VARCHAR2(03);
  CDPROJETO        VARCHAR2(20);
  DEPRTOT1         DATE;
  DEPRTOT2         DATE;
  DTPRJINATIVO     DATE;
  SEQUENCIAMOVSAP  NUMBER;
  SEQUENCIAMOVSAP1 NUMBER;
  IDMOVSAP1        NUMBER;
BEGIN
  IF IDMOVIMENTACAO IS NULL THEN
    SELECT SEQ1_MOVSAP_MSAP.NEXTVAL INTO SEQUENCIAMOVSAP FROM DUAL;
  END IF;
  BEGIN
    SELECT RMM_NRMOVSAP1
      INTO IDMOVSAP1
      FROM SAPRELMOVSAPMOVSAP1_RMM
     WHERE RMM_NRMOVSAP = IDMOVIMENTACAO;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      IDMOVSAP1 := NULL;
  END;
  SELECT PAT_GRPATRIM,
         PAT_NOCCUSTO,
         PAT_LOCAL,
         PAT_RESPONSAVEL,
         PAT_DEPRTOT1,
         PAT_DEPRTOT2,
         PAT_CDPROJETO
    INTO GRPAT, CCUSTO, LOCAL, RESPONS, DEPRTOT1, DEPRTOT2, CDPROJETO
    FROM PATRIMON_PAT
   WHERE PAT_CDEMPRESA = CDEMPRESA
     AND PAT_CDPATRIMO = CODIGO
     AND PAT_CDANEXO = ANEXO;
  IF CONTABIL = 'S' THEN
    SELECT LTRIM(TO_CHAR(TO_NUMBER(PAR_VLPARAM) + 1, '000000'))
      INTO LANCTO
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = 'WPAR_NAUTOLANC'
       FOR UPDATE;
    UPDATE PARAMS_PAR
       SET PAR_VLPARAM = LANCTO
     WHERE PAR_CDPARAM = 'WPAR_NAUTOLANC';
  ELSE
    LANCTO := '';
  END IF;
  VMOEDA := '';
  SELECT EMP_SEGMOEDA INTO VMOEDA FROM EMP WHERE EMP_CODIGO = CDEMPRESA;
  IF IDMOVIMENTACAO IS NULL THEN
    INSERT INTO MOVSAP_MSAP
      (MSAP_IDMOVIMENTACAO,
       MSAP_CDEMPRESA,
       MSAP_CDPATRIMO,
       MSAP_CDANEXO,
       MSAP_DATA,
       MSAP_TPMOV,
       MSAP_CCUSTO,
       MSAP_LOCAL,
       MSAP_RESPONSAVEL,
       MSAP_VCOR,
       MSAP_VDEP,
       MSAP_QUANTIDADE,
       MSAP_LANCCTB,
       MSAP_COTACAO,
       MSAP_HISTORICO)
    VALUES
      (SEQUENCIAMOVSAP,
       CDEMPRESA,
       CODIGO,
       ANEXO,
       DATA,
       TIPO,
       CCUSTO,
       LOCAL,
       RESPONS,
       VALMOED1,
       VALDEP1,
       QUANTIDADE,
       LTRIM(LANCTO),
       COTACAO,
       HISTORICO);
    IF VMOEDA IS NOT NULL THEN
      SELECT SEQ1_MOVSAP1_MSAP.NEXTVAL INTO SEQUENCIAMOVSAP1 FROM DUAL;
      INSERT INTO MOVSAP1_MSAP
        (MSAP_IDMOVIMENTACAO,
         MSAP_CDEMPRESA1,
         MSAP_CDPATRIMO1,
         MSAP_CDANEXO1,
         MSAP_DATA1,
         MSAP_TPMOV1,
         MSAP_CCUSTO1,
         MSAP_LOCAL1,
         MSAP_RESPONSAVEL1,
         MSAP_VCOR1,
         MSAP_VDEP1,
         MSAP_QUANTIDADE1,
         MSAP_LANCCTB1,
         MSAP_COTACAO1,
         MSAP_HISTORICO1)
      VALUES
        (SEQUENCIAMOVSAP1,
         CDEMPRESA,
         CODIGO,
         ANEXO,
         DATA,
         TIPO,
         CCUSTO,
         LOCAL,
         RESPONS,
         VALMOED2,
         VALDEP2,
         QUANTIDADE,
         LTRIM(LANCTO),
         COTACAO,
         HISTORICO);
    END IF;
    INSERT INTO SAPRELMOVSAPMOVSAP1_RMM
      (RMM_IDRELACIONAMENTO,
       RMM_NRMOVSAP,
       RMM_NRMOVSAP1,
       RMM_USINCLUSAO,
       RMM_DTINCLUSAO)
    VALUES
      (SEQ1_SAPRELMOVSAPMOVSAP1_RMM.NEXTVAL,
       SEQUENCIAMOVSAP,
       SEQUENCIAMOVSAP1,
       GET_USER_MXM,
       SYSDATE);
    UPDATE PATRIMON_PAT
       SET PAT_QTDACRDEC = NVL(PAT_QTDACRDEC, 0) + QUANTIDADE
     WHERE PAT_CDEMPRESA = CDEMPRESA
       AND PAT_CDPATRIMO = CODIGO
       AND PAT_CDANEXO = ANEXO;
    INSACRDRC_FISCAL(CDEMPRESA,
                     CODIGO,
                     ANEXO,
                     DATA,
                     TIPO,
                     VALMOED1,
                     HISTORICO,
                     QUANTIDADE,
                     SEQUENCIAMOVSAP);
  ELSE
    UPDATE MOVSAP_MSAP
       SET MSAP_QUANTIDADE = QUANTIDADE,
           MSAP_HISTORICO  = HISTORICO,
           MSAP_COTACAO    = COTACAO,
           MSAP_VCOR       = VALMOED1,
           MSAP_LANCCTB    = LANCTO,
           MSAP_CCUSTO     = CCUSTO
     WHERE MSAP_IDMOVIMENTACAO = IDMOVIMENTACAO;
    INSACRDRC_FISCAL(CDEMPRESA,
                     CODIGO,
                     ANEXO,
                     DATA,
                     TIPO,
                     VALMOED1,
                     HISTORICO,
                     QUANTIDADE,
                     IDMOVIMENTACAO);
    IF (VMOEDA IS NOT NULL AND IDMOVSAP1 IS NOT NULL) THEN
      UPDATE MOVSAP1_MSAP
         SET MSAP_QUANTIDADE1 = QUANTIDADE,
             MSAP_HISTORICO1  = HISTORICO,
             MSAP_COTACAO1    = COTACAO,
             MSAP_VCOR1       = VALMOED2,
             MSAP_LANCCTB1    = LANCTO,
             MSAP_CCUSTO1     = CCUSTO
       WHERE MSAP_IDMOVIMENTACAO = IDMOVSAP1;
    END IF;
  END IF;
  IF TIPO = 'AC' THEN
    IF (DEPRTOT1 IS NOT NULL) THEN
      UPDATE PATRIMON_PAT
         SET PAT_DEPRTOT1 = NULL
       WHERE PAT_CDEMPRESA = CDEMPRESA
         AND PAT_CDPATRIMO = CODIGO
         AND PAT_CDANEXO = ANEXO;
    END IF;
    IF (DEPRTOT2 IS NOT NULL) THEN
      UPDATE PATRIMON_PAT
         SET PAT_DEPRTOT2 = NULL
       WHERE PAT_CDEMPRESA = CDEMPRESA
         AND PAT_CDPATRIMO = CODIGO
         AND PAT_CDANEXO = ANEXO;
    END IF;
  END IF;
  IF CONTABIL = 'S' THEN
    BEGIN
      SELECT CGPAT_CTABEM, CGPAT_CTARESULT
        INTO CONTABEM, CONTARES
        FROM GRPATCTB_CGPAT
       WHERE CGPAT_CODIGO = GRPAT
         AND CGPAT_CDEMPRESA = CDEMPRESA;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20000,
                                'NAO FORAM DEFINIDAS AS CONTAS DO GRUPO PATRIMONIAL "' ||
                                GRPAT || '", DA EMPRESA "' || CDEMPRESA || '"');
    END;
    IF CONTABEM IS NULL THEN
      RAISE_APPLICATION_ERROR(-20000,
                              'A CONTA DO BEM DO GRUPO "' || GRPAT ||
                              '" NAO FOI INFORMADA.');
    END IF;
    IF CONTARES IS NULL THEN
      RAISE_APPLICATION_ERROR(-20000,
                              'A CONTA DE RESULTADO DO GRUPO "' || GRPAT ||
                              '" NAO FOI INFORMADA.');
    END IF;
    -- VALIDAR PROJETO
    IF CDPROJETO IS NOT NULL THEN
      BEGIN
        -- VALIDAR DATA INATIVA
        SELECT PJC_DTINATIVO
          INTO DTPRJINATIVO
          FROM PRJCTB_PJC
         WHERE PJC_CDPROJETO = CDPROJETO;
        IF DTPRJINATIVO IS NOT NULL AND DTPRJINATIVO <= DATA THEN
          RAISE_APPLICATION_ERROR(-20000,
                                  'PROJETO "' || CDPROJETO || '" INATIVO.');
        END IF;
      END;
    END IF;
    IF TIPO = 'AC' THEN
      LOTE := 'SAP_AC';
      IF VALIDCCUST(CDEMPRESA, CODPLAN, CONTABEM, CCUSTO) = 1 THEN
        INSLANCCTB_LCT(CDEMPRESA,
                       LOTE,
                       DATA,
                       LTRIM(LANCTO),
                       '1',
                       CONTABEM,
                       CCUSTO,
                       HISTORICO,
                       'D',
                       ABS(VALMOED1),
                       ABS(VALMOED2),
                       '',
                       VMOEDA,
                       '',
                       '',
                       CDPROJETO);
      ELSE
        INSLANCCTB_LCT(CDEMPRESA,
                       LOTE,
                       DATA,
                       LTRIM(LANCTO),
                       '1',
                       CONTABEM,
                       '',
                       HISTORICO,
                       'D',
                       ABS(VALMOED1),
                       ABS(VALMOED2),
                       '',
                       VMOEDA,
                       '',
                       '',
                       CDPROJETO);
      END IF;
      IF VALIDCCUST(CDEMPRESA, CODPLAN, CONTRPART, CCUSTO) = 1 THEN
        INSLANCCTB_LCT(CDEMPRESA,
                       LOTE,
                       DATA,
                       LTRIM(LANCTO),
                       '2',
                       CONTRPART,
                       CCUSTO,
                       HISTORICO,
                       'C',
                       ABS(VALMOED1),
                       ABS(VALMOED2),
                       '',
                       VMOEDA,
                       '',
                       '',
                       CDPROJETO);
      ELSE
        INSLANCCTB_LCT(CDEMPRESA,
                       LOTE,
                       DATA,
                       LTRIM(LANCTO),
                       '2',
                       CONTRPART,
                       '',
                       HISTORICO,
                       'C',
                       ABS(VALMOED1),
                       ABS(VALMOED2),
                       '',
                       VMOEDA,
                       '',
                       '',
                       CDPROJETO);
      END IF;
    ELSE
      IF (ABS(NVL(VALMOED1, 0)) - ABS(NVL(VALDEP1, 0))) > 0 THEN
        LOTE := 'SAP_DC';
        IF VALIDCCUST(CDEMPRESA, CODPLAN, CONTABEM, CCUSTO) = 1 THEN
          INSLANCCTB_LCT(CDEMPRESA,
                         LOTE,
                         DATA,
                         LTRIM(LANCTO),
                         '1',
                         CONTABEM,
                         CCUSTO,
                         HISTORICO,
                         'C',
                         ABS(VALMOED1),
                         ABS(VALMOED2),
                         '',
                         VMOEDA,
                         '',
                         '',
                         CDPROJETO);
        ELSE
          INSLANCCTB_LCT(CDEMPRESA,
                         LOTE,
                         DATA,
                         LTRIM(LANCTO),
                         '1',
                         CONTABEM,
                         '',
                         HISTORICO,
                         'C',
                         ABS(VALMOED1),
                         ABS(VALMOED2),
                         '',
                         VMOEDA,
                         '',
                         '',
                         CDPROJETO);
        END IF;
        IF VALIDCCUST(CDEMPRESA, CODPLAN, CONTRPART, CCUSTO) = 1 THEN
          INSLANCCTB_LCT(CDEMPRESA,
                         LOTE,
                         DATA,
                         LTRIM(LANCTO),
                         '2',
                         CONTRPART,
                         CCUSTO,
                         HISTORICO,
                         'D',
                         ABS(VALMOED1) - ABS(VALDEP1),
                         ABS(VALMOED2) - ABS(VALDEP2),
                         '',
                         VMOEDA,
                         '',
                         '',
                         CDPROJETO);
        ELSE
          INSLANCCTB_LCT(CDEMPRESA,
                         LOTE,
                         DATA,
                         LTRIM(LANCTO),
                         '2',
                         CONTRPART,
                         '',
                         HISTORICO,
                         'D',
                         ABS(VALMOED1) - ABS(VALDEP1),
                         ABS(VALMOED2) - ABS(VALDEP2),
                         '',
                         VMOEDA,
                         '',
                         '',
                         CDPROJETO);
        END IF;
      END IF;
    END IF;
  END IF;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 273416
PROMPT ======================================================================