PROMPT ======================================================================
PROMPT == DEMANDA......: 274678
PROMPT == SISTEMA......: Contas a Receber
PROMPT == RESPONSAVEL..: NIKOLAS DE AGUIAR PONTES
PROMPT == DATA.........: 07/07/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRECAMPOS_CDR
SET
CDR_DSCAMPOTABELA = 'DECODE(CLIENTE_CLI.CLI_TIPESSOA, ''J'', ''Jur�dico'', ''F'', ''F�sico'', ''O'', ''Outros'', ''E'', ''Estrageiro'', ''G'', ''Governamental'')', CDR_DSCAMPO = 'Tipo (Jur�dica/F�sica/Governamental/Outra)'
WHERE CDR_DSCAMPOTABELA = 'DECODE(CLIENTE_CLI.CLI_TIPESSOA, ''J'', ''Jur�dico'', ''F'', ''F�sico'', ''O'', ''Outros'', ''E'', ''Estrageiro'')'
AND CDR_NRTABELA = (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'CLIENTE_CLI')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 274678
PROMPT ======================================================================