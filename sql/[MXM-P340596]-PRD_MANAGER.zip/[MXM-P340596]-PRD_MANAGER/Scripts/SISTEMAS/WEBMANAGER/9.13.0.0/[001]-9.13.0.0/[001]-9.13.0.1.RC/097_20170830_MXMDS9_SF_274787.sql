PROMPT ======================================================================
PROMPT == DEMANDA......: 274787
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: CAIXA FATURAMENTO
PROMPT == DATA.........: 09/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE CODIPIFECP_FECP MODIFY (FECP_CDCLASSFISCAL VARCHAR2(15))
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 274787
PROMPT ======================================================================