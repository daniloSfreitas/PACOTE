PROMPT ======================================================================
PROMPT == DEMANDA......: 273335
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: Eduardo Lopes de Oliveira
PROMPT == DATA.........: 26/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE UNIDADE_UNI ADD UNI_UNITRIBCOMEXT VARCHAR2(10)
/

COMMENT ON COLUMN UNIDADE_UNI.UNI_UNITRIBCOMEXT IS 'Unidade Tribut�vel do Com�rcio Exterior'
/

CREATE OR REPLACE PROCEDURE INSUNIDADE_UNI(PUNI_CODIGO        IN CHAR,
                                           PUNI_DESCRICAO     IN CHAR,
                                           PUNI_SIMBOLO       IN CHAR,
                                           PUNI_CASASDEC      IN NUMBER,
                                           PUNI_HORARIA       IN CHAR,
                                           PUNI_UNITRIBCOMEXT IN CHAR) AS
BEGIN
  INSERT INTO UNIDADE_UNI
    (UNI_CODIGO,
     UNI_DESCRICAO,
     UNI_SIMBOLO,
     UNI_CASASDEC,
     UNI_HORARIA,
     UNI_UNITRIBCOMEXT)
  VALUES
    (PUNI_CODIGO,
     PUNI_DESCRICAO,
     PUNI_SIMBOLO,
     PUNI_CASASDEC,
     PUNI_HORARIA,
     PUNI_UNITRIBCOMEXT);
END;
/

CREATE OR REPLACE PROCEDURE ALTUNIDADE_UNI(PUNI_CODIGO        IN CHAR,
                                           PUNI_DESCRICAO     IN CHAR,
                                           PUNI_SIMBOLO       IN CHAR,
                                           PUNI_CASASDEC      IN CHAR,
                                           PUNI_HORARIA       IN CHAR,
                                           PUNI_UNITRIBCOMEXT IN CHAR) AS
BEGIN
  UPDATE UNIDADE_UNI
     SET UNI_DESCRICAO     = PUNI_DESCRICAO,
         UNI_SIMBOLO       = PUNI_SIMBOLO,
         UNI_CASASDEC      = PUNI_CASASDEC,
         UNI_HORARIA       = PUNI_HORARIA,
         UNI_EXP           = NULL,
         UNI_UNITRIBCOMEXT = PUNI_UNITRIBCOMEXT
   WHERE UNI_CODIGO = PUNI_CODIGO;
END;
/

INSERT INTO FATCLASSIFICACFOP_FCO
  (FCO_IDFATCLASSIFICACFOP,
   FCO_DSFATCLASSIFICACFOP,
   FCO_DTINCLUSAO,
   FCO_USINCLUSAO)
VALUES
  (11,
   'Opera��es vinculadas a exporta��o',
   SYSDATE,
   GET_USER_MXM)
/

INSERT INTO FATITCFOPESPECIF_FICE
  (FICE_IDFATITCFOPESPECIF,
   FICE_CDFATCFOPESPECIF,
   FICE_CDCLASSIFICACAOCFOP,
   FICE_CDCFOP,
   FICE_DSCFOP,
   FICE_DTINCLUSAO,
   FICE_USINCLUSAO)
values
  (SQ1_FATITCFOPESPECIF_FICE.NEXTVAL,
   (SELECT FCE_IDFATCFOPESPECIFICO
      FROM FATCFOPESPECIFICO_FCE
     WHERE FCE_VBINATIVACAO = 'F'
       AND FCE_DTVIGENCIADE <= SYSDATE
       AND FCE_DTVIGENCIAATE >= SYSDATE),
   (SELECT FCO_IDFATCLASSIFICACFOP
      FROM FATCLASSIFICACFOP_FCO
     WHERE UPPER(FCO_DSFATCLASSIFICACFOP) =
           UPPER('Opera��es vinculadas a exporta��o')),
   1501,
   'Entrada de mercadoria recebida com fim espec�fico de exporta��o',
   sysdate,
   get_user_mxm)
/

INSERT INTO FATITCFOPESPECIF_FICE
  (FICE_IDFATITCFOPESPECIF,
   FICE_CDFATCFOPESPECIF,
   FICE_CDCLASSIFICACAOCFOP,
   FICE_CDCFOP,
   FICE_DSCFOP,
   FICE_DTINCLUSAO,
   FICE_USINCLUSAO)
values
  (SQ1_FATITCFOPESPECIF_FICE.NEXTVAL,
   (SELECT FCE_IDFATCFOPESPECIFICO
      FROM FATCFOPESPECIFICO_FCE
     WHERE FCE_VBINATIVACAO = 'F'
       AND FCE_DTVIGENCIADE <= SYSDATE
       AND FCE_DTVIGENCIAATE >= SYSDATE),
   (SELECT FCO_IDFATCLASSIFICACFOP
      FROM FATCLASSIFICACFOP_FCO
     WHERE UPPER(FCO_DSFATCLASSIFICACFOP) =
           UPPER('Opera��es vinculadas a exporta��o')),
   2501,
   'Entrada de mercadoria recebida com fim espec�fico de exporta��o',
   sysdate,
   get_user_mxm)
/

INSERT INTO FATITCFOPESPECIF_FICE
  (FICE_IDFATITCFOPESPECIF,
   FICE_CDFATCFOPESPECIF,
   FICE_CDCLASSIFICACAOCFOP,
   FICE_CDCFOP,
   FICE_DSCFOP,
   FICE_DTINCLUSAO,
   FICE_USINCLUSAO)
values
  (SQ1_FATITCFOPESPECIF_FICE.NEXTVAL,
   (SELECT FCE_IDFATCFOPESPECIFICO
      FROM FATCFOPESPECIFICO_FCE
     WHERE FCE_VBINATIVACAO = 'F'
       AND FCE_DTVIGENCIADE <= SYSDATE
       AND FCE_DTVIGENCIAATE >= SYSDATE),
   (SELECT FCO_IDFATCLASSIFICACFOP
      FROM FATCLASSIFICACFOP_FCO
     WHERE UPPER(FCO_DSFATCLASSIFICACFOP) =
           UPPER('Opera��es vinculadas a exporta��o')),
   5501,
   'Remessa de produ��o do estabelecimento, com fim espec�fico de exporta��o',
   sysdate,
   get_user_mxm)
/

INSERT INTO FATITCFOPESPECIF_FICE
  (FICE_IDFATITCFOPESPECIF,
   FICE_CDFATCFOPESPECIF,
   FICE_CDCLASSIFICACAOCFOP,
   FICE_CDCFOP,
   FICE_DSCFOP,
   FICE_DTINCLUSAO,
   FICE_USINCLUSAO)
values
  (SQ1_FATITCFOPESPECIF_FICE.NEXTVAL,
   (SELECT FCE_IDFATCFOPESPECIFICO
      FROM FATCFOPESPECIFICO_FCE
     WHERE FCE_VBINATIVACAO = 'F'
       AND FCE_DTVIGENCIADE <= SYSDATE
       AND FCE_DTVIGENCIAATE >= SYSDATE),
   (SELECT FCO_IDFATCLASSIFICACFOP
      FROM FATCLASSIFICACFOP_FCO
     WHERE UPPER(FCO_DSFATCLASSIFICACFOP) =
           UPPER('Opera��es vinculadas a exporta��o')),
   5502,
   'Remessa de mercadoria adquirida ou recebida de terceiros, com fim espec�fico de exporta��o',
   sysdate,
   get_user_mxm)
/

INSERT INTO FATITCFOPESPECIF_FICE
  (FICE_IDFATITCFOPESPECIF,
   FICE_CDFATCFOPESPECIF,
   FICE_CDCLASSIFICACAOCFOP,
   FICE_CDCFOP,
   FICE_DSCFOP,
   FICE_DTINCLUSAO,
   FICE_USINCLUSAO)
values
  (SQ1_FATITCFOPESPECIF_FICE.NEXTVAL,
   (SELECT FCE_IDFATCFOPESPECIFICO
      FROM FATCFOPESPECIFICO_FCE
     WHERE FCE_VBINATIVACAO = 'F'
       AND FCE_DTVIGENCIADE <= SYSDATE
       AND FCE_DTVIGENCIAATE >= SYSDATE),
   (SELECT FCO_IDFATCLASSIFICACFOP
      FROM FATCLASSIFICACFOP_FCO
     WHERE UPPER(FCO_DSFATCLASSIFICACFOP) =
           UPPER('Opera��es vinculadas a exporta��o')),
   5504,
   'Remessa de mercadoria p/ forma��o de lote de exporta��o, de produto industrializado ou produzido pelo pr�prio estabelecimento.',
   sysdate,
   get_user_mxm)
/

INSERT INTO FATITCFOPESPECIF_FICE
  (FICE_IDFATITCFOPESPECIF,
   FICE_CDFATCFOPESPECIF,
   FICE_CDCLASSIFICACAOCFOP,
   FICE_CDCFOP,
   FICE_DSCFOP,
   FICE_DTINCLUSAO,
   FICE_USINCLUSAO)
values
  (SQ1_FATITCFOPESPECIF_FICE.NEXTVAL,
   (SELECT FCE_IDFATCFOPESPECIFICO
      FROM FATCFOPESPECIFICO_FCE
     WHERE FCE_VBINATIVACAO = 'F'
       AND FCE_DTVIGENCIADE <= SYSDATE
       AND FCE_DTVIGENCIAATE >= SYSDATE),
   (SELECT FCO_IDFATCLASSIFICACFOP
      FROM FATCLASSIFICACFOP_FCO
     WHERE UPPER(FCO_DSFATCLASSIFICACFOP) =
           UPPER('Opera��es vinculadas a exporta��o')),
   5505,
   'Remessa de mercadoria, adquirida ou recebida de terceiros, p/ forma��o de lote de exporta��o.',
   sysdate,
   get_user_mxm)
/

INSERT INTO FATITCFOPESPECIF_FICE
  (FICE_IDFATITCFOPESPECIF,
   FICE_CDFATCFOPESPECIF,
   FICE_CDCLASSIFICACAOCFOP,
   FICE_CDCFOP,
   FICE_DSCFOP,
   FICE_DTINCLUSAO,
   FICE_USINCLUSAO)
values
  (SQ1_FATITCFOPESPECIF_FICE.NEXTVAL,
   (SELECT FCE_IDFATCFOPESPECIFICO
      FROM FATCFOPESPECIFICO_FCE
     WHERE FCE_VBINATIVACAO = 'F'
       AND FCE_DTVIGENCIADE <= SYSDATE
       AND FCE_DTVIGENCIAATE >= SYSDATE),
   (SELECT FCO_IDFATCLASSIFICACFOP
      FROM FATCLASSIFICACFOP_FCO
     WHERE UPPER(FCO_DSFATCLASSIFICACFOP) =
           UPPER('Opera��es vinculadas a exporta��o')),
   6501,
   'Remessa de produ��o do estabelecimento, com fim espec�fico de exporta��o.',
   sysdate,
   get_user_mxm)
/

INSERT INTO FATITCFOPESPECIF_FICE
  (FICE_IDFATITCFOPESPECIF,
   FICE_CDFATCFOPESPECIF,
   FICE_CDCLASSIFICACAOCFOP,
   FICE_CDCFOP,
   FICE_DSCFOP,
   FICE_DTINCLUSAO,
   FICE_USINCLUSAO)
values
  (SQ1_FATITCFOPESPECIF_FICE.NEXTVAL,
   (SELECT FCE_IDFATCFOPESPECIFICO
      FROM FATCFOPESPECIFICO_FCE
     WHERE FCE_VBINATIVACAO = 'F'
       AND FCE_DTVIGENCIADE <= SYSDATE
       AND FCE_DTVIGENCIAATE >= SYSDATE),
   (SELECT FCO_IDFATCLASSIFICACFOP
      FROM FATCLASSIFICACFOP_FCO
     WHERE UPPER(FCO_DSFATCLASSIFICACFOP) =
           UPPER('Opera��es vinculadas a exporta��o')),
   6502,
   'Remessa de mercadoria adquirida ou recebida de terceiros, com fim espec�fico de exporta��o.',
   sysdate,
   get_user_mxm)
/

INSERT INTO FATITCFOPESPECIF_FICE
  (FICE_IDFATITCFOPESPECIF,
   FICE_CDFATCFOPESPECIF,
   FICE_CDCLASSIFICACAOCFOP,
   FICE_CDCFOP,
   FICE_DSCFOP,
   FICE_DTINCLUSAO,
   FICE_USINCLUSAO)
values
  (SQ1_FATITCFOPESPECIF_FICE.NEXTVAL,
   (SELECT FCE_IDFATCFOPESPECIFICO
      FROM FATCFOPESPECIFICO_FCE
     WHERE FCE_VBINATIVACAO = 'F'
       AND FCE_DTVIGENCIADE <= SYSDATE
       AND FCE_DTVIGENCIAATE >= SYSDATE),
   (SELECT FCO_IDFATCLASSIFICACFOP
      FROM FATCLASSIFICACFOP_FCO
     WHERE UPPER(FCO_DSFATCLASSIFICACFOP) =
           UPPER('Opera��es vinculadas a exporta��o')),
   6504,
   'Remessa de mercadoria p/ forma��o de lote de exporta��o, de produto industrializado ou produzido pelo pr�prio estabelecimento.',
   sysdate,
   get_user_mxm)
/

INSERT INTO FATITCFOPESPECIF_FICE
  (FICE_IDFATITCFOPESPECIF,
   FICE_CDFATCFOPESPECIF,
   FICE_CDCLASSIFICACAOCFOP,
   FICE_CDCFOP,
   FICE_DSCFOP,
   FICE_DTINCLUSAO,
   FICE_USINCLUSAO)
values
  (SQ1_FATITCFOPESPECIF_FICE.NEXTVAL,
   (SELECT FCE_IDFATCFOPESPECIFICO
      FROM FATCFOPESPECIFICO_FCE
     WHERE FCE_VBINATIVACAO = 'F'
       AND FCE_DTVIGENCIADE <= SYSDATE
       AND FCE_DTVIGENCIAATE >= SYSDATE),
   (SELECT FCO_IDFATCLASSIFICACFOP
      FROM FATCLASSIFICACFOP_FCO
     WHERE UPPER(FCO_DSFATCLASSIFICACFOP) =
           UPPER('Opera��es vinculadas a exporta��o')),
   6505,
   'Remessa de mercadoria, adquirida ou recebida de terceiros, p/ forma��o de lote de exporta��o.',
   sysdate,
   get_user_mxm)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 273335
PROMPT ======================================================================