PROMPT ======================================================================
PROMPT == DEMANDA......: 277610
PROMPT == SISTEMA......: Vendas
PROMPT == RESPONSAVEL..: DIOGO_RODRIGUES
PROMPT == DATA.........: 11/09/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRECAMPOS_CDR
  (CDR_IDCAMPO,
   CDR_NRTABELA,
   CDR_DSCAMPOTABELA,
   CDR_DSCAMPO,
   CDR_TPCAMPO,
   CDR_DSCAMPOTABELACABECALHO)
VALUES
  ((SELECT MAX(CDR_IDCAMPO) + 1 FROM GRECAMPOS_CDR),
   (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'PEDVENDA_PDV'),
   'PEDVENDA_PDV.PDV_DESCRSERV',
   'Desc. Servi�os',
   0,
   'Desc. Servi�os')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 277610
PROMPT ======================================================================