PROMPT ======================================================================
PROMPT == DEMANDA......: 271340
PROMPT == SISTEMA......: MXM CONNECT
PROMPT == RESPONSAVEL..: SAMUEL MACHADO PINA DE MACEDO
PROMPT == DATA.........: 18/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE RECCARGOITEMAVALIACAO_CIA
ADD CIA_VBQUANTOMAISMELHOR NUMBER(1) DEFAULT 0 NOT NULL
/

ALTER TABLE RECCARGOITEMAVALIACAO_CIA
ADD CIA_VBQUANTOMENOSMELHOR NUMBER(1) DEFAULT 0 NOT NULL
/

COMMENT ON COLUMN RECCARGOITEMAVALIACAO_CIA.CIA_VBQUANTOMAISMELHOR IS 'Flag "Quanto mais melhor" dos itens de avalia��o de cargo'
/

COMMENT ON COLUMN RECCARGOITEMAVALIACAO_CIA.CIA_VBQUANTOMENOSMELHOR IS 'Flag "Quanto menos melhor" dos itens de avalia��o de cargo'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 271340
PROMPT ======================================================================