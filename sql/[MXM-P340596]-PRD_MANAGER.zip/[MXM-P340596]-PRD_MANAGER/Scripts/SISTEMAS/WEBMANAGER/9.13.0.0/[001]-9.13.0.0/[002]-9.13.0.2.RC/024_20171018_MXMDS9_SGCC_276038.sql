PROMPT ======================================================================
PROMPT == DEMANDA......: 276038
PROMPT == SISTEMA......: Contratos de Compras
PROMPT == RESPONSAVEL..: RODRIGO MASSAYOSHI TOMA
PROMPT == DATA.........: 17/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES (
    (SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR),
    (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA = 'ITCONTRATOS_ITC'),
    'ITCONTRATOS_ITC.ITC_ITEM',
    'C�digo do Item',0,'C�digo do Item')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276038
PROMPT ======================================================================