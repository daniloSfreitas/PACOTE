PROMPT ======================================================================
PROMPT == DEMANDA......: 273745
PROMPT == SISTEMA......: Sistema de Integracao Padrao
PROMPT == RESPONSAVEL..: THIAGO FERREIRA BARBOSA
PROMPT == DATA.........: 19/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO LAYOUTCOD_LYC (LYC_CODLAYOUT, LYC_MODELO, LYC_CAMPO, LYC_TIPO, LYC_POS, LYC_TAM, LYC_DEC, LYC_INDEX)
VALUES ('01', 'CLIENTES', 'CLI_GRPEMPRESARIAL', 'C', 614, 4, 0, 0)
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX)
VALUES ('CLIENTES', 'CLI_GRPEMPRESARIAL', 32, 'Grupo Empresarial', 'C', '4', 0, 0)
/

alter table TI_ARQCLIENTE_TACL add TACL_CDGRPEMPRESARIAL VARCHAR2(4)
/

comment on column TI_ARQCLIENTE_TACL.TACL_CDGRPEMPRESARIAL is 'C�digo do Grupo Empresarial'
/

CREATE OR REPLACE PROCEDURE INSTI_ARQCLIENTE_TACL
(
    PTACL_SQPROCESSO           IN NUMBER,
    PTACL_SQREGISTRO           IN NUMBER,
    PTACL_CODIGO               IN CHAR,
    PTACL_NOME                 IN CHAR,
    PTACL_ENDERECO             IN CHAR,
    PTACL_TIPESSOA             IN CHAR,
    PTACL_BAIRRO               IN CHAR,
    PTACL_CIDADE               IN CHAR,
    PTACL_UF                   IN CHAR,
    PTACL_CEP                  IN CHAR,
    PTACL_TELEFONE             IN CHAR,
    PTACL_CGC                  IN CHAR,
    PTACL_INSCRICAO            IN CHAR,
    PTACL_CONTATO              IN CHAR,
    PTACL_ENDERECO1            IN CHAR,
    PTACL_DTMOV                IN CHAR,
    PTACL_DTCAD                IN CHAR,
    PTACL_DTNASC               IN CHAR,
    PTACL_NOMEFANT             IN CHAR,
    PTACL_ATIVO                IN CHAR,
    PTACL_PAIS                 IN CHAR,
    PTACL_EMAIL                IN CHAR,
    PTACL_INSCMUNIC            IN CHAR,
    PTACL_INSCSUFRAMA          IN CHAR,
    PTACL_NAOPEDIR             IN CHAR,
    PTACL_CDGRUPO              IN CHAR,
    PTACL_TPENTREGA            IN CHAR,
    PTACL_TIPOINSC             IN CHAR,
    PTACL_DTINATIVO            IN CHAR,
    PTACL_MICROEMPRESA         IN CHAR,
    PTACL_ORGEXP               IN CHAR,
    PTACL_DTEXP                IN CHAR,
    PTACL_PROF                 IN CHAR,
    PTACL_CDNACIONALIDADE      IN CHAR,
    PTACL_ESTCIV               IN CHAR,
    PTACL_STOPERACAO           IN NUMBER,
    PTACL_CDPAIS               IN CHAR DEFAULT NULL,
   	PTACL_CDCIDADE             IN CHAR DEFAULT NULL,
    PTACL_NUMENDERECO          IN CHAR DEFAULT NULL,
    PTACL_COMPENDERECO         IN CHAR DEFAULT NULL,
    PTACL_TPINDIEDEST          IN CHAR DEFAULT NULL,
    PTACL_CDGRPEMPRESARIAL     IN CHAR DEFAULT NULL
)
AS
  BEGIN
    INSERT INTO TI_ARQCLIENTE_TACL(
    TACL_SQPROCESSO,
    TACL_SQREGISTRO,
    TACL_CODIGO,
    TACL_NOME,
    TACL_ENDERECO,
    TACL_TIPESSOA,
    TACL_BAIRRO,
    TACL_CIDADE,
    TACL_UF,
    TACL_CEP,
    TACL_TELEFONE,
    TACL_CGC,
    TACL_INSCRICAO,
    TACL_CONTATO,
    TACL_ENDERECO1,
    TACL_DTMOV,
    TACL_DTCAD,
    TACL_DTNASC,
    TACL_NOMEFANT,
    TACL_ATIVO,
    TACL_PAIS,
    TACL_EMAIL,
    TACL_INSCMUNIC,
    TACL_INSCSUFRAMA,
    TACL_NAOPEDIR,
    TACL_CDGRUPO,
    TACL_TPENTREGA,
    TACL_TIPOINSC,
    TACL_DTINATIVO,
    TACL_MICROEMPRESA,
    TACL_ORGEXP,
    TACL_DTEXP,
    TACL_PROF,
    TACL_CDNACIONALIDADE,
    TACL_ESTCIV,
    TACL_STOPERACAO,
    TACL_CDPAIS,
   	TACL_CDCIDADE,
    TACL_NUMENDERECO,
    TACL_COMPENDERECO,
    TACL_TPINDIEDEST,
    TACL_CDGRPEMPRESARIAL
)
      VALUES(
        PTACL_SQPROCESSO,
        PTACL_SQREGISTRO,
        PTACL_CODIGO,
        PTACL_NOME,
        PTACL_ENDERECO,
        PTACL_TIPESSOA,
        PTACL_BAIRRO,
        PTACL_CIDADE,
        PTACL_UF,
        PTACL_CEP,
        PTACL_TELEFONE,
        PTACL_CGC,
        PTACL_INSCRICAO,
        PTACL_CONTATO,
        PTACL_ENDERECO1,
        PTACL_DTMOV,
        PTACL_DTCAD,
        PTACL_DTNASC,
        PTACL_NOMEFANT,
        PTACL_ATIVO,
        PTACL_PAIS,
        PTACL_EMAIL,
        PTACL_INSCMUNIC,
        PTACL_INSCSUFRAMA,
        PTACL_NAOPEDIR,
        PTACL_CDGRUPO,
        PTACL_TPENTREGA,
        PTACL_TIPOINSC,
        PTACL_DTINATIVO,
        PTACL_MICROEMPRESA,
        PTACL_ORGEXP,
        PTACL_DTEXP,
        PTACL_PROF,
        PTACL_CDNACIONALIDADE,
        PTACL_ESTCIV,
        PTACL_STOPERACAO,
        PTACL_CDPAIS,
        PTACL_CDCIDADE,
        PTACL_NUMENDERECO,
        PTACL_COMPENDERECO,
        PTACL_TPINDIEDEST,
        PTACL_CDGRPEMPRESARIAL
        );
  END;
/

UPDATE layoutcod_lyc
  SET LYC_FORMATO   = 'DDMMAAAA'
where lyc_modelo    = 'LANCAMENTOS CONTABEIS'
  and lyc_index     = 0
  and lyc_codlayout = '01'
  and lyc_campo     = 'LCT_DATA'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 273745
PROMPT ======================================================================