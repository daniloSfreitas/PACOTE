PROMPT ======================================================================
PROMPT == DEMANDA......: 266926
PROMPT == SISTEMA......: Contas a Receber
PROMPT == RESPONSAVEL..: JOAO PAULO RODRIGUES JIMENEZ
PROMPT == DATA.........: 03/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_BARCODE
  (PT_CdEmpBco  IN CHAR,
   PT_CdBanco   IN CHAR,   -- Codigo do Banco    -- CTA_CDBANCO
   PT_Moeda     IN CHAR,   -- Moeda              -- TCR_MOEDA
   PT_DataVcto  IN DATE,   -- Data de Vencimento -- TCR_DTVENCIME
   PT_ValorTit  IN NUMBER, -- Valor do Titulo    -- TCR_VLRTITULO
   PT_NN        IN VARCHAR,-- Nosso Numero Gerado pelas fun��es de cada banco sem o DV
   PT_NNDV      IN VARCHAR DEFAULT NULL,-- Nosso Numero Gerado pelas fun��es de cada banco com o DV
   PT_Agencia   IN CHAR,   -- Numero da Agencia  -- TCR_AGENCIA
   PT_Conta     IN CHAR,   -- Conta Corrente
   PT_Carteira  IN CHAR)   -- Carteira
  RETURN VARCHAR
IS
 VR_FtVencime    NUMBER(10);
 VR_DvBarcode    VARCHAR2(50);
 VR_Dv1Barcode   VARCHAR2(1);
 VR_Dv2Barcode   VARCHAR2(1);
 VR_Barcode      VARCHAR2(50);
 VR_VlrTitTemp   VARCHAR2(50);
 VR_AgenciaTemp  VARCHAR2(50);
 VR_CdEmpBco     VARCHAR2(20);
BEGIN
   VR_FtVencime   := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
   VR_AgenciaTemp := SUBSTR(PT_Agencia,1,4);
   IF PT_CdBanco = '001' THEN
     --Atende a conv�nios de 4 e 6 posi��es do banco do brasil
     IF LENGTH(PT_CdEmpBco) = 4 THEN
       VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
       VR_DvBarcode  := PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NN || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),8,'0') || PT_Carteira;
       VR_DvBarcode  := mod11_barcode(VR_DvBarcode);
       VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || VR_DvBarcode || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NN || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),8,'0') || PT_Carteira,' ');
     ELSIF LENGTH(PT_CdEmpBco) = 6 THEN
       VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
       VR_DvBarcode  := PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NN || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),8,'0') || PT_Carteira;
       VR_DvBarcode  := mod11_barcode(VR_DvBarcode);
       VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || VR_DvBarcode || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NN || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),8,'0') || PT_Carteira,' ');
     END IF;
   ELSIF PT_CdBanco = '237' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || LPAD(VR_AgenciaTemp,4,'0') || LPAD(PT_Carteira,2,'0') || LPAD(PT_NN,11,'0')  || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0',' ');
     VR_DvBarcode  := MOD11_BARCODE_237(VR_Barcode);
     VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,39),' ');
   ELSIF PT_CdBanco = '341' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Dv1Barcode := GET_MOD10_CAMPOS033(VR_AgenciaTemp || SUBSTR(PT_Conta,1,5) || LPAD(PT_Carteira,3,'0') || PT_NN);
     VR_Dv2Barcode := GET_MOD10_CAMPOS033(VR_AgenciaTemp || SUBSTR(PT_Conta,1,5));
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || LPAD(PT_Carteira,3,'0') || PT_NN || VR_Dv1Barcode || VR_AgenciaTemp || SUBSTR(PT_Conta,1,5) || VR_Dv2Barcode || '000',' ');
     VR_DvBarcode  := MOD11_BARCODE_237(VR_Barcode);
     VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,44),' ');
   ELSIF PT_CdBanco = '033' THEN
     VR_CdEmpBco   := LPAD(SUBSTR(PT_CdEmpBco,6,7),7,'0');
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_DvBarcode  := PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '9' || PADL(VR_CdEmpBco,7,'0') || PADL(PT_NNDV,13,'0') || '0' || PT_Carteira;
     VR_DvBarcode  := mod11_barcode_033(VR_DvBarcode);
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || VR_DvBarcode || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '9' || PADL(VR_CdEmpBco,7,'0') || PADL(PT_NNDV,13,'0') || '0' || PT_Carteira,' ');
   ELSIF PT_CdBanco = '104' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Barcode    := PADL(PT_CdEmpBco || GET_MOD11_NN104(PT_CdEmpBco),7,'0') || PADL(SUBSTR(PT_NN,3,3),3,'0') || SUBSTR(PT_Carteira,1,1) || PADL(SUBSTR(PT_NN,6,3),3,'0') || SUBSTR(PT_Carteira,2,1) || PADL(SUBSTR(PT_NN,9,9),9,'0');
     VR_Dv1Barcode := GET_MOD11_NN104(VR_BarCode);
     VR_DvBarcode  := PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || VR_Barcode || VR_Dv1Barcode;
     VR_DvBarcode  := mod11_barcode(VR_DvBarcode);
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || VR_DvBarcode || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || VR_Barcode || VR_Dv1Barcode, ' ');
   ELSIF PT_CdBanco = '399' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NNDV || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,7),7,'0') || PT_Carteira || '1',' ');
     VR_DvBarcode  := MOD11_BARCODE_399(VR_Barcode);
     VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,44),' ');
   ELSIF PT_CdBanco = '755' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PADL(PT_CdEmpBco,12,'0') || LPAD(PT_NN,10,'0') || PT_Carteira || '4', ' ');
     VR_DvBarcode  := mod11_barcode(VR_Barcode);
     VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,44),' ');
   ELSIF PT_CdBanco = '633' THEN
     IF PT_Carteira IN ('02','06','07','09') THEN
       VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
       VR_Barcode    := REPLACE('237' || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || LPAD(VR_AgenciaTemp,4,'0') || LPAD(PT_Carteira,2,'0') || LPAD(PT_NN,11,'0')  || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0',' ');
       VR_DvBarcode  := MOD11_BARCODE_237(VR_Barcode);
       VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,39),' ');
     ELSE
       VR_CdEmpBco   := LPAD(SUBSTR(PT_CdEmpBco,6,7),7,'0');
       VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
       VR_DvBarcode  := '033' || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '9' || PADL(VR_CdEmpBco,7,'0') || PADL(PT_NNDV,13,'0') || '0' || PT_Carteira;
       VR_DvBarcode  := mod11_barcode_033(VR_DvBarcode);
       VR_Barcode    := REPLACE('033' || PT_Moeda || VR_DvBarcode || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '9' || PADL(VR_CdEmpBco,7,'0') || PADL(PT_NNDV,13,'0') || '0' || PT_Carteira,' ');
     END IF;
   ELSIF PT_CdBanco = '422' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '7' || LPAD(REPLACE(PT_Agencia,'-',''),5,'0') || LPAD(REPLACE(PT_Conta,'-',''),9,'0') || LPAD(PT_NNDV,9,'0') || '2',' ');
     VR_DvBarcode  := GET_MOD11_BARCODE_422(VR_Barcode);
     VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,39),' ');
   END IF;
   RETURN VR_Barcode;
END;
/

CREATE OR REPLACE FUNCTION GET_LINHADIGITAVEL
  (PT_CdEmpBco  IN CHAR DEFAULT NULL, --Codigo da  Empresa no Banco (CTA_CDEMPBCO)
   PT_CdBanco   IN CHAR,        -- Codigo do Banco    -- CTA_CDBANCO
   PT_Moeda     IN CHAR,        -- Moeda              -- TCR_MOEDA
   PT_NN        IN VARCHAR,           -- Nosso Numero Gerado pelas fun��es de cada banco sem o DV
   PT_NNDV      IN VARCHAR DEFAULT NULL, -- Nosso Numero Gerado pelas fun��es de cada banco com o DV
   PT_DataVcto  IN DATE,        -- Data de Vencimento -- TCR_DTVENCIME
   PT_ValorTit  IN NUMBER,      -- Valor do Titulo    -- TCR_VLRTITULO
   PT_BARCODE   IN VARCHAR2,
   PT_Carteira  IN CHAR,
   PT_Agencia   IN CHAR,
   PT_Conta     IN CHAR)
  RETURN VARCHAR
IS
 VR_LINHAD       VARCHAR2(50);
 VR_DVCAMPO1     CHAR;
 VR_DVCAMPOS1    VARCHAR2(2);
 VR_DVCAMPOS2    VARCHAR2(2);
 VR_DVCAMPOS3    VARCHAR2(2);
 VR_FtVencime    NUMBER(10);
 VR_VlrTitTemp   VARCHAR2(50);
 VR_AgenciaTemp  VARCHAR2(50);
 VR_CAMPO1       VARCHAR2(40);
 VR_CAMPO2       VARCHAR2(40);
 VR_CAMPO3       VARCHAR2(40);
 VR_CAMPO4       VARCHAR2(40);
 VR_CAMPO5       VARCHAR2(40);
 VR_STRTEMP      VARCHAR2(44);
 VR_DIGITAOCDBARRAS CHAR;
BEGIN
  VR_AgenciaTemp := SUBSTR(PT_Agencia,1,4);
  IF PT_CdBanco = '341' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_STRTEMP := PT_CdBanco || PT_Moeda || SUBSTR(LPAD(PT_Carteira,3,'0'),1,3) || SUBSTR(PT_NNDV,1,2);
    VR_CAMPO1 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_STRTEMP := SUBSTR(PT_NNDV,1,7) || SUBSTR(VR_AgenciaTemp,1,3);
    VR_CAMPO2 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_STRTEMP := SUBSTR(VR_AgenciaTemp,4,1) || REPLACE(SUBSTR(PT_Conta,1,6),'-') || '000';
    VR_CAMPO3 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || VR_FtVencime || VR_VlrTitTemp || SUBSTR(LPAD(PT_Carteira,3,'0'),1,3) || SUBSTR(PT_NNDV,1,9) || VR_AgenciaTemp || PT_Conta || '000',' ');
    VR_CAMPO4 := mod11_barcode_033(VR_STRTEMP);
    VR_LINHAD:= REPLACE(VR_CAMPO1 || VR_CAMPO2 || VR_CAMPO3 || VR_CAMPO4 || VR_CAMPO5,' ');
  END IF;
  IF PT_CdBanco = '033' THEN
    VR_STRTEMP := PT_CdBanco || PT_Moeda || '9' || SUBSTR(PT_CdEmpBco,6,4);
    VR_CAMPO1 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_STRTEMP := SUBSTR(PT_CdEmpBco,10,3) || SUBSTR(PT_NNDV,1,7);
    VR_CAMPO2 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_STRTEMP := SUBSTR(PT_NNDV,8,6) || '0' || SUBSTR(PT_Carteira,1,3);
    VR_CAMPO3 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_CAMPO4 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || VR_FtVencime || VR_VlrTitTemp || '9' || SUBSTR(PT_CdEmpBco,6,7)  || SUBSTR(PT_NNDV,1,13) || '0' || SUBSTR(PT_Carteira,1,3),' ');
    VR_DIGITAOCDBARRAS := mod11_barcode_033(VR_STRTEMP);
    VR_LINHAD:= REPLACE(VR_CAMPO1 || VR_CAMPO2 || VR_CAMPO3 || VR_DIGITAOCDBARRAS || VR_CAMPO4,' ');
  ELSIF PT_CdBanco = '237' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || VR_AgenciaTemp || PT_Carteira || PT_NN || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0',' ');
    VR_CAMPO1 := PT_CdBanco || PT_Moeda || VR_AgenciaTemp || SUBSTR(PT_Carteira,1,1);
    VR_DVCAMPOS1 := GET_MOD10_CAMPOS033(VR_CAMPO1);
    VR_CAMPO2 := SUBSTR(PT_Carteira,2,1) || SUBSTR(PT_NN,1,9);
    VR_DVCAMPOS2 := GET_MOD10_CAMPOS033(VR_CAMPO2);
    VR_CAMPO3 := SUBSTR(PT_NN,10,2) || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0';
    VR_DVCAMPOS3 := GET_MOD10_CAMPOS033(VR_CAMPO3);
    VR_CAMPO4 := MOD11_BARCODE_237(VR_STRTEMP);
    VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_LINHAD := REPLACE(VR_CAMPO1 || VR_DVCAMPOS1 || VR_CAMPO2 || VR_DVCAMPOS2 || VR_CAMPO3 || VR_DVCAMPOS3 || VR_CAMPO4 || VR_CAMPO5,' ');
  ELSIF PT_CdBanco = '399' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NNDV || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,7),7,'0') || PT_Carteira || '1',' ');
    VR_CAMPO1 := PT_CdBanco || PT_Moeda || SUBSTR(PT_NNDV,1,5);
    VR_DVCAMPOS1 := GET_MOD10_CAMPOS399(VR_CAMPO1);
    VR_CAMPO2 := SUBSTR(PT_NNDV,6,6) || VR_AgenciaTemp;
    VR_DVCAMPOS2 := GET_MOD10_CAMPOS399(VR_CAMPO2);
    VR_CAMPO3 := LPAD(SUBSTR(PT_Conta,1,7),7,'0') || SUBSTR(PT_Carteira,1,2) || '1';
    VR_DVCAMPOS3 := GET_MOD10_CAMPOS399(VR_CAMPO3);
    VR_CAMPO4 := MOD11_BARCODE_399(VR_STRTEMP);
    VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_LINHAD := REPLACE(VR_CAMPO1 || VR_DVCAMPOS1 || VR_CAMPO2 || VR_DVCAMPOS2 || VR_CAMPO3 || VR_DVCAMPOS3 || VR_CAMPO4 || VR_CAMPO5,' ');
  ELSIF PT_CdBanco = '755' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PADL(PT_CdEmpBco,12,'0') || PADL(PT_NN,10,'0') || PT_Carteira || '4', ' ');
    VR_CAMPO1 := PT_CdBanco || PT_Moeda || SUBSTR(PT_CdEmpBco,1,5);
    VR_DVCAMPOS1 := GET_MOD10_CAMPOS033(VR_CAMPO1);
    VR_CAMPO2 := SUBSTR(PT_CdEmpBco,6,7) || SUBSTR(PT_NN,1,3);
    VR_DVCAMPOS2 := GET_MOD10_CAMPOS033(VR_CAMPO2);
    VR_CAMPO3 := SUBSTR(PT_NN,4,7) || PT_Carteira || '4';
    VR_DVCAMPOS3 := GET_MOD10_CAMPOS033(VR_CAMPO3);
    VR_CAMPO4 := mod11_barcode(VR_STRTEMP);
    VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_LINHAD := REPLACE(VR_CAMPO1 || VR_DVCAMPOS1 || VR_CAMPO2 || VR_DVCAMPOS2 || VR_CAMPO3 || VR_DVCAMPOS3 || VR_CAMPO4 || VR_CAMPO5,' ');
  ELSIF PT_CdBanco = '633' THEN
    IF PT_Carteira IN ('02','06','07','09') THEN
      VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
      VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
      VR_STRTEMP := REPLACE('237' || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || VR_AgenciaTemp || PT_Carteira || PT_NN || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0',' ');
      VR_CAMPO1 := '237' || PT_Moeda || VR_AgenciaTemp || SUBSTR(PT_Carteira,1,1);
      VR_DVCAMPOS1 := GET_MOD10_CAMPOS033(VR_CAMPO1);
      VR_CAMPO2 := SUBSTR(PT_Carteira,2,1) || SUBSTR(PT_NN,1,9);
      VR_DVCAMPOS2 := GET_MOD10_CAMPOS033(VR_CAMPO2);
      VR_CAMPO3 := SUBSTR(PT_NN,10,2) || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0';
      VR_DVCAMPOS3 := GET_MOD10_CAMPOS033(VR_CAMPO3);
      VR_CAMPO4 := MOD11_BARCODE_237(VR_STRTEMP);
      VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
      VR_LINHAD := REPLACE(VR_CAMPO1 || VR_DVCAMPOS1 || VR_CAMPO2 || VR_DVCAMPOS2 || VR_CAMPO3 || VR_DVCAMPOS3 || VR_CAMPO4 || VR_CAMPO5,' ');
    ELSE
      VR_STRTEMP := '033' || PT_Moeda || '9' || SUBSTR(PT_CdEmpBco,6,4);
      VR_CAMPO1 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
      VR_STRTEMP := SUBSTR(PT_CdEmpBco,10,3) || SUBSTR(PT_NNDV,1,7);
      VR_CAMPO2 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
      VR_STRTEMP := SUBSTR(PT_NNDV,8,6) || '0' || SUBSTR(PT_Carteira,1,3);
      VR_CAMPO3 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
      VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
      VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
      VR_CAMPO4 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
      VR_STRTEMP := REPLACE('033' || PT_Moeda || VR_FtVencime || VR_VlrTitTemp || '9' || SUBSTR(PT_CdEmpBco,6,7)  || SUBSTR(PT_NNDV,1,13) || '0' || SUBSTR(PT_Carteira,1,3),' ');
      VR_DIGITAOCDBARRAS := mod11_barcode_033(VR_STRTEMP);
      VR_LINHAD:= REPLACE(VR_CAMPO1 || VR_CAMPO2 || VR_CAMPO3 || VR_DIGITAOCDBARRAS || VR_CAMPO4,' ');
    END IF;
  ELSIF PT_CdBanco = '422' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '7' || LPAD(REPLACE(PT_Agencia,'-',''),5,'0') || LPAD(REPLACE(PT_Conta,'-',''),9,'0') || LPAD(PT_NNDV,9,'0') || '2',' ');
    VR_CAMPO1 := PT_CdBanco || PT_Moeda || '7' || VR_AgenciaTemp;
    VR_DVCAMPOS1 := GET_MOD10_CAMPOS422(VR_CAMPO1);
    VR_CAMPO2 := SUBSTR(LPAD(REPLACE(PT_Agencia,'-',''),5,'0'), LENGTH(LPAD(REPLACE(PT_Agencia,'-',''),5,'0')),1) || LPAD(REPLACE(PT_Conta,'-',''),9,'0');
    VR_DVCAMPOS2 := GET_MOD10_CAMPOS422(VR_CAMPO2);
    VR_CAMPO3 := REPLACE(PT_NNDV,'-','') || '2';
    VR_DVCAMPOS3 := GET_MOD10_CAMPOS422(VR_CAMPO3);
    VR_CAMPO4 := GET_MOD11_BARCODE_422(VR_STRTEMP);
    VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_LINHAD := REPLACE(VR_CAMPO1 || VR_DVCAMPOS1 || VR_CAMPO2 || VR_DVCAMPOS2 || VR_CAMPO3 || VR_DVCAMPOS3 || VR_CAMPO4 || VR_CAMPO5,' ');
  ELSIF PT_CdBanco = '001' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_DVCAMPO1   := GET_MOD10(TO_CHAR(PT_CdBanco || PT_Moeda || SUBSTR(PT_BARCODE,20,5)));
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_LINHAD := REPLACE(PT_CdBanco || PT_Moeda || SUBSTR(PT_BARCODE,20,5) || VR_DVCAMPO1 || SUBSTR(PT_BARCODE,25,10) ||
    GET_MOD10(TO_CHAR(SUBSTR(PT_BARCODE,25,10))) || SUBSTR(PT_BARCODE,35,10) || GET_MOD10(TO_CHAR(SUBSTR(PT_BARCODE,35,10)))
    || SUBSTR(PT_BARCODE,5,1) || VR_FtVencime || VR_VlrTitTemp,' ');
  ELSE
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_DVCAMPO1   := GET_MOD10(TO_CHAR(PT_CdBanco || PT_Moeda || SUBSTR(PT_BARCODE,20,5)));
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_LINHAD := REPLACE(PT_CdBanco || PT_Moeda || SUBSTR(PT_BARCODE,20,5) || VR_DVCAMPO1 || SUBSTR(PT_BARCODE,25,10) ||
    GET_MOD10(TO_CHAR(SUBSTR(PT_BARCODE,25,10))) || SUBSTR(PT_BARCODE,35,10) || GET_MOD10(TO_CHAR(SUBSTR(PT_BARCODE,35,10)))
    || SUBSTR(PT_BARCODE,5,1) || VR_FtVencime || VR_VlrTitTemp,' ');
  END IF;
  RETURN VR_LINHAD;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 266926
PROMPT ======================================================================