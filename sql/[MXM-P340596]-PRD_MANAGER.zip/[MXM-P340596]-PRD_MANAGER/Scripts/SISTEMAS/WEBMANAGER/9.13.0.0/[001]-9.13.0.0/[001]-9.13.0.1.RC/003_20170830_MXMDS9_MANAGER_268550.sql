PROMPT ======================================================================
PROMPT == DEMANDA......: 268550
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: IGOR LUIZ HASTENREITER BORGES
PROMPT == DATA.........: 27/04/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE FATITFATIMPOSTO_IFI MODIFY IFI_VLICMSOPERACAO NUMBER(15,4)
/

ALTER TABLE SGEITMOVIMPOSTO_MVI MODIFY MVI_VLICMSOPERACAO NUMBER(15,4)
/

ALTER TABLE SIPITPEDIMPOSTO_IPI MODIFY IPI_VLICMSOPERACAO NUMBER(15,4)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 268550
PROMPT ======================================================================