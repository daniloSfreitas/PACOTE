PROMPT ======================================================================
PROMPT == DEMANDA......: 272529
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: MARCEL BRUNO BARREIROS COSTA
PROMPT == DATA.........: 05/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRECAMPOS_CDR SET CDR_DSCAMPOTABELA = 'MOEDACONV(CALCJDC(''TCP'', TITCP_TCP.TCP_CDFOR, TITCP_TCP.TCP_NOTITULO, TITCP_TCP.TCP_MOEDA, NULL, TITCP_TCP.TCP_DTENTRADA, ''L'', ''S'','''', ''''), :PARAM_TCP_MOEDA, TITCP_TCP.TCP_MOEDA, TITCP_TCP.TCP_DTMOVP, TITCP_TCP.TCP_VLRCOTACAOPR, EMP.EMP_MOEDACOR)'
WHERE CDR_DSCAMPOTABELA = 'CALCJDC(''TCP'', TITCP_TCP.TCP_CDFOR, TITCP_TCP.TCP_NOTITULO,:PTITCP_TCP.TCP_MOEDA, NULL, TITCP_TCP.TCP_DTENTRADA, ''L'', ''S'','''', '''')'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 272529
PROMPT ======================================================================