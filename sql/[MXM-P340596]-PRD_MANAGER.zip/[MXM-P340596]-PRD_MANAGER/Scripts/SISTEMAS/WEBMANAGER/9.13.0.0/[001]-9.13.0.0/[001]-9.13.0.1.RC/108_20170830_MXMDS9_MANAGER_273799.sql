PROMPT ======================================================================
PROMPT == DEMANDA......: 273799
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: IGOR LUIZ HASTENREITER BORGES
PROMPT == DATA.........: 21/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE CODIPI_CIPI
MODIFY CIPI_NRCEST VARCHAR2(7)
/

CREATE OR REPLACE PROCEDURE INSCODIPI_CIPI
  (PCIPI_CODIGO            IN CHAR,
   PCIPI_DESCRICAO         IN CHAR,
   PCIPI_CLFISCAL          IN CHAR,
   PCIPI_PERCII            IN NUMBER,
   PCIPI_PERC              IN NUMBER,
   PCIPI_PERC0             IN NUMBER,
   PCIPI_ALIQPIS           IN NUMBER,
   PCIPI_ALIQCOFINS        IN NUMBER,
   PCIPI_CST               IN CHAR,
   PCIPI_PISPAUTADO        IN NUMBER default null,
   PCIPI_COFINSPAUTADO     IN NUMBER default null,
   PCIPI_SUBSTTRIB         IN CHAR default null,
   PCIPI_REDALIQPIS        IN NUMBER default null,
   PCIPI_REDALIQCOFINS     IN NUMBER default null,
   PCIPI_PEALIQCOFINSMAJDI IN NUMBER default null,
   PCIPI_UNIDADE           IN CHAR DEFAULT NULL,
   PCIPI_EX                IN VARCHAR default null,
   PCIPI_GENERO            IN NUMBER default null,
   PCIPI_CLFISCALNBS       IN CHAR default null,
   PCIPI_NRCEST            IN CHAR DEFAULT NULL
   )
AS BEGIN
   INSERT INTO CODIPI_CIPI
    (CIPI_CODIGO,
     CIPI_DESCRICAO,
     CIPI_CLFISCAL,
     CIPI_PERCII,
     CIPI_PERC,
     CIPI_PERC0,
     CIPI_ALIQPIS,
     CIPI_ALIQCOFINS,
     CIPI_CST,
     CIPI_SUBSTTRIB,
     CIPI_REDALIQPIS,
     CIPI_REDALIQCOFINS,
     CIPI_PEALIQCOFINSMAJDI,
     CIPI_UNIDADE,
     CIPI_EX,
     CIPI_GENERO,
     CIPI_PISPAUTADO,
     CIPI_COFINSPAUTADO,
     CIPI_CLFISCALNBS,
     CIPI_NRCEST
     )
   VALUES
    (PCIPI_CODIGO,
     PCIPI_DESCRICAO,
     PCIPI_CLFISCAL,
     PCIPI_PERCII,
     PCIPI_PERC,
     PCIPI_PERC0,
     PCIPI_ALIQPIS,
     PCIPI_ALIQCOFINS,
     PCIPI_CST,
     PCIPI_SUBSTTRIB,
     PCIPI_REDALIQPIS,
     PCIPI_REDALIQCOFINS,
     PCIPI_PEALIQCOFINSMAJDI,
     PCIPI_UNIDADE,
     PCIPI_EX,
     PCIPI_GENERO,
     PCIPI_PISPAUTADO,
     PCIPI_COFINSPAUTADO,
     PCIPI_CLFISCALNBS,
     PCIPI_NRCEST);
END;
/

CREATE OR REPLACE PROCEDURE ALTCODIPI_CIPI
  (PCIPI_CODIGO            IN CHAR,
   PCIPI_DESCRICAO         IN CHAR,
   PCIPI_CLFISCAL          IN CHAR,
   PCIPI_PERCII            IN NUMBER,
   PCIPI_PERC0             IN NUMBER,
   PCIPI_ALIQPIS           IN NUMBER,
   PCIPI_ALIQCOFINS        IN NUMBER,
   PCIPI_PERC              IN NUMBER,
   PCIPI_CST               IN CHAR,
   PCIPI_SUBSTTRIB         IN CHAR default null,
   PCIPI_REDALIQPIS        IN NUMBER default null,
   PCIPI_REDALIQCOFINS     IN NUMBER default null,
   PCIPI_PEALIQCOFINSMAJDI IN NUMBER default null,
   PCIPI_UNIDADE           IN CHAR DEFAULT NULL,
   PCIPI_EX                IN varchar default null,
   PCIPI_GENERO            IN NUMBER DEFAULT NULL,
   PCIPI_PISPAUTADO        IN NUMBER,
   PCIPI_COFINSPAUTADO     IN NUMBER,
   PCIPI_CLFISCALNBS       IN CHAR default null,
   PCIPI_NRCEST            IN CHAR DEFAULT NULL
   )
AS BEGIN
   UPDATE CODIPI_CIPI
      SET CIPI_DESCRICAO         = PCIPI_DESCRICAO,
          CIPI_PERC0             = PCIPI_PERC0,
          CIPI_PERC              = PCIPI_PERC,
          CIPI_PERCII            = PCIPI_PERCII,
          CIPI_ALIQPIS           = PCIPI_ALIQPIS,
          CIPI_ALIQCOFINS        = PCIPI_ALIQCOFINS,
          CIPI_CLFISCAL          = PCIPI_CLFISCAL,
          CIPI_CST               = PCIPI_CST,
          CIPI_SUBSTTRIB         = PCIPI_SUBSTTRIB,
          CIPI_REDALIQPIS        = PCIPI_REDALIQPIS,
          CIPI_REDALIQCOFINS     = PCIPI_REDALIQCOFINS,
          CIPI_PEALIQCOFINSMAJDI = PCIPI_PEALIQCOFINSMAJDI,
          CIPI_UNIDADE           = PCIPI_UNIDADE,
          CIPI_EX                = PCIPI_EX,
          CIPI_GENERO            = PCIPI_GENERO,
          CIPI_PISPAUTADO        = PCIPI_PISPAUTADO,
          CIPI_COFINSPAUTADO     = PCIPI_COFINSPAUTADO,
          CIPI_CLFISCALNBS       = PCIPI_CLFISCALNBS,
          CIPI_NRCEST            = PCIPI_NRCEST
    WHERE CIPI_CODIGO            = PCIPI_CODIGO;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 273799
PROMPT ======================================================================