PROMPT ======================================================================
PROMPT == DEMANDA......: 269041
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: LUIZ GUSTAVO FERREIRA SODRE
PROMPT == DATA.........: 12/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE MXS_FUNCAO_MXF
   SET MXF_TITULO = 'Ambiente para Recep��o de NF-e / NFS-e',
       MXF_DESCRICAO = 'Utilit�rios de Ambiente para Recep��o de NF-e / NFS-e'
WHERE MXF_FUNCAO = 40201
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 269041
PROMPT ======================================================================