PROMPT ======================================================================
PROMPT == DEMANDA......: 270279
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: Eduardo Lopes de Oliveira
PROMPT == DATA.........: 02/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

alter table  NFECARGATRIBMEDIAIBPT_CTM modify CTM_DSCDNCM varchar(2000)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 270279
PROMPT ======================================================================