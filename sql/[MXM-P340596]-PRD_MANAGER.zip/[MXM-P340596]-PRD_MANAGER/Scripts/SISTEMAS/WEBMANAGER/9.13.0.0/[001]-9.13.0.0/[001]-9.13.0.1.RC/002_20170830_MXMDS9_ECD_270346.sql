PROMPT ======================================================================
PROMPT == DEMANDA......: 270346
PROMPT == SISTEMA......: Escritura��o Cont�bil Digital
PROMPT == RESPONSAVEL..: CELSO DE OLIVEIRA JUNIOR
PROMPT == DATA.........: 26/04/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO SPEDQUALIFASSINANTE_SQA (SQA_CDQUALIFICACAO, SQA_DESCRICAO) VALUES ('001', 'Pessoa Jur�dica(e-CNPJ ou e-PJ)')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 270346
PROMPT ======================================================================