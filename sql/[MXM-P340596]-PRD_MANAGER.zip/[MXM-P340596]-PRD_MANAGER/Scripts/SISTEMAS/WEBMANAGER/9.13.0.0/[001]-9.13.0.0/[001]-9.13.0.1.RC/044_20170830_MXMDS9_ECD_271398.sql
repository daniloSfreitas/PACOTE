PROMPT ======================================================================
PROMPT == DEMANDA......: 271398
PROMPT == SISTEMA......: Escritura��o Cont�bil Digital
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 17/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE ECD_PROCESSA_RI200 (PSME_CODIGO IN VARCHAR2, PTOTALREGISTRO_I200 OUT NUMBER, PTOTALREGISTRO_I250 OUT NUMBER) AS
--TIPOS RI200
  TYPE TP_NUM_LCTO           IS TABLE OF SPEDECDLANCCTBV10_RI200.NUM_LCTO%TYPE;
  TYPE TP_DT_LCTO            IS TABLE OF VARCHAR2(8);--SPEDECDLANCCTBV10_RI200.DT_LCTO%TYPE;
  TYPE TP_VL_LCTO            IS TABLE OF SPEDECDLANCCTBV10_RI200.VL_LCTO%TYPE;
  TYPE TP_IND_LCTO           IS TABLE OF SPEDECDLANCCTBV10_RI200.IND_LCTO%TYPE;
--  TYPE TP_IDRI200            IS TABLE OF SPEDECDLANCCTBV10_RI200.IDRI200%TYPE;
  TYPE TP_REGI200            IS TABLE OF VARCHAR2(8);
--VARIAVEIS RI200
  LST_NUM_LCTO               TP_NUM_LCTO;
  LST_DT_LCTO                TP_DT_LCTO;
  LST_VL_LCTO                TP_VL_LCTO;
  LST_IND_LCTO               TP_IND_LCTO;
  LST_REGI200                TP_REGI200;
--TIPOS RI250
  TYPE TP_COD_CTA            IS TABLE OF SPEDECDPARTLANCV10_RI250.COD_CTA%TYPE;
  TYPE TP_COD_CCUS           IS TABLE OF SPEDECDPARTLANCV10_RI250.COD_CCUS%TYPE;
  TYPE TP_VL_DC              IS TABLE OF SPEDECDPARTLANCV10_RI250.VL_DC%TYPE;
  TYPE TP_IND_DC             IS TABLE OF SPEDECDPARTLANCV10_RI250.IND_DC%TYPE;
  TYPE TP_COD_HIST_PAD       IS TABLE OF SPEDECDPARTLANCV10_RI250.COD_HIST_PAD%TYPE;
  TYPE TP_HIST               IS TABLE OF SPEDECDPARTLANCV10_RI250.HIST%TYPE;
  TYPE TP_COD_PART           IS TABLE OF SPEDECDPARTLANCV10_RI250.COD_PART%TYPE;
  TYPE TP_REGI250            IS TABLE OF SPEDECDPARTLANCV10_RI250.REG%TYPE;
  TYPE TP_LCT_LOTE           IS TABLE OF LANCCTB_LCT.LCT_LOTE%TYPE;
--VARIAVEIS RI250
  LST_COD_CTA                TP_COD_CTA;
  LST_COD_CCUS               TP_COD_CCUS;
  LST_VL_DC                  TP_VL_DC;
  LST_IND_DC                 TP_IND_DC;
  LST_COD_HIST_PAD           TP_COD_HIST_PAD;
  LST_HIST                   TP_HIST;
  LST_COD_PART               TP_COD_PART;
  LST_REGI250                TP_REGI250;
  LST_LCT_LOTE               TP_LCT_LOTE;
  PIDR200                    NUMBER;
  QRY                        LONG;
  STR_EQUIV                  LONG;
  CDEMPRESA                  VARCHAR2(4);
  DTINICIO                   DATE;
  DTFIM                      DATE;
  DTPROCESSA                 DATE;
  NUMLANCCTBATU              SPEDECDLANCCTBV10_RI200.NUM_LCTO%TYPE;
  ISCONSOLIDADORA            VARCHAR2(1);
  ISUTILIZACCUSTO            VARCHAR2(1);
  CURSOR GET_EMPRESA_FROM_SMECODIGO IS
    SELECT SME_CDEMPRESA,SME_DTINICIO,SME_DTFIM
      FROM SPEDMODELOESCRT_SME
     WHERE SME_CODIGO = PSME_CODIGO;
  CURSOR GET_EMPRESA_CONSOLIDADORA IS
    SELECT EMP_CONSOLIDACAO
      FROM EMPGERAL_EMP
     WHERE EMP_CODIGO = CDEMPRESA;
  CURSOR GET_PAR_ECD_UTILIZACCUSTO_ECD IS
     SELECT PAR_VLPARAM
       FROM PARAMS_PAR
      WHERE PAR_CDPARAM = 'wECD_UTILIZAR_CENTRO_CUSTO_NO_ECD'||CDEMPRESA;
BEGIN
  DELETE FROM SPEDECDPARTLANCV10_RI250 WHERE SMECODIGO = PSME_CODIGO;
  DELETE FROM SPEDECDLANCCTBV10_RI200  WHERE SMECODIGO = PSME_CODIGO;
  /*Busca a empresa de acordo com o SMECodigo*/
  OPEN GET_EMPRESA_FROM_SMECODIGO;
  FETCH GET_EMPRESA_FROM_SMECODIGO INTO CDEMPRESA,DTINICIO,DTFIM;
  CLOSE GET_EMPRESA_FROM_SMECODIGO;
  OPEN GET_EMPRESA_CONSOLIDADORA;
  FETCH GET_EMPRESA_CONSOLIDADORA  INTO ISCONSOLIDADORA;
  CLOSE GET_EMPRESA_CONSOLIDADORA;
  OPEN  GET_PAR_ECD_UTILIZACCUSTO_ECD;
  FETCH GET_PAR_ECD_UTILIZACCUSTO_ECD INTO ISUTILIZACCUSTO;
  CLOSE GET_PAR_ECD_UTILIZACCUSTO_ECD;
  STR_EQUIV  := '';
  STR_EQUIV  := GET_LANCCTB_EQUIV(CDEMPRESA);
  DTPROCESSA := DTINICIO;
  PTOTALREGISTRO_I200 := 0;
  PTOTALREGISTRO_I250 := 0;
  NUMLANCCTBATU       := '0';
  WHILE DTPROCESSA <= DTFIM
  LOOP
    QRY := '';
    QRY := QRY || ' SELECT REPLACE(SPED_RETIRA_CHARS(LCT.LCT_CDEMPRESA || LCT.LCT_LOTE || LCT.LCT_LANCCTB || TO_CHAR(LCT.LCT_DATA, ''DDMMYYYY'')),'' '') AS NUM_LCTO';
    QRY := QRY || ' , ''I200'' AS REGRI200';
    QRY := QRY || ' , TO_CHAR(LCT.LCT_DATA,''DDMMYYYY'') AS DT_LCTO';
    QRY := QRY || ' , DECODE(LCT.LCT_LOTE,''ENCERR'',''E'',''N'') AS IND_LCTO';
    QRY := QRY || ' , TOTALIZADOR.TOT_LCTO';
    QRY := QRY || ' , ''I250'' AS REGRI250';
    QRY := QRY || ' , MONTAMASCARA(LCT_NOCONTAB, CPLC_MASCARA)        AS COD_CTA';
    IF ISUTILIZACCUSTO = 'S'
     THEN QRY := QRY || ' , ''               '' AS COD_CCUS';
     ELSE QRY := QRY || ' , LCT_NOCCUSTO  AS COD_CCUS';
    END IF;
    QRY := QRY || ' , REPLACE(TO_CHAR(LCT_VALOR, ''9999999999999990.99''), ''.'', '','') AS VL_DC';
    QRY := QRY || ' , LCT_DC AS IND_DC';
    QRY := QRY || ' , DECODE(NVL(PLC_HISTCRED,''*''),''*'',DECODE(NVL(PLC_HISTDEB,''*''),''*'','''',PLC_HISTDEB),PLC_HISTCRED) AS COD_HIS_PAD';
    QRY := QRY || ' , REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( REPLACE( REPLACE( REPLACE( LCT_HISTORICO,CHR(9),'' ''),CHR(10),'' ''),CHR(13),'' ''),''|'',''-''),CHR(18),'' ''),CHR(00),'' ''),CHR(01),'' ''),CHR(02),'' ''),CHR(03),'' ''),CHR(04),'' ''),CHR(05),'' ''),CHR(06),'' ''),CHR(07),'' ''),CHR(08),'' ''),CHR(11),'' ''),CHR(12),'' ''),CHR(14),'' ''),CHR(15),'' ''),CHR(16),'' ''),CHR(17),'' ''),CHR(19),'' ''),CHR(20),'' ''),CHR(21),'' ''),CHR(22),'' ''),CHR(23),'' ''),CHR(24),'' ''),CHR(25),'' ''),CHR(26),'' ''),CHR(27),'' ''),CHR(28),'' ''),CHR(29),'' ''),CHR(30),'' ''),CHR(31),'' ''),CHR(127),'' '') AS HIST';
    QRY := QRY || ' , CODIGOPART  AS COD_PART';
    QRY := QRY || ' , REPLACE(SPED_RETIRA_CHARS(LCT.LCT_LOTE),'' '') AS LCT_LOTE';
    QRY := QRY || ' FROM '|| STR_EQUIV || ' LCT';
    QRY := QRY || ',SPEDMODELOESCRT_SME SME';
    QRY := QRY || ',EMPGERAL_EMP EMP';
    QRY := QRY || ', ( SELECT SME.SME_CODIGO';
    QRY := QRY || '          ,LCT.LCT_CDEMPRESA   AS LCT_CDEMPRESARELAC';
    QRY := QRY || '          ,LCT.LCT_LOTE    AS LCT_LOTERELAC';
    QRY := QRY || '          ,LCT.LCT_LANCCTB AS LCT_LANCCTBRELAC';
    QRY := QRY || '          ,LCT.LCT_DATA    AS LCT_DATARELAC';
    QRY := QRY || '          ,REPLACE(TO_CHAR(SUM(DECODE(LCT.LCT_DC,''C'',LCT.LCT_VALOR,0)),''9999999999999990.99''),''.'','','') AS TOT_LCTO';
    QRY := QRY || '       FROM LANCCTB_LCT LCT';
    QRY := QRY || '         , SPEDMODELOESCRT_SME SME';
    QRY := QRY || '         , EMPGERAL_EMP EMP';
    IF ISCONSOLIDADORA = 'S'
     THEN
       BEGIN
         QRY := QRY || ' WHERE EXISTS(SELECT NULL';
         QRY := QRY || ' FROM EMP_CONS';
         QRY := QRY || ' WHERE CONS_CDEMPTIT = SME.SME_CDEMPRESA';
         QRY := QRY || ' AND CONS_CDEMPRESA = EMP.EMP_CODIGO)';
       END;
     ELSE
       QRY := QRY || ' WHERE SME.SME_CDEMPRESA = EMP.EMP_CODIGO';
    END IF;
    QRY := QRY || '         AND LCT.LCT_CDEMPRESA = EMP.EMP_CODIGO';
    QRY := QRY || '         AND LCT.LCT_DATA = ''' || DTPROCESSA || '''';
    --QRY := QRY || '         AND LCT.LCT_DATA <= SME.SME_DTFIM ';
    QRY := QRY || '         AND LCT.LCT_DC = ''C''';
    QRY := QRY || '         AND LCT.LCT_PLCCUSTO = EMP_CODCENTCUS';
    QRY := QRY || '         AND LCT.LCT_VALOR <> 0';
    QRY := QRY || '         AND SME.SME_CODIGO = ''' || PSME_CODIGO || '''';
    QRY := QRY || '         AND SME.SME_SYSTEMID = ''ECD''';
    QRY := QRY || '       GROUP BY SME.SME_CODIGO';
    QRY := QRY || '          ,LCT.LCT_CDEMPRESA, LCT.LCT_LOTE , LCT.LCT_LANCCTB, LCT.LCT_DATA ';
    QRY := QRY || '      )  TOTALIZADOR';
    QRY := QRY || ', PLANOCTA_PLC';
    QRY := QRY || ', CDPLANO_CPLC';
    QRY := QRY || ', ( SELECT DISTINCT PPA_CODIGOPART';
    QRY := QRY || '      , PPA_CLIFOR || PPA_CODIGOPART AS CODIGOPART';
    QRY := QRY || '      , PPA_CLIFOR';
    QRY := QRY || '      , RPA_CODIGOEMPRESA';
    QRY := QRY || '    FROM SPEDPARPART_PPA';
    QRY := QRY || '      , SPEDRELPART_RPA';
    QRY := QRY || '      , SPEDMODELOESCRT_SME';
    QRY := QRY || '    WHERE PPA_CODIGOPART = RPA_CODIGOPART';
    QRY := QRY || '       AND PPA_CLIFOR     = RPA_CLIFOR';
    QRY := QRY || '       AND RPA_CODIGOEMPRESA(+) = SME_CDEMPRESA';
    QRY := QRY || '       AND SME_CODIGO = ''' || PSME_CODIGO || '''';
    QRY := QRY || '       AND RPA_CODRELAC  <> ''00'' )';
    IF ISCONSOLIDADORA = 'S'
     THEN BEGIN
       QRY := QRY || ' WHERE EXISTS(SELECT NULL';
       QRY := QRY || ' FROM EMP_CONS';
       QRY := QRY || ' WHERE CONS_CDEMPTIT = SME.SME_CDEMPRESA';
       QRY := QRY || ' AND CONS_CDEMPRESA = EMP.EMP_CODIGO)';
     END;
     ELSE
       QRY := QRY || ' WHERE SME.SME_CDEMPRESA=EMP.EMP_CODIGO';
    END IF;
    QRY := QRY || ' AND LCT.LCT_CDEMPRESA=EMP.EMP_CODIGO';
    QRY := QRY || ' AND LCT.LCT_DATA = ''' || DTPROCESSA || '''';
    --QRY := QRY || ' AND LCT.LCT_DATA<=SME.SME_DTFIM';
    IF ISCONSOLIDADORA = 'S'
     THEN BEGIN
       QRY := QRY || ' AND LCT.LCT_PLCCUSTO IN (SELECT EMP_CODCENTCUS';
       QRY := QRY || ' FROM EMPGERAL_EMP';
       QRY := QRY || ' WHERE EXISTS(SELECT NULL';
       QRY := QRY || ' FROM EMP_CONS';
       QRY := QRY || ' WHERE CONS_CDEMPTIT=''' || CDEMPRESA || '''';
       QRY := QRY || '              ))';
       QRY := QRY || ' AND PLC_CODPLANO IN (SELECT EMP_CODPLCONTA';
       QRY := QRY || ' FROM EMPGERAL_EMP';
       QRY := QRY || ' WHERE EXISTS(SELECT NULL';
       QRY := QRY || ' FROM EMP_CONS';
       QRY := QRY || ' WHERE CONS_CDEMPTIT=''' || CDEMPRESA || '''';
       QRY := QRY || '              ))';
     END;
     ELSE BEGIN
       QRY := QRY || ' AND LCT.LCT_PLCCUSTO=EMP_CODCENTCUS';
       QRY := QRY || ' AND LCT_PLCONTAB=PLC_CODPLANO';
     END;
    END IF;
    QRY := QRY || ' AND LCT_NOCONTAB=PLC_NOCONTAB';
    QRY := QRY || ' AND LCT_PLCONTAB=CPLC_CODIGO';
    QRY := QRY || ' AND LCT.LCT_VALOR<>0';
    QRY := QRY || ' AND SME.SME_CODIGO=''' || PSME_CODIGO || '''';
    QRY := QRY || ' AND LCT_CDEMPRESARELAC=LCT.LCT_CDEMPRESA';
    QRY := QRY || ' AND LCT_CDEMPRESA=RPA_CODIGOEMPRESA(+)';
    /*Condi��o abaixo substituida pois estava duplicando registros do select caso o cliente e o fornecedor tenha o
     mesmo codigo*/
    --QRY := QRY || ' AND DECODE(NVL(LCT_CDFOR,''*''),''*'',LCT_CDCLIENTE,LCT_CDFOR) = PPA_CODIGOPART (+)';
  --  QRY := QRY || ' AND ''C''||LCT_CDCLIENTE = CODIGOPART(+)';
  --  QRY := QRY || ' AND ''F''||LCT_CDFOR = CODIGOPART(+)';
    QRY := QRY || ' AND DECODE(NVL(LCT_CDFOR,''*''),''*'',''C''||LCT_CDCLIENTE,''F''||LCT_CDFOR)=CODIGOPART (+)';
    QRY := QRY || ' AND LCT_LOTERELAC = LCT.LCT_LOTE';
    QRY := QRY || ' AND LCT_LANCCTBRELAC = LCT.LCT_LANCCTB';
    QRY := QRY || ' AND LCT_DATARELAC = LCT.LCT_DATA';
    QRY := QRY || ' AND SME.SME_SYSTEMID = ''ECD''';
    QRY := QRY || ' AND LCT_PLCONTAB = PLC_CODPLANO';
    QRY := QRY || ' ORDER BY LCT.LCT_DATA';
    QRY := QRY || ' , (LCT.LCT_CDEMPRESA||LCT.LCT_LOTE||LCT.LCT_LANCCTB||TO_CHAR(LCT.LCT_DATA,''DDMMYYYY''))';
    EXECUTE IMMEDIATE QRY BULK COLLECT INTO  LST_NUM_LCTO
                                           , LST_REGI200
                                           , LST_DT_LCTO
                                           , LST_IND_LCTO
                                           , LST_VL_LCTO
                                           , LST_REGI250
                                           , LST_COD_CTA
                                           , LST_COD_CCUS
                                           , LST_VL_DC
                                           , LST_IND_DC
                                           , LST_COD_HIST_PAD
                                           , LST_HIST
                                           , LST_COD_PART
                                           , LST_LCT_LOTE;
    IF LST_REGI200.EXISTS(1) THEN
     BEGIN
       FOR IDX_I200 IN LST_REGI200.FIRST..LST_REGI200.LAST LOOP
         BEGIN
           IF (LST_NUM_LCTO(IDX_I200) <> NUMLANCCTBATU) THEN
            BEGIN
              NUMLANCCTBATU := LST_NUM_LCTO(IDX_I200);
              SELECT SEQ_SPEDECD_IDRI200.NEXTVAL INTO PIDR200 FROM DUAL;
              INSERT INTO SPEDECDLANCCTBV10_RI200 (SMECODIGO
                                                  ,NUM_LCTO
                                                  ,REG
                                                  ,DT_LCTO
                                                  ,VL_LCTO
                                                  ,IND_LCTO
                                                  ,IDRI200)
                VALUES (PSME_CODIGO
                       ,LST_NUM_LCTO(IDX_I200)
                       ,'I200'
                       ,LST_DT_LCTO(IDX_I200)
                       ,LST_VL_LCTO(IDX_I200)
                       ,LST_IND_LCTO(IDX_I200)
                       ,PIDR200);
              PTOTALREGISTRO_I200 := PTOTALREGISTRO_I200 + 1;
            END;
           END IF;
           PTOTALREGISTRO_I250 := PTOTALREGISTRO_I250 + 1;
           INSERT INTO SPEDECDPARTLANCV10_RI250(  SMECODIGO
                                                , NUM_LCTO
                                                , COD_CTA
                                                , COD_CCUS
                                                , REG
                                                , VL_DC
                                                , IND_DC
                                                , NUM_ARQ
                                                , COD_HIST_PAD
                                                , HIST
                                                , COD_PART
                                                , IDRI250
                                                , IDRI200
                                                ,RI250_NRORDEM)
              VALUES( PSME_CODIGO
                    , LST_NUM_LCTO(IDX_I200)
                    , LST_COD_CTA(IDX_I200)
                    , LST_COD_CCUS(IDX_I200)
                    , 'I250'
                    , LST_VL_DC(IDX_I200)
                    , LST_IND_DC(IDX_I200)
                    , LST_LCT_LOTE(IDX_I200)
                    , LST_COD_HIST_PAD(IDX_I200)
                    , LST_HIST(IDX_I200)
                    , LST_COD_PART(IDX_I200)
                    , SEQ_SPEDECD_IDRI250.NEXTVAL
                    , PIDR200
                    , PTOTALREGISTRO_I250);
          LST_NUM_LCTO.EXTEND;
          LST_DT_LCTO.EXTEND;
          LST_VL_LCTO.EXTEND;
          LST_IND_LCTO.EXTEND;
          LST_REGI200.EXTEND;
          LST_COD_CTA.EXTEND;
          LST_COD_CCUS.EXTEND;
          LST_VL_DC.EXTEND;
          LST_IND_DC.EXTEND;
          LST_COD_HIST_PAD.EXTEND;
          LST_HIST.EXTEND;
          LST_COD_PART.EXTEND;
          LST_REGI250.EXTEND;
         END;
       END LOOP;
      LST_NUM_LCTO.DELETE;
      LST_DT_LCTO.DELETE;
      LST_VL_LCTO.DELETE;
      LST_IND_LCTO.DELETE;
      LST_REGI200.DELETE;
      LST_COD_CTA.DELETE;
      LST_COD_CCUS.DELETE;
      LST_VL_DC.DELETE;
      LST_IND_DC.DELETE;
      LST_COD_HIST_PAD.DELETE;
      LST_HIST.DELETE;
      LST_COD_PART.DELETE;
      LST_REGI250.DELETE;
     END;
    END IF;
   COMMIT;
   DTPROCESSA := DTPROCESSA+1;
  END LOOP;
END ECD_PROCESSA_RI200;
/

CREATE OR REPLACE PROCEDURE PRC_ECDPROCESSA_I200MOEDAFUNC (PSME_CODIGO IN VARCHAR2, PTOTALREGISTRO_I200 OUT NUMBER, PTOTALREGISTRO_I250 OUT NUMBER) AS
--TIPOS RI200
  TYPE TP_NUM_LCTO           IS TABLE OF SPEDECDLANCCTBV10_RI200.NUM_LCTO%TYPE;
  TYPE TP_DT_LCTO            IS TABLE OF VARCHAR2(8);--SPEDECDLANCCTBV10_RI200.DT_LCTO%TYPE;
  TYPE TP_VL_LCTO            IS TABLE OF SPEDECDLANCCTBV10_RI200.VL_LCTO%TYPE;
  TYPE TP_IND_LCTO           IS TABLE OF SPEDECDLANCCTBV10_RI200.IND_LCTO%TYPE;
--  TYPE TP_IDRI200            IS TABLE OF SPEDECDLANCCTBV10_RI200.IDRI200%TYPE;
  TYPE TP_REGI200            IS TABLE OF VARCHAR2(8);
--VARIAVEIS RI200
  LST_NUM_LCTO               TP_NUM_LCTO;
  LST_DT_LCTO                TP_DT_LCTO;
  LST_VL_LCTO                TP_VL_LCTO;
  LST_VL_LCTO_FUNCIONAL      TP_VL_LCTO;
  LST_IND_LCTO               TP_IND_LCTO;
  LST_REGI200                TP_REGI200;
--TIPOS RI250
  TYPE TP_COD_CTA            IS TABLE OF SPEDECDPARTLANCV10_RI250.COD_CTA%TYPE;
  TYPE TP_COD_CCUS           IS TABLE OF SPEDECDPARTLANCV10_RI250.COD_CCUS%TYPE;
  TYPE TP_VL_DC              IS TABLE OF SPEDECDPARTLANCV10_RI250.VL_DC%TYPE;
  TYPE TP_IND_DC             IS TABLE OF SPEDECDPARTLANCV10_RI250.IND_DC%TYPE;
  TYPE TP_COD_HIST_PAD       IS TABLE OF SPEDECDPARTLANCV10_RI250.COD_HIST_PAD%TYPE;
  TYPE TP_HIST               IS TABLE OF SPEDECDPARTLANCV10_RI250.HIST%TYPE;
  TYPE TP_COD_PART           IS TABLE OF SPEDECDPARTLANCV10_RI250.COD_PART%TYPE;
  TYPE TP_REGI250            IS TABLE OF SPEDECDPARTLANCV10_RI250.REG%TYPE;
  TYPE TP_LCT_LOTE           IS TABLE OF LANCCTB_LCT.LCT_LOTE%TYPE;
--VARIAVEIS RI250
  LST_COD_CTA                TP_COD_CTA;
  LST_COD_CCUS               TP_COD_CCUS;
  LST_VL_DC                  TP_VL_DC;
  LST_IND_DC                 TP_IND_DC;
  LST_VL_DC_FUNCIONAL        TP_VL_DC;
  LST_IND_DC_FUNCIONAL       TP_IND_DC;
  LST_COD_HIST_PAD           TP_COD_HIST_PAD;
  LST_HIST                   TP_HIST;
  LST_COD_PART               TP_COD_PART;
  LST_REGI250                TP_REGI250;
  LST_LCT_LOTE               TP_LCT_LOTE;
  PIDR200                    NUMBER;
  QRY                        LONG;
  STR_EQUIV                  LONG;
  CDEMPRESA                  VARCHAR2(4);
  DTINICIO                   DATE;
  DTFIM                      DATE;
  DTPROCESSA                 DATE;
  NUMLANCCTBATU              SPEDECDLANCCTBV10_RI200.NUM_LCTO%TYPE;
  ISCONSOLIDADORA            VARCHAR2(1);
  ISUTILIZACCUSTO            VARCHAR2(1);
  CURSOR GET_EMPRESA_FROM_SMECODIGO IS
    SELECT SME_CDEMPRESA,SME_DTINICIO,SME_DTFIM
      FROM SPEDMODELOESCRT_SME
     WHERE SME_CODIGO = PSME_CODIGO;
  CURSOR GET_EMPRESA_CONSOLIDADORA IS
    SELECT EMP_CONSOLIDACAO
      FROM EMPGERAL_EMP
     WHERE EMP_CODIGO = CDEMPRESA;
  CURSOR GET_PAR_ECD_UTILIZACCUSTO_ECD IS
     SELECT PAR_VLPARAM
       FROM PARAMS_PAR
      WHERE PAR_CDPARAM = 'wECD_UTILIZAR_CENTRO_CUSTO_NO_ECD'||CDEMPRESA;
BEGIN
  DELETE FROM SPEDECDPARTLANCV10_RI250 WHERE SMECODIGO = PSME_CODIGO;
  DELETE FROM SPEDECDLANCCTBV10_RI200  WHERE SMECODIGO = PSME_CODIGO;
  /*Busca a empresa de acordo com o SMECodigo*/
  OPEN GET_EMPRESA_FROM_SMECODIGO;
  FETCH GET_EMPRESA_FROM_SMECODIGO INTO CDEMPRESA,DTINICIO,DTFIM;
  CLOSE GET_EMPRESA_FROM_SMECODIGO;
  OPEN GET_EMPRESA_CONSOLIDADORA;
  FETCH GET_EMPRESA_CONSOLIDADORA  INTO ISCONSOLIDADORA;
  CLOSE GET_EMPRESA_CONSOLIDADORA;
  OPEN  GET_PAR_ECD_UTILIZACCUSTO_ECD;
  FETCH GET_PAR_ECD_UTILIZACCUSTO_ECD INTO ISUTILIZACCUSTO;
  CLOSE GET_PAR_ECD_UTILIZACCUSTO_ECD;
  STR_EQUIV  := '';
  STR_EQUIV  := GET_LANCCTB_EQUIV(CDEMPRESA);
  DTPROCESSA := DTINICIO;
  PTOTALREGISTRO_I200 := 0;
  PTOTALREGISTRO_I250 := 0;
  NUMLANCCTBATU       := '0';
  WHILE DTPROCESSA <= DTFIM
  LOOP
    QRY := '';
    QRY := QRY || ' SELECT LCT.LCT_CDEMPRESA || LCT.LCT_LOTE || LCT.LCT_LANCCTB || TO_CHAR(LCT.LCT_DATA, ''DDMMYYYY'') AS NUM_LCTO';
    QRY := QRY || ' , ''I200'' AS REGRI200';
    QRY := QRY || ' , TO_CHAR(LCT.LCT_DATA,''DDMMYYYY'') AS DT_LCTO';
    QRY := QRY || ' , DECODE(LCT.LCT_LOTE,''ENCERR'',''E'',''N'') AS IND_LCTO';
    QRY := QRY || ' , TOTALIZADOR.TOT_LCTO';
    QRY := QRY || ' , TOTALIZADOR.TOT_LCTO_FUNCIONAL';
    QRY := QRY || ' , ''I250'' AS REGRI250';
    QRY := QRY || ' , MONTAMASCARA(LCT_NOCONTAB, CPLC_MASCARA)        AS COD_CTA';
    IF ISUTILIZACCUSTO = 'S'
     THEN QRY := QRY || ' , ''               '' AS COD_CCUS';
     ELSE QRY := QRY || ' , LCT_NOCCUSTO  AS COD_CCUS';
    END IF;
    QRY := QRY || ' , REPLACE(TO_CHAR(LCT_VALOR, ''9999999999999990.99''), ''.'', '','') AS VL_DC';
    QRY := QRY || ' , LCT_DC AS IND_DC';
    QRY := QRY || ' , REPLACE(TO_CHAR(LCT_VALORM, ''9999999999999990.99''), ''.'', '','') AS VL_DC_FUNCIONAL';
    QRY := QRY || ' , LCT_DC AS IND_DC_FUNCIONAL';
    QRY := QRY || ' , DECODE(NVL(PLC_HISTCRED,''*''),''*'',DECODE(NVL(PLC_HISTDEB,''*''),''*'','''',PLC_HISTDEB),PLC_HISTCRED) AS COD_HIS_PAD';
    QRY := QRY || ' , REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE( REPLACE( REPLACE( REPLACE( LCT_HISTORICO,CHR(9),'' ''),CHR(10),'' ''),CHR(13),'' ''),''|'',''-''),CHR(18),'' ''),CHR(00),'' ''),CHR(01),'' ''),CHR(02),'' ''),CHR(03),'' ''),CHR(04),'' ''),CHR(05),'' ''),CHR(06),'' ''),CHR(07),'' ''),CHR(08),'' ''),CHR(11),'' ''),CHR(12),'' ''),CHR(14),'' ''),CHR(15),'' ''),CHR(16),'' ''),CHR(17),'' ''),CHR(19),'' ''),CHR(20),'' ''),CHR(21),'' ''),CHR(22),'' ''),CHR(23),'' ''),CHR(24),'' ''),CHR(25),'' ''),CHR(26),'' ''),CHR(27),'' ''),CHR(28),'' ''),CHR(29),'' ''),CHR(30),'' ''),CHR(31),'' ''),CHR(127),'' '') AS HIST';
    QRY := QRY || ' , CODIGOPART  AS COD_PART';
    QRY := QRY || ' , LCT.LCT_LOTE AS LCT_LOTE';
    QRY := QRY || ' FROM '|| STR_EQUIV || ' LCT';
    QRY := QRY || ',SPEDMODELOESCRT_SME SME';
    QRY := QRY || ',EMPGERAL_EMP EMP';
    QRY := QRY || ', ( SELECT SME_CODIGO';
    QRY := QRY || '          ,LCT_CDEMPRESARELAC';
    QRY := QRY || '          ,LCT_LOTERELAC';
    QRY := QRY || '          ,LCT_LANCCTBRELAC';
    QRY := QRY || '          ,LCT_DATARELAC';
    QRY := QRY || '          ,REPLACE(TO_CHAR(SUM(TOT_LCTO),''9999999999999990.99''),''.'','','') AS TOT_LCTO';
    QRY := QRY || '          ,REPLACE(TO_CHAR(SUM(TOT_LCTO_FUNCIONAL),''9999999999999990.99''),''.'','','') AS TOT_LCTO_FUNCIONAL';
    QRY := QRY || '       FROM(';
    QRY := QRY || '    SELECT SME.SME_CODIGO';
    QRY := QRY || '          ,LCT.LCT_CDEMPRESA   AS LCT_CDEMPRESARELAC';
    QRY := QRY || '          ,LCT.LCT_LOTE    AS LCT_LOTERELAC';
    QRY := QRY || '          ,LCT.LCT_LANCCTB AS LCT_LANCCTBRELAC';
    QRY := QRY || '          ,LCT.LCT_DATA    AS LCT_DATARELAC';
    QRY := QRY || '          ,SUM(DECODE(LCT.LCT_DC,''C'',LCT.LCT_VALOR,0)) AS TOT_LCTO';
    QRY := QRY || '          ,0 AS TOT_LCTO_FUNCIONAL';
    QRY := QRY || '       FROM LANCCTB_LCT LCT';
    QRY := QRY || '         , SPEDMODELOESCRT_SME SME';
    QRY := QRY || '         , EMPGERAL_EMP EMP';
    IF ISCONSOLIDADORA = 'S'
     THEN
       BEGIN
         QRY := QRY || ' WHERE EXISTS(SELECT NULL';
         QRY := QRY || ' FROM EMP_CONS';
         QRY := QRY || ' WHERE CONS_CDEMPTIT = SME.SME_CDEMPRESA';
         QRY := QRY || ' AND CONS_CDEMPRESA = EMP.EMP_CODIGO)';
       END;
     ELSE
       QRY := QRY || ' WHERE SME.SME_CDEMPRESA = EMP.EMP_CODIGO';
    END IF;
    QRY := QRY || '         AND LCT.LCT_CDEMPRESA = EMP.EMP_CODIGO';
    QRY := QRY || '         AND LCT.LCT_DATA = ''' || DTPROCESSA || '''';
    QRY := QRY || '         AND LCT.LCT_DC = ''C''';
    QRY := QRY || '         AND LCT.LCT_PLCCUSTO = EMP_CODCENTCUS';
    QRY := QRY || '         AND SME.SME_CODIGO = ''' || PSME_CODIGO || '''';
    QRY := QRY || '         AND SME.SME_SYSTEMID = ''ECD''';
    QRY := QRY || '       GROUP BY SME.SME_CODIGO,LCT.LCT_CDEMPRESA, LCT.LCT_LOTE , LCT.LCT_LANCCTB, LCT.LCT_DATA';
    QRY := QRY || '    UNION ALL';
    QRY := QRY || '    SELECT SME.SME_CODIGO';
    QRY := QRY || '          ,LCT.LCT_CDEMPRESA   AS LCT_CDEMPRESARELAC';
    QRY := QRY || '          ,LCT.LCT_LOTE    AS LCT_LOTERELAC';
    QRY := QRY || '          ,LCT.LCT_LANCCTB AS LCT_LANCCTBRELAC';
    QRY := QRY || '          ,LCT.LCT_DATA    AS LCT_DATARELAC';
    QRY := QRY || '          ,0 AS TOT_LCTO';
    QRY := QRY || '          ,SUM(DECODE(LCT.LCT_DC,''C'',LCT.LCT_VALORM,0)) AS TOT_LCTO_FUNCIONAL';
    QRY := QRY || '       FROM LANCCTB_LCT LCT';
    QRY := QRY || '         , SPEDMODELOESCRT_SME SME';
    QRY := QRY || '         , EMPGERAL_EMP EMP';
    IF ISCONSOLIDADORA = 'S'
     THEN
       BEGIN
         QRY := QRY || ' WHERE EXISTS(SELECT NULL';
         QRY := QRY || ' FROM EMP_CONS';
         QRY := QRY || ' WHERE CONS_CDEMPTIT = SME.SME_CDEMPRESA';
         QRY := QRY || ' AND CONS_CDEMPRESA = EMP.EMP_CODIGO)';
       END;
     ELSE
       QRY := QRY || ' WHERE SME.SME_CDEMPRESA = EMP.EMP_CODIGO';
    END IF;
    QRY := QRY || '         AND LCT.LCT_CDEMPRESA = EMP.EMP_CODIGO';
    QRY := QRY || '         AND LCT.LCT_DATA = ''' || DTPROCESSA || '''';
    QRY := QRY || '         AND LCT.LCT_DC = ''C''';
    QRY := QRY || '         AND LCT.LCT_PLCCUSTO = EMP_CODCENTCUS';
    QRY := QRY || '         AND SME.SME_CODIGO = ''' || PSME_CODIGO || '''';
    QRY := QRY || '         AND SME.SME_SYSTEMID = ''ECD''';
    QRY := QRY || '       GROUP BY SME.SME_CODIGO,LCT.LCT_CDEMPRESA, LCT.LCT_LOTE , LCT.LCT_LANCCTB, LCT.LCT_DATA';
    QRY := QRY || '    )GROUP BY SME_CODIGO,LCT_CDEMPRESARELAC,LCT_LOTERELAC,LCT_LANCCTBRELAC,LCT_DATARELAC';
    QRY := QRY || '      )  TOTALIZADOR';
    QRY := QRY || ', PLANOCTA_PLC';
    QRY := QRY || ', CDPLANO_CPLC';
    QRY := QRY || ', ( SELECT PPA_CODIGOPART';
    QRY := QRY || '      , PPA_CLIFOR || PPA_CODIGOPART AS CODIGOPART';
    QRY := QRY || '      , PPA_CLIFOR';
    QRY := QRY || '      , RPA_CODIGOEMPRESA';
    QRY := QRY || '    FROM SPEDPARPART_PPA';
    QRY := QRY || '      , SPEDRELPART_RPA';
    QRY := QRY || '      , SPEDMODELOESCRT_SME';
    QRY := QRY || '    WHERE PPA_CODIGOPART = RPA_CODIGOPART';
    QRY := QRY || '       AND PPA_CLIFOR     = RPA_CLIFOR';
    QRY := QRY || '       AND RPA_CODIGOEMPRESA(+) = SME_CDEMPRESA';
    QRY := QRY || '       AND SME_CODIGO = ''' || PSME_CODIGO || '''';
    QRY := QRY || '       AND RPA_CODRELAC  <> ''00'' )';
    IF ISCONSOLIDADORA = 'S'
     THEN BEGIN
       QRY := QRY || ' WHERE EXISTS(SELECT NULL';
       QRY := QRY || ' FROM EMP_CONS';
       QRY := QRY || ' WHERE CONS_CDEMPTIT = SME.SME_CDEMPRESA';
       QRY := QRY || ' AND CONS_CDEMPRESA = EMP.EMP_CODIGO)';
     END;
     ELSE
       QRY := QRY || ' WHERE SME.SME_CDEMPRESA=EMP.EMP_CODIGO';
    END IF;
    QRY := QRY || ' AND LCT.LCT_CDEMPRESA=EMP.EMP_CODIGO';
    QRY := QRY || ' AND LCT.LCT_DATA = ''' || DTPROCESSA || '''';
    IF ISCONSOLIDADORA = 'S'
     THEN BEGIN
       QRY := QRY || ' AND LCT.LCT_PLCCUSTO IN (SELECT EMP_CODCENTCUS';
       QRY := QRY || ' FROM EMPGERAL_EMP';
       QRY := QRY || ' WHERE EXISTS(SELECT NULL';
       QRY := QRY || ' FROM EMP_CONS';
       QRY := QRY || ' WHERE CONS_CDEMPTIT=''' || CDEMPRESA || '''';
       QRY := QRY || '              ))';
       QRY := QRY || ' AND PLC_CODPLANO IN (SELECT EMP_CODPLCONTA';
       QRY := QRY || ' FROM EMPGERAL_EMP';
       QRY := QRY || ' WHERE EXISTS(SELECT NULL';
       QRY := QRY || ' FROM EMP_CONS';
       QRY := QRY || ' WHERE CONS_CDEMPTIT=''' || CDEMPRESA || '''';
       QRY := QRY || '              ))';
     END;
     ELSE BEGIN
       QRY := QRY || ' AND LCT.LCT_PLCCUSTO=EMP_CODCENTCUS';
       QRY := QRY || ' AND LCT_PLCONTAB=PLC_CODPLANO';
     END;
    END IF;
    QRY := QRY || ' AND LCT_NOCONTAB=PLC_NOCONTAB';
    QRY := QRY || ' AND LCT_PLCONTAB=CPLC_CODIGO';
    QRY := QRY || ' AND SME.SME_CODIGO=''' || PSME_CODIGO || '''';
    QRY := QRY || ' AND LCT_CDEMPRESARELAC=LCT.LCT_CDEMPRESA';
    QRY := QRY || ' AND LCT_CDEMPRESA=RPA_CODIGOEMPRESA(+)';
    QRY := QRY || ' AND DECODE(NVL(LCT_CDFOR,''*''),''*'',''C''||LCT_CDCLIENTE,''F''||LCT_CDFOR)=CODIGOPART (+)';
    QRY := QRY || ' AND LCT_LOTERELAC = LCT.LCT_LOTE';
    QRY := QRY || ' AND LCT_LANCCTBRELAC = LCT.LCT_LANCCTB';
    QRY := QRY || ' AND LCT_DATARELAC = LCT.LCT_DATA';
    QRY := QRY || ' AND SME.SME_SYSTEMID = ''ECD'' ';
    QRY := QRY || ' AND LCT_PLCONTAB = PLC_CODPLANO ';
    QRY := QRY || ' ORDER BY LCT.LCT_DATA, (LCT.LCT_CDEMPRESA||LCT.LCT_LOTE||LCT.LCT_LANCCTB||TO_CHAR(LCT.LCT_DATA,''DDMMYYYY''))';
    EXECUTE IMMEDIATE QRY BULK COLLECT INTO  LST_NUM_LCTO
                                           , LST_REGI200
                                           , LST_DT_LCTO
                                           , LST_IND_LCTO
                                           , LST_VL_LCTO
                                           , LST_VL_LCTO_FUNCIONAL
                                           , LST_REGI250
                                           , LST_COD_CTA
                                           , LST_COD_CCUS
                                           , LST_VL_DC
                                           , LST_IND_DC
                                           , LST_VL_DC_FUNCIONAL
                                           , LST_IND_DC_FUNCIONAL
                                           , LST_COD_HIST_PAD
                                           , LST_HIST
                                           , LST_COD_PART
                                           , LST_LCT_LOTE;
    IF LST_REGI200.EXISTS(1) THEN
     BEGIN
       FOR IDX_I200 IN LST_REGI200.FIRST..LST_REGI200.LAST LOOP
         BEGIN
           IF (LST_NUM_LCTO(IDX_I200) <> NUMLANCCTBATU) THEN
            BEGIN
              NUMLANCCTBATU := LST_NUM_LCTO(IDX_I200);
              SELECT SEQ_SPEDECD_IDRI200.NEXTVAL INTO PIDR200 FROM DUAL;
              INSERT INTO SPEDECDLANCCTBV10_RI200 (SMECODIGO
                                                  ,NUM_LCTO
                                                  ,REG
                                                  ,DT_LCTO
                                                  ,VL_LCTO
                                                  ,IND_LCTO
                                                  ,IDRI200
                                                  ,RI200_VLLCTOAUX)
                VALUES (PSME_CODIGO
                       ,LST_NUM_LCTO(IDX_I200)
                       ,'I200'
                       ,LST_DT_LCTO(IDX_I200)
                       ,LST_VL_LCTO(IDX_I200)
                       ,LST_IND_LCTO(IDX_I200)
                       ,PIDR200
                       ,LST_VL_LCTO_FUNCIONAL(IDX_I200));
              PTOTALREGISTRO_I200 := PTOTALREGISTRO_I200 + 1;
            END;
           END IF;
           PTOTALREGISTRO_I250 := PTOTALREGISTRO_I250 + 1;
           INSERT INTO SPEDECDPARTLANCV10_RI250(  SMECODIGO
                                                , NUM_LCTO
                                                , COD_CTA
                                                , COD_CCUS
                                                , REG
                                                , VL_DC
                                                , IND_DC
                                                , NUM_ARQ
                                                , COD_HIST_PAD
                                                , HIST
                                                , COD_PART
                                                , IDRI250
                                                , IDRI200
                                                , RI250_VLDCAUX
                                                , RI250_VBDCAUX
                                                , RI250_NRORDEM)
              VALUES( PSME_CODIGO
                    , LST_NUM_LCTO(IDX_I200)
                    , LST_COD_CTA(IDX_I200)
                    , LST_COD_CCUS(IDX_I200)
                    , 'I250'
                    , LST_VL_DC(IDX_I200)
                    , LST_IND_DC(IDX_I200)
                    , LST_LCT_LOTE(IDX_I200)
                    , LST_COD_HIST_PAD(IDX_I200)
                    , LST_HIST(IDX_I200)
                    , LST_COD_PART(IDX_I200)
                    , SEQ_SPEDECD_IDRI250.NEXTVAL
                    , PIDR200
                    , LST_VL_DC_FUNCIONAL(IDX_I200)
                    , LST_IND_DC_FUNCIONAL(IDX_I200)
                    , PTOTALREGISTRO_I250
                    );
          LST_NUM_LCTO.EXTEND;
          LST_DT_LCTO.EXTEND;
          LST_VL_LCTO.EXTEND;
          LST_IND_LCTO.EXTEND;
          LST_REGI200.EXTEND;
          LST_COD_CTA.EXTEND;
          LST_COD_CCUS.EXTEND;
          LST_VL_DC.EXTEND;
          LST_IND_DC.EXTEND;
          LST_COD_HIST_PAD.EXTEND;
          LST_HIST.EXTEND;
          LST_COD_PART.EXTEND;
          LST_REGI250.EXTEND;
         END;
       END LOOP;
      LST_NUM_LCTO.DELETE;
      LST_DT_LCTO.DELETE;
      LST_VL_LCTO.DELETE;
      LST_IND_LCTO.DELETE;
      LST_REGI200.DELETE;
      LST_COD_CTA.DELETE;
      LST_COD_CCUS.DELETE;
      LST_VL_DC.DELETE;
      LST_IND_DC.DELETE;
      LST_COD_HIST_PAD.DELETE;
      LST_HIST.DELETE;
      LST_COD_PART.DELETE;
      LST_REGI250.DELETE;
     END;
    END IF;
   COMMIT;
   DTPROCESSA := DTPROCESSA+1;
  END LOOP;
END PRC_ECDPROCESSA_I200MOEDAFUNC;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 271398
PROMPT ======================================================================