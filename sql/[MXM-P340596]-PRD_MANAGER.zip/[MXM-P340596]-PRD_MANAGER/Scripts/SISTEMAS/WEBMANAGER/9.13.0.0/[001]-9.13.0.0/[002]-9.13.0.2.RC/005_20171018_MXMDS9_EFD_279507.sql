PROMPT ======================================================================
PROMPT == DEMANDA......: 279507
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: ANDRE LUIZ PEREIRA FONTES
PROMPT == DATA.........: 29/09/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGA020(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGA020         VARCHAR2(4) := 'A020';
   CURSOR CS_REGA020 IS
      SELECT SEQ1_EFDLEDFREGISTROA020_A02.NEXTVAL AS IDLEDFREGISTROA020
           , PT_IDMODESCRITURACAO
           , SDFS_SQDOCFISSERV AS SQDOCFISSERV
           , CT_REGA020
           , DECODE(TPO_TIPO, 'E', '0', '1') AS IND_OPER
           , DECODE(SDFS_EMITENTE, 'P', '0', '1') AS IND_EMIT
           , DECODE(SDFS_SITDOC, '02', '', SDFS_CLIFOR) AS CLIFOR
           , DECODE(SDFS_SITDOC, '02', '', TRIM(SDFS_CDCLIFOR)) AS COD_PART
		   , NVL(DECODE(UPPER(TIP_DOCFISCAL), 'X1', '55', TIP_DOCFISCAL), '03') AS COD_MOD
           , NVL(SDFS_SITDOC, '00') AS COD_SIT
           , SDFS_SERIE AS SER
           , SDFS_SUBSERIE AS SUB
           , REPLACE(REPLACE(SDFS_DOCUMENTO, '-'), '/') AS NUM_DOC
           , TO_CHAR(SDFS_DATA, 'DDMMYYYY') AS DT_DOC
           , IRT_CDCFPS AS CFPS
           , DECODE(UF, 'EX', '', PPA_CODMUNIC) AS COD_MUN_SERV
           , TPO_CODIGO AS COD_NAT
           , SDFS_VLTOTAL AS VL_DOC
           , SDFS_INDPAG AS IND_PGTO
           , SDFS_VLTOTAL AS VL_SUB_TOT
           , SDFS_VLTOTDESC AS VL_DESC
           , SDFS_VLTOTAL AS VL_SERV
           , 0 AS VL_MAT_PROP
           , 0 AS VL_MAT_TERC
           , 0 AS VL_DA
           , CASE
                WHEN (SDFS_CLIFOR = 'F') AND (NVL(TPO_GBISSRETIDO, 'N') = 'N')
                THEN SDFS_VLBCISS
                WHEN (SDFS_CLIFOR = 'C') AND (NVL(TPO_GBISSRETIDO, 'N') = 'N')
                THEN SDFS_VLBCISS
                WHEN (SDFS_CLIFOR = 'C') AND (NVL(TPO_GBISSRETIDO, 'N') = 'S')
                THEN SDFS_VLBCISS
                ELSE 0
             END AS VL_BC_ISS
           , CASE
                WHEN (SDFS_CLIFOR = 'F') AND (NVL(TPO_GBISSRETIDO, 'N') = 'N')
                THEN SDFS_VLISS
                WHEN (SDFS_CLIFOR = 'C') AND (NVL(TPO_GBISSRETIDO, 'N') = 'N')
                THEN SDFS_VLISS
                WHEN (SDFS_CLIFOR = 'C') AND (NVL(TPO_GBISSRETIDO, 'N') = 'S')
                THEN SDFS_VLISS
                ELSE 0
             END AS VL_ISS
           , CASE
                WHEN (SDFS_CLIFOR = 'F') AND (NVL(TPO_GBISSRETIDO, 'N') = 'S')
                THEN SDFS_VLBCISS
                WHEN (SDFS_CLIFOR = 'C') AND (NVL(TPO_GBISSRETIDO, 'N') = 'N')
                THEN 0
                WHEN (SDFS_CLIFOR = 'C') AND (NVL(TPO_GBISSRETIDO, 'N') = 'S')
                THEN SDFS_VLBCISS
                ELSE 0
             END AS VL_BC_ISS_RT
           , CASE
                WHEN (SDFS_CLIFOR = 'F') AND (NVL(TPO_GBISSRETIDO, 'N') = 'S')
                THEN SDFS_VLISS
                WHEN (SDFS_CLIFOR = 'C') AND (NVL(TPO_GBISSRETIDO, 'N') = 'N')
                THEN 0
                WHEN (SDFS_CLIFOR = 'C') AND (NVL(TPO_GBISSRETIDO, 'N') = 'S')
                THEN SDFS_VLISS
                ELSE 0
             END AS VL_ISS_RT
           , '' AS COD_INF_OBS
        FROM SPEDDOCFISSERV_SDFS
             INNER JOIN TPOPER_TPO
                ON SDFS_TPOP = TPO_CODIGO
             LEFT JOIN TIPULO_TIP
                ON TPO_CDTIPTIT = TIP_CDTIPULO
             INNER JOIN SPEDPARPART_PPA
                ON SDFS_CDCLIFOR = PPA_CODIGOPART
               AND SDFS_CLIFOR = PPA_CLIFOR
             INNER JOIN EFDLEDFMODELOESCRIT_LME
                ON SDFS_CDEMPRESA = LME_CDEMPRESA
               AND SDFS_CDFILIAL = LME_CDFILIAL
               AND SDFS_DATAESCR >= LME_DTINI
               AND SDFS_DATAESCR <= LME_DTFIN
               AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
             LEFT JOIN EFDLEDFCABRELTOCFPS_TPS
                ON SDFS_CDEMPRESA = TPS_CDEMPRESA
               AND SDFS_CDFILIAL = TPS_CDFILIAL
             LEFT JOIN EFDLEDFITRELTOCFPS_IRT
                ON TPS_IDCABRELTOCFPS = IRT_NRTPS
               AND TPO_CODIGO = IRT_CDTPO
             INNER JOIN CLIENTEFORNEC
                ON SDFS_CLIFOR = TIPO
               AND SDFS_CDCLIFOR = CODIGO
       WHERE SDFS_SITDOC <> '02';
   TYPE TP_CS_REGA020 IS TABLE OF CS_REGA020%ROWTYPE INDEX BY PLS_INTEGER;
   TB_CS_REGB020      TP_CS_REGA020;
BEGIN
   OPEN CS_REGA020;
   LOOP
      FETCH CS_REGA020 BULK COLLECT INTO TB_CS_REGB020 LIMIT 1000;
      EXIT WHEN TB_CS_REGB020.COUNT = 0;
      FORALL I IN TB_CS_REGB020.FIRST .. TB_CS_REGB020.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROA020_A02 VALUES TB_CS_REGB020(I);
   END LOOP;
   CLOSE CS_REGA020;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGA020%ISOPEN
         THEN CLOSE CS_REGA020;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGB020(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
   VR_MENSAGEM_ERRO   VARCHAR2(500);
   CT_REGB020         VARCHAR2(4) := 'B020';
   CURSOR CS_REGB020 IS
      SELECT SEQ1_EFDLEDFREGISTROB020_B02.NEXTVAL AS IDLEDFREGISTROB020
           , PT_IDMODESCRITURACAO
           , SDFS_SQDOCFISSERV AS SQDOCFISSERV
           , CT_REGB020
           , DECODE(TPO_TIPO, 'E', '0', '1') AS IND_OPER
           , DECODE(SDFS_EMITENTE, 'P', '0', '1') AS IND_EMIT
           , DECODE(SDFS_SITDOC, '02', '', SDFS_CLIFOR) AS CLIFOR
           , DECODE(SDFS_SITDOC, '02', '', TRIM(SDFS_CDCLIFOR)) AS COD_PART
		   , NVL(DECODE(UPPER(TIP_DOCFISCAL), 'X1', '55', TIP_DOCFISCAL), '03') AS COD_MOD
           , NVL(SDFS_SITDOC, '00') AS COD_SIT
           , SDFS_SERIE AS SER
           , SDFS_SUBSERIE AS SUB
           , REPLACE(REPLACE(SDFS_DOCUMENTO, '-'), '/') AS NUM_DOC
           , TO_CHAR(SDFS_DATA, 'DDMMYYYY') AS DT_DOC
           , IRT_CDCFPS AS CFPS
           , 0 AS NUM_LCTO
           , DECODE(UF, 'EX', '', PPA_CODMUNIC) AS COD_MUN_SERV
           , SDFS_VLTOTAL - SDFS_VLTOTDESC AS VL_CONT
           , 0 AS VL_MAT_TERC
           , 0 AS VL_SUB
           , SDFS_VLBIISS AS VL_ISNT_ISS
           , 0 AS VL_DED_BC
           , CASE
                WHEN (NVL(TPO_GBTRBISS, 'N') = 'S')
                 AND (NVL(TPO_ISSDESTACADO, 'N') = 'S')
                THEN
                   SDFS_VLBCISS
                ELSE
                   0
             END
                AS VL_BC_ISS
           , CASE
                WHEN (NVL(TPO_GBTRBISS, 'N') = 'S')
                 AND (NVL(TPO_ISSDESTACADO, 'N') = 'S')
                 AND (NVL(TPO_GBISSRETIDO, 'N') = 'S')
                THEN
                   SDFS_VLBCISS
                ELSE
                   0
             END
                AS VL_BC_ISS_RT
           , CASE
                WHEN (NVL(TPO_GBTRBISS, 'N') = 'S')
                 AND (NVL(TPO_ISSDESTACADO, 'N') = 'S')
                 AND (NVL(TPO_GBISSRETIDO, 'N') = 'S')
                THEN
                   SDFS_VLISS
                ELSE
                   0
             END
                AS VL_ISS_RT
           , CASE
                WHEN (NVL(TPO_GBTRBISS, 'N') = 'S')
                 AND (NVL(TPO_ISSDESTACADO, 'N') = 'S')
                THEN
                   SDFS_VLISS
                ELSE
                   0
             END
                AS VL_ISS
           , '' AS COD_INF_OBS
           , TPO_CODIGO
        FROM SPEDDOCFISSERV_SDFS
             INNER JOIN TPOPER_TPO
                ON SDFS_TPOP = TPO_CODIGO
             LEFT JOIN TIPULO_TIP
                ON TPO_CDTIPTIT = TIP_CDTIPULO
             INNER JOIN SPEDPARPART_PPA
                ON SDFS_CDCLIFOR = PPA_CODIGOPART
               AND SDFS_CLIFOR = PPA_CLIFOR
             INNER JOIN EFDLEDFMODELOESCRIT_LME
                ON SDFS_CDEMPRESA = LME_CDEMPRESA
               AND SDFS_CDFILIAL = LME_CDFILIAL
               AND SDFS_DATAESCR >= LME_DTINI
               AND SDFS_DATAESCR <= LME_DTFIN
               AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
             LEFT JOIN EFDLEDFCABRELTOCFPS_TPS
                ON SDFS_CDEMPRESA = TPS_CDEMPRESA
               AND SDFS_CDFILIAL = TPS_CDFILIAL
             LEFT JOIN EFDLEDFITRELTOCFPS_IRT
                ON TPS_IDCABRELTOCFPS = IRT_NRTPS
               AND TPO_CODIGO = IRT_CDTPO
             INNER JOIN CLIENTEFORNEC
                ON SDFS_CLIFOR = TIPO
               AND SDFS_CDCLIFOR = CODIGO
       WHERE SDFS_SITDOC <> '02';
   TYPE TP_CS_REGB020 IS TABLE OF CS_REGB020%ROWTYPE
                            INDEX BY PLS_INTEGER;
   TB_CS_REGB020      TP_CS_REGB020;
BEGIN
   OPEN CS_REGB020;
   LOOP
      FETCH CS_REGB020
        BULK COLLECT INTO TB_CS_REGB020
      LIMIT 1000;
      EXIT WHEN TB_CS_REGB020.COUNT = 0;
      FORALL I IN TB_CS_REGB020.FIRST .. TB_CS_REGB020.LAST SAVE EXCEPTIONS
         INSERT INTO EFDLEDFREGISTROB020_B02
         VALUES TB_CS_REGB020(I);
   END LOOP;
   CLOSE CS_REGB020;
EXCEPTION
   WHEN OTHERS
   THEN
      BEGIN
         VR_MENSAGEM_ERRO   := SUBSTR('Mensagem do Sistema: "' || SQLERRM, 1, 499) || '"';
         IF CS_REGB020%ISOPEN
         THEN
            CLOSE CS_REGB020;
         END IF;
         RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
      END;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279507
PROMPT ======================================================================