PROMPT ======================================================================
PROMPT == DEMANDA......: 275844
PROMPT == SISTEMA......: Escritura��o Cont�bil Fiscal
PROMPT == RESPONSAVEL..: DEBORAH EVELYN MOREIRA DA ROCHA
PROMPT == DATA.........: 03/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

MERGE INTO ECFTABELADINAMICA_TD1 A
USING (SELECT 3372 as TD1_IDTD1,
              175 as TD1_NRIDENTREGISTRO,
              '7' as TD1_NMORDEM,
              '6' as TD1_NMLINHAECF,
              '7' as TD1_CDTABELADINAMICA,
              'Rendimentos e Ganhos L�quidos de Aplica��es de Renda Fixa e Renda Vari�vel' as TD1_DSTABELADINAMICA,
              TO_DATE('01/01/2015', 'DD/MM/RRRR') as TD1_DTINI,
              NULL as TD1_DTFIN,
              'E' as TD1_TPCODIGO,
              'N' as TD1_CDFORMATO,
              NULL as TD1_TXFORMULA,
              NULL as TD1_TPLANCAMENTO,
              SYSDATE as TD1_DTINCLUSAO,
              GET_USER_MXM as TD1_USINCLUSAO,
              13 as TD1_NRINTEIRO,
              2 as TD1_NRDECIMAL,
              'N' as TD1_VBVALORPERCENTUAL,
              NULL as TD1_DSOBSERVACAO
         FROM DUAL) B
ON (A.TD1_IDTD1 = B.TD1_IDTD1)
WHEN NOT MATCHED THEN
  INSERT
    (TD1_IDTD1,
     TD1_NRIDENTREGISTRO,
     TD1_NMORDEM,
     TD1_NMLINHAECF,
     TD1_CDTABELADINAMICA,
     TD1_DSTABELADINAMICA,
     TD1_DTINI,
     TD1_DTFIN,
     TD1_TPCODIGO,
     TD1_CDFORMATO,
     TD1_TXFORMULA,
     TD1_TPLANCAMENTO,
     TD1_DTINCLUSAO,
     TD1_USINCLUSAO,
     TD1_NRINTEIRO,
     TD1_NRDECIMAL,
     TD1_VBVALORPERCENTUAL,
     TD1_DSOBSERVACAO)
  VALUES
    (B.TD1_IDTD1,
     B.TD1_NRIDENTREGISTRO,
     B.TD1_NMORDEM,
     B.TD1_NMLINHAECF,
     B.TD1_CDTABELADINAMICA,
     B.TD1_DSTABELADINAMICA,
     B.TD1_DTINI,
     B.TD1_DTFIN,
     B.TD1_TPCODIGO,
     B.TD1_CDFORMATO,
     B.TD1_TXFORMULA,
     B.TD1_TPLANCAMENTO,
     B.TD1_DTINCLUSAO,
     B.TD1_USINCLUSAO,
     B.TD1_NRINTEIRO,
     B.TD1_NRDECIMAL,
     B.TD1_VBVALORPERCENTUAL,
     B.TD1_DSOBSERVACAO)
WHEN MATCHED THEN
  UPDATE
     SET A.TD1_NRIDENTREGISTRO   = B.TD1_NRIDENTREGISTRO,
         A.TD1_NMORDEM           = B.TD1_NMORDEM,
         A.TD1_NMLINHAECF        = B.TD1_NMLINHAECF,
         A.TD1_CDTABELADINAMICA  = B.TD1_CDTABELADINAMICA,
         A.TD1_DSTABELADINAMICA  = B.TD1_DSTABELADINAMICA,
         A.TD1_DTINI             = B.TD1_DTINI,
         A.TD1_DTFIN             = B.TD1_DTFIN,
         A.TD1_TPCODIGO          = B.TD1_TPCODIGO,
         A.TD1_CDFORMATO         = B.TD1_CDFORMATO,
         A.TD1_TXFORMULA         = B.TD1_TXFORMULA,
         A.TD1_TPLANCAMENTO      = B.TD1_TPLANCAMENTO,
         A.TD1_DTINCLUSAO        = B.TD1_DTINCLUSAO,
         A.TD1_USINCLUSAO        = B.TD1_USINCLUSAO,
         A.TD1_NRINTEIRO         = B.TD1_NRINTEIRO,
         A.TD1_NRDECIMAL         = B.TD1_NRDECIMAL,
         A.TD1_VBVALORPERCENTUAL = B.TD1_VBVALORPERCENTUAL,
         A.TD1_DSOBSERVACAO      = B.TD1_DSOBSERVACAO
/

CREATE OR REPLACE PROCEDURE PRC_ECFPROCESSA_M312M362(PT_IDMODESCRITURACAO IN NUMBER,
                                                     PT_NRPA1             IN NUMBER,
                                                     PT_CDEMPRESA         IN CHAR,
                                                     PT_ISCONSOLIDADORA   IN CHAR,
                                                     PT_TOM312M362        OUT NUMBER,
                                                     PT_NRA00             IN NUMBER,
                                                     PT_NRA12             IN NUMBER) AS
  VR_MENSAGEM_ERRO      VARCHAR2(500);
  CT_REG_M312M362       VARCHAR2(9) := 'M312/M362';
  QUERY                 LONG;
  QUERYA00              LONG;
  VR_PA2_IDPA2          NUMBER;
  VR_PA2_TPMESBALRED    CHAR;
  VR_PA2_ESTIMAVIVA     VARCHAR2(500);
  VR_NAOUTILIZACCUSTO   CHAR(1) := 'N'; --Por Default, utilizar centro de custo na escritura��o.
  TYPE TP_LPA_IDLPA             IS TABLE OF ECFREGISTROLANCCTBPTA_LPA.LPA_IDLPA%TYPE;
  TYPE TP_LPA_NRMODESCRITURACAO IS TABLE OF ECFREGISTROLANCCTBPTA_LPA.LPA_NRMODESCRITURACAO%TYPE;
  TYPE TP_LPA_NRPTA             IS TABLE OF ECFREGISTROLANCCTBPTA_LPA.LPA_NRPTA%TYPE;
  TYPE TP_LPA_CDLANCAMENTO      IS TABLE OF ECFREGISTROLANCCTBPTA_LPA.LPA_CDLANCAMENTO%TYPE;
  TYPE TP_LPA_CDREGISTRO        IS TABLE OF ECFREGISTROLANCCTBPTA_LPA.LPA_CDREGISTRO%TYPE;
  C_LPA_IDLPA              TP_LPA_IDLPA;
  C_LPA_NRMODESCRITURACAO  TP_LPA_NRMODESCRITURACAO;
  C_LPA_NRPTA              TP_LPA_NRPTA;
  C_LPA_CDLANCAMENTO       TP_LPA_CDLANCAMENTO;
  C_LPA_CDREGISTRO         TP_LPA_CDREGISTRO;
  C_LPA_IDLPA_A00              TP_LPA_IDLPA;
  C_LPA_NRMODESCRITURACAO_A00  TP_LPA_NRMODESCRITURACAO;
  C_LPA_NRPTA_A00              TP_LPA_NRPTA;
  C_LPA_CDLANCAMENTO_A00       TP_LPA_CDLANCAMENTO;
  C_LPA_CDREGISTRO_A00         TP_LPA_CDREGISTRO;
  CURSOR CS_PA2 IS
  SELECT PA2_IDPA2, PA2_TPMESBALRED, PA2_CDPERAPUR
    FROM ECFPERIODOFORMAPUR_PA2 P
   WHERE P.PA2_NRPA1 = PT_NRPA1;
BEGIN
  FOR LOOP_PARAMS IN (SELECT PAR_VLPARAM FROM PARAMS_PAR WHERE PAR_CDPARAM LIKE 'PARECFNAOUTILIZARCCUSTONOECF'||PT_CDEMPRESA||'%')
  LOOP
    VR_NAOUTILIZACCUSTO := LOOP_PARAMS.PAR_VLPARAM;
    EXIT;
  END LOOP;
  QUERYA00 := QUERYA00 || 'SELECT SQ1_ECFREGISTROLANCCTBPTA_LPA.NEXTVAL AS LPA_IDLPA,                    ';
  QUERYA00 := QUERYA00 || '       LPA_NRMODESCRITURACAO,                                                 ';
  QUERYA00 := QUERYA00 || '       LPA_NRPTA,                                                             ';
  QUERYA00 := QUERYA00 || '       REPLACE(SPED_RETIRA_CHARS(LPA_CDLANCAMENTO),'' ''),                                                      ';
  QUERYA00 := QUERYA00 || '       LPA_CDREGISTRO                                                         ';
  QUERYA00 := QUERYA00 || '  FROM(SELECT DISTINCT '||PT_IDMODESCRITURACAO||' AS LPA_NRMODESCRITURACAO,            ';
  QUERYA00 := QUERYA00 || '              A00.PTA_IDPTA              AS LPA_NRPTA,                        ';
  QUERYA00 := QUERYA00 || '              A12.DOCUMENTO              AS LPA_CDLANCAMENTO,                 ';
  QUERYA00 := QUERYA00 || '              A12.PTA_CDREGISTRO         AS LPA_CDREGISTRO                    ';
  QUERYA00 := QUERYA00 || '         FROM (SELECT RT1_NRTD1,                                              ';
  QUERYA00 := QUERYA00 || '                      PTA_CDCONTACONTABIL,                                    ';
  QUERYA00 := QUERYA00 || '                      PTA_CDCENTROCUSTO,                                      ';
  QUERYA00 := QUERYA00 || '                      PTA_VLLANCPTA,                                          ';
  QUERYA00 := QUERYA00 || '                      PTA_CDINDVLCTA,                                         ';
  QUERYA00 := QUERYA00 || '                      PTA_IDPTA                                               ';
  QUERYA00 := QUERYA00 || '                 FROM ECFREGISTROCTAPTA_PTA   P,                              ';
  QUERYA00 := QUERYA00 || '                      ECFREGISTROTABDINAM_RT1 RT1,                            ';
  QUERYA00 := QUERYA00 || '                      ECFREGISTROPER030_RE1                                   ';
  QUERYA00 := QUERYA00 || '                WHERE P.PTA_NRRT1 = RT1.RT1_IDRT1                             ';
  QUERYA00 := QUERYA00 || '                  AND RE1_IDREGISTROPER030 = RT1_NRREGISTROPER030             ';
  QUERYA00 := QUERYA00 || '                  AND PTA_VBGERALANCAMENTO = ''S''                            ';
  QUERYA00 := QUERYA00 || '                  AND RE1_NRPA2 = '||PT_NRA00                                  ;
  QUERYA00 := QUERYA00 || '                  AND PTA_NRMODESCRITURACAO = 1) A00,                         ';
  QUERYA00 := QUERYA00 || '              (SELECT RT1_NRTD1,                                              ';
  QUERYA00 := QUERYA00 || '                      PTA_CDCONTACONTABIL,                                    ';
  QUERYA00 := QUERYA00 || '                      PTA_CDCENTROCUSTO,                                      ';
  QUERYA00 := QUERYA00 || '                      PTA_VLLANCPTA,                                          ';
  QUERYA00 := QUERYA00 || '                      PTA_CDINDVLCTA,                                         ';
  QUERYA00 := QUERYA00 || '                      IDN_CDEMPRESA || IDN_CDLOTE || IDN_CDDOCUMENTO ||       ';
  QUERYA00 := QUERYA00 || '                      TO_CHAR(IDN_DTLANCAMENTO, ''DDMMYYYY'') AS DOCUMENTO,   ';
  QUERYA00 := QUERYA00 || '                      PTA_CDREGISTRO                                          ';
  QUERYA00 := QUERYA00 || '                 FROM ECFREGISTROCTAPTA_PTA   P,                              ';
  QUERYA00 := QUERYA00 || '                      ECFREGISTROTABDINAM_RT1 RT1,                            ';
  QUERYA00 := QUERYA00 || '                      ECFREGISTROPER030_RE1,                                  ';
  QUERYA00 := QUERYA00 || '                      ECFIDENTIFICADOR_IDN                                    ';
  QUERYA00 := QUERYA00 || '                WHERE P.PTA_NRRT1 = RT1.RT1_IDRT1                             ';
  QUERYA00 := QUERYA00 || '                  AND RE1_IDREGISTROPER030 = RT1_NRREGISTROPER030             ';
  QUERYA00 := QUERYA00 || '                  AND IDN_NRTD1 = RT1_NRTD1                                   ';
  QUERYA00 := QUERYA00 || '                  AND IDN_NRPA2 = RE1_NRPA2                                   ';
  QUERYA00 := QUERYA00 || '                  AND IDN_CDCCONTABIL = REPLACE(PTA_CDCONTACONTABIL, ''.'')   ';
  IF (VR_NAOUTILIZACCUSTO = 'N')
   THEN QUERYA00 := QUERYA00 || '            AND NVL(IDN_CDCCUSTO,''*'') = NVL(PTA_CDCENTROCUSTO,''*'')  ';
  END IF;
  QUERYA00 := QUERYA00 || '                  AND PTA_VBGERALANCAMENTO = ''S''                            ';
  IF PT_ISCONSOLIDADORA = 'S'
    THEN BEGIN
         QUERYA00 := QUERYA00 || '           AND  EXISTS(SELECT NULL                                     ';
         QUERYA00 := QUERYA00 || '                         FROM EMP_CONS                                 ';
         QUERYA00 := QUERYA00 || '                        WHERE CONS_CDEMPTIT = '''|| PT_CDEMPRESA ||''' ';
         QUERYA00 := QUERYA00 || '                          AND CONS_CDEMPRESA = IDN_CDEMPRESA)          ';
    END;
    ELSE QUERYA00 := QUERYA00 || '           AND IDN_CDEMPRESA = '''||PT_CDEMPRESA||'''                  ';
  END IF;
  QUERYA00 := QUERYA00 || '                   AND RE1_NRPA2 = '||PT_NRA12                                 ;
  QUERYA00 := QUERYA00 || '                   AND PTA_NRMODESCRITURACAO = 1) A12                         ';
  QUERYA00 := QUERYA00 || '                 WHERE A12.RT1_NRTD1 = A00.RT1_NRTD1                          ';
  QUERYA00 := QUERYA00 || '                   AND A12.PTA_CDCONTACONTABIL = A00.PTA_CDCONTACONTABIL      ';
  IF (VR_NAOUTILIZACCUSTO = 'N')
   THEN QUERYA00 := QUERYA00 || '             AND NVL(A12.PTA_CDCENTROCUSTO,''*'') = NVL(A00.PTA_CDCENTROCUSTO,''*'') ';
  END IF;
  QUERYA00 := QUERYA00 || '                   AND A12.PTA_VLLANCPTA = A00.PTA_VLLANCPTA                  ';
  QUERYA00 := QUERYA00 || '                   AND A12.PTA_CDINDVLCTA = A00.PTA_CDINDVLCTA)               ';
  EXECUTE IMMEDIATE QUERYA00 BULK COLLECT INTO C_LPA_IDLPA_A00
                                              ,C_LPA_NRMODESCRITURACAO_A00
                                              ,C_LPA_NRPTA_A00
                                              ,C_LPA_CDLANCAMENTO_A00
                                              ,C_LPA_CDREGISTRO_A00;
  IF C_LPA_IDLPA_A00.EXISTS(1) THEN
   BEGIN
      PT_TOM312M362 := 0;
      FOR INTM312M362_A00 IN C_LPA_IDLPA_A00.FIRST .. C_LPA_IDLPA_A00.LAST LOOP
      BEGIN
        INSERT INTO ECFREGISTROLANCCTBPTA_LPA (LPA_IDLPA,LPA_NRMODESCRITURACAO,LPA_NRPTA,LPA_CDLANCAMENTO,LPA_CDREGISTRO)
        VALUES (C_LPA_IDLPA_A00(INTM312M362_A00),
                C_LPA_NRMODESCRITURACAO_A00(INTM312M362_A00),
                C_LPA_NRPTA_A00(INTM312M362_A00),
                C_LPA_CDLANCAMENTO_A00(INTM312M362_A00),
                C_LPA_CDREGISTRO_A00(INTM312M362_A00));
        PT_TOM312M362 := PT_TOM312M362 + 1;
      END;
      END LOOP;
    END;
   END IF;
  FOR REC_PA2 IN CS_PA2 LOOP
    BEGIN
      VR_PA2_IDPA2       := REC_PA2.PA2_IDPA2;
      VR_PA2_TPMESBALRED := REC_PA2.PA2_TPMESBALRED;
      IF VR_PA2_TPMESBALRED = 'B' THEN
        BEGIN
          QUERY := '';
          IF VR_PA2_ESTIMAVIVA IS NOT NULL
            THEN VR_PA2_ESTIMAVIVA := VR_PA2_ESTIMAVIVA ||','|| TO_CHAR(REC_PA2.PA2_IDPA2);
          END IF;
          QUERY := QUERY || 'SELECT SQ1_ECFREGISTROLANCCTBPTA_LPA.NEXTVAL AS LPA_IDLPA, ';
          QUERY := QUERY || '       LPA_NRMODESCRITURACAO,';
          QUERY := QUERY || '       LPA_NRPTA,';
          QUERY := QUERY || '       REPLACE(SPED_RETIRA_CHARS(LPA_CDLANCAMENTO),'' ''),';
          QUERY := QUERY || '       LPA_CDREGISTRO';
          QUERY := QUERY || '  FROM (SELECT '||PT_IDMODESCRITURACAO||' AS LPA_NRMODESCRITURACAO,';
          QUERY := QUERY || '               PTA_IDPTA            AS LPA_NRPTA,';
          QUERY := QUERY || '               DOCUMENTO            AS LPA_CDLANCAMENTO,';
          QUERY := QUERY || '               PTA_CDREGISTRO       AS LPA_CDREGISTRO';
          QUERY := QUERY || '          FROM (SELECT PTA_IDPTA,';
          QUERY := QUERY || '                       IDN_CDEMPRESA || IDN_CDLOTE || IDN_CDDOCUMENTO ||TO_CHAR(IDN_DTLANCAMENTO, ''DDMMYYYY'') AS DOCUMENTO,';
          QUERY := QUERY || '                       PTA_CDREGISTRO';
          QUERY := QUERY || '                  FROM ECFIDENTIFICADOR_IDN    D,';
          QUERY := QUERY || '                       ECFREGISTROPER030_RE1   T,';
          QUERY := QUERY || '                       ECFREGISTROTABDINAM_RT1 B,';
          QUERY := QUERY || '                       ECFREGISTROCTAPTA_PTA,';
          QUERY := QUERY || '                       ECFPERIODOFORMAPUR_PA2';
          QUERY := QUERY || '                 WHERE IDN_NRTD1            = RT1_NRTD1';
          QUERY := QUERY || '                   AND IDN_NRPA2            = PA2_IDPA2';
          QUERY := QUERY || '                   AND IDN_NRPA2            = RE1_NRPA2';
          QUERY := QUERY || '                   AND RT1_IDRT1            = PTA_NRRT1';
          QUERY := QUERY || '                   AND RE1_NRPA2            = PA2_IDPA2';
          QUERY := QUERY || '                   AND RE1_IDREGISTROPER030 = RT1_NRREGISTROPER030';
          QUERY := QUERY || '                   AND PTA_VBGERALANCAMENTO = ''S''';
          IF PT_ISCONSOLIDADORA = 'S'
            THEN BEGIN
                 QUERY := QUERY || '            AND  EXISTS(SELECT NULL';
                 QUERY := QUERY || '                          FROM EMP_CONS';
                 QUERY := QUERY || '                         WHERE CONS_CDEMPTIT = '''|| PT_CDEMPRESA ||'''';
                 QUERY := QUERY || '                           AND CONS_CDEMPRESA = IDN_CDEMPRESA)';
            END;
            ELSE QUERY := QUERY || '            AND IDN_CDEMPRESA = '''||PT_CDEMPRESA||'''';
          END IF;
          QUERY := QUERY || '                   AND IDN_CDCCONTABIL      = REPLACE(PTA_CDCONTACONTABIL, ''.'', '''')';
          IF (VR_NAOUTILIZACCUSTO = 'N')
           THEN QUERY := QUERY || '             AND NVL(IDN_CDCCUSTO,''*'') = NVL(PTA_CDCENTROCUSTO,''*'')';
          END IF;
          QUERY := QUERY || '                   AND PA2_NRPA1            = '||PT_NRPA1;
          IF VR_PA2_ESTIMAVIVA IS NOT NULL
            THEN QUERY := QUERY || '            AND PA2_IDPA2            IN ('||VR_PA2_ESTIMAVIVA||')';
            ELSE QUERY := QUERY || '            AND PA2_IDPA2            = '||VR_PA2_IDPA2;
          END IF;
          QUERY := QUERY || '                   AND PTA_NRMODESCRITURACAO= '||PT_IDMODESCRITURACAO;
          QUERY := QUERY || '                  )';
          QUERY := QUERY || 'GROUP BY PTA_IDPTA, DOCUMENTO, PTA_CDREGISTRO)';
          VR_PA2_ESTIMAVIVA := NULL;
          EXECUTE IMMEDIATE QUERY BULK COLLECT INTO C_LPA_IDLPA
                                                   ,C_LPA_NRMODESCRITURACAO
                                                   ,C_LPA_NRPTA
                                                   ,C_LPA_CDLANCAMENTO
                                                   ,C_LPA_CDREGISTRO;
          IF C_LPA_IDLPA.EXISTS(1) THEN
          BEGIN
             IF PT_TOM312M362 IS NULL
               THEN PT_TOM312M362 := 0;
             END IF;
             FOR INTM312M362 IN C_LPA_IDLPA.FIRST .. C_LPA_IDLPA.LAST LOOP
             BEGIN
               INSERT INTO ECFREGISTROLANCCTBPTA_LPA (LPA_IDLPA,LPA_NRMODESCRITURACAO,LPA_NRPTA,LPA_CDLANCAMENTO,LPA_CDREGISTRO)
               VALUES (C_LPA_IDLPA(INTM312M362),
                       C_LPA_NRMODESCRITURACAO(INTM312M362),
                       C_LPA_NRPTA(INTM312M362),
                       C_LPA_CDLANCAMENTO(INTM312M362),
                       C_LPA_CDREGISTRO(INTM312M362));
               PT_TOM312M362 := PT_TOM312M362 + 1;
             END;
             END LOOP;
           END;
          END IF;
        END;
        ELSE
          BEGIN
            IF VR_PA2_ESTIMAVIVA IS NULL
              THEN VR_PA2_ESTIMAVIVA := TO_CHAR(REC_PA2.PA2_IDPA2);
              ELSE VR_PA2_ESTIMAVIVA := VR_PA2_ESTIMAVIVA ||','|| TO_CHAR(REC_PA2.PA2_IDPA2);
            END IF;
          END;
      END IF;
    END;
  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      VR_MENSAGEM_ERRO := SUBSTR('Mensagem do Sistema - Erro no processamento do registro : "' ||
                                 CT_REG_M312M362 || ' ' || SQLERRM,
                                 1,
                                 499) || '"';
      RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
    END;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 275844
PROMPT ======================================================================