PROMPT ======================================================================
PROMPT == DEMANDA......: 276348
PROMPT == SISTEMA......: Gestao de Processos
PROMPT == RESPONSAVEL..: CAIXA FINANCEIRO
PROMPT == DATA.........: 18/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (35269, 'Emiss�o da requisi��o de antecipa��o - Termo de responsabilidade', 'Emiss�o da requisi��o de antecipa��o - Termo de responsabilidade')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SGP', 35269, 23, 3000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35269, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35269, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35269, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276348
PROMPT ======================================================================