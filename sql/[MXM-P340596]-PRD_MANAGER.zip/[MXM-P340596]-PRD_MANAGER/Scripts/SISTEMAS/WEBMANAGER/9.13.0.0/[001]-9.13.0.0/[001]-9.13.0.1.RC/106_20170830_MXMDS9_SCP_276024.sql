PROMPT ======================================================================
PROMPT == DEMANDA......: 276024
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: WALTER FERREIRA NETO
PROMPT == DATA.........: 17/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GREFILTROCAMPOTAB_FCT
    SET FCT_NMCONDCAMPOCHB = 'CASE
           WHEN ((SELECT ANTECCPPRESTCONTA_APC.APC_DOCANTEC
                    FROM ANTECCPPRESTCONTA_APC
                   WHERE ANTECCPPRESTCONTA_APC.APC_CDFOR = ANTECCP_ACP.ACP_CDFOR
                     AND ANTECCPPRESTCONTA_APC.APC_DOCANTEC = ANTECCP_ACP.ACP_DOCANTEC
                     GROUP BY ANTECCPPRESTCONTA_APC.APC_DOCANTEC
                     HAVING COUNT(*) = 1) IS NULL
                AND ANTECCP_ACP.ACP_TPCAD = ''A''
                )
           THEN ''S''
           ELSE ''N''
   END'
  WHERE FCT_DSFILTRO = 'Somente em aberto'
    AND FCT_NRVISAO = '1'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276024
PROMPT ======================================================================