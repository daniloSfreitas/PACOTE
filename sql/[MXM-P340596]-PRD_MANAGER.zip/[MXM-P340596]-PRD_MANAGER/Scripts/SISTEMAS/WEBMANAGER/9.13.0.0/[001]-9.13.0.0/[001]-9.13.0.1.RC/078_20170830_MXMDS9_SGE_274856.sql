PROMPT ======================================================================
PROMPT == DEMANDA......: 274856
PROMPT == SISTEMA......: Estoque
PROMPT == RESPONSAVEL..: RODRIGO DA PAZ DO NASCIMENTO
PROMPT == DATA.........: 14/07/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE MANINFTRIBMODULOS_ITM MODIFY ITM_TXOBSERVACAO VARCHAR2(4000)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 274856
PROMPT ======================================================================