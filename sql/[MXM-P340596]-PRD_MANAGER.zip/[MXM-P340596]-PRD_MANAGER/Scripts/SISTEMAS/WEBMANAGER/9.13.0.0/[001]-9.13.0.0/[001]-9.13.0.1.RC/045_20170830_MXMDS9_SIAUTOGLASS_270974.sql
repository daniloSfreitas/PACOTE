PROMPT ======================================================================
PROMPT == DEMANDA......: 270974
PROMPT == SISTEMA......: Interfece AutoClass (Maxpar)
PROMPT == RESPONSAVEL..: JULIANO MENEZES
PROMPT == DATA.........: 18/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

create table FATANTECCP_FAP
(
  FAP_IDFATANTECCP   NUMBER(10) not null,
  FAP_CDEMPRESA      VARCHAR2(4) not null,
  FAP_CDFILIAL       VARCHAR2(4) not null,
  FAP_CDFATURA       NUMBER(10) not null,
  FAP_CDSEQUENCIA    NUMBER(3) not null,
  FAP_CDFOR          VARCHAR2(15) not null,
  FAP_CDDOCANTEC     VARCHAR2(20) not null,
  FAP_VLANTECIPACAO  NUMBER(15,2),
  FAP_DTINCLUSAO     DATE not null,
  FAP_USINCLUSAO     VARCHAR2(40) not null,
  FAP_DTALTERACAO    DATE,
  FAP_USALTERACAO    VARCHAR2(40)
)
/

comment on table FATANTECCP_FAP
  is 'Tabela responsavel por armazenar as antecipacoes vinculadas a fatura.'
/

comment on column FATANTECCP_FAP.FAP_IDFATANTECCP
  is 'Identificador de registro da antecipacao da fatura.'
/

comment on column FATANTECCP_FAP.FAP_CDEMPRESA
  is 'Codigo da empresa da fatura vinculada antecipacao.'
/

comment on column FATANTECCP_FAP.FAP_CDFILIAL
  is 'Codigo da filial da fatura vinculada antecipacao.'
/

comment on column FATANTECCP_FAP.FAP_CDFATURA
  is 'Codigo da fatura vinculada antecipacao.'
/

comment on column FATANTECCP_FAP.FAP_CDSEQUENCIA
  is 'Codigo da sequ�ncia da antecipacao na fatura'
/

comment on column FATANTECCP_FAP.FAP_CDFOR
  is 'Codigo do fornecedor da antecipacao vinculada a fatura.'
/

comment on column FATANTECCP_FAP.FAP_CDDOCANTEC
  is 'Codigo da antecipacao vinculada a fatura.'
/

comment on column FATANTECCP_FAP.FAP_VLANTECIPACAO
  is 'Valor da antecipacao da fatura'
/

comment on column FATANTECCP_FAP.FAP_DTINCLUSAO
  is 'Indicacao do dia, mes e ano em que a informacao foi criada na base de dados'
/

comment on column FATANTECCP_FAP.FAP_USINCLUSAO
  is 'O responsavel por realizar a criacao das informacoes na base de dados'
/

comment on column FATANTECCP_FAP.FAP_DTALTERACAO
  is 'Indicacao do dia, mes e ano em que a informacao foi alterada na base de dados'
/

comment on column FATANTECCP_FAP.FAP_USALTERACAO
  is 'O responsavel por realizar a alteracao das informacoes na base de dados'
/

alter table FATANTECCP_FAP
  add constraint PK_FATANTECCP_FAP primary key (FAP_IDFATANTECCP)
/

alter table FATANTECCP_FAP
  add constraint UK1_FATANTECCP_FAP unique (FAP_CDEMPRESA, FAP_CDFILIAL, FAP_CDFATURA, FAP_CDFOR, FAP_CDDOCANTEC)
/

alter table FATANTECCP_FAP
  add constraint FK1_FATANTECCP_FAP foreign key (FAP_CDEMPRESA, FAP_CDFILIAL, FAP_CDFATURA)
  references FATURAS_FAT (FAT_CDEMPRESA, FAT_CDFILIAL, FAT_CDFATURA)
/

alter table FATANTECCP_FAP
  add constraint FK2_FATANTECCP_FAP foreign key (FAP_CDFOR)
  references FORNEC_FOR (FOR_CODIGO)
/

alter table FATANTECCP_FAP
  add constraint FK3_FATANTECCP_FAP foreign key (FAP_CDFOR, FAP_CDDOCANTEC)
  references ANTECCP_ACP (ACP_CDFOR, ACP_DOCANTEC)
/

create index IN1_FATANTECCP_FAP on FATANTECCP_FAP (FAP_CDEMPRESA, FAP_CDFILIAL, FAP_CDFATURA)
/

create index IN2_FATANTECCP_FAP on FATANTECCP_FAP (FAP_CDFOR)
/

create index IN3_FATANTECCP_FAP on FATANTECCP_FAP (FAP_CDFOR, FAP_CDDOCANTEC)
/

CREATE OR REPLACE PROCEDURE PRC_INSFATANTECCP_FAP(
 PFAP_IDFATANTECCP   IN OUT NUMBER
,PFAP_CDEMPRESA      IN CHAR
,PFAP_CDFILIAL       IN CHAR
,PFAP_CDFATURA       IN NUMBER
,PFAP_CDSEQUENCIA    IN NUMBER
,PFAP_CDFOR          IN CHAR
,PFAP_CDDOCANTEC     IN CHAR
,PFAP_VLANTECIPACAO  IN NUMBER
)
AS
BEGIN
  IF PFAP_IDFATANTECCP IS NULL THEN
   SELECT SEQ1_FATANTECCP_FAP.NEXTVAL INTO PFAP_IDFATANTECCP FROM DUAL;
  END IF;
  INSERT INTO FATANTECCP_FAP(
    FAP_IDFATANTECCP
   ,FAP_CDEMPRESA
   ,FAP_CDFILIAL
   ,FAP_CDFATURA
   ,FAP_CDSEQUENCIA
   ,FAP_CDFOR
   ,FAP_CDDOCANTEC
   ,FAP_VLANTECIPACAO
   ,FAP_DTINCLUSAO
   ,FAP_USINCLUSAO
) VALUES (
    PFAP_IDFATANTECCP
   ,PFAP_CDEMPRESA
   ,PFAP_CDFILIAL
   ,PFAP_CDFATURA
   ,PFAP_CDSEQUENCIA
   ,PFAP_CDFOR
   ,PFAP_CDDOCANTEC
   ,PFAP_VLANTECIPACAO
   ,SYSDATE
   ,GET_USER_MXM
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATANTECCP_FAP(
 PFAP_IDFATANTECCP   IN OUT NUMBER
,PFAP_CDEMPRESA      IN CHAR
,PFAP_CDFILIAL       IN CHAR
,PFAP_CDFATURA       IN NUMBER
,PFAP_CDSEQUENCIA    IN NUMBER
,PFAP_CDFOR          IN CHAR
,PFAP_CDDOCANTEC     IN CHAR
,PFAP_VLANTECIPACAO  IN NUMBER
)
AS
BEGIN
  UPDATE FATANTECCP_FAP
     SET FAP_IDFATANTECCP = PFAP_IDFATANTECCP
        ,FAP_CDEMPRESA = PFAP_CDEMPRESA
        ,FAP_CDFILIAL = PFAP_CDFILIAL
        ,FAP_CDFATURA = PFAP_CDFATURA
        ,FAP_CDSEQUENCIA = PFAP_CDSEQUENCIA
        ,FAP_CDFOR = PFAP_CDFOR
        ,FAP_CDDOCANTEC = PFAP_CDDOCANTEC
        ,FAP_VLANTECIPACAO = PFAP_VLANTECIPACAO
        ,FAP_USALTERACAO = GET_USER_MXM
   WHERE FAP_IDFATANTECCP = PFAP_IDFATANTECCP;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 270974
PROMPT ======================================================================