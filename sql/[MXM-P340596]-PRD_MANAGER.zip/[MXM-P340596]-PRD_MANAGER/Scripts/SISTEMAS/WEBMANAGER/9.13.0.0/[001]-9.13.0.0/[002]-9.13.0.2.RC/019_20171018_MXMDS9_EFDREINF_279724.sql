PROMPT ======================================================================
PROMPT == DEMANDA......: 279724
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: LUCAS PEREIRA D AMICO
PROMPT == DATA.........: 17/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE RNFTCPCOMP_RPC ADD RPC_TPORIGEMGRAVACAO NUMBER(1) DEFAULT '0'
/

ALTER TABLE RNFTCPCOMP_RPC MODIFY RPC_TPORIGEMGRAVACAO NOT NULL NOVALIDATE
/

COMMENT ON COLUMN RNFTCPCOMP_RPC.RPC_TPORIGEMGRAVACAO IS 'Campo indicar� a origem da grava��o, 0 - autom�tica / 1 - manual.'
/

ALTER TABLE RNFTCRCOMP_RRC ADD RRC_TPORIGEMGRAVACAO NUMBER(1) DEFAULT '0'
/

ALTER TABLE RNFTCRCOMP_RRC MODIFY RRC_TPORIGEMGRAVACAO NOT NULL NOVALIDATE
/

COMMENT ON COLUMN RNFTCRCOMP_RRC.RRC_TPORIGEMGRAVACAO IS 'Campo indicar� a origem da grava��o, 0 - autom�tica / 1 - manual.'
/

ALTER TABLE RNFACRDECPROCESSREF_ADP ADD ADP_TPIMPOSTO NUMBER(1) DEFAULT '1'
/

ALTER TABLE RNFACRDECPROCESSREF_ADP MODIFY ADP_TPIMPOSTO NOT NULL NOVALIDATE
/

ALTER TABLE RNFACRDECPROCESSREF_ADP ADD CONSTRAINT UK1_RNFACRDECPROCESSREF_ADP UNIQUE (ADP_CDACRDEC, ADP_TPIMPOSTO)
/

COMMENT ON COLUMN RNFACRDECPROCESSREF_ADP.ADP_TPIMPOSTO IS 'Tipos de imposto que o decr�scimo incide: Nenhum {0} , INSS {1}.'
/

COMMENT ON COLUMN FATCADOBRA_FCO.FCO_TPRESPONSAVELOBRA IS 'Tipo para indicar quem � o respons�vel pela matr�cula CEI/CNO,
 perante ao governo. Op��es: Empresa/Filial (E), Cliente (C), Fornecedor (F).'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279724
PROMPT ======================================================================