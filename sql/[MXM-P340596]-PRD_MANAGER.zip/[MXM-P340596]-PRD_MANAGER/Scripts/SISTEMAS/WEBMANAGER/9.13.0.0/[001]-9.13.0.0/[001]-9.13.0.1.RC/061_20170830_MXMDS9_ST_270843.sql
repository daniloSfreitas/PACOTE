PROMPT ======================================================================
PROMPT == DEMANDA......: 270843
PROMPT == SISTEMA......: Tesouraria
PROMPT == RESPONSAVEL..: MARCEL BRUNO BARREIROS COSTA
PROMPT == DATA.........: 14/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE VIEW CONS_LANC_FLUXOCAIXA AS
SELECT "FCR_CDEMPRESA","FCR_CDFILIAL","FCR_CDMOEDA","FCR_COTACAO","FCF_TIPO","FCF_DATA","IFC_SQREGISTRO","IFC_SQPROCESSO","IFC_SQITEM","IFC_PLANOFCAIXA","IFC_CTAFLUXOCAIXA","IFC_NOCCUSTO","IFC_HISTORICO","IFC_VALORLIQUIDO","IFC_VALORLIQUIDO2M","IFC_CDPROJETO"
  FROM (SELECT A.FCR_CDEMPRESA,
              A.FCR_CDFILIAL,
              A.FCR_CDMOEDA,
              A.FCR_COTACAO,
              B.FCF_TIPO,
              B.FCF_DATA,
              C.IFC_SQREGISTRO,
              C.IFC_SQPROCESSO,
              C.IFC_SQITEM,
              C.IFC_PLANOFCAIXA,
              C.IFC_CTAFLUXOCAIXA,
              C.IFC_NOCCUSTO,
              C.IFC_HISTORICO,
              C.IFC_VALORLIQUIDO,
              C.IFC_VALORLIQUIDO2M,
              C.IFC_CDPROJETO
         FROM FLUXOCAIXAREG_FCR A,
              FLUXOCAIXAFIN_FCF B,
              ITEMFLUXOCAIXA_IFC C
        WHERE C.IFC_SQPROCESSO = B.FCF_SQPROCESSO
          AND C.IFC_SQPROCESSO = A.FCR_SQPROCESSO
          AND C.IFC_SQREGISTRO = A.FCR_SQREGISTRO
        UNION ALL
        SELECT G.CONS_CDEMPTIT AS FCR_CDEMPRESA,
              D.FCR_CDFILIAL,
              D.FCR_CDMOEDA,
              D.FCR_COTACAO,
              E.FCF_TIPO,
              E.FCF_DATA,
              F.IFC_SQREGISTRO,
              F.IFC_SQPROCESSO,
              F.IFC_SQITEM,
              F.IFC_PLANOFCAIXA,
              F.IFC_CTAFLUXOCAIXA,
              F.IFC_NOCCUSTO,
              F.IFC_HISTORICO,
              F.IFC_VALORLIQUIDO,
              F.IFC_VALORLIQUIDO2M,
              F.IFC_CDPROJETO
         FROM FLUXOCAIXAREG_FCR D,
              FLUXOCAIXAFIN_FCF E,
              ITEMFLUXOCAIXA_IFC F,
              EMP_CONS G
        WHERE F.IFC_SQPROCESSO = E.FCF_SQPROCESSO
          AND F.IFC_SQPROCESSO = D.FCR_SQPROCESSO
          AND F.IFC_SQREGISTRO = D.FCR_SQREGISTRO
          AND G.CONS_CDEMPRESA = D.FCR_CDEMPRESA
       )
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 270843
PROMPT ======================================================================