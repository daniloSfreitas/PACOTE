PROMPT ======================================================================
PROMPT == DEMANDA......: 272419
PROMPT == SISTEMA......: SISTEMA DE INTEGRA��O SONHO DOS PES
PROMPT == RESPONSAVEL..: THIAGO FERREIRA BARBOSA
PROMPT == DATA.........: 07/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

alter table TI_ARQCLIENTE_TACL add(TACL_CDCONTROLE VARCHAR2(30))
/

alter table TI_ARQFORNEC_TAFO add(TAFO_CDCONTROLE VARCHAR2(30))
/

comment on column TI_ARQFORNEC_TAFO.TAFO_CDCONTROLE  is 'Campo que conter� o c�digo para controle na base do cliente. Esse campo � de uso exclusivo da interface, n�o ser� enviado para o manager.'
/

comment on column TI_ARQCLIENTE_TACL.TACL_CDCONTROLE  is 'Campo que conter� o c�digo para controle na base do cliente. Esse campo � de uso exclusivo da interface, n�o ser� enviado para o manager.'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 272419
PROMPT ======================================================================