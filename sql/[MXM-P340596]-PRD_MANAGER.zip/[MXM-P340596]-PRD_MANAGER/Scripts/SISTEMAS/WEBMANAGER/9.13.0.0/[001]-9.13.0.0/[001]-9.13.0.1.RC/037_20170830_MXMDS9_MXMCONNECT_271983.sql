PROMPT ======================================================================
PROMPT == DEMANDA......: 271983
PROMPT == SISTEMA......: MXM CONNECT
PROMPT == RESPONSAVEL..: ANDERSON EIJI NOGUTI
PROMPT == DATA.........: 29/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE SCH_EXECUCAO_SCE
ADD (SCE_IDARQUIVO  NUMBER(10))
/

COMMENT ON COLUMN SCH_EXECUCAO_SCE.SCE_IDARQUIVO IS 'Id do arquivo publicado no MXM-Connect'
/

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (40500, 'Acompanhamento do agendador de relat�rios', 'Acompanhamento do agendador de relat�rios')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('MXMCONNECT', 40500, 1, 4000)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40500, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40500, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (40500, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 271983
PROMPT ======================================================================