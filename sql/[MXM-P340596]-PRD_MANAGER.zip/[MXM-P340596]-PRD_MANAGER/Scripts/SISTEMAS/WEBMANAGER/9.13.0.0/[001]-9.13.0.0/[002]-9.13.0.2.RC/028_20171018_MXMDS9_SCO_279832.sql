PROMPT ======================================================================
PROMPT == DEMANDA......: 279832
PROMPT == SISTEMA......: Compras
PROMPT == RESPONSAVEL..: ERICA LIMA BOTELHO
PROMPT == DATA.........: 17/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE MXS_FUNCAO_MXF
  SET MXF_TITULO    = 'Crit�rio de avalia��o de fornecedores',
      MXF_DESCRICAO = 'Cadastro de crit�rio de avalia��o de fornecedores'
 WHERE MXF_FUNCAO = '10252'
/

UPDATE MXS_FUNCAOSISTEMA_MXFS
  SET MXFS_CDFUNCAOSUP = 1000,
        MXFS_ORDEM= 34
 WHERE MXFS_CDSISTEMA = 'SCO'
   AND MXFS_CDFUNCAO = '10251'
/

UPDATE MXS_FUNCAOSISTEMA_MXFS
  SET MXFS_CDFUNCAOSUP = 1000,
        MXFS_ORDEM= 35
 WHERE MXFS_CDSISTEMA = 'SCO'
   AND MXFS_CDFUNCAO = '10252'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279832
PROMPT ======================================================================