PROMPT ======================================================================
PROMPT == DEMANDA......: 271158
PROMPT == SISTEMA......: Patrimonio
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 15/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE CALCDEPMEN (
   codemp       IN   CHAR,
   itemini      IN   CHAR,
   anexini      IN   CHAR,
   itemfim      IN   CHAR,
   anexfim      IN   CHAR,
   dtaquis1     IN   DATE,
   dtaquis2     IN   DATE,
   ccusto1      IN   CHAR,
   ccusto2      IN   CHAR,
   cdprojeto1   IN   CHAR,
   cdprojeto2   IN   CHAR,
   grpat1       IN   CHAR,
   grpat2       IN   CHAR,
   codplan      IN   CHAR,
   dtbase       IN   DATE,
   contabil     IN   CHAR,
   todos        IN   CHAR
)
AS
   vcodemp             VARCHAR2 (04);
   vpatrim             VARCHAR2 (10);
   vanexo              VARCHAR2 (03);
   vccusto             VARCHAR2 (15);
   accusto             VARCHAR2 (15);
   vlocal              VARCHAR2 (10);
   vrespons            VARCHAR2 (30);
   vdiadepr            VARCHAR2 (02);
   lancto              VARCHAR2 (06);
   lote                VARCHAR2 (06);
   grpat               VARCHAR2 (06);
   vaux                VARCHAR2 (10);
   vmoeda              VARCHAR2 (03);
   vmoedal             VARCHAR2 (03);
   amtmoeda            VARCHAR2 (01);
   vsequencial         NUMBER;
   vstaccusto          NUMBER;
   vultmov1            DATE;
   vultmov2            DATE;
   vultdata1           DATE;
   vultdata2           DATE;
   vpridpdt1           DATE;
   vpridpdt2           DATE;
   vultdtlct1          DATE;
   vultdtlct2          DATE;
   vdatatmp            DATE;
   vdtaquis            DATE;
   vdtpdepres1         DATE;
   vdtpdepres2         DATE;
   vaquis1             NUMBER;
   vacrbem1            NUMBER;
   vdeprec1            NUMBER;
   vacrdep1            NUMBER;
   vpercdep1           NUMBER;
   vaquis2             NUMBER;
   vacrbem2            NUMBER;
   vdeprec2            NUMBER;
   vacrdep2            NUMBER;
   vpercdep2           NUMBER;
   vmvdep              NUMBER;
   vsaldo              NUMBER;
   a                   NUMBER;
   vvalormaxdep1       NUMBER;
              -- Valor residual limite, ser� depreciado o item at� esse valor
   vvalormaxdep2       NUMBER;
              -- Valor residual limite, ser� depreciado o item at� esse valor
   vachou              BOOLEAN;
   vachou1             BOOLEAN;
   vachou2             BOOLEAN;
   vdeppro1            BOOLEAN;
   vgrpatrim           VARCHAR2 (06);
   vgrcont             VARCHAR2 (01);
   vctadep             VARCHAR2 (15);
   vdespdep            VARCHAR2 (15);
   vhistorico          VARCHAR2 (200);
   historico           VARCHAR2 (200);
   vtotdep             NUMBER;
   vtotdep1            NUMBER;
   vgeroumov           VARCHAR2 (01);
   vdatalibper         DATE;
   vdatalibpersap      DATE;
   vcdprojeto          VARCHAR2 (20);
   vultimaordemusada   NUMBER (10);
   vgrupopatrimonial   varchar2 (6);
   vultitemctb         VARCHAR2 (15);
   vGrupoPatriProporcional varchar2(1);
   vseqmovsap number;
   vseqmovsap1 number;
   CURSOR pegaitem -- Pega faixa seleta de itens
   IS
      SELECT pat_cdempresa, pat_cdpatrimo, pat_cdanexo, pat_pdep1, pat_pdep2,
             pat_ultmov1, pat_ultmov2, pat_vlmaxdeprec1, pat_vlmaxdeprec2,
             pat_cdprojeto, PAT_GRPATRIM, GPAT_VBPROPORCIONAL
        FROM patrimon_pat,GRPATRIM_GPAT
       WHERE PAT_GRPATRIM = GPAT_CODIGO
         AND pat_cdpatrimo >= itemini
         AND pat_cdanexo >= anexini
         AND pat_cdpatrimo <= itemfim
         AND pat_cdanexo <= anexfim
         AND (   TO_DATE (dtaquis1, 'DD/MM/RR') IS NULL
              OR TO_DATE (pat_dtaquis, 'DD/MM/RR') >=
                                                TO_DATE (dtaquis1, 'DD/MM/RR')
             )
         AND (   TO_DATE (dtaquis2, 'DD/MM/RR') IS NULL
              OR TO_DATE (pat_dtaquis, 'DD/MM/RR') <=
                                                TO_DATE (dtaquis2, 'DD/MM/RR')
             )
         AND (ccusto1 IS NULL OR pat_noccusto >= ccusto1)
         AND (ccusto2 IS NULL OR pat_noccusto <= ccusto2)
         AND (cdprojeto1 IS NULL OR pat_cdprojeto >= cdprojeto1)
         AND (cdprojeto2 IS NULL OR pat_cdprojeto <= cdprojeto2)
         AND (grpat1 IS NULL OR pat_grpatrim >= grpat1)
         AND (grpat2 IS NULL OR pat_grpatrim <= grpat2)
         AND pat_cdempresa = codemp
         AND TO_DATE (pat_dtbaixa, 'DD/MM/RR') IS NULL
         AND (   (pat_deprtot1 IS NULL)
              OR ((pat_deprtot2 IS NULL) AND (pat_deprec2 > 0))
             )
         AND (   pat_percdep1 > 0
              OR EXISTS (
                    SELECT 1
                      FROM grpatrim_gpat
                     WHERE gpat_codigo = pat_grpatrim
                       AND gpat_idtaxadepreciacao IS NOT NULL)
             )
         AND NOT TO_DATE (pat_pdep1, 'DD/MM/RR') IS NULL
         AND (   TO_DATE (pat_pdep1, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
              OR TO_DATE (pat_pdep2, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
             )
         AND (   (   TO_DATE (pat_ultmov1, 'DD/MM/RR') IS NULL
                  OR TO_DATE (pat_ultmov1, 'DD/MM/RR') <
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                 )
              OR (   TO_DATE (pat_ultmov2, 'DD/MM/RR') IS NULL
                  OR TO_DATE (pat_ultmov2, 'DD/MM/RR') <
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                 )
             );
   CURSOR pegaitem1 -- Pega todos os itens da empresa
   IS
      SELECT pat_cdempresa, pat_cdpatrimo, pat_cdanexo, pat_pdep1, pat_pdep2,
             pat_ultmov1, pat_ultmov2, pat_vlmaxdeprec1, pat_vlmaxdeprec2,
             pat_cdprojeto, PAT_grpatrim, GPAT_VBPROPORCIONAL
        FROM patrimon_pat,GRPATRIM_GPAT
       WHERE PAT_GRPATRIM = GPAT_CODIGO
         AND (   TO_DATE (dtaquis1, 'DD/MM/RR') IS NULL
              OR pat_dtaquis >= TO_DATE (dtaquis1, 'DD/MM/RR')
             )
         AND (   TO_DATE (dtaquis2, 'DD/MM/RR') IS NULL
              OR TO_DATE (pat_dtaquis, 'DD/MM/RR') <=
                                                TO_DATE (dtaquis2, 'DD/MM/RR')
             )
         AND (ccusto1 IS NULL OR pat_noccusto >= ccusto1)
         AND (ccusto2 IS NULL OR pat_noccusto <= ccusto2)
         AND (cdprojeto1 IS NULL OR pat_cdprojeto >= cdprojeto1)
         AND (cdprojeto2 IS NULL OR pat_cdprojeto <= cdprojeto2)
         AND (grpat1 IS NULL OR pat_grpatrim >= grpat1)
         AND (grpat2 IS NULL OR pat_grpatrim <= grpat2)
         AND pat_cdempresa = codemp
         AND TO_DATE (pat_dtbaixa, 'DD/MM/RR') IS NULL
         AND (   (pat_deprtot1 IS NULL)
              OR ((pat_deprtot2 IS NULL) AND (pat_deprec2 > 0))
             )
         AND (   pat_percdep1 > 0
              OR EXISTS (
                    SELECT 1
                      FROM grpatrim_gpat
                     WHERE gpat_codigo = pat_grpatrim
                       AND gpat_idtaxadepreciacao IS NOT NULL)
             )
         AND NOT TO_DATE (pat_pdep1, 'DD/MM/RR') IS NULL
         AND (   TO_DATE (pat_pdep1, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
              OR TO_DATE (pat_pdep2, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
             )
         AND (   (   TO_DATE (pat_ultmov1, 'DD/MM/RR') IS NULL
                  OR TO_DATE (pat_ultmov1, 'DD/MM/RR') <
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                 )
              OR (   TO_DATE (pat_ultmov2, 'DD/MM/RR') IS NULL
                  OR TO_DATE (pat_ultmov2, 'DD/MM/RR') <
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                 )
             );
   CURSOR ultdata1                   -- Data do proximo movimento na 1a. moeda
   IS
      SELECT MAX (ADD_MONTHS (LAST_DAY (msap_data), 1))
        FROM movsap_msap
       WHERE msap_cdempresa = codemp
         AND msap_cdpatrimo = vpatrim
         AND msap_cdanexo = vanexo
         AND (msap_tpmov = 'D' OR msap_tpmov = 'A');
   CURSOR ultdata2                   -- Data do proximo movimento na 2a. moeda
   IS
      SELECT MAX (ADD_MONTHS (LAST_DAY (msap_data1), 1))
        FROM movsap1_msap
       WHERE msap_cdempresa1 = codemp
         AND msap_cdpatrimo1 = vpatrim
         AND msap_cdanexo1 = vanexo
         AND (msap_tpmov1 = 'D' OR msap_tpmov1 = 'A');
   CURSOR jatemmov1    -- Verifica se ja possui movimento da 1a. moeda na data
   IS
      SELECT msap_cdpatrimo
        FROM movsap_msap
       WHERE msap_cdempresa = codemp
         AND msap_cdpatrimo = vpatrim
         AND msap_cdanexo = vanexo
         AND msap_tpmov = 'D'
         AND TO_DATE (msap_data, 'DD/MM/RR') >=
                                               TO_DATE (vpridpdt1, 'DD/MM/RR');
   CURSOR jatemmov2    -- Verifica se ja possui movimento da 2a. moeda na data
   IS
      SELECT msap_cdpatrimo1
        FROM movsap1_msap
       WHERE msap_cdempresa1 = codemp
         AND msap_cdpatrimo1 = vpatrim
         AND msap_cdanexo1 = vanexo
         AND msap_tpmov1 = 'D'
         AND TO_DATE (msap_data1, 'DD/MM/RR') >=
                                               TO_DATE (vpridpdt2, 'DD/MM/RR');
   CURSOR lancamento
-- Pega faixa seleta de itens e seus valores para o lancamento contabil na 1a. moeda
   IS
      SELECT   ctadep, ctadespdep, noccusto, grpatrim, contabil, DATA,
               SUM (NVL (ttot1, 0)) AS tot1, SUM (NVL (ttot2, 0)) AS tot2,
               projeto
          FROM (SELECT   cgpat_ctadep AS ctadep,
                         DECODE (a.plc_ccusto,
                                 'S', DECODE (b.plc_ccusto,
                                              'N', NULL,
                                              cgpat_ctadespdep
                                             ),
                                 DECODE (b.plc_ccusto,
                                         'S', cgpat_ctadespdep,
                                         NULL
                                        )
                                ) AS ctadespdep,
                         DECODE (a.plc_ccusto,
                                 'N', NULL,
                                 pat_noccusto
                                ) AS noccusto,
                         pat_grpatrim AS grpatrim, gpat_contabil AS contabil,
                         TO_DATE (msap_data, 'DD/MM/RR') AS DATA,
                         SUM (NVL (msap_vdep, 0)) AS ttot1, 0 AS ttot2,
                         pat_cdprojeto AS projeto
                    FROM patrimon_pat,
                         movsap_msap,
                         grpatctb_cgpat,
                         grpatrim_gpat,
                         planocta_plc a,
                         planocta_plc b
                   WHERE pat_cdpatrimo >= itemini
                     AND pat_cdanexo >= anexini
                     AND pat_cdpatrimo <= itemfim
                     AND pat_cdanexo <= anexfim
                     AND (ccusto1 IS NULL OR pat_noccusto >= ccusto1)
                     AND (ccusto2 IS NULL OR pat_noccusto <= ccusto2)
                     AND (cdprojeto1 IS NULL OR pat_cdprojeto >= cdprojeto1)
                     AND (cdprojeto2 IS NULL OR pat_cdprojeto <= cdprojeto2)
                     AND (grpat1 IS NULL OR pat_grpatrim >= grpat1)
                     AND (grpat2 IS NULL OR pat_grpatrim <= grpat2)
                     AND pat_cdempresa = codemp
                     AND TO_DATE (pat_dtbaixa, 'DD/MM/RR') IS NULL
                     AND (   pat_percdep1 > 0
                          OR gpat_idtaxadepreciacao IS NOT NULL
                         )
                     AND pat_cdempresa = msap_cdempresa
                     AND pat_cdpatrimo = msap_cdpatrimo
                     AND pat_cdanexo = msap_cdanexo
                    AND pat_grpatrim = gpat_codigo
                     AND gpat_codigo = cgpat_codigo
                     AND pat_cdempresa = cgpat_cdempresa
                     AND a.plc_nocontab = cgpat_ctadep
                     AND a.plc_codplano = cgpat_codplconta
                     AND b.plc_nocontab = cgpat_ctadespdep
                     AND b.plc_codplano = cgpat_codplconta
                     AND TO_DATE (msap_data, 'DD/MM/RR') >=
                                              TO_DATE (vultdtlct1, 'DD/MM/RR')
                     AND TO_DATE (msap_data, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                     AND msap_tpmov = 'D'
                GROUP BY cgpat_ctadep,
                         cgpat_ctadespdep,
                         pat_noccusto,
                         a.plc_ccusto,
                         b.plc_ccusto,
                         pat_grpatrim,
                         gpat_contabil,
                         TO_DATE (msap_data, 'DD/MM/RR'),
                         pat_cdprojeto
                UNION ALL
                SELECT   DECODE (a.plc_ccusto,
                                 'S', DECODE (b.plc_ccusto,
                                              'N', NULL,
                                              cgpat_ctadep
                                             ),
                                 DECODE (b.plc_ccusto,
                                         'S', cgpat_ctadep,
                                         NULL
                                        )
                                ) AS ctadep,
                         cgpat_ctadespdep AS ctadespdep,
                         DECODE (a.plc_ccusto,
                                 'N', NULL,
                                 pat_noccusto
                                ) AS noccusto,
                         pat_grpatrim AS grpatrim, gpat_contabil AS contabil,
                         msap_data AS DATA, SUM (NVL (msap_vdep, 0)) AS ttot1,
                         0 AS ttot2, pat_cdprojeto AS projeto
                    FROM patrimon_pat,
                         movsap_msap,
                         grpatctb_cgpat,
                         grpatrim_gpat,
                         planocta_plc a,
                         planocta_plc b
                   WHERE pat_cdpatrimo >= itemini
                     AND pat_cdanexo >= anexini
                     AND pat_cdpatrimo <= itemfim
                     AND pat_cdanexo <= anexfim
                     AND (ccusto1 IS NULL OR pat_noccusto >= ccusto1)
                     AND (ccusto2 IS NULL OR pat_noccusto <= ccusto2)
                     AND (cdprojeto1 IS NULL OR pat_cdprojeto >= cdprojeto1)
                     AND (cdprojeto2 IS NULL OR pat_cdprojeto <= cdprojeto2)
                     AND (grpat1 IS NULL OR pat_grpatrim >= grpat1)
                     AND (grpat2 IS NULL OR pat_grpatrim <= grpat2)
                     AND pat_cdempresa = codemp
                     AND pat_dtbaixa IS NULL
                     AND (   pat_percdep1 > 0
                          OR gpat_idtaxadepreciacao IS NOT NULL
                         )
                     AND pat_cdempresa = msap_cdempresa
                     AND pat_cdpatrimo = msap_cdpatrimo
                     AND pat_cdanexo = msap_cdanexo
                     AND pat_grpatrim = gpat_codigo
                     AND gpat_codigo = cgpat_codigo
                     AND pat_cdempresa = cgpat_cdempresa
                     AND b.plc_nocontab = cgpat_ctadep
                     AND b.plc_codplano = cgpat_codplconta
                     AND a.plc_nocontab = cgpat_ctadespdep
                     AND a.plc_codplano = cgpat_codplconta
                     AND TO_DATE (msap_data, 'DD/MM/RR') >=
                                              TO_DATE (vultdtlct1, 'DD/MM/RR')
                     AND TO_DATE (msap_data, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                     AND msap_tpmov = 'D'
                GROUP BY cgpat_ctadep,
                         cgpat_ctadespdep,
                         pat_noccusto,
                         b.plc_ccusto,
                         a.plc_ccusto,
                         pat_grpatrim,
                         gpat_contabil,
                         msap_data,
                         pat_cdprojeto
                UNION ALL
                SELECT   cgpat_ctadep AS ctadep,
                         DECODE (a.plc_ccusto,
                                 'S', DECODE (b.plc_ccusto,
                                              'N', NULL,
                                              cgpat_ctadespdep
                                             ),
                                 DECODE (b.plc_ccusto,
                                         'S', cgpat_ctadespdep,
                                         NULL
                                        )
                                ) AS ctadespdep,
                         DECODE (a.plc_ccusto,
                                 'N', NULL,
                                 pat_noccusto
                                ) AS noccusto,
                         pat_grpatrim AS grpatrim, gpat_contabil AS contabil,
                         msap_data1 AS DATA, 0 AS ttot1,
                         SUM (NVL (msap_vdep1, 0)) AS ttot2,
                         pat_cdprojeto AS projeto
                    FROM patrimon_pat,
                         movsap1_msap,
                         grpatctb_cgpat,
                         grpatrim_gpat,
                         planocta_plc a,
                         planocta_plc b
                   WHERE pat_cdpatrimo >= itemini
                     AND pat_cdanexo >= anexini
                     AND pat_cdpatrimo <= itemfim
                     AND pat_cdanexo <= anexfim
                     AND (ccusto1 IS NULL OR pat_noccusto >= ccusto1)
                     AND (ccusto2 IS NULL OR pat_noccusto <= ccusto2)
                     AND (cdprojeto1 IS NULL OR pat_cdprojeto >= cdprojeto1)
                     AND (cdprojeto2 IS NULL OR pat_cdprojeto <= cdprojeto2)
                     AND (grpat1 IS NULL OR pat_grpatrim >= grpat1)
                     AND (grpat2 IS NULL OR pat_grpatrim <= grpat2)
                     AND pat_cdempresa = codemp
                     AND pat_dtbaixa IS NULL
                     AND pat_percdep2 > 0
                     AND pat_cdempresa = msap_cdempresa1
                     AND pat_cdpatrimo = msap_cdpatrimo1
                     AND pat_cdanexo = msap_cdanexo1
                     AND pat_grpatrim = gpat_codigo
                     AND gpat_codigo = cgpat_codigo
                     AND pat_cdempresa = cgpat_cdempresa
                     AND a.plc_nocontab = cgpat_ctadep
                     AND a.plc_codplano = cgpat_codplconta
                     AND b.plc_nocontab = cgpat_ctadespdep
                     AND b.plc_codplano = cgpat_codplconta
                     AND TO_DATE (msap_data1, 'DD/MM/RR') >=
                                              TO_DATE (vultdtlct1, 'DD/MM/RR')
                     AND TO_DATE (msap_data1, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                     AND msap_tpmov1 = 'D'
                GROUP BY cgpat_ctadep,
                         cgpat_ctadespdep,
                         pat_noccusto,
                         a.plc_ccusto,
                         b.plc_ccusto,
                         pat_grpatrim,
                         gpat_contabil,
                         msap_data1,
                         pat_cdprojeto
                UNION ALL
                SELECT   DECODE (a.plc_ccusto,
                                 'S', DECODE (b.plc_ccusto,
                                              'N', NULL,
                                              cgpat_ctadep
                                             ),
                                 DECODE (b.plc_ccusto,
                                         'S', cgpat_ctadep,
                                         NULL
                                        )
                                ) AS ctadep,
                         cgpat_ctadespdep AS ctadespdep,
                         DECODE (a.plc_ccusto,
                                 'N', NULL,
                                 pat_noccusto
                                ) AS noccusto,
                         pat_grpatrim AS grpatrim, gpat_contabil AS contabil,
                         msap_data1 AS DATA, 0 AS ttot1,
                         SUM (NVL (msap_vdep1, 0)) AS ttot2,
                         pat_cdprojeto AS projeto
                    FROM patrimon_pat,
                         movsap1_msap,
                         grpatctb_cgpat,
                         grpatrim_gpat,
                         planocta_plc a,
                         planocta_plc b
                   WHERE pat_cdpatrimo >= itemini
                     AND pat_cdanexo >= anexini
                     AND pat_cdpatrimo <= itemfim
                     AND pat_cdanexo <= anexfim
                     AND (ccusto1 IS NULL OR pat_noccusto >= ccusto1)
                     AND (ccusto2 IS NULL OR pat_noccusto <= ccusto2)
                     AND (cdprojeto1 IS NULL OR pat_cdprojeto >= cdprojeto1)
                     AND (cdprojeto2 IS NULL OR pat_cdprojeto <= cdprojeto2)
                     AND (grpat1 IS NULL OR pat_grpatrim >= grpat1)
                     AND (grpat2 IS NULL OR pat_grpatrim <= grpat2)
                     AND pat_cdempresa = codemp
                     AND pat_dtbaixa IS NULL
                     AND pat_percdep2 > 0
                     AND pat_cdempresa = msap_cdempresa1
                     AND pat_cdpatrimo = msap_cdpatrimo1
                     AND pat_cdanexo = msap_cdanexo1
                     AND pat_grpatrim = gpat_codigo
                     AND gpat_codigo = cgpat_codigo
                     AND pat_cdempresa = cgpat_cdempresa
                     AND b.plc_nocontab = cgpat_ctadep
                     AND b.plc_codplano = cgpat_codplconta
                     AND a.plc_nocontab = cgpat_ctadespdep
                     AND a.plc_codplano = cgpat_codplconta
                     AND TO_DATE (msap_data1, 'DD/MM/RR') >=
                                              TO_DATE (vultdtlct1, 'DD/MM/RR')
                     AND TO_DATE (msap_data1, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                     AND msap_tpmov1 = 'D'
                GROUP BY cgpat_ctadep,
                         cgpat_ctadespdep,
                         pat_noccusto,
                         b.plc_ccusto,
                         a.plc_ccusto,
                         pat_grpatrim,
                         gpat_contabil,
                         msap_data1,
                         pat_cdprojeto)
      GROUP BY ctadep, ctadespdep, noccusto, grpatrim, contabil, DATA,
               projeto
      ORDER BY grpatrim, DATA, ctadespdep, ctadep, noccusto, contabil;
   CURSOR lancamentoa
-- Pega todos os itens e seus valores para o lancamento contabil na 1a. moeda
   IS
      SELECT   ctadep, ctadespdep, noccusto, grpatrim, contabil, DATA,
               SUM (NVL (ttot1, 0)) AS tot1, SUM (NVL (ttot2, 0)) AS tot2,
               projeto
          FROM (SELECT   cgpat_ctadep AS ctadep,
                         DECODE (a.plc_ccusto,
                                 'S', DECODE (b.plc_ccusto,
                                              'N', NULL,
                                              cgpat_ctadespdep
                                             ),
                                 DECODE (b.plc_ccusto,
                                         'S', cgpat_ctadespdep,
                                         NULL
                                        )
                                ) AS ctadespdep,
                         DECODE (a.plc_ccusto,
                                 'N', NULL,
                                 pat_noccusto
                                ) AS noccusto,
                         pat_grpatrim AS grpatrim, gpat_contabil AS contabil,
                         msap_data AS DATA, SUM (NVL (msap_vdep, 0)) AS ttot1,
                         0 AS ttot2, pat_cdprojeto AS projeto
                    FROM patrimon_pat,
                         movsap_msap,
                         grpatctb_cgpat,
                         grpatrim_gpat,
                         planocta_plc a,
                         planocta_plc b
                   WHERE (ccusto1 IS NULL OR pat_noccusto >= ccusto1)
                     AND (ccusto2 IS NULL OR pat_noccusto <= ccusto2)
                     AND (cdprojeto1 IS NULL OR pat_cdprojeto >= cdprojeto1)
                     AND (cdprojeto2 IS NULL OR pat_cdprojeto <= cdprojeto2)
                     AND (grpat1 IS NULL OR pat_grpatrim >= grpat1)
                     AND (grpat2 IS NULL OR pat_grpatrim <= grpat2)
                     AND pat_cdempresa = codemp
                     AND pat_dtbaixa IS NULL
                     AND (   pat_percdep1 > 0
                          OR gpat_idtaxadepreciacao IS NOT NULL
                         )
                     AND pat_cdempresa = msap_cdempresa
                     AND pat_cdpatrimo = msap_cdpatrimo
                     AND pat_cdanexo = msap_cdanexo
                     AND pat_grpatrim = gpat_codigo
                     AND gpat_codigo = cgpat_codigo
                     AND pat_cdempresa = cgpat_cdempresa
                     AND a.plc_nocontab = cgpat_ctadep
                     AND a.plc_codplano = cgpat_codplconta
                     AND b.plc_nocontab = cgpat_ctadespdep
                     AND b.plc_codplano = cgpat_codplconta
                     AND TO_DATE (msap_data, 'DD/MM/RR') >=
                                              TO_DATE (vultdtlct1, 'DD/MM/RR')
                     AND TO_DATE (msap_data, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                     AND msap_tpmov = 'D'
                GROUP BY cgpat_ctadep,
                         cgpat_ctadespdep,
                         pat_noccusto,
                         a.plc_ccusto,
                         b.plc_ccusto,
                         pat_grpatrim,
                         gpat_contabil,
                         msap_data,
                         pat_cdprojeto
                UNION ALL
                SELECT   DECODE (a.plc_ccusto,
                                 'S', DECODE (b.plc_ccusto,
                                              'N', NULL,
                                              cgpat_ctadep
                                             ),
                                 DECODE (b.plc_ccusto,
                                         'S', cgpat_ctadep,
                                         NULL
                                        )
                                ) AS ctadep,
                         cgpat_ctadespdep AS ctadespdep,
                         DECODE (a.plc_ccusto,
                                 'N', NULL,
                                 pat_noccusto
                                ) AS noccusto,
                         pat_grpatrim AS grpatrim, gpat_contabil AS contabil,
                         msap_data AS DATA, SUM (NVL (msap_vdep, 0)) AS ttot1,
                         0 AS ttot2, pat_cdprojeto AS projeto
                    FROM patrimon_pat,
                         movsap_msap,
                         grpatctb_cgpat,
                         grpatrim_gpat,
                         planocta_plc a,
                         planocta_plc b
                   WHERE (ccusto1 IS NULL OR pat_noccusto >= ccusto1)
                     AND (ccusto2 IS NULL OR pat_noccusto <= ccusto2)
                     AND (cdprojeto1 IS NULL OR pat_cdprojeto >= cdprojeto1)
                     AND (cdprojeto2 IS NULL OR pat_cdprojeto <= cdprojeto2)
                     AND (grpat1 IS NULL OR pat_grpatrim >= grpat1)
                     AND (grpat2 IS NULL OR pat_grpatrim <= grpat2)
                     AND pat_cdempresa = codemp
                     AND TO_DATE (pat_dtbaixa, 'DD/MM/RR') IS NULL
                     AND (   pat_percdep1 > 0
                          OR gpat_idtaxadepreciacao IS NOT NULL
                         )
                     AND pat_cdempresa = msap_cdempresa
                     AND pat_cdpatrimo = msap_cdpatrimo
                     AND pat_cdanexo = msap_cdanexo
                     AND pat_grpatrim = gpat_codigo
                     AND gpat_codigo = cgpat_codigo
                     AND pat_cdempresa = cgpat_cdempresa
                     AND b.plc_nocontab = cgpat_ctadep
                     AND b.plc_codplano = cgpat_codplconta
                     AND a.plc_nocontab = cgpat_ctadespdep
                     AND a.plc_codplano = cgpat_codplconta
                     AND TO_DATE (msap_data, 'DD/MM/RR') >=
                                              TO_DATE (vultdtlct1, 'DD/MM/RR')
                     AND TO_DATE (msap_data, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                     AND msap_tpmov = 'D'
                GROUP BY cgpat_ctadep,
                         cgpat_ctadespdep,
                         pat_noccusto,
                         b.plc_ccusto,
                         a.plc_ccusto,
                         pat_grpatrim,
                         gpat_contabil,
                         msap_data,
                         pat_cdprojeto
                UNION ALL
                SELECT   cgpat_ctadep AS ctadep,
                         DECODE (a.plc_ccusto,
                                 'S', DECODE (b.plc_ccusto,
                                              'N', NULL,
                                              cgpat_ctadespdep
                                             ),
                                 DECODE (b.plc_ccusto,
                                         'S', cgpat_ctadespdep,
                                         NULL
                                        )
                                ) AS ctadespdep,
                         DECODE (a.plc_ccusto,
                                 'N', NULL,
                                 pat_noccusto
                                ) AS noccusto,
                         pat_grpatrim AS grpatrim, gpat_contabil AS contabil,
                         msap_data1 AS DATA, 0 AS ttot1,
                         SUM (NVL (msap_vdep1, 0)) AS ttot2,
                         pat_cdprojeto AS projeto
                    FROM patrimon_pat,
                         movsap1_msap,
                         grpatctb_cgpat,
                         grpatrim_gpat,
                         planocta_plc a,
                         planocta_plc b
                   WHERE (ccusto1 IS NULL OR pat_noccusto >= ccusto1)
                     AND (ccusto2 IS NULL OR pat_noccusto <= ccusto2)
                     AND (cdprojeto1 IS NULL OR pat_cdprojeto >= cdprojeto1)
                     AND (cdprojeto2 IS NULL OR pat_cdprojeto <= cdprojeto2)
                     AND (grpat1 IS NULL OR pat_grpatrim >= grpat1)
                     AND (grpat2 IS NULL OR pat_grpatrim <= grpat2)
                     AND pat_cdempresa = codemp
                     AND TO_DATE (pat_dtbaixa, 'DD/MM/RR') IS NULL
                     AND pat_percdep2 > 0
                     AND pat_cdempresa = msap_cdempresa1
                     AND pat_cdpatrimo = msap_cdpatrimo1
                     AND pat_cdanexo = msap_cdanexo1
                     AND pat_grpatrim = gpat_codigo
                     AND gpat_codigo = cgpat_codigo
                     AND pat_cdempresa = cgpat_cdempresa
                     AND a.plc_nocontab = cgpat_ctadep
                     AND a.plc_codplano = cgpat_codplconta
                     AND b.plc_nocontab = cgpat_ctadespdep
                     AND b.plc_codplano = cgpat_codplconta
                     AND TO_DATE (msap_data1, 'DD/MM/RR') >=
                                              TO_DATE (vultdtlct1, 'DD/MM/RR')
                     AND TO_DATE (msap_data1, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                     AND msap_tpmov1 = 'D'
                GROUP BY cgpat_ctadep,
                         cgpat_ctadespdep,
                         pat_noccusto,
                         a.plc_ccusto,
                         b.plc_ccusto,
                         pat_grpatrim,
                         gpat_contabil,
                         msap_data1,
                         pat_cdprojeto
                UNION ALL
                SELECT   DECODE (a.plc_ccusto,
                                 'S', DECODE (b.plc_ccusto,
                                              'N', NULL,
                                              cgpat_ctadep
                                             ),
                                 DECODE (b.plc_ccusto,
                                         'S', cgpat_ctadep,
                                         NULL
                                        )
                                ) AS ctadep,
                         cgpat_ctadespdep AS ctadespdep,
                         DECODE (a.plc_ccusto,
                                 'N', NULL,
                                 pat_noccusto
                                ) AS noccusto,
                         pat_grpatrim AS grpatrim, gpat_contabil AS contabil,
                         msap_data1 AS DATA, 0 AS ttot1,
                         SUM (NVL (msap_vdep1, 0)) AS ttot2,
                         pat_cdprojeto AS projeto
                    FROM patrimon_pat,
                         movsap1_msap,
                         grpatctb_cgpat,
                         grpatrim_gpat,
                         planocta_plc a,
                         planocta_plc b
                   WHERE (ccusto1 IS NULL OR pat_noccusto >= ccusto1)
                     AND (ccusto2 IS NULL OR pat_noccusto <= ccusto2)
                     AND (cdprojeto1 IS NULL OR pat_cdprojeto >= cdprojeto1)
                     AND (cdprojeto2 IS NULL OR pat_cdprojeto <= cdprojeto2)
                     AND (grpat1 IS NULL OR pat_grpatrim >= grpat1)
                     AND (grpat2 IS NULL OR pat_grpatrim <= grpat2)
                     AND pat_cdempresa = codemp
                     AND TO_DATE (pat_dtbaixa, 'DD/MM/RR') IS NULL
                     AND pat_percdep2 > 0
                     AND pat_cdempresa = msap_cdempresa1
                     AND pat_cdpatrimo = msap_cdpatrimo1
                     AND pat_cdanexo = msap_cdanexo1
                     AND pat_grpatrim = gpat_codigo
                     AND gpat_codigo = cgpat_codigo
                     AND pat_cdempresa = cgpat_cdempresa
                     AND b.plc_nocontab = cgpat_ctadep
                     AND b.plc_codplano = cgpat_codplconta
                     AND a.plc_nocontab = cgpat_ctadespdep
                     AND a.plc_codplano = cgpat_codplconta
                     AND TO_DATE (msap_data1, 'DD/MM/RR') >=
                                              TO_DATE (vultdtlct1, 'DD/MM/RR')
                     AND TO_DATE (msap_data1, 'DD/MM/RR') <=
                                                  TO_DATE (dtbase, 'DD/MM/RR')
                     AND msap_tpmov1 = 'D'
                GROUP BY cgpat_ctadep,
                         cgpat_ctadespdep,
                         pat_noccusto,
                         b.plc_ccusto,
                         a.plc_ccusto,
                         pat_grpatrim,
                         gpat_contabil,
                         msap_data1,
                         pat_cdprojeto)
      GROUP BY ctadep, ctadespdep, noccusto, grpatrim, contabil, DATA,
               projeto
      ORDER BY grpatrim, DATA, ctadespdep, ctadep, noccusto, contabil;
   CURSOR pgitem
        -- Pega itens para marcar o numero do lancamento contabil da 1a. moeda
   IS
      SELECT pat_cdpatrimo, pat_cdanexo
        FROM patrimon_pat
       WHERE pat_cdpatrimo >= itemini
         AND pat_cdanexo >= anexini
         AND pat_cdpatrimo <= itemfim
         AND pat_cdanexo <= anexfim
         AND (   TO_DATE (dtaquis1, 'DD/MM/RR') IS NULL
              OR TO_DATE (pat_dtaquis, 'DD/MM/RR') >=
                                                TO_DATE (dtaquis1, 'DD/MM/RR')
             )
         AND (   TO_DATE (dtaquis2, 'DD/MM/RR') IS NULL
              OR TO_DATE (pat_dtaquis, 'DD/MM/RR') <=
                                                TO_DATE (dtaquis2, 'DD/MM/RR')
             )
         AND (vccusto IS NULL OR pat_noccusto = vccusto)
         AND (vgrpatrim IS NULL OR pat_grpatrim = vgrpatrim)
         AND pat_cdempresa = codemp
         AND TO_DATE (pat_dtbaixa, 'DD/MM/RR') IS NULL;
   CURSOR pgitem1
        -- Pega itens para marcar o numero do lancamento contabil da 2a. moeda
   IS
      SELECT pat_cdpatrimo, pat_cdanexo
        FROM patrimon_pat
       WHERE (   TO_DATE (dtaquis1, 'DD/MM/RR') IS NULL
              OR TO_DATE (pat_dtaquis, 'DD/MM/RR') >=
                                                TO_DATE (dtaquis1, 'DD/MM/RR')
             )
         AND (   TO_DATE (dtaquis2, 'DD/MM/RR') IS NULL
              OR TO_DATE (pat_dtaquis, 'DD/MM/RR') <=
                                                TO_DATE (dtaquis2, 'DD/MM/RR')
             )
         AND (vccusto IS NULL OR pat_noccusto = vccusto)
         AND (vgrpatrim IS NULL OR pat_grpatrim = vgrpatrim)
         AND pat_cdempresa = codemp
         AND TO_DATE (pat_dtbaixa, 'DD/MM/RR') IS NULL;
   CURSOR paramdia                          -- Pega dia do lancamento contabil
   IS
      SELECT par_vlparam
        FROM params_par
       WHERE par_cdparam = 'wSAP_DIADEPREC';
   CURSOR paramhist                   -- Pega historico do lancamento contabil
   IS
      SELECT RTRIM (LTRIM (par_vlparam))
        FROM params_par
       WHERE par_cdparam = 'wSAP_HISTDEPRECIACAO';
   CURSOR seguranca
              -- Seguranca para efetuar lancamento da depreciacao na 1a. moeda
   IS
      SELECT msap_cdempresa, msap_cdpatrimo, msap_cdanexo
        FROM movsap_msap
       WHERE msap_cdempresa = codemp
         AND msap_cdpatrimo = vpatrim
         AND msap_cdanexo = vanexo
         AND msap_tpmov = 'D'
         AND TO_CHAR (msap_data, 'DD/MM/RR') = TO_CHAR (vultdata1, 'DD/MM/RR');
   CURSOR seguranca1
              -- Seguranca para efetuar lancamento da depreciacao na 2a. moeda
   IS
      SELECT msap_cdempresa1, msap_cdpatrimo1, msap_cdanexo1
        FROM movsap1_msap
       WHERE msap_cdempresa1 = codemp
         AND msap_cdpatrimo1 = vpatrim
         AND msap_cdanexo1 = vanexo
         AND msap_tpmov1 = 'D'
         AND TO_CHAR (msap_data1, 'DD/MM/RR') =
                                               TO_CHAR (vultdata2, 'DD/MM/RR');
   CURSOR periodolibscb
   IS
      SELECT DATA
      FROM
       (
         SELECT lib_data AS DATA
           FROM liberacao_lib
          WHERE lib_cdempresa = codemp
            AND lib_cdsistema = 'SCB'
            AND TO_CHAR (lib_data, 'DD/MM/RR') = TO_CHAR (vultdata1, 'DD/MM/RR')
         UNION
      SELECT LPG_DATA AS DATA
        FROM LIBPERGRUPO_LPG LPG
           , MXS_PERFILUSUARIO_MXPU MXPU
      WHERE lpg.LPG_EMPRESA = codemp
        AND lpg.LPG_CDSISTEMA = 'SCB'
        AND lpg.LPG_PERFILACESSO = MXPU.MXPU_PERFILACESSO
        AND MXPU.MXPU_USUARIO = get_user_mxm
       AND TO_CHAR (LPG_DATA, 'DD/MM/RR') = TO_CHAR (vultdata1, 'DD/MM/RR')
      );
   CURSOR periodolibsap
   IS
      SELECT lib_data
        FROM liberacao_lib
       WHERE lib_cdempresa = codemp
         AND lib_cdsistema = 'SAP'
         AND TO_CHAR (lib_data, 'DD/MM/RR') = TO_CHAR (vultdata1, 'DD/MM/RR');
BEGIN
   vmvdep := 0;
   vsaldo := 0;
   vultdtlct1 := '';
   vultdtlct2 := '';
   vmoeda := NULL;
   vdiadepr := '';
   vgeroumov := 'N';
   vultitemctb := '';
   -- Verifica 2a. Moeda --------
   SELECT emp_segmoeda
     INTO vmoeda
     FROM emp
    WHERE emp_codigo = codemp;
-------------------------------
-- Pega dia do lancamento da depreciacao ----
   OPEN paramdia;
   FETCH paramdia
    INTO vdiadepr;
   vachou2 := paramdia%FOUND;
   CLOSE paramdia;
---------------------------------------------
-- Verifica "Flag" de controle para depreciar toda a empresa ----
   IF todos = 'N'
   THEN
      OPEN pegaitem;
      FETCH pegaitem
       INTO vcodemp, vpatrim, vanexo, vpridpdt1, vpridpdt2, vultmov1,
            vultmov2, vvalormaxdep1, vvalormaxdep2, vcdprojeto, vgrupopatrimonial,vGrupoPatriProporcional;
      vachou := pegaitem%FOUND;
   ELSE
      OPEN pegaitem1;
      FETCH pegaitem1
       INTO vcodemp, vpatrim, vanexo, vpridpdt1, vpridpdt2, vultmov1,
            vultmov2, vvalormaxdep1, vvalormaxdep2, vcdprojeto, vgrupopatrimonial,vGrupoPatriProporcional;
      vachou := pegaitem1%FOUND;
   END IF;
-----------------------------------------------------------------
   WHILE vachou
   LOOP
      -- Verifica se item ja possui movimento de primeira depreciac?o na 1a. moeda ------
      OPEN jatemmov1;
      FETCH jatemmov1
       INTO vaux;
      vachou1 := jatemmov1%FOUND;
      IF    NOT vachou1
         OR vultmov1 IS NULL
                          -- Se nao achou e nao existe dt. do ultimo movimento
      THEN
         vultmov1 := vpridpdt1;
      END IF;
      vultdata1 := NULL;
-----------------------------------------------------------------------------------
      IF    vachou1                              -- Se ja existir movimento ou
         OR vultmov1 >
               vultdata1
  -- a data e ultimo movimento for maior que a data do movimento a ser lancado
      THEN
         -- Pega a data do novo movimento ---
         OPEN ultdata1;
         FETCH ultdata1
          INTO vultdata1;
         CLOSE ultdata1;
------------------------------------
         IF    (vultmov1 > vultdata1
               )
            -- Se a data do ultimo movimento for maior que a do novo movimento
            OR (vultdata1 IS NULL
               )                -- ou nao existe data para o proximo movimento
         THEN
            BEGIN
               IF    (vultmov1 < dtbase)
                  OR (vultdata1 IS NULL
                     )
-- Se a data o ultimo movimento for menor que data base (suspensao da depreciacao) ou nao existir data do ultimo movimento
               THEN
                  vultdata1 := dtbase;
                            -- A data do proximo movimento recebe a data base
               ELSE
                  vultdata1 := vultmov1;
             -- A data do proximo movimento recebe a data do ultimo movimento
               END IF;
            END;
         END IF;
      END IF;
      CLOSE jatemmov1;
      IF vultdata1 IS NULL                 -- Se o ultimo movimento nao existe
      THEN
         vultdata1 := vultmov1;
      END IF;
      -- Se existe dia de lancamento diferenciado, muda a 1a. vez na entrada do "loop" -----
      IF vachou2
      THEN
         IF     TO_CHAR (vultdata1, 'MM') = '02'   -- Se for mes de fevereiro
            AND (vdiadepr = '29'                             -- e o dia for 29
                 OR vdiadepr = '30'
                )                                                     -- ou 30
         THEN
            vultdata1 := vultdata1;
                                   -- Mantem o ultimo dia do mes como ja esta
         ELSE
            -- Muda o dia do lancamento da depreciacao na 1a. Moeda ---
            vdiadepr := TO_CHAR (LAST_DAY (vultdata1), 'DD');
            vultdata1 :=
               TO_DATE (vdiadepr || '/' || TO_CHAR (vultdata1, 'MM/YYYY'),
                        'DD/MM/YYYY'
                       );
-----------------------------------------------------------
         END IF;
      END IF;
--------------------------------------------------------------------------------------
-- "Loop" de lancamentos de depreciacao na 1a. moeda ---
      WHILE TO_CHAR(dtbase, 'YYYY/MM') >= TO_CHAR(vultdata1, 'YYYY/MM')
            -- Enquanto a database for maior ou igual que a data de lancamento
      LOOP
         -- Verifica se o per�odo est� liberado para movimenta��o patrimonial
         OPEN periodolibsap;
         FETCH periodolibsap
          INTO vdatalibpersap;
         IF NOT periodolibsap%FOUND
         THEN
            raise_application_error
               (-20000,
                   'PER�ODO DE '
                || TO_CHAR (vultdata1, 'DD/MM/RR')
                || ' BLOQUEADO PARA MOVIMENTA��O PATRIMONIAL. FAVOR LIBER�-LO PARA EXECU��O DESTE PROCESSO. - PATRIMONIO: ' || vpatrim
               );
         END IF;
         -- Monta o valor residual atual do item a ser depreciado na 1a. moeda --------
         SELECT NVL (pat_aquis1, 0), NVL (pat_acrbem1, 0),
                NVL (pat_deprec1, 0), NVL (pat_acrdep1, 0),
                NVL (pat_aquis2, 0), pat_grpatrim, pat_noccusto, pat_local,
                pat_responsavel, pat_dtaquis,
                pat_pdep1
           INTO vaquis1, vacrbem1,
                vdeprec1, vacrdep1,
                vaquis2, grpat, vccusto, vlocal,
                vrespons, vdtaquis,
                vdtpdepres1
           FROM patrimon_pat
          WHERE pat_cdempresa = vcodemp
            AND pat_cdpatrimo = vpatrim
            AND pat_cdanexo = vanexo;
         -- Obter taxa de depreciacao e ordem se usado taxa variavel
         prc_depreciacaopatrimonio (vcodemp,
                                    vpatrim,
                                    vanexo,
                                    vpercdep1,
                                    vultimaordemusada
                                   );
------------------------------------------------------------------------------
         -- Verifica se a data de aquisi��o esta dentro do mes da 1� deprecia��o
         IF (  (TO_CHAR (vultdata1, 'MM/YYYY') = TO_CHAR (vdtaquis, 'MM/YYYY'))
           AND (vGrupoPatriProporcional = 'S')
            )
         THEN
         vmvdep :=
              ((((vaquis1 + vacrbem1) - NVL (vvalormaxdep1, '0'))
            * (vpercdep1 / 100 / 12))/ TO_CHAR(LAST_DAY(vdtpdepres1),'DD'))
            * (TO_CHAR(vdtpdepres1, 'DD') - TO_CHAR(vdtaquis, 'DD')); -- Valor proporcional de dias a ser depreciado na 1a. moeda
         ELSE
         vmvdep :=
              ((vaquis1 + vacrbem1) - NVL (vvalormaxdep1, '0'))
            * (vpercdep1 / 100 / 12);   -- Valor a ser depreciado na 1a. moeda
         END IF;
         vsaldo :=
              (vaquis1 + vacrbem1)
            - (vdeprec1 + vacrdep1)
            - NVL (vvalormaxdep1, '0');      -- Saldo do item a ser depreciado
         IF ((vsaldo > 0) AND (vmvdep <> 0)) -- Se o saldo for maior que zero e o valor da deprecia��o for maior que zero.
         THEN
            -- Verica se o item pode ser depreciado -------
            OPEN seguranca;
            FETCH seguranca
             INTO vcodemp, vpatrim, vanexo;
-----------------------------------------------
            IF NOT seguranca%FOUND
                        -- Se nao encontrou nada (item apto a ser depreciado)
            THEN
               IF     vsaldo >
                         vmvdep
                     -- Se o saldo o item for maior que o valor do lancamento
                  AND (vsaldo - vmvdep) >
                                       0.99
                                           -- e a diferenca for maior que 0,99
               THEN
                  -- Efetua lancamento de depreciacao no valor do movimento ---
                  vgeroumov := 'S';
                  -- Carrega a data de lan�amento cont�bil apenas se for gerar movimenta��o para a data de deprecia��o
                  IF    (vultdtlct1 > vultdata1
                        )
      -- S� pode atualizar a data de contabiliza��o caso a data de deprecia��o
                     OR (vultdtlct1 IS NULL
                        )
-- seja menor que a contabilizar j� caregada ou ainda n�o tenha alguma data de contabiliza��o
                  THEN
                     vultdtlct1 := vultdata1;
                     vultitemctb := vpatrim;
                  END IF;
          vdatatmp:=GET_DATA_CORRIGIDA(TO_NUMBER(TO_CHAR(dtbase, 'DD')),TO_NUMBER(TO_CHAR(vultdata1, 'MM')), TO_NUMBER(TO_CHAR(vultdata1, 'RRRR')));
          vseqmovsap := NULL;
                  insmovsap_msap (vcodemp,
                                  vpatrim,
                                  vanexo,
                                 vdatatmp,
                                  'D',
                                  vccusto,
                                  vlocal,
                                  vrespons,
                                  0,
                                  vmvdep,
                                  vpercdep1,
                                  0,
                                  0,
                                  0,
                                  '',
                                  '',
                                  vultimaordemusada
                                  ,vseqmovsap
                                 );
-------------------------------------------------------------
               ELSE
                  -- Efetua lancamento de depreciacao no valor do saldo residual ---
                  vgeroumov := 'S';
                  -- Carrega a data de lan�amento cont�bil apenas se for gerar movimenta��o para a data de deprecia��o
                  IF    (vultdtlct1 > vultdata1
                        )
      -- S� pode atualizar a data de contabiliza��o caso a data de deprecia��o
                     OR (vultdtlct1 IS NULL
                        )
-- seja menor que a contabilizar j� caregada ou ainda n�o tenha alguma data de contabiliza��o
                  THEN
                     vultdtlct1 := vultdata1;
                  END IF;
          vdatatmp:=GET_DATA_CORRIGIDA(TO_NUMBER(TO_CHAR(dtbase, 'DD')),TO_NUMBER(TO_CHAR(vultdata1, 'MM')), TO_NUMBER(TO_CHAR(vultdata1, 'RRRR')));
          vseqmovsap := null;
                  insmovsap_msap (vcodemp,
                                  vpatrim,
                                  vanexo,
                                  vdatatmp,
                                  'D',
                                  vccusto,
                                  vlocal,
                                  vrespons,
                                  0,
                                  vsaldo,
                                  vpercdep1,
                                  0,
                                  0,
                                  0,
                                  '',
                                  '',
                                  vultimaordemusada,
                                  vseqmovsap
                                 );
------------------------------------------------------------------
               END IF;
            END IF;
            CLOSE seguranca;
         END IF;
         IF vsaldo > 0                -- Se o saldo do item for maior que zero
         THEN
            -- Pega proxima provavel data de lancamento do item --
            OPEN ultdata1;
            FETCH ultdata1
             INTO vultdata1;
            CLOSE ultdata1;
------------------------------------------------------
            IF vachou2            -- Se existe dia de lancamento diferenciado
            THEN
               IF     (TO_CHAR (vultdata1, 'MM') = '02'
                      )                             -- Se for mes de fevereiro
                  AND (vdiadepr = '29'                       -- e o dia for 29
                       OR vdiadepr = '30'
                      )                                               -- ou 30
               THEN
                  vultdata1 := vultdata1;
                                   -- Mantem o ultimo dia do mes como ja esta
               ELSE
                  -- Muda o dia do lancamento da depreciacao na 1a. Moeda ---
                  vdiadepr := TO_CHAR (LAST_DAY (vultdata1), 'DD');
                  vultdata1 :=
                     TO_DATE (vdiadepr || '/'
                              || TO_CHAR (vultdata1, 'MM/YYYY'),
                              'DD/MM/YYYY'
                             );
               END IF;
               IF     (TO_CHAR (vultdtlct1, 'MM') = '02')
                  AND (vdiadepr = '29' OR vdiadepr = '30')
               THEN
                  vultdtlct1 := vultdtlct1;
               ELSE
                  -- Muda o dia do lancamento contabil na 2a. Moeda ---------
                  vdiadepr := TO_CHAR (LAST_DAY (vultdtlct1), 'DD');
                  vultdtlct1 :=
                     TO_DATE (vdiadepr || '/'
                              || TO_CHAR (vultdtlct1, 'MM/YYYY'),
                              'DD/MM/YYYY'
                             );
-----------------------------------------------------------
               END IF;
            END IF;
         ELSE
            vultdata1 := dtbase + 1;
                        -- Forca a saida o "loop" de lancamentos na 1a. moeda
         END IF;
         CLOSE periodolibsap;
      END LOOP;
      IF    NOT vmoeda IS NULL                     -- Se existir segunda moeda
         OR (vaquis2 <> 0 AND NOT vaquis2 IS NULL
            )
    -- ou valor da aquisicao na 2a. moeda nao for diferente de zero e nao nulo
      THEN
         -- Verifica se item ja possui movimento de primeira depreciac?o na 2a. moeda ------
         OPEN jatemmov2;
         FETCH jatemmov2
          INTO vaux;
         vachou1 := jatemmov2%FOUND;
         IF    NOT vachou1
            OR vultmov2 IS NULL
                          -- Se nao achou e nao existe dt. do ultimo movimento
         THEN
            vultmov2 := vpridpdt2;
         END IF;
         vultdata2 := NULL;
-----------------------------------------------------------------------------------
         IF    vachou1                           -- Se ja existir movimento ou
            OR vultmov2 >
                  vultdata2
  -- a data e ultimo movimento for maior que a data do movimento a ser lancado
         THEN
            -- Pega a data do novo movimento ---
            OPEN ultdata2;
            FETCH ultdata2
             INTO vultdata2;
            CLOSE ultdata2;
------------------------------------
            IF    (vultmov2 > vultdata2
                  )
            -- Se a data do ultimo movimento for maior que a do novo movimento
               OR (vultdata2 IS NULL
                  )             -- ou nao existe data para o proximo movimento
            THEN
               BEGIN
                  IF    (vultmov2 < dtbase)
                     OR (vultdata2 IS NULL
                        )
-- Se a data o ultimo movimento for menor que data base (suspensao da depreciacao)
                  THEN
                     vultdata2 := dtbase;
                            -- A data do proximo movimento recebe a data base
                  ELSE
                     vultdata2 := vultmov2;
             -- A data do proximo movimento recebe a data do ultimo movimento
                  END IF;
               END;
            END IF;
         END IF;
         CLOSE jatemmov2;
         IF vultdata2 IS NULL              -- Se o ultimo movimento nao existe
         THEN
            vultdata2 := vultmov2;
         END IF;
         vultdtlct2 := vultdata2;
                           -- Inicializa data de lancamento contabil 2a. moeda
         -- Se existe dia de lancamento diferenciado, muda a 1a. vez na entrada do "loop" -----
         IF vachou2
         THEN
            IF     TO_CHAR (vultdata2, 'MM') = '02'
                                                   -- Se for mes de fevereiro
               AND (vdiadepr = '29'                          -- e o dia for 29
                    OR vdiadepr = '30'
                   )                                                  -- ou 30
            THEN
               vultdata2 := vultdata2;
                                   -- Mantem o ultimo dia do mes como ja esta
            ELSE
               -- Muda o dia do lancamento da depreciacao na 1a. Moeda ---
               IF vultdata2 IS NOT NULL
               THEN
                  vdiadepr := TO_CHAR (LAST_DAY (vultdata2), 'DD');
                  vultdata2 :=
                     TO_DATE (vdiadepr || '/'
                              || TO_CHAR (vultdata2, 'MM/YYYY'),
                              'DD/MM/YYYY'
                             );
               END IF;
-----------------------------------------------------------
            END IF;
         END IF;
--------------------------------------------------------------------------------------
-- "Loop" de lancamentos de depreciacao na 2a. moeda ---
         WHILE TO_CHAR(dtbase, 'YYYY/MM') >= TO_CHAR(vultdata2, 'YYYY/MM')
                     -- Enquanto a database for maior que a data de lancamento
         LOOP
            -- Monta o valor residual atual do item a ser depreciado na 2a. moeda --------
            SELECT NVL (pat_aquis2, 0), NVL (pat_acrbem2, 0),
                   NVL (pat_deprec2, 0), NVL (pat_acrdep2, 0),
                   NVL (pat_percdep2, 0), pat_grpatrim, pat_noccusto,
                   pat_local, pat_responsavel,pat_dtaquis,
                   pat_pdep2
              INTO vaquis2, vacrbem2,
                   vdeprec2, vacrdep2,
                   vpercdep2, grpat, vccusto,
                   vlocal, vrespons, vdtaquis,
                   vdtpdepres2
              FROM patrimon_pat
             WHERE pat_cdempresa = vcodemp
               AND pat_cdpatrimo = vpatrim
               AND pat_cdanexo = vanexo;
------------------------------------------------------------------------------
         -- Verifica se a data de aquisi��o esta dentro do mes da 1� deprecia��o
            IF ( (TO_CHAR (vultdata2, 'MM/YYYY') = TO_CHAR (vdtpdepres2, 'MM/YYYY'))
             AND (vGrupoPatriProporcional = 'S')
               )
            THEN
            vmvdep :=
                (((vaquis2 + vacrbem2) * (vpercdep2 / 100 / 12))/ TO_CHAR(LAST_DAY(vdtpdepres2),'DD'))
              * (TO_CHAR(vdtpdepres2, 'DD') - TO_CHAR(vdtaquis, 'DD'));
                                        -- Valor proporcional de dias a ser depreciado na 2a. moeda
            ELSE
            vmvdep := (vaquis2 + vacrbem2) * (vpercdep2 / 100 / 12);
                                        -- Valor a ser depreciado na 2a. moeda
            END IF;
            vsaldo :=
                 (vaquis2 + vacrbem2)
               - (vdeprec2 + vacrdep2)
               - NVL (vvalormaxdep2, '0');   -- Saldo do item a ser depreciado
            IF ((vsaldo > 0) AND (vmvdep <> 0)) -- Se o saldo for maior que zero e o valor da deprecia��o for maior que zero.
            THEN
               -- Verica se o item pode ser depreciado -------
               OPEN seguranca1;
               FETCH seguranca1
                INTO vcodemp, vpatrim, vanexo;
-----------------------------------------------
               IF NOT seguranca1%FOUND
                        -- Se nao encontrou nada (item apto a ser depreciado)
               THEN
                  IF vultdtlct2 IS NULL
             -- Se a 1a. data de lancamento contabil nao estiver inicializada
                  THEN
                     vultdtlct2 := vultdata2;
            -- 1a. data de lancamento contabil recebe a data do 1o. movimento
                  END IF;
                  IF     vsaldo >
                            vmvdep
                      -- Se o saldo o item for maior que o valor do lancamento
                     AND (vsaldo - vmvdep) >
                                       0.99
                                           -- e a diferenca for maior que 0,99
                  THEN
                     -- Efetua lancamento de depreciacao no valor do movimento ---
                     vgeroumov := 'S';
                     -- Carrega a data de lan�amento cont�bil apenas se for gerar movimenta��o para a data de deprecia��o
                     IF    (vultdtlct1 > vultdata1
                           )
      -- S� pode atualizar a data de contabiliza��o caso a data de deprecia��o
                        OR (vultdtlct1 IS NULL
                           )
-- seja menor que a contabilizar j� caregada ou ainda n�o tenha alguma data de contabiliza��o
                     THEN
                        vultdtlct1 := vultdata1;
                     END IF;
           vdatatmp:=GET_DATA_CORRIGIDA(TO_NUMBER(TO_CHAR(dtbase, 'DD')),TO_NUMBER(TO_CHAR(vultdata2, 'MM')), TO_NUMBER(TO_CHAR(vultdata2, 'RRRR')));
           vseqmovsap1 := NULL;
                     insmovsap1_msap (vcodemp,
                                      vpatrim,
                                      vanexo,
                                      vdatatmp,
                                      'D',
                                      vccusto,
                                      vlocal,
                                      vrespons,
                                      0,
                                      vmvdep,
                                      vpercdep2,
                                      0,
                                      0,
                                      0,
                                      '',
                                      '',
                                      vseqmovsap1
                                     );
-------------------------------------------------------------
                  ELSE
                     -- Efetua lancamento de depreciacao no valor do saldo residual ---
                     vgeroumov := 'S';
                     -- Carrega a data de lan�amento cont�bil apenas se for gerar movimenta��o para a data de deprecia��o
                     IF    (vultdtlct1 > vultdata1
                           )
      -- S� pode atualizar a data de contabiliza��o caso a data de deprecia��o
                        OR (vultdtlct1 IS NULL
                           )
-- seja menor que a contabilizar j� caregada ou ainda n�o tenha alguma data de contabiliza��o
                     THEN
                        vultdtlct1 := vultdata1;
                     END IF;
           vdatatmp:=GET_DATA_CORRIGIDA(TO_NUMBER(TO_CHAR(dtbase, 'DD')),TO_NUMBER(TO_CHAR(vultdata2, 'MM')), TO_NUMBER(TO_CHAR(vultdata2, 'RRRR')));
           vseqmovsap1 := NULL;
                     insmovsap1_msap (vcodemp,
                                      vpatrim,
                                      vanexo,
                                      vdatatmp,
                                      'D',
                                      vccusto,
                                      vlocal,
                                      vrespons,
                                      0,
                                      vsaldo,
                                      vpercdep2,
                                      0,
                                      0,
                                      0,
                                      '',
                                      '',
                                      vseqmovsap1
                                     );
-------------------------------------------------------------
                  END IF;
               END IF;
               CLOSE seguranca1;
            END IF;
            IF vsaldo > 0             -- Se o saldo do item for maior que zero
            THEN
               -- Pega proxima provavel data de lancamento do item --
               OPEN ultdata2;
               FETCH ultdata2
                INTO vultdata2;
               CLOSE ultdata2;
------------------------------------------------------
               IF vachou2         -- Se existe dia de lancamento diferenciado
               THEN
                  IF     TO_CHAR (vultdata2, 'MM') =
                                               '02'
                                                   -- Se for mes de fevereiro
                     AND (vdiadepr = '29'                    -- e o dia for 29
                          OR vdiadepr = '30'
                         )                                            -- ou 30
                  THEN
                     vultdata2 := vultdata2;
                                   -- Mantem o ultimo dia do mes como ja esta
                  ELSE
                     -- Muda o dia do lancamento da depreciacao na 1a. Moeda ---
                     IF vultdata2 IS NOT NULL
                     THEN
                        vdiadepr := TO_CHAR (LAST_DAY (vultdata2), 'DD');
                        vultdata2 :=
                           TO_DATE (   vdiadepr
                                    || '/'
                                    || TO_CHAR (vultdata2, 'MM/YYYY'),
                                    'DD/MM/YYYY'
                                   );
-----------------------------------------------------------
                     END IF;
                  END IF;
                  IF     (TO_CHAR (vultdtlct2, 'mm') = '02')
                     AND (vdiadepr = '29' OR vdiadepr = '30')
                  THEN
                     vultdtlct2 := vultdtlct2;
                  ELSE
                     -- Muda o dia do lancamento contabil na 2a. Moeda ---------
                     IF vultdata2 IS NOT NULL
                     THEN
                        vdiadepr := TO_CHAR (LAST_DAY (vultdtlct2), 'DD');
                        vultdtlct2 :=
                           TO_DATE (   vdiadepr
                                    || '/'
                                    || TO_CHAR (vultdtlct2, 'MM/YYYY'),
                                    'DD/MM/YYYY'
                                   );
-----------------------------------------------------------
                     END IF;
                  END IF;
               END IF;
            ELSE
               vultdata2 := dtbase + 1;
                        -- Forca a saida o "loop" de lancamentos na 2a. moeda
            END IF;
         END LOOP;
      END IF;
      -- Verifica "Flag" de controle para depreciar toda a empresa, e pegar item seguinte ----
      IF todos = 'N'
      THEN
         FETCH pegaitem
          INTO vcodemp, vpatrim, vanexo, vpridpdt1, vpridpdt2, vultmov1,
               vultmov2, vvalormaxdep1, vvalormaxdep2, vcdprojeto, vgrupopatrimonial,vGrupoPatriProporcional;
         vachou := pegaitem%FOUND;
      ELSE
         FETCH pegaitem1
          INTO vcodemp, vpatrim, vanexo, vpridpdt1, vpridpdt2, vultmov1,
               vultmov2, vvalormaxdep1, vvalormaxdep2, vcdprojeto, vgrupopatrimonial,vGrupoPatriProporcional;
         vachou := pegaitem1%FOUND;
      END IF;
   END LOOP;
   IF todos = 'N'
   THEN
      CLOSE pegaitem;
   ELSE
      CLOSE pegaitem1;
   END IF;
   -- Gera lancamentos contabeis
   IF contabil = 'S' AND NOT vultdtlct1 IS NULL AND vgeroumov = 'S'
   THEN
      IF vultdtlct1 > dtbase
      THEN
         vultdtlct1 := dtbase;
      END IF;
      IF todos = 'N'
      THEN
         OPEN lancamento;
         FETCH lancamento
          INTO vctadep, vdespdep, vccusto, vgrpatrim, vgrcont, vultdata1,
               vtotdep, vtotdep1, vcdprojeto;
         vachou := lancamento%FOUND;
      ELSE
         OPEN lancamentoa;
         FETCH lancamentoa
          INTO vctadep, vdespdep, vccusto, vgrpatrim, vgrcont, vultdata1,
               vtotdep, vtotdep1, vcdprojeto;
         vachou := lancamentoa%FOUND;
      END IF;
      SELECT DECODE (SUM (NVL (pat_deprec2, 0)), 0, 'N', 'S')
        INTO amtmoeda
        FROM patrimon_pat
       WHERE pat_grpatrim = vgrpatrim;
      IF NOT vachou
      THEN
         IF vgrcont = 'S' OR vgrcont IS NULL
         THEN
            raise_application_error
               (-20000,
                   'NAO FORAM ENCONTRADAS CONTAS PARA CONTABILIZACAO DA DEPRECIACAO DA EMPRESA '
                || codemp
                || ' ITEM PATRIMONIAL DO GRUPO '
                || vgrupopatrimonial
               );
         END IF;
      END IF;
      WHILE vachou
      LOOP
         SELECT LTRIM (TO_CHAR (TO_NUMBER (par_vlparam) + 1, '000000'))
           INTO lancto
           FROM params_par
          WHERE par_cdparam = 'wPAR_NAUTOLANC';
         UPDATE params_par
            SET par_vlparam = lancto
          WHERE par_cdparam = 'wPAR_NAUTOLANC';
         lote := 'SAP_DP';
         historico := '';
         OPEN paramhist;
         FETCH paramhist
          INTO vhistorico;
         CLOSE paramhist;
         IF (vhistorico = '') OR (vhistorico IS NULL)
         THEN
            vhistorico := 'DEPRECIACAO/AMORTIZACAO @D DO GRUPO @G';
         END IF;
         FOR a IN 1 .. LENGTH (vhistorico)
         LOOP
            IF SUBSTR (vhistorico, a, 1) = '@'
            THEN
               IF SUBSTR (vhistorico, a, 2) = '@D'
               THEN
                  historico := historico || TO_CHAR (vultdata1, 'MM/YYYY');
               END IF;
               IF SUBSTR (vhistorico, a, 2) = '@G'
               THEN
                  historico := historico || vgrpatrim;
               END IF;
            ELSE
               IF a > 1
               THEN
                  IF SUBSTR (vhistorico, a - 1, 1) <> '@'
                  THEN
                     historico := historico || SUBSTR (vhistorico, a, 1);
                  END IF;
               ELSE
                  historico := historico || SUBSTR (vhistorico, a, 1);
               END IF;
            END IF;
         END LOOP;
         OPEN periodolibscb;
         FETCH periodolibscb
          INTO vdatalibper;
         IF NOT periodolibscb%FOUND
         THEN
            raise_application_error
               (-20000,
                   'PER�ODO DE '
                || TO_CHAR (vultdata1, 'DD/MM/RR')
                || ' BLOQUEADO PARA CONTABILIZA��O. FAVOR LIBER�-LO PARA EXECU��O DESTE PROCESSO. Conta: ' || vctadep || '| Centro de Custo: ' ||vccusto ||' | Valor: ' || vtotdep ||' Patrim�nio: (' ||vultitemctb||')'
               );
         END IF;
         IF periodolibscb%FOUND AND vgrcont = 'S'
         THEN
            IF    (vctadep IS NOT NULL AND vdespdep IS NOT NULL)
               OR (vctadep IS NULL AND vdespdep IS NULL)
            THEN
               vstaccusto := validccust (codemp, codplan, vctadep, vccusto);
               IF vstaccusto >= 1
               THEN
                  IF vstaccusto =
                        2
                        -- nao pode ter centro de custo, assim limpo o mesmo.
                  THEN
                     accusto := '';
                  ELSE
                     accusto := vccusto;
                  END IF;
                  IF vtotdep1 = 0 AND amtmoeda = 'N'
                  THEN
                     vmoedal := '';
                  ELSE
                     vmoedal := vmoeda;
                  END IF;
                  inslancctb_lct (codemp,
                                  lote,
                                  vultdata1,
                                  LTRIM (lancto),
                                  '1',
                                  vctadep,
                                  accusto,
                                  historico,
                                  'C',
                                  ABS (vtotdep),
                                  ABS (vtotdep1),
                                  '',
                                  vmoedal,
                                  '',
                                  '',
                                  vcdprojeto
                                 );
               --Se o resultado do valida centro de custo for 0 ou -1 ou -2
               ELSE
                  IF vstaccusto = -2
                  THEN
                     raise_application_error
                                      (-20000,
                                          'CENTRO DE CUSTO '
                                       || vccusto
                                       || ' INATIVO PARA GERAR CONTABILIZAC?O. '
                                      );
                  ELSE
                     IF vstaccusto < 0 OR vccusto IS NULL
                     THEN
                        raise_application_error
                           (-20000,
                            'CENTRO DE CUSTO OBRIGATORIO PARA CONTABILIZAR O(S) PATRIMONIO(S) INFORMADO(S). '
                           );
                     ELSE
                        raise_application_error (-20000,
                                                    'CENTRO DE CUSTO '
                                                 || vccusto
                                                 || ' INVALIDO PARA CONTA '
                                                 || vctadep
                                                 || '.'
                                                );
                     END IF;
                  END IF;
               END IF;
               vstaccusto := validccust (codemp, codplan, vdespdep, vccusto);
               IF vstaccusto >= 1
               THEN
                  IF vstaccusto =
                        2
                        -- nao pode ter centro de custo, assim limpo o mesmo.
                  THEN
                     accusto := '';
                  ELSE
                     accusto := vccusto;
                  END IF;
                  IF vtotdep1 = 0 AND amtmoeda = 'N'
                  THEN
                     vmoedal := '';
                  ELSE
                     vmoedal := vmoeda;
                  END IF;
                  inslancctb_lct (codemp,
                                  lote,
                                  vultdata1,
                                  LTRIM (lancto),
                                  '2',
                                  vdespdep,
                                  accusto,
                                  historico,
                                  'D',
                                  ABS (vtotdep),
                                  ABS (vtotdep1),
                                  '',
                                  vmoedal,
                                  '',
                                  '',
                                  vcdprojeto
                                 );
               ELSE
                  IF vstaccusto = -2
                  THEN
                     raise_application_error
                                      (-20000,
                                          'CENTRO DE CUSTO '
                                       || vccusto
                                       || ' INATIVO PARA GERAR CONTABILIZAC?O. '
                                      );
                  ELSE
                     IF vstaccusto < 0 OR vccusto IS NULL
                     THEN
                        raise_application_error
                           (-20000,
                            'CENTRO DE CUSTO OBRIGATORIO PARA CONTABILIZAR O(S) PATRIMONIO(S) INFORMADO(S). ' || vpatrim
                           );
                     ELSE
                        raise_application_error (-20000,
                                                    'CENTRO DE CUSTO '
                                                 || vccusto
                                                 || ' INVALIDO PARA CONTA '
                                                 || vdespdep
                                                 || '.'
                                                );
                     END IF;
                  END IF;
               END IF;
               IF todos = 'N'
               THEN
                  OPEN pgitem;
                  FETCH pgitem
                   INTO vpatrim, vanexo;
                  vachou2 := pgitem%FOUND;
               ELSE
                  OPEN pgitem1;
                  FETCH pgitem1
                   INTO vpatrim, vanexo;
                  vachou2 := pgitem1%FOUND;
               END IF;
               WHILE vachou2 AND vgrcont = 'S'
               LOOP
                  UPDATE movsap_msap
                     SET msap_lancctb = lancto
                   WHERE msap_cdpatrimo = vpatrim
                     AND msap_cdanexo = vanexo
                     AND (vccusto IS NULL OR msap_ccusto = vccusto)
                     AND msap_cdempresa = codemp
                     AND msap_tpmov = 'D'
                     AND TO_DATE (msap_data, 'DD/MM/RR') =
                                               TO_DATE (vultdata1, 'DD/MM/RR');
                  IF todos = 'N'
                  THEN
                     FETCH pgitem
                      INTO vpatrim, vanexo;
                     vachou2 := pgitem%FOUND;
                  ELSE
                     FETCH pgitem1
                      INTO vpatrim, vanexo;
                     vachou2 := pgitem1%FOUND;
                  END IF;
               END LOOP;
               IF todos = 'N'
               THEN
                  CLOSE pgitem;
               ELSE
                  CLOSE pgitem1;
               END IF;
               IF todos = 'N'
               THEN
                  FETCH lancamento
                   INTO vctadep, vdespdep, vccusto, vgrpatrim, vgrcont,
                        vultdata1, vtotdep, vtotdep1, vcdprojeto;
                  vachou := lancamento%FOUND;
               ELSE
                  FETCH lancamentoa
                   INTO vctadep, vdespdep, vccusto, vgrpatrim, vgrcont,
                        vultdata1, vtotdep, vtotdep1, vcdprojeto;
                  vachou := lancamentoa%FOUND;
               END IF;
            ELSE
               /* ------------------------------------------------------------
                   Contas que nao permitem centro de custo
               ------------------------------------------------------------  */
               vsequencial := 1;
               IF vctadep IS NULL AND vdespdep IS NOT NULL
               THEN
                  WHILE vachou AND vdespdep IS NOT NULL AND vctadep IS NULL
                  LOOP
                     vstaccusto :=
                              validccust (codemp, codplan, vdespdep, vccusto);
                     IF vstaccusto >= 1
                     THEN
                        IF vstaccusto =
                              2
                        -- nao pode ter centro de custo, assim limpo o mesmo.
                        THEN
                           accusto := '';
                        ELSE
                           accusto := vccusto;
                        END IF;
                        IF vtotdep1 = 0 AND amtmoeda = 'N'
                        THEN
                           vmoedal := '';
                        ELSE
                           vmoedal := vmoeda;
                        END IF;
                        inslancctb_lct (codemp,
                                        lote,
                                        vultdata1,
                                        LTRIM (lancto),
                                        TO_CHAR (vsequencial),
                                        vdespdep,
                                        accusto,
                                        historico,
                                        'D',
                                        ABS (vtotdep),
                                        ABS (vtotdep1),
                                        '',
                                        vmoedal,
                                        '',
                                        '',
                                        vcdprojeto
                                       );
                     ELSE
                        IF vstaccusto = -2
                        THEN
                           raise_application_error
                                      (-20000,
                                          'CENTRO DE CUSTO '
                                       || vccusto
                                       || ' INATIVO PARA GERAR CONTABILIZAC?O. '
                                      );
                        ELSE
                           IF vstaccusto < 0 OR vccusto IS NULL
                           THEN
                              raise_application_error
                                 (-20000,
                                  'CENTRO DE CUSTO OBRIGATORIO PARA CONTABILIZAR O(S) PATRIMONIO(S) INFORMADO(S). '
                                 );
                           ELSE
                              raise_application_error
                                                  (-20000,
                                                      'CENTRO DE CUSTO '
                                                   || vccusto
                                                   || ' INVALIDO PARA CONTA '
                                                   || vdespdep
                                                   || '.'
                                                  );
                           END IF;
                        END IF;
                     END IF;
                     vsequencial := vsequencial + 1;
                     IF todos = 'N'
                     THEN
                        OPEN pgitem;
                        FETCH pgitem
                         INTO vpatrim, vanexo;
                        vachou2 := pgitem%FOUND;
                     ELSE
                        OPEN pgitem1;
                        FETCH pgitem1
                         INTO vpatrim, vanexo;
                        vachou2 := pgitem1%FOUND;
                     END IF;
                     WHILE vachou2 AND vgrcont = 'S'
                     LOOP
                        UPDATE movsap_msap
                           SET msap_lancctb = lancto
                         WHERE msap_cdpatrimo = vpatrim
                           AND msap_cdanexo = vanexo
                           AND (vccusto IS NULL OR msap_ccusto = vccusto)
                           AND msap_cdempresa = codemp
                           AND msap_tpmov = 'D'
                           AND TO_DATE (msap_data, 'DD/MM/RR') =
                                               TO_DATE (vultdata1, 'DD/MM/RR');
                        IF todos = 'N'
                        THEN
                           FETCH pgitem
                            INTO vpatrim, vanexo;
                           vachou2 := pgitem%FOUND;
                        ELSE
                           FETCH pgitem1
                            INTO vpatrim, vanexo;
                           vachou2 := pgitem1%FOUND;
                        END IF;
                     END LOOP;
                     IF todos = 'N'
                     THEN
                        CLOSE pgitem;
                    ELSE
                        CLOSE pgitem1;
                     END IF;
                     IF todos = 'N'
                     THEN
                        FETCH lancamento
                         INTO vctadep, vdespdep, vccusto, vgrpatrim, vgrcont,
                              vultdata1, vtotdep, vtotdep1, vcdprojeto;
                        vachou := lancamento%FOUND;
                     ELSE
                        FETCH lancamentoa
                         INTO vctadep, vdespdep, vccusto, vgrpatrim, vgrcont,
                              vultdata1, vtotdep, vtotdep1, vcdprojeto;
                        vachou := lancamentoa%FOUND;
                     END IF;
                  END LOOP;
               END IF;
               IF vctadep IS NOT NULL AND vdespdep IS NULL
               THEN
                  WHILE vachou AND vctadep IS NOT NULL AND vdespdep IS NULL
                  LOOP
                     vstaccusto :=
                               validccust (codemp, codplan, vctadep, vccusto);
                     IF vstaccusto >= 1
                     THEN
                        IF vstaccusto =
                              2
                        -- nao pode ter centro de custo, assim limpo o mesmo.
                        THEN
                           accusto := '';
                        ELSE
                           accusto := vccusto;
                        END IF;
                        IF vtotdep1 = 0 AND amtmoeda = 'N'
                        THEN
                           vmoedal := '';
                        ELSE
                           vmoedal := vmoeda;
                        END IF;
                        inslancctb_lct (codemp,
                                        lote,
                                        vultdata1,
                                        LTRIM (lancto),
                                        TO_CHAR (vsequencial),
                                        vctadep,
                                        accusto,
                                        historico,
                                        'C',
                                        ABS (vtotdep),
                                        ABS (vtotdep1),
                                        '',
                                        vmoedal,
                                        '',
                                        '',
                                        vcdprojeto
                                       );
                     ELSE
                        IF vstaccusto = -2
                        THEN
                           raise_application_error
                                      (-20000,
                                          'CENTRO DE CUSTO '
                                       || vccusto
                                       || ' INATIVO PARA GERAR CONTABILIZAC?O. '
                                      );
                        ELSE
                           IF vstaccusto < 0 OR vccusto IS NULL
                           THEN
                              raise_application_error
                                 (-20000,
                                  'CENTRO DE CUSTO OBRIGATORIO PARA CONTABILIZAR O(S) PATRIMONIO(S) INFORMADO(S). '
                                 );
                           ELSE
                              raise_application_error
                                                  (-20000,
                                                      'CENTRO DE CUSTO '
                                                   || vccusto
                                                   || ' INVALIDO PARA CONTA '
                                                   || vctadep
                                                   || '.'
                                                  );
                           END IF;
                        END IF;
                     END IF;
                     vsequencial := vsequencial + 1;
                     IF todos = 'N'
                     THEN
                        OPEN pgitem;
                        FETCH pgitem
                         INTO vpatrim, vanexo;
                        vachou2 := pgitem%FOUND;
                     ELSE
                        OPEN pgitem1;
                        FETCH pgitem1
                         INTO vpatrim, vanexo;
                        vachou2 := pgitem1%FOUND;
                     END IF;
                     WHILE vachou2 AND vgrcont = 'S'
                     LOOP
                        UPDATE movsap_msap
                           SET msap_lancctb = lancto
                         WHERE msap_cdpatrimo = vpatrim
                           AND msap_cdanexo = vanexo
                           AND (vccusto IS NULL OR msap_ccusto = vccusto)
                           AND msap_cdempresa = codemp
                           AND msap_tpmov = 'D'
                           AND msap_data = vultdata1;
                        IF todos = 'N'
                        THEN
                           FETCH pgitem
                            INTO vpatrim, vanexo;
                           vachou2 := pgitem%FOUND;
                        ELSE
                           FETCH pgitem1
                            INTO vpatrim, vanexo;
                           vachou2 := pgitem1%FOUND;
                        END IF;
                     END LOOP;
                     IF todos = 'N'
                     THEN
                        CLOSE pgitem;
                     ELSE
                        CLOSE pgitem1;
                     END IF;
                     IF todos = 'N'
                     THEN
                        FETCH lancamento
                         INTO vctadep, vdespdep, vccusto, vgrpatrim, vgrcont,
                              vultdata1, vtotdep, vtotdep1, vcdprojeto;
                        vachou := lancamento%FOUND;
                     ELSE
                        FETCH lancamentoa
                         INTO vctadep, vdespdep, vccusto, vgrpatrim, vgrcont,
                              vultdata1, vtotdep, vtotdep1, vcdprojeto;
                        vachou := lancamentoa%FOUND;
                     END IF;
                  END LOOP;
               END IF;
            END IF;
         ELSE
            IF todos = 'N'
            THEN
               FETCH lancamento
                INTO vctadep, vdespdep, vccusto, vgrpatrim, vgrcont,
                     vultdata1, vtotdep, vtotdep1, vcdprojeto;
               vachou := lancamento%FOUND;
            ELSE
               FETCH lancamentoa
                INTO vctadep, vdespdep, vccusto, vgrpatrim, vgrcont,
                     vultdata1, vtotdep, vtotdep1, vcdprojeto;
               vachou := lancamentoa%FOUND;
            END IF;
         END IF;
         CLOSE periodolibscb;
      END LOOP;
      IF todos = 'N'
      THEN
         CLOSE lancamento;
      ELSE
         CLOSE lancamentoa;
      END IF;
   END IF;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 271158
PROMPT ======================================================================