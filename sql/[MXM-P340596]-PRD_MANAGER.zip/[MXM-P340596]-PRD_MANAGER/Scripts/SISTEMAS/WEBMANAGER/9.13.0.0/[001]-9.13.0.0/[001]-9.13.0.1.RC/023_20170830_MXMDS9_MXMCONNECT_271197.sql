PROMPT ======================================================================
PROMPT == DEMANDA......: 271197
PROMPT == SISTEMA......: MXM CONNECT
PROMPT == RESPONSAVEL..: LUIS FELIPE CORTES FELGUEIRAS
PROMPT == DATA.........: 17/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE CNTMEUSLINKS_MLK DROP CONSTRAINT FK1_CNTMEUSLINKS_MLK
/

ALTER TABLE CNTMEUSLINKS_MLK
ADD CONSTRAINT FK1_CNTMEUSLINKS_MLK
    FOREIGN KEY (MLK_CDUSUARIO)
    REFERENCES CNTUSUARIO_USU (USU_IDUSUARIO)
    ON DELETE CASCADE
    NOVALIDATE
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 271197
PROMPT ======================================================================