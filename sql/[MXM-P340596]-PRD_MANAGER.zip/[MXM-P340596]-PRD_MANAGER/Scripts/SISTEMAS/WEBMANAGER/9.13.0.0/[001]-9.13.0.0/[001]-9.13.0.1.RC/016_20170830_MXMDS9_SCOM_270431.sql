PROMPT ======================================================================
PROMPT == DEMANDA......: 270431
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 10/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRETABELARELVISAL_TRV
   SET TRV_NMCONDICAOTABREL = 'FORCTB_FTB.FTB_CODFOR = FGPAGIR_FGI.FGI_CODFOR(+) AND FORCTB_FTB.FTB_CODPLCONTA = FGPAGIR_FGI.FGI_CODEMP(+) AND NVL(FORCTB_FTB.FTB_CODFILIAL,''*'') = NVL(FGPAGIR_FGI.FGI_CODFILIAL,''*'') AND NVL(FORCTB_FTB.FTB_CODMOEDA,''*'') = NVL(FGPAGIR_FGI.FGI_CODMOEDA,''*'')'
 WHERE TRV_NRVISAO = 236
   AND TRV_NRTABELA = 28
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 270431
PROMPT ======================================================================