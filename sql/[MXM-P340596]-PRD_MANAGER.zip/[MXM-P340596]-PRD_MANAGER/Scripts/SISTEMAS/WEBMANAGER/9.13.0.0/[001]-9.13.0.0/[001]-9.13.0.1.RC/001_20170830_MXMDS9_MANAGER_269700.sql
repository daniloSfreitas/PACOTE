PROMPT ======================================================================
PROMPT == DEMANDA......: 269700
PROMPT == SISTEMA......: MANAGER
PROMPT == RESPONSAVEL..: JULIANO MENEZES
PROMPT == DATA.........: 26/04/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE TABLE TINARQCLIPARPART_CPPA
(
  CPPA_IDPARPART         NUMBER,
  CPPA_IDPROCESSO        NUMBER,
  CPPA_IDREGISTRO        NUMBER,
  CPPA_NRINSCESTST       VARCHAR2(20),
  CPPA_NRCEI             VARCHAR2(12),
  CPPA_NRNIT             VARCHAR2(11),
  CPPA_NRINDNATRET       VARCHAR2(2),
  CPPA_TPASSINANTE       VARCHAR2(1),
  CPPA_TPSIMPLESNACIONAL VARCHAR2(1),
  CPPA_TPCLIENTESERVCOM  VARCHAR2(2),
  CPPA_VBINATIVACAO      CHAR(1) DEFAULT 'F' NOT NULL,
  CPPA_USINATIVACAO      VARCHAR2(30),
  CPPA_DTINATIVACAO      DATE,
  CPPA_USINCLUSAO        VARCHAR2(30) NOT NULL,
  CPPA_DTINCLUSAO        DATE         NOT NULL,
  CPPA_USALTERACAO       VARCHAR2(30),
  CPPA_DTALTERACAO       DATE
)
/

COMMENT ON TABLE TINARQCLIPARPART_CPPA IS 'Informa��es fiscais complementares do cliente'
/

comment on column TINARQCLIPARPART_CPPA.CPPA_IDPROCESSO is 'N�mero de Identifica��o do Arquivo Importado'
/

comment on column TINARQCLIPARPART_CPPA.CPPA_IDREGISTRO is 'N�mero do Registro no Arquivo Importado'
/

comment on column TINARQCLIPARPART_CPPA.CPPA_NRINSCESTST is 'Inscri��o Estadual do Participante na unidade de federa��o do Destinat�rio, na condi��o de contribuinte substituto.'
/

comment on column TINARQCLIPARPART_CPPA.CPPA_NRCEI is 'N�mero de Inscri��o no Cadastro Espec�fico do INSS.'
/

comment on column TINARQCLIPARPART_CPPA.CPPA_NRNIT is 'N�mero de Identifica��o do Trabalhador, PIS, PASEP, SUS.'
/

comment on column TINARQCLIPARPART_CPPA.CPPA_NRINDNATRET is 'Indicador da Natureza da Reten��o'
/

comment on column TINARQCLIPARPART_CPPA.CPPA_TPASSINANTE  is 'C�digo do Tipo de Assinante'
/

comment on column TINARQCLIPARPART_CPPA.CPPA_TPSIMPLESNACIONAL  is 'Classifica��o do Simples Nacional, a ser utilizada exclusivamente na gera��o do arquivo DES-BH'
/

comment on column TINARQCLIPARPART_CPPA.CPPA_TPCLIENTESERVCOM  is 'Tipo de Cliente de Servi�os de Comunica��o'
/

COMMENT ON COLUMN TINARQCLIPARPART_CPPA.CPPA_VBINATIVACAO IS '[V] - Inativo / [F] - Ativo'
/

COMMENT ON COLUMN TINARQCLIPARPART_CPPA.CPPA_USINCLUSAO IS 'Usu�rio de inclus�o'
/

COMMENT ON COLUMN TINARQCLIPARPART_CPPA.CPPA_DTINCLUSAO IS 'Data de inclus�o'
/

COMMENT ON COLUMN TINARQCLIPARPART_CPPA.CPPA_USALTERACAO IS 'Usu�rio de altera��o'
/

COMMENT ON COLUMN TINARQCLIPARPART_CPPA.CPPA_DTALTERACAO IS 'Data de altera��o'
/

COMMENT ON COLUMN TINARQCLIPARPART_CPPA.CPPA_USINATIVACAO IS 'Usu�rio de inativa��o'
/

COMMENT ON COLUMN TINARQCLIPARPART_CPPA.CPPA_DTINATIVACAO IS 'Data de inativa��o'
/

ALTER TABLE TINARQCLIPARPART_CPPA
  ADD CONSTRAINT PK_TINARQCLIPARPART_CPPA PRIMARY KEY (CPPA_IDPARPART)
/

alter table TINARQCLIPARPART_CPPA
  add constraint FK1_TINARQCLIPARPART_CPPA foreign key (CPPA_IDPROCESSO, CPPA_IDREGISTRO)
  references TI_ARQCLIENTE_TACL (TACL_SQPROCESSO, TACL_SQREGISTRO)
/

alter table TINARQCLIPARPART_CPPA
 add constraint UK1_TINARQCLIPARPART_CPPA unique (CPPA_IDPROCESSO, CPPA_IDREGISTRO)
/

CREATE SEQUENCE SQ1_TINARQCLIPARPART_CPPA
MINVALUE 0
MAXVALUE 999999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE OR REPLACE PROCEDURE PRC_INSTINARQCLIPARPART_CPPA
(
  PCPPA_IDPROCESSO        IN NUMBER,
  PCPPA_IDREGISTRO        IN NUMBER,
  PCPPA_NRINSCESTST       IN CHAR,
  PCPPA_NRCEI             IN CHAR,
  PCPPA_NRNIT             IN CHAR,
  PCPPA_NRINDNATRET       IN CHAR,
  PCPPA_TPASSINANTE       IN CHAR,
  PCPPA_TPSIMPLESNACIONAL IN CHAR,
  PCPPA_TPCLIENTESERVCOM  IN CHAR
)
AS BEGIN
  INSERT INTO TINARQCLIPARPART_CPPA
  (CPPA_IDPARPART, CPPA_IDPROCESSO, CPPA_IDREGISTRO, CPPA_NRINSCESTST, CPPA_NRCEI, CPPA_NRNIT,
   CPPA_NRINDNATRET, CPPA_TPASSINANTE, CPPA_TPSIMPLESNACIONAL, CPPA_TPCLIENTESERVCOM, CPPA_VBINATIVACAO,
   CPPA_USINCLUSAO, CPPA_DTINCLUSAO)
  VALUES
  (SQ1_TINARQCLIPARPART_CPPA.NEXTVAL, PCPPA_IDPROCESSO, PCPPA_IDREGISTRO, PCPPA_NRINSCESTST, PCPPA_NRCEI, PCPPA_NRNIT,
   PCPPA_NRINDNATRET, PCPPA_TPASSINANTE, PCPPA_TPSIMPLESNACIONAL, PCPPA_TPCLIENTESERVCOM, 'F',
   GET_USER_MXM, SYSDATE);
END;
/

CREATE TABLE TINARQFORPARPART_FPPA
(
  FPPA_IDPARPART         NUMBER,
  FPPA_IDPROCESSO        NUMBER,
  FPPA_IDREGISTRO        NUMBER,
  FPPA_NRINSCESTST       VARCHAR2(20),
  FPPA_NRCEI             VARCHAR2(12),
  FPPA_NRNIT             VARCHAR2(11),
  FPPA_NRINDNATRET       VARCHAR2(2),
  FPPA_TPASSINANTE       VARCHAR2(1),
  FPPA_TPSIMPLESNACIONAL VARCHAR2(1),
  FPPA_TPCLIENTESERVCOM  VARCHAR2(2),
  FPPA_VBINATIVACAO      CHAR(1) DEFAULT 'F' NOT NULL,
  FPPA_USINATIVACAO      VARCHAR2(30),
  FPPA_DTINATIVACAO      DATE,
  FPPA_USINCLUSAO        VARCHAR2(30) NOT NULL,
  FPPA_DTINCLUSAO        DATE         NOT NULL,
  FPPA_USALTERACAO       VARCHAR2(30),
  FPPA_DTALTERACAO       DATE
)
/

COMMENT ON TABLE TINARQFORPARPART_FPPA IS 'Informa��es fiscais complementares do fornecedor'
/

comment on column TINARQFORPARPART_FPPA.FPPA_IDPROCESSO is 'N�mero de Identifica��o do Arquivo Importado'
/

comment on column TINARQFORPARPART_FPPA.FPPA_IDREGISTRO is 'N�mero do Registro no Arquivo Importado'
/

comment on column TINARQFORPARPART_FPPA.FPPA_NRINSCESTST is 'Inscri��o Estadual do Participante na unidade de federa��o do Destinat�rio, na condi��o de contribuinte substituto.'
/

comment on column TINARQFORPARPART_FPPA.FPPA_NRCEI is 'N�mero de Inscri��o no Cadastro Espec�fico do INSS.'
/

comment on column TINARQFORPARPART_FPPA.FPPA_NRNIT is 'N�mero de Identifica��o do Trabalhador, PIS, PASEP, SUS.'
/

comment on column TINARQFORPARPART_FPPA.FPPA_NRINDNATRET is 'Indicador da Natureza da Reten��o'
/

comment on column TINARQFORPARPART_FPPA.FPPA_TPASSINANTE  is 'C�digo do Tipo de Assinante'
/

comment on column TINARQFORPARPART_FPPA.FPPA_TPSIMPLESNACIONAL  is 'Classifica��o do Simples Nacional, a ser utilizada exclusivamente na gera��o do arquivo DES-BH'
/

comment on column TINARQFORPARPART_FPPA.FPPA_TPCLIENTESERVCOM  is 'Tipo de Cliente de Servi�os de Comunica��o'
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_VBINATIVACAO IS '[V] - Inativo / [F] - Ativo'
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_USINCLUSAO IS 'Usu�rio de inclus�o'
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_DTINCLUSAO IS 'Data de inclus�o'
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_USALTERACAO IS 'Usu�rio de altera��o'
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_DTALTERACAO IS 'Data de altera��o'
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_USINATIVACAO IS 'Usu�rio de inativa��o'
/

COMMENT ON COLUMN TINARQFORPARPART_FPPA.FPPA_DTINATIVACAO IS 'Data de inativa��o'
/

ALTER TABLE TINARQFORPARPART_FPPA
  ADD CONSTRAINT PK_TINARQFORPARPART_FPPA PRIMARY KEY (FPPA_IDPARPART)
/

alter table TINARQFORPARPART_FPPA
  add constraint FK1_TINARQFORPARPART_FPPA foreign key (FPPA_IDPROCESSO, FPPA_IDREGISTRO)
  references TI_ARQFORNEC_TAFO (TAFO_SQPROCESSO, TAFO_SQREGISTRO)
/

alter table TINARQFORPARPART_FPPA
  add constraint UK1_TINARQFORPARPART_FPPA unique (FPPA_IDPROCESSO, FPPA_IDREGISTRO)
/

CREATE SEQUENCE SQ1_TINARQFORPARPART_FPPA
MINVALUE 0
MAXVALUE 999999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE
/

CREATE OR REPLACE PROCEDURE PRC_INSTINARQFORPARPART_FPPA
(
  PFPPA_IDPROCESSO        IN NUMBER,
  PFPPA_IDREGISTRO        IN NUMBER,
  PFPPA_NRINSCESTST       IN CHAR,
  PFPPA_NRCEI             IN CHAR,
  PFPPA_NRNIT             IN CHAR,
  PFPPA_NRINDNATRET       IN CHAR,
  PFPPA_TPASSINANTE       IN CHAR,
  PFPPA_TPSIMPLESNACIONAL IN CHAR,
  PFPPA_TPCLIENTESERVCOM  IN CHAR
)
AS BEGIN
  INSERT INTO TINARQFORPARPART_FPPA
  (FPPA_IDPARPART, FPPA_IDPROCESSO, FPPA_IDREGISTRO, FPPA_NRINSCESTST, FPPA_NRCEI, FPPA_NRNIT,
   FPPA_NRINDNATRET, FPPA_TPASSINANTE, FPPA_TPSIMPLESNACIONAL, FPPA_TPCLIENTESERVCOM, FPPA_VBINATIVACAO,
   FPPA_USINCLUSAO, FPPA_DTINCLUSAO)
  VALUES
  (SQ1_TINARQFORPARPART_FPPA.NEXTVAL, PFPPA_IDPROCESSO, PFPPA_IDREGISTRO, PFPPA_NRINSCESTST, PFPPA_NRCEI, PFPPA_NRNIT,
   PFPPA_NRINDNATRET, PFPPA_TPASSINANTE, PFPPA_TPSIMPLESNACIONAL, PFPPA_TPCLIENTESERVCOM, 'F',
   GET_USER_MXM, SYSDATE);
END;
/

CREATE OR REPLACE FUNCTION GET_DESCRICAO_STATUS_NFE(STATUS NUMBER)
  RETURN VARCHAR2 IS
  DESCRICAO VARCHAR2(200);
BEGIN
  DESCRICAO := '';
    CASE STATUS
      WHEN 0
        THEN DESCRICAO := 'N�o enviada';
      WHEN 1
        THEN DESCRICAO := 'Aguardando envio';
      WHEN 2
        THEN DESCRICAO := 'Erro no processamento';
      WHEN 3
        THEN DESCRICAO := 'Em processamento';
      WHEN 4
        THEN DESCRICAO := 'Processado'  ;
      WHEN 5
        THEN DESCRICAO := 'Liberado' ;
      WHEN 6
        THEN DESCRICAO := 'Denegado';
      WHEN 7
        THEN DESCRICAO := 'Cancelado';
      WHEN 8
        THEN DESCRICAO := 'Em Cancelamento';
      WHEN 9
        THEN DESCRICAO := 'Cancelado pelo Site';
      WHEN 10
        THEN DESCRICAO := 'Erro Cancelamento NF no Site';
      WHEN 11
        THEN DESCRICAO := 'Exporta��o XML sem Integra��o';
      WHEN 12
        THEN DESCRICAO := 'DANFE de Conting�ncia';
      WHEN 13
        THEN DESCRICAO := 'Inutilizando Nota Fiscal';
      WHEN 14
        THEN DESCRICAO := 'Erro na Inutiliza��o';
      WHEN 15
        THEN DESCRICAO := 'Nota Inutilizada';
      WHEN 16
        THEN DESCRICAO := 'Erro no envio da Conting�ncia';
      WHEN 17
        THEN DESCRICAO := 'Conting�ncia Processada';
      WHEN 18
        THEN DESCRICAO :='DANFE de Conting�ncia DPEC' ;
      WHEN 19
        THEN DESCRICAO := 'Conting�ncia DPEC Processada';
      WHEN 20
        THEN DESCRICAO := 'Erro no envio da Conting�ncia DPEC';
      WHEN 21
        THEN DESCRICAO :='Cancelamento NF Fora de Prazo';
      WHEN 22
        THEN DESCRICAO :='Conting�ncia SVCAN Processada';
      WHEN 23
        THEN DESCRICAO :='Conting�ncia SVCRS Processada';
      END CASE;
  RETURN DESCRICAO;
END;
/

DECLARE
  PARAMETROMARCADO CHAR(1);
  DTCADASTRO       PARAMS_PAR.PAR_DTCADASTRADO%TYPE;
BEGIN
  SELECT DECODE(COUNT(*), 0, 'N', 'S')
    INTO PARAMETROMARCADO
    FROM PARAMS_PAR
   WHERE UPPER(PAR_CDPARAM)  LIKE UPPER('%UtilizarDataCompetenciaContabilizacaoEscrituracao%')
     AND (  (UPPER(PAR_VLPARAM) = 'TRUE')
          OR(UPPER(PAR_VLPARAM) = 'SIM')
          OR(UPPER(PAR_VLPARAM) = 'S')
         );
  IF (PARAMETROMARCADO = 'N')
   THEN
   UPDATE NOTA_NT
      SET NT_DTCOMPETENCIA = DECODE(NT_TIPO, 'E', NT_ENTRADA, NT_EMISSAO)
    WHERE (  (   (NT_TIPO = 'E')
              AND(NT_DTCOMPETENCIA IS NULL)
              AND(NT_ENTRADA IS NOT NULL)
             )
           OR(   (NT_TIPO = 'S')
              AND(NT_DTCOMPETENCIA IS NULL)
              AND(NT_EMISSAO IS NOT NULL)
             )
           OR(   (NT_TIPO = 'E')
              AND(NT_DTCOMPETENCIA <> NT_ENTRADA)
             )
           OR(   (NT_TIPO = 'S')
              AND(NT_DTCOMPETENCIA <> NT_EMISSAO)
             )
          );
   END IF;
  IF (PARAMETROMARCADO = 'S')
   THEN
   SELECT MAX(PAR_DTCADASTRADO)
     INTO DTCADASTRO
     FROM PARAMS_PAR
    WHERE UPPER(PAR_CDPARAM)  LIKE UPPER('%UtilizarDataCompetenciaContabilizacaoEscrituracao%')
      AND (  (UPPER(PAR_VLPARAM) = 'TRUE')
           OR(UPPER(PAR_VLPARAM) = 'SIM')
           OR(UPPER(PAR_VLPARAM) = 'S')
          );
   UPDATE NOTA_NT
      SET NT_DTCOMPETENCIA = DECODE(NT_TIPO, 'E', NT_ENTRADA, NT_EMISSAO)
    WHERE (  (   (NT_TIPO = 'E')
              AND(NT_DTCOMPETENCIA IS NULL)
              AND(NT_ENTRADA IS NOT NULL)
             )
           OR(   (NT_TIPO = 'S')
              AND(NT_DTCOMPETENCIA IS NULL)
              AND(NT_EMISSAO IS NOT NULL)
             )
           OR(   (NT_TIPO = 'E')
              AND(NT_DTCOMPETENCIA <> NT_ENTRADA)
             )
           OR(   (NT_TIPO = 'S')
              AND(NT_DTCOMPETENCIA <> NT_EMISSAO)
             )
          )
      AND NT_DATA <= DTCADASTRO;
   END IF;
END;
/

CREATE SEQUENCE SEQ1_FATANTECCP_FAP
MINVALUE 1
MAXVALUE 999999999999
START WITH 1
INCREMENT BY 1
NOCACHE
/

create table FATANTECCP_FAP
(
  FAP_IDFATANTECCP   NUMBER(10) not null,
  FAP_CDEMPRESA      VARCHAR2(4) not null,
  FAP_CDFILIAL       VARCHAR2(4) not null,
  FAP_CDFATURA       NUMBER(10) not null,
  FAP_CDFOR          VARCHAR2(15) not null,
  FAP_CDDOCANTEC     VARCHAR2(20) not null,
  FAP_CDSEQUENCIA    NUMBER(3) not null,
  FAP_VLDESPESA      NUMBER(15,2),
  FAP_VLDESPESA2M    NUMBER(15,2),
  FAP_VLDEVREEMB     NUMBER(15,2),
  FAP_VLDEVREEMB2M   NUMBER(15,2),
  FAP_VLCOTACAO      NUMBER(15,9),
  FAP_VLCOTACAOEMP2M NUMBER(15,9),
  FAP_DTINCLUSAO     DATE not null,
  FAP_USINCLUSAO     VARCHAR2(40) not null,
  FAP_DTALTERACAO    DATE,
  FAP_USALTERACAO    VARCHAR2(40)
)
/

comment on table FATANTECCP_FAP
  is 'Tabela respons�vel por armazenar as antecipa��es vinculadas a fatura.'
/

comment on column FATANTECCP_FAP.FAP_IDFATANTECCP
  is 'Identificador de registro da antecipa��o da fatura.'
/

comment on column FATANTECCP_FAP.FAP_CDEMPRESA
  is 'C�digo da empresa da fatura vinculada antecipa��o.'
/

comment on column FATANTECCP_FAP.FAP_CDFILIAL
  is 'C�digo da filial da fatura vinculada antecipa��o.'
/

comment on column FATANTECCP_FAP.FAP_CDFATURA
  is 'C�digo da fatura vinculada antecipa��o.'
/

comment on column FATANTECCP_FAP.FAP_CDFOR
  is 'C�digo do fornecedor da antecipa��o vinculada a fatura.'
/

comment on column FATANTECCP_FAP.FAP_CDDOCANTEC
  is 'C�digo da antecipa��o vinculada a fatura.'
/

comment on column FATANTECCP_FAP.FAP_CDSEQUENCIA
  is 'C�digo da sequ�ncia da antecipa��o na fatura'
/

comment on column FATANTECCP_FAP.FAP_VLDESPESA
  is 'Valor da despesa da antecipa��o da fatura'
/

comment on column FATANTECCP_FAP.FAP_VLDESPESA2M
  is 'Valor da devolu��o ou reembolso da antecipa��o da fatura'
/

comment on column FATANTECCP_FAP.FAP_VLDEVREEMB
  is 'O respons�vel por realizar a altera��o das informa��es na base de dados'
/

comment on column FATANTECCP_FAP.FAP_VLDEVREEMB2M
  is 'Valor da devolu��o ou reembolso da antecipa��o da fatura na segunda moeda'
/

comment on column FATANTECCP_FAP.FAP_VLCOTACAO
  is 'Valor da cota��o da antecipa��o da fatura'
/

comment on column FATANTECCP_FAP.FAP_VLCOTACAOEMP2M
  is 'Valor da cota��o da antecipa��o da fatura na segunda moeda da empresa'
/

comment on column FATANTECCP_FAP.FAP_DTINCLUSAO
  is 'Indica��o do dia, m�s e ano em que a informa��o foi criada na base de dados'
/

comment on column FATANTECCP_FAP.FAP_USINCLUSAO
  is 'O respons�vel por realizar a cria��o das informa��es na base de dados'
/

comment on column FATANTECCP_FAP.FAP_DTALTERACAO
  is 'Indica��o do dia, m�s e ano em que a informa��o foi alterada na base de dados'
/

comment on column FATANTECCP_FAP.FAP_USALTERACAO
  is 'O respons�vel por realizar a altera��o das informa��es na base de dados'
/

alter table FATANTECCP_FAP
  add constraint PK_FATANTECCP_FAP primary key (FAP_IDFATANTECCP)
/

alter table FATANTECCP_FAP
  add constraint UK1_FATANTECCP_FAP unique (FAP_CDEMPRESA, FAP_CDFILIAL, FAP_CDFATURA, FAP_CDFOR, FAP_CDDOCANTEC)
/

alter table FATANTECCP_FAP
  add constraint FK1_FATANTECCP_FAP foreign key (FAP_CDEMPRESA, FAP_CDFILIAL, FAP_CDFATURA)
  references FATURAS_FAT (FAT_CDEMPRESA, FAT_CDFILIAL, FAT_CDFATURA)
/

alter table FATANTECCP_FAP
  add constraint FK2_FATANTECCP_FAP foreign key (FAP_CDFOR)
  references FORNEC_FOR (FOR_CODIGO)
/

alter table FATANTECCP_FAP
  add constraint FK3_FATANTECCP_FAP foreign key (FAP_CDFOR, FAP_CDDOCANTEC)
  references ANTECCP_ACP (ACP_CDFOR, ACP_DOCANTEC)
/

CREATE INDEX IN1_FATANTECCP_FAP ON FATANTECCP_FAP (FAP_CDEMPRESA, FAP_CDFILIAL, FAP_CDFATURA)
/

CREATE INDEX IN2_FATANTECCP_FAP ON FATANTECCP_FAP (FAP_CDFOR)
/

CREATE INDEX IN3_FATANTECCP_FAP ON FATANTECCP_FAP (FAP_CDFOR, FAP_CDDOCANTEC)
/

CREATE OR REPLACE PROCEDURE PRC_INSFATANTECCP_FAP(
 PFAP_IDFATANTECCP   IN OUT NUMBER
,PFAP_CDEMPRESA      IN CHAR
,PFAP_CDFILIAL       IN CHAR
,PFAP_CDFATURA       IN NUMBER
,PFAP_CDFOR          IN CHAR
,PFAP_CDDOCANTEC     IN CHAR
,PFAP_CDSEQUENCIA    IN NUMBER
,PFAP_VLDESPESA      IN NUMBER
,PFAP_VLDESPESA2M    IN NUMBER
,PFAP_VLDEVREEMB     IN NUMBER
,PFAP_VLDEVREEMB2M   IN NUMBER
,PFAP_VLCOTACAO      IN NUMBER
,PFAP_VLCOTACAOEMP2M IN NUMBER
)
AS
BEGIN
  IF PFAP_IDFATANTECCP IS NULL THEN
   SELECT SEQ1_FATANTECCP_FAP.NEXTVAL INTO PFAP_IDFATANTECCP FROM DUAL;
  END IF;
  INSERT INTO FATANTECCP_FAP(
    FAP_IDFATANTECCP
   ,FAP_CDEMPRESA
   ,FAP_CDFILIAL
   ,FAP_CDFATURA
   ,FAP_CDFOR
   ,FAP_CDDOCANTEC
   ,FAP_CDSEQUENCIA
   ,FAP_VLDESPESA
   ,FAP_VLDESPESA2M
   ,FAP_VLDEVREEMB
   ,FAP_VLDEVREEMB2M
   ,FAP_VLCOTACAO
   ,FAP_VLCOTACAOEMP2M
   ,FAP_DTINCLUSAO
   ,FAP_USINCLUSAO
) VALUES (
    PFAP_IDFATANTECCP
   ,PFAP_CDEMPRESA
   ,PFAP_CDFILIAL
   ,PFAP_CDFATURA
   ,PFAP_CDFOR
   ,PFAP_CDDOCANTEC
   ,PFAP_CDSEQUENCIA
   ,PFAP_VLDESPESA
   ,PFAP_VLDESPESA2M
   ,PFAP_VLDEVREEMB
   ,PFAP_VLDEVREEMB2M
   ,PFAP_VLCOTACAO
   ,PFAP_VLCOTACAOEMP2M
   ,SYSDATE
   ,GET_USER_MXM
);
END;
/

CREATE OR REPLACE PROCEDURE PRC_ALTFATANTECCP_FAP(
 PFAP_IDFATANTECCP   IN OUT NUMBER
,PFAP_CDEMPRESA      IN CHAR
,PFAP_CDFILIAL       IN CHAR
,PFAP_CDFATURA       IN NUMBER
,PFAP_CDFOR          IN CHAR
,PFAP_CDDOCANTEC     IN CHAR
,PFAP_CDSEQUENCIA    IN NUMBER
,PFAP_VLDESPESA      IN NUMBER
,PFAP_VLDESPESA2M    IN NUMBER
,PFAP_VLDEVREEMB     IN NUMBER
,PFAP_VLDEVREEMB2M   IN NUMBER
,PFAP_VLCOTACAO      IN NUMBER
,PFAP_VLCOTACAOEMP2M IN NUMBER
)
AS
BEGIN
  UPDATE FATANTECCP_FAP
     SET FAP_IDFATANTECCP = PFAP_IDFATANTECCP
        ,FAP_CDEMPRESA = PFAP_CDEMPRESA
        ,FAP_CDFILIAL = PFAP_CDFILIAL
        ,FAP_CDFATURA = PFAP_CDFATURA
        ,FAP_CDFOR = PFAP_CDFOR
        ,FAP_CDDOCANTEC = PFAP_CDDOCANTEC
        ,FAP_CDSEQUENCIA = PFAP_CDSEQUENCIA
        ,FAP_VLDESPESA = PFAP_VLDESPESA
        ,FAP_VLDESPESA2M = PFAP_VLDESPESA2M
        ,FAP_VLDEVREEMB = PFAP_VLDEVREEMB
        ,FAP_VLDEVREEMB2M = PFAP_VLDEVREEMB2M
        ,FAP_VLCOTACAO = PFAP_VLCOTACAO
        ,FAP_VLCOTACAOEMP2M = PFAP_VLCOTACAOEMP2M
        ,FAP_DTALTERACAO = SYSDATE
        ,FAP_USALTERACAO = GET_USER_MXM
   WHERE FAP_IDFATANTECCP = PFAP_IDFATANTECCP;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EXCFATANTECCP_FAP(
 PFAP_IDFATANTECCP IN NUMBER
)
AS
BEGIN
  DELETE FROM FATANTECCP_FAP
   WHERE FAP_IDFATANTECCP = PFAP_IDFATANTECCP;
END;
/

CREATE OR REPLACE PROCEDURE ALTSPEDPARPART_PPA
(PPPA_CODIGOPART IN CHAR,
 PPPA_CLIFOR IN CHAR,
 PPPA_CODMUNIC IN CHAR,
 PPPA_CODPAIS IN CHAR,
 PPPA_INSCESTST IN CHAR,
 PPPA_CEI IN CHAR,
 PPPA_NIT IN CHAR,
 PPPA_INDNATRET IN CHAR,
 PPPA_TPASSINANTE IN CHAR,
 PPPA_TPCLIENTESERVCOM IN CHAR,
 PPPA_TPSIMPLESNACIONAL IN CHAR DEFAULT NULL)
AS
BEGIN
  UPDATE SPEDPARPART_PPA
   SET PPA_CODMUNIC = PPPA_CODMUNIC,
       PPA_CODPAIS = PPPA_CODPAIS,
       PPA_INSCESTST = PPPA_INSCESTST,
       PPA_CEI = PPPA_CEI,
       PPA_NIT = PPPA_NIT,
       PPA_INDNATRET = PPPA_INDNATRET,
       PPA_TPASSINANTE = PPPA_TPASSINANTE,
       PPA_TPCLIENTESERVCOM = PPPA_TPCLIENTESERVCOM,
       PPA_TPSIMPLESNACIONAL = PPPA_TPSIMPLESNACIONAL
   WHERE PPA_CODIGOPART = PPPA_CODIGOPART AND
     PPA_CLIFOR = PPPA_CLIFOR;
END;
/

CREATE OR REPLACE PROCEDURE INSSPEDPARPART_PPA
(PPPA_CODIGOPART IN CHAR,
 PPPA_CLIFOR IN CHAR,
 PPPA_CODMUNIC IN CHAR,
 PPPA_CODPAIS IN CHAR,
 PPPA_INSCESTST IN CHAR,
 PPPA_CEI IN CHAR,
 PPPA_NIT IN CHAR,
 PPPA_INDNATRET IN CHAR,
 PPPA_TPASSINANTE IN CHAR,
 PPPA_TPCLIENTESERVCOM IN CHAR,
 PPPA_TPSIMPLESNACIONAL IN CHAR DEFAULT NULL)
AS
BEGIN
  INSERT INTO SPEDPARPART_PPA(
      PPA_CODIGOPART,
      PPA_CLIFOR,
      PPA_CODMUNIC,
      PPA_CODPAIS,
      PPA_INSCESTST,
      PPA_CEI,
      PPA_NIT,
      PPA_INDNATRET,
      PPA_TPASSINANTE,
      PPA_TPCLIENTESERVCOM,
      PPA_TPSIMPLESNACIONAL
) VALUES (
      PPPA_CODIGOPART,
      PPPA_CLIFOR,
      PPPA_CODMUNIC,
      PPPA_CODPAIS,
      PPPA_INSCESTST,
      PPPA_CEI,
      PPPA_NIT,
      PPPA_INDNATRET,
      PPPA_TPASSINANTE,
      PPPA_TPCLIENTESERVCOM,
      PPPA_TPSIMPLESNACIONAL);
END;
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de D�bito do IPI, onde existe o valor do imposto.', 'GSCOCON001')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de Cr�dito do IPI, onde existe o valor do imposto.', 'GSCOCON002')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de D�bito do ICMS, onde existe o valor do imposto.', 'GSCOCON003')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de Cr�dito do ICMS, onde existe o valor do imposto.', 'GSCOCON004')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de D�bito do Difal ICMS, onde existe o valor do imposto.', 'GSCOCON005')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de Cr�dito do Difal ICMS, onde existe o valor do imposto.', 'GSCOCON006')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de D�bito da Substitui��o Tribut�ria, onde existe o valor do imposto.', 'GSCOCON007')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de Cr�dito da Substitui��o Tribut�ria, onde existe o valor do imposto.', 'GSCOCON008')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de D�bito do II, onde existe o valor do imposto.', 'GSCOCON009')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de Cr�dito do II, onde existe o valor do imposto.', 'GSCOCON010')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de D�bito do PIS, onde existe o valor do imposto.', 'GSCOCON011')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de Cr�dito do PIS, onde existe o valor do imposto.', 'GSCOCON012')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de D�bito do Cofins, onde existe o valor do imposto.', 'GSCOCON013')
/

INSERT INTO ERROMSG_ERM (ERM_DSERRO, ERM_CDERRO) VALUES('N�o foi parametrizada a conta de Cr�dito do Cofins, onde existe o valor do imposto.', 'GSCOCON014')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 269700
PROMPT ======================================================================