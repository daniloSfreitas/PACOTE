PROMPT ======================================================================
PROMPT == DEMANDA......: 276947
PROMPT == SISTEMA......: Contabilidade
PROMPT == RESPONSAVEL..: DEBORAH EVELYN MOREIRA DA ROCHA
PROMPT == DATA.........: 28/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO MXS_FUNCAO_MXF (MXF_FUNCAO, MXF_TITULO, MXF_DESCRICAO) VALUES (35271, 'Balancete com detalhamento da consolida��o', 'Balancete com detalhamento da consolida��o')
/

INSERT INTO MXS_FUNCAOSISTEMA_MXFS (MXFS_CDSISTEMA, MXFS_CDFUNCAO, MXFS_ORDEM, MXFS_CDFUNCAOSUP) VALUES ('SCB', 35271, 17, 3869)
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35271, 'CON')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35271, 'INC')
/

INSERT INTO MXS_RELPROPFUNCAO_MRPF (MRPF_CDFUNCAO, MRPF_CDPROPRIEDADE) VALUES (35271, 'EXC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276947
PROMPT ======================================================================