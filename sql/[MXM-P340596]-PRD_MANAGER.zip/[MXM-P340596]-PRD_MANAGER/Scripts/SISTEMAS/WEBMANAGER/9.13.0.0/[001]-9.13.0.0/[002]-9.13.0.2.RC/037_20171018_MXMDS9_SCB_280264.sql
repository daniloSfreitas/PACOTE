PROMPT ======================================================================
PROMPT == DEMANDA......: 280264
PROMPT == SISTEMA......: Contabilidade
PROMPT == RESPONSAVEL..: JULIANO MENEZES
PROMPT == DATA.........: 17/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCESSAREGE025(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
  VR_MENSAGEM_ERRO VARCHAR2(500);
  CT_REGE025       VARCHAR2(4) := 'E025';
  CURSOR CS_REGE025 IS
    SELECT SEQ1_EFDLEDFREGISTROE025_E03.NEXTVAL AS VR_IDLEDFREGISTROE025,
           PT_IDMODESCRITURACAO                 AS NRLME,
           NRE020,
           CT_REGE025                           AS REGE025,
           CFOP,
           VL_CONT_P,
           VL_BC_ICMS_P,
           ALIQ_ICMS,
           VL_ICMS_P,
           VL_ST_P,
           VL_COMPL_P,
           VL_ISNT_ICMS_P,
           VL_OUT_ICMS_P,
           VL_BC_IPI_P,
           VL_IPI_P,
           VL_ISNT_IPI_P,
           VL_OUT_IPI_P
      FROM (SELECT E02_IDLEDFREGISTROE020 AS NRE020,
                   IDF_CFOP AS CFOP,
                   SUM(IDF_VLCONTABIL) AS VL_CONT_P,
                   SUM(IDF_VLBCICMS) AS VL_BC_ICMS_P,
                   IDF_ALIQICMS AS ALIQ_ICMS,
                   SUM(IDF_VLICMS) AS VL_ICMS_P, --SUM(IDF_VLICMSST) AS VL_ST_P,
                   DECODE(SUM(NVL(IDF_VLICMSUFREMETENTE,0)),
                          0,
                          SUM(IDF_VLICMSST),
                          DECODE(TPO_TIPO,
                                 'S',
                                 SUM(ROUND(IDF_VLICMSUFREMETENTE, 2)),
                                 SUM(ROUND(IDF_VLICMSUFDESTINO, 2)))) AS VL_ST_P,
                   SUM(IDF_VLCOMPLEMENTARDF) AS VL_COMPL_P,
                   SUM(IDF_VLBIICMS) AS VL_ISNT_ICMS_P,
                   SUM(IDF_VLBOICMS) AS VL_OUT_ICMS_P,
                   SUM(IDF_VLBCIPI) AS VL_BC_IPI_P,
                   SUM(IDF_VLIPI) AS VL_IPI_P,
                   SUM(IDF_VLBIIPI) AS VL_ISNT_IPI_P,
                   SUM(IDF_VLBOIPI) AS VL_OUT_IPI_P
              FROM SPEDDOCFIS_SDF,
                   SPEDITDOCFIS_IDF,
                   TPOPER_TPO,
                   EFDLEDFREGISTROE020_E02,
                   EFDLEDFMODELOESCRIT_LME
             WHERE SDF_SQDOCFIS = IDF_SQDOCFIS
               AND SDF_TPOP = TPO_CODIGO
               AND E02_NRLME = PT_IDMODESCRITURACAO
               AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
               AND SDF_CDEMPRESA = LME_CDEMPRESA
               AND SDF_CDFILIAL = LME_CDFILIAL
               AND DECODE(TPO_TIPO, 'E', '0', '1') = E02_TPINDOPER
               AND DECODE(SDF_EMITENTE, 'P', '0', '1') = E02_TPINDEMIT
               AND SDF_CLIFOR = E02_TPCLIFOR
               AND SDF_CDCLIFOR = E02_CDPART
               AND NVL(SDF_MODELO, '*') = NVL(E02_CDMOD, '*')
               AND NVL(SDF_SITDOC, '*') = NVL(E02_CDSIT, '*')
               AND NVL(SDF_SERIE, '*') = NVL(E02_CDSER, '*')
               AND SDF_DOCUMENTO = E02_NRDOC
               AND DECODE(TPO_TIPO,
                          'E',
                          TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'),
                          TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')) = E02_DTES
               AND TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY') = E02_DTDOC
             GROUP BY E02_IDLEDFREGISTROE020, IDF_CFOP, IDF_ALIQICMS,TPO_TIPO);
  TYPE TP_CS_REGE025 IS TABLE OF CS_REGE025%ROWTYPE INDEX BY PLS_INTEGER;
  TB_CS_REGE025 TP_CS_REGE025;
BEGIN
  OPEN CS_REGE025;
  LOOP
    FETCH CS_REGE025 BULK COLLECT
      INTO TB_CS_REGE025 LIMIT 1000;
    EXIT WHEN TB_CS_REGE025.COUNT = 0;
    FORALL I IN TB_CS_REGE025.FIRST .. TB_CS_REGE025.LAST SAVE EXCEPTIONS
      INSERT INTO EFDLEDFREGISTROE025_E03 VALUES TB_CS_REGE025 (I);
  END LOOP;
  CLOSE CS_REGE025;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      VR_MENSAGEM_ERRO := SUBSTR('Mensagem do Sistema: "' || SQLERRM,
                                 1,
                                 499) || '"';
      IF CS_REGE025%ISOPEN THEN
        CLOSE CS_REGE025;
      END IF;
      RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
    END;
END;
/

CREATE OR REPLACE PROCEDURE PRC_EFDLEDFPROCREGE020DIFAL(PT_IDMODESCRITURACAO IN EFDLEDFMODELOESCRIT_LME.LME_IDLEDFMODELOESCRIT%TYPE) AS
  VR_MENSAGEM_ERRO VARCHAR2(500);
  CT_REGE020       VARCHAR2(4) := 'E020';
  CURSOR CS_REGE020 IS
    SELECT SEQ1_EFDLEDFREGISTROE020_E02.NEXTVAL AS IDLEDFREGISTROE020,
           PT_IDMODESCRITURACAO                 AS NRLME,
           CT_REGE020                           AS REGE020,
           IND_OPER,
           IND_EMIT,
           CLIFOR,
           COD_PART,
           COD_MOD,
           COD_SIT,
           SER,
           NUM_DOC,
           DT_DOC,
           NUM_LCTO,
           DT_E_S,
           VL_CONT,
           VL_BC_ICMS,
           VL_ICMS,
           VL_ST,
           VL_COMPL,
           IND_COMPL,
           VL_ISNT_ICMS,
           VL_OUT_ICMS,
           VL_BC_IPI,
           VL_IPI,
           VL_ISNT_IPI,
           VL_OUT_IPI,
           COD_INF_OBS
      FROM (SELECT DECODE(TPO_TIPO, 'E', '0', '1') AS IND_OPER,
                   DECODE(SDF_EMITENTE, 'P', '0', '1') AS IND_EMIT,
                   SDF_CLIFOR AS CLIFOR,
                   TRIM(SDF_CDCLIFOR) AS COD_PART,
                   SDF_MODELO AS COD_MOD,
                   SDF_SITDOC AS COD_SIT,
                   SDF_SERIE AS SER,
                   SDF_DOCUMENTO AS NUM_DOC,
                   TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY') AS DT_DOC,
                   0 AS NUM_LCTO,
                   DECODE(TPO_TIPO,
                          'E',
                          TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'),
                          TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')) AS DT_E_S,
                   SUM(ROUND(IDF_VLCONTABIL, 2)) AS VL_CONT,
                   SUM(ROUND(IDF_VLBCICMS, 2)) AS VL_BC_ICMS,
                   SUM(ROUND(IDF_VLICMS, 2)) AS VL_ICMS,
                   DECODE(TPO_TIPO,
                          'S',
                          SUM(ROUND(IDF_VLICMSUFREMETENTE, 2)),
                          SUM(ROUND(IDF_VLICMSUFDESTINO, 2))) AS VL_ST,
                   SDF_VLTOTALCOMPLEMENTAR AS VL_COMPL,
                   NVL(SDF_TPINDCOMPLEMENTAR, '00') AS IND_COMPL,
                   SUM(IDF_VLBIICMS) AS VL_ISNT_ICMS,
                   SUM(IDF_VLBOICMS) AS VL_OUT_ICMS,
                   SUM(IDF_VLBCIPI) AS VL_BC_IPI,
                   SUM(IDF_VLIPI) AS VL_IPI,
                   SUM(IDF_VLBIIPI) AS VL_ISNT_IPI,
                   SUM(IDF_VLBOIPI) AS VL_OUT_IPI,
                   'DIFALEC87DF' AS COD_INF_OBS
              FROM SPEDDOCFIS_SDF,
                   SPEDITDOCFIS_IDF,
                   TPOPER_TPO,
                   EFDLEDFMODELOESCRIT_LME
             WHERE SDF_SQDOCFIS = IDF_SQDOCFIS
               AND SDF_TPOP = TPO_CODIGO
               AND SDF_CDEMPRESA = LME_CDEMPRESA
               AND SDF_CDFILIAL = LME_CDFILIAL(+)
               AND SDF_DATAESCR >= LME_DTINI
               AND SDF_DATAESCR <= LME_DTFIN
               AND SDF_MODELO = '55'
               AND ((NVL(IDF_VLICMSUFDESTINO, 0) + NVL(IDF_VLICMSUFREMETENTE, 0)) > 0)
               AND LME_IDLEDFMODELOESCRIT = PT_IDMODESCRITURACAO
             GROUP BY DECODE(TPO_TIPO, 'E', '0', '1'),
                      DECODE(SDF_EMITENTE, 'P', '0', '1'),
                      SDF_CLIFOR,
                      SDF_CDCLIFOR,
                      SDF_MODELO,
                      SDF_SITDOC,
                      SDF_SERIE,
                      SDF_DOCUMENTO,
                      TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY'),
                      DECODE(TPO_TIPO,
                             'E',
                             TO_CHAR(SDF_DATAENTR, 'DDMMYYYY'),
                             TO_CHAR(SDF_DATAEMISS, 'DDMMYYYY')),
                      SDF_VLTOTALCOMPLEMENTAR,
                      NVL(SDF_TPINDCOMPLEMENTAR, '00'),
                      TPO_TIPO);
  TYPE TP_CS_REGE020 IS TABLE OF CS_REGE020%ROWTYPE INDEX BY PLS_INTEGER;
  TB_CS_REGE020 TP_CS_REGE020;
BEGIN
  OPEN CS_REGE020;
  LOOP
    FETCH CS_REGE020 BULK COLLECT
      INTO TB_CS_REGE020 LIMIT 1000;
    EXIT WHEN TB_CS_REGE020.COUNT = 0;
    FORALL I IN TB_CS_REGE020.FIRST .. TB_CS_REGE020.LAST SAVE EXCEPTIONS
      INSERT INTO EFDLEDFREGISTROE020_E02 VALUES TB_CS_REGE020 (I);
  END LOOP;
  CLOSE CS_REGE020;
EXCEPTION
  WHEN OTHERS THEN
    BEGIN
      VR_MENSAGEM_ERRO := SUBSTR('Mensagem do Sistema: "' || SQLERRM,
                                 1,
                                 499) || '"';
      IF CS_REGE020%ISOPEN THEN
        CLOSE CS_REGE020;
      END IF;
      RAISE_APPLICATION_ERROR(-20000, VR_MENSAGEM_ERRO);
    END;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 280264
PROMPT ======================================================================