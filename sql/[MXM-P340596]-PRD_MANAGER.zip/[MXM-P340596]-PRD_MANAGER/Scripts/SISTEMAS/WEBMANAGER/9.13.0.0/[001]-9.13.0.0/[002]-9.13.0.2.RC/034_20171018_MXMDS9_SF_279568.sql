PROMPT ======================================================================
PROMPT == DEMANDA......: 279568
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: LEONARDO OLIVEIRA GOMES
PROMPT == DATA.........: 17/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('RTS0001', 'Empresa obrigat�rio.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('RTS0002', 'Empresa inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('RTS0003', 'Filial inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('RTS0004', 'Tipo de opera��o obrigat�rio.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('RTS0005', 'Tipo de opera��o inexistente')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('SRS0001', 'Processo referenciado obrigat�rio.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('SRS0002', 'Processo referenciado inexistente.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('SRS0003', 'Processo referenciado duplicado.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('SRS0004', 'Tipo de processo Judicial selecionado, portanto todos os processos referenciados que sejam do tipo Administrativo devem ser inativados.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('SRS0005', 'Tipo de processo Administrativo selecionado, portanto todos os processos referenciados que sejam do tipo Judicial devem ser inativados.')
/

INSERT INTO ERROMSG_ERM(ERM_CDERRO, ERM_DSERRO) VALUES ('SRS0006', 'Processo referenciado n�o parametrizado para ISS, ICMS, PIS ou COFINS.')
/

ALTER TABLE SFRELTPOSPRR_RTS
  ADD CONSTRAINT UK1_SFRELTPOSPRR_RTS UNIQUE (RTS_CDEMPRESA, RTS_CDFILIAL, RTS_CDTPOPER)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 279568
PROMPT ======================================================================