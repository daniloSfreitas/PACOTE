PROMPT ======================================================================
PROMPT == DEMANDA......: 272150
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: RODRIGO DA PAZ DO NASCIMENTO
PROMPT == DATA.........: 07/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRETABELARELVISAL_TRV
   SET TRV_NMLISTATABREL = 'ITFATURA_IFAT'
 WHERE TRV_NRVISAO = (SELECT VDR_IDVISAO
                        FROM GREVISAOTAB_VDR
                       WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA
                                                FROM GRETABDICDADOS_TDR
                                               WHERE TDR_NMTABELA = 'FATURAS_FAT'))
  AND TRV_NRTABELA = (SELECT TDR_IDTABELA
                          FROM GRETABDICDADOS_TDR
                         WHERE TDR_NMTABELA = 'CCUSTO_CC')
  AND TRV_NMLISTATABREL = 'ITFATURA_IFAT, EMP'
/

UPDATE GREFILTROCAMPOTAB_FCT
SET FCT_NMCAMPO = 'ITFATURA_IFAT.IFAT_ITEM'
WHERE FCT_NRVISAO =
       (SELECT VDR_IDVISAO
          FROM GREVISAOTAB_VDR
         WHERE VDR_NRTABELA =
               (SELECT TDR_IDTABELA
                  FROM GRETABDICDADOS_TDR
                 WHERE TDR_NMTABELA = 'FATURAS_FAT'))
   AND FCT_DSFILTRO = 'Item'
   AND FCT_NMCAMPO = 'PRODUTO_PRD.PRD_ITEM'
   AND FCT_TABELARELVISAO =
       (SELECT TRV_IDTABELARELVISAO
          FROM GRETABELARELVISAL_TRV
         WHERE TRV_NRVISAO =
               (SELECT VDR_IDVISAO
                  FROM GREVISAOTAB_VDR
                 WHERE VDR_NRTABELA =
                       (SELECT TDR_IDTABELA
                          FROM GRETABDICDADOS_TDR
                         WHERE TDR_NMTABELA = 'FATURAS_FAT'))
           AND TRV_NRTABELA =
               (SELECT TDR_IDTABELA
                  FROM GRETABDICDADOS_TDR
                 WHERE TDR_NMTABELA = 'ITFATURA_IFAT'))
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 272150
PROMPT ======================================================================