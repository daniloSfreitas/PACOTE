PROMPT ======================================================================
PROMPT == DEMANDA......: 276140
PROMPT == SISTEMA......: Estoque
PROMPT == RESPONSAVEL..: JULIANO MENEZES
PROMPT == DATA.........: 27/07/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE PARAMIMPOSTOS_PINP ADD PINP_CDICMSPARTDESTCONT VARCHAR2(15)
/

ALTER TABLE PARAMIMPOSTOS_PINP ADD PINP_CDICMSPARTDESTCCUS VARCHAR2(15)
/

ALTER TABLE PARAMIMPOSTOS_PINP ADD PINP_CDICMSPARTDESTCONTP VARCHAR2(15)
/

ALTER TABLE PARAMIMPOSTOS_PINP ADD PINP_CDICMSPARTDESTCCUSP VARCHAR2(15)
/

comment on column PARAMIMPOSTOS_PINP.PINP_CDICMSPARTDESTCONT
  is 'C�digo da conta cont�bil de d�bito para a Partilha do ICMS de Destino'
/

comment on column PARAMIMPOSTOS_PINP.PINP_CDICMSPARTDESTCCUS
  is 'C�digo do centro de custo cont�bil de d�bito para a Partilha do ICMS de Destino'
/

comment on column PARAMIMPOSTOS_PINP.PINP_CDICMSPARTDESTCONTP
  is 'C�digo da conta cont�bil de cr�dito para a Partilha do ICMS de Destinoa'
/

comment on column PARAMIMPOSTOS_PINP.PINP_CDICMSPARTDESTCCUSP
  is 'C�digo do centro de custo cont�bil de cr�dito para a Partilha do ICMS de Destino'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276140
PROMPT ======================================================================