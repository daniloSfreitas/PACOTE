PROMPT ======================================================================
PROMPT == DEMANDA......: 273597
PROMPT == SISTEMA......: Vendas
PROMPT == RESPONSAVEL..: THAISA PUPPIN TAVARES
PROMPT == DATA.........: 12/07/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRECAMPOS_CDR
  (CDR_IDCAMPO,
   CDR_NRTABELA,
   CDR_DSCAMPOTABELA,
   CDR_DSCAMPO,
   CDR_TPCAMPO,
   CDR_DSCAMPOTABELACABECALHO)
VALUES
  ((SELECT MAX(cdr_idcampo) + 1 FROM GRECAMPOS_CDR),
   (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='PEDVENDA_PDV'),
   'PEDVENDA_PDV.PDV_DTLIBFIN',
   'Data Libera��o Financeira',
   1,
   'Data Lib.Financeira')
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (FCT_IDFILTROCAMPO,
   FCT_NRVISAO,
   FCT_DSFILTRO,
   FCT_TPFILTRO,
   FCT_TPCAMPOFILTRO,
   FCT_NMARQUIVOAJUDA,
   FCT_NMLISTATABELA,
   FCT_NMLISTACONDICAOAJUDA,
   FCT_NMCONDCAMPOCHB,
   FCT_TABELARELVISAO,
   FCT_NMCAMPO,
   FCT_DSFILTROCABECALHO)
VALUES
  ((SELECT MAX(FCT_IDFILTROCAMPO) + 1 FROM GREFILTROCAMPOTAB_FCT),
   (SELECT VDR_IDVISAO
      FROM GREVISAOTAB_VDR
     WHERE VDR_NRTABELA = (SELECT TDR_IDTABELA
                             FROM GRETABDICDADOS_TDR
                            WHERE TDR_NMTABELA = 'PEDVENDA_PDV')),
   'Data Libera��o Financeira',
   0,
   1,
   null,
   null,
   null,
   null,
   null,
   'PEDVENDA_PDV.PDV_DTLIBFIN',
   'Data Libera��o Financeira')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 273597
PROMPT ======================================================================