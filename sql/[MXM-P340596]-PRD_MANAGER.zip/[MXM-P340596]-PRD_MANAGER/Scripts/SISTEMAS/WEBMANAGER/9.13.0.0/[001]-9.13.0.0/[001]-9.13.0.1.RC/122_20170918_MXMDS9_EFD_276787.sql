PROMPT ======================================================================
PROMPT == DEMANDA......: 276787
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: Julian Alves
PROMPT == DATA.........: 08/09/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DROP PROCEDURE EFD_PROCIMPORTAFISCAL
/

DROP PROCEDURE EFD_PROCIMPFISCAL_SDF
/

DROP PROCEDURE EFD_PROCIMPORTAFATURAMENTO
/

DROP PROCEDURE EFD_PROCIMPORTAESTOQUE
/

DROP PROCEDURE EFD_PROCIMPORTAFISCAL_FISCAL
/

DROP PROCEDURE EFD_PROCIMPFISCAL_SDFS
/

DROP PROCEDURE EFD_PROCIMPFISCAL_SDFS_FAT
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276787
PROMPT ======================================================================