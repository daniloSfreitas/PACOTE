PROMPT ======================================================================
PROMPT == DEMANDA......: 273326
PROMPT == SISTEMA......: Contabilidade
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 03/07/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE PARAMS_PAR
   SET PAR_VLPARAM = 'N'
 WHERE PAR_CDPARAM LIKE '%PAREFDMODELOCTB%' AND PAR_VLPARAM = 'MOD_CONTABIL'
/

UPDATE PARAMS_PAR
   SET PAR_VLPARAM = 'S'
 WHERE PAR_CDPARAM LIKE '%PAREFDMODELOCTB%' AND PAR_VLPARAM = 'PAR_CONTABIL'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 273326
PROMPT ======================================================================