PROMPT ======================================================================
PROMPT == DEMANDA......: 271631
PROMPT == SISTEMA......: Escritura��o Cont�bil Digital
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 17/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

alter table SPEDECDPLCONTASV10_RI050 modify cta VARCHAR2(255)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 271631
PROMPT ======================================================================