PROMPT ======================================================================
PROMPT == DEMANDA......: 272878
PROMPT == SISTEMA......: Compras
PROMPT == RESPONSAVEL..: ERICA LIMA BOTELHO
PROMPT == DATA.........: 09/06/2017
PROMPT == BASE.........: MXMDS912
PROMPT == OWNER DESTINO: MXMDS912
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO grefiltrocampotab_fct
    (fct_idfiltrocampo,
     fct_nrvisao,
     fct_dsfiltro,
     fct_tpfiltro,
     fct_tpcampofiltro,
     fct_nmarquivoajuda,
     fct_nmlistatabela,
     fct_nmlistacondicaoajuda,
     fct_nmcondcampochb,
     fct_tabelarelvisao,
     fct_nmcampo,
     fct_dsfiltrocabecalho)
  VALUES
    ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
     (SELECT vdr_idvisao
        FROM grevisaotab_vdr
       WHERE vdr_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'REQCOMPRA_RCO')),
     'Somente em aprova��o',
     1,
     0,
     '',
     '',
     '',
     'DECODE(IREQCOMPRA_IRC.IRC_STATUS,''E'',''S'', ''N'')',
     (SELECT trv_idtabelarelvisao
        FROM gretabelarelvisal_trv
       WHERE trv_nrvisao =
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela =
                     (SELECT tdr_idtabela
                        FROM gretabdicdados_tdr
                       WHERE tdr_nmtabela = 'REQCOMPRA_RCO'))
         AND trv_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'IREQCOMPRA_IRC')),
     'IREQCOMPRA_IRC.IRC_STATUS1',
     'Somente em aprova��o')
/

INSERT INTO grefiltrocampotab_fct
    (fct_idfiltrocampo,
     fct_nrvisao,
     fct_dsfiltro,
     fct_tpfiltro,
     fct_tpcampofiltro,
     fct_nmarquivoajuda,
     fct_nmlistatabela,
     fct_nmlistacondicaoajuda,
     fct_nmcondcampochb,
     fct_tabelarelvisao,
     fct_nmcampo,
     fct_dsfiltrocabecalho)
  VALUES
    ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
     (SELECT vdr_idvisao
        FROM grevisaotab_vdr
       WHERE vdr_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'REQCOMPRA_RCO')),
     'Somente aprovada',
     1,
     0,
     '',
     '',
     '',
     'DECODE(IREQCOMPRA_IRC.IRC_STATUS,''A'',''S'',''N'')',
     (SELECT trv_idtabelarelvisao
        FROM gretabelarelvisal_trv
       WHERE trv_nrvisao =
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela =
                     (SELECT tdr_idtabela
                        FROM gretabdicdados_tdr
                       WHERE tdr_nmtabela = 'REQCOMPRA_RCO'))
         AND trv_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'IREQCOMPRA_IRC')),
     'IREQCOMPRA_IRC.IRC_STATUS2',
     'Somente aprovada')
/

INSERT INTO grefiltrocampotab_fct
    (fct_idfiltrocampo,
     fct_nrvisao,
     fct_dsfiltro,
     fct_tpfiltro,
     fct_tpcampofiltro,
     fct_nmarquivoajuda,
     fct_nmlistatabela,
     fct_nmlistacondicaoajuda,
     fct_nmcondcampochb,
     fct_tabelarelvisao,
     fct_nmcampo,
     fct_dsfiltrocabecalho)
  VALUES
    ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
     (SELECT vdr_idvisao
        FROM grevisaotab_vdr
       WHERE vdr_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'REQCOMPRA_RCO')),
     'Somente reprovada',
     1,
     0,
     '',
     '',
     '',
     'DECODE(IREQCOMPRA_IRC.IRC_STATUS,''R'',''S'', ''N'')',
     (SELECT trv_idtabelarelvisao
        FROM gretabelarelvisal_trv
       WHERE trv_nrvisao =
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela =
                     (SELECT tdr_idtabela
                        FROM gretabdicdados_tdr
                       WHERE tdr_nmtabela = 'REQCOMPRA_RCO'))
         AND trv_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'IREQCOMPRA_IRC')),
     'IREQCOMPRA_IRC.IRC_STATUS3',
     'Somente reprovada')
/

INSERT INTO grefiltrocampotab_fct
    (fct_idfiltrocampo,
     fct_nrvisao,
     fct_dsfiltro,
     fct_tpfiltro,
     fct_tpcampofiltro,
     fct_nmarquivoajuda,
     fct_nmlistatabela,
     fct_nmlistacondicaoajuda,
     fct_nmcondcampochb,
     fct_tabelarelvisao,
     fct_nmcampo,
     fct_dsfiltrocabecalho)
  VALUES
    ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
     (SELECT vdr_idvisao
        FROM grevisaotab_vdr
       WHERE vdr_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'REQCOMPRA_RCO')),
     'Somente tot. atendida',
     1,
     0,
     '',
     '',
     '',
     'DECODE(IREQCOMPRA_IRC.IRC_STATUS,''T'',''S'', ''N'')',
     (SELECT trv_idtabelarelvisao
        FROM gretabelarelvisal_trv
       WHERE trv_nrvisao =
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela =
                     (SELECT tdr_idtabela
                        FROM gretabdicdados_tdr
                       WHERE tdr_nmtabela = 'REQCOMPRA_RCO'))
         AND trv_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'IREQCOMPRA_IRC')),
     'IREQCOMPRA_IRC.IRC_STATUS4',
     'Somente tot. atendida')
/

INSERT INTO grefiltrocampotab_fct
    (fct_idfiltrocampo,
     fct_nrvisao,
     fct_dsfiltro,
     fct_tpfiltro,
     fct_tpcampofiltro,
     fct_nmarquivoajuda,
     fct_nmlistatabela,
     fct_nmlistacondicaoajuda,
     fct_nmcondcampochb,
     fct_tabelarelvisao,
     fct_nmcampo,
     fct_dsfiltrocabecalho)
  VALUES
    ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
     (SELECT vdr_idvisao
        FROM grevisaotab_vdr
       WHERE vdr_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'REQCOMPRA_RCO')),
     'Somente parc. atendida',
     1,
     0,
     '',
     '',
     '',
     'DECODE(IREQCOMPRA_IRC.IRC_STATUS,''P'',''S'', ''N'')',
     (SELECT trv_idtabelarelvisao
        FROM gretabelarelvisal_trv
       WHERE trv_nrvisao =
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela =
                     (SELECT tdr_idtabela
                        FROM gretabdicdados_tdr
                       WHERE tdr_nmtabela = 'REQCOMPRA_RCO'))
         AND trv_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'IREQCOMPRA_IRC')),
     'IREQCOMPRA_IRC.IRC_STATUS5',
     'Somente parc. atendida')
/

INSERT INTO grefiltrocampotab_fct
    (fct_idfiltrocampo,
     fct_nrvisao,
     fct_dsfiltro,
     fct_tpfiltro,
     fct_tpcampofiltro,
     fct_nmarquivoajuda,
     fct_nmlistatabela,
     fct_nmlistacondicaoajuda,
     fct_nmcondcampochb,
     fct_tabelarelvisao,
     fct_nmcampo,
     fct_dsfiltrocabecalho)
  VALUES
    ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
     (SELECT vdr_idvisao
        FROM grevisaotab_vdr
       WHERE vdr_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'REQCOMPRA_RCO')),
     'Somente atend. com falta',
     1,
     0,
     '',
     '',
     '',
     'DECODE(IREQCOMPRA_IRC.IRC_STATUS,''F'',''S'', ''N'')',
     (SELECT trv_idtabelarelvisao
        FROM gretabelarelvisal_trv
       WHERE trv_nrvisao =
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela =
                     (SELECT tdr_idtabela
                        FROM gretabdicdados_tdr
                       WHERE tdr_nmtabela = 'REQCOMPRA_RCO'))
         AND trv_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'IREQCOMPRA_IRC')),
     'IREQCOMPRA_IRC.IRC_STATUS6',
     'Somente atend. com falta')
/

INSERT INTO grefiltrocampotab_fct
    (fct_idfiltrocampo,
     fct_nrvisao,
     fct_dsfiltro,
     fct_tpfiltro,
     fct_tpcampofiltro,
     fct_nmarquivoajuda,
     fct_nmlistatabela,
     fct_nmlistacondicaoajuda,
     fct_nmcondcampochb,
     fct_tabelarelvisao,
     fct_nmcampo,
     fct_dsfiltrocabecalho)
  VALUES
    ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
     (SELECT vdr_idvisao
        FROM grevisaotab_vdr
       WHERE vdr_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'REQCOMPRA_RCO')),
     'Somente cancelada',
     1,
     0,
     '',
     '',
     '',
     'DECODE(IREQCOMPRA_IRC.IRC_STATUS,''C'',''S'', ''N'')',
     (SELECT trv_idtabelarelvisao
        FROM gretabelarelvisal_trv
       WHERE trv_nrvisao =
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela =
                     (SELECT tdr_idtabela
                        FROM gretabdicdados_tdr
                       WHERE tdr_nmtabela = 'REQCOMPRA_RCO'))
         AND trv_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'IREQCOMPRA_IRC')),
     'IREQCOMPRA_IRC.IRC_STATUS7',
     'Somente cancelada')
/

INSERT INTO grefiltrocampotab_fct
    (fct_idfiltrocampo,
     fct_nrvisao,
     fct_dsfiltro,
     fct_tpfiltro,
     fct_tpcampofiltro,
     fct_nmarquivoajuda,
     fct_nmlistatabela,
     fct_nmlistacondicaoajuda,
     fct_nmcondcampochb,
     fct_tabelarelvisao,
     fct_nmcampo,
     fct_dsfiltrocabecalho)
  VALUES
    ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
     (SELECT vdr_idvisao
        FROM grevisaotab_vdr
       WHERE vdr_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'REQCOMPRA_RCO')),
     'Somente em compra',
     1,
     0,
     '',
     '',
     '',
     'DECODE(IREQCOMPRA_IRC.IRC_MAPA, NULL, ''N'', DECODE(IREQCOMPRA_IRC.IRC_STATUS,''A'', ''S'', ''N''))',
     (SELECT trv_idtabelarelvisao
        FROM gretabelarelvisal_trv
       WHERE trv_nrvisao =
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela =
                     (SELECT tdr_idtabela
                        FROM gretabdicdados_tdr
                       WHERE tdr_nmtabela = 'REQCOMPRA_RCO'))
         AND trv_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'IREQCOMPRA_IRC')),
     'IREQCOMPRA_IRC.IRC_STATUS8',
     'Somente em compra')
/

INSERT INTO grefiltrocampotab_fct
    (fct_idfiltrocampo,
     fct_nrvisao,
     fct_dsfiltro,
     fct_tpfiltro,
     fct_tpcampofiltro,
     fct_nmarquivoajuda,
     fct_nmlistatabela,
     fct_nmlistacondicaoajuda,
     fct_nmcondcampochb,
     fct_tabelarelvisao,
     fct_nmcampo,
     fct_dsfiltrocabecalho)
  VALUES
    ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
     (SELECT vdr_idvisao
        FROM grevisaotab_vdr
       WHERE vdr_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'REQCOMPRA_RCO')),
     'Somente atendida',
     1,
     0,
     '',
     '',
     '',
     'DECODE(IREQCOMPRA_IRC.IRC_STATUS,''T'',''S'',DECODE(IREQCOMPRA_IRC.IRC_STATUS,''F'',''S'',DECODE(IREQCOMPRA_IRC.IRC_STATUS, ''P'', ''S'', ''N'')))',
     (SELECT trv_idtabelarelvisao
        FROM gretabelarelvisal_trv
       WHERE trv_nrvisao =
             (SELECT vdr_idvisao
                FROM grevisaotab_vdr
               WHERE vdr_nrtabela =
                     (SELECT tdr_idtabela
                        FROM gretabdicdados_tdr
                       WHERE tdr_nmtabela = 'REQCOMPRA_RCO'))
         AND trv_nrtabela =
             (SELECT tdr_idtabela
                FROM gretabdicdados_tdr
               WHERE tdr_nmtabela = 'IREQCOMPRA_IRC')),
     'IREQCOMPRA_IRC.IRC_STATUS9',
     'Somente atendida')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 272878
PROMPT ======================================================================