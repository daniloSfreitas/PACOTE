PROMPT ======================================================================
PROMPT == DEMANDA......: 277163
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: Julian Alves
PROMPT == DATA.........: 29/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE PRC_EFDPROCESSA_RC190 (
 PSMECODIGO       IN CHAR
,PIDREGC100       IN NUMBER
,PSDF_SQDOCFIS IN NUMBER
) AS
vIDREGC190           NUMBER(9);
ERR_MSG VARCHAR2(500);
CURSOR CS_RC190_CUR IS
  SELECT  'C190'         AS REG
    ,DECODE(IDF.IDF_CSTICMS,'','',NVL(IDF.IDF_ORIGEM, (NVL(PRD.PRD_CST,'0'))) || IDF.IDF_CSTICMS) AS CST_ICMS
    , IDF.IDF_CFOP                         AS CFOP
    , TO_CHAR(ROUND((NVL(IDF.IDF_ALIQICMS,0)),2),'FM9999999999990D00')                   AS ALIQ_ICMS
    , TO_CHAR(ROUND(SUM(NVL(IDF.IDF_VLCONTABIL,0)),2),'FM9999999999990D00')              AS VL_OPR
    , TO_CHAR(ROUND(SUM(NVL(IDF.IDF_VLBCICMS,0)),2),'FM9999999999990D00')                AS VL_BC_ICMS
    , TO_CHAR(ROUND(SUM(NVL(IDF.IDF_VLICMS,0)),2),'FM9999999999990D00')                  AS VL_ICMS
    , TO_CHAR(ROUND(SUM(NVL(IDF.IDF_VLBCICMSST,0)),2),'FM9999999999990D00')              AS VL_BC_ICMS_ST
    , TO_CHAR(ROUND(SUM(NVL(IDF.IDF_VLICMSST,0)),2),'FM9999999999990D00')                AS VL_ICMS_ST
    , CASE
          WHEN ROUND(SUM(NVL(IDF.IDF_VLITEM - IDF.IDF_VLBCICMS,0)),2) > 0
           AND IDF.IDF_CSTICMS IN ('20', '70')
          THEN TO_CHAR(ROUND(SUM(NVL(IDF.IDF_VLITEM - IDF.IDF_VLBCICMS,0)),2),'FM9999999999990D00')
        ELSE TO_CHAR(0,'FM9999999999990D00') END                                         AS VL_RED_BC
    , TO_CHAR(ROUND(SUM(NVL(IDF.IDF_VLIPI,0)),2),'FM9999999999990D00')                   AS VL_IPI
    , NVL(SOF.SOF_CODOBS, NULL)                                                          AS COD_OBS
  FROM SPEDITDOCFIS_IDF IDF
     , PRODUTO_PRD PRD
     , (SELECT * FROM SPEDOBSDOCFIS_SOF SOF WHERE SOF.SOF_SQDOCFIS = PSDF_SQDOCFIS AND ROWNUM = 1) SOF
  WHERE IDF.IDF_SQDOCFIS = PSDF_SQDOCFIS
  AND PRD.PRD_ITEM = IDF.IDF_ITEM
   GROUP BY
      DECODE(IDF.IDF_CSTICMS,'','',NVL(IDF.IDF_ORIGEM, (NVL(PRD.PRD_CST,'0'))) || IDF.IDF_CSTICMS)
    , IDF.IDF_CFOP
    , IDF.IDF_ALIQICMS
    , IDF.IDF_CSTICMS
    , NVL(SOF.SOF_CODOBS, NULL);
  TYPE TP_CS_RC190 IS TABLE OF CS_RC190_CUR%ROWTYPE INDEX BY PLS_INTEGER;
  TBL_CS_RC190 TP_CS_RC190;
BEGIN
  -- ABRE CURSOR REGISTRO C190
  OPEN CS_RC190_CUR;
  LOOP
    FETCH CS_RC190_CUR BULK COLLECT INTO TBL_CS_RC190 LIMIT 2000;
      EXIT WHEN TBL_CS_RC190.COUNT=0;
      FOR IDXRC190 IN 1..TBL_CS_RC190.COUNT
       LOOP
        BEGIN
        vIDREGC190 := NULL;
        INSSPEDEFDREGANALV10_RC190(  vIDREGC190
                                    ,PIDREGC100
                                    ,PSMECODIGO
                                    ,TBL_CS_RC190(IDXRC190).REG
                                    ,TBL_CS_RC190(IDXRC190).CST_ICMS
                                    ,TBL_CS_RC190(IDXRC190).CFOP
                                    ,TBL_CS_RC190(IDXRC190).ALIQ_ICMS
                                    ,TBL_CS_RC190(IDXRC190).VL_OPR
                                    ,TBL_CS_RC190(IDXRC190).VL_BC_ICMS
                                    ,TBL_CS_RC190(IDXRC190).VL_ICMS
                                    ,TBL_CS_RC190(IDXRC190).VL_BC_ICMS_ST
                                    ,TBL_CS_RC190(IDXRC190).VL_ICMS_ST
                                    ,TBL_CS_RC190(IDXRC190).VL_RED_BC
                                    ,TBL_CS_RC190(IDXRC190).VL_IPI
                                    ,TBL_CS_RC190(IDXRC190).COD_OBS);
        END;
       END LOOP;
  END LOOP;
  CLOSE CS_RC190_CUR;
EXCEPTION
  WHEN OTHERS
   THEN BEGIN
     ERR_MSG := SUBSTR('Mensagem do Sistema: "' || SQLERRM,1,499) || '"';
     IF CS_RC190_CUR%ISOPEN
      THEN CLOSE CS_RC190_CUR; END IF;
     RAISE_APPLICATION_ERROR(-20000,ERR_MSG);
   END;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 277163
PROMPT ======================================================================