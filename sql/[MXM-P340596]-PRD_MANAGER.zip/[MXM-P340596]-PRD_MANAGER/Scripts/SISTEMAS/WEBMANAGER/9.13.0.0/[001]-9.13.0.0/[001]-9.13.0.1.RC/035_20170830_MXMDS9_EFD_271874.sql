PROMPT ======================================================================
PROMPT == DEMANDA......: 271874
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 25/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE EFDPROC_APUR_ICMSST_SALDO
(PSAI_SQAPUICMS        IN NUMBER,
 PVL_DEVOL_ST          OUT NUMBER,
 PVL_RESSARC_ST        OUT NUMBER,
 PVL_OUT_CRED_ST       OUT NUMBER,
 PVL_RETENCAO_ST       OUT NUMBER,
 PDEB_ESP_ST           OUT NUMBER
)
AS
 --DECLARACAO DE VARIAVEIS
 VSAI_SQAPUICMS  NUMBER;
 --DECLARACAO DE CURSORES
 CURSOR CUR_SPEDAPUICMS_SAI
  IS
    SELECT SUM(VL_DEVOL_ST)       AS VL_DEVOL_ST
         , SUM(VL_RESSARC_ST)     AS VL_RESSARC_ST
         , SUM(VL_OUT_CRED_ST)    AS VL_OUT_CRED_ST
         , SUM(VL_RETENCAO_ST)    AS VL_RETENCAO_ST
         , SUM(DEB_ESP_ST)        AS DEB_ESP_ST
    FROM (
           SELECT CASE
              WHEN SDF_MODELO IN ('01','1B','04','55')
                     AND IDF_CFOP IN ('1410','1411','1660','1661','1662','2410','2411','2660','2661','2662')
                     --AND NOT SDF_SITDOC IN ('01','07')
              THEN IDF_VLICMSST
              ELSE 0
            END         AS VL_DEVOL_ST
          , CASE
              WHEN SDF_MODELO IN ('01','1B','04','55')
                     AND IDF_CFOP IN ('1603','2603')
                     --AND NOT SDF_SITDOC IN ('01','07')
            THEN IDF_VLICMSST
            ELSE 0
            END         AS VL_RESSARC_ST
          , CASE
              WHEN SDF_MODELO IN ('01','1B','04','55')
                     AND SUBSTR(IDF_CFOP,1,1) IN ('1','2')
                     AND NOT IDF_CFOP IN ('1410','1411','1660','1661','1662','2410','2411','2660','2661','2662')
                     --AND NOT SDF_SITDOC IN ('01','07')
            THEN IDF_VLICMSST
            ELSE 0
            END          AS VL_OUT_CRED_ST
          , CASE
              WHEN SUBSTR(IDF_CFOP,1,1) IN ('5','6')
                     --AND NOT SDF_SITDOC IN ('01','07')
            THEN IDF_VLICMSST
            ELSE 0
            END          AS VL_RETENCAO_ST
          , CASE
              WHEN TPO_TIPO = 'S'
               AND SDF_SITDOC IN ('01','07')
            THEN IDF_VLICMSST
            ELSE 0
            END          AS DEB_ESP_ST
                , SAI_DATAINI        AS DT_INICIAL
                , SAI_DATAFIM        AS DT_FINAL
                , SAI_ICMSTPOPERACAO AS TPAPURACAO
                , SAI_SQAPUICMS      AS SQAPURACAO
                , SAI_CDEMPRESA      AS CDEMPRESA
                , SAI_CDFILIAL       AS CDFILIAL
                , SAI_UF             AS UF
             FROM SPEDDOCFIS_SDF       S
                , SPEDITDOCFIS_IDF
                , TPOPER_TPO
                , SPEDAPUICMS_SAI
                , SPEDPAREMPRESA_PEMP
                , CLIENTE_CLI          CLI
                , FORNEC_FOR           FORN
                , CLE_CLE              CLE
                , FOE_FOE              FOE
            WHERE SDF_SQDOCFIS = IDF_SQDOCFIS
              AND SDF_TPOP = TPO_CODIGO
              AND SAI_ICMSTPOPERACAO = 1
              AND SDF_DATAESCR >= SAI_DATAINI
              AND SDF_DATAESCR <= SAI_DATAFIM
              AND SDF_CDEMPRESA = SAI_CDEMPRESA
              AND SDF_CDFILIAL  = SAI_CDFILIAL
              AND SAI_SQAPUICMS = VSAI_SQAPUICMS
              AND PEMP_CDEMPRESA = SAI_CDEMPRESA
              AND PEMP_CDFILIAL  = SAI_CDFILIAL
              AND (   (   (PEMP_VBINFICMS11503 = 'N')
                       OR (PEMP_VBINFICMS11503 IS NULL))
                   OR (    (PEMP_VBINFICMS11503 = 'S')
                       AND (NOT (    (TPO_NotaFiscal = 'T')
                                 AND (TPO_TIPO = 'S')))))
               AND S.SDF_CDCLIFOR = CLI.CLI_CODIGO(+)
               AND S.SDF_CDCLIFOR = FORN.FOR_CODIGO(+)
               AND S.SDF_CDENDCLIFOR = FOE.FOE_CDEND(+)
               AND S.SDF_CDCLIFOR = CLE.CLE_CODIGO(+)
               AND S.SDF_CDENDCLIFOR = CLE.CLE_CDEND(+)
               AND S.SDF_CDCLIFOR = FOE.FOE_CODIGO(+)
               AND S.SDF_CDENDCLIFOR = FOE.FOE_CDEND(+)
               AND (SAI_UF = DECODE(SDF_CDENDCLIFOR, NULL, DECODE(SDF_CLIFOR, 'C', CLI_UF, FOR_UF), DECODE(SDF_CLIFOR, 'C', CLE_UF, FOE_UF)))
           UNION ALL
           SELECT 0 AS VL_DEVOL_ST
                , 0 AS VL_RESSARC_ST
                , 0 AS VL_OUT_CRED_ST
                , IDC_VLICMSST AS VL_RETENCAO_ST
                , 0 AS DEB_ESP_ST
          , SAI_DATAINI        AS DT_INICIAL
                , SAI_DATAFIM        AS DT_FINAL
                , SAI_ICMSTPOPERACAO AS TPAPURACAO
                , SAI_SQAPUICMS      AS SQAPURACAO
                , SAI_CDEMPRESA      AS CDEMPRESA
                , SAI_CDFILIAL       AS CDFILIAL
                , SAI_UF             AS UF
             FROM SPEDDOCFISCON_DFC
                , SPEDITDOCCON_IDC
                , SPEDTABUF_TUF
                , SPEDTABMUNICIBGE_TMI
                , SPEDAPUICMS_SAI
                , TPOPER_TPO
                , SPEDPAREMPRESA_PEMP
            WHERE DFC_SQDOCFISCON = IDC_SQDOCFISCON
              AND SAI_ICMSTPOPERACAO = 1
              AND DFC_DATA >= SAI_DATAINI
              AND DFC_DATA <= SAI_DATAFIM
              AND DFC_CDEMPRESA = SAI_CDEMPRESA
              AND DFC_CDFILIAL  = SAI_CDFILIAL
              AND DFC_CODMUN = TMI_CODIGO
              AND TMI_CODIGOUF = TUF_CODIGO
              AND TUF_SIGLA = SAI_UF
              AND SUBSTR(IDC_CFOP,1,1) IN ('5','6')
              AND SAI_SQAPUICMS = VSAI_SQAPUICMS
              AND DFC_TPOP = TPO_CODIGO
              AND PEMP_CDEMPRESA = SAI_CDEMPRESA
              AND PEMP_CDFILIAL  = SAI_CDFILIAL
              AND (   (   (PEMP_VBINFICMS11503 = 'N')
                       OR (PEMP_VBINFICMS11503 IS NULL))
                   OR (    (PEMP_VBINFICMS11503 = 'S')
                       AND (NOT (    (TPO_NotaFiscal = 'T')
                                 AND (TPO_TIPO = 'S')))))
             );
BEGIN
  VSAI_SQAPUICMS := PSAI_SQAPUICMS;
  FOR REC_SPEDAPUICMS_SAI IN CUR_SPEDAPUICMS_SAI LOOP
    PVL_DEVOL_ST     := REC_SPEDAPUICMS_SAI.VL_DEVOL_ST;
    PVL_RESSARC_ST   := REC_SPEDAPUICMS_SAI.VL_RESSARC_ST;
    PVL_OUT_CRED_ST  := REC_SPEDAPUICMS_SAI.VL_OUT_CRED_ST;
    PVL_RETENCAO_ST  := REC_SPEDAPUICMS_SAI.VL_RETENCAO_ST;
    PDEB_ESP_ST      := REC_SPEDAPUICMS_SAI.DEB_ESP_ST;
  END LOOP;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 271874
PROMPT ======================================================================