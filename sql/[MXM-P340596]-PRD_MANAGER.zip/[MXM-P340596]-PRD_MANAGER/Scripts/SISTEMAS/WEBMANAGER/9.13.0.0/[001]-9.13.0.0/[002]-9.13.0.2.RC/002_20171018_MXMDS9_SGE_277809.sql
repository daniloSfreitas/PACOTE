PROMPT ======================================================================
PROMPT == DEMANDA......: 277809
PROMPT == SISTEMA......: Estoque
PROMPT == RESPONSAVEL..: JOSE BARBOSA DA SILVA JUNIOR
PROMPT == DATA.........: 22/09/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DROP INDEX NOTASRATEIO_NTR_PKX
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 277809
PROMPT ======================================================================