PROMPT ======================================================================
PROMPT == DEMANDA......: 274097
PROMPT == SISTEMA......: Integra��o Padr�o
PROMPT == RESPONSAVEL..: GABRIEL SPINOLA TRINDADE MARINHO
PROMPT == DATA.........: 22/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

alter table TI_ARQMOVIST_TAMT add TAMT_DTCOMPETENCIA VARCHAR2(8)
/

comment on column TI_ARQMOVIST_TAMT.TAMT_DTCOMPETENCIA
  is 'Data de Compet�ncia que ser� utilizada para contabiliza��o e escritura��o.'
/

ALTER TABLE TI_ARQMOVIST_TAMT MODIFY(TAMT_NOME VARCHAR2(40 BYTE))
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 274097
PROMPT ======================================================================