PROMPT ======================================================================
PROMPT == DEMANDA......: 278140
PROMPT == SISTEMA......: Integra��o com EFD
PROMPT == RESPONSAVEL..: Julian Alves
PROMPT == DATA.........: 13/09/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM LAYOUTMOD_LYM WHERE LYM_MODELO = 'EFD - DOC. FISCAL' AND LYM_CAMPO = 'TSDF_TAXASEGMOEDA' AND LYM_SEQ = 73 AND LYM_INDEX = 0
/

INSERT INTO LAYOUTMOD_LYM (LYM_MODELO, LYM_CAMPO, LYM_SEQ, LYM_DESCRICAO, LYM_TIPO, LYM_TAM, LYM_DEC, LYM_INDEX)
VALUES ('EFD - DOC. FISCAL','TSDF_TAXASEGMOEDA',73,'Taxa da Segunda Moeda','C',10,2,0)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 278140
PROMPT ======================================================================