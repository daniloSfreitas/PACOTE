PROMPT ======================================================================
PROMPT == DEMANDA......: 274472
PROMPT == SISTEMA......: Cobranca Escritural
PROMPT == RESPONSAVEL..: JOAO PAULO RODRIGUES JIMENEZ
PROMPT == DATA.........: 17/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_PARNNRENDIMENTO
 (cCdCli     IN CHAR,
  cNoTit     IN CHAR,
  cIdPort    IN CHAR,
  cCart      IN CHAR)
  RETURN VARCHAR
IS
BEGIN
  RETURN (cCdCli||'^1^'||cNoTit||'^2^'||cIdPort||'^3^'||cCart||'^4^');
END;
/

CREATE OR REPLACE FUNCTION GET_NNRENDIMENTO
  (pCdEmpBco   IN CHAR,                -- Codigo da  Empresa no Banco (conv�nio)
   pCdConta    IN CHAR,                -- Codigo da Conta Corrente Banco
   pCtaCodigo  IN CHAR,                -- Codigo da Conta Manager
   pIdPort     IN CHAR,                -- nosso n�mero do t�tulo
   pCDCliente  IN CHAR,                -- C�digo do Cliente
   pNOTitulo   IN CHAR,                -- Numero do T�tulo
   pCarteira   IN CHAR,                -- Carteira (parametro da tela)
   pAgencia    IN CHAR,
   pGetDigito  IN BOOLEAN DEFAULT TRUE)-- Retorna com DV do nosso numero
  RETURN VARCHAR
IS
  ProxNum             VARCHAR2(18);
  MinNN               VARCHAR2(18);
  MaxNN               VARCHAR2(18);
  NossoNumero         VARCHAR2(18);
  sIdPort             VARCHAR2(18);
  VR_CDAGENCIA        VARCHAR2(50);
  CURSOR GETNNATUALCCORRENTE IS
  SELECT CTA_NNATUAL, TO_CHAR(CTA_NNMINIMO), TO_CHAR(CTA_NNMAXIMO)
    FROM CONTA_CTA
   WHERE CTA_CODIGO = pCtaCodigo;
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  VR_CDAGENCIA := SUBSTR(pAgencia,1,4);
  IF pIdPort IS NULL THEN
    OPEN GETNNATUALCCORRENTE;
    FETCH GETNNATUALCCORRENTE
    INTO ProxNum,MinNN,MaxNN;
    --O nosso n�mero do banco rendimento � por conta somente
    --utiliza um range espec�fico com sequencial de 10 mais o DV.
    IF MinNN IS NULL THEN
      MinNN   := '0000000001';
    END IF;
    IF MaxNN IS NULL THEN
      MaxNN   := '9999999999';
    END IF;
    IF ProxNum IS NULL THEN
      ProxNum := MinNN;
    END IF;
    IF TO_NUMBER(ProxNum) > TO_NUMBER(MaxNN) THEN
      ProxNum := MinNN;
    END IF;
    --Para o calculo do DV o tamanho do NN deve ser de 10 caracteres com zeros a esquerda,
    --tamb�m � necess�rio adicionar agencia e carteira antes do sequencial para o calculo
    --AAAACCCNNNNNNNNNN
    --AAAA O c�digo da ag�ncia do t�tulo, sem dv.
    --CCC O c�digo da carteira (por exemplo, 121)
    --NNNNNNNNNN O nosso n�mero, sem DV
    WHILE LENGTH(ProxNum) < 10 LOOP
      ProxNum := '0' || ProxNum;
    END LOOP;
    IF (NOT pGetDigito) THEN
      NossoNumero := ProxNum;
    ELSE
      NossoNumero := ProxNum || '-' || get_mod10_campos033(VR_CDAGENCIA||pCarteira||ProxNum);
    END IF;
    -- Atualiza o t�tulo com o nosso n�mero gerado e o portador.
    UPDATE TITCR_TCR
       SET TCR_IDPORTADO = REPLACE(NossoNumero,'-'), TCR_PORTADOR = pCtaCodigo
     WHERE TCR_CDCLIENTE = pCDCliente
       AND TCR_NOTITULO  = pNOTitulo;
    -- Atualiza o nosso numero na conta corrente
    UPDATE CONTA_CTA
       SET CTA_NNATUAL = TO_NUMBER(ProxNum) +1
     WHERE CTA_CODIGO  = pCtaCodigo;
    COMMIT;
    RETURN NossoNumero;
  ELSE
    --Para o boleto tem que ir o DV com o "-"
    IF INSTR(pIdPort,'-')>0 THEN
      sIdPort := pIdPort;
    ELSE
      sIdPort := SUBSTR(pIdPort,1,(LENGTH(pIdPort)-1)) ||'-'|| SUBSTR(pIdPort,LENGTH(pIdPort),1);
    END IF;
    RETURN sIdPort;
  END IF;
END;
/

CREATE OR REPLACE FUNCTION GET_NNUMERO
  (pBanco      IN CHAR, -- Banco da Conta Corrente
   pCdEmpBco   IN CHAR, -- Codigo da  Empresa no Banco (conv�nio)
   pCdConta    IN CHAR, -- Codigo da Conta Banco
   pCtaCodigo  IN CHAR, --C�digo da Conta Manager
   pIdPort     IN CHAR, -- nosso n�mero do t�tulo
   pCDCliente  IN CHAR, -- C�digo do Cliente
   pNOTitulo   IN CHAR, -- Numero do T�tulo
   pGetDigito  IN BOOLEAN DEFAULT TRUE,-- Retorna com DV do nosso numero
   pCarteira   IN CHAR,
   pAgencia    IN CHAR)
  RETURN VARCHAR
IS
BEGIN
 IF pBanco = '001' THEN
   RETURN GET_NNBRASIL(pCdEmpBco,pCdConta,pCtaCodigo,pIdPort,pCDCliente,pNOTitulo,pGetDigito);
 ELSIF pBanco = '237' THEN
   RETURN GET_NNBRADESCO(pCdEmpBco,pCdConta,pCtaCodigo,pIdPort,pCDCliente,pNOTitulo,pCarteira,pGetDigito);
 ELSIF pBanco = '341' THEN
   RETURN GET_NNITAU(pCdEmpBco,pCdConta,pCtaCodigo,pIdPort,pCDCliente,pNOTitulo,pCarteira,pAgencia,pGetDigito);
 ELSIF pBanco = '033' THEN
   RETURN GET_NNSANTANDER(pCdEmpBco,pCdConta,pCtaCodigo,pIdPort,pCDCliente,pNOTitulo,pCarteira,pGetDigito);
 ELSIF pBanco = '104' THEN
   RETURN GET_NNCAIXA(pCdEmpBco,pCdConta,pCtaCodigo,pIdPort,pCDCliente,pNOTitulo,pCarteira,pGetDigito);
 ELSIF pBanco = '399' THEN
   RETURN GET_NNHSBC(pCdEmpBco,pCdConta,pCtaCodigo,pIdPort,pCDCliente,pNOTitulo,pCarteira,pGetDigito);
 ELSIF pBanco = '755' THEN
   RETURN GET_NNBAML(pCdEmpBco,pCdConta,pCtaCodigo,pIdPort,pCDCliente,pNOTitulo,pCarteira,pGetDigito);
 ELSIF pBanco = '633' THEN
   IF pCarteira IN ('02','06','07','09') THEN
     RETURN GET_NNRENDIMENTOBRADESCO(pCdEmpBco,pCdConta,pCtaCodigo,pIdPort,pCDCliente,pNOTitulo,pCarteira,pGetDigito);
   ELSIF (pCarteira = '121') THEN
     RETURN GET_NNRENDIMENTO(pCdEmpBco,pCdConta,pCtaCodigo,pIdPort,pCDCliente,pNOTitulo,pCarteira,pAgencia,pGetDigito);
   ELSE
     RETURN GET_NNRENDIMENTOSANTANDER(pCdEmpBco,pCdConta,pCtaCodigo,pIdPort,pCDCliente,pNOTitulo,pCarteira,pGetDigito);
   END IF;
 ELSIF pBanco = '422' THEN
   RETURN GET_NNSAFRA(pCdEmpBco,pCdConta,pCtaCodigo,pIdPort,pCDCliente,pNOTitulo,pCarteira,pGetDigito);
 ELSE
   RETURN '000';
 END IF;
END;
/

CREATE OR REPLACE FUNCTION GET_BARCODE
  (PT_CdEmpBco  IN CHAR,
   PT_CdBanco   IN CHAR,   -- Codigo do Banco    -- CTA_CDBANCO
   PT_Moeda     IN CHAR,   -- Moeda              -- TCR_MOEDA
   PT_DataVcto  IN DATE,   -- Data de Vencimento -- TCR_DTVENCIME
   PT_ValorTit  IN NUMBER, -- Valor do Titulo    -- TCR_VLRTITULO
   PT_NN        IN VARCHAR,-- Nosso Numero Gerado pelas fun��es de cada banco sem o DV
   PT_NNDV      IN VARCHAR DEFAULT NULL,-- Nosso Numero Gerado pelas fun��es de cada banco com o DV
   PT_Agencia   IN CHAR,   -- Numero da Agencia  -- TCR_AGENCIA
   PT_Conta     IN CHAR,   -- Conta Corrente
   PT_Carteira  IN CHAR)   -- Carteira
  RETURN VARCHAR
IS
 VR_FtVencime    NUMBER(10);
 VR_DvBarcode    VARCHAR2(50);
 VR_Dv1Barcode   VARCHAR2(1);
 VR_Dv2Barcode   VARCHAR2(1);
 VR_Barcode      VARCHAR2(50);
 VR_VlrTitTemp   VARCHAR2(50);
 VR_AgenciaTemp  VARCHAR2(50);
 VR_CdEmpBco     VARCHAR2(20);
BEGIN
   VR_FtVencime   := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
   VR_AgenciaTemp := SUBSTR(PT_Agencia,1,4);
   IF PT_CdBanco = '001' THEN
     --Atende a conv�nios de 4 e 6 posi��es do banco do brasil
     IF LENGTH(PT_CdEmpBco) = 4 THEN
       VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
       VR_DvBarcode  := PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NN || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),8,'0') || PT_Carteira;
       VR_DvBarcode  := mod11_barcode(VR_DvBarcode);
       VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || VR_DvBarcode || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NN || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),8,'0') || PT_Carteira,' ');
     ELSIF LENGTH(PT_CdEmpBco) = 6 THEN
       VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
       VR_DvBarcode  := PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NN || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),8,'0') || PT_Carteira;
       VR_DvBarcode  := mod11_barcode(VR_DvBarcode);
       VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || VR_DvBarcode || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NN || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),8,'0') || PT_Carteira,' ');
     END IF;
   ELSIF PT_CdBanco = '237' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || LPAD(VR_AgenciaTemp,4,'0') || LPAD(PT_Carteira,2,'0') || LPAD(PT_NN,11,'0')  || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0',' ');
     VR_DvBarcode  := MOD11_BARCODE_237(VR_Barcode);
     VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,39),' ');
   ELSIF PT_CdBanco = '341' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Dv1Barcode := GET_MOD10_CAMPOS033(VR_AgenciaTemp || SUBSTR(PT_Conta,1,5) || LPAD(PT_Carteira,3,'0') || PT_NN);
     VR_Dv2Barcode := GET_MOD10_CAMPOS033(VR_AgenciaTemp || SUBSTR(PT_Conta,1,5));
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || LPAD(PT_Carteira,3,'0') || PT_NN || VR_Dv1Barcode || VR_AgenciaTemp || SUBSTR(PT_Conta,1,5) || VR_Dv2Barcode || '000',' ');
     VR_DvBarcode  := MOD11_BARCODE_237(VR_Barcode);
     VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,44),' ');
   ELSIF PT_CdBanco = '033' THEN
     VR_CdEmpBco   := LPAD(SUBSTR(PT_CdEmpBco,6,7),7,'0');
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_DvBarcode  := PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '9' || PADL(VR_CdEmpBco,7,'0') || PADL(PT_NNDV,13,'0') || '0' || PT_Carteira;
     VR_DvBarcode  := mod11_barcode_033(VR_DvBarcode);
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || VR_DvBarcode || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '9' || PADL(VR_CdEmpBco,7,'0') || PADL(PT_NNDV,13,'0') || '0' || PT_Carteira,' ');
   ELSIF PT_CdBanco = '104' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Barcode    := PADL(PT_CdEmpBco || GET_MOD11_NN104(PT_CdEmpBco),7,'0') || PADL(SUBSTR(PT_NN,3,3),3,'0') || SUBSTR(PT_Carteira,1,1) || PADL(SUBSTR(PT_NN,6,3),3,'0') || SUBSTR(PT_Carteira,2,1) || PADL(SUBSTR(PT_NN,9,9),9,'0');
     VR_Dv1Barcode := GET_MOD11_NN104(VR_BarCode);
     VR_DvBarcode  := PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || VR_Barcode || VR_Dv1Barcode;
     VR_DvBarcode  := mod11_barcode(VR_DvBarcode);
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || VR_DvBarcode || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || VR_Barcode || VR_Dv1Barcode, ' ');
   ELSIF PT_CdBanco = '399' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NNDV || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,7),7,'0') || PT_Carteira || '1',' ');
     VR_DvBarcode  := MOD11_BARCODE_399(VR_Barcode);
     VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,44),' ');
   ELSIF PT_CdBanco = '755' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PADL(PT_CdEmpBco,12,'0') || LPAD(PT_NN,10,'0') || PT_Carteira || '4', ' ');
     VR_DvBarcode  := mod11_barcode(VR_Barcode);
     VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,44),' ');
   ELSIF PT_CdBanco = '633' THEN
     IF PT_Carteira IN ('02','06','07','09') THEN
       VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
       VR_Barcode    := REPLACE('237' || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || LPAD(VR_AgenciaTemp,4,'0') || LPAD(PT_Carteira,2,'0') || LPAD(PT_NN,11,'0')  || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0',' ');
       VR_DvBarcode  := MOD11_BARCODE_237(VR_Barcode);
       VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,39),' ');
     ELSIF (PT_Carteira = '121') THEN
       VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
       VR_Barcode    := REPLACE('633' || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || LPAD(VR_AgenciaTemp,4,'0') || LPAD(PT_Carteira,3,'0') || LPAD(PT_CdEmpBco,7,'0') || LPAD(PT_NNDV,11,'0'),' ');
       VR_DvBarcode  := MOD11_BARCODE_237(VR_Barcode);
       VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,39),' ');
     ELSE
       VR_CdEmpBco   := LPAD(SUBSTR(PT_CdEmpBco,6,7),7,'0');
       VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
       VR_DvBarcode  := '033' || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '9' || PADL(VR_CdEmpBco,7,'0') || PADL(PT_NNDV,13,'0') || '0' || PT_Carteira;
       VR_DvBarcode  := mod11_barcode_033(VR_DvBarcode);
       VR_Barcode    := REPLACE('033' || PT_Moeda || VR_DvBarcode || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '9' || PADL(VR_CdEmpBco,7,'0') || PADL(PT_NNDV,13,'0') || '0' || PT_Carteira,' ');
     END IF;
   ELSIF PT_CdBanco = '422' THEN
     VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
     VR_Barcode    := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '7' || LPAD(REPLACE(PT_Agencia,'-',''),5,'0') || LPAD(REPLACE(PT_Conta,'-',''),9,'0') || LPAD(PT_NNDV,9,'0') || '2',' ');
     VR_DvBarcode  := GET_MOD11_BARCODE_422(VR_Barcode);
     VR_Barcode    := REPLACE(SUBSTR(VR_Barcode,1,4) || VR_DvBarcode || SUBSTR(VR_Barcode,5,39),' ');
   END IF;
   RETURN VR_Barcode;
END;
/

CREATE OR REPLACE FUNCTION GET_LINHADIGITAVEL
  (PT_CdEmpBco  IN CHAR DEFAULT NULL, --Codigo da  Empresa no Banco (CTA_CDEMPBCO)
   PT_CdBanco   IN CHAR,        -- Codigo do Banco    -- CTA_CDBANCO
   PT_Moeda     IN CHAR,        -- Moeda              -- TCR_MOEDA
   PT_NN        IN VARCHAR,           -- Nosso Numero Gerado pelas fun��es de cada banco sem o DV
   PT_NNDV      IN VARCHAR DEFAULT NULL, -- Nosso Numero Gerado pelas fun��es de cada banco com o DV
   PT_DataVcto  IN DATE,        -- Data de Vencimento -- TCR_DTVENCIME
   PT_ValorTit  IN NUMBER,      -- Valor do Titulo    -- TCR_VLRTITULO
   PT_BARCODE   IN VARCHAR2,
   PT_Carteira  IN CHAR,
   PT_Agencia   IN CHAR,
   PT_Conta     IN CHAR)
  RETURN VARCHAR
IS
 VR_LINHAD       VARCHAR2(50);
 VR_DVCAMPO1     CHAR;
 VR_DVCAMPOS1    VARCHAR2(2);
 VR_DVCAMPOS2    VARCHAR2(2);
 VR_DVCAMPOS3    VARCHAR2(2);
 VR_FtVencime    NUMBER(10);
 VR_VlrTitTemp   VARCHAR2(50);
 VR_AgenciaTemp  VARCHAR2(50);
 VR_CAMPO1       VARCHAR2(40);
 VR_CAMPO2       VARCHAR2(40);
 VR_CAMPO3       VARCHAR2(40);
 VR_CAMPO4       VARCHAR2(40);
 VR_CAMPO5       VARCHAR2(40);
 VR_STRTEMP      VARCHAR2(44);
 VR_DIGITAOCDBARRAS CHAR;
BEGIN
  VR_AgenciaTemp := SUBSTR(PT_Agencia,1,4);
  IF PT_CdBanco = '341' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_STRTEMP := PT_CdBanco || PT_Moeda || SUBSTR(LPAD(PT_Carteira,3,'0'),1,3) || SUBSTR(PT_NNDV,1,2);
    VR_CAMPO1 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_STRTEMP := SUBSTR(PT_NNDV,1,7) || SUBSTR(VR_AgenciaTemp,1,3);
    VR_CAMPO2 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_STRTEMP := SUBSTR(VR_AgenciaTemp,4,1) || REPLACE(SUBSTR(PT_Conta,1,6),'-') || '000';
    VR_CAMPO3 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || VR_FtVencime || VR_VlrTitTemp || SUBSTR(LPAD(PT_Carteira,3,'0'),1,3) || SUBSTR(PT_NNDV,1,9) || VR_AgenciaTemp || PT_Conta || '000',' ');
    VR_CAMPO4 := mod11_barcode_033(VR_STRTEMP);
    VR_LINHAD:= REPLACE(VR_CAMPO1 || VR_CAMPO2 || VR_CAMPO3 || VR_CAMPO4 || VR_CAMPO5,' ');
  END IF;
  IF PT_CdBanco = '033' THEN
    VR_STRTEMP := PT_CdBanco || PT_Moeda || '9' || SUBSTR(PT_CdEmpBco,6,4);
    VR_CAMPO1 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_STRTEMP := SUBSTR(PT_CdEmpBco,10,3) || SUBSTR(PT_NNDV,1,7);
    VR_CAMPO2 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_STRTEMP := SUBSTR(PT_NNDV,8,6) || '0' || SUBSTR(PT_Carteira,1,3);
    VR_CAMPO3 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_CAMPO4 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || VR_FtVencime || VR_VlrTitTemp || '9' || SUBSTR(PT_CdEmpBco,6,7)  || SUBSTR(PT_NNDV,1,13) || '0' || SUBSTR(PT_Carteira,1,3),' ');
    VR_DIGITAOCDBARRAS := mod11_barcode_033(VR_STRTEMP);
    VR_LINHAD:= REPLACE(VR_CAMPO1 || VR_CAMPO2 || VR_CAMPO3 || VR_DIGITAOCDBARRAS || VR_CAMPO4,' ');
  ELSIF PT_CdBanco = '237' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || VR_AgenciaTemp || PT_Carteira || PT_NN || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0',' ');
    VR_CAMPO1 := PT_CdBanco || PT_Moeda || VR_AgenciaTemp || SUBSTR(PT_Carteira,1,1);
    VR_DVCAMPOS1 := GET_MOD10_CAMPOS033(VR_CAMPO1);
    VR_CAMPO2 := SUBSTR(PT_Carteira,2,1) || SUBSTR(PT_NN,1,9);
    VR_DVCAMPOS2 := GET_MOD10_CAMPOS033(VR_CAMPO2);
    VR_CAMPO3 := SUBSTR(PT_NN,10,2) || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0';
    VR_DVCAMPOS3 := GET_MOD10_CAMPOS033(VR_CAMPO3);
    VR_CAMPO4 := MOD11_BARCODE_237(VR_STRTEMP);
    VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_LINHAD := REPLACE(VR_CAMPO1 || VR_DVCAMPOS1 || VR_CAMPO2 || VR_DVCAMPOS2 || VR_CAMPO3 || VR_DVCAMPOS3 || VR_CAMPO4 || VR_CAMPO5,' ');
  ELSIF PT_CdBanco = '399' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PT_NNDV || VR_AgenciaTemp || LPAD(SUBSTR(PT_Conta,1,7),7,'0') || PT_Carteira || '1',' ');
    VR_CAMPO1 := PT_CdBanco || PT_Moeda || SUBSTR(PT_NNDV,1,5);
    VR_DVCAMPOS1 := GET_MOD10_CAMPOS399(VR_CAMPO1);
    VR_CAMPO2 := SUBSTR(PT_NNDV,6,6) || VR_AgenciaTemp;
    VR_DVCAMPOS2 := GET_MOD10_CAMPOS399(VR_CAMPO2);
    VR_CAMPO3 := LPAD(SUBSTR(PT_Conta,1,7),7,'0') || SUBSTR(PT_Carteira,1,2) || '1';
    VR_DVCAMPOS3 := GET_MOD10_CAMPOS399(VR_CAMPO3);
    VR_CAMPO4 := MOD11_BARCODE_399(VR_STRTEMP);
    VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_LINHAD := REPLACE(VR_CAMPO1 || VR_DVCAMPOS1 || VR_CAMPO2 || VR_DVCAMPOS2 || VR_CAMPO3 || VR_DVCAMPOS3 || VR_CAMPO4 || VR_CAMPO5,' ');
  ELSIF PT_CdBanco = '755' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || PADL(PT_CdEmpBco,12,'0') || PADL(PT_NN,10,'0') || PT_Carteira || '4', ' ');
    VR_CAMPO1 := PT_CdBanco || PT_Moeda || SUBSTR(PT_CdEmpBco,1,5);
    VR_DVCAMPOS1 := GET_MOD10_CAMPOS033(VR_CAMPO1);
    VR_CAMPO2 := SUBSTR(PT_CdEmpBco,6,7) || SUBSTR(PT_NN,1,3);
    VR_DVCAMPOS2 := GET_MOD10_CAMPOS033(VR_CAMPO2);
    VR_CAMPO3 := SUBSTR(PT_NN,4,7) || PT_Carteira || '4';
    VR_DVCAMPOS3 := GET_MOD10_CAMPOS033(VR_CAMPO3);
    VR_CAMPO4 := mod11_barcode(VR_STRTEMP);
    VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_LINHAD := REPLACE(VR_CAMPO1 || VR_DVCAMPOS1 || VR_CAMPO2 || VR_DVCAMPOS2 || VR_CAMPO3 || VR_DVCAMPOS3 || VR_CAMPO4 || VR_CAMPO5,' ');
  ELSIF PT_CdBanco = '633' THEN
    IF PT_Carteira IN ('02','06','07','09') THEN
      VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
      VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
      VR_STRTEMP := REPLACE('237' || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || VR_AgenciaTemp || PT_Carteira || PT_NN || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0',' ');
      VR_CAMPO1 := '237' || PT_Moeda || VR_AgenciaTemp || SUBSTR(PT_Carteira,1,1);
      VR_DVCAMPOS1 := GET_MOD10_CAMPOS033(VR_CAMPO1);
      VR_CAMPO2 := SUBSTR(PT_Carteira,2,1) || SUBSTR(PT_NN,1,9);
      VR_DVCAMPOS2 := GET_MOD10_CAMPOS033(VR_CAMPO2);
      VR_CAMPO3 := SUBSTR(PT_NN,10,2) || LPAD(SUBSTR(PT_Conta,1,LENGTH(PT_Conta)-1),7,'0') || '0';
      VR_DVCAMPOS3 := GET_MOD10_CAMPOS033(VR_CAMPO3);
      VR_CAMPO4 := MOD11_BARCODE_237(VR_STRTEMP);
      VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
      VR_LINHAD := REPLACE(VR_CAMPO1 || VR_DVCAMPOS1 || VR_CAMPO2 || VR_DVCAMPOS2 || VR_CAMPO3 || VR_DVCAMPOS3 || VR_CAMPO4 || VR_CAMPO5,' ');
    ELSIF (PT_Carteira = '121') THEN
      VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
      VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
      VR_STRTEMP := REPLACE('633' || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || LPAD(VR_AgenciaTemp,4,'0') || LPAD(PT_Carteira,3,'0') || LPAD(PT_CdEmpBco,7,'0') || LPAD(PT_NNDV,11,'0'),' ');
      VR_CAMPO1 := '633' || PT_Moeda || VR_AgenciaTemp || SUBSTR(PT_Carteira,1,1);
      VR_DVCAMPOS1 := GET_MOD10_CAMPOS033(VR_CAMPO1);
      VR_CAMPO2 := SUBSTR(PT_Carteira,2,2) || LPAD(PT_CdEmpBco,7,'0') || SUBSTR(PT_NNDV,1,1);
      VR_DVCAMPOS2 := GET_MOD10_CAMPOS033(VR_CAMPO2);
      VR_CAMPO3 := SUBSTR(PT_NNDV,2,10);
      VR_DVCAMPOS3 := GET_MOD10_CAMPOS033(VR_CAMPO3);
      VR_CAMPO4 := SUBSTR(PT_BARCODE,5,1);
      VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
      VR_LINHAD := REPLACE(VR_CAMPO1 || VR_DVCAMPOS1 || VR_CAMPO2 || VR_DVCAMPOS2 || VR_CAMPO3 || VR_DVCAMPOS3 || VR_CAMPO4 || VR_CAMPO5,' ');
    ELSE
      VR_STRTEMP := '033' || PT_Moeda || '9' || SUBSTR(PT_CdEmpBco,6,4);
      VR_CAMPO1 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
      VR_STRTEMP := SUBSTR(PT_CdEmpBco,10,3) || SUBSTR(PT_NNDV,1,7);
      VR_CAMPO2 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
      VR_STRTEMP := SUBSTR(PT_NNDV,8,6) || '0' || SUBSTR(PT_Carteira,1,3);
      VR_CAMPO3 := SUBSTR(VR_STRTEMP,1,10) || GET_MOD10_CAMPOS033(VR_STRTEMP);
      VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
      VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
      VR_CAMPO4 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
      VR_STRTEMP := REPLACE('033' || PT_Moeda || VR_FtVencime || VR_VlrTitTemp || '9' || SUBSTR(PT_CdEmpBco,6,7)  || SUBSTR(PT_NNDV,1,13) || '0' || SUBSTR(PT_Carteira,1,3),' ');
      VR_DIGITAOCDBARRAS := mod11_barcode_033(VR_STRTEMP);
      VR_LINHAD:= REPLACE(VR_CAMPO1 || VR_CAMPO2 || VR_CAMPO3 || VR_DIGITAOCDBARRAS || VR_CAMPO4,' ');
    END IF;
  ELSIF PT_CdBanco = '422' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_STRTEMP := REPLACE(PT_CdBanco || PT_Moeda || TO_CHAR(VR_FtVencime) || VR_VlrTitTemp || '7' || LPAD(REPLACE(PT_Agencia,'-',''),5,'0') || LPAD(REPLACE(PT_Conta,'-',''),9,'0') || LPAD(PT_NNDV,9,'0') || '2',' ');
    VR_CAMPO1 := PT_CdBanco || PT_Moeda || '7' || VR_AgenciaTemp;
    VR_DVCAMPOS1 := GET_MOD10_CAMPOS422(VR_CAMPO1);
    VR_CAMPO2 := SUBSTR(LPAD(REPLACE(PT_Agencia,'-',''),5,'0'), LENGTH(LPAD(REPLACE(PT_Agencia,'-',''),5,'0')),1) || LPAD(REPLACE(PT_Conta,'-',''),9,'0');
    VR_DVCAMPOS2 := GET_MOD10_CAMPOS422(VR_CAMPO2);
    VR_CAMPO3 := REPLACE(PT_NNDV,'-','') || '2';
    VR_DVCAMPOS3 := GET_MOD10_CAMPOS422(VR_CAMPO3);
    VR_CAMPO4 := GET_MOD11_BARCODE_422(VR_STRTEMP);
    VR_CAMPO5 := VR_FtVencime || REPLACE(VR_VlrTitTemp,' ');
    VR_LINHAD := REPLACE(VR_CAMPO1 || VR_DVCAMPOS1 || VR_CAMPO2 || VR_DVCAMPOS2 || VR_CAMPO3 || VR_DVCAMPOS3 || VR_CAMPO4 || VR_CAMPO5,' ');
  ELSIF PT_CdBanco = '001' THEN
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_DVCAMPO1   := GET_MOD10(TO_CHAR(PT_CdBanco || PT_Moeda || SUBSTR(PT_BARCODE,20,5)));
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_LINHAD := REPLACE(PT_CdBanco || PT_Moeda || SUBSTR(PT_BARCODE,20,5) || VR_DVCAMPO1 || SUBSTR(PT_BARCODE,25,10) ||
    GET_MOD10(TO_CHAR(SUBSTR(PT_BARCODE,25,10))) || SUBSTR(PT_BARCODE,35,10) || GET_MOD10(TO_CHAR(SUBSTR(PT_BARCODE,35,10)))
    || SUBSTR(PT_BARCODE,5,1) || VR_FtVencime || VR_VlrTitTemp,' ');
  ELSE
    VR_FtVencime  := PT_DataVcto - TO_DATE('07/10/1997', 'DD/MM/RRRR');
    VR_DVCAMPO1   := GET_MOD10(TO_CHAR(PT_CdBanco || PT_Moeda || SUBSTR(PT_BARCODE,20,5)));
    VR_VlrTitTemp := TO_CHAR(PT_ValorTit*100,'0000000000');
    VR_LINHAD := REPLACE(PT_CdBanco || PT_Moeda || SUBSTR(PT_BARCODE,20,5) || VR_DVCAMPO1 || SUBSTR(PT_BARCODE,25,10) ||
    GET_MOD10(TO_CHAR(SUBSTR(PT_BARCODE,25,10))) || SUBSTR(PT_BARCODE,35,10) || GET_MOD10(TO_CHAR(SUBSTR(PT_BARCODE,35,10)))
    || SUBSTR(PT_BARCODE,5,1) || VR_FtVencime || VR_VlrTitTemp,' ');
  END IF;
  RETURN VR_LINHAD;
END;
/

INSERT INTO COLPADSCE_CPCE
  (CPCE_TPREG,
   CPCE_CDCAMPO,
   CPCE_NMCAMPO,
   CPCE_DSCAMPO,
   CPCE_TABELA,
   CPCE_FUNCAO,
   CPCE_CONDICAO)
VALUES
  ('2',
   (SELECT MAX(TO_NUMBER(CPCE_CDCAMPO))+1 FROM COLPADSCE_CPCE),
   'NNRENDIMENTO',
   'NOSSO NUMERO RENDIMENTO (6-121)',
   'TITCR_TCR',
   'GET_PARNNRENDIMENTO(TCR_CDCLIENTE,TCR_NOTITULO,TCR_IDPORTADO,''121'')',
   NULL)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 274472
PROMPT ======================================================================