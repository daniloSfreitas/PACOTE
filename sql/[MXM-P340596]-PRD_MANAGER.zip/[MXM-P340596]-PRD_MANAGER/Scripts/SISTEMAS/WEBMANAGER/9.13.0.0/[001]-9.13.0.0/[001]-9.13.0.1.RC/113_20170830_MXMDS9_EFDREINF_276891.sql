PROMPT ======================================================================
PROMPT == DEMANDA......: 276891
PROMPT == SISTEMA......: EFD de Reten��es e Outras Inf. Fiscais
PROMPT == RESPONSAVEL..: LUCAS PEREIRA D AMICO
PROMPT == DATA.........: 30/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE TABLE RNFINTTPSERVICO_RTS
(
  RTS_IDRTS           NUMBER(9) NOT NULL,
  RTS_CDTPSERVICO     VARCHAR2(9) NOT NULL,
  RTS_TPSERVICO       VARCHAR2(100) NOT NULL
)
/

COMMENT ON TABLE RNFINTTPSERVICO_RTS
  IS 'TABELA INTERNA DE TIPO DE SERVI�O'
/

COMMENT ON COLUMN RNFINTTPSERVICO_RTS.RTS_IDRTS
  IS 'IDENTIFICADOR'
/

COMMENT ON COLUMN RNFINTTPSERVICO_RTS.RTS_CDTPSERVICO
  IS 'C�DIGO DO TIPO DE SERVI�O'
/

COMMENT ON COLUMN RNFINTTPSERVICO_RTS.RTS_TPSERVICO
  IS 'DESCRI��O DO TIPO DE SERVI�O'
/

ALTER TABLE RNFINTTPSERVICO_RTS
  ADD CONSTRAINT PK_RNFINTTPSERVICO_RTS PRIMARY KEY (RTS_IDRTS)
/

ALTER TABLE RNFINTTPSERVICO_RTS
  ADD CONSTRAINT UK1_RNFINTTPSERVICO_RTS UNIQUE (RTS_CDTPSERVICO)
/

INSERT INTO RNFINTTPSERVICO_RTS VALUES (1 ,'100000001','Limpeza, conserva��o ou zeladoria')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (2 ,'100000002','Vigil�ncia ou seguran�a')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (3 ,'100000003','Constru��o civil')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (4 ,'100000004','Servi�os de natureza rural')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (5 ,'100000005','Digita��o')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (6 ,'100000006','Prepara��o de dados para processamento')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (7 ,'100000007','Acabamento')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (8 ,'100000008','Embalagem')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (9 ,'100000009','Acondicionamento')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (10,'100000010','Cobran�a')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (11,'100000011','Coleta ou reciclagem de lixo ou de res�duos')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (12,'100000012','Copa')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (13,'100000013','Hotelaria')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (14,'100000014','Corte ou liga��o de servi�os p�blicos')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (15,'100000015','Distribui��o')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (16,'100000016','Treinamento e ensino')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (17,'100000017','Entrega de contas e de documentos')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (18,'100000018','Liga��o de medidores')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (19,'100000019','Leitura de medidores')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (20,'100000020','Manuten��o de instala��es, de m�quinas ou de equipamentos')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (21,'100000021','Montagem')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (22,'100000022','Opera��o de m�quinas, de equipamentos e de ve�culos')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (23,'100000023','Opera��o de ped�gio ou de terminal de transporte')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (24,'100000024','Opera��o de transporte de passageiros')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (25,'100000025','Portaria, recep��o ou ascensorista')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (26,'100000026','Recep��o, triagem ou movimenta��o de materiais')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (27,'100000027','Promo��o de vendas ou de eventos')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (28,'100000028','Secretaria e expediente')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (29,'100000029','Sa�de')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (30,'100000030','Telefonia ou telemarketing')
/
INSERT INTO RNFINTTPSERVICO_RTS VALUES (31,'100000031','Trabalho tempor�rio na forma da Lei n� 6.019, de janeiro de 1974')
/

ALTER TABLE GRPAG_GPA ADD GPA_NRRTS NUMBER(9)
/

ALTER TABLE GRPAG_GPA ADD GPA_NRCAS NUMBER(9)
/

CREATE INDEX IN1_GRPAG_GPA ON GRPAG_GPA (GPA_NRRTS)
/

ALTER TABLE GRPAG_GPA ADD CONSTRAINT FK1_GRPAG_GPA FOREIGN KEY (GPA_NRRTS) REFERENCES RNFINTTPSERVICO_RTS (RTS_IDRTS)
/

comment on column GRPAG_GPA.GPA_NRRTS
  is 'Identificador do Tipo de Servi�o.'
/

CREATE INDEX IN2_GRPAG_GPA ON GRPAG_GPA (GPA_NRCAS)
/

ALTER TABLE GRPAG_GPA ADD CONSTRAINT FK2_GRPAG_GPA FOREIGN KEY (GPA_NRCAS) REFERENCES EFDSPEDCODATIVSCP_CAS (CAS_IDATIVIDADE)
/

comment on column GRPAG_GPA.GPA_NRCAS
  is 'Identificador do C�digo de Atividade Econ�mica.'
/

ALTER TABLE GRREC_GRE ADD GRE_NRRTS NUMBER(9)
/

ALTER TABLE GRREC_GRE ADD GRE_NRCAS NUMBER(9)
/

ALTER TABLE GRREC_GRE ADD GRE_VBSERVICO CHAR(1) DEFAULT 'N'
/

comment on column GRREC_GRE.GRE_VBSERVICO
  is 'Flag indicativo se o grupo corresponde a um servi�o.'
/

ALTER TABLE GRREC_GRE ADD CONSTRAINT FK1_GRREC_GRE FOREIGN KEY (GRE_NRRTS) REFERENCES RNFINTTPSERVICO_RTS (RTS_IDRTS)
/

comment on column GRREC_GRE.GRE_NRRTS
  is 'Identificador do Tipo de Servi�o.'
/

ALTER TABLE GRREC_GRE ADD CONSTRAINT FK2_GRREC_GRE FOREIGN KEY (GRE_NRCAS) REFERENCES EFDSPEDCODATIVSCP_CAS (CAS_IDATIVIDADE)
/

comment on column GRREC_GRE.GRE_NRCAS
  is 'Identificador do C�digo de Atividade Econ�mica.'
/

CREATE INDEX IN1_GRREC_GRE ON GRREC_GRE (GRE_NRRTS)
/

CREATE INDEX IN2_GRREC_GRE ON GRREC_GRE (GRE_NRCAS)
/

  CREATE OR REPLACE VIEW  VW_EFDSPEDCODATIVSCP_CAS AS
  SELECT CAS_IDATIVIDADE,
         CAS_CDATIVIDADE,
         CAS_DSATIVRESUMIDA,
         CAS_CDATIVIDADE ||' - '|| CAS_DSATIVRESUMIDA  AS COD_DESCRICAO,
         CAS_DTINICIOESCR,
         CAS_DTFIMESCR
  FROM EFDSPEDCODATIVSCP_CAS
/

CREATE OR REPLACE PROCEDURE INSGRPAG_GPA
(PGPA_CDGRUPO        IN CHAR,
 PGPA_DSGRUPO        IN CHAR,
 PGPA_CDPLCTB        IN CHAR,
 PGPA_CDPLCC         IN CHAR,
 PGPA_CTBGRUPO       IN CHAR,
 PGPA_CCCGRUPO       IN CHAR,
 PGPA_CTBRECFIN      IN CHAR,
 PGPA_CCCRECFIN      IN CHAR,
 PGPA_CTBDESFIN      IN CHAR,
 PGPA_CCCDESFIN      IN CHAR,
 PGPA_CTBVARMOR      IN CHAR,
 PGPA_CCCVARMOR      IN CHAR,
 PGPA_CTBVARMOP      IN CHAR,
 PGPA_CCCVARMOP      IN CHAR,
 PGPA_CTAFCAIXA      IN CHAR,
 PGPA_CDFCAIXA       IN CHAR,
 PGPA_CTBFOR         IN CHAR,
 PGPA_CCCFOR         IN CHAR,
 PGPA_IMPOSTO1       IN CHAR,
 PGPA_IMPOSTO2       IN CHAR,
 PGPA_IMPOSTO3       IN CHAR,
 PGPA_IMPOSTO4       IN CHAR,
 PGPA_IMPOSTO5       IN CHAR,
 PGPA_IMPOSTO6       IN CHAR,
 PGPA_IMPOSTO7       IN CHAR,
 PGPA_IMPOSTO8       IN CHAR,
 PGPA_CODMODRATCCFIN IN CHAR,
 PGPA_DTINATIVO      IN DATE,
 PGPA_SERVICO        IN CHAR DEFAULT 'N',
 PGPA_NRRTS          IN NUMBER DEFAULT NULL,
 PGPA_NRCAS          IN NUMBER DEFAULT NULL)
AS
  nRows        INTEGER;
  nCursor      INTEGER;
  nPAR_DBLMXM  INTEGER;
  CURSOR PARAMS IS
    SELECT TO_NUMBER(NVL(PAR_VLPARAM,0))
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = 'wPAR_DBLMXM';
BEGIN
  INSERT INTO GRPAG_GPA
     (GPA_CDGRUPO,   GPA_DSGRUPO,   GPA_CDPLCTB,        GPA_CDPLCC,
      GPA_CTBGRUPO,  GPA_CCCGRUPO,  GPA_CTBRECFIN,      GPA_CCCRECFIN,
      GPA_CTBDESFIN, GPA_CCCDESFIN, GPA_CTBVARMOR,      GPA_CCCVARMOR,
      GPA_CTBVARMOP, GPA_CCCVARMOP, GPA_CTAFCAIXA,      GPA_CDFCAIXA,
      GPA_CTBFOR,    GPA_CCCFOR,    GPA_IMPOSTO1,       GPA_IMPOSTO2,
      GPA_IMPOSTO3,  GPA_IMPOSTO4,  GPA_IMPOSTO5,       GPA_IMPOSTO6,
      GPA_IMPOSTO7,  GPA_IMPOSTO8,  GPA_CODMODRATCCFIN, GPA_DTINATIVO,
      GPA_SERVICO,   GPA_NRRTS,     GPA_NRCAS)
  VALUES
     (PGPA_CDGRUPO,   PGPA_DSGRUPO,   PGPA_CDPLCTB,        PGPA_CDPLCC,
      PGPA_CTBGRUPO,  PGPA_CCCGRUPO,  PGPA_CTBRECFIN,      PGPA_CCCRECFIN,
      PGPA_CTBDESFIN, PGPA_CCCDESFIN, PGPA_CTBVARMOR,      PGPA_CCCVARMOR,
      PGPA_CTBVARMOP, PGPA_CCCVARMOP, PGPA_CTAFCAIXA,      PGPA_CDFCAIXA,
      PGPA_CTBFOR,    PGPA_CCCFOR,    PGPA_IMPOSTO1,       PGPA_IMPOSTO2,
      PGPA_IMPOSTO3,  PGPA_IMPOSTO4,  PGPA_IMPOSTO5,       PGPA_IMPOSTO6,
      PGPA_IMPOSTO7,  PGPA_IMPOSTO8,  PGPA_CODMODRATCCFIN, PGPA_DTINATIVO,
      PGPA_SERVICO,   PGPA_NRRTS,     PGPA_NRCAS);
  OPEN  PARAMS;
  FETCH PARAMS INTO nPAR_DBLMXM;
  IF PARAMS%FOUND THEN
    nCursor := dbms_sql.open_cursor;
    WHILE nPAR_DBLMXM > 0 LOOP
      DBMS_SQL.PARSE(nCursor,
      'INSERT INTO GRPAG_GPA@DBLMXM' || TO_CHAR(nPAR_DBLMXM) ||
      ' (GPA_CDGRUPO,   GPA_DSGRUPO,   GPA_CDPLCTB,        GPA_CDPLCC,'   ||
      '  GPA_CTBGRUPO,  GPA_CCCGRUPO,  GPA_CTBRECFIN,      GPA_CCCRECFIN,'||
      '  GPA_CTBDESFIN, GPA_CCCDESFIN, GPA_CTBVARMOR,      GPA_CCCVARMOR,'||
      '  GPA_CTBVARMOP, GPA_CCCVARMOP, GPA_CTAFCAIXA,      GPA_CDFCAIXA,' ||
      '  GPA_CTBFOR,    GPA_CCCFOR,    GPA_IMPOSTO1,       GPA_IMPOSTO2,' ||
      '  GPA_IMPOSTO3,  GPA_IMPOSTO4,  GPA_IMPOSTO5,       GPA_IMPOSTO6,' ||
      '  GPA_IMPOSTO7,  GPA_IMPOSTO8,  GPA_CODMODRATCCFIN, GPA_DTINATIVO,'||
      '  GPA_SERVICO,   GPA_NRRTS,     GPA_NRCAS)'||
      'VALUES' ||
      ' ('''||PGPA_CDGRUPO  ||''','''||PGPA_DSGRUPO  ||''','''||PGPA_CDPLCTB       ||''','''||PGPA_CDPLCC   ||''','||
      '  '''||PGPA_CTBGRUPO ||''','''||PGPA_CCCGRUPO ||''','''||PGPA_CTBRECFIN     ||''','''||PGPA_CCCRECFIN||''','||
      '  '''||PGPA_CTBDESFIN||''','''||PGPA_CCCDESFIN||''','''||PGPA_CTBVARMOR     ||''','''||PGPA_CCCVARMOR||''','||
      '  '''||PGPA_CTBVARMOP||''','''||PGPA_CCCVARMOP||''','''||PGPA_CTAFCAIXA     ||''','''||PGPA_CDFCAIXA ||''','||
      '  '''||PGPA_CTBFOR   ||''','''||PGPA_CCCFOR   ||''','''||PGPA_IMPOSTO1      ||''','''||PGPA_IMPOSTO2 ||''','||
      '  '''||PGPA_IMPOSTO3 ||''','''||PGPA_IMPOSTO4 ||''','''||PGPA_IMPOSTO5      ||''','''||PGPA_IMPOSTO6 ||''','||
      '  '''||PGPA_IMPOSTO7 ||''','''||PGPA_IMPOSTO8 ||''','''||PGPA_CODMODRATCCFIN||''','''||PGPA_DTINATIVO||''','||
      '  '''||PGPA_SERVICO  ||''','  ||PGPA_NRRTS    ||','    ||PGPA_NRCAS         ||')',
       nCursor);
       nRows   := dbms_sql.execute(nCursor);
       nPAR_DBLMXM := nPAR_DBLMXM - 1;
    END LOOP;
    dbms_sql.close_cursor(nCursor);
  END IF;
  CLOSE PARAMS;
END;
/

CREATE OR REPLACE PROCEDURE INSGRREC_GRE
(PGRE_CDGRUPO        IN CHAR,
 PGRE_DSGRUPO        IN CHAR,
 PGRE_CDPLCTB        IN CHAR,
 PGRE_CDPLCC         IN CHAR,
 PGRE_CDFCAIXA       IN CHAR,
 PGRE_CTAFCAIXA      IN CHAR,
 PGRE_CTBGRUPO       IN CHAR,
 PGRE_CCCGRUPO       IN CHAR,
 PGRE_CTBRECFIN      IN CHAR,
 PGRE_CCCRECFIN      IN CHAR,
 PGRE_CTBDESFIN      IN CHAR,
 PGRE_CCCDESFIN      IN CHAR,
 PGRE_CTBVARMOR      IN CHAR,
 PGRE_CCCVARMOR      IN CHAR,
 PGRE_CTBVARMOP      IN CHAR,
 PGRE_CCCVARMOP      IN CHAR,
 PGRE_CTBVENCANC     IN CHAR,
 PGRE_CCCVENCANC     IN CHAR,
 PGRE_CTBCLIENTE     IN CHAR,
 PGRE_CCCCLIENTE     IN CHAR,
 PGRE_CTBGLOSAREC    IN CHAR,
 PGRE_CCCGLOSAREC    IN CHAR,
 PGRE_CTBREDRECEITA  IN CHAR,
 PGRE_CCCREDRECEITA  IN CHAR,
 PGRE_IMPOSTO1       IN CHAR,
 PGRE_IMPOSTO2       IN CHAR,
 PGRE_IMPOSTO3       IN CHAR,
 PGRE_IMPOSTO4       in char,
 PGRE_IMPOSTO5       in char,
 PGRE_IMPOSTO6       in char,
 PGRE_CODMODRATCCFIN in char,
 PGRE_DTINATIVO      IN DATE,
 PGRE_CCONTABPDD     IN CHAR,
 PGRE_CCUSTOPDD         IN CHAR,
 PGRE_CCONTAREDPDD   IN CHAR,
 PGRE_CCUSTOREDPDD   IN CHAR,
 PGRE_CTBBXNFIN      IN CHAR,
 PGRE_VBSERVICO      IN CHAR DEFAULT 'N',
 PGRE_NRRTS          IN NUMBER DEFAULT NULL,
 PGRE_NRCAS          IN NUMBER DEFAULT NULL)
AS
  nRows        INTEGER;
  nCursor      INTEGER;
  nPAR_DBLMXM  INTEGER;
  CURSOR PARAMS IS
    SELECT TO_NUMBER(NVL(PAR_VLPARAM,0))
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = 'wPAR_DBLMXM';
BEGIN
  INSERT INTO GRREC_GRE
     (GRE_CDGRUPO,     GRE_DSGRUPO,     GRE_CDPLCTB,        GRE_CDPLCC,
      GRE_CDFCAIXA,    GRE_CTAFCAIXA,   GRE_CTBGRUPO,       GRE_CCCGRUPO,
      GRE_CTBRECFIN,   GRE_CCCRECFIN,   GRE_CTBDESFIN,      GRE_CCCDESFIN,
      GRE_CTBVARMOR,   GRE_CCCVARMOR,   GRE_CTBVARMOP,      GRE_CCCVARMOP,
      GRE_CTBVENCANC,  GRE_CCCVENCANC,  GRE_CTBCLIENTE,     GRE_CCCCLIENTE,
      GRE_CTBGLOSAREC, GRE_CCCGLOSAREC, GRE_CTBREDRECEITA,  GRE_CCCREDRECEITA,
      GRE_IMPOSTO1,    GRE_IMPOSTO2,    GRE_IMPOSTO3,       GRE_IMPOSTO4,
      GRE_IMPOSTO5,    GRE_IMPOSTO6,    GRE_CODMODRATCCFIN, GRE_DTINATIVO,
      GRE_CCONTABPDD,  GRE_CCUSTOPDD,   GRE_CCONTAREDPDD,   GRE_CCUSTOREDPDD,
      GRE_CTBBXNFIN,   GRE_VBSERVICO,   GRE_NRRTS,          GRE_NRCAS)
  VALUES
     (PGRE_CDGRUPO,     PGRE_DSGRUPO,     PGRE_CDPLCTB,        PGRE_CDPLCC,
      PGRE_CDFCAIXA,    PGRE_CTAFCAIXA,   PGRE_CTBGRUPO,       PGRE_CCCGRUPO,
      PGRE_CTBRECFIN,   PGRE_CCCRECFIN,   PGRE_CTBDESFIN,      PGRE_CCCDESFIN,
      PGRE_CTBVARMOR,   PGRE_CCCVARMOR,   PGRE_CTBVARMOP,      PGRE_CCCVARMOP,
      PGRE_CTBVENCANC,  PGRE_CCCVENCANC,  PGRE_CTBCLIENTE,     PGRE_CCCCLIENTE,
      PGRE_CTBGLOSAREC, PGRE_CCCGLOSAREC, PGRE_CTBREDRECEITA,  PGRE_CCCREDRECEITA,
      PGRE_IMPOSTO1,    PGRE_IMPOSTO2,    PGRE_IMPOSTO3,       PGRE_IMPOSTO4,
      PGRE_IMPOSTO5,    PGRE_IMPOSTO6,    PGRE_CODMODRATCCFIN, PGRE_DTINATIVO,
      PGRE_CCONTABPDD,  PGRE_CCUSTOPDD,   PGRE_CCONTAREDPDD,   PGRE_CCUSTOREDPDD,
      PGRE_CTBBXNFIN,   PGRE_VBSERVICO,   PGRE_NRRTS,          PGRE_NRCAS);
  OPEN  PARAMS;
  FETCH PARAMS INTO nPAR_DBLMXM;
  IF PARAMS%FOUND THEN
    nCursor := dbms_sql.open_cursor;
    WHILE nPAR_DBLMXM > 0 LOOP
      DBMS_SQL.PARSE(nCursor,
     'INSERT INTO GRREC_GRE@DBLMXM' || TO_CHAR(nPAR_DBLMXM) ||
     ' (GRE_CDGRUPO,     GRE_DSGRUPO,     GRE_CDPLCTB,        GRE_CDPLCC,'        ||
     '  GRE_CDFCAIXA,    GRE_CTAFCAIXA,   GRE_CTBGRUPO,       GRE_CCCGRUPO,'      ||
     '  GRE_CTBRECFIN,   GRE_CCCRECFIN,   GRE_CTBDESFIN,      GRE_CCCDESFIN,'     ||
     '  GRE_CTBVARMOR,   GRE_CCCVARMOR,   GRE_CTBVARMOP,      GRE_CCCVARMOP,'     ||
     '  GRE_CTBVENCANC,  GRE_CCCVENCANC,  GRE_CTBCLIENTE,     GRE_CCCCLIENTE,'    ||
     '  GRE_CTBGLOSAREC, GRE_CCCGLOSAREC, GRE_CTBREDRECEITA,  GRE_CCCREDRECEITA,' ||
     '  GRE_IMPOSTO1,    GRE_IMPOSTO2,    GRE_IMPOSTO3,       GRE_IMPOSTO4, '     ||
     '  GRE_IMPOSTO5,    GRE_IMPOSTO6,    GRE_CODMODRATCCFIN, GRE_DTINATIVO,'     ||
     '  GRE_CCONTABPDD,  GRE_CCUSTOPDD,   GRE_CCONTAREDPDD,   GRE_CCUSTOREDPDD,'  ||
     '  GRE_CTBBXNFIN,   GRE_SERVICO,     GRE_NRRTS,          GRE_NRCAS)'         ||
     'VALUES' ||
     ' (''' || PGRE_CDGRUPO        || ''',''' || PGRE_DSGRUPO      || ''',' ||
     '  ''' || PGRE_CDPLCTB        || ''',''' || PGRE_CDPLCC       || ''',' ||
     '  ''' || PGRE_CDFCAIXA       || ''',''' || PGRE_CTAFCAIXA    || ''',' ||
     '  ''' || PGRE_CTBGRUPO       || ''',''' || PGRE_CCCGRUPO     || ''',' ||
     '  ''' || PGRE_CTBRECFIN      || ''',''' || PGRE_CCCRECFIN    || ''',' ||
     '  ''' || PGRE_CTBDESFIN      || ''',''' || PGRE_CCCDESFIN    || ''',' ||
     '  ''' || PGRE_CTBVARMOR      || ''',''' || PGRE_CCCVARMOR    || ''',' ||
     '  ''' || PGRE_CTBVARMOP      || ''',''' || PGRE_CCCVARMOP    || ''',' ||
     '  ''' || PGRE_CTBVENCANC     || ''',''' || PGRE_CCCVENCANC   || ''',' ||
     '  ''' || PGRE_CTBCLIENTE     || ''',''' || PGRE_CCCCLIENTE   || ''',' ||
     '  ''' || PGRE_CTBGLOSAREC    || ''',''' || PGRE_CCCGLOSAREC  || ''',' ||
     '  ''' || PGRE_CTBREDRECEITA  || ''',''' || PGRE_CCCREDRECEITA|| ''',' ||
     '  ''' || PGRE_IMPOSTO1       || ''',''' || PGRE_IMPOSTO2     || ''',' ||
     '  ''' || PGRE_IMPOSTO3       || ''',''' || PGRE_IMPOSTO4     || ''',' ||
     '  ''' || PGRE_IMPOSTO5       || ''',''' || PGRE_IMPOSTO6     || ''',' ||
     '  ''' || PGRE_CODMODRATCCFIN || ''',''' || PGRE_DTINATIVO    || ''',' ||
     '  ''' || PGRE_CCONTABPDD     || ''',''' || PGRE_CCUSTOPDD    || ''',' ||
     '  ''' || PGRE_CCONTAREDPDD   || ''',''' || PGRE_CCUSTOREDPDD || ''',' ||
     '  ''' || PGRE_CTBBXNFIN      || ''',''' || PGRE_VBSERVICO    || ''',' ||
     '  '   || PGRE_NRRTS          || ','     || PGRE_NRCAS        || ')',
         nCursor);
     nRows   := dbms_sql.execute(nCursor);
     nPAR_DBLMXM := nPAR_DBLMXM - 1;
    END LOOP;
    dbms_sql.close_cursor(nCursor);
  END IF;
  CLOSE PARAMS;
END;
/

CREATE OR REPLACE PROCEDURE ALTGRPAG_GPA
  (PGPA_CDGRUPO        IN CHAR,
   PGPA_DSGRUPO        IN CHAR,
   PGPA_CDPLCTB        IN CHAR,
   PGPA_CDPLCC         IN CHAR,
   PGPA_CTBGRUPO       IN CHAR,
   PGPA_CCCGRUPO       IN CHAR,
   PGPA_CTBRECFIN      IN CHAR,
   PGPA_CCCRECFIN      IN CHAR,
   PGPA_CTBDESFIN      IN CHAR,
   PGPA_CCCDESFIN      IN CHAR,
   PGPA_CTBVARMOR      IN CHAR,
   PGPA_CCCVARMOR      IN CHAR,
   PGPA_CTBVARMOP      IN CHAR,
   PGPA_CCCVARMOP      IN CHAR,
   PGPA_CTAFCAIXA      IN CHAR,
   PGPA_CDFCAIXA       IN CHAR,
   PGPA_CTBFOR         IN CHAR,
   PGPA_CCCFOR         IN CHAR,
   PGPA_IMPOSTO1       IN CHAR,
   PGPA_IMPOSTO2       IN CHAR,
   PGPA_IMPOSTO3       IN CHAR,
   PGPA_IMPOSTO4       IN CHAR,
   PGPA_IMPOSTO5       IN CHAR,
   PGPA_IMPOSTO6       IN CHAR,
   PGPA_IMPOSTO7       IN CHAR,
   PGPA_IMPOSTO8       IN CHAR,
   PGPA_CODMODRATCCFIN IN CHAR,
   PGPA_DTINATIVO      IN DATE,
   PGPA_SERVICO        IN CHAR DEFAULT 'N',
   PGPA_NRRTS          IN NUMBER DEFAULT NULL,
   PGPA_NRCAS          IN NUMBER DEFAULT NULL)
AS
  nRows        INTEGER;
  nCursor      INTEGER;
  nPAR_DBLMXM  INTEGER;
  CURSOR PARAMS IS
    SELECT TO_NUMBER(NVL(PAR_VLPARAM,0))
      FROM PARAMS_PAR
     WHERE PAR_CDPARAM = 'wPAR_DBLMXM';
BEGIN
  UPDATE GRPAG_GPA
     SET GPA_DSGRUPO        = PGPA_DSGRUPO,
         GPA_CTBGRUPO       = PGPA_CTBGRUPO,
         GPA_CDPLCTB        = PGPA_CDPLCTB,
         GPA_CDPLCC         = PGPA_CDPLCC,
         GPA_CCCGRUPO       = PGPA_CCCGRUPO,
         GPA_CTBRECFIN      = PGPA_CTBRECFIN,
         GPA_CCCRECFIN      = PGPA_CCCRECFIN,
         GPA_CTBDESFIN      = PGPA_CTBDESFIN,
         GPA_CCCDESFIN      = PGPA_CCCDESFIN,
         GPA_CTBVARMOR      = PGPA_CTBVARMOR,
         GPA_CCCVARMOR      = PGPA_CCCVARMOR,
         GPA_CTBVARMOP      = PGPA_CTBVARMOP,
         GPA_CCCVARMOP      = PGPA_CCCVARMOP,
         GPA_CTAFCAIXA      = PGPA_CTAFCAIXA,
         GPA_CDFCAIXA       = PGPA_CDFCAIXA,
         GPA_CTBFOR         = PGPA_CTBFOR,
         GPA_CCCFOR         = PGPA_CCCFOR,
         GPA_IMPOSTO1       = PGPA_IMPOSTO1,
         GPA_IMPOSTO2       = PGPA_IMPOSTO2,
         GPA_IMPOSTO3       = PGPA_IMPOSTO3,
         GPA_IMPOSTO4       = PGPA_IMPOSTO4,
         GPA_IMPOSTO5       = PGPA_IMPOSTO5,
         GPA_IMPOSTO6       = PGPA_IMPOSTO6,
         GPA_IMPOSTO7       = PGPA_IMPOSTO7,
         GPA_IMPOSTO8       = PGPA_IMPOSTO8,
         GPA_CODMODRATCCFIN = PGPA_CODMODRATCCFIN,
         GPA_DTINATIVO      = PGPA_DTINATIVO ,
         GPA_SERVICO        = PGPA_SERVICO,
         GPA_NRRTS          = PGPA_NRRTS,
         GPA_NRCAS          = PGPA_NRCAS
   WHERE GPA_CDGRUPO        = PGPA_CDGRUPO;
  OPEN  PARAMS;
  FETCH PARAMS INTO nPAR_DBLMXM;
  IF PARAMS%FOUND THEN
    nCursor := dbms_sql.open_cursor;
    WHILE nPAR_DBLMXM > 0 LOOP
      DBMS_SQL.PARSE(nCursor,
      'UPDATE GRPAG_GPA@DBLMXM'        || TO_CHAR(nPAR_DBLMXM) ||
      '   SET GPA_DSGRUPO        = ''' || PGPA_DSGRUPO         || ''',' ||
      '       GPA_CTBGRUPO       = ''' || PGPA_CTBGRUPO        || ''',' ||
      '       GPA_CDPLCTB        = ''' || PGPA_CDPLCTB         || ''',' ||
      '       GPA_CDPLCC         = ''' || PGPA_CDPLCC          || ''',' ||
      '       GPA_CCCGRUPO       = ''' || PGPA_CCCGRUPO        || ''',' ||
      '       GPA_CTBRECFIN      = ''' || PGPA_CTBRECFIN       || ''',' ||
      '       GPA_CCCRECFIN      = ''' || PGPA_CCCRECFIN       || ''',' ||
      '       GPA_CTBDESFIN      = ''' || PGPA_CTBDESFIN       || ''',' ||
      '       GPA_CCCDESFIN      = ''' || PGPA_CCCDESFIN       || ''',' ||
      '       GPA_CTBVARMOR      = ''' || PGPA_CTBVARMOR       || ''',' ||
      '       GPA_CCCVARMOR      = ''' || PGPA_CCCVARMOR       || ''',' ||
      '       GPA_CTBVARMOP      = ''' || PGPA_CTBVARMOP       || ''',' ||
      '       GPA_CCCVARMOP      = ''' || PGPA_CCCVARMOP       || ''',' ||
      '       GPA_CTAFCAIXA      = ''' || PGPA_CTAFCAIXA       || ''',' ||
      '       GPA_CDFCAIXA       = ''' || PGPA_CDFCAIXA        || ''',' ||
      '       GPA_CTBFOR         = ''' || PGPA_CTBFOR          || ''',' ||
      '       GPA_CCCFOR         = ''' || PGPA_CCCFOR          || ''',' ||
      '       GPA_IMPOSTO1       = ''' || PGPA_IMPOSTO1        || ''',' ||
      '       GPA_IMPOSTO2       = ''' || PGPA_IMPOSTO2        || ''',' ||
      '       GPA_IMPOSTO3       = ''' || PGPA_IMPOSTO3        || ''',' ||
      '       GPA_IMPOSTO4       = ''' || PGPA_IMPOSTO4        || ''',' ||
      '       GPA_IMPOSTO5       = ''' || PGPA_IMPOSTO5        || ''',' ||
      '       GPA_IMPOSTO6       = ''' || PGPA_IMPOSTO6        || ''',' ||
      '       GPA_IMPOSTO7       = ''' || PGPA_IMPOSTO7        || ''',' ||
      '       GPA_IMPOSTO8       = ''' || PGPA_IMPOSTO8        || ''',' ||
      '       GPA_CODMODRATCCFIN = ''' || PGPA_CODMODRATCCFIN  || ''',' ||
      '       GPA_DTINATIVO      = ''' || PGPA_DTINATIVO       || ''',' ||
      '       GPA_SERVICO        = ''' || PGPA_SERVICO         || ''',' ||
      '       GPA_NRRTS          = '   || PGPA_NRRTS           || ','   ||
      '       GPA_NRCAS          = '   || PGPA_NRCAS           ||
      ' WHERE GPA_CDGRUPO   = '''      || PGPA_CDGRUPO         || '''',
       nCursor);
       nRows   := dbms_sql.execute(nCursor);
       nPAR_DBLMXM := nPAR_DBLMXM - 1;
    END LOOP;
    dbms_sql.close_cursor(nCursor);
  END IF;
  CLOSE PARAMS;
END;
/

CREATE OR REPLACE PROCEDURE ALTGRREC_GRE
 (PGRE_CDGRUPO        IN CHAR,
  PGRE_DSGRUPO        IN CHAR,
  PGRE_CDPLCTB        IN CHAR,
  PGRE_CDPLCC         IN CHAR,
  PGRE_CDFCAIXA       IN CHAR,
  PGRE_CTAFCAIXA      IN CHAR,
  PGRE_CTBGRUPO       IN CHAR,
  PGRE_CCCGRUPO       IN CHAR,
  PGRE_CTBRECFIN      IN CHAR,
  PGRE_CCCRECFIN      IN CHAR,
  PGRE_CTBDESFIN      IN CHAR,
  PGRE_CCCDESFIN      IN CHAR,
  PGRE_CTBVARMOR      IN CHAR,
  PGRE_CCCVARMOR      IN CHAR,
  PGRE_CTBVARMOP      IN CHAR,
  PGRE_CCCVARMOP      IN CHAR,
  PGRE_CTBVENCANC     IN CHAR,
  PGRE_CCCVENCANC     IN CHAR,
  PGRE_CTBCLIENTE     IN CHAR,
  PGRE_CCCCLIENTE     IN CHAR,
  PGRE_CTBGLOSAREC    IN CHAR,
  PGRE_CCCGLOSAREC    IN CHAR,
  PGRE_CTBREDRECEITA  IN CHAR,
  PGRE_CCCREDRECEITA  IN CHAR,
  PGRE_IMPOSTO1       IN CHAR,
  PGRE_IMPOSTO2       IN CHAR,
  PGRE_IMPOSTO3       IN CHAR,
  PGRE_IMPOSTO4       in char,
  PGRE_IMPOSTO5       in char,
  PGRE_IMPOSTO6       in char,
  PGRE_CODMODRATCCFIN in char,
  PGRE_DTINATIVO      IN DATE,
  PGRE_CCONTABPDD     IN CHAR,
  PGRE_CCUSTOPDD      IN CHAR,
  PGRE_CCONTAREDPDD   IN CHAR,
  PGRE_CCUSTOREDPDD   IN CHAR,
  PGRE_CTBBXNFIN      IN CHAR,
  PGRE_VBSERVICO      IN CHAR DEFAULT 'N',
  PGRE_NRRTS          IN NUMBER DEFAULT NULL,
  PGRE_NRCAS          IN NUMBER DEFAULT NULL)
AS
  nRows        INTEGER;
  nCursor      INTEGER;
  nPAR_DBLMXM  INTEGER;
  CURSOR PARAMS IS
    SELECT TO_NUMBER(NVL(PAR_VLPARAM,0))
	  FROM PARAMS_PAR
     WHERE PAR_CDPARAM = 'wPAR_DBLMXM';
BEGIN
  UPDATE GRREC_GRE
     SET GRE_DSGRUPO        = PGRE_DSGRUPO,
         GRE_CTBGRUPO       = PGRE_CTBGRUPO,
         GRE_CDPLCTB        = PGRE_CDPLCTB,
         GRE_CDPLCC         = PGRE_CDPLCC,
         GRE_CDFCAIXA       = PGRE_CDFCAIXA,
         GRE_CTAFCAIXA      = PGRE_CTAFCAIXA,
         GRE_CCCGRUPO       = PGRE_CCCGRUPO,
         GRE_CTBRECFIN      = PGRE_CTBRECFIN,
         GRE_CCCRECFIN      = PGRE_CCCRECFIN,
         GRE_CTBDESFIN      = PGRE_CTBDESFIN,
         GRE_CCCDESFIN      = PGRE_CCCDESFIN,
         GRE_CTBVARMOR      = PGRE_CTBVARMOR,
         GRE_CCCVARMOR      = PGRE_CCCVARMOR,
         GRE_CTBVARMOP      = PGRE_CTBVARMOP,
         GRE_CCCVARMOP      = PGRE_CCCVARMOP,
         GRE_CTBVENCANC     = PGRE_CTBVENCANC,
         GRE_CCCVENCANC     = PGRE_CCCVENCANC,
         GRE_CTBCLIENTE     = PGRE_CTBCLIENTE,
         GRE_CCCCLIENTE     = PGRE_CCCCLIENTE,
         GRE_CTBGLOSAREC    = PGRE_CTBGLOSAREC,
         GRE_CCCGLOSAREC    = PGRE_CCCGLOSAREC,
         GRE_CTBREDRECEITA  = PGRE_CTBREDRECEITA,
         GRE_CCCREDRECEITA  = PGRE_CCCREDRECEITA,
         GRE_IMPOSTO1       = PGRE_IMPOSTO1,
         GRE_IMPOSTO2       = PGRE_IMPOSTO2,
         GRE_IMPOSTO3       = PGRE_IMPOSTO3,
         GRE_IMPOSTO4       = PGRE_IMPOSTO4,
         GRE_IMPOSTO5       = PGRE_IMPOSTO5,
         GRE_IMPOSTO6       = PGRE_IMPOSTO6,
         GRE_CODMODRATCCFIN = PGRE_CODMODRATCCFIN,
         GRE_DTINATIVO      = PGRE_DTINATIVO,
         GRE_CCONTABPDD     = PGRE_CCONTABPDD,
         GRE_CCUSTOPDD      = PGRE_CCUSTOPDD,
         GRE_CCONTAREDPDD   = PGRE_CCONTAREDPDD,
         GRE_CCUSTOREDPDD   = PGRE_CCUSTOREDPDD,
         GRE_CTBBXNFIN      = PGRE_CTBBXNFIN,
         GRE_VBSERVICO      = PGRE_VBSERVICO,
         GRE_NRRTS          = PGRE_NRRTS,
         GRE_NRCAS          = PGRE_NRCAS
   WHERE GRE_CDGRUPO        = PGRE_CDGRUPO;
  OPEN  PARAMS;
  FETCH PARAMS INTO nPAR_DBLMXM;
  IF PARAMS%FOUND THEN
    nCursor := dbms_sql.open_cursor;
    WHILE nPAR_DBLMXM > 0 LOOP
      DBMS_SQL.PARSE(nCursor,
      'UPDATE GRREC_GRE@DBLMXM' || TO_CHAR(nPAR_DBLMXM) ||
      '   SET GRE_DSGRUPO        = ''' || PGRE_DSGRUPO       || ''',' ||
      '       GRE_CTBGRUPO       = ''' || PGRE_CTBGRUPO      || ''',' ||
      '       GRE_CDPLCTB        = ''' || PGRE_CDPLCTB       || ''',' ||
      '       GRE_CDPLCC         = ''' || PGRE_CDPLCC        || ''',' ||
      '       GRE_CDFCAIXA       = ''' || PGRE_CDFCAIXA      || ''',' ||
      '       GRE_CTAFCAIXA      = ''' || PGRE_CTAFCAIXA     || ''',' ||
      '       GRE_CCCGRUPO       = ''' || PGRE_CCCGRUPO      || ''',' ||
      '       GRE_CTBRECFIN      = ''' || PGRE_CTBRECFIN     || ''',' ||
      '       GRE_CCCRECFIN      = ''' || PGRE_CCCRECFIN     || ''',' ||
      '       GRE_CTBDESFIN      = ''' || PGRE_CTBDESFIN     || ''',' ||
      '       GRE_CCCDESFIN      = ''' || PGRE_CCCDESFIN     || ''',' ||
      '       GRE_CTBVARMOR      = ''' || PGRE_CTBVARMOR     || ''',' ||
      '       GRE_CCCVARMOR      = ''' || PGRE_CCCVARMOR     || ''',' ||
      '       GRE_CTBVARMOP      = ''' || PGRE_CTBVARMOP     || ''',' ||
      '       GRE_CCCVARMOP      = ''' || PGRE_CCCVARMOP     || ''',' ||
      '       GRE_CTBVENCANC     = ''' || PGRE_CTBVENCANC    || ''',' ||
      '       GRE_CCCVENCANC     = ''' || PGRE_CCCVENCANC    || ''',' ||
      '       GRE_CTBCLIENTE     = ''' || PGRE_CTBCLIENTE    || ''',' ||
      '       GRE_CCCCLIENTE     = ''' || PGRE_CCCCLIENTE    || ''',' ||
      '       GRE_CTBGLOSAREC    = ''' || PGRE_CTBGLOSAREC   || ''',' ||
      '       GRE_CCCGLOSAREC    = ''' || PGRE_CCCGLOSAREC   || ''',' ||
      '       GRE_CTBREDRECEITA  = ''' || PGRE_CTBREDRECEITA || ''',' ||
      '       GRE_CCCREDRECEITA  = ''' || PGRE_CCCREDRECEITA || ''',' ||
      '       GRE_IMPOSTO1       = ''' || PGRE_IMPOSTO1      || ''',' ||
      '       GRE_IMPOSTO2       = ''' || PGRE_IMPOSTO2      || ''',' ||
      '       GRE_IMPOSTO3       = ''' || PGRE_IMPOSTO3      || ''',' ||
      '       GRE_IMPOSTO4       = ''' || PGRE_IMPOSTO1      || ''',' ||
      '       GRE_IMPOSTO5       = ''' || PGRE_IMPOSTO2      || ''',' ||
      '       GRE_IMPOSTO6       = ''' || PGRE_IMPOSTO3      || ''',' ||
      '       GRE_CODMODRATCCFIN = ''' || PGRE_CODMODRATCCFIN|| ''',' ||
      '       GRE_DTINATIVO      = ''' || PGRE_DTINATIVO     || ''',' ||
      '       GRE_CCONTABPDD     = ''' || PGRE_CCONTABPDD    || ''',' ||
      '       GRE_CCUSTOPDD      = ''' || PGRE_CCUSTOPDD     || ''',' ||
      '       GRE_CCONTAREDPDD   = ''' || PGRE_CCONTAREDPDD  || ''',' ||
      '       GRE_CCUSTOREDPDD   = ''' || PGRE_CCUSTOREDPDD  || ''',' ||
      '       GRE_CTBBXNFIN      = ''' || PGRE_CTBBXNFIN     || ''',' ||
      '       GRE_VBSERVICO      = ''' || PGRE_VBSERVICO     || ''',' ||
      '       GRE_NRRTS          = '   || PGRE_NRRTS         || ','   ||
      '       GRE_NRCAS          = '   || PGRE_NRCAS         ||
      ' WHERE GRE_CDGRUPO        = ''' || PGRE_CDGRUPO       || '''',
      nCursor);
      nRows   := dbms_sql.execute(nCursor);
      nPAR_DBLMXM := nPAR_DBLMXM - 1;
    END LOOP;
	dbms_sql.close_cursor(nCursor);
  END IF;
  CLOSE PARAMS;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276891
PROMPT ======================================================================