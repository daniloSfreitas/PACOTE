PROMPT ======================================================================
PROMPT == DEMANDA......: 272614
PROMPT == SISTEMA......: Frete
PROMPT == RESPONSAVEL..: JOSE BARBOSA DA SILVA JUNIOR
PROMPT == DATA.........: 23/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE FATURAS_FAT
   SET FAT_TPFATURA = (SELECT DECODE(CTP_TIPO,
                                       0, 35,--AQUAVIARIO
                                       1, 34,--RODOVIARIO
                                       4, 44,--DUTOVIARIO
                                       2, 45,--FERROVIARIO
                                       3, 46,--AEREOVIARIO
                                       34)
                         FROM INTMODFAT_IMF,
                              INTMODCTC_IMCT,
                              CONHECIMENTOTRANS_CTP
                        WHERE IMF_CDEMPRESA      = FAT_CDEMPRESA
                          AND IMF_CDFILIAL       = FAT_CDFILIAL
                          AND IMF_CDFATURA       = FAT_CDFATURA
                          AND IMF_SQINTEGRACAO   = IMCT_SQINTEGRACAO
                          AND CTP_SQCONHECIMENTO = IMCT_SQCONHECIMENTO)
 WHERE EXISTS(SELECT 1
                FROM INTMODFAT_IMF,
                     INTMODCTC_IMCT,
                              CONHECIMENTOTRANS_CTP
               WHERE IMF_CDEMPRESA      = FAT_CDEMPRESA
                 AND IMF_CDFILIAL       = FAT_CDFILIAL
                 AND IMF_CDFATURA       = FAT_CDFATURA
                 AND IMF_SQINTEGRACAO   = IMCT_SQINTEGRACAO
                 AND CTP_SQCONHECIMENTO = IMCT_SQCONHECIMENTO
                 AND DECODE(CTP_TIPO,
                               0, 35,--AQUAVIARIO
                               1, 34,--RODOVIARIO
                               4, 44,--DUTOVIARIO
                               2, 45,--FERROVIARIO
                               3, 46,--AEREOVIARIO
                               34) <> FAT_TPFATURA)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 272614
PROMPT ======================================================================