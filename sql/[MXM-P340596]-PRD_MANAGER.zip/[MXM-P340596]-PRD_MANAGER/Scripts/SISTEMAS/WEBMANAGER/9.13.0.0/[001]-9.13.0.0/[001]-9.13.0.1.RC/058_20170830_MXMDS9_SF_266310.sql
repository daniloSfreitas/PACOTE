PROMPT ======================================================================
PROMPT == DEMANDA......: 266310
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: Eduardo Lopes de Oliveira
PROMPT == DATA.........: 14/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE INDEX IN1_FATRPS_FFP ON FATRPS_FRP(FRP_CDEMPRESA, FRP_CDFILIAL, FRP_CDFATURA)
/

CREATE INDEX IN1_SPEDPARPART_PPA ON SPEDPARPART_PPA(PPA_CODMUNIC)
/

CREATE INDEX IN8_FATURAS_FAT ON FATURAS_FAT(FAT_CDCLIFOR)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 266310
PROMPT ======================================================================