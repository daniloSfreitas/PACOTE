PROMPT ======================================================================
PROMPT == DEMANDA......: 270766
PROMPT == SISTEMA......: Contabilidade
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 05/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM LOGTIPOFUNCAO_LTFC WHERE LTFC_CDTIPO IN (1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,29,30,31,32,33,35,36,37,38)
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (1, 'SCB - Libera��o do Per�odo Cont�bil para Digita��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (2, 'SCB - Bloqueio do Per�odo Cont�bil para Digita��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (23, 'ST.R - Libera��o do Per�odo Financeiro')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (24, 'ST.R - Bloqueio do Per�odo Financeiro')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (3, 'SCR - Libera��o do Per�odo para Digita��o Financeira')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (4, 'SCR - Bloqueio do Per�odo para Digita��o Financeira')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (5, 'SCP - Libera��o do Per�odo para Digita��o Financeira')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (6, 'SCP - Bloqueio do Per�odo para Digita��o Financeira')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (7, 'ST  - Libera��o do Per�odo Financeiro')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (8, 'ST  - Bloqueio do Per�odo Financeiro')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (9, 'SAP - Libera��o do Movimento Patrimonial')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (10, 'SAP - Bloqueio do Movimento Patrimonial')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (11, 'SCC - Libera��o do Per�odo Cont�bil para Custeio')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (12, 'SCC - Bloqueio do Per�odo Cont�bil para Custeio')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (13, 'SCO - Libera��o de Per�odo de Digita��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (14, 'SCO - Bloqueio de Per�odo de Digita��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (15, 'SGE - Libera��o de Per�odo para Movimenta��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (16, 'SGE - Bloqueio de Per�odo para Movimenta��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (17, 'SF - Libera��o para Emiss�o de NF')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (18, 'SF - Bloqueio para Emiss�o de NF')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (19, 'SLF - Libera��o do Per�odo Fiscal para Digita��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (20, 'SLF - Bloqueio do Per�odo Fiscal para Digita��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (21, 'ST.P - Libera��o do Per�odo Financeiro')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (22, 'ST.P - Bloqueio do Per�odo Financeiro')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (25, 'SCB - Libera��o do Per�odo Cont�bil por Grupo de Trabalho')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (26, 'SCB - Bloqueio do Per�odo Cont�bil por Grupo de Trabalho')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (29, 'SCR - Libera��o do Per�odo Financeiro para Digita��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (30, 'SCR - Bloqueio do Per�odo Financeiro para Digita��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (31, 'SCP - Libera��o do Per�odo Financeiro para Digita��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (32, 'SCP - Bloqueio do Per�odo Financeiro para Digita��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (33, 'ST - Libera��o do Per�odo Financeiro para Digita��o')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (35, 'ST.P - Libera��o do Per�odo Financeiro para Conta')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (36, 'ST.P - Bloqueio do Per�odo Financeiro para Conta')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (37, 'ST.R - Libera��o do Per�odo Financeiro para Conta')
/

insert into LOGTIPOFUNCAO_LTFC (LTFC_CDTIPO, LTFC_DESCTIPO)
values (38, 'ST.R - Bloqueio do Per�odo Financeiro para Conta')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 270766
PROMPT ======================================================================