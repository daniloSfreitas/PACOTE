PROMPT ======================================================================
PROMPT == DEMANDA......: 278329
PROMPT == SISTEMA......: Escritura��o Fiscal Digital
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 17/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM MODOCFISC_MFIS WHERE MFIS_CODIGO = '67'
/

insert into MODOCFISC_MFIS (MFIS_CODIGO, MFIS_DESCRICAO) values ('67', 'CONHEC. DE TRANSP. ELETR�NICO - CT-E OS, MOD 67')
/

DELETE FROM TIPOENUMERADO_TENU WHERE TENU_CDTPENUMERADO = 'TPENU_INFCOMPDISPENSAPISCOFINS'
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_INFCOMPDISPENSAPISCOFINS', '01', 'Pessoa jur�dica imune ou isenta do IRPJ')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_INFCOMPDISPENSAPISCOFINS', '02', '�rg�os p�blicos, autarquias e funda��es p�blicas')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_INFCOMPDISPENSAPISCOFINS', '03', 'Pessoa jur�dica inativa')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_INFCOMPDISPENSAPISCOFINS', '04', 'Pessoa jur�dica em geral, que n�o realizou opera��es geradoras de receitas (tribut�veis ou
n�o) ou de cr�ditos')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_INFCOMPDISPENSAPISCOFINS', '05', 'Sociedade em Conta de Participa��o - SCP, que n�o realizou opera��es geradoras de
receitas (tribut�veis ou n�o) ou de cr�ditos')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_INFCOMPDISPENSAPISCOFINS', '06', 'Sociedade Cooperativa, que n�o realizou opera��es geradoras de receitas (tribut�veis ou
n�o) ou de cr�ditos')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_INFCOMPDISPENSAPISCOFINS', '07', 'Escritura��o decorrente de incorpora��o, fus�o ou cis�o, sem opera��es geradoras de
receitas (tribut�veis ou n�o) ou de cr�ditos')
/

insert into TIPOENUMERADO_TENU (TENU_CDTPENUMERADO, TENU_VALORARMAZENADO, TENU_DESCRICAO)
values ('TPENU_INFCOMPDISPENSAPISCOFINS', '99', 'Demais hip�teses de dispensa de escritura��o, relacionadas no art. 5�, da IN RFB n� 1.252, de
2012')
/

alter table EFDIDENTPERDISPESC_IPD add ipd_vbgerarregistro VARCHAR2(1)
/

comment on column EFDIDENTPERDISPESC_IPD.ipd_vbgerarregistro
  is 'Indicador se o registro ser� gerado somente na apura��o de dezembro ou no mes da escritura��o.'
/

CREATE OR REPLACE PROCEDURE INSEFDIDENTPERDISPESC_IPD(
 PIPD_IDIPD IN OUT NUMBER
,PIPD_CDEMPRESA IN CHAR
,PIPD_CDFILIAL IN CHAR
,PIPD_DSMESDISPENSA IN CHAR
,PIPD_DSINFCOMPLEMENTAR IN CHAR DEFAULT NULL
,PIPD_VBGERARREGISTRO IN CHAR
)
AS
BEGIN
  IF PIPD_IDIPD IS NULL THEN
   SELECT SEQ1_EFDIDENTPERDISPESC_IPD.NEXTVAL INTO PIPD_IDIPD FROM DUAL;
  END IF;
  INSERT INTO EFDIDENTPERDISPESC_IPD(
    IPD_IDIPD
   ,IPD_CDEMPRESA
   ,IPD_CDFILIAL
   ,IPD_DSMESDISPENSA
   ,IPD_DSINFCOMPLEMENTAR
   ,IPD_DTINCLUSAO
   ,IPD_USINCLUSAO
   ,IPD_VBGERARREGISTRO
) VALUES (
    PIPD_IDIPD
   ,PIPD_CDEMPRESA
   ,PIPD_CDFILIAL
   ,PIPD_DSMESDISPENSA
   ,PIPD_DSINFCOMPLEMENTAR
   ,SYSDATE
   ,GET_USER_MXM
   ,PIPD_VBGERARREGISTRO
);
END;
/

CREATE OR REPLACE PROCEDURE ALTEFDIDENTPERDISPESC_IPD(
 PIPD_IDIPD IN NUMBER
,PIPD_CDEMPRESA IN CHAR
,PIPD_CDFILIAL IN CHAR
,PIPD_DSMESDISPENSA IN CHAR
,PIPD_DSINFCOMPLEMENTAR IN CHAR DEFAULT NULL
,PIPD_VBGERARREGISTRO IN CHAR
)
AS
BEGIN
  UPDATE EFDIDENTPERDISPESC_IPD
     SET IPD_IDIPD = PIPD_IDIPD
        ,IPD_CDEMPRESA = PIPD_CDEMPRESA
        ,IPD_CDFILIAL = PIPD_CDFILIAL
        ,IPD_DSMESDISPENSA = PIPD_DSMESDISPENSA
        ,IPD_DSINFCOMPLEMENTAR = PIPD_DSINFCOMPLEMENTAR
        ,IPD_DTALTERACAO = SYSDATE
        ,IPD_USALTERACAO = GET_USER_MXM
        ,IPD_VBGERARREGISTRO = PIPD_VBGERARREGISTRO
   WHERE IPD_IDIPD = PIPD_IDIPD;
END;
/

delete from ERROMSG_ERM WHERE ERM_CDERRO IN ('IPD0011','IPD0012')
/

insert into ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO)
values ('IPD0011', 'Informa��o complementar obrigat�ria.')
/

insert into ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO)
values ('IPD0012', 'Informa��o complementar inexistente.')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 278329
PROMPT ======================================================================