PROMPT ======================================================================
PROMPT == DEMANDA......: 276475
PROMPT == SISTEMA......: Tesouraria
PROMPT == RESPONSAVEL..: MARCEL BRUNO BARREIROS COSTA
PROMPT == DATA.........: 10/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE TRIGGER TMOVIST_MST BEFORE INSERT OR UPDATE OR DELETE ON MOVIST_MST
  FOR EACH ROW
DECLARE
  cAprovNaBaixa  CHAR;
  nVALORMINBAIXA NUMBER;
  cPV            CHAR;   -- ponto ou virgula para uso oracle instalado em portugues ou ingles
  cEXCAPROVTITBX CHAR;
  cCTBDATA       DATE;
  CURSOR APROVNABAIXA IS
    SELECT PAR_VLPARAM FROM PARAMS_PAR WHERE PAR_CDPARAM = 'wSGP_APROVNABAIXA';
  CURSOR VALORMINBAIXA IS
    SELECT TO_NUMBER(REPLACE(REPLACE(PAR_VLPARAM,'.',''),cPV,'.'))
      FROM PARAMS_PAR WHERE PAR_CDPARAM = 'wSGP_VALORMINBAIXA';
BEGIN
  IF :OLD.MST_RP = 'P' OR :NEW.MST_RP = 'P' THEN
    OPEN  APROVNABAIXA;
    FETCH APROVNABAIXA INTO cAprovNaBaixa;
    IF APROVNABAIXA%NOTFOUND THEN
      cAprovNaBaixa := 'N';
    END IF;
    CLOSE APROVNABAIXA;
  END IF;
  IF DELETING THEN
    INSERT INTO LOGDELMXM_LOG(LOG_NMTB, LOG_STR1, LOG_STR2, LOG_DTLOG, LOG_USER)
      VALUES('MOVIST_MST', :OLD.MST_CDCONTA, :OLD.MST_NOLANC, SYSDATE, GET_USER_MXM);
    IF (:OLD.MST_NOCHEQUE IS NOT NULL) AND (:OLD.MST_LANCCTB IS NOT NULL) THEN
      IF :OLD.MST_DTCOMPETENCIA IS NULL
       THEN
         cCTBDATA := :OLD.MST_DATA;
       ELSE
         cCTBDATA := :OLD.MST_DTCOMPETENCIA;
       END IF;
      CTBHISTCHQ('E',:OLD.MST_NOCHEQUE,'',:OLD.MST_LOTE,cCTBDATA,:OLD.MST_LANCCTB);
    END IF;
    IF :OLD.MST_RP = 'P' THEN
      EXCAPROVTITBX_ATB(:OLD.MST_CDEMPORI,:OLD.MST_CDCONTA,:OLD.MST_NOLANC,:OLD.MST_DATA);
      /*Insere com o valor positivo para adicionar saldo da conta tabela de saldo da conta corrente*/
      INSERT INTO CTASLDMES_CSM(CSM_CDCONTA, CSM_ANO, CSM_MES, CSM_SALDO, CSM_TIPO)
       VALUES(:OLD.MST_CDCONTA, TO_CHAR(:OLD.MST_DATA,'YYYY'), TO_CHAR(:OLD.MST_DATA,'MM'), :OLD.MST_VALOR, 2);
    END IF;
    IF :OLD.MST_RP = 'R' THEN
      /*Insere com o valor negativo para retirar do saldo da conta tabela de saldo da conta corrente*/
      INSERT INTO CTASLDMES_CSM(CSM_CDCONTA, CSM_ANO, CSM_MES, CSM_SALDO, CSM_TIPO)
       VALUES(:OLD.MST_CDCONTA, TO_CHAR(:OLD.MST_DATA,'YYYY'), TO_CHAR(:OLD.MST_DATA,'MM'), -:OLD.MST_VALOR, 2);
    END IF;
    RETMOVIST_MST(:OLD.MST_CDCONTA, :OLD.MST_NOLANC, :OLD.MST_RP, :OLD.MST_DATA, :OLD.MST_VALOR, :OLD.MST_LANCCTB,
                  :OLD.MST_LOTE,:OLD.MST_SYSTEM, :OLD.MST_CDCLIFOR, :OLD.MST_DOCUMENTO);
  END IF;
  IF UPDATING OR INSERTING THEN
    IF :NEW.MST_RP = 'P' AND cAprovNaBaixa = 'S' THEN
      cEXCAPROVTITBX := 'N';
      IF UPDATING AND NVL(:NEW.MST_NOCHEQUE,'') = NVL(:OLD.MST_NOCHEQUE,'') AND NVL(:NEW.MST_STATUSDOC,'') = NVL(:OLD.MST_STATUSDOC,'') THEN
        cEXCAPROVTITBX := 'S';
        EXCAPROVTITBX_ATB(:OLD.MST_CDEMPORI,:OLD.MST_CDCONTA,:OLD.MST_NOLANC,:OLD.MST_DATA);
      END IF;
      IF INSERTING OR cEXCAPROVTITBX = 'S' THEN
        BEGIN
          SELECT TO_NUMBER('1.5') INTO nVALORMINBAIXA FROM DUAL;
          cPV := ',';
        EXCEPTION WHEN OTHERS THEN
          cPV := '.';
        END;
        OPEN  VALORMINBAIXA;
        FETCH VALORMINBAIXA INTO nVALORMINBAIXA;
        CLOSE VALORMINBAIXA;
        IF nVALORMINBAIXA IS NULL OR :NEW.MST_VALOR >= nVALORMINBAIXA THEN
          INSAPROVTITBX_ATB(:NEW.MST_CDEMPORI,:NEW.MST_CDCONTA,:NEW.MST_NOLANC,:NEW.MST_DATA);
        END IF;
      END IF;
    END IF;
    IF UPDATING THEN
      IF :OLD.MST_RP = 'P' THEN
       /*Insere com o valor positivo para adicionar saldo da conta tabela de saldo da conta corrente*/
       INSERT INTO CTASLDMES_CSM(CSM_CDCONTA, CSM_ANO, CSM_MES, CSM_SALDO, CSM_TIPO)
        VALUES(:OLD.MST_CDCONTA, TO_CHAR(:OLD.MST_DATA,'YYYY'), TO_CHAR(:OLD.MST_DATA,'MM'), :OLD.MST_VALOR, 2);
      END IF;
      IF :OLD.MST_RP = 'R' THEN
       /*Insere com o valor negativo para retirar do saldo da conta tabela de saldo da conta corrente*/
       INSERT INTO CTASLDMES_CSM(CSM_CDCONTA, CSM_ANO, CSM_MES, CSM_SALDO, CSM_TIPO)
        VALUES(:OLD.MST_CDCONTA, TO_CHAR(:OLD.MST_DATA,'YYYY'), TO_CHAR(:OLD.MST_DATA,'MM'), -:OLD.MST_VALOR, 2);
      END IF;
      IF (NVL(:OLD.MST_NOCHEQUE,' ') <> NVL(:NEW.MST_NOCHEQUE,' ')) THEN
        IF (:OLD.MST_NOCHEQUE IS NOT NULL) AND (:OLD.MST_LANCCTB IS NOT NULL) THEN
          IF :OLD.MST_DTCOMPETENCIA IS NULL
           THEN
             cCTBDATA := :OLD.MST_DATA;
           ELSE
             cCTBDATA := :OLD.MST_DTCOMPETENCIA;
           END IF;
          CTBHISTCHQ('E',:OLD.MST_NOCHEQUE,'',:OLD.MST_LOTE,cCTBDATA,:OLD.MST_LANCCTB);
        END IF;
        IF (:NEW.MST_NOCHEQUE IS NOT NULL) AND (:NEW.MST_LANCCTB IS NOT NULL) THEN
          IF :NEW.MST_DTCOMPETENCIA IS NULL
           THEN
             cCTBDATA := :NEW.MST_DATA;
           ELSE
             cCTBDATA := :NEW.MST_DTCOMPETENCIA;
           END IF;
          CTBHISTCHQ('I',:NEW.MST_NOCHEQUE,'',:NEW.MST_LOTE,cCTBDATA,:NEW.MST_LANCCTB);
        END IF;
      END IF;
    END IF;
   IF :NEW.MST_RP = 'P' THEN
      /*Insere com o valor negativo para retirar saldo da conta tabela de saldo da conta corrente*/
    INSERT INTO CTASLDMES_CSM(CSM_CDCONTA, CSM_ANO, CSM_MES, CSM_SALDO, CSM_TIPO)
      VALUES(:NEW.MST_CDCONTA, TO_CHAR(:NEW.MST_DATA,'YYYY'), TO_CHAR(:NEW.MST_DATA,'MM'), -:NEW.MST_VALOR, 2);
   END IF;
   IF :NEW.MST_RP = 'R' THEN
      /*Insere com o valor positivo para adicionar saldo da conta tabela de saldo da conta corrente*/
       INSERT INTO CTASLDMES_CSM(CSM_CDCONTA, CSM_ANO, CSM_MES, CSM_SALDO, CSM_TIPO)
      VALUES(:NEW.MST_CDCONTA, TO_CHAR(:NEW.MST_DATA,'YYYY'), TO_CHAR(:NEW.MST_DATA,'MM'), :NEW.MST_VALOR, 2);
   END IF;
  END IF;
END;

/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276475
PROMPT ======================================================================