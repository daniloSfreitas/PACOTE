PROMPT ======================================================================
PROMPT == DEMANDA......: 276459
PROMPT == SISTEMA......: Escritura��o Cont�bil Fiscal
PROMPT == RESPONSAVEL..: DEBORAH EVELYN MOREIRA DA ROCHA
PROMPT == DATA.........: 11/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DELETE FROM ERROMSG_ERM WHERE ERM_CDERRO IN ('CI10048', 'CI10049')
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES ('CI10048', 'Contabiliza��o alternativa obrigt�ria (S/N).')
/

INSERT INTO ERROMSG_ERM (ERM_CDERRO, ERM_DSERRO) VALUES ('CI10049', 'A op��o Gerar Contabiliza��o dos Valores Brutos n�o pode ser selecionada quando for utilizada a op��o de gera��o de t�tulo cont�bil.')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 276459
PROMPT ======================================================================