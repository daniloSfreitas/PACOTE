PROMPT ======================================================================
PROMPT == DEMANDA......: 275824
PROMPT == SISTEMA......: Cadastros Comuns
PROMPT == RESPONSAVEL..: VICTOR SANTOS DE MELLO
PROMPT == DATA.........: 16/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

INSERT INTO GRECAMPOS_CDR (CDR_IDCAMPO,CDR_NRTABELA,CDR_DSCAMPOTABELA,CDR_DSCAMPO,
CDR_TPCAMPO,CDR_DSCAMPOTABELACABECALHO)
VALUES ((SELECT MAX(CDR_IDCAMPO)+1 FROM GRECAMPOS_CDR), (SELECT TDR_IDTABELA FROM GRETABDICDADOS_TDR WHERE TDR_NMTABELA='CLIENTE_CLI'),'CLIENTE_CLI.CLI_DTCAD','Data de Cadastro',1,'Cadastro')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 275824
PROMPT ======================================================================