PROMPT ======================================================================
PROMPT == DEMANDA......: 269484
PROMPT == SISTEMA......: Patrimonio
PROMPT == RESPONSAVEL..: KAROLLYNE MENDES DA SILVA
PROMPT == DATA.........: 18/09/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE SAPLOTEBAIXA_SLT ADD (SLT_CDSTATUS CHAR(1) DEFAULT 'A' NOT NULL)
/

comment on column SAPLOTEBAIXA_SLT.SLT_CDSTATUS
  is 'B - Baixado, A - Em aberto'
/

UPDATE SAPLOTEBAIXA_SLT SET SLT_CDSTATUS = 'B' WHERE SLT_IDLOTEBAIXA IN (SELECT SBL_NRLOTEBAIXA FROM SAPBAIXALOTE_SBL)
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 269484
PROMPT ======================================================================