PROMPT ======================================================================
PROMPT == DEMANDA......: 278226
PROMPT == SISTEMA......: Escritura��o Cont�bil Digital
PROMPT == RESPONSAVEL..: VICTOR DANTAS DA SILVA
PROMPT == DATA.........: 21/09/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE PROCEDURE ECD_PROCESSA_RJ210 (PSME_CODIGO IN VARCHAR2, PTOTALREGISTRO_J210 OUT NUMBER, PTOTALREGISTRO_J215 OUT NUMBER) AS
--TIPOS RJ210
  TYPE TP_REGJ210       IS TABLE OF ECDDLPADMPL_J21.J21_CDREG%TYPE;
  TYPE TP_VBINDTIP      IS TABLE OF ECDDLPADMPL_J21.J21_VBINDTIP%TYPE;
  TYPE TP_CDAGL         IS TABLE OF ECDDLPADMPL_J21.J21_CDAGL%TYPE;
  TYPE TP_DSCODAGL      IS TABLE OF ECDDLPADMPL_J21.J21_DSCODAGL%TYPE;
  TYPE TP_VLCTA         IS TABLE OF ECDDLPADMPL_J21.J21_VLCTA%TYPE;
  TYPE TP_VLCTAINI      IS TABLE OF ECDDLPADMPL_J21.J21_VLCTAINI%TYPE;
  TYPE TP_SMECODIGO    IS TABLE OF ECDDLPADMPL_J21.SMECODIGO%TYPE;
--VARIAVEIS RJ210
  LST_REGJ210         TP_REGJ210;
  LST_VBINDTIP        TP_VBINDTIP;
  LST_CDAGL           TP_CDAGL;
  LST_DSCODAGL        TP_DSCODAGL;
  LST_VLCTA           TP_VLCTA;
  LST_VLCTAINI        TP_VLCTAINI;
  LST_SMECODIGO       TP_SMECODIGO;
  PIDR210             NUMBER;
--TIPOS RJ215
  TYPE TP_REGJ215     IS TABLE OF ECDFATCTBDLPADMPL_J22.J22_CDREG%TYPE;
  TYPE TP_CDHISTFAT   IS TABLE OF ECDFATCTBDLPADMPL_J22.J22_CDHISTFAT%TYPE;
  TYPE TP_VLFATCONT   IS TABLE OF ECDFATCTBDLPADMPL_J22.J22_VLFATCONT%TYPE;
--VARIAVEIS RJ215
   LST_REGJ215     TP_REGJ215;
   LST_CDHISTFAT   TP_CDHISTFAT;
   LST_VLFATCONT   TP_VLFATCONT;
   PIDR215         NUMBER;
-- VARIAVEIS GLOBAIS
  CDEMPRESA                  VARCHAR2(4);
  ISCONSOLIDADORA            VARCHAR2(1);
  PRIMEIRODIA                VARCHAR2(2);
  CODMODAGL                  SPEDPAREMPPLCONTAS_PEPC.PEPC_CODMODAGL%TYPE;
  QRY                        LONG;
  QRY_215                    LONG;
  STR_EQUIV_LCT              LONG;
  STR_EQUIV_MEN              LONG;
  CURSOR GET_EMPRESA_FROM_SMECODIGO IS
    SELECT SME_CDEMPRESA
      FROM SPEDMODELOESCRT_SME
     WHERE SME_CODIGO = PSME_CODIGO
       AND SME_SYSTEMID = 'ECD';
  CURSOR GET_EMPRESA_CONSOLIDADORA IS
    SELECT EMP_CONSOLIDACAO
      FROM EMPGERAL_EMP
     WHERE EMP_CODIGO = CDEMPRESA;
  CURSOR GET_MODELO_AGLUTINACAO IS
    SELECT PEPC_CODMODAGL
      FROM SPEDPAREMPRESA_PEMP,SPEDPAREMPPLCONTAS_PEPC
     WHERE PEMP_IDPEMP = PEPC_IDPEMP
       AND PEMP_CDFILIAL IS NULL
       AND PEMP_CDEMPRESA = CDEMPRESA;
BEGIN
  DELETE FROM ECDFATCTBDLPADMPL_J22 WHERE SMECODIGO = PSME_CODIGO;
  DELETE FROM ECDDLPADMPL_J21  WHERE SMECODIGO = PSME_CODIGO;
  SELECT TO_CHAR(CASE
                 WHEN (SME_DTINIDEMCONTAB IS NOT NULL AND
                      SME_DTFIMDEMCONTAB IS NOT NULL) THEN
                  SME_DTINIDEMCONTAB
                 ELSE
                  SME_DTINICIO
               END,
               'DD')
   INTO PRIMEIRODIA
   FROM SPEDMODELOESCRT_SME
  WHERE SME_CODIGO = PSME_CODIGO
    AND SME_SYSTEMID = 'ECD';
  /*Busca a empresa de acordo com o SMECodigo*/
  OPEN GET_EMPRESA_FROM_SMECODIGO;
  FETCH GET_EMPRESA_FROM_SMECODIGO INTO CDEMPRESA;
  CLOSE GET_EMPRESA_FROM_SMECODIGO;
  /*Verifica se a empresa � consolidadora*/
  OPEN GET_EMPRESA_CONSOLIDADORA;
  FETCH GET_EMPRESA_CONSOLIDADORA  INTO ISCONSOLIDADORA;
  CLOSE GET_EMPRESA_CONSOLIDADORA;
  /*Busca o c�digo do Modelo de Aglutina��o*/
  OPEN GET_MODELO_AGLUTINACAO;
  FETCH GET_MODELO_AGLUTINACAO  INTO CODMODAGL;
  CLOSE GET_MODELO_AGLUTINACAO;
  STR_EQUIV_LCT  := '';
  STR_EQUIV_MEN  := '';
  STR_EQUIV_LCT  := GET_LANCCTB_EQUIV(CDEMPRESA);
  STR_EQUIV_MEN  := GET_CUSTOMES_EQUIV(CDEMPRESA);
  PTOTALREGISTRO_J210 := 0;
  PTOTALREGISTRO_J215 := 0;
  QRY := '';
  QRY := QRY || '  SELECT REG,                                                ';
  QRY := QRY || '       VBINDTIP,                                             ';
  QRY := QRY || '       CDAGL,                                                ';
  QRY := QRY || '       DSCODAGL,                                             ';
  QRY := QRY || '       VLCTA,                                                ';
  QRY := QRY || '       VLCTAINI,                                             ';
  QRY := QRY || '       SMECODIGO                                             ';
  QRY := QRY || '  FROM(                                                      ';
  QRY := QRY || 'SELECT ''J210'' AS REG,                                      ';
  QRY := QRY || '       NVL(LCT.VBINDTIP,''1'') AS VBINDTIP,                  ';
  QRY := QRY || '       LCT.COD_AGL AS CDAGL,                                 ';
  QRY := QRY || '       LCT.DESCR_COD_AGL AS DSCODAGL,                        ';
  QRY := QRY || '       SUM(NVL(NVL(CMES.VL_CTA, 0) + NVL(LCT.VL_CTA,0) , 0)) AS VLCTA, ';
  QRY := QRY || '       SUM(NVL(CMES.VL_CTA_INI, 0) + NVL(LCT.VL_CTA_INI, 0)) AS VLCTAINI,';
  QRY := QRY || '       LCT.SMECODIGO,                                          ';
  QRY := QRY || '       SUM(LCT.CONTROLE) AS CONTROLE                           ';
  QRY := QRY || '  FROM (SELECT SMECODIGO,                                      ';
  QRY := QRY || '               SCA_CODIGO AS COD_AGL,                          ';
  QRY := QRY || '               SCA_DESCRICAO AS DESCR_COD_AGL,                 ';
  QRY := QRY || '               SUM(VL_CTA) AS VL_CTA,                          ';
  QRY := QRY || '               SUM(VL_CTA_INI) AS VL_CTA_INI,                  ';
  QRY := QRY || '               SUM(CONTROLE) AS CONTROLE                       ';
  QRY := QRY || '  FROM (SELECT SME_CODIGO AS SMECODIGO,                        ';
  QRY := QRY || '               SCA.SCA_CODIGO AS COD_AGL,                      ';
  QRY := QRY || '               SCA.SCA_DESCRICAO AS DESCR_COD_AGL,             ';
  QRY := QRY || '               SUM(DEBITO - CREDITO) AS VL_CTA,                ';
  QRY := QRY || '               SUM(DEBITO - CREDITO) AS VL_CTA_INI,            ';
  QRY := QRY || '               1 AS CONTROLE                                   ';
  QRY := QRY || '          FROM SPEDMODELOESCRT_SME    SME,                     ';
  QRY := QRY || '               EMPGERAL_EMP           EMP,                     ';
  QRY := QRY || '               '|| STR_EQUIV_MEN || ' MEN,                     ';
  QRY := QRY || '               PLANOCTA_PLC           PLC,                     ';
  QRY := QRY || '               SPEDCODAGLUTINACAO_SCA SCA,                     ';
  QRY := QRY || '               SPEDPARCCONTAB_SPCC    SPCC                     ';
  QRY := QRY || '         WHERE SME.SME_CODIGO = ''' || PSME_CODIGO || '''      ';
  QRY := QRY || '           AND SME.SME_SYSTEMID = ''ECD''                      ';
  IF ISCONSOLIDADORA = 'S'
   THEN
     BEGIN
       QRY := QRY || '           AND EXISTS(SELECT NULL                            ';
       QRY := QRY || '                        FROM EMP_CONS                        ';
       QRY := QRY || '                       WHERE CONS_CDEMPTIT  = SME_CDEMPRESA  ';
       QRY := QRY || '                         AND CONS_CDEMPRESA = EMP.EMP_CODIGO)';
     END;
   ELSE
     QRY := QRY || '           AND SME.SME_CDEMPRESA = EMP.EMP_CODIGO           ';
  END IF;
  QRY := QRY || '           AND EMP.EMP_CODIGO       = MEN.CMES_CDEMPRESA       ';
  QRY := QRY || '           AND MEN.ANOMES           <   TO_CHAR(CASE WHEN(    SME.SME_DTINIDEMCONTAB IS NOT NULL  ';
  QRY := QRY || '                                                          AND SME.SME_DTFIMDEMCONTAB IS NOT NULL) ';
  QRY := QRY || '                                                     THEN SME.SME_DTINIDEMCONTAB                  ';
  QRY := QRY || '                                                     ELSE SME.SME_DTINICIO                        ';
  QRY := QRY || '                                                 END, ''YYYYMM'')                                 ';
  QRY := QRY || '           AND PLC.PLC_CODPLANO     = MEN.CMES_PLCONTAB        ';
  QRY := QRY || '           AND MEN.CMES_NOCONTAB    = PLC_NOCONTAB             ';
  QRY := QRY || '           AND PLC.PLC_CODPLANO     = SPCC.SPCC_PLCONTAB       ';
  QRY := QRY || '           AND PLC.PLC_NOCONTAB     = SPCC.SPCC_NOCONTAB       ';
  QRY := QRY || '           AND PLC_SA               = ''A''                    ';
  QRY := QRY || '           AND NVL(PLC.PLC_CONTRESUL,''N'')   <> ''S''         ';
  QRY := QRY || '           AND SCA_CODMODAGL        = ''' || CODMODAGL || '''  ';
  QRY := QRY || '           AND SPCC.SPCC_CODMODAGL  = SCA_CODMODAGL            ';
  QRY := QRY || '           AND SPCC.SPCC_CODIGOAGLU = SCA.SCA_CODIGO           ';
  QRY := QRY || '           AND SPCC_CODNAT          = ''03''                   ';
  QRY := QRY || '           AND SCA_SA               = ''A''                    ';
  QRY := QRY || '        GROUP BY SCA.SCA_CODIGO                                ';
  QRY := QRY || '               , SCA.SCA_NIVELAGL                              ';
  QRY := QRY || '               , SCA.SCA_DESCRICAO                             ';
  QRY := QRY || '               , SME_CODIGO                                    ';
  IF PRIMEIRODIA <> '01' THEN
    -- Incluindo Query para buscar o saldo inicial quando o modelo de escritura��o n�o come�ar no primeiro dia do m�s.
    QRY := QRY || '  UNION ALL                                                    ';
    QRY := QRY || '  SELECT SME_CODIGO AS SMECODIGO,                        ';
    QRY := QRY || '         SCA.SCA_CODIGO AS COD_AGL,                      ';
    QRY := QRY || '         SCA.SCA_DESCRICAO AS DESCR_COD_AGL,             ';
    QRY := QRY || '         SUM(DECODE(LCT.LCT_DC,''D'',LCT.LCT_VALOR,(LCT.LCT_VALOR * -1))) AS VL_CTA,';
    QRY := QRY || '         SUM(DECODE(LCT.LCT_DC,''D'',LCT.LCT_VALOR,(LCT.LCT_VALOR * -1))) AS VL_CTA_INI,';
    QRY := QRY || '         0 AS CONTROLE                                   ';
    QRY := QRY || '    FROM SPEDPARCCONTAB_SPCC    SPCC,                    ';
    QRY := QRY || '         PLANOCTA_PLC           PLC,                     ';
    QRY := QRY || '         SPEDCODAGLUTINACAO_SCA SCA,                     ';
    QRY := QRY || '         '|| STR_EQUIV_LCT || ' LCT,                     ';
    QRY := QRY || '         SPEDMODELOESCRT_SME    SME,                     ';
    QRY := QRY || '         EMPGERAL_EMP           EMP                     ';
    QRY := QRY || '         WHERE SME.SME_CODIGO = ''' || PSME_CODIGO || '''      ';
    QRY := QRY || '           AND SME.SME_SYSTEMID = ''ECD''                      ';
    IF ISCONSOLIDADORA = 'S'
     THEN
       BEGIN
         QRY := QRY || '           AND EXISTS(SELECT 1 FROM EMP_CONS                    ';
         QRY := QRY || '                        WHERE CONS_CDEMPTIT  = SME.SME_CDEMPRESA';
         QRY := QRY || '                          AND CONS_CDEMPRESA = EMP.EMP_CODIGO)  ';
       END;
     ELSE QRY := QRY || '           AND SME.SME_CDEMPRESA = EMP.EMP_CODIGO           ';
    END IF;
    QRY := QRY || '           AND EMP.EMP_CODIGO       = LCT.LCT_CDEMPRESA        ';
    QRY := QRY || '           AND TO_DATE(LCT.LCT_DATA,''DD/MM/YYYY'') >=  TO_DATE(''01/''||TO_CHAR(TO_DATE(CASE WHEN(    SME.SME_DTINIDEMCONTAB IS NOT NULL ';
    QRY := QRY || '                                                                                                   AND SME.SME_DTFIMDEMCONTAB IS NOT NULL)';
    QRY := QRY || '                                                                                              THEN SME.SME_DTINIDEMCONTAB                 ';
    QRY := QRY || '                                                                                              ELSE SME.SME_DTINICIO                       ';
    QRY := QRY || '                                                                                          END,''DD/MM/YYYY''),''MM/YYYY''),''DD/MM/YYYY'')';
    QRY := QRY || '           AND TO_DATE(LCT.LCT_DATA,''DD/MM/YYYY'')  <   TO_DATE(CASE WHEN(    SME.SME_DTINIDEMCONTAB IS NOT NULL  ';
    QRY := QRY || '                                                                           AND SME.SME_DTFIMDEMCONTAB IS NOT NULL) ';
    QRY := QRY || '                                                                      THEN SME.SME_DTINIDEMCONTAB                  ';
    QRY := QRY || '                                                                      ELSE SME.SME_DTINICIO                        ';
    QRY := QRY || '                                                                  END, ''DD/MM/YYYY'')                             ';
    QRY := QRY || '           AND PLC.PLC_CODPLANO     = LCT.LCT_PLCONTAB         ';
    QRY := QRY || '           AND PLC_NOCONTAB         = LCT.LCT_NOCONTAB         ';
    QRY := QRY || '           AND PLC.PLC_CODPLANO     = SPCC.SPCC_PLCONTAB       ';
    QRY := QRY || '           AND PLC.PLC_NOCONTAB     = SPCC.SPCC_NOCONTAB       ';
    QRY := QRY || '           AND PLC_SA               = ''A''                    ';
    QRY := QRY || '           AND NVL(PLC.PLC_CONTRESUL,''N'')   <> ''S''         ';
    QRY := QRY || '           AND SPCC.SPCC_CODMODAGL  = SCA_CODMODAGL            ';
    QRY := QRY || '           AND SPCC.SPCC_CODIGOAGLU = SCA.SCA_CODIGO           ';
    QRY := QRY || '           AND SCA_CODMODAGL        = ''' || CODMODAGL || '''  ';
    QRY := QRY || '           AND SPCC_CODNAT          = ''03''                   ';
    QRY := QRY || '           AND SCA_SA               = ''A''                    ';
    QRY := QRY || '       GROUP BY SCA.SCA_CODIGO                                 ';
    QRY := QRY || '              , SCA.SCA_DESCRICAO                              ';
    QRY := QRY || '              , SME_CODIGO                                     ';
   END IF;
  QRY := QRY || '               ),SPEDCODAGLUTINACAO_SCA                          ';
  QRY := QRY || '         WHERE SUBSTR(COD_AGL, 1, LENGTH(SCA_CODIGO)) = SCA_CODIGO';
  QRY := QRY || '           AND SCA_CODMODAGL = ''' || CODMODAGL || '''         ';
  QRY := QRY || '           AND SCA_SA = ''A''                                  ';
  QRY := QRY || '         GROUP BY SMECODIGO, SCA_CODIGO, SCA_DESCRICAO) CMES,  ';
  QRY := QRY || '       (SELECT SMECODIGO,                                      ';
  QRY := QRY || '               VBINDTIP,                                       ';
  QRY := QRY || '               SCA_CODIGO AS COD_AGL,                          ';
  QRY := QRY || '               SCA_DESCRICAO AS DESCR_COD_AGL,                 ';
  QRY := QRY || '               SUM(VL_CTA) AS VL_CTA,                          ';
  QRY := QRY || '               0 AS VL_CTA_INI,                                ';
  QRY := QRY || '               SUM(CONTROLE) AS CONTROLE                                        ';
  QRY := QRY || '  FROM (SELECT SME_CODIGO AS SMECODIGO,                        ';
  QRY := QRY || '               CHF.CHF_VBTIPODEMONS as VBINDTIP,               ';
  QRY := QRY || '               SCA.SCA_CODIGO AS COD_AGL,                      ';
  QRY := QRY || '               SCA.SCA_DESCRICAO AS DESCR_COD_AGL,             ';
  QRY := QRY || '               SUM(DECODE(LCT.LCT_DC,''D'',LCT.LCT_VALOR,(LCT.LCT_VALOR * -1))) AS VL_CTA,';
  QRY := QRY || '               0 AS VL_CTA_INI,                                ';
  QRY := QRY || '               1 AS CONTROLE                                   ';
  QRY := QRY || '          FROM SPEDPARCCONTAB_SPCC    SPCC,                    ';
  QRY := QRY || '               PLANOCTA_PLC           PLC,                     ';
  QRY := QRY || '               SPEDCODAGLUTINACAO_SCA SCA,                     ';
  QRY := QRY || '               '|| STR_EQUIV_LCT || ' LCT,                     ';
  QRY := QRY || '               SPEDMODELOESCRT_SME    SME,                     ';
  QRY := QRY || '               EMPGERAL_EMP           EMP,                     ';
  QRY := QRY || '               ECDRELANCTBHISTCTB_RLH RLH,                     ';
  QRY := QRY || '               ECDCODHISTFATCTB_CHF   CHF                      ';
  QRY := QRY || '         WHERE CHF.CHF_CDFATCONTAB = RLH.RLH_CDHISTFATCTB      ';
  QRY := QRY || '           AND RLH.RLH_CDMODESCRIT = SME.SME_CODIGO            ';
  QRY := QRY || '           AND RLH.RLH_CDEMPRESA = EMP.EMP_CODIGO              ';
  QRY := QRY || '           AND RLH.RLH_LTCONTAB = LCT.LCT_LOTE                 ';
  QRY := QRY || '           AND RLH.RLH_DTLANCCTB = LCT.LCT_DATA                ';
  QRY := QRY || '           AND RLH.RLH_CDLANCCTB = LCT.LCT_LANCCTB             ';
  QRY := QRY || '           AND RLH.RLH_CDAGLU = SPCC_CODIGOAGLU                ';
  QRY := QRY || '           AND SME.SME_CODIGO = ''' || PSME_CODIGO || '''      ';
  QRY := QRY || '           AND SME.SME_SYSTEMID = ''ECD''                      ';
  IF ISCONSOLIDADORA = 'S'
   THEN
     BEGIN
       QRY := QRY || '           AND EXISTS(SELECT NULL                   ';
       QRY := QRY || '                         FROM EMP_CONS              ';
       QRY := QRY || '                        WHERE CONS_CDEMPTIT  = SME.SME_CDEMPRESA';
       QRY := QRY || '                          AND CONS_CDEMPRESA = EMP.EMP_CODIGO)  ';
     END;
   ELSE
     QRY := QRY || '           AND SME.SME_CDEMPRESA = EMP.EMP_CODIGO           ';
  END IF;
  QRY := QRY || '           AND EMP.EMP_CODIGO       = LCT.LCT_CDEMPRESA        ';
  QRY := QRY || '           AND TO_DATE(LCT.LCT_DATA,''DD/MM/YYYY'') >=  TO_DATE(''01/''||TO_CHAR(TO_DATE(CASE WHEN(    SME.SME_DTINIDEMCONTAB IS NOT NULL ';
  QRY := QRY || '                                                                                                   AND SME.SME_DTFIMDEMCONTAB IS NOT NULL)';
  QRY := QRY || '                                                                                              THEN SME.SME_DTINIDEMCONTAB                 ';
  QRY := QRY || '                                                                                              ELSE SME.SME_DTINICIO                       ';
  QRY := QRY || '                                                                                          END,''DD/MM/YYYY''),''MM/YYYY''),''DD/MM/YYYY'')';
  QRY := QRY || '           AND TO_DATE(LCT.LCT_DATA,''DD/MM/YYYY'') <= TO_DATE(SME_DTFIM,''DD/MM/YYYY'')';
  QRY := QRY || '           AND PLC.PLC_CODPLANO     = LCT.LCT_PLCONTAB         ';
  QRY := QRY || '           AND PLC_NOCONTAB         = LCT.LCT_NOCONTAB         ';
  QRY := QRY || '           AND PLC.PLC_CODPLANO     = SPCC.SPCC_PLCONTAB       ';
  QRY := QRY || '           AND PLC.PLC_NOCONTAB     = SPCC.SPCC_NOCONTAB       ';
  QRY := QRY || '           AND PLC_SA               = ''A''                    ';
  QRY := QRY || '           AND NVL(PLC.PLC_CONTRESUL,''N'')   <> ''S''         ';
  QRY := QRY || '           AND SPCC.SPCC_CODMODAGL  = SCA_CODMODAGL            ';
  QRY := QRY || '           AND SPCC.SPCC_CODIGOAGLU = SCA.SCA_CODIGO           ';
  QRY := QRY || '           AND SCA_CODMODAGL        = ''' || CODMODAGL || '''  ';
  QRY := QRY || '           AND SPCC_CODNAT          = ''03''                   ';
  QRY := QRY || '           AND SCA_SA               = ''A''                    ';
  QRY := QRY || '       GROUP BY SCA.SCA_CODIGO                                 ';
  QRY := QRY || '              , CHF_VBTIPODEMONS                               ';
  QRY := QRY || '              , SCA.SCA_DESCRICAO                              ';
  QRY := QRY || '              , SCA.SCA_INDVL                                  ';
  QRY := QRY || '              , SME_CODIGO                                     ';
  QRY := QRY || '  UNION ALL                                                    ';
  QRY := QRY || '        SELECT SME_CODIGO AS SMECODIGO,                        ';
  QRY := QRY || '               ''1''      AS VBINDTIP,                         ';
  QRY := QRY || '               SCA.SCA_CODIGO AS COD_AGL,                      ';
  QRY := QRY || '               SCA.SCA_DESCRICAO AS DESCR_COD_AGL,             ';
  QRY := QRY || '               0 AS VL_CTA,                                    ';
  QRY := QRY || '               0 AS VL_CTA_INI,                                ';
  QRY := QRY || '               0 AS CONTROLE                                   ';
  QRY := QRY || '          FROM SPEDPARCCONTAB_SPCC    SPCC,                    ';
  QRY := QRY || '               PLANOCTA_PLC           PLC,                     ';
  QRY := QRY || '               SPEDCODAGLUTINACAO_SCA SCA,                     ';
  QRY := QRY || '               SPEDMODELOESCRT_SME    SME,                     ';
  QRY := QRY || '               EMPGERAL_EMP           EMP                      ';
  QRY := QRY || '         WHERE SME.SME_CODIGO = ''' || PSME_CODIGO || '''      ';
  QRY := QRY || '           AND SME.SME_SYSTEMID = ''ECD''                      ';
  IF ISCONSOLIDADORA = 'S'
   THEN
     BEGIN
       QRY := QRY || '           AND EXISTS(SELECT NULL                   ';
       QRY := QRY || '                         FROM EMP_CONS              ';
       QRY := QRY || '                        WHERE CONS_CDEMPTIT  = SME.SME_CDEMPRESA';
       QRY := QRY || '                          AND CONS_CDEMPRESA = EMP.EMP_CODIGO)  ';
     END;
   ELSE
     QRY := QRY || '           AND SME.SME_CDEMPRESA = EMP.EMP_CODIGO           ';
  END IF;
  QRY := QRY || '           AND PLC.PLC_CODPLANO     = SPCC.SPCC_PLCONTAB       ';
  QRY := QRY || '           AND PLC.PLC_NOCONTAB     = SPCC.SPCC_NOCONTAB       ';
  QRY := QRY || '           AND PLC_SA               = ''A''                    ';
  QRY := QRY || '           AND NVL(PLC.PLC_CONTRESUL,''N'')   <> ''S''         ';
  QRY := QRY || '           AND SPCC.SPCC_CODMODAGL  = SCA_CODMODAGL            ';
  QRY := QRY || '           AND SPCC.SPCC_CODIGOAGLU = SCA.SCA_CODIGO           ';
  QRY := QRY || '           AND SCA_CODMODAGL        = ''' || CODMODAGL || '''  ';
  QRY := QRY || '           AND SPCC_CODNAT          = ''03''                   ';
  QRY := QRY || '           AND SCA_SA               = ''A''                    ';
  QRY := QRY || '      GROUP BY SCA.SCA_CODIGO                                  ';
  QRY := QRY || '             , SCA.SCA_DESCRICAO                               ';
  QRY := QRY || '             , SCA.SCA_INDVL                                   ';
  QRY := QRY || '             , SME_CODIGO                                      ';
  QRY := QRY || '             ),                                                ';
  QRY := QRY || '               SPEDCODAGLUTINACAO_SCA                          ';
  QRY := QRY || '         WHERE SUBSTR(COD_AGL, 1, LENGTH(SCA_CODIGO)) = SCA_CODIGO';
  QRY := QRY || '           AND SCA_CODMODAGL = ''' || CODMODAGL || '''         ';
  QRY := QRY || '           AND SCA_SA = ''A''                                  ';
  QRY := QRY || '         GROUP BY SMECODIGO, VBINDTIP, SCA_CODIGO, SCA_DESCRICAO) LCT';
  QRY := QRY || ' WHERE CMES.SMECODIGO(+)     = LCT.SMECODIGO                   ';
  QRY := QRY || '   AND CMES.COD_AGL(+)       = LCT.COD_AGL                     ';
  QRY := QRY || '   AND CMES.DESCR_COD_AGL(+) = LCT.DESCR_COD_AGL               ';
  QRY := QRY || ' GROUP BY LCT.VBINDTIP, LCT.COD_AGL, LCT.DESCR_COD_AGL, LCT.SMECODIGO)';
  QRY := QRY || '  WHERE ((VLCTA <> 0) OR (VLCTAINI <> 0) OR (CONTROLE = 1))    ';
  EXECUTE IMMEDIATE QRY BULK COLLECT INTO  LST_REGJ210
                                         , LST_VBINDTIP
                                         , LST_CDAGL
                                         , LST_DSCODAGL
                                         , LST_VLCTA
                                         , LST_VLCTAINI
                                         , LST_SMECODIGO;
    IF LST_REGJ210.EXISTS(1) THEN
     BEGIN
       FOR IDX_J210 IN LST_REGJ210.FIRST..LST_REGJ210.LAST LOOP
         BEGIN
          SELECT SEQ1_ECDDLPADMPL_J21.NEXTVAL INTO PIDR210 FROM DUAL;
          INSERT INTO ECDDLPADMPL_J21(
             IDRJ210
            ,SMECODIGO
            ,J21_CDREG
            ,J21_VBINDTIP
            ,J21_CDAGL
            ,J21_DSCODAGL
            ,J21_VLCTA
            ,J21_VBINDDCCTA
            ,J21_VLCTAINI
            ,J21_VBINDDCCTAINI
            ,J21_DTINCLUSAO
            ,J21_USINCLUSAO)
          VALUES (
             PIDR210
            ,LST_SMECODIGO(IDX_J210)
            ,LST_REGJ210(IDX_J210)
            ,LST_VBINDTIP(IDX_J210)
            ,LST_CDAGL(IDX_J210)
            ,LST_DSCODAGL(IDX_J210)
            ,TO_CHAR(ABS(LST_VLCTA(IDX_J210)),'FM99999999999999990D00')
            ,CASE WHEN (TO_NUMBER(LST_VLCTA(IDX_J210)) >= 0)
              THEN 'D'
              ELSE 'C'
             END
            ,TO_CHAR(ABS(LST_VLCTAINI(IDX_J210)),'FM99999999999999990D00')
            ,CASE WHEN (TO_NUMBER(LST_VLCTAINI(IDX_J210)) >= 0)
              THEN 'D'
              ELSE 'C'
             END
            ,SYSDATE
            ,GET_USER_MXM);
          PTOTALREGISTRO_J210 := PTOTALREGISTRO_J210 + 1;
          QRY_215 := '';
          QRY_215 := QRY_215 || 'SELECT ''J215'' AS REG,                                        ';
          QRY_215 := QRY_215 || '       RLH_CDHISTFATCTB AS COD_HIST_FAT,                       ';
          QRY_215 := QRY_215 || '       SUM(DECODE(LCT.LCT_DC, ''D'', LCT.LCT_VALOR, (LCT.LCT_VALOR * -1))) AS VL_FAT_CONT';
          QRY_215 := QRY_215 || '  FROM SPEDPARCCONTAB_SPCC    SPCC,                            ';
          QRY_215 := QRY_215 || '       PLANOCTA_PLC           PLC,                             ';
          QRY_215 := QRY_215 || '       SPEDCODAGLUTINACAO_SCA SCA,                             ';
          QRY_215 := QRY_215 || '      '|| STR_EQUIV_LCT || ' LCT,                              ';
          QRY_215 := QRY_215 || '       SPEDMODELOESCRT_SME    SME,                             ';
          QRY_215 := QRY_215 || '       EMPGERAL_EMP           EMP,                             ';
          QRY_215 := QRY_215 || '       ECDRELANCTBHISTCTB_RLH RLH,                             ';
          QRY_215 := QRY_215 || '       ECDCODHISTFATCTB_CHF   CHF                              ';
          QRY_215 := QRY_215 || ' WHERE CHF.CHF_CDFATCONTAB = RLH.RLH_CDHISTFATCTB              ';
          QRY_215 := QRY_215 || '   AND RLH.RLH_CDMODESCRIT = SME.SME_CODIGO                    ';
          QRY_215 := QRY_215 || '   AND RLH.RLH_CDEMPRESA = EMP.EMP_CODIGO                      ';
          QRY_215 := QRY_215 || '   AND RLH.RLH_LTCONTAB = LCT.LCT_LOTE                         ';
          QRY_215 := QRY_215 || '   AND RLH.RLH_DTLANCCTB = LCT.LCT_DATA                        ';
          QRY_215 := QRY_215 || '   AND RLH.RLH_CDLANCCTB = LCT.LCT_LANCCTB                     ';
          QRY_215 := QRY_215 || '   AND RLH.RLH_CDAGLU = SPCC_CODIGOAGLU                        ';
          QRY_215 := QRY_215 || '   AND SME.SME_CODIGO = ''' || PSME_CODIGO || '''              ';
          QRY_215 := QRY_215 || '   AND SME.SME_SYSTEMID = ''ECD''                              ';
          IF ISCONSOLIDADORA = 'S'
           THEN BEGIN
             QRY_215 := QRY_215 || '   AND EXISTS(SELECT NULL                                   ';
             QRY_215 := QRY_215 || '                  FROM EMP_CONS                             ';
             QRY_215 := QRY_215 || '                 WHERE CONS_CDEMPTIT  = SME.SME_CDEMPRESA   ';
             QRY_215 := QRY_215 || '                   AND CONS_CDEMPRESA = EMP.EMP_CODIGO)     ';
           END;
           ELSE
             QRY_215 := QRY_215 || '   AND SME.SME_CDEMPRESA = EMP.EMP_CODIGO                   ';
           END IF;
          QRY_215 := QRY_215 || '   AND EMP.EMP_CODIGO = LCT.LCT_CDEMPRESA                      ';
          QRY_215 := QRY_215 || '   AND TO_DATE(LCT.LCT_DATA,''DD/MM/YYYY'') >=  TO_DATE(''01/''||TO_CHAR(TO_DATE(CASE WHEN(    SME.SME_DTINIDEMCONTAB IS NOT NULL ';
          QRY_215 := QRY_215 || '                                                                                           AND SME.SME_DTFIMDEMCONTAB IS NOT NULL)';
          QRY_215 := QRY_215 || '                                                                                      THEN SME.SME_DTINIDEMCONTAB                 ';
          QRY_215 := QRY_215 || '                                                                                      ELSE SME.SME_DTINICIO                       ';
          QRY_215 := QRY_215 || '                                                                                  END,''DD/MM/YYYY''),''MM/YYYY''),''DD/MM/YYYY'')';
          QRY_215 := QRY_215 || '   AND TO_DATE(LCT.LCT_DATA,''DD/MM/YYYY'') <= TO_DATE(SME_DTFIM,''DD/MM/YYYY'')';
          QRY_215 := QRY_215 || '   AND PLC.PLC_CODPLANO = LCT.LCT_PLCONTAB                     ';
          QRY_215 := QRY_215 || '   AND PLC_NOCONTAB = LCT.LCT_NOCONTAB                         ';
          QRY_215 := QRY_215 || '   AND PLC.PLC_CODPLANO = SPCC.SPCC_PLCONTAB                   ';
          QRY_215 := QRY_215 || '   AND PLC.PLC_NOCONTAB = SPCC.SPCC_NOCONTAB                   ';
          QRY_215 := QRY_215 || '   AND SPCC_CODNAT          = ''03''                           ';
          QRY_215 := QRY_215 || '   AND SPCC.SPCC_CODMODAGL  = SCA_CODMODAGL                    ';
          QRY_215 := QRY_215 || '   AND SPCC.SPCC_CODIGOAGLU = SCA.SCA_CODIGO                   ';
          QRY_215 := QRY_215 || '   AND SCA_CODMODAGL        = ''' || CODMODAGL || '''          ';
          QRY_215 := QRY_215 || '   AND SCA_SA               = ''A''                            ';
          QRY_215 := QRY_215 || '   AND CHF_VBTIPODEMONS     = ''' || LST_VBINDTIP(IDX_J210) || '''';
          QRY_215 := QRY_215 || '   AND SCA_CODIGO           LIKE ''' || LST_CDAGL(IDX_J210) || '%''';
          QRY_215 := QRY_215 || ' GROUP BY RLH_CDHISTFATCTB                                     ';
          EXECUTE IMMEDIATE QRY_215 BULK COLLECT INTO LST_REGJ215
                                                 ,LST_CDHISTFAT
                                                 ,LST_VLFATCONT;
          IF LST_REGJ215.EXISTS(1) THEN
           BEGIN
             FOR IDX_J215 IN LST_REGJ215.FIRST..LST_REGJ215.LAST LOOP
              BEGIN
                SELECT SEQ1_ECDFATCTBDLPADMPL_J22.NEXTVAL INTO PIDR215 FROM DUAL;
                INSERT INTO ECDFATCTBDLPADMPL_J22( J22_IDCODIGO
                                                  ,SMECODIGO
                                                  ,J22_CDREG
                                                  ,J22_CDAGL
                                                  ,J22_CDHISTFAT
                                                  ,J22_VLFATCONT
                                                  ,J22_CDINDDCFAT
                                                  ,IDRJ210
                                                  ,J22_DTINCLUSAO
                                                  ,J22_USINCLUSAO )
                                          VALUES (PIDR215
                                                 ,LST_SMECODIGO(IDX_J210)
                                                 ,LST_REGJ215(IDX_J215)
                                                 ,LST_CDAGL(IDX_J210)
                                                 ,LST_CDHISTFAT(IDX_J215)
                                                 ,TO_CHAR(ABS(LST_VLFATCONT(IDX_J215)),'FM99999999999999990D00')
                                                 ,CASE WHEN (TO_NUMBER(LST_VLFATCONT(IDX_J215)) >= 0)
                                                       THEN 'D'
                                                       ELSE 'C'
                                                   END
                                                 ,PIDR210
                                                 ,SYSDATE
                                                 ,GET_USER_MXM);
                PTOTALREGISTRO_J215 := PTOTALREGISTRO_J215 + 1;
              END;
              LST_REGJ215.EXTEND;
              LST_CDHISTFAT.EXTEND;
              LST_VLFATCONT.EXTEND;
             END LOOP;
                LST_REGJ215.DELETE;
             LST_CDHISTFAT.DELETE;
             LST_VLFATCONT.DELETE;
           END;
          END IF;
          LST_REGJ210.EXTEND;
          LST_VBINDTIP.EXTEND;
          LST_CDAGL.EXTEND;
          LST_DSCODAGL.EXTEND;
          LST_VLCTA.EXTEND;
          LST_VLCTAINI.EXTEND;
          LST_SMECODIGO.EXTEND;
         END;
       END LOOP;
       LST_REGJ210.DELETE;
       LST_VBINDTIP.DELETE;
       LST_CDAGL.DELETE;
       LST_DSCODAGL.DELETE;
       LST_VLCTA.DELETE;
       LST_VLCTAINI.DELETE;
       LST_SMECODIGO.DELETE;
     END;
    END IF;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 278226
PROMPT ======================================================================