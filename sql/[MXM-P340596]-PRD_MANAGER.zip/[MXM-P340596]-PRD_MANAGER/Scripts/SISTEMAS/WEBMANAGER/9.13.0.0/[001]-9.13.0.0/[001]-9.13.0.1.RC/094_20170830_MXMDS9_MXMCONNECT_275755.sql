PROMPT ======================================================================
PROMPT == DEMANDA......: 275755
PROMPT == SISTEMA......: MXM CONNECT
PROMPT == RESPONSAVEL..: PALOMA CASSIA CAMPELO DE OLIVEIRA
PROMPT == DATA.........: 07/08/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

DELETE
  FROM GREFILTROCAMPOTAB_FCT
where FCT_NMCAMPO      = 'RECPROCRECRUTAMENTO_PRC.PRC_IDRECRUTAMENTO'
AND FCT_TPFILTRO       IN (0, 1)
AND FCT_TABELARELVISAO =   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
/

 INSERT INTO grefiltrocampotab_fct
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Recrutamento', --Descri��o do filtro na tela onde imprime o relat�rio
   0,
   2,
   'RECPROCRECRUTAMENTO_PRC',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'RECPROCRECRUTAMENTO_PRC.PRC_IDRECRUTAMENTO',
   'Recrutamento' --Descri��o do filtro na montagem do relat�rio
   )
/

INSERT INTO JANELAJUDA_JAJU (JAJU_ARQUIVO, JAJU_CODIGO, JAJU_TAMANHO, JAJU_NUMCAMPO, JAJU_COMPRIMENTO, JAJU_PROCURA, JAJU_DSFROM, JAJU_DSWHERE, JAJU_NOMEPROCURA, JAJU_TODOS, JAJU_DSORDERBY)
                VALUES
                ('RECENTREVISTA_ENT', 'Y13', 535, 'ENT_IDENTREVISTA', 300, 'ENT_DSOBSERVACAO',
                'RECPROCRECRUTAMENTO_PRC, RECENTREVISTA_ENT',
                'ENT_IDPROCESSO = PRC_IDRECRUTAMENTO',
                'Entrevista processo',
                 'S',
                 'ENT_DSOBSERVACAO')
/

INSERT INTO JANELAJUDA_JAJU (JAJU_ARQUIVO, JAJU_CODIGO, JAJU_TAMANHO, JAJU_NUMCAMPO, JAJU_COMPRIMENTO, JAJU_PROCURA, JAJU_DSFROM, JAJU_DSWHERE, JAJU_NOMEPROCURA, JAJU_TODOS, JAJU_DSORDERBY)
                VALUES
                ('CNTUSUARIO_USU', 'Y14', 535, 'USU_IDUSUARIO', 300, 'USU_NMNOME',
                null,
                null,
                'Usu�rio', 'S', 'USU_NMNOME')
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y13', '001', 'ENT_IDENTREVISTA', 'Entrevista', NULL, NULL)
/

INSERT INTO campoajuda_caju(caju_codigo, caju_sequencia, caju_numcampo, caju_cabecalho, caju_dsqueryfield, caju_formatfield)
                  VALUES('Y13', '008', 'ENT_DSOBSERVACAO', 'Observa��o', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y13', '002', 'ENT_IDENTREVISTADOR', 'Entrevistador', NULL, NULL)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y13', '003', 'ENT_DTENTREVISTA', 'Data do agendamento', NULL, 'dd/mm/yy')
/

    INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y13', '004', 'TO_CHAR(ENT_DTENTREVISTA , ''HH24:mi'')', 'Hora do agendamento', 'ENT_DTENTREVISTA', null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y13', '005', 'ENT_USCADASTRADOPOR', 'Entr. agendada por', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y13', '006', 'ENT_USALTERADOEM', 'Entr. alterada por', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y13', '007',  'DECODE(ENT_VBRESULTADO, 1, ''Aprovado'', ''Reprovado'')', 'Resultado entrevista', 'ENT_VBRESULTADO', null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y07', '003', 'PRC_DTCRIACAO', 'Data de abertura', null, 'dd/mm/yy')
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y07', '004', 'PRC_IDUSUARIOREQUISITANTE', 'Requisitante', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y07', '005', 'PRC_VLREMUNERACAO', 'Remun. proposta', null, '#,##0.00')
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y07', '006', 'PRC_USCRIACAO', 'Proc. criado por', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y07', '007', 'PRC_USALTERACAO', 'Proc. alterado por', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y07', '008', 'PRC_DTFINALIZACAO', 'Dt encerramento', null, 'dd/mm/yy')
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y09', '003', 'CAN_DSDOCUMENTO', 'Doc. do candidato', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y09', '004', 'DECODE(CAN_CDSEXO, ''M'',''Masculino'', ''Feminino'')', 'Sexo do candidato', 'CAN_CDSEXO', null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y09', '005', 'CAN_DTNASCIMENTO', 'Nascimento candidato', null, 'dd/mm/yy')
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y09', '006', 'CAN_DSPROFISSAO', 'Profiss�o candidato', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y09', '007', 'CAN_DSPAIS', 'Nacionalidade', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y09', '008', 'DECODE(CAN_VBINATIVACAO, 0,''S'', ''N'')', 'Candidato ativo', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y09', '009', 'DECODE(CAN_VBTRABALHOU, 1,''S'', ''N'')', 'Trab. na empresa', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y09', '010', 'CAN_IDCADASTRADOPOR', 'Cadastrado por', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y09', '011', 'CAN_USALTERADOPOR', 'Alterado por', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y14', '001', 'USU_IDUSUARIO', 'Id usu�rio', null, null)
/

INSERT INTO CAMPOAJUDA_CAJU (CAJU_CODIGO, CAJU_SEQUENCIA, CAJU_NUMCAMPO, CAJU_CABECALHO, CAJU_DSQUERYFIELD, CAJU_FORMATFIELD)
    VALUES ('Y14', '002', 'USU_NMNOME', 'Nome usu�rio', null, null)
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Filial',
   0,
   2,
   'RECFILIAL_FIL',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECFILIAL_FIL')),
   'RECFILIAL_FIL.FIL_IDFILIAL',
   'Filial'
   )
/

INSERT INTO grefiltrocampotab_fct
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Data de abertura',
   0,
   1,
   '',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'RECPROCRECRUTAMENTO_PRC.PRC_DTCRIACAO',
   'Data de abertura'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Departamento', --Descri��o do filtro na tela onde imprime o relat�rio
   0,
   2,
   'RECDEPARTAMENTO_DEP',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECDEPARTAMENTO_DEP')),
   'RECDEPARTAMENTO_DEP.DEP_IDDEPARTAMENTO',
   'Departamento' --Descri��o do filtro na montagem do relat�rio
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Requisitante', --Descri��o do filtro na tela onde imprime o relat�rio
   0,
   2,
   'CNTUSUARIO_USU',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'RECPROCRECRUTAMENTO_PRC.PRC_IDUSUARIOREQUISITANTE',
   'Requisitante' --Descri��o do filtro na montagem do relat�rio
 )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Aprovador', --Descri��o do filtro na tela onde imprime o relat�rio
   0,
   2,
   'CNTUSUARIO_USU',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'RECPROCRECRUTAMENTO_PRC.PRC_IDUSUARIOGERENTE',
   'Aprovador' --Descri��o do filtro na montagem do relat�rio
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Remunera��o proposta', --Descri��o do filtro na tela onde imprime o relat�rio
   0,
   3,
   null,
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'RECPROCRECRUTAMENTO_PRC.PRC_VLREMUNERACAO',
   'Remunera��o proposta' --Descri��o do filtro na montagem do relat�rio
   )
/

DELETE FROM GREFILTROCAMPOTAB_FCT
where FCT_NMCAMPO      = 'RECCANDIDATO_CAN.CAN_IDCANDIDATO'
AND FCT_TPFILTRO       = 0
AND FCT_TABELARELVISAO =  (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN'))
/

 INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Candidato',
   0,
   2,
   'RECCANDIDATO_CAN',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
   'RECCANDIDATO_CAN.CAN_IDCANDIDATO',
   'Candidato'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Documento do candidato',
   0,
   0,
   '',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
   'RECCANDIDATO_CAN.CAN_DSDOCUMENTO',
   'Documento do candidato'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Processo criado por',
   0,
   2,
   'CNTUSUARIO_USU',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'RECPROCRECRUTAMENTO_PRC.PRC_USCRIACAO',
   'Processo criado por'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Processo alterado por',
   0,
   2,
   'CNTUSUARIO_USU',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'RECPROCRECRUTAMENTO_PRC.PRC_USALTERACAO',
   'Processo alterado por'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Nascimento do candidato',
   0,
   1,
   null,
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
   'RECCANDIDATO_CAN.CAN_DTNASCIMENTO',
   'Nascimento do candidato'
   )
/

 INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct), --fct_idfiltrocampo
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Profiss�o do candidato',
   0,
   0,
   null,
   '',
   '',
   null, -- tradu��o do fct_tpfiltro se =1 , para 'S' ou 'N' Ex: DECODE(IREQCOMPRA_IRC.IRC_STATUS,'T','S', 'N')
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
   'RECCANDIDATO_CAN.CAN_DSPROFISSAO',
   'Profiss�o do candidato'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Nacionalidade do candidato',
   0,
   0,
   null,
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
   'RECCANDIDATO_CAN.CAN_DSPAIS',
   'Nacionalidade do candidato'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Candidato ativo',
   1,
   0,
   'RECCANDIDATO_CAN',
   '',
   '',
   'DECODE(CAN_VBINATIVACAO, 0, ''S'', ''N'')',
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
   'RECCANDIDATO_CAN.CAN_VBINATIVACAO',
   'Candidato ativo'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct), --fct_idfiltrocampo
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Candidato trabalhou na empresa',
   1,
   0,
   'RECCANDIDATO_CAN',
   '',
   '',
   'DECODE(CAN_VBTRABALHOU, 1, ''S'', ''N'')',
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
   'RECCANDIDATO_CAN.CAN_VBTRABALHOU',
   'Candidato trabalhou na empresa'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Candidato cadastrado por',
   0,
   2,
   'CNTUSUARIO_USU',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
   'RECCANDIDATO_CAN.CAN_IDCADASTRADOPOR',
   'Candidato cadastrado por'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct), --fct_idfiltrocampo
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Candidato alterado por',
   0,
   2,
   'CNTUSUARIO_USU',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECCANDIDATO_CAN')),
   'RECCANDIDATO_CAN.CAN_USALTERADOPOR',
   'Candidato alterado por'
   )
/

DELETE FROM GREFILTROCAMPOTAB_FCT
where FCT_NMCAMPO      = 'RECPROCRECRUTAMENTO_PRC.PRC_DTFINALIZACAO'
AND FCT_TPFILTRO       = 0
AND FCT_TABELARELVISAO =   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Dt. encerramento processo',
   0,
   1,
   '',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'RECPROCRECRUTAMENTO_PRC.PRC_DTFINALIZACAO',
   'Dt. encerramento processo'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Entrevistador',
   0,
   2,
   'CNTUSUARIO_USU',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECENTREVISTA_ENT')),
   'RECENTREVISTA_ENT.ENT_IDENTREVISTADOR',
   'Entrevistador'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Entrevista',
   0,
   2,
   'RECENTREVISTA_ENT',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECENTREVISTA_ENT')),
   'RECENTREVISTA_ENT.ENT_IDENTREVISTA',
   'Entrevista'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct), --fct_idfiltrocampo
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Entrevista agendada por', --Descri��o do filtro na tela onde imprime o relat�rio
   0,
   2,
   'CNTUSUARIO_USU',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECENTREVISTA_ENT')),
   'RECENTREVISTA_ENT.ENT_USCADASTRADOPOR',
   'Entrevista agendada por'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Entrevista Alterada por',
   0,
   2,
   'CNTUSUARIO_USU',
   '',
   '',
   null,
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECENTREVISTA_ENT')),
   'RECENTREVISTA_ENT.ENT_USALTERADOEM',
   'Alterada por'
   )
/

INSERT INTO GREFILTROCAMPOTAB_FCT
  (fct_idfiltrocampo,
   fct_nrvisao,
   fct_dsfiltro,
   fct_tpfiltro,
   fct_tpcampofiltro,
   fct_nmarquivoajuda,
   fct_nmlistatabela,
   fct_nmlistacondicaoajuda,
   fct_nmcondcampochb,
   fct_tabelarelvisao,
   fct_nmcampo,
   fct_dsfiltrocabecalho)
VALUES
  ((SELECT MAX(fct_idfiltrocampo) + 1 FROM grefiltrocampotab_fct),
   (SELECT vdr_idvisao
      FROM grevisaotab_vdr
     WHERE vdr_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'Contrata��es realizadas',
   1,
   0,
   null,
   '',
   '',
   'DECODE(PRC_STATUSCONTRATACAO,  1, ''S'', ''N'')',
   (SELECT trv_idtabelarelvisao
      FROM gretabelarelvisal_trv
     WHERE trv_nrvisao =
           (SELECT vdr_idvisao
              FROM grevisaotab_vdr
             WHERE vdr_nrtabela =
                   (SELECT tdr_idtabela
                      FROM gretabdicdados_tdr
                     WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC'))
       AND trv_nrtabela =
           (SELECT tdr_idtabela
              FROM gretabdicdados_tdr
             WHERE tdr_nmtabela = 'RECPROCRECRUTAMENTO_PRC')),
   'RECPROCRECRUTAMENTO_PRC.PRC_STATUSCONTRATACAO',
   'Contrata��es realizadas'
   )
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 275755
PROMPT ======================================================================