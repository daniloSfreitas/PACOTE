PROMPT ======================================================================
PROMPT == DEMANDA......: 265950
PROMPT == SISTEMA......: Business Process Management Suite
PROMPT == RESPONSAVEL..: PABLO ROBERTO L. DE AZEVEDO
PROMPT == DATA.........: 02/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION get_descrparschedule (
   ptpfiltro       IN   CHAR,
   pdsparam        IN   CHAR,
   pvlcalculado    IN   CHAR,
   pvlcalculado2   IN   CHAR
)
   RETURN CHAR
IS
   vparam   VARCHAR2 (256);
BEGIN
   vparam := '';
   IF (ptpfiltro = 2)
   THEN
      BEGIN
         IF (pvlcalculado IS NOT NULL)
         THEN
            BEGIN
               IF (pvlcalculado2 IS NOT NULL)
               THEN
                  vparam :=
                     pdsparam || ': ' || pvlcalculado || ' at� '
                     || pvlcalculado2;
               ELSE
                  vparam := pdsparam || ': ' || pvlcalculado;
               END IF;
            END;
         ELSE
            IF (pvlcalculado2 IS NOT NULL)
            THEN
               vparam := pdsparam || ':  at� ' || pvlcalculado2;
            ELSE
               vparam := pdsparam || ':';
            END IF;
         END IF;
      END;
   ELSE
      IF (pvlcalculado2 IS NOT NULL)
      THEN
         vparam := pdsparam || ': ' || pvlcalculado;
      ELSE
         vparam := pdsparam || ':';
      END IF;
   END IF;
   RETURN vparam;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 265950
PROMPT ======================================================================