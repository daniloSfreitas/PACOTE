PROMPT ======================================================================
PROMPT == DEMANDA......: 277654
PROMPT == SISTEMA......: Contas a Pagar
PROMPT == RESPONSAVEL..: WALTER FERREIRA NETO
PROMPT == DATA.........: 18/09/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRETABELARELVISAL_TRV
SET TRV_NMCONDICAOTABREL = '(TITCP_TCP.TCP_CDFMPAGBAN = FORMAPAGBAN_FPB.FPB_CDFMPAGBAN OR TITCP_TCP.TCP_CDFMPAGBANPR = FORMAPAGBAN_FPB.FPB_CDFMPAGBAN)'
WHERE TRV_NMCONDICAOTABREL = 'TITCP_TCP.TCP_CDFMPAGBAN = FORMAPAGBAN_FPB.FPB_CDFMPAGBAN(+)'
  AND trv_nrvisao = (SELECT vdr_idvisao
         FROM grevisaotab_vdr
        WHERE vdr_nrtabela = (SELECT tdr_idtabela
                                FROM gretabdicdados_tdr
                               WHERE tdr_nmtabela = 'TITCP_TCP'))
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 277654
PROMPT ======================================================================