PROMPT ======================================================================
PROMPT == DEMANDA......: 271226
PROMPT == SISTEMA......: Estoque
PROMPT == RESPONSAVEL..: CAIXA FATURAMENTO
PROMPT == DATA.........: 02/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE ESTOQUES_EST
   SET EST_TPMERCADORIA = '1'
 WHERE EST_TPMERCADORIA = '0'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 271226
PROMPT ======================================================================