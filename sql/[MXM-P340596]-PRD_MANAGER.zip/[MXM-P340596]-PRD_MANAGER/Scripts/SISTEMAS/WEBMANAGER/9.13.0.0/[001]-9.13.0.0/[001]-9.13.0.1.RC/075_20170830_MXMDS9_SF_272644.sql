PROMPT ======================================================================
PROMPT == DEMANDA......: 272644
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: DIOGO_RODRIGUES
PROMPT == DATA.........: 11/07/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_TOTALSERVICOFAT(
  PIFAT_CDEMPRESA IN CHAR
  ,PIFAT_CDFILIAL IN CHAR
  ,PIFAT_CDFATURA IN NUMBER)
RETURN NUMBER IS
  VRETORNO             NUMBER(23,4);
  VNOTAFISCAL          VARCHAR2(1);
  VNOTALFISCALSEMVALOR VARCHAR2(1);
BEGIN
  SELECT
    TPO_NOTAFISCAL, TPO_NFSEMVALOR
  INTO
    VNOTAFISCAL, VNOTALFISCALSEMVALOR
  FROM
    FATURAS_FAT, TPOPER_TPO
  WHERE
    FAT_CDEMPRESA    = PIFAT_CDEMPRESA
    AND FAT_CDFILIAL = PIFAT_CDFILIAL
    AND FAT_CDFATURA = PIFAT_CDFATURA
    AND FAT_TPOPER   = TPO_CODIGO;
  -- Quando no cadastro do tipo de opera��o o campo Documento for igual a M-Nota fiscal de servi�o
  -- funer�rio e a op��o Nota fiscal sem valor estiver marcada, o total do servi�o ser� igual a  0
  -- (zero).
  IF (VNOTAFISCAL = 'M' AND VNOTALFISCALSEMVALOR = 'S') THEN
    VRETORNO := 0;
  ELSE
    SELECT
      NVL(SUM(DECODE(TPO_ISSDESTACADO, 'S', IFAT_VLRPROD, IFAT_VLRPROD + IFAT_VLRISS)), 0)
    INTO
      VRETORNO
    FROM
      ITFATURA_IFAT, TPOPER_TPO
    WHERE
      IFAT_CDEMPRESA    = PIFAT_CDEMPRESA
      AND IFAT_CDFILIAL = PIFAT_CDFILIAL
      AND IFAT_CDFATURA = PIFAT_CDFATURA
      AND TPO_CODIGO    = IFAT_TPOPER;
  END IF;
RETURN (VRETORNO) ;
END;
/

UPDATE  TPOPER_TPO T
SET     T.TPO_NOTAFISCAL = 'U'
WHERE   T.TPO_NOTAFISCAL = 'M'
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 272644
PROMPT ======================================================================