PROMPT ======================================================================
PROMPT == DEMANDA......: 271958
PROMPT == SISTEMA......: Gestao de Processos
PROMPT == RESPONSAVEL..: MARCEL BRUNO BARREIROS COSTA
PROMPT == DATA.........: 24/05/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

UPDATE GRETABELARELVISAL_TRV
   SET TRV_NMCONDICAOTABREL = 'TITCPGR_PGRR.PGRR_CDFOR = TITCP_TCPR.TCPR_CDFOR
   AND TITCPGR_PGRR.PGRR_NOTITULO = TITCP_TCPR.TCPR_NOTITULO
   AND TITCPGR_PGRR.PGRR_PLCCUSTO = VW_CCUSTO_CC.CC_CODCENT(+)
   AND TITCPGR_PGRR.PGRR_NOCCUSTO = VW_CCUSTO_CC.CC_CODIGO(+)'
 WHERE TRV_NRVISAO =
       (SELECT VDR_IDVISAO
          FROM GREVISAOTAB_VDR
         WHERE VDR_NRTABELA =
               (SELECT TDR_IDTABELA
                  FROM GRETABDICDADOS_TDR
                 WHERE TDR_NMTABELA = 'TITCP_TCPR'))
   AND TRV_NRTABELA = (SELECT TDR_IDTABELA
                         FROM GRETABDICDADOS_TDR
                        WHERE TDR_NMTABELA = 'VW_CCUSTO_CC')
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 271958
PROMPT ======================================================================