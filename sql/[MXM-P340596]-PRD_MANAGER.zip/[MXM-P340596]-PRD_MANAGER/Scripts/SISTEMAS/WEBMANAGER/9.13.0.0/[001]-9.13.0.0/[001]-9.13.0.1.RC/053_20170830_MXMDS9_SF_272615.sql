PROMPT ======================================================================
PROMPT == DEMANDA......: 272615
PROMPT == SISTEMA......: Sistema de Faturamento
PROMPT == RESPONSAVEL..: LEONARDO OLIVEIRA GOMES
PROMPT == DATA.........: 12/06/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

ALTER TABLE CODISS_ISS
MODIFY (ISS_CDSERVICO VARCHAR2(50))
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 272615
PROMPT ======================================================================