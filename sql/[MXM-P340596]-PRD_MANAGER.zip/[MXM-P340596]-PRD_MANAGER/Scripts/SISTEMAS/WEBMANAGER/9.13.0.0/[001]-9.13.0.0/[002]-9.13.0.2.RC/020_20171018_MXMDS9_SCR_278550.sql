PROMPT ======================================================================
PROMPT == DEMANDA......: 278550
PROMPT == SISTEMA......: Contas a Receber
PROMPT == RESPONSAVEL..: MARCOS FELIPE DE CARVALHO FIGUEIRED
PROMPT == DATA.........: 17/10/2017
PROMPT == BASE.........: MXMDS9
PROMPT == OWNER DESTINO: MXMDS9
PROMPT ======================================================================

SET DEFINE OFF;

CREATE OR REPLACE FUNCTION GET_NNCAIXA
  (pCdEmpBco   IN CHAR,                -- Codigo da  Empresa no Banco (conv�nio)
   pCdConta    IN CHAR,                -- Codigo da Conta Corrente Banco
   pCtaCodigo  IN CHAR,                -- Codigo da Conta Manager
   pIdPort     IN CHAR,                -- nosso n�mero do t�tulo
   pCDCliente  IN CHAR,                -- C�digo do Cliente
   pNOTitulo   IN CHAR,                -- Numero do T�tulo
   pCarteira   IN CHAR,                -- Carteira (parametro da tela)
   pGetDigito  IN BOOLEAN DEFAULT TRUE)-- Retorna com DV do nosso numero
  RETURN VARCHAR
IS
  ProxNum             VARCHAR2(19);
  MaxNN               VARCHAR2(19);
  NossoNumero         VARCHAR2(19);
  sIdPort             VARCHAR2(19);
  CURSOR GETPARAMSATUALNNUMERO IS
   SELECT PAR_VLPARAM
     FROM PARAMS_PAR
    WHERE PAR_CDPARAM = 'wSCE_MINNUM104';
  CURSOR GETPARAMSMAXNNUMERO IS
   SELECT PAR_VLPARAM
     FROM PARAMS_PAR
    WHERE PAR_CDPARAM = 'wSCE_MAXNUM104';
PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN
  IF pIdPort IS NULL THEN
    OPEN GETPARAMSATUALNNUMERO;
    FETCH GETPARAMSATUALNNUMERO
    INTO ProxNum;
    OPEN GETPARAMSMAXNNUMERO;
    FETCH GETPARAMSMAXNNUMERO
    INTO MaxNN;
    IF ProxNum IS NULL THEN
      --Caso n�o esteja parametrizado o valor m�nimo do nosso n�mero no parametros do SCE
      --assume o valor inicial de 1 de tamanho 15 que o layout determina para calculo do DV
      ProxNum := '000000000000001';
    END IF;
    IF MaxNN IS NULL THEN
      --Caso n�o esteja parametrizado o valor m�ximo do nosso n�mero no parametros do SCE
      --assume o valor m�ximo de tamanho 15 para compara��o com o m�nimo e assume o limite
      MaxNN   := '999999999999999';
      UPDATE PARAMS_PAR
         SET PAR_VLPARAM = MaxNN
       WHERE PAR_CDPARAM = 'wSCE_MAXNUM104';
    END IF;
    IF TO_NUMBER(ProxNum) > TO_NUMBER(MaxNN) THEN
      ProxNum := '000000000000001';
    END IF;
    WHILE LENGTH(ProxNum) < 15 LOOP
     ProxNum := '0' || ProxNum;
    END LOOP;
    IF (NOT pGetDigito) THEN
      NossoNumero := pCarteira || ProxNum;
    ELSE
      NossoNumero := pCarteira || ProxNum || '-' || MOD11(pCarteira || ProxNum);
    END IF;
    -- Atualiza o t�tulo com o nosso n�mero gerado.
    UPDATE TITCR_TCR
       SET TCR_IDPORTADO = REPLACE(NossoNumero,'-'),
           TCR_PORTADOR  = pCtaCodigo
     WHERE TCR_CDCLIENTE = pCDCliente
       AND TCR_NOTITULO  = pNOTitulo;
    --Atualiza o nosso n�mero no par�metro somando 1 para n�o gerar duplicidade no SCE
    UPDATE PARAMS_PAR
       SET PAR_VLPARAM = TO_NUMBER(ProxNum) +1
     WHERE PAR_CDPARAM = 'wSCE_MINNUM104';
    COMMIT;
    RETURN NossoNumero;
  ELSE
    --Para o boleto tem que ir o DV com o "-"
    IF INSTR(pIdPort,'-')>0 THEN
      sIdPort := pIdPort;
    ELSE
      sIdPort := SUBSTR(pIdPort,1,(LENGTH(pIdPort)-1)) ||'-'|| SUBSTR(pIdPort,LENGTH(pIdPort),1);
    END IF;
    RETURN sIdPort;
  END IF;
END;
/

COMMIT;

PROMPT ======================================================================
PROMPT == FIM 278550
PROMPT ======================================================================