SET SERVEROUT ON
PROMPT ========================================================================================================
PROMPT LIMPANDO RECYCLEBIN, AGUARDE...
PROMPT ========================================================================================================
DECLARE
BEGIN
	EXECUTE IMMEDIATE 'PURGE RECYCLEBIN';
END;
/


PROMPT ========================================================================================================
PROMPT CONCEDENDO PERMISSOES AOS OBJETOS CRIADOS, AGUARDE...
PROMPT ========================================================================================================
SET SERVEROUT ON
DECLARE 
	V_QDESUC INTEGER;	
	V_QDEERR INTEGER;
	CURSOR C_OBJ_GRANTS IS 
					SELECT 
						'GRANT '||PRIVILEGELIST.PRIVILEGE ||' ON "'||PRIVILEGELIST.OBJECT_NAME||'" TO MXMSYS' COMANDO
					FROM (SELECT 
							UO.OBJECT_TYPE, 
							REALGRANTS.PRIVILEGE, 
							UO.OBJECT_NAME 
						FROM (
							SELECT 'TABLE' 		OBJECT_TYPE, 'INSERT' 	PRIVILEGE FROM DUAL UNION
							SELECT 'TABLE' 		OBJECT_TYPE, 'DELETE' 	PRIVILEGE FROM DUAL UNION
							SELECT 'TABLE' 		OBJECT_TYPE, 'UPDATE' 	PRIVILEGE FROM DUAL UNION
							SELECT 'TABLE' 		OBJECT_TYPE, 'SELECT' 	PRIVILEGE FROM DUAL UNION
							SELECT 'VIEW' 		OBJECT_TYPE, 'SELECT' 	PRIVILEGE FROM DUAL UNION
							SELECT 'SEQUENCE' 	OBJECT_TYPE, 'SELECT' 	PRIVILEGE FROM DUAL UNION
							SELECT 'PROCEDURE' 	OBJECT_TYPE, 'EXECUTE' 	PRIVILEGE FROM DUAL UNION
							SELECT 'FUNCTION' 	OBJECT_TYPE, 'EXECUTE' 	PRIVILEGE FROM DUAL UNION
							SELECT 'PACKAGE' 	OBJECT_TYPE, 'EXECUTE' 	PRIVILEGE FROM DUAL ) REALGRANTS
					INNER JOIN 
						(SELECT 
							OBJECT_TYPE, 
							OBJECT_NAME 
						FROM USER_OBJECTS 
							WHERE OBJECT_TYPE IN ('PROCEDURE','FUNCTION','VIEW','TABLE','SEQUENCE','PACKAGE')) UO 
					ON (REALGRANTS.OBJECT_TYPE=UO.OBJECT_TYPE)) PRIVILEGELIST
					WHERE NOT EXISTS ( SELECT 1 
										FROM 	USER_TAB_PRIVS UTP
										WHERE 	UTP.TABLE_NAME=PRIVILEGELIST.OBJECT_NAME
										AND 	UTP.PRIVILEGE=PRIVILEGELIST.PRIVILEGE
										AND 	UTP.GRANTEE='MXMSYS' 
										AND 	UTP.OWNER=USER );	
BEGIN
	V_QDESUC:=0;
	V_QDEERR:=0;
	FOR IDX IN C_OBJ_GRANTS LOOP
			BEGIN
				EXECUTE IMMEDIATE (IDX.COMANDO);
				V_QDESUC:=V_QDESUC+1;
				EXCEPTION WHEN OTHERS THEN 
					V_QDEERR:=V_QDEERR+1;
					DBMS_OUTPUT.PUT_LINE(SQLERRM);
			END;		
	END LOOP;
	DBMS_OUTPUT.PUT_LINE('**************************************************');
	DBMS_OUTPUT.PUT_LINE('Grants concedidos com sucesso: '||V_QDESUC);
	DBMS_OUTPUT.PUT_LINE('Grants concedidos SEM sucesso: '||V_QDEERR);
	DBMS_OUTPUT.PUT_LINE('**************************************************');
END;
/



PROMPT ========================================================================================================
PROMPT CRIANDO SINONIMOS AOS OBJETOS CRIADOS(CASO AMBIENTE=2), AGUARDE...
PROMPT ========================================================================================================
DECLARE 
	PRAGMA AUTONOMOUS_TRANSACTION;	
	CONTADOR   INTEGER;
	CURSOR C_OBJ_SINONIMOS IS SELECT  'CREATE PUBLIC SYNONYM '||OBJECT_NAME||' FOR '||OBJECT_NAME AS SINONIMO
                           FROM USER_OBJECTS
                           WHERE OBJECT_TYPE IN ('PROCEDURE','FUNCTION','VIEW','TABLE','SEQUENCE','PACKAGE','PACKAGE BODY')
                           AND
                                 NOT EXISTS (SELECT SYNONYM_NAME 
                                             FROM ALL_SYNONYMS
                                             WHERE OWNER='PUBLIC' AND
                                                   TABLE_OWNER=user AND
                                                    SYNONYM_NAME = OBJECT_NAME)
                           ORDER BY 1;	
BEGIN
	SELECT COUNT(1) INTO contador  FROM all_synonyms
	WHERE owner = 'PUBLIC' AND table_owner = USER  AND table_name in ('CLIENTE_CLI','PLANOCTA_PLC','LANCCTB_LCT','TITCP_TCP');
	IF contador <> 4 THEN
		DBMS_OUTPUT.put_line ('A base n�o possui sin�nimos.');
	ELSE
		DBMS_OUTPUT.put_line ('A base possui sin�nimos.');
	    FOR COMANADO IN C_OBJ_SINONIMOS LOOP
	    	BEGIN
	    		EXECUTE IMMEDIATE (COMANADO.SINONIMO);
	    		EXCEPTION WHEN OTHERS THEN NULL;
	    	END;			
	    END LOOP;
	END IF;	
END;
/



PROMPT ========================================================================================================
PROMPT VALIDANDO OBJETOS, AGUARDE...
PROMPT ========================================================================================================
DECLARE 
	V_QDEANTES INTEGER;	
	V_QDDEPOIS INTEGER;
	V_QDETMPRA INTEGER;
	CURSOR C_OBJ_INVALIDOS IS SELECT     
	'ALTER '||DECODE (OBJECT_TYPE, 
		'PACKAGE BODY', 
		'PACKAGE "' ||OBJECT_NAME||'" COMPILE BODY', 
		OBJECT_TYPE ||' "' ||OBJECT_NAME||'" COMPILE') COMANDO
		FROM USER_OBJECTS
   WHERE STATUS = 'INVALID';	
BEGIN
	SELECT COUNT(1) INTO V_QDEANTES FROM USER_OBJECTS WHERE STATUS='INVALID';
	FOR IDX IN 1..5 LOOP
		FOR IDX2 IN C_OBJ_INVALIDOS LOOP
			SELECT COUNT(1) INTO V_QDETMPRA FROM USER_OBJECTS WHERE STATUS='INVALID';
			BEGIN
				EXECUTE IMMEDIATE (IDX2.COMANDO);
				EXCEPTION WHEN OTHERS THEN NULL;
			END;			
		END LOOP;
		SELECT COUNT(1) INTO V_QDDEPOIS FROM USER_OBJECTS WHERE STATUS='INVALID';
		IF (V_QDETMPRA=V_QDDEPOIS) THEN
			EXIT;
		END IF;
	END LOOP;
	DBMS_OUTPUT.PUT_LINE('**************************************************');
	DBMS_OUTPUT.PUT_LINE('[ANTES ]- Total de Objetos Invalidos: '||V_QDEANTES);
	DBMS_OUTPUT.PUT_LINE('[DEPOIS]- Total de Objetos Invalidos: '||V_QDDEPOIS);
	DBMS_OUTPUT.PUT_LINE('Total de Objetos Validados..........: '||(V_QDEANTES-V_QDDEPOIS));
	DBMS_OUTPUT.PUT_LINE('**************************************************');
END;
/